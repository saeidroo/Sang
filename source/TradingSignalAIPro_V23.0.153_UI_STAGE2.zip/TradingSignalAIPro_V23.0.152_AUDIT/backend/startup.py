"""Application startup policies for independently managed background services."""
from __future__ import annotations

import os


def start_autopilot_on_server_start():
    """Start the paper-trading engine only after an explicit environment opt-in.

    The Storm Scout and its historical brain are independent background services.
    Starting the desktop app should learn and monitor by default, not silently
    enable a paper-entry scanner because a persisted AutoPilot config says enabled.
    Set AUTOPILOT_ENABLED=1 to opt in to automatic PAPER entries on startup.
    """
    if os.getenv('AUTOPILOT_ENABLED', '0').strip() != '1':
        print('[autopilot] شروع خودکار معامله‌گر خاموش است؛ مغز دیده‌بان و یادگیری مستقل فعال می‌مانند.')
        return {'ok': True, 'started': False, 'reason': 'startup_opt_in_required',
                'paper_only': True, 'entries_enabled': False}

    try:
        from backend import autopilot
        if not autopilot._CONFIG.get('enabled', True):
            print('[autopilot] معامله‌گر خودکار در تنظیمات غیرفعال است.')
            return {'ok': True, 'started': False, 'reason': 'disabled_in_config',
                    'paper_only': True, 'entries_enabled': False}
        result = autopilot.start(
            resume_entries=bool(autopilot._CONFIG.get('entries_enabled', True)))
        state = result.get('state') or {}
        if not result.get('ok'):
            print('[autopilot] شروع خودکار مسدود شد؛ هیچ worker جدیدی مجاز نشد.')
            return result
        print('[autopilot] شروع خودکار فعال شد؛ ورود جدید=' +
              str(bool(state.get('entries_enabled', result.get('entries_enabled', False)))) + '.')
        return result
    except Exception as exc:
        print(f'[autopilot] could not start: {exc}')
        return {'ok': False, 'started': False, 'reason': 'startup_error',
                'error': str(exc)[:240], 'paper_only': True, 'entries_enabled': False}

