"""Leakage-aware, cost-aware meta-labeling utilities (V22.2b)."""
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier

FEATURES = ['primary_prob','primary_conf','atr_pct','rsi','adx','vol_ratio','trend_up']
META_VERSION = 'meta-v2'

def _row(prob, row):
    close=float(row.get('close',1) or 1); atr=float(row.get('atr_14',0) or 0)
    vol=float(row.get('volume',1) or 1); vmean=float(row.get('volume_mean_20',vol) or vol)
    return {'primary_prob':float(prob),'primary_conf':abs(float(prob)-.5),
      'atr_pct':atr/max(abs(close),1e-9),'rsi':float(row.get('rsi_14',50) or 50),
      'adx':float(row.get('adx_14',20) or 20), 'vol_ratio':vol/max(vmean,1e-9),
      'trend_up':int(float(row.get('close',0) or 0)>float(row.get('ema_20',0) or 0)>float(row.get('ema_50',0) or 0))}

def _cost_bps(costs):
    costs=costs or {}
    vals=[float(costs.get(k,0.0)) for k in ('fee_bps','slippage_bps','spread_bps')]
    if any(not np.isfinite(x) or x<0 or x>500 for x in vals): raise ValueError('invalid cost configuration')
    return sum(vals)

class MetaLabeler:
    def __init__(self):
        self.model=None; self.is_fitted=False; self.threshold=.55; self.base_rate=.5; self.n_samples=0
        self.version=META_VERSION; self.training_end_pos=None; self.metrics={}

    def fit(self, probs, ind, threshold=.60, tp_mult=1.5, sl_mult=1.5, horizon=12, costs=None):
        """Fit only on supplied historical OOF segment; never reorders/compresses its timeline.

        A timeout is labeled from directional close-to-close return after round-trip
        costs. A same-bar TP+SL collision is excluded as ambiguous. Positions cannot overlap.
        """
        probs=np.asarray(probs,dtype=float); n=min(len(probs),len(ind))
        if n<200 or not {'high','low','close','atr_14'}.issubset(ind.columns): return False
        H=ind['high'].to_numpy(float); L=ind['low'].to_numpy(float); C=ind['close'].to_numpy(float); A=ind['atr_14'].to_numpy(float)
        fee=_cost_bps(costs)/10000.0; rows=[]; labels=[]; ends=[]; net=[]; busy_until=-1
        for i in range(n-1):
            p=probs[i]
            if i<=busy_until or not np.isfinite(p) or abs(p-.5)<threshold-.5: continue
            if not (np.isfinite(C[i]) and C[i]>0): continue
            a=A[i] if np.isfinite(A[i]) and A[i]>0 else C[i]*.01
            side=1 if p>=.5 else -1; tp=C[i]+side*tp_mult*a; sl=C[i]-side*sl_mult*a
            outcome=None; exit_idx=min(n-1,i+max(1,int(horizon))); ambiguous=False
            for j in range(i+1,min(n,i+1+max(1,int(horizon)))):
                hit_tp=H[j]>=tp if side>0 else L[j]<=tp
                hit_sl=L[j]<=sl if side>0 else H[j]>=sl
                if hit_tp and hit_sl: exit_idx=j; ambiguous=True; break
                if hit_tp: outcome=1; exit_idx=j; break
                if hit_sl: outcome=0; exit_idx=j; break
            if ambiguous: busy_until=exit_idx; continue
            gross=side*(C[exit_idx]/C[i]-1.0)
            rnet=gross-fee
            if outcome is None: outcome=int(rnet>0)
            rows.append(_row(p,ind.iloc[i])); labels.append(outcome); ends.append(exit_idx); net.append(rnet)
            busy_until=exit_idx
        if len(labels)<100 or len(set(labels))<2:return False
        X=pd.DataFrame(rows,columns=FEATURES).replace([np.inf,-np.inf],np.nan).fillna(0); y=np.asarray(labels,dtype=int)
        self.model=HistGradientBoostingClassifier(max_iter=120,max_leaf_nodes=7,learning_rate=.05,l2_regularization=2,random_state=42)
        self.model.fit(X,y); self.is_fitted=True; self.base_rate=float(y.mean()); self.n_samples=len(y)
        self.training_end_pos=int(max(ends)) if ends else None
        self.metrics={'label_version':META_VERSION,'n':len(y),'positive_rate':self.base_rate,'ambiguous_excluded':int(n-len(y)-1),'mean_net_return':float(np.mean(net)) if net else None,'cost_bps_round_trip':_cost_bps(costs)}
        return True

    def predict_meta(self, primary_prob, ind_row):
        if not self.is_fitted or self.model is None:return None
        x=pd.DataFrame([_row(primary_prob,ind_row)],columns=FEATURES).replace([np.inf,-np.inf],np.nan).fillna(0)
        return float(self.model.predict_proba(x)[0,1])

    def select_threshold(self, probs, meta_probs, ind, *, candidates=None, horizon=12, costs=None, min_trades=20):
        """Choose a threshold on a later, untouched OOF calibration block only."""
        p=np.asarray(probs,float); m=np.asarray(meta_probs,float); n=min(len(p),len(m),len(ind))
        if n<min_trades*2:return {'selected':False,'reason':'insufficient_holdout','threshold':self.threshold}
        candidates=list(candidates or np.arange(.50,.81,.05)); fee=_cost_bps(costs)/10000.0
        best=None
        for th in candidates:
            rets=[]; busy=-1
            for i in range(n-1):
                if i<=busy or not np.isfinite(p[i]) or not np.isfinite(m[i]) or m[i]<th or abs(p[i]-.5)<.10: continue
                side=1 if p[i]>=.5 else -1; entry=float(ind.iloc[i]['close'])
                if not np.isfinite(entry) or entry<=0: continue
                end=min(n-1,i+max(1,int(horizon))); a=float(ind.iloc[i].get('atr_14',entry*.01) or entry*.01); a=a if np.isfinite(a) and a>0 else entry*.01
                tp=entry+side*1.5*a; sl=entry-side*1.5*a
                for j in range(i+1,min(n,i+1+max(1,int(horizon)))):
                    hi=float(ind.iloc[j]['high']); lo=float(ind.iloc[j]['low'])
                    ht=hi>=tp if side>0 else lo<=tp; hs=lo<=sl if side>0 else hi>=sl
                    if ht and hs: end=j; break
                    if ht or hs: end=j; break
                r=side*(float(ind.iloc[end]['close'])/entry-1)-fee
                rets.append(r); busy=end
            if len(rets)<min_trades: continue
            arr=np.asarray(rets); score=float(arr.mean())
            item={'threshold':float(th),'n_trades':len(arr),'mean_net_return':score,'total_compounded_return':float(np.prod(1+arr)-1),'win_rate':float((arr>0).mean())}
            if best is None or score>best['mean_net_return']: best=item
        if best is None:return {'selected':False,'reason':'minimum_trade_count_not_met','threshold':self.threshold}
        self.threshold=best['threshold']; self.metrics['threshold_selection']=best
        return {'selected':True,**best}
