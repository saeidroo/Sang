"""Deterministic, read-only OHLCV market-regime classifier."""
from __future__ import annotations
import math
import pandas as pd


def classify_market_regime(candles) -> dict:
    frame = pd.DataFrame(candles).copy()
    required = ('open', 'high', 'low', 'close')
    if any(name not in frame.columns for name in required):
        raise ValueError('OHLC columns are required')
    for name in required:
        frame[name] = pd.to_numeric(frame[name], errors='coerce')
    frame = frame.replace([float('inf'), float('-inf')], float('nan')).dropna(subset=list(required))
    if len(frame) < 60:
        raise ValueError('برای تشخیص رژیم حداقل ۶۰ کندل معتبر لازم است')
    if (frame[list(required)] <= 0).any().any():
        raise ValueError('OHLC prices must be positive')
    if ((frame.high < frame[['open','close','low']].max(axis=1)) |
        (frame.low > frame[['open','close','high']].min(axis=1))).any():
        raise ValueError('Invalid OHLC candle bounds')
    close = frame.close.astype(float)
    high, low = frame.high.astype(float), frame.low.astype(float)
    fast = close.ewm(span=20, adjust=False).mean()
    slow = close.ewm(span=50, adjust=False).mean()
    tr = pd.concat([high-low, (high-close.shift()).abs(), (low-close.shift()).abs()], axis=1).max(axis=1)
    atr_pct = float(tr.rolling(14).mean().iloc[-1] / close.iloc[-1] * 100)
    slope_pct = float((slow.iloc[-1] / slow.iloc[-11] - 1) * 100)
    gap_pct = float((fast.iloc[-1] / slow.iloc[-1] - 1) * 100)
    net_move = abs(float(close.iloc[-1] / close.iloc[-21] - 1))
    path = float(close.diff().abs().iloc[-20:].sum() / max(close.iloc[-20], 1e-12))
    efficiency = net_move / path if path > 0 else 0.0
    if not all(math.isfinite(x) for x in (atr_pct, slope_pct, gap_pct, efficiency)):
        raise ValueError('Insufficient finite OHLC indicators')
    if atr_pct >= 3.5:
        regime = 'HIGH_VOLATILITY'
        label = 'نوسان شدید'
    elif slope_pct >= 0.18 and gap_pct > 0.08 and efficiency >= 0.22:
        regime, label = 'UPTREND', 'روند صعودی'
    elif slope_pct <= -0.18 and gap_pct < -0.08 and efficiency >= 0.22:
        regime, label = 'DOWNTREND', 'روند نزولی'
    elif efficiency <= 0.16:
        regime, label = 'RANGE', 'بازار رنج'
    else:
        regime, label = 'TRANSITION', 'تغییر رژیم / نامشخص'
    confidence = min(0.85, max(0.20, 0.35 + efficiency * 0.5 + min(abs(slope_pct), 1.0) * 0.15))
    return {'regime': regime, 'label_fa': label, 'confidence_pct': round(confidence*100, 2),
            'indicators': {'atr_pct': round(atr_pct, 4), 'ema_gap_pct': round(gap_pct, 4),
                           'ema_slope_10_pct': round(slope_pct, 4), 'efficiency_ratio': round(efficiency, 4)},
            'candles_used': len(frame), 'method': 'EMA20/EMA50 slope + ATR14% + 20-bar efficiency ratio',
            'read_only': True, 'real_orders_enabled': False,
            'warning': 'طبقه‌بندی تقریبی و توصیفی است؛ به‌تنهایی سیگنال ورود یا تضمین پیش‌بینی نیست.'}


REGIME_DIRECTION = {
    "UPTREND": "BULLISH", "DOWNTREND": "BEARISH", "RANGE": "NEUTRAL",
    "HIGH_VOLATILITY": "RISK_OFF", "TRANSITION": "UNCERTAIN",
}

def confirm_multi_timeframe_regimes(reports: dict) -> dict:
    """Summarize explicit 4h/1h/15m regime reports without inventing missing data.

    Alignment is descriptive and only supplies a bounded ranking multiplier; it
    never creates or reverses a BUY/SELL decision.
    """
    required = ("4h", "1h", "15m")
    normalized = {}
    for tf in required:
        item = reports.get(tf) if isinstance(reports, dict) else None
        regime = str((item or {}).get("regime") or "UNAVAILABLE").upper()
        if regime not in (*REGIME_DIRECTION.keys(), "UNAVAILABLE"):
            regime = "UNAVAILABLE"
        normalized[tf] = {
            "regime": regime,
            "confidence_pct": float((item or {}).get("confidence_pct") or 0.0),
        }
    available = [v["regime"] for v in normalized.values() if v["regime"] != "UNAVAILABLE"]
    if len(available) != 3:
        status, multiplier = "INSUFFICIENT_DATA", 1.0
    else:
        directions = [REGIME_DIRECTION[x] for x in available]
        # A strong directional conflict between the higher and entry timeframe
        # is a warning; no hard rejection or forced reversal is applied.
        high, mid, entry = directions
        if high == mid == entry:
            status, multiplier = "ALIGNED", 1.03
        elif high == "BULLISH" and entry == "BEARISH" or high == "BEARISH" and entry == "BULLISH":
            status, multiplier = "DIRECTIONAL_CONFLICT", 0.90
        elif len(set(directions)) == 1:
            status, multiplier = "ALIGNED", 1.03
        else:
            status, multiplier = "MIXED", 0.96
    confidence_values = [v["confidence_pct"] for v in normalized.values() if v["regime"] != "UNAVAILABLE"]
    return {
        "timeframes": normalized, "status": status,
        "agreement_count": (sum(1 for i in range(3) for j in range(i + 1, 3)
                                  if REGIME_DIRECTION[available[i]] == REGIME_DIRECTION[available[j]])
                            if len(available) == 3 else 0),
        "confidence_pct": round(sum(confidence_values) / len(confidence_values), 2) if confidence_values else 0.0,
        "ranking_multiplier": multiplier, "read_only": True, "real_orders_enabled": False,
        "warning": "تأیید چندتایم‌فریمی فقط رتبه‌بندی فرصت را تعدیل می‌کند؛ سیگنال یا سفارش واقعی ایجاد نمی‌کند.",
    }
