"""Deterministic, conservative paper-fill cost model (not an order-book simulator)."""
from __future__ import annotations
import math

DEFAULTS = {
    "fee_bps_per_side": 10.0,
    "slippage_bps_per_side": 5.0,
    "spread_bps_full": 2.0,
    "impact_bps_per_1000_usdt": 0.5,
    "max_impact_bps_per_side": 20.0,
}

def execution_costs(notional: float, overrides: dict | None = None) -> dict:
    cfg = dict(DEFAULTS)
    if isinstance(overrides, dict):
        cfg.update({k: overrides[k] for k in cfg if k in overrides})
    values = [float(notional)] + [float(cfg[k]) for k in cfg]
    if not all(math.isfinite(v) for v in values) or float(notional) <= 0:
        raise ValueError("notional and execution costs must be finite and positive")
    if any(float(cfg[k]) < 0 for k in cfg):
        raise ValueError("execution costs cannot be negative")
    impact = min(float(cfg["max_impact_bps_per_side"]),
                 float(cfg["impact_bps_per_1000_usdt"]) * (float(notional) / 1000.0))
    half_spread = float(cfg["spread_bps_full"]) / 2.0
    adverse_bps = half_spread + float(cfg["slippage_bps_per_side"]) + impact
    return {
        "model": "deterministic_spread_slippage_size_impact_v1",
        "fee_bps_per_side": float(cfg["fee_bps_per_side"]),
        "spread_bps_full_assumed": float(cfg["spread_bps_full"]),
        "half_spread_bps_per_side": half_spread,
        "base_slippage_bps_per_side": float(cfg["slippage_bps_per_side"]),
        "size_impact_bps_per_side": impact,
        "total_adverse_price_bps_per_side": adverse_bps,
        "notional_usdt": float(notional),
        "is_orderbook_measured": False,
    }

def fill_price(reference_price: float, side: str, action: str, costs: dict) -> float:
    price = float(reference_price)
    if not math.isfinite(price) or price <= 0:
        raise ValueError("reference price must be finite and positive")
    side = str(side).upper()
    action = str(action).lower()
    if side not in ("LONG", "SHORT") or action not in ("entry", "exit"):
        raise ValueError("invalid side or action")
    direction = 1 if side == "LONG" else -1
    adverse = float(costs["total_adverse_price_bps_per_side"]) / 10000.0
    if not math.isfinite(adverse) or adverse < 0 or adverse >= 0.25:
        raise ValueError("execution cost outside safe bounds")
    sign = direction if action == "entry" else -direction
    return price * (1.0 + sign * adverse)


def round_trip_cost_pct(notional: float, overrides: dict | None = None) -> float:
    """Return estimated round-trip fees plus adverse entry/exit price costs.

    The percentage is measured against entry notional. This is a deterministic
    assumption, not a measured order-book quote; use the same settings as the
    paper executor when comparing backtest and paper results.
    """
    costs = execution_costs(notional, overrides)
    total_bps = (2.0 * float(costs["fee_bps_per_side"])
                 + 2.0 * float(costs["total_adverse_price_bps_per_side"]))
    return total_bps / 100.0


def net_return_fraction(*, entry_reference: float, exit_reference: float,
                        side: str, notional: float, costs: dict) -> float:
    """Return realized PAPER net return as a fraction of entry notional.

    Uses the exact same adverse fill-price and two-sided fee calculations as
    paper_live. Funding is deliberately excluded and must be added separately
    for perpetual contracts.
    """
    entry_ref = float(entry_reference)
    exit_ref = float(exit_reference)
    amount = float(notional)
    if (not all(math.isfinite(v) for v in (entry_ref, exit_ref, amount))
            or entry_ref <= 0 or exit_ref <= 0 or amount <= 0):
        raise ValueError("entry, exit and notional must be finite positive numbers")
    normalized_side = str(side).upper()
    if normalized_side not in ("LONG", "SHORT"):
        raise ValueError("side must be LONG or SHORT")
    entry_fill = fill_price(entry_ref, normalized_side, "entry", costs)
    exit_fill = fill_price(exit_ref, normalized_side, "exit", costs)
    quantity = amount / entry_fill
    fee_rate = float(costs["fee_bps_per_side"]) / 10000.0
    if not math.isfinite(fee_rate) or fee_rate < 0:
        raise ValueError("fee rate is invalid")
    direction = 1.0 if normalized_side == "LONG" else -1.0
    gross = direction * quantity * (exit_fill - entry_fill)
    fees = amount * fee_rate + quantity * exit_fill * fee_rate
    return (gross - fees) / amount


def net_return_from_filled_entry_fraction(*, entry_fill: float, exit_reference: float,
                                          side: str, notional: float,
                                          costs: dict) -> float:
    """Return net PnL when ``entry_fill`` already includes entry-side slippage.

    This variant is for callers that have already simulated/recorded the entry
    fill. It applies the exit-side adverse fill and both fees, but deliberately
    does not apply entry slippage a second time.
    """
    entry = float(entry_fill)
    exit_ref = float(exit_reference)
    amount = float(notional)
    if (not all(math.isfinite(v) for v in (entry, exit_ref, amount))
            or entry <= 0 or exit_ref <= 0 or amount <= 0):
        raise ValueError("filled entry, exit and notional must be finite positive numbers")
    normalized_side = str(side).upper()
    if normalized_side not in ("LONG", "SHORT"):
        raise ValueError("side must be LONG or SHORT")
    exit_fill = fill_price(exit_ref, normalized_side, "exit", costs)
    fee_rate = float(costs["fee_bps_per_side"]) / 10000.0
    if not math.isfinite(fee_rate) or fee_rate < 0:
        raise ValueError("fee rate is invalid")
    quantity = amount / entry
    direction = 1.0 if normalized_side == "LONG" else -1.0
    gross = direction * quantity * (exit_fill - entry)
    fees = amount * fee_rate + quantity * exit_fill * fee_rate
    return (gross - fees) / amount


def funding_cashflow_for_bars(*, side: str, quantity: float,
                              funding_rates, mark_prices) -> float:
    """Sum settled perpetual funding cashflows over held bars.

    ``funding_rates`` must contain only realized settlement rates; NaN means no
    settlement in that bar. ``mark_prices`` must provide settlement mark prices
    for every non-null rate. Positive rates charge longs and credit shorts.
    This helper never estimates or forward-fills a missing funding rate.
    """
    import numpy as np

    q = float(quantity)
    if not math.isfinite(q) or q <= 0:
        raise ValueError("funding quantity must be finite and positive")
    rates = np.asarray(funding_rates, dtype=float)
    marks = np.asarray(mark_prices, dtype=float)
    if rates.ndim != 1 or marks.ndim != 1 or len(rates) != len(marks):
        raise ValueError("funding rates and mark prices must be equal-length vectors")
    normalized_side = str(side).upper()
    if normalized_side not in ("LONG", "SHORT"):
        raise ValueError("side must be LONG or SHORT")
    total = 0.0
    sign = -1.0 if normalized_side == "LONG" else 1.0
    for rate, mark in zip(rates, marks):
        if np.isnan(rate):
            continue
        if not math.isfinite(float(rate)) or abs(float(rate)) > 0.10:
            raise ValueError("realized funding rate is invalid")
        if not math.isfinite(float(mark)) or float(mark) <= 0:
            raise ValueError("settlement mark price is required for funding")
        total += q * float(mark) * float(rate) * sign
    return total
