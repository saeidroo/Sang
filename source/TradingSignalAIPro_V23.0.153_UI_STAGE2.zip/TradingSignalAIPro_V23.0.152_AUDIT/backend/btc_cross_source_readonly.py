"""Read-only Binance/OKX BTCUSDT 4h source failover and reconciliation."""
from __future__ import annotations
import json, math, time, urllib.parse, urllib.request
from datetime import datetime, timezone
from backend.btc_live_readonly import validate_btc_4h_candles, INTERVAL_MS

OKX_BASE='https://www.okx.com'
MAX_BYTES=2*1024*1024


def fetch_okx_btc_4h_readonly(*, limit=200, timeout=10.0, now_ms=None, max_age_hours=8):
    if isinstance(limit,bool) or not isinstance(limit,int) or not 2<=limit<=300:
        raise ValueError('okx_live_limit_out_of_range')
    query=urllib.parse.urlencode({'instId':'BTC-USDT','bar':'4H','limit':limit})
    request=urllib.request.Request(OKX_BASE+'/api/v5/market/candles?'+query,
        headers={'Accept':'application/json','User-Agent':'TradingSignalAIPro-ReadOnly/22.4'},method='GET')
    try:
        with urllib.request.urlopen(request,timeout=timeout) as response:
            raw=response.read(MAX_BYTES+1)
            if len(raw)>MAX_BYTES: raise ValueError('okx_live_response_too_large')
            if getattr(response,'status',200)!=200: raise ValueError(f'okx_live_http_status:{response.status}')
        payload=json.loads(raw.decode('utf-8'))
    except Exception as exc:
        if isinstance(exc,ValueError): raise
        raise RuntimeError(f'okx_readonly_request_failed:{type(exc).__name__}:{exc}') from exc
    if not isinstance(payload,dict) or payload.get('code')!='0' or not isinstance(payload.get('data'),list):
        raise ValueError('okx_live_payload_invalid')
    rows=[]
    for i,item in enumerate(reversed(payload['data'])):
        if not isinstance(item,list) or len(item)<9: raise ValueError(f'okx_live_candle_invalid:{i}')
        if str(item[8])!='1': continue
        t=int(item[0]); rows.append({'t':t,'open':float(item[1]),'high':float(item[2]),
            'low':float(item[3]),'close':float(item[4]),'volume':float(item[5]),
            'close_time':t+INTERVAL_MS-1})
    report=validate_btc_4h_candles(rows,now_ms=now_ms,max_age_hours=max_age_hours,
        require_closed=True,require_contiguous=True)
    report.update({'source':'OKX public market-data REST API','read_only':True,
        'endpoint_path':'/api/v5/market/candles','fetched_at_utc':datetime.now(timezone.utc).isoformat()})
    return report


def reconcile_btc_4h_sources(primary: dict, backup: dict, *, price_rel_tolerance=0.001,
                             volume_rel_tolerance=0.05):
    if not isinstance(primary,dict) or not isinstance(backup,dict):
        raise ValueError('cross_source_reports_invalid')
    if primary.get('status')!='PASS' or backup.get('status')!='PASS':
        return {'status':'DEGRADED','reason':'one_or_more_sources_not_pass',
                'training_allowed':False,'live_orders':False}
    p={int(r['t']):r for r in primary.get('candles',[])}
    b={int(r['t']):r for r in backup.get('candles',[])}
    if not p or not b: return {'status':'BLOCKED','reason':'cross_source_candles_missing','training_allowed':False,'live_orders':False}
    if set(p)!=set(b):
        return {'status':'BLOCKED','reason':'cross_source_timestamp_coverage_mismatch',
            'primary_only':sorted(set(p)-set(b)),'backup_only':sorted(set(b)-set(p)),
            'training_allowed':False,'live_orders':False}
    differences=[]
    for ts in sorted(p):
        fields={}
        for field in ('open','high','low','close','volume'):
            x=float(p[ts][field]); y=float(b[ts][field])
            if not math.isfinite(x) or not math.isfinite(y):
                return {'status':'BLOCKED','reason':'cross_source_non_finite_value','timestamp':ts,
                        'training_allowed':False,'live_orders':False}
            tolerance=volume_rel_tolerance if field=='volume' else price_rel_tolerance
            allowed=max(abs(x),abs(y))*tolerance
            if abs(x-y)>allowed:
                fields[field]={'primary':x,'backup':y,'absolute_delta':abs(x-y),'allowed_delta':allowed}
        if fields: differences.append({'t':ts,'fields':fields})
    return {'status':'BLOCKED' if differences else 'PASS','compared_candles':len(p),
        'difference_count':len(differences),'differences':differences,
        'primary_sha256':primary.get('candles_sha256'),'backup_sha256':backup.get('candles_sha256'),
        'policy':{'price_rel_tolerance':price_rel_tolerance,'volume_rel_tolerance':volume_rel_tolerance},
        'training_allowed':not differences,'live_orders':False}


def select_readonly_failover(primary: dict|None, backup: dict|None, *, price_rel_tolerance=0.001,
                             volume_rel_tolerance=0.05):
    p_ok=isinstance(primary,dict) and primary.get('status')=='PASS'
    b_ok=isinstance(backup,dict) and backup.get('status')=='PASS'
    if p_ok and b_ok:
        reconciliation=reconcile_btc_4h_sources(primary,backup,
            price_rel_tolerance=price_rel_tolerance,volume_rel_tolerance=volume_rel_tolerance)
        return {'status':reconciliation['status'],'selected_source':'Binance' if reconciliation['status']=='PASS' else None,
            'fallback_used':False,'reconciliation':reconciliation,
            'training_allowed':False,'live_orders':False}
    if p_ok or b_ok:
        selected='Binance' if p_ok else 'OKX'
        return {'status':'DEGRADED','selected_source':selected,'fallback_used':not p_ok,
            'reason':'cross_source_validation_unavailable','reconciliation':None,
            'training_allowed':False,'live_orders':False}
    return {'status':'BLOCKED','selected_source':None,'fallback_used':False,
        'reason':'all_readonly_sources_failed','reconciliation':None,
        'training_allowed':False,'live_orders':False}


def fetch_cross_source_btc_4h_readonly(*, limit=200, timeout=10.0, max_age_hours=8):
    from backend.btc_live_readonly import fetch_binance_btc_4h_readonly
    primary=backup=None; errors={}
    try: primary=fetch_binance_btc_4h_readonly(limit=limit,timeout=timeout,max_age_hours=max_age_hours)
    except Exception as exc: errors['Binance']=f'{type(exc).__name__}:{exc}'
    try: backup=fetch_okx_btc_4h_readonly(limit=min(limit,300),timeout=timeout,max_age_hours=max_age_hours)
    except Exception as exc: errors['OKX']=f'{type(exc).__name__}:{exc}'
    result=select_readonly_failover(primary,backup)
    def observation(report):
        if not isinstance(report,dict) or report.get('status')!='PASS':
            return {'status':'UNAVAILABLE'}
        return {'status':'PASS','row_count':report.get('row_count'),
            'latest_age_hours':report.get('latest_age_hours'),
            'candles_sha256':report.get('candles_sha256')}
    result.update({'primary_source':'Binance','backup_source':'OKX','errors':errors,
        'source_observations':{'Binance':observation(primary),'OKX':observation(backup)},
        'read_only':True,'training_allowed':False,'live_orders':False})
    return result
