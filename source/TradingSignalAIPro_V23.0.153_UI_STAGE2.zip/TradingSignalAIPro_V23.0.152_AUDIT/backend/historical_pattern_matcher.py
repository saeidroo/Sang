"""Read-only comparison of the latest closed-candle context with mined history."""
from __future__ import annotations
import sqlite3
from pathlib import Path
from collections import defaultdict
from backend.historical_event_miner import DEFAULT_DB, SUPPORTED, _pre_move_features, mine_rows


def _signature(f):
    return '|'.join([f['momentum_4_band'], f['momentum_12_band'], f['volume_band'],
                     f['volatility_band'], f['pressure'], f['trend']])


def match_current_to_history(symbol=None, timeframe='1h', threshold_pct=10.0,
                              horizon_bars=24, lookback=24, db_path=None,
                              max_candles=250000, min_samples=5):
    if timeframe not in SUPPORTED:
        raise ValueError('تایم‌فریم پشتیبانی نمی‌شود')
    if not 1 <= int(min_samples) <= 1000:
        raise ValueError('حداقل نمونه باید بین ۱ تا ۱۰۰۰ باشد')
    path = Path(db_path or DEFAULT_DB).expanduser()
    if not path.exists():
        return {'status':'no_history_archive','matches':[], 'archive_path':str(path)}
    uri=f'file:{path.resolve().as_posix()}?mode=ro'
    con=sqlite3.connect(uri, uri=True, timeout=10)
    try:
        q='SELECT symbol,timeframe,t,open,high,low,close,volume FROM candles WHERE timeframe=?'
        args=[timeframe]
        if symbol:
            q+=' AND UPPER(symbol)=?'; args.append(str(symbol).upper())
        q+=' ORDER BY symbol,t LIMIT ?'; args.append(int(max_candles))
        records=con.execute(q,args).fetchall()
    finally:
        con.close()
    grouped=defaultdict(list)
    for sym,tf,t,o,h,l,c,v in records:
        grouped[str(sym).upper()].append((t,o,h,l,c,v))
    matches=[]
    for sym, rows in grouped.items():
        if len(rows) < lookback + horizon_bars + 1:
            continue
        # The newest candle is treated as the latest available closed candle.
        clean=sorted(rows, key=lambda x:int(x[0]))
        current=_pre_move_features(clean, len(clean), lookback)
        if not current:
            continue
        signature=_signature(current)
        mined=mine_rows(clean, sym, timeframe, threshold_pct, horizon_bars, lookback, max_events=10000)
        pattern=next((p for p in mined['patterns'] if p['signature']==signature), None)
        pump=int(pattern['pump']) if pattern else 0
        dump=int(pattern['dump']) if pattern else 0
        samples=pump+dump
        if samples < int(min_samples):
            bias='insufficient_samples'; reliability='low'
        else:
            pump_share=100*pump/samples; dump_share=100*dump/samples
            if pump_share >= 65: bias='pump_favored'
            elif dump_share >= 65: bias='dump_favored'
            else: bias='mixed'
            reliability='high' if samples>=30 else 'moderate'
        matches.append({'symbol':sym,'timeframe':timeframe,'signature':signature,
                        'current_conditions':current,'historical_samples':samples,
                        'historical_pump_events':pump,'historical_dump_events':dump,
                        'pump_share_pct':round(100*pump/samples,1) if samples else None,
                        'dump_share_pct':round(100*dump/samples,1) if samples else None,
                        'historical_bias':bias,'evidence_reliability':reliability,
                        'min_samples_required':int(min_samples),
                        'is_forecast':False,
                        'warning':'شباهت تاریخی تضمین‌کننده حرکت آینده نیست؛ این خروجی به‌تنهایی سیگنال معامله نیست.'})
    return {'status':'completed' if matches else 'no_matching_candles',
            'archive_path':str(path),'candles_scanned':len(records),
            'matches':matches}
