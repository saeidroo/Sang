"""Durable remote Witness replication scheduler and health/lag monitor (V22.2r)."""
from __future__ import annotations
import json, sqlite3, time
from datetime import datetime, timezone
from pathlib import Path
from backend.witness_ops import _records
from backend.witness_remote import sync_replication_http, _request, _validate_endpoint
from backend.witness_alerting import notify_if_needed


def _now(): return datetime.now(timezone.utc).isoformat()


def init_scheduler_db(path):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(p) as db:
        db.execute('''CREATE TABLE IF NOT EXISTS replication_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, started_at TEXT NOT NULL, finished_at TEXT NOT NULL,
            status TEXT NOT NULL, source_sequence INTEGER NOT NULL, replica_sequence INTEGER,
            lag INTEGER, chunks INTEGER NOT NULL DEFAULT 0, appended INTEGER NOT NULL DEFAULT 0,
            duration_seconds REAL NOT NULL, error TEXT, alert TEXT)''')
        db.execute('CREATE INDEX IF NOT EXISTS idx_replication_runs_started ON replication_runs(started_at)')


def scheduler_status(state_db, *, max_lag=0, stale_after_seconds=900):
    init_scheduler_db(state_db)
    with sqlite3.connect(state_db) as db:
        row=db.execute('SELECT id,started_at,finished_at,status,source_sequence,replica_sequence,lag,chunks,appended,duration_seconds,error,alert FROM replication_runs ORDER BY id DESC LIMIT 1').fetchone()
    if not row:
        return {'status':'never_run','healthy':False,'alert':'replication_never_run','last_run':None}
    keys=('id','started_at','finished_at','run_status','source_sequence','replica_sequence','lag','chunks','appended','duration_seconds','error','alert')
    last=dict(zip(keys,row))
    age=max(0,(datetime.now(timezone.utc)-datetime.fromisoformat(last['finished_at'])).total_seconds())
    alerts=[]
    if last['run_status']!='success': alerts.append('last_replication_failed')
    if last['lag'] is None: alerts.append('replica_status_unavailable')
    elif last['lag']>max_lag: alerts.append('replication_lag_exceeded')
    if age>stale_after_seconds: alerts.append('replication_status_stale')
    return {'status':'healthy' if not alerts else 'degraded','healthy':not alerts,'age_seconds':round(age,2),
            'alerts':alerts,'last_run':last,'max_lag':max_lag,'stale_after_seconds':stale_after_seconds}


def run_sync_once(source_db, source_public_key, endpoint, token, state_db, *, timeout=15, chunk_size=500,
                  max_lag=0, ssl_context=None, webhook_url=None, webhook_token=None):
    init_scheduler_db(state_db); started=_now(); tick=time.monotonic(); result=None; error=None
    source_sequence=len(_records(source_db)); replica_sequence=None; lag=None; chunks=0; appended=0
    try:
        result=sync_replication_http(source_db,source_public_key,endpoint,token,timeout=timeout,
                                     chunk_size=chunk_size,ssl_context=ssl_context)
        chunks=int(result.get('chunks',0)); appended=int(result.get('appended',0))
        status=_request(endpoint.rstrip('/')+'/v1/replication/status','GET',token,timeout=timeout,context=ssl_context)
        replica_sequence=int(status['sequence']); lag=max(0,source_sequence-replica_sequence)
        run_status='success'
    except Exception as exc:
        error=f'{type(exc).__name__}: {exc}'[:1000]; run_status='failed'
        try:
            _validate_endpoint(endpoint)
            status=_request(endpoint.rstrip('/')+'/v1/replication/status','GET',token,timeout=timeout,context=ssl_context)
            replica_sequence=int(status['sequence']); lag=max(0,source_sequence-replica_sequence)
        except Exception: pass
    duration=round(time.monotonic()-tick,3); finished=_now()
    alerts=[]
    if run_status!='success': alerts.append('replication_failed')
    if lag is None: alerts.append('replica_status_unavailable')
    elif lag>max_lag: alerts.append('replication_lag_exceeded')
    with sqlite3.connect(state_db) as db:
        db.execute('''INSERT INTO replication_runs(started_at,finished_at,status,source_sequence,replica_sequence,lag,chunks,appended,duration_seconds,error,alert)
                      VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
                   (started,finished,run_status,source_sequence,replica_sequence,lag,chunks,appended,duration,error,','.join(alerts) or None))
    outcome={'status':run_status,'source_sequence':source_sequence,'replica_sequence':replica_sequence,'lag':lag,
            'chunks':chunks,'appended':appended,'duration_seconds':duration,'error':error,'alerts':alerts,'result':result}
    outcome['webhook']=notify_if_needed(outcome,webhook_url,webhook_token=webhook_token)
    return outcome


def run_scheduler(source_db, source_public_key, endpoint, token, state_db, *, interval_seconds=300,
                  max_lag=0, chunk_size=500, timeout=15, ssl_context=None, stop_event=None, max_runs=None, webhook_url=None, webhook_token=None):
    if interval_seconds<10: raise ValueError('scheduler_interval_must_be_at_least_10_seconds')
    runs=0; history=[]
    while max_runs is None or runs<max_runs:
        history.append(run_sync_once(source_db,source_public_key,endpoint,token,state_db,timeout=timeout,
                                     chunk_size=chunk_size,max_lag=max_lag,ssl_context=ssl_context,webhook_url=webhook_url,webhook_token=webhook_token))
        runs+=1
        if max_runs is not None and runs>=max_runs: break
        if stop_event is not None:
            if stop_event.wait(interval_seconds): break
        else: time.sleep(interval_seconds)
    return history
