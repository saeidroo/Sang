"""Trading Signal AI Pro backend package."""
from .env import load_dotenv  # noqa: F401  (loads project .env at import time)
