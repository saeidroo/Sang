"""V22.6 read-only new-listing discovery and cold-start triage.

Only public spot-market metadata/tickers are used. A listing timestamp is never
invented: unknown timestamps remain unknown and cannot be called newly listed.
"""
from __future__ import annotations
import os, time
from datetime import datetime, timezone
from typing import Callable
import requests

TIMEOUT = (3, 7)
SESSION = requests.Session()
SESSION.headers.update({'User-Agent': 'TradingSignalAIPro/22.6', 'Accept': 'application/json'})


def _json(url: str, params=None):
    r = SESSION.get(url, params=params, timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()


def _utc_ms(value):
    try:
        n = int(float(value))
        if n < 10_000_000_000: n *= 1000
        return n if n > 0 else None
    except (TypeError, ValueError, OverflowError):
        return None


def _triage(row: dict, now_ms: int, max_age_days: int) -> dict:
    listed = _utc_ms(row.get('listed_at_ms'))
    age_days = max(0.0, (now_ms-listed)/86_400_000) if listed else None
    quote_vol = float(row.get('quote_volume') or 0)
    trades_raw = row.get('trades')
    trades = int(trades_raw) if trades_raw is not None else None
    price = float(row.get('price') or 0)
    change = float(row.get('change_pct') or 0)
    age_known = age_days is not None
    recent = bool(age_known and age_days <= max_age_days)
    # Data sufficiency is explicit; price action alone cannot create an entry signal.
    data_points = sum([price > 0, quote_vol > 0, trades is not None and trades > 0, age_known])
    if not age_known:
        status, advice = 'age_unknown', 'زمان فهرست‌شدن تأیید نشده؛ فقط پایش، بدون توصیه ورود.'
    elif not recent:
        status, advice = 'not_new', 'از بازه ارزهای تازه‌وارد خارج است.'
    elif quote_vol < 100_000 or (trades is not None and trades < 100) or price <= 0:
        status, advice = 'thin_market', 'نقدشوندگی/تعداد معاملات ناکافی؛ فعلاً ورود نکن.'
    else:
        status, advice = 'cold_start_watch', 'داده اولیه قابل بررسی است؛ منتظر شکل‌گیری ساختار و کندل‌های کافی بمان.'
    # Conservative risk grade; not a probability or return forecast.
    risk = 'very_high' if not age_known or age_days is not None and age_days < 2 else 'high'
    if quote_vol < 100_000 or (trades is not None and trades < 100): risk = 'very_high'
    return {**row, 'age_days': round(age_days, 2) if age_days is not None else None,
            'is_new': recent, 'data_points': data_points, 'status': status,
            'risk': risk, 'advice': advice, 'cold_start': True,
            'entry_ready': False, 'score': round(min(40, data_points*8 + (8 if quote_vol >= 1_000_000 else 0)), 1),
            'change_pct': round(change, 3), 'quote_volume': round(quote_vol, 2)}


def discover_new_listings(max_age_days: int = 30, limit: int = 30,
                          fetch_json: Callable = _json, now_ms: int | None = None) -> dict:
    """Discover recent USDT spot listings from Binance, MEXC and Bybit.

    Exchange responses differ; unsupported/missing listing timestamps are kept
    as unknown. Partial source failures do not fabricate a result.
    """
    max_age_days = max(1, min(int(max_age_days), 90)); limit = max(1, min(int(limit), 100))
    now_ms = int(now_ms or time.time()*1000)
    sources, rows = [], []
    # Binance Spot: onboardDate is present on supported exchangeInfo responses.
    try:
        info = fetch_json('https://api.binance.com/api/v3/exchangeInfo')
        tickers = fetch_json('https://api.binance.com/api/v3/ticker/24hr')
        by_symbol = {x.get('symbol'): x for x in tickers if isinstance(x, dict)}
        count = 0
        for s in info.get('symbols', []):
            if s.get('status') != 'TRADING' or s.get('quoteAsset') != 'USDT' or s.get('isSpotTradingAllowed') is False: continue
            t = by_symbol.get(s.get('symbol'), {})
            rows.append({'symbol': s.get('symbol'), 'base': s.get('baseAsset'), 'quote': 'USDT', 'exchange': 'Binance',
                         'listed_at_ms': s.get('onboardDate'), 'price': t.get('lastPrice'),
                         'quote_volume': t.get('quoteVolume'), 'trades': t.get('count'),
                         'change_pct': t.get('priceChangePercent')})
            count += 1
        sources.append({'id':'binance','ok':True,'symbols':count})
    except Exception as e: sources.append({'id':'binance','ok':False,'error':str(e)[:120]})
    # MEXC exchangeInfo does not consistently expose a reliable listing timestamp.
    try:
        info = fetch_json('https://api.mexc.com/api/v3/exchangeInfo')
        tickers = fetch_json('https://api.mexc.com/api/v3/ticker/24hr')
        by_symbol = {x.get('symbol'): x for x in tickers if isinstance(x, dict)}
        count = 0
        for s in info.get('symbols', []):
            if s.get('status') not in ('1', 1, 'TRADING') or s.get('quoteAsset') != 'USDT': continue
            t = by_symbol.get(s.get('symbol'), {})
            rows.append({'symbol': s.get('symbol'), 'base': s.get('baseAsset'), 'quote': 'USDT', 'exchange': 'MEXC',
                         'listed_at_ms': s.get('onboardDate') or s.get('launchTime'), 'price': t.get('lastPrice'),
                         'quote_volume': t.get('quoteVolume'), 'trades': t.get('count'),
                         'change_pct': t.get('priceChangePercent')})
            count += 1
        sources.append({'id':'mexc','ok':True,'symbols':count})
    except Exception as e: sources.append({'id':'mexc','ok':False,'error':str(e)[:120]})
    # Bybit launchTime is explicit in instruments-info; ticker turnover is quote turnover.
    try:
        info = fetch_json('https://api.bybit.com/v5/market/instruments-info', {'category':'spot','limit':1000})
        tick = fetch_json('https://api.bybit.com/v5/market/tickers', {'category':'spot'})
        by_symbol = {x.get('symbol'): x for x in (tick.get('result') or {}).get('list', [])}
        items = (info.get('result') or {}).get('list', [])
        count = 0
        for s in items:
            if s.get('quoteCoin') != 'USDT' or s.get('status') != 'Trading': continue
            t = by_symbol.get(s.get('symbol'), {})
            rows.append({'symbol': s.get('symbol'), 'base': s.get('baseCoin'), 'quote': 'USDT', 'exchange': 'Bybit',
                         'listed_at_ms': s.get('launchTime'), 'price': t.get('lastPrice'),
                         'quote_volume': t.get('turnover24h'), 'trades': None,
                         'change_pct': (float(t.get('price24hPcnt') or 0)*100)})
            count += 1
        sources.append({'id':'bybit','ok':True,'symbols':count})
    except Exception as e: sources.append({'id':'bybit','ok':False,'error':str(e)[:120]})
    seen, out = set(), []
    for r in rows:
        sym = str(r.get('symbol') or '')
        if not sym or sym in seen: continue
        seen.add(sym)
        try: item = _triage(r, now_ms, max_age_days)
        except (TypeError, ValueError): continue
        if item['is_new'] or item['status'] == 'age_unknown': out.append(item)
    out.sort(key=lambda x: (x['age_days'] is None, x['age_days'] if x['age_days'] is not None else 9999,
                            -x['quote_volume']))
    return {'generated_at': now_ms//1000, 'window_days': max_age_days, 'sources': sources,
            'source_ok_count': sum(1 for x in sources if x['ok']), 'count': min(len(out), limit),
            'items': out[:limit], 'disclaimer': 'کشف و غربالگری read-only است؛ امتیاز، احتمال سود نیست. ارز تازه‌لیست‌شده پرریسک است و هیچ سیگنال ورود خودکار صادر نمی‌شود.'}
