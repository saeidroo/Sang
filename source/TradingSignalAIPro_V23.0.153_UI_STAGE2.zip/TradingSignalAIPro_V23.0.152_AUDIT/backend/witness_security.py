"""Security primitives for the standalone Witness HTTP service (V22.2u)."""
from __future__ import annotations
import threading, time
from dataclasses import dataclass


@dataclass
class _Bucket:
    started: float
    count: int


class FixedWindowRateLimiter:
    """Small process-local limiter. Use a gateway/shared limiter for multi-worker deployments."""
    def __init__(self, limit: int = 120, window_seconds: int = 60, *, clock=None):
        if not isinstance(limit, int) or limit < 1 or not isinstance(window_seconds, int) or window_seconds < 1:
            raise ValueError('rate_limit_configuration_invalid')
        self.limit, self.window_seconds = limit, window_seconds
        self.clock = clock or time.monotonic
        self._buckets: dict[str, _Bucket] = {}
        self._lock = threading.Lock()

    def allow(self, identity: str) -> bool:
        now = self.clock()
        with self._lock:
            bucket = self._buckets.get(identity)
            if bucket is None or now - bucket.started >= self.window_seconds:
                self._buckets[identity] = _Bucket(now, 1)
                return True
            if bucket.count >= self.limit:
                return False
            bucket.count += 1
            return True

    def prune(self) -> int:
        now = self.clock()
        with self._lock:
            expired = [k for k, v in self._buckets.items() if now - v.started >= self.window_seconds]
            for key in expired:
                del self._buckets[key]
            return len(expired)


def validate_json_shape(value, *, max_depth=12, max_nodes=20000, max_string=65536):
    """Reject deeply nested or pathological JSON before domain processing."""
    nodes = 0
    stack = [(value, 0)]
    while stack:
        item, depth = stack.pop()
        nodes += 1
        if nodes > max_nodes:
            raise ValueError('json_complexity_limit_exceeded')
        if depth > max_depth:
            raise ValueError('json_nesting_limit_exceeded')
        if isinstance(item, str) and len(item) > max_string:
            raise ValueError('json_string_limit_exceeded')
        if isinstance(item, dict):
            for key, child in item.items():
                if not isinstance(key, str) or len(key) > 256:
                    raise ValueError('json_key_invalid_or_too_long')
                stack.append((child, depth + 1))
        elif isinstance(item, list):
            stack.extend((child, depth + 1) for child in item)
        elif item is not None and not isinstance(item, (str, int, float, bool)):
            raise ValueError('json_value_type_invalid')
    return True
