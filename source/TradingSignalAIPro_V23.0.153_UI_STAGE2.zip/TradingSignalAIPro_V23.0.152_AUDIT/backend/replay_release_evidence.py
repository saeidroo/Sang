"""Build and verify a reproducible evidence bundle for BTC 4h replay releases."""
from __future__ import annotations
import hashlib, json, os, platform, re, sys, zipfile
from datetime import datetime, timezone
from pathlib import Path

SCHEMA='btc-4h-replay-release-evidence-v1'
EXCLUDED_DIRS={'.git','.venv','venv','__pycache__','.pytest_cache','node_modules','dist','build'}
SECRET_NAME=re.compile(r'(^|[/\\])\.env($|\.)|private|secret|token|password|credential',re.I)


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()


def _sha(raw): return hashlib.sha256(raw).hexdigest()


def _safe_inventory(root: Path):
    rows=[]
    for path in sorted(root.rglob('*')):
        if not path.is_file(): continue
        rel=path.relative_to(root)
        if any(part in EXCLUDED_DIRS for part in rel.parts): continue
        name=rel.as_posix()
        if SECRET_NAME.search(name) or name.lower().endswith(('.pem','.key','.p12','.pfx')): continue
        if path.stat().st_size > 20*1024*1024: continue
        raw=path.read_bytes()
        rows.append({'path':name,'size_bytes':len(raw),'sha256':_sha(raw)})
    return rows


def build_replay_release_evidence_pack(*, project_root, output_path, test_summary: dict,
                                       gate_report: dict, release_version: str):
    root=Path(project_root).expanduser().resolve(); out=Path(output_path).expanduser()
    if not root.is_dir(): raise FileNotFoundError('release_evidence_project_root_missing')
    if not isinstance(test_summary,dict) or int(test_summary.get('failed',-1)) != 0 or int(test_summary.get('passed',0)) < 1:
        raise ValueError('release_evidence_tests_not_passing')
    if not isinstance(gate_report,dict) or gate_report.get('status') not in ('READY','BLOCKED'):
        raise ValueError('release_evidence_gate_report_invalid')
    inventory=_safe_inventory(root)
    environment={'python':sys.version.split()[0],'platform':platform.platform(),
                 'implementation':platform.python_implementation()}
    payload={'schema_version':SCHEMA,'release_version':str(release_version),
             'created_at_utc':datetime.now(timezone.utc).isoformat(),
             'environment':environment,'test_summary':test_summary,
             'release_gate':gate_report,'source_inventory':inventory,
             'source_inventory_sha256':_sha(_canonical(inventory))}
    manifest={**payload,'manifest_sha256':_sha(_canonical(payload))}
    readme=(f"# Release Evidence {release_version}\n\n"
            f"- Tests: {test_summary.get('passed')} passed, {test_summary.get('failed')} failed, {test_summary.get('skipped',0)} skipped.\n"
            f"- Integrity/operations gate: {gate_report.get('status')}.\n"
            "- Source inventory contains SHA-256 digests; private keys, .env files and secret-named files are excluded.\n"
            "- This pack does not certify predictive accuracy or live-trading readiness.\n")
    out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists(): raise FileExistsError('release_evidence_destination_exists')
    temp=out.with_name(out.name+'.tmp')
    try:
        with zipfile.ZipFile(temp,'x',compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('manifest.json',_canonical(manifest)+b'\n')
            archive.writestr('README.md',readme)
            archive.writestr('SHA256SUMS.txt',f"manifest.json  {_sha(_canonical(manifest)+b'\\n')}\n")
        fd=os.open(str(temp),os.O_RDONLY)
        try: os.fsync(fd)
        finally: os.close(fd)
        os.link(temp,out)
    finally:
        try: temp.unlink()
        except FileNotFoundError: pass
    return {'created':True,'path':str(out),'manifest_sha256':manifest['manifest_sha256'],
            'source_file_count':len(inventory),'test_summary':test_summary,
            'release_gate_status':gate_report['status'],'bytes':out.stat().st_size}


def verify_replay_release_evidence_pack(path):
    with zipfile.ZipFile(path,'r') as archive:
        names=archive.namelist()
        if set(names)!={'manifest.json','README.md','SHA256SUMS.txt'}:
            raise ValueError('release_evidence_file_set_invalid')
        manifest=json.loads(archive.read('manifest.json'))
        body=dict(manifest); declared=body.pop('manifest_sha256',None)
        if not declared or _sha(_canonical(body))!=declared:
            raise ValueError('release_evidence_manifest_hash_mismatch')
        inventory=manifest.get('source_inventory')
        if not isinstance(inventory,list) or _sha(_canonical(inventory))!=manifest.get('source_inventory_sha256'):
            raise ValueError('release_evidence_inventory_hash_mismatch')
        for item in inventory:
            name=item.get('path','')
            if Path(name).is_absolute() or '..' in Path(name).parts or SECRET_NAME.search(name) or name.lower().endswith(('.pem','.key','.p12','.pfx')):
                raise ValueError('release_evidence_inventory_path_unsafe')
        if int(manifest.get('test_summary',{}).get('failed',-1))!=0:
            raise ValueError('release_evidence_test_gate_failed')
        return {'valid':True,'release_version':manifest.get('release_version'),
                'manifest_sha256':declared,'source_file_count':len(inventory),
                'release_gate_status':manifest.get('release_gate',{}).get('status')}
