"""V23.0.66 conservative paper-only capital allocation planner.
Pure calculations only: it never creates, submits, or modifies orders.
"""
from __future__ import annotations
import math
from collections import defaultdict

DEFAULTS = {
    'initial_capital': 1000.0, 'risk_per_trade_pct': 0.5,
    'max_total_open_risk_pct': 2.0, 'max_position_notional_pct': 20.0,
    'reserve_pct': 20.0, 'max_positions': 5, 'max_group_exposure_pct': 30.0,
    'min_score': 60.0, 'fee_bps_per_side': 10.0, 'slippage_bps_per_side': 5.0,
}

def _num(value, name, minimum=0.0):
    try: n = float(value)
    except (TypeError, ValueError, OverflowError): raise ValueError(f'{name} نامعتبر است')
    if not math.isfinite(n) or n < minimum: raise ValueError(f'{name} نامعتبر است')
    return n

def plan_paper_allocations(candidates, *, equity=1000.0, available_balance=None,
                           open_risk=0.0, open_positions=0, group_exposure=None,
                           settings=None):
    cfg = dict(DEFAULTS); cfg.update(settings or {})
    equity = _num(equity, 'equity', 0.01)
    available = _num(equity if available_balance is None else available_balance, 'available_balance')
    open_risk = _num(open_risk, 'open_risk')
    open_positions = int(open_positions)
    if open_positions < 0: raise ValueError('open_positions نامعتبر است')
    if not isinstance(candidates, list): raise ValueError('candidates باید فهرست باشد')
    groups = defaultdict(float)
    for key, value in (group_exposure or {}).items(): groups[str(key)] = _num(value, 'group_exposure')
    reserve = equity * _num(cfg['reserve_pct'], 'reserve_pct') / 100
    usable = max(0.0, available - reserve)
    total_risk_cap = equity * _num(cfg['max_total_open_risk_pct'], 'max_total_open_risk_pct') / 100
    risk_left = max(0.0, total_risk_cap - open_risk)
    risk_each = equity * _num(cfg['risk_per_trade_pct'], 'risk_per_trade_pct') / 100
    notional_cap = equity * _num(cfg['max_position_notional_pct'], 'max_position_notional_pct') / 100
    group_cap = equity * _num(cfg['max_group_exposure_pct'], 'max_group_exposure_pct') / 100
    max_positions = int(cfg['max_positions']); min_score = _num(cfg['min_score'], 'min_score')
    fee = _num(cfg['fee_bps_per_side'], 'fee_bps_per_side')
    slip = _num(cfg['slippage_bps_per_side'], 'slippage_bps_per_side')
    ranked = sorted(enumerate(candidates), key=lambda x: _num(x[1].get('score', 0), 'score'), reverse=True)
    results = []
    for index, raw in ranked:
        row = dict(raw); symbol = str(row.get('symbol') or '').upper().strip()
        group = str(row.get('correlation_group') or symbol or 'UNGROUPED')
        try:
            score = _num(row.get('score'), 'score')
            stop_pct = _num(row.get('stop_loss_pct'), 'stop_loss_pct', 0.000001)
            if not symbol: raise ValueError('symbol نامعتبر است')
            if score < min_score: raise ValueError('امتیاز کمتر از حداقل مجاز')
            if row.get('blocked') or row.get('data_reliable') is False: raise ValueError('فرصت مسدود یا داده نامعتبر است')
            if open_positions >= max_positions: raise ValueError('سقف تعداد موقعیت باز پر شده است')
            if risk_left <= 0 or usable <= 0: raise ValueError('بودجه ریسک یا موجودی قابل استفاده تمام شده است')
            group_room = max(0.0, group_cap - groups[group])
            if group_room <= 0: raise ValueError('سقف مواجهه گروه همبسته پر شده است')
            friction = 2 * (fee + slip) / 10000
            risk_fraction = stop_pct / 100 + friction
            notional = min(risk_each / risk_fraction, notional_cap, usable, group_room, risk_left / risk_fraction)
            if notional <= 0: raise ValueError('اندازه موقعیت قابل تخصیص نیست')
            risk_cash = notional * risk_fraction
            usable -= notional; risk_left -= risk_cash; groups[group] += notional; open_positions += 1
            results.append({'symbol': symbol, 'score': score, 'status': 'PAPER_ALLOCATION_PLANNED',
                            'notional_usdt': round(notional, 8), 'estimated_stop_risk_usdt': round(risk_cash, 8),
                            'correlation_group': group, 'stop_loss_pct': stop_pct})
        except (ValueError, TypeError) as exc:
            results.append({'symbol': symbol or 'UNKNOWN', 'status': 'NOT_ALLOCATED', 'reason': str(exc)})
    allocated = sum(x.get('notional_usdt', 0) for x in results)
    risk = sum(x.get('estimated_stop_risk_usdt', 0) for x in results)
    return {'version': '23.0.66', 'initial_capital_usdt': 1000.0,
            'equity_input_usdt': round(equity, 8), 'allocated_notional_usdt': round(allocated, 8),
            'planned_stop_risk_usdt': round(risk, 8), 'remaining_available_usdt': round(usable, 8),
            'reserved_cash_usdt': round(reserve, 8), 'open_risk_before_usdt': round(open_risk, 8),
            'max_total_open_risk_usdt': round(total_risk_cap, 8), 'allocations': results,
            'paper_only': True, 'read_only_plan': True, 'creates_orders': False,
            'real_orders_enabled': False, 'execution_authorized': False}
