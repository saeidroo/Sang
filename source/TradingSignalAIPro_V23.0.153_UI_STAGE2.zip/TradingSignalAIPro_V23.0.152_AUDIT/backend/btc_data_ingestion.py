"""V22.3j: paginated BTCUSDT 4h ingestion with a fail-closed quality gate.

The default public source is Binance spot REST klines. Network access is only
performed when explicitly requested; tests inject a page fetcher and never use
live market data. No candles are silently sorted, filled, or repaired.
"""
from __future__ import annotations

import hashlib
import json
import math
import time
from datetime import datetime, timezone
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import pandas as pd

from backend.btc_walkforward import FOUR_HOURS_MS, validate_btc_4h

VERSION = "btc-4h-ingestion-v1"
DEFAULT_BASE_URL = "https://api.binance.com"
DEFAULT_SYMBOL = "BTCUSDT"
DEFAULT_INTERVAL = "4h"
MAX_PAGE_LIMIT = 1000


def _default_fetch_page(params, *, base_url=DEFAULT_BASE_URL, timeout=15):
    url = base_url.rstrip("/") + "/api/v3/klines?" + urlencode(params)
    req = Request(url, headers={"User-Agent": "TradingSignalAIPro/22.3.10", "Accept": "application/json"})
    with urlopen(req, timeout=float(timeout)) as response:
        if int(getattr(response, "status", 200)) != 200:
            raise RuntimeError(f"market_data_http_status:{response.status}")
        payload = json.loads(response.read().decode("utf-8"))
    if not isinstance(payload, list):
        raise ValueError("market_data_response_not_list")
    return payload


def _parse_klines(rows):
    parsed = []
    for row in rows:
        if not isinstance(row, (list, tuple)) or len(row) < 6:
            raise ValueError("malformed_kline_row")
        try:
            parsed.append({
                "t": int(row[0]), "open": float(row[1]), "high": float(row[2]),
                "low": float(row[3]), "close": float(row[4]), "volume": float(row[5]),
                "close_time": int(row[6]) if len(row) > 6 else None,
            })
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError("non_numeric_kline_field") from exc
    return parsed


def fetch_btc_4h_history(*, start_time_ms, end_time_ms=None, now_ms=None,
                         symbol=DEFAULT_SYMBOL, page_limit=1000, max_pages=100,
                         fetch_page=None, base_url=DEFAULT_BASE_URL, timeout=15,
                         max_gap_bars=0, max_staleness_bars=0):
    """Fetch closed BTCUSDT 4h candles using startTime pagination.

    `start_time_ms` and `end_time_ms` are candle-open-time boundaries. The
    end is inclusive. An injected `fetch_page(params)` can be used in tests.
    The latest fully closed candle must be present within the staleness policy.
    """
    start = int(start_time_ms)
    end = int(end_time_ms) if end_time_ms is not None else None
    now = int(now_ms if now_ms is not None else time.time() * 1000)
    limit = int(page_limit)
    pages_cap = int(max_pages)
    if start < 0 or (end is not None and end < start):
        raise ValueError("invalid_time_range")
    if start % FOUR_HOURS_MS or (end is not None and end % FOUR_HOURS_MS):
        raise ValueError("time_range_must_align_to_4h")
    if not 1 <= limit <= MAX_PAGE_LIMIT or pages_cap < 1:
        raise ValueError("invalid_pagination_limits")
    fetcher = fetch_page
    if fetcher is None:
        fetcher = lambda params: _default_fetch_page(params, base_url=base_url, timeout=timeout)

    rows, page_count, cursor = [], 0, start
    seen = set()
    while cursor <= now and (end is None or cursor <= end):
        if page_count >= pages_cap:
            raise RuntimeError("pagination_page_limit_exceeded")
        params = {"symbol": str(symbol).upper(), "interval": DEFAULT_INTERVAL,
                  "startTime": cursor, "limit": limit}
        if end is not None:
            params["endTime"] = end + FOUR_HOURS_MS - 1
        page = fetcher(params)
        if not isinstance(page, list):
            raise ValueError("page_fetcher_must_return_list")
        page_count += 1
        if not page:
            break
        parsed = _parse_klines(page)
        previous_cursor = cursor
        for item in parsed:
            ts = item["t"]
            if ts in seen:
                raise ValueError("duplicate_candle_across_pages")
            seen.add(ts)
            # Binance closeTime is inclusive; a candle is closed only after it.
            if item["close_time"] is not None and item["close_time"] >= now:
                continue
            if ts + FOUR_HOURS_MS > now:
                continue
            rows.append(item)
        last_ts = max(item["t"] for item in parsed)
        next_cursor = last_ts + FOUR_HOURS_MS
        if next_cursor <= previous_cursor:
            raise RuntimeError("pagination_cursor_did_not_advance")
        if len(parsed) < limit:
            break
        cursor = next_cursor

    rows.sort(key=lambda x: x["t"])
    if not rows:
        return _blocked_result("no_closed_candles", symbol=symbol, page_count=page_count)
    df = pd.DataFrame(rows)
    # Keep close_time in source metadata, not in the model's OHLCV frame.
    source_close_times = df.pop("close_time").tolist()
    quality = validate_btc_4h(df, timestamp="t", max_gap_bars=int(max_gap_bars), require_volume=True)
    reasons = list(quality.get("reasons", []))
    warnings = list(quality.get("warnings", []))
    latest_expected = (now // FOUR_HOURS_MS - 1) * FOUR_HOURS_MS
    latest_actual = int(df["t"].iloc[-1])
    staleness = max(0, (latest_expected - latest_actual) // FOUR_HOURS_MS)
    if staleness > int(max_staleness_bars):
        reasons.append(f"latest_candle_stale:{staleness}_bars")
    if end is not None and latest_actual > end:
        reasons.append("candle_after_requested_end")
    status = "BLOCKED" if reasons else ("WARN" if warnings else "PASS")
    records = df[["t", "open", "high", "low", "close", "volume"]].to_dict("records")
    canonical = json.dumps(records, sort_keys=True, separators=(",", ":"), allow_nan=False)
    data_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return {
        "version": VERSION, "status": status, "symbol": str(symbol).upper(),
        "timeframe": "4h", "source": "binance_spot_rest_klines",
        "source_endpoint": "/api/v3/klines", "page_count": page_count,
        "row_count": len(df), "start_time_ms": int(df["t"].iloc[0]),
        "end_time_ms": latest_actual, "latest_expected_closed_open_time_ms": latest_expected,
        "staleness_bars": int(staleness), "source_close_times": source_close_times,
        "data_sha256": data_hash, "quality": quality,
        "reasons": reasons, "warnings": warnings,
        "policy": {"closed_candles_only": True, "auto_sort": False,
                   "auto_fill_gaps": False, "auto_repair_ohlcv": False,
                   "max_gap_bars": int(max_gap_bars),
                   "max_staleness_bars": int(max_staleness_bars)},
        "candles": records if status != "BLOCKED" else [],
        "fetched_at_utc": datetime.fromtimestamp(now / 1000, tz=timezone.utc).isoformat(),
        "safety": {"training_allowed": status == "PASS",
                   "paper_execution_allowed": False, "live_order_submission": False},
    }


def _blocked_result(reason, *, symbol=DEFAULT_SYMBOL, page_count=0):
    return {"version": VERSION, "status": "BLOCKED", "symbol": str(symbol).upper(),
            "timeframe": "4h", "source": "binance_spot_rest_klines",
            "page_count": int(page_count), "row_count": 0, "candles": [],
            "data_sha256": None, "reasons": [str(reason)], "warnings": [],
            "safety": {"training_allowed": False, "paper_execution_allowed": False,
                       "live_order_submission": False}}


def require_training_quality(ingestion_result):
    """Fail closed: only a clean PASS result may proceed to training."""
    if not isinstance(ingestion_result, dict) or ingestion_result.get("status") != "PASS":
        reasons = ingestion_result.get("reasons", []) if isinstance(ingestion_result, dict) else []
        raise ValueError("btc_data_quality_gate_blocked:" + ",".join(map(str, reasons)))
    if not ingestion_result.get("candles") or not ingestion_result.get("data_sha256"):
        raise ValueError("btc_data_quality_gate_missing_payload_or_hash")
    return pd.DataFrame(ingestion_result["candles"])


def main(argv=None):
    import argparse
    from pathlib import Path
    parser = argparse.ArgumentParser(description="Fetch and quality-check BTCUSDT 4h candles (public Binance spot REST).")
    parser.add_argument("--start-time-ms", type=int, required=True, help="Aligned 4h candle open time in milliseconds")
    parser.add_argument("--end-time-ms", type=int, default=None, help="Optional inclusive aligned 4h candle open time")
    parser.add_argument("--output", default="data/btcusdt_4h_ingestion.json")
    parser.add_argument("--max-gap-bars", type=int, default=0)
    parser.add_argument("--max-staleness-bars", type=int, default=0)
    args = parser.parse_args(argv)
    result = fetch_btc_4h_history(start_time_ms=args.start_time_ms, end_time_ms=args.end_time_ms,
                                  max_gap_bars=args.max_gap_bars,
                                  max_staleness_bars=args.max_staleness_bars)
    target = Path(args.output)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(target.suffix + ".tmp")
    temp.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(target)
    print(json.dumps({k: result.get(k) for k in ("status", "symbol", "timeframe", "row_count", "page_count", "data_sha256", "reasons")}, ensure_ascii=False, indent=2))
    return 0 if result.get("status") == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
