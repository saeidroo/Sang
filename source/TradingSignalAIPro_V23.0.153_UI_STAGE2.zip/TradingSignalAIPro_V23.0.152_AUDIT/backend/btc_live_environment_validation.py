"""Operator-run, read-only live environment validation for BTCUSDT 4h."""
from __future__ import annotations
import hashlib, json, os, platform, ssl, sys, time, urllib.parse
from datetime import datetime, timezone
from pathlib import Path


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode('utf-8')


def build_environment_fingerprint():
    """Return non-secret runtime facts; deliberately excludes env vars and hostnames."""
    payload = {
        'python_version': platform.python_version(),
        'python_implementation': platform.python_implementation(),
        'platform': platform.system(),
        'platform_release': platform.release(),
        'machine': platform.machine(),
        'openssl': ssl.OPENSSL_VERSION,
        'timezone_aware_utc': datetime.now(timezone.utc).utcoffset() is not None,
    }
    payload['sha256'] = hashlib.sha256(_canonical(payload)).hexdigest()
    return payload


def validate_live_environment(*, limit=120, timeout=12.0, max_age_hours=8,
                               fetcher=None, now_utc=None):
    """Perform actual public GET fetches unless a test fetcher is injected."""
    if fetcher is None:
        from backend.btc_cross_source_readonly import fetch_cross_source_btc_4h_readonly
        fetcher = fetch_cross_source_btc_4h_readonly
    started = time.monotonic()
    try:
        cross = fetcher(limit=limit, timeout=timeout, max_age_hours=max_age_hours)
        fetch_error = None
    except Exception as exc:  # capture diagnostics without leaking request headers/secrets
        cross = None
        fetch_error = f'{type(exc).__name__}:{str(exc)[:300]}'
    elapsed = round(time.monotonic() - started, 3)
    cross_status = cross.get('status') if isinstance(cross, dict) else None
    status = 'PASS' if cross_status == 'PASS' and fetch_error is None else (
        'DEGRADED' if cross_status == 'DEGRADED' else 'BLOCKED')
    report = {
        'schema': 'tekar.btc4h.live_environment_validation.v1',
        'created_at_utc': (now_utc or datetime.now(timezone.utc)).isoformat(),
        'status': status,
        'validation_scope': 'public_read_only_market_data_only',
        'environment': build_environment_fingerprint(),
        'request': {'symbol': 'BTCUSDT', 'timeframe': '4h', 'limit': limit,
                    'timeout_seconds': timeout, 'max_age_hours': max_age_hours},
        'elapsed_seconds': elapsed,
        'cross_source': cross,
        'fetch_error': fetch_error,
        'training_allowed': False,
        'paper_execution_allowed': False,
        'live_orders': False,
    }
    report['report_sha256'] = hashlib.sha256(_canonical(report)).hexdigest()
    return report


def verify_live_environment_report(report):
    if not isinstance(report, dict):
        raise ValueError('live_environment_report_invalid')
    supplied = report.get('report_sha256')
    payload = dict(report)
    payload.pop('report_sha256', None)
    actual = hashlib.sha256(_canonical(payload)).hexdigest()
    if not isinstance(supplied, str) or supplied != actual:
        raise ValueError('live_environment_report_hash_mismatch')
    if report.get('schema') != 'tekar.btc4h.live_environment_validation.v1':
        raise ValueError('live_environment_report_schema_invalid')
    if report.get('training_allowed') is not False or report.get('live_orders') is not False:
        raise ValueError('live_environment_report_safety_flags_invalid')
    return {'valid': True, 'status': report.get('status'), 'sha256': actual}


def save_live_environment_report(report, *, output_path):
    verify_live_environment_report(report)
    path = Path(output_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = _canonical(report) + b'\n'
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
    except Exception:
        try: os.unlink(path)
        except OSError: pass
        raise
    return {'saved': True, 'path': str(path), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest(), 'status': report['status'],
            'training_allowed': False, 'live_orders': False}
