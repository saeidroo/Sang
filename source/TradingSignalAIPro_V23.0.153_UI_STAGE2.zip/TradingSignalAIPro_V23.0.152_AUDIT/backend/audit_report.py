"""Cross-stream V22 audit report builder (V22.2h)."""
from __future__ import annotations
import json
from pathlib import Path
from .reproducible_run import verify_run_manifest


def build_audit_report(*, registry_events, paper_events, manifest_dir, registry_integrity=None, paper_integrity=None):
    starts = {str(e.get('experiment_id')): e for e in registry_events
              if e.get('event_type') == 'experiment_started' and e.get('experiment_id')}
    finishes = {str(e.get('experiment_id')): e for e in registry_events
                if e.get('event_type') == 'experiment_finished' and e.get('experiment_id')}
    paper_by_run = {}
    paper_by_id = {}
    for event in paper_events:
        paper_by_run.setdefault(str(event.get('run_id')), []).append(event)
        if event.get('event_id'):
            paper_by_id[str(event['event_id'])] = event
    manifests = []
    errors = []
    root = Path(manifest_dir)
    for path in sorted(root.glob('*.json')) if root.exists() else []:
        try:
            m = json.loads(path.read_text(encoding='utf-8'))
            verify = verify_run_manifest(m)
            run_id = str(m.get('run_id', ''))
            provenance = m.get('experiment_registry') or {}
            exp_id = provenance.get('experiment_id')
            consistency = []
            if exp_id and str(exp_id) not in starts:
                consistency.append('experiment_missing_from_registry')
            if exp_id and str(exp_id) in starts:
                start = starts[str(exp_id)]
                if start.get('data_hash') and start.get('data_hash') != (m.get('data') or {}).get('sha256'):
                    consistency.append('data_hash_mismatch')
            ledger = m.get('paper_ledger') or {}
            if ledger.get('run_id') and str(ledger['run_id']) != run_id:
                consistency.append('manifest_ledger_run_id_mismatch')
            for eid in ledger.get('event_ids') or []:
                linked = paper_by_id.get(str(eid))
                if not linked:
                    consistency.append(f'paper_event_missing:{eid}')
                elif str(linked.get('run_id')) != run_id:
                    consistency.append(f'paper_event_run_mismatch:{eid}')
            manifests.append({'run_id': run_id, 'path': path.name,
                'manifest_integrity': verify, 'experiment_id': exp_id,
                'experiment_finished': bool(exp_id and str(exp_id) in finishes),
                'paper_event_count_current': len(paper_by_run.get(run_id, [])),
                'consistency_errors': consistency})
            if not verify.get('valid'):
                errors.append(f'manifest_invalid:{path.name}')
            errors.extend(f'{run_id}:{x}' for x in consistency)
        except Exception as exc:
            errors.append(f'manifest_read_error:{path.name}:{exc}')
    return {'schema_version':'audit-report-v1', 'status':'ok' if not errors else 'attention_required',
        'registry_integrity':registry_integrity or {}, 'paper_ledger_integrity':paper_integrity or {},
        'registry_event_count':len(registry_events), 'paper_event_count':len(paper_events),
        'manifest_count':len(manifests), 'manifests':manifests, 'errors':errors,
        'recovery_note':'گزارش از فایل‌های پایدار Registry، Manifest و SQLite دوباره خوانده شده است؛ این بررسی، وجود نسخه پشتیبان مستقل را تضمین نمی‌کند.'}
