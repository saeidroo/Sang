"""V19 — Analyst: the brain explains itself (Persian narrative report).

Two engines, one contract:
- ``local``  — a deterministic Persian report assembled from the actual
  analysis payload (prices, brain component scores, scenario, memory stats).
  It can only cite numbers that exist in the payload; missing feeds are
  reported as missing, never invented. Works fully offline.
- ``deep``   — the same payload is sent to a GLM model (Z.ai, the same family
  that powers the assistant) with a strict prompt: "use only the provided
  numbers". If the model fails or no API key is configured, the local report
  is returned unchanged with a note.

The report is a VIEW over the decision pipeline — it never re-decides.
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from typing import Any

import requests

# --- configuration (mirrors ai_coach, but a separate limiter/cache) ---------
LOCK = threading.Lock()
_LAST_CALL_TS = 0.0
MIN_CALL_INTERVAL = 20.0
REQUEST_TIMEOUT = 60.0
_CACHE: dict[str, tuple[float, dict]] = {}
_CACHE_TTL = 90.0

BASE_URL_DEFAULT = 'https://api.z.ai/api/paas/v4/chat/completions'
MODEL_DEFAULT = 'glm-4.6'

COMPONENT_LABELS_FA = {
    'ml': 'مدل یادگیری ماشین',
    'technical': 'تکنیکال مستقل',
    'regime': 'رژیم بازار',
    'multi_timeframe': 'تأیید چندتایم‌فریم',
    'patterns': 'الگوهای کندلی',
    'derivatives': 'مشتقات و جریان سفارش',
    'horizon': 'چشم‌انداز آماری',
    'sentiment': 'شاخص ترس و طمع',
    'early_trend': 'تغییر روند زودهنگام',
    'drl': 'عامل یادگیری تقویتی',
    'divergence': 'واگرایی RSI/MACD',
    'ichimoku': 'ایچیموکو',
    'volume': 'جریان پول و حجم',
}

SETUP_LABELS_FA = {
    'trend_continuation': 'ادامه روند',
    'momentum_breakout': 'شکست مومنتوم',
    'mean_reversion': 'بازگشت به میانگین',
    'reversal_watch': 'مراقب بازگشت',
    'range': 'بازار رنج',
    'high_vol_caution': 'احتیاط در نوسان بالا',
}

SIGNAL_LABELS_FA = {'BUY': 'خرید', 'SELL': 'فروش', 'HOLD': 'انتظار/هیچ معامله‌ای'}

_REGIME_FA = {
    'bull': 'صعودی', 'bear': 'نزولی', 'sideways': 'خنثی/رنج',
    'high_volatility': 'نوسان بسیار بالا', 'unknown': 'نامشخص',
}


def deep_available() -> dict:
    base = (os.getenv('AI_COACH_BASE_URL', '') or BASE_URL_DEFAULT).strip()
    key = (os.getenv('ZAI_API_KEY', '') or os.getenv('AI_COACH_API_KEY', '') or '').strip()
    return {'available': bool(key), 'api_key': key,
            'model': (os.getenv('AI_COACH_MODEL', '') or MODEL_DEFAULT).strip(),
            'base_url': base,
            'note': ('گزارش عمیق GLM فعال است.' if key else
                     'برای گزارش عمیق، ZAI_API_KEY را در .env تنظیم کن؛ بدون کلید، گزارش محلی ساخته می‌شود.')}


# ---------------------------------------------------------------------------
# small formatting helpers
# ---------------------------------------------------------------------------
def _f(value: Any, nd: int = 2, default: str = '—') -> str:
    try:
        x = float(value)
    except (TypeError, ValueError):
        return default
    if x != x:  # NaN
        return default
    return f'{x:.{nd}f}'


def _score_phrase(score: float) -> str:
    if score >= 0.5:
        return 'به‌طور قوی به نفع صعود'
    if score >= 0.2:
        return 'ملایم و به نفع صعود'
    if score > -0.2:
        return 'عملاً خنثی'
    if score > -0.5:
        return 'ملایم و به نفع نزول'
    return 'به‌طور قوی به نفع نزول'


def _kind_fa(kind: str) -> str:
    return SIGNAL_LABELS_FA.get(str(kind).upper(), str(kind))


def _regime_fa(regime: dict | None) -> str:
    name = (regime or {}).get('regime') or 'unknown'
    return _REGIME_FA.get(name, str(name))


# ---------------------------------------------------------------------------
# local (offline) report
# ---------------------------------------------------------------------------
def _short_term_view(context: dict) -> tuple[str, float | None]:
    """Summarise the 5m/30m reads. Returns (Persian text, mean score or None)."""
    items = [x for x in (context.get('short_term') or []) if x.get('available')]
    if not items:
        return ('• نگاه ۵ و ۳۰ دقیقه: داده‌ی کوتاه‌مدت در دسترس نبود؛ در برآورد کلی لحاظ نشد.', None)
    lines, scores = [], []
    for x in items:
        s = float(x.get('score') or 0.0)
        scores.append(s)
        tf_fa = {'5m': '۵ دقیقه', '30m': '۳۰ دقیقه'}.get(x.get('timeframe'), str(x.get('timeframe')))
        lines.append(f'• {tf_fa}: امتیاز روند {_f(s, 2)} — {_score_phrase(s)}؛ '
                     f'تغییر ۵ کندل اخیر {_f(x.get("momentum_5_pct"))}٪.')
    mean = sum(scores) / len(scores)
    if len(scores) == 2 and scores[0] * scores[1] < 0 and min(abs(scores[0]), abs(scores[1])) >= 0.15:
        lines.append('• این دو تایم‌فریم با هم مخالف‌اند؛ نوسان کوتاه‌مدت پرنویز است و به‌تنهایی قابل اتکا نیست.')
    return ('\n'.join(lines), mean)


def build_verdict(analysis: dict, short_mean: float | None = None) -> str:
    """ONE Persian sentence: the overall estimate, built only from computed numbers."""
    sig = analysis.get('signal') or {}
    brain = analysis.get('brain') or {}
    kind = str(sig.get('kind', 'HOLD'))
    score = brain.get('score')
    score = float(score) if isinstance(score, (int, float)) else 0.0
    conf = brain.get('confidence')
    conf = float(conf) if isinstance(conf, (int, float)) else 0.0
    if kind == 'BUY':
        lead = 'تمایل کلی صعودی'
    elif kind == 'SELL':
        lead = 'تمایل کلی نزولی'
    elif score >= 0.15:
        lead = 'تمایل ضعیف صعودی'
    elif score <= -0.15:
        lead = 'تمایل ضعیف نزولی'
    else:
        lead = 'بازار فعلاً خنثی و بدون جهت مشخص'
    level = 'بالا' if conf >= 0.6 else 'متوسط' if conf >= 0.35 else 'پایین'
    if short_mean is None:
        short = 'داده‌ی ۵ و ۳۰ دقیقه در دسترس نبود'
    elif short_mean >= 0.15:
        short = 'نگاه کوتاه‌مدت ۵ و ۳۰ دقیقه صعودی است'
    elif short_mean <= -0.15:
        short = 'نگاه کوتاه‌مدت ۵ و ۳۰ دقیقه نزولی است'
    else:
        short = 'نگاه کوتاه‌مدت ۵ و ۳۰ دقیقه خنثی است'
    if kind in ('BUY', 'SELL'):
        agree = ((kind == 'BUY' and (short_mean or 0) >= 0.15) or
                 (kind == 'SELL' and (short_mean or 0) <= -0.15))
        clash = ((kind == 'BUY' and (short_mean or 0) <= -0.15) or
                 (kind == 'SELL' and (short_mean or 0) >= 0.15))
        tail = ('هم‌راستا با سیگنال ورود' if agree else
                'در تعارض با سیگنال ورود؛ با احتیاط و حد ضرر عمل کن' if clash else
                'و سیگنال ورود صادر شده است')
    else:
        tail = 'و سیگنال ورود صادر نشده؛ صبر منطقی‌تر است'
    ev = (sig.get('scenario') or {}).get('ev_net_pct')
    ev_txt = (f' (امید ریاضی خالص {_f(ev)}٪)' if isinstance(ev, (int, float)) and kind in ('BUY', 'SELL') else '')
    return f'برآورد کلی: {lead} با اطمینان {level}، {short}، {tail}{ev_txt}.'


def local_report(analysis: dict, memory_report: dict | None = None) -> dict:
    """Build the deterministic Persian report from one /api/analyze payload."""
    analysis = analysis or {}
    sig = analysis.get('signal') or {}
    brain = analysis.get('brain') or {}
    meta = analysis.get('model_meta') or {}
    context = analysis.get('market_context') or {}
    sections: list[dict] = []

    # 1 — summary
    price = analysis.get('price')
    chg = analysis.get('change_pct')
    summary_lines = [
        f'بازار {analysis.get("symbol", "—")} در تایم‌فریم {analysis.get("timeframe", "—")} '
        f'قیمت {_f(price, 4)} را معامله می‌کند '
        f'(تغییر {_f(chg)}٪ در بازه‌ی اخیر).',
        f'رژیم شناسایی‌شده: {_regime_fa(context.get("regime"))}. '
        f'منبع داده: {analysis.get("source_label") or analysis.get("source") or "—"} '
        f'با {analysis.get("candle_count", "—")} کندل.',
    ]
    kind = str(sig.get('kind', 'HOLD'))
    power_pct = _f((float(sig.get('power')) * 100.0)
                   if isinstance(sig.get('power'), (int, float)) else None, 0, '0')
    conf = brain.get('final_signal', kind)
    summary_lines.append(
        f'خروجی نهایی: {_kind_fa(kind)}'
        + (' (تأییدشده توسط مغز مرکزی)' if sig.get('brain_confirmed')
           else ' (سیگنال پایه توسط مغز مرکزی وتو شد)' if sig.get('brain_veto') else '')
        + f' با قدرت {power_pct}٪ و امتیاز اجماع {_f(brain.get("score"), 3)}.'
        if kind != 'HOLD' else
        f'خروجی نهایی: {_kind_fa(kind)} — شرایط ورودِ مطمئن جمع نشده است '
        f'(امتیاز اجماع {_f(brain.get("score"), 3)}، قدرت {power_pct}٪).')
    sections.append({'key': 'summary', 'title': 'خلاصه وضعیت', 'body': ' '.join(summary_lines)})

    # 2 — evidence from every available brain component
    used = brain.get('components') or {}
    evidence_lines = []
    directional = 0
    for name, item in used.items():
        label = COMPONENT_LABELS_FA.get(name, name)
        if not item.get('available'):
            reason = (item.get('detail') or {}).get('reason') or 'داده در دسترس نبود'
            reason_fa = {'not available': 'در دسترس نبود',
                         'not requested': 'درخواست نشد'}.get(str(reason), reason)
            evidence_lines.append(f'• {label}: غیرفعال ({reason_fa}).')
            continue
        score = float(item.get('score') or 0.0)
        if abs(score) >= 0.15:
            directional += 1
        evidence_lines.append(f'• {label}: امتیاز {_f(score, 2)} — {_score_phrase(score)}.')
    if brain.get('confluence'):
        conf_info = brain['confluence']
        if conf_info.get('shaping_factor') and float(conf_info['shaping_factor']) != 1.0:
            evidence_lines.append(
                f'• شکل‌دهی اجماع: ضریب {_f(conf_info["shaping_factor"], 2)} '
                f'({len(conf_info.get("bull_sources") or [])} منبع صعودی در برابر '
                f'{len(conf_info.get("bear_sources") or [])} منبع نزولی).')
    evidence_lines.append(
        f'• در مجموع {brain.get("available_sources", 0)} منبع فعال از ۱۳ و '
        f'{directional} منبع جهت‌دار (آستانه جهت‌داری |امتیاز| ≥ ۰٫۱۵).')
    sections.append({'key': 'evidence', 'title': 'استدلال منابع', 'body': '\n'.join(evidence_lines)})

    # 3 — agreement / conflicts / vetoes
    agree_lines = []
    if sig.get('agreement'):
        agree_map = {'high': 'هم‌رأیی بالای مدل‌های درون مجموعه', 'medium': 'هم‌رأیی متوسط',
                     'low': 'هم‌رأیی ضعیف (مدل‌ها اختلاف دارند)'}
        agree_lines.append(f'• {agree_map.get(sig["agreement"], sig["agreement"])}.')
    vetoes = brain.get('vetoes') or []
    if vetoes:
        agree_lines.append('• وتوهای فعال این بار: ' + '؛ '.join(vetoes) + '.')
    elif sig.get('brain_confirmed'):
        agree_lines.append('• هیچ وتویی فعال نشد؛ اجماع مستقل سیگنال پایه را تأیید کرد.')
    else:
        agree_lines.append('• وتویی لازم نبود چون سیگنال پایه از ابتدا BUY/SELL نشد.')
    if brain.get('edge_confirmed') is False:
        agree_lines.append('• برتری مدل خارج‌ازنمونه تأیید نشده؛ هر عدد سیگنال صرفاً اطلاعاتی است.')
    if not agree_lines:
        agree_lines.append('• مورد خاصی گزارش نشد.')
    sections.append({'key': 'agreement', 'title': 'توافق، تعارض و وتوها',
                     'body': '\n'.join(agree_lines)})

    # 4 — scenario (levels, RR, EV). Always emitted so downstream consumers
    # (deep GLM mapping, UI) can rely on all seven sections existing.
    scenario = sig.get('scenario') or {}
    if scenario:
        prov = ' (سناریوی مرجع، نه توصیه ورود)' if scenario.get('provisional') else ''
        setup_fa = SETUP_LABELS_FA.get(scenario.get('setup'), scenario.get('setup') or '—')
        scen_lines = [
            f'برچسب ستاپ: {setup_fa}{prov}.',
            f'ورود {_f(scenario.get("entry"), 4)} | هدف {_f(scenario.get("tp"), 4)} | '
            f'حدضرر {_f(scenario.get("sl"), 4)} — نسبت پاداش به ریسک {_f(scenario.get("reward_risk"), 2)}.',
            f'ارزش موردانتظار معامله‌ی مرجع: ناخالص {_f(scenario.get("ev_gross_pct"))}٪ و '
            f'خالص پس از هزینه {_f(scenario.get("ev_net_pct"))}٪ '
            f'(فرض هزینه رفت‌وبرگشت {_f(scenario.get("cost_pct"))}٪).',
            f'نقطه‌ی ابطال سناریو: {_f(scenario.get("invalidation"), 4)}.',
        ]
    else:
        scen_lines = ['سطوح سناریو در این پاسخ موجود نیست (مثلاً داده‌ی ATR کافی نبود).']
    sections.append({'key': 'scenario', 'title': 'سناریوی معامله و مدیریت ریسک',
                     'body': '\n'.join(scen_lines)})

    # 5 — risks
    risk_lines = []
    news_alert = sig.get('news_alert') or {}
    if sig.get('news_blocked'):
        risk_lines.append(f'• مسدودسازی خبری فعال است: {news_alert.get("alert_text") or "رویداد پرریسک"}.')
    if sig.get('meta_blocked'):
        risk_lines.append(f'• Meta-Labeler کیفیت این معامله را پایین دید '
                          f'({_f(sig.get("meta_probability"), 2)}).')
    regime = context.get('regime') or {}
    if regime.get('regime') == 'high_volatility':
        risk_lines.append(f'• نوسان سالانه {_f(regime.get("annualized_volatility"), 1)}٪ — '
                          'اندازه پوزیشن را کوچک‌تر نگه دار.')
    feed_errors = context.get('feed_errors') or []
    if feed_errors:
        risk_lines.append(f'• {len(feed_errors)} جریان داده موقتاً در دسترس نبود '
                          'و از اجماع حذف شد (نه اینکه رأی صفر بگیرد).')
    rl = analysis.get('rl_review') or {}
    if rl.get('deployment_eligible') and rl.get('direction') and \
            rl.get('direction') != sig.get('kind') and sig.get('kind') in ('BUY', 'SELL'):
        risk_lines.append('• عامل DRL با جهت سیگنال نهایی مخالف بود و به HOLD کمک کرد.')
    risk_lines.append('• هیچ خروجی این برنامه توصیه مالی نیست؛ مسئولیت اجرا با خودت است.')
    sections.append({'key': 'risks', 'title': 'ریسک‌ها و هشدارها', 'body': '\n'.join(risk_lines)})

    # 5b — short-term (5m / 30m) summary
    short_text, short_mean = _short_term_view(context)
    sections.append({'key': 'short_term', 'title': 'نگاه کوتاه‌مدت ۵ و ۳۰ دقیقه', 'body': short_text})

    # 6 — market memory
    mem = memory_report or {}
    mem_lines = []
    if mem.get('available'):
        latest = mem.get('latest') or {}
        diff = mem.get('diff') or {}
        if latest.get('bar_ts'):
            mem_lines.append(
                f'• تحلیل قبلی این بازار: سیگنال {_kind_fa(latest.get("signal_kind") or "HOLD")} '
                f'در قیمت {_f(latest.get("price"), 4)}.')
        if diff.get('price_change_pct') is not None:
            mem_lines.append(f'• تغییر قیمت از آن تحلیل: {_f(diff["price_change_pct"])}٪.')
        stats = mem.get('stats') or {}
        n_t = stats.get('matured_trades') or 0
        if n_t:
            mem_lines.append(
                f'• از {n_t} تحلیلِ رسیده‌به‌افق: برد جهت‌دار {_f(stats.get("directional_hit_rate"), 2)} '
                f'و میانگین بازده {_f(stats.get("avg_return_pct"))}٪.')
        else:
            mem_lines.append('• هنوز تحلیلی به افق ۱۲ کندلی نرسیده؛ آمار بعداً شکل می‌گیرد.')
    else:
        mem_lines.append('• حافظه برای این بازار خالی است؛ با هر تحلیل، مغز تاریخچه‌ی خودش را می‌سازد.')
    sections.append({'key': 'memory', 'title': 'حافظه بازار', 'body': '\n'.join(mem_lines)})

    # 7 — conclusion
    conclusion_lines = [
        f'جمع‌بندی: {_kind_fa(kind)}' + (' تأییدشده' if sig.get('brain_confirmed') else '')
        + f' با {_f(brain.get("confidence"), 2)} اطمینان اجماع.',
    ]
    if scenario.get('invalidation') is not None:
        conclusion_lines.append(
            f'اگر قیمت {_f(scenario.get("invalidation"), 4)} را از دست بدهد، این سناریو باطل است؛ '
            'در آن صورت هیچ دلیلی برای چسبیدن به تحلیل فعلی وجود ندارد.')
    if meta.get('edge_confirmed') and meta.get('best_threshold'):
        conclusion_lines.append(
            f'مدل این نماد برتری OOF تأییدشده دارد و آستانه‌ی فعال {_f(meta.get("best_threshold"), 2)} است.')
    sections.append({'key': 'conclusion', 'title': 'جمع‌بندی', 'body': ' '.join(conclusion_lines)})

    return {
        'engine': 'local',
        'title': f'گزارش تحلیلی {analysis.get("symbol", "")} — {analysis.get("timeframe", "")}',
        'generated_at': int(time.time()),
        'verdict': build_verdict(analysis, short_mean),
        'sections': sections,
        'disclaimer': 'این گزارش توصیه مالی نیست؛ بازتاب ساختاریافته‌ی همان داده‌هایی است که موتور تصمیم استفاده کرده است.',
    }


# ---------------------------------------------------------------------------
# deep (GLM) report
# ---------------------------------------------------------------------------
_SYSTEM_PROMPT = (
    'You are the senior Persian-language market analyst embedded in a trading-signal '
    'application. You receive ONE JSON payload containing everything the local decision '
    'engine computed (price, signal, central-brain component scores, scenario levels, '
    'expected value, memory stats, risks). Rules:\n'
    '1) Use ONLY the numbers present in the payload. Never invent, round differently, or '
    'add new numbers/levels/indicators. If a feed is missing, say it is missing.\n'
    '2) Write natural, specific Persian (Farsi) prose for an experienced trader. No markdown '
    'headers, no bullet characters, no English sentences.\n'
    '3) Be honest about uncertainty; never promise profit; never give leverage advice.\n'
    '4) Reply with ONLY a single JSON object, no markdown fences, exactly this schema:\n'
    '{"summary_fa": "<2-4 sentences>", "evidence_fa": "<3-6 sentences citing component scores>", '
    '"agreement_fa": "<2-4 sentences about agreement/conflicts/vetoes>", '
    '"scenario_fa": "<2-4 sentences about entry/TP/SL/RR/EV/invalidation>", '
    '"short_term_fa": "<1-3 sentences summarising the 5m and 30m reads in payload.short_term; if empty say it is missing>", '
    '"risks_fa": "<2-4 sentences>", "memory_fa": "<1-3 sentences>", '
    '"conclusion_fa": "<2-3 sentences>", '
    '"verdict_fa": "<EXACTLY ONE Persian sentence: your overall estimate of the market (direction + confidence + short-term view)>"}'
)

_JSON_RE = re.compile(r'\{.*\}', re.DOTALL)

_SECTION_MAP = [
    ('summary_fa', 'summary', 'خلاصه وضعیت'),
    ('evidence_fa', 'evidence', 'استدلال منابع'),
    ('agreement_fa', 'agreement', 'توافق، تعارض و وتوها'),
    ('scenario_fa', 'scenario', 'سناریوی معامله و مدیریت ریسک'),
    ('short_term_fa', 'short_term', 'نگاه کوتاه‌مدت ۵ و ۳۰ دقیقه'),
    ('risks_fa', 'risks', 'ریسک‌ها و هشدارها'),
    ('memory_fa', 'memory', 'حافظه بازار'),
    ('conclusion_fa', 'conclusion', 'جمع‌بندی'),
]


def _compact_context(analysis: dict, memory_report: dict | None) -> str:
    """Small JSON for the model: everything needed, nothing more."""
    analysis = analysis or {}
    sig = analysis.get('signal') or {}
    brain = analysis.get('brain') or {}
    components = {k: {'score': v.get('score'), 'available': v.get('available')}
                  for k, v in (brain.get('components') or {}).items()}
    payload = {
        'symbol': analysis.get('symbol'), 'timeframe': analysis.get('timeframe'),
        'price': analysis.get('price'), 'change_pct': analysis.get('change_pct'),
        'candles': analysis.get('candle_count'),
        'signal': {k: sig.get(k) for k in (
            'kind', 'power', 'prob', 'entry', 'tp', 'sl', 'levels_side',
            'levels_provisional', 'brain_confirmed', 'brain_veto', 'agreement',
            'meta_probability', 'meta_blocked', 'news_blocked')},
        'scenario': sig.get('scenario'),
        'brain': {'decision': brain.get('decision'), 'final_signal': brain.get('final_signal'),
                  'score': brain.get('score'), 'confidence': brain.get('confidence'),
                  'coverage': brain.get('coverage'),
                  'available_sources': brain.get('available_sources'),
                  'directional_sources': brain.get('directional_sources'),
                  'confluence': brain.get('confluence'), 'vetoes': brain.get('vetoes'),
                  'components': components},
        'regime': (analysis.get('market_context') or {}).get('regime'),
        'patterns': (analysis.get('market_context') or {}).get('patterns'),
        'multi_timeframe': (analysis.get('market_context') or {}).get('multi_timeframe'),
        'short_term': (analysis.get('market_context') or {}).get('short_term'),
        'derivatives_available': bool((analysis.get('market_context') or {}).get('derivatives', {}).get('available')),
        'news_alert': {k: (analysis.get('signal') or {}).get(k) for k in ('news_blocked',)},
        'model_meta': {k: (analysis.get('model_meta') or {}).get(k) for k in (
            'val_acc', 'balanced_acc', 'walk_forward_acc', 'best_threshold',
            'edge_confirmed', 'n_seeds', 'training_round', 'calibrated')},
        'backtest_stats': analysis.get('backtest_stats'),
        'memory': memory_report,
        'strength_profile': analysis.get('strength'),
    }
    return json.dumps(payload, ensure_ascii=False, default=str)[:9000]


def deep_report(analysis: dict, memory_report: dict | None = None) -> dict:
    """GLM-enhanced report; always falls back to the local engine on any failure."""
    global _LAST_CALL_TS
    local = local_report(analysis, memory_report)
    cfg = deep_available()
    if not cfg['available']:
        local['note'] = cfg['note']
        return local
    symbol = str((analysis or {}).get('symbol') or '')
    tf = str((analysis or {}).get('timeframe') or '')
    cache_key = f'{symbol}|{tf}'
    now = time.time()
    cached = _CACHE.get(cache_key)
    if cached and now - cached[0] < _CACHE_TTL:
        out = dict(cached[1])
        out['from_cache'] = True
        return out
    with LOCK:
        wait = MIN_CALL_INTERVAL - (now - _LAST_CALL_TS)
        if wait > 0:
            time.sleep(min(wait, 15.0))
        _LAST_CALL_TS = time.time()
    context = _compact_context(analysis, memory_report)
    payload = {
        'model': cfg['model'],
        'temperature': 0.4,
        'max_tokens': 1400,
        'messages': [
            {'role': 'system', 'content': _SYSTEM_PROMPT},
            {'role': 'user', 'content': 'Payload:\n' + context},
        ],
    }
    headers = {'Authorization': f"Bearer {cfg.get('api_key')}",
               'Content-Type': 'application/json',
               'User-Agent': 'TradingSignalAIPro/19.0'}
    last_error = None
    for attempt in range(2):
        try:
            response = requests.post(cfg['base_url'], json=payload, headers=headers,
                                     timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            data = response.json()
            content = ''
            choices = data.get('choices') or []
            if choices:
                content = str((choices[0].get('message') or {}).get('content') or '')
            match = _JSON_RE.search(content)
            if not match:
                raise ValueError('پاسخ مدل JSON نداشت')
            parsed = json.loads(match.group(0))
            if not isinstance(parsed, dict):
                raise ValueError('ساختار پاسخ نامعتبر بود')
            sections = []
            for field, key, title in _SECTION_MAP:
                text = str(parsed.get(field) or '').strip()
                if not text:
                    # fall back to the local section instead of an empty block
                    text = next((s['body'] for s in local['sections'] if s['key'] == key), '')
                sections.append({'key': key, 'title': title, 'body': text})
            out = {
                'engine': f"glm:{cfg['model']}",
                'title': local['title'],
                'generated_at': int(time.time()),
                'verdict': (' '.join(str(parsed.get('verdict_fa') or '').split()[:60]) or local.get('verdict')),
                'sections': sections,
                'disclaimer': local['disclaimer'],
            }
            _CACHE[cache_key] = (time.time(), out)
            return out
        except Exception as exc:
            last_error = f'{type(exc).__name__}: {exc}'[:200]
            if attempt == 0:
                time.sleep(2.0)
    local['engine'] = 'local'
    local['note'] = f'گزارش عمیق در دسترس نبود ({last_error})؛ نسخه‌ی محلی ارائه شد.'
    return local
