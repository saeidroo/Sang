"""Encrypted backup, restore and audit for the BTC replay Ed25519 trust store."""
from __future__ import annotations
import base64, hashlib, json, os, re, tempfile
from pathlib import Path
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

SCHEMA='btc-replay-trust-backup-v1'


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()


def _derive(password: str, salt: bytes) -> bytes:
    if not isinstance(password,str) or len(password) < 12:
        raise ValueError('trust_backup_password_too_short')
    return base64.urlsafe_b64encode(Scrypt(salt=salt,length=32,n=2**14,r=8,p=1).derive(password.encode('utf-8')))


def audit_replay_trust_store(*, trust_dir=None):
    from backend import signed_anchor
    root=Path(trust_dir).expanduser() if trust_dir is not None else signed_anchor._key_dir()
    errors=[]
    try:
        active=json.loads((root/'active_key.json').read_text(encoding='utf-8'))
        revoked_state=json.loads((root/'revoked.json').read_text(encoding='utf-8')) if (root/'revoked.json').exists() else {'revoked': []}
        sequence_state=json.loads((root/'sequence.json').read_text(encoding='utf-8')) if (root/'sequence.json').exists() else {'highest_sequence': 0}
        revoked=revoked_state.get('revoked',[])
        sequence=sequence_state.get('highest_sequence',0)
        if not isinstance(sequence,int) or sequence < 0: errors.append('trust_sequence_invalid')
        if not isinstance(revoked,list) or any(not isinstance(x,str) or not re.fullmatch(r'[0-9a-f]{64}',x) for x in revoked): errors.append('trust_revocation_list_invalid')
        trusted=root/'trusted'; keys={}
        for pub_path in trusted.glob('*.public.pem'):
            kid=pub_path.name[:-len('.public.pem')]
            if not re.fullmatch(r'[0-9a-f]{64}',kid): errors.append('trust_public_filename_invalid'); continue
            pub=serialization.load_pem_public_key(pub_path.read_bytes())
            if not isinstance(pub,Ed25519PublicKey): errors.append('trust_public_key_type_invalid'); continue
            raw=pub.public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
            if hashlib.sha256(raw).hexdigest()!=kid: errors.append('trust_public_fingerprint_mismatch')
            priv_path=trusted/f'{kid}.private.pem'
            if priv_path.exists():
                priv=serialization.load_pem_private_key(priv_path.read_bytes(),password=None)
                if not isinstance(priv,Ed25519PrivateKey): errors.append('trust_private_key_type_invalid')
                elif priv.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)!=raw: errors.append('trust_keypair_mismatch')
            keys[kid]=True
        active_id=active.get('key_id') if isinstance(active,dict) else None
        if active_id not in keys: errors.append('trust_active_key_missing')
        if active_id in set(revoked if isinstance(revoked,list) else []): errors.append('trust_active_key_revoked')
        if not keys: errors.append('trust_no_public_keys')
        return {'healthy':not errors,'active_key_id':active_id,'trusted_key_count':len(keys),
                'revoked_key_count':len(revoked) if isinstance(revoked,list) else 0,
                'highest_signing_sequence':sequence,'errors':errors}
    except Exception as exc:
        return {'healthy':False,'errors':[f'{type(exc).__name__}:{exc}']}


def export_replay_trust_store_backup(output_path, *, password: str):
    from backend import signed_anchor
    root=signed_anchor._key_dir()
    health=audit_replay_trust_store(trust_dir=root)
    if not health['healthy']:
        raise ValueError('trust_store_unhealthy:'+';'.join(health['errors']))
    files={}
    defaults={'revoked.json':b'{\"revoked\":[]}\n','sequence.json':b'{\"highest_sequence\":0}\n'}
    for name in ('active_key.json','revoked.json','sequence.json'):
        raw=(root/name).read_bytes() if (root/name).exists() else defaults[name]
        files[name]=base64.b64encode(raw).decode('ascii')
    trusted=root/'trusted'
    for path in sorted(trusted.glob('*.pem')):
        if path.name.endswith('.private.pem') or path.name.endswith('.public.pem'):
            files['trusted/'+path.name]=base64.b64encode(path.read_bytes()).decode('ascii')
    payload=_canonical({'schema_version':SCHEMA,'files':files})
    import secrets
    salt=secrets.token_bytes(16); token=Fernet(_derive(password,salt)).encrypt(payload)
    envelope={'schema_version':SCHEMA,'kdf':'scrypt-n16384-r8-p1','salt':base64.b64encode(salt).decode(),
              'ciphertext':base64.b64encode(token).decode(),
              'ciphertext_sha256':hashlib.sha256(token).hexdigest()}
    out=Path(output_path).expanduser(); out.parent.mkdir(parents=True,exist_ok=True)
    fd=os.open(str(out),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as stream:
        stream.write(_canonical(envelope)+b'\n'); stream.flush(); os.fsync(stream.fileno())
    return {'created':True,'path':str(out),'encrypted':True,'file_count':len(files),
            'ciphertext_sha256':envelope['ciphertext_sha256'],'active_key_id':health['active_key_id']}


def restore_replay_trust_store_backup(backup_path, destination_dir, *, password: str):
    source=Path(backup_path).expanduser(); destination=Path(destination_dir).expanduser()
    if not source.is_file(): raise FileNotFoundError('trust_backup_missing')
    if destination.exists(): raise FileExistsError('trust_restore_destination_exists')
    envelope=json.loads(source.read_text(encoding='utf-8'))
    if envelope.get('schema_version')!=SCHEMA or envelope.get('kdf')!='scrypt-n16384-r8-p1':
        raise ValueError('trust_backup_schema_or_kdf_invalid')
    salt=base64.b64decode(envelope['salt'],validate=True); token=base64.b64decode(envelope['ciphertext'],validate=True)
    if hashlib.sha256(token).hexdigest()!=envelope.get('ciphertext_sha256'):
        raise ValueError('trust_backup_ciphertext_hash_mismatch')
    try: payload=json.loads(Fernet(_derive(password,salt)).decrypt(token))
    except (InvalidToken,ValueError) as exc: raise ValueError('trust_backup_decryption_failed') from exc
    if payload.get('schema_version')!=SCHEMA or not isinstance(payload.get('files'),dict):
        raise ValueError('trust_backup_payload_invalid')
    destination.parent.mkdir(parents=True,exist_ok=True)
    temp=Path(tempfile.mkdtemp(prefix=destination.name+'.restore.',dir=str(destination.parent)))
    try:
        for relative,encoded in payload['files'].items():
            rel=Path(relative)
            if rel.is_absolute() or '..' in rel.parts or len(rel.parts)>2:
                raise ValueError('trust_backup_path_invalid')
            if relative not in ('active_key.json','revoked.json','sequence.json') and not (len(rel.parts)==2 and rel.parts[0]=='trusted' and re.fullmatch(r'[0-9a-f]{64}\.(private|public)\.pem',rel.name)):
                raise ValueError('trust_backup_filename_invalid')
            target=temp/rel; target.parent.mkdir(parents=True,exist_ok=True)
            raw=base64.b64decode(encoded,validate=True)
            fd=os.open(str(target),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600 if rel.name.endswith('.private.pem') or rel.name.endswith('.json') else 0o644)
            with os.fdopen(fd,'wb') as stream: stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        health=audit_replay_trust_store(trust_dir=temp)
        if not health['healthy']: raise ValueError('restored_trust_store_unhealthy:'+';'.join(health['errors']))
        destination.parent.mkdir(parents=True,exist_ok=True)
        os.rename(temp,destination)
        return {'restored':True,'path':str(destination),'active_key_id':health['active_key_id'],
                'trusted_key_count':health['trusted_key_count'],'highest_signing_sequence':health['highest_signing_sequence']}
    except Exception:
        import shutil
        shutil.rmtree(temp,ignore_errors=True)
        raise
