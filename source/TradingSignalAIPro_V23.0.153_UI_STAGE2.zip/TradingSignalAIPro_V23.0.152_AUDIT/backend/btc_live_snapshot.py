"""Reconcile read-only live BTC 4h candles into immutable snapshots without auto-training."""
from __future__ import annotations
import hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path
from backend.btc_ingestion_store import _read_manifest, _load_latest, append_ingestion
from backend.btc_source_reconciliation import reconcile_candles

FIELDS=('t','open','high','low','close','volume')


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)


def _sha(value): return hashlib.sha256(_canonical(value).encode()).hexdigest()


def ingest_readonly_live_snapshot(report: dict, *, store_root):
    if not isinstance(report,dict) or report.get('status')!='PASS' or report.get('read_only') is not True:
        raise ValueError('readonly_live_report_not_passed')
    if report.get('symbol')!='BTCUSDT' or report.get('timeframe')!='4h':
        raise ValueError('readonly_live_report_contract_mismatch')
    candles=report.get('candles')
    if not isinstance(candles,list) or len(candles)<2:
        raise ValueError('readonly_live_report_candles_missing')
    rows=[{k:(int(row[k]) if k=='t' else float(row[k])) for k in FIELDS} for row in candles]
    batch_hash=_sha(rows)
    root=Path(store_root); manifest=_read_manifest(root)
    if manifest.get('latest_snapshot'):
        prior=_load_latest(root,manifest)
        # Compare only the timestamp overlap represented by the new live window.
        lo,hi=rows[0]['t'],rows[-1]['t']
        prior_overlap=[r for r in prior if lo <= int(r['t']) <= hi]
        reconciliation=reconcile_candles(prior_overlap,rows)
        reconciliation.update({'created_at_utc':datetime.now(timezone.utc).isoformat(),
            'previous_snapshot':manifest['latest_snapshot'],'source':'read_only_live_binance',
            'training_allowed':False,'live_orders':False})
        reconciliation['report_sha256']=_sha(reconciliation)
        rec_dir=root/'reconciliation'; rec_dir.mkdir(parents=True,exist_ok=True)
        rec_path=rec_dir/(reconciliation['report_sha256']+'.json')
        raw=json.dumps(reconciliation,sort_keys=True,ensure_ascii=False,indent=2).encode('utf-8')
        fd=os.open(str(rec_path),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'wb') as stream: stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        if reconciliation['status']!='PASS':
            return {'status':'BLOCKED','reason':'closed_candle_revision_or_removal',
                    'reconciliation':reconciliation,'snapshot':None,
                    'training_allowed':False,'live_orders':False}
    else:
        reconciliation={'status':'FIRST_SNAPSHOT','revision_count':0,'removed_count':0,
            'added_count':len(rows),'training_allowed':False,'live_orders':False,
            'created_at_utc':datetime.now(timezone.utc).isoformat()}
        reconciliation['report_sha256']=_sha(reconciliation)
    ingestion={'version':'btc-4h-ingestion-readonly-v1','status':'PASS','symbol':'BTCUSDT',
        'timeframe':'4h','source':'binance_readonly_adapter','row_count':len(rows),
        'candles':rows,'data_sha256':batch_hash,'quality':{'status':'PASS'},
        'safety':{'training_allowed':False,'live_orders':False}}
    stored=append_ingestion(root,ingestion,allow_training=False)
    return {'status':'PASS','snapshot':stored['snapshot'],'row_count':stored['row_count'],
        'added_rows':stored['added_rows'],'data_sha256':stored['data_sha256'],
        'reconciliation':reconciliation,'training_allowed':False,'live_orders':False}
