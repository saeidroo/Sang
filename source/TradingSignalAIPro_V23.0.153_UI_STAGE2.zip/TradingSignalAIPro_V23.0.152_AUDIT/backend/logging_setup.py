"""Central bounded, redacted application logging for Trading Signal AI Pro."""
from __future__ import annotations
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import re
import threading

_LOCK = threading.Lock()
_CONFIGURED = False
_SECRET_PATTERNS = [
    (re.compile(r'(?i)(authorization\s*[=:]\s*Bearer\s+)[A-Za-z0-9._~+/=-]+'), r'\1[REDACTED]'),
    (re.compile(r'(?i)(api[_-]?key|secret|password|token|authorization)(\s*[=:]\s*)([^\s,;]+)'), r'\1\2[REDACTED]'),
    (re.compile(r'(?i)(Bearer\s+)[A-Za-z0-9._~+/=-]+'), r'\1[REDACTED]'),
]

class RedactingFilter(logging.Filter):
    """Redact common credentials from rendered messages and arguments."""
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            message = record.getMessage()
            for pattern, replacement in _SECRET_PATTERNS:
                message = pattern.sub(replacement, message)
            record.msg = message
            record.args = ()
        except Exception:
            record.msg = '[LOG MESSAGE REDACTION FAILED]'
            record.args = ()
        return True

def log_directory() -> Path:
    override = os.getenv('TRADING_AI_LOG_DIR', '').strip()
    return Path(override).expanduser() if override else Path.home() / '.trading_ai_logs'

def configure_logging(*, max_bytes: int = 2_000_000, backup_count: int = 5) -> Path:
    """Install one rotating UTF-8 log file; safe to call repeatedly."""
    global _CONFIGURED
    with _LOCK:
        directory = log_directory()
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / 'trading_ai.log'
        if not _CONFIGURED:
            handler = RotatingFileHandler(path, maxBytes=max_bytes, backupCount=backup_count, encoding='utf-8')
            handler.setLevel(logging.INFO)
            handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(name)s [%(threadName)s] %(message)s'))
            handler.addFilter(RedactingFilter())
            root = logging.getLogger()
            root.addHandler(handler)
            if root.level > logging.INFO or root.level == logging.NOTSET:
                root.setLevel(logging.INFO)
            _CONFIGURED = True
        return path
