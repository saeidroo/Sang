"""Resumable chunked HTTPS Witness replication (V22.2q)."""
from __future__ import annotations
import json, ssl
from urllib.request import Request, urlopen
from backend.witness_ops import _records
from backend.witness_server import verify_anchor_record


def build_replication_batch(source_db, source_public_key, *, after_sequence=0, limit=500):
    if after_sequence < 0 or limit < 1 or limit > 5000:
        raise ValueError('invalid_replication_cursor_or_limit')
    entries=[]
    rows=_records(source_db)
    for row in rows:
        seq=int(row['sequence'])
        if seq <= after_sequence: continue
        if seq != after_sequence + len(entries) + 1:
            raise ValueError('witness_sequence_gap')
        receipt={k:row[k] for k in ('schema_version','witness_id','anchor_digest','sequence','timestamp','signature')}
        verify_anchor_record(receipt, source_public_key)
        anchor=json.loads(row['anchor_json'])
        entries.append({'receipt':receipt,'anchor':anchor})
        if len(entries) >= limit: break
    return entries


def _request(url, method, token, *, payload=None, timeout=15, context=None):
    body=None if payload is None else json.dumps(payload,separators=(',',':'),ensure_ascii=False).encode()
    headers={'Authorization':'Bearer '+token,'Accept':'application/json'}
    if body is not None: headers['Content-Type']='application/json'
    req=Request(url,data=body,headers=headers,method=method)
    with urlopen(req,timeout=timeout,context=context) as response:
        result=json.loads(response.read().decode())
        if response.status != 200: raise RuntimeError('remote_replication_http_error')
        return result


def push_replication_http(source_db, source_public_key, endpoint, bearer_token, *, timeout=15, after_sequence=0, limit=500, ssl_context=None):
    """Push one bounded chunk; `after_sequence` is the last acknowledged source sequence."""
    _validate_endpoint(endpoint)
    entries=build_replication_batch(source_db,source_public_key,after_sequence=after_sequence,limit=limit)
    if not entries:
        return {'status':'synchronized','appended':0,'source_sequence':after_sequence,'next_sequence':after_sequence+1,'has_more':False}
    result=_request(endpoint.rstrip('/')+'/v1/replication/push', 'POST', bearer_token,
                    payload={'after_sequence':after_sequence,'entries':entries},timeout=timeout,context=ssl_context)
    expected=entries[-1]['receipt']['sequence']
    if result.get('sequence') != expected or result.get('head_digest') != entries[-1]['receipt']['anchor_digest']:
        raise RuntimeError('remote_replication_ack_mismatch')
    return {**result,'source_sequence':expected,'next_sequence':expected+1,'has_more':len(_records(source_db))>expected}


def sync_replication_http(source_db, source_public_key, endpoint, bearer_token, *, timeout=15, chunk_size=500, max_chunks=100000, ssl_context=None):
    """Resume from receiver's committed cursor; safe to call again after a disconnect."""
    _validate_endpoint(endpoint)
    base=endpoint.rstrip('/')
    chunks=0; total_appended=0
    while chunks < max_chunks:
        status=_request(base+'/v1/replication/status','GET',bearer_token,timeout=timeout,context=ssl_context)
        cursor=int(status.get('sequence',-1))
        if cursor < 0: raise RuntimeError('remote_replication_invalid_cursor')
        local_rows=_records(source_db)
        if cursor > len(local_rows): raise ValueError('remote_replica_ahead_of_source')
        if cursor:
            local=local_rows[cursor-1]
            if local['anchor_digest'] != status.get('head_digest'):
                raise ValueError('remote_replication_divergent_cursor')
        if cursor == len(local_rows):
            return {'status':'synchronized','sequence':cursor,'head_digest':status.get('head_digest'),'chunks':chunks,'appended':total_appended}
        result=push_replication_http(source_db,source_public_key,endpoint,bearer_token,timeout=timeout,
                                     after_sequence=cursor,limit=chunk_size,ssl_context=ssl_context)
        total_appended += int(result.get('appended',0)); chunks += 1
    raise RuntimeError('remote_replication_max_chunks_exceeded')


def build_mtls_context(*, ca_file=None, cert_file=None, key_file=None):
    """Client TLS context. Supplying cert+key enables mutual TLS at the TLS terminator."""
    if bool(cert_file) != bool(key_file): raise ValueError('mtls_client_cert_and_key_required_together')
    ctx=ssl.create_default_context(cafile=ca_file)
    if cert_file: ctx.load_cert_chain(certfile=cert_file,keyfile=key_file)
    return ctx


def _validate_endpoint(endpoint):
    if not endpoint.startswith('https://') and not endpoint.startswith('http://127.0.0.1') and not endpoint.startswith('http://localhost'):
        raise ValueError('remote_replication_requires_https')
