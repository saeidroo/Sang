"""V22.2l external witness client.

The remote witness is an independently operated HTTPS service. This module only
implements the client contract; it deliberately does not pretend that a local
file or the trading application itself is an external timestamp authority.
"""
from __future__ import annotations
import base64, hashlib, json, os, urllib.request, urllib.error
from datetime import datetime, timezone
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

SCHEMA = 'ts-ai-external-witness-v1'

def canonical(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')

def anchor_digest(anchor: dict) -> str:
    return hashlib.sha256(canonical(anchor)).hexdigest()

def config_status() -> dict:
    url = os.getenv('TS_AI_WITNESS_URL', '').strip()
    pem = os.getenv('TS_AI_WITNESS_PUBLIC_KEY_PEM', '').strip()
    return {'configured': bool(url and pem), 'https_only': True,
            'url_present': bool(url), 'pinned_public_key_present': bool(pem),
            'contract': SCHEMA}

def verify_receipt(receipt: dict, expected_digest: str, *, public_key_pem: str | None = None) -> dict:
    try:
        if receipt.get('schema_version') != SCHEMA: raise ValueError('witness_schema_unsupported')
        if receipt.get('anchor_digest') != expected_digest: raise ValueError('witness_anchor_digest_mismatch')
        if not isinstance(receipt.get('sequence'), int) or receipt['sequence'] < 1: raise ValueError('witness_sequence_invalid')
        ts = datetime.fromisoformat(str(receipt['timestamp']).replace('Z', '+00:00'))
        if ts.tzinfo is None: raise ValueError('witness_timestamp_timezone_missing')
        pem = public_key_pem or os.getenv('TS_AI_WITNESS_PUBLIC_KEY_PEM', '')
        if not pem: raise ValueError('witness_public_key_not_configured')
        pub = serialization.load_pem_public_key(pem.encode() if isinstance(pem, str) else pem)
        if not isinstance(pub, Ed25519PublicKey): raise ValueError('witness_key_type_invalid')
        payload = {k: receipt[k] for k in ('schema_version','witness_id','anchor_digest','sequence','timestamp')}
        pub.verify(base64.b64decode(receipt['signature'], validate=True), canonical(payload))
        return {'valid': True, 'witness_id': payload['witness_id'], 'sequence': payload['sequence'], 'timestamp': payload['timestamp'], 'errors': []}
    except Exception as exc:
        return {'valid': False, 'errors': [str(exc)]}

def submit_anchor(anchor: dict, *, timeout: float = 8.0) -> dict:
    url = os.getenv('TS_AI_WITNESS_URL', '').strip()
    pem = os.getenv('TS_AI_WITNESS_PUBLIC_KEY_PEM', '').strip()
    if not url.startswith('https://'): return {'ok': False, 'error': 'witness_https_url_required'}
    if not pem: return {'ok': False, 'error': 'witness_public_key_not_configured'}
    body = {'schema_version': SCHEMA, 'anchor_digest': anchor_digest(anchor), 'anchor': anchor}
    req = urllib.request.Request(url.rstrip('/') + '/v1/anchors', data=canonical(body), headers={'Content-Type':'application/json','Accept':'application/json', **({'Authorization': 'Bearer ' + os.getenv('TS_AI_WITNESS_API_TOKEN', '').strip()} if os.getenv('TS_AI_WITNESS_API_TOKEN', '').strip() else {})}, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            if response.status != 200: return {'ok': False, 'error': f'witness_http_status:{response.status}'}
            receipt = json.loads(response.read().decode('utf-8'))
        verified = verify_receipt(receipt, body['anchor_digest'], public_key_pem=pem)
        if not verified['valid']: return {'ok': False, 'error': 'witness_receipt_invalid', 'details': verified['errors']}
        return {'ok': True, 'anchor_digest': body['anchor_digest'], 'receipt': receipt, 'verification': verified}
    except Exception as exc:
        return {'ok': False, 'error': f'witness_request_failed:{type(exc).__name__}:{exc}'}
