"""Auditable strategy performance summaries from realized paper outcomes only."""
from __future__ import annotations
import json
from collections import defaultdict


def _strategy_name(context_json: str) -> str:
    try:
        ctx = json.loads(context_json or "{}")
    except (TypeError, ValueError):
        ctx = {}
    if not isinstance(ctx, dict):
        return "UNATTRIBUTED"
    nested = ctx.get("decision") if isinstance(ctx.get("decision"), dict) else {}
    for source in (ctx, nested):
        for key in ("strategy_id", "strategy", "brain", "strategy_name", "signal_source"):
            value = source.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()[:80]
    return "UNATTRIBUTED"


def _market_regime(context_json: str) -> str:
    """Extract a recorded regime label; do not infer regime from future outcomes."""
    try:
        ctx = json.loads(context_json or "{}")
    except (TypeError, ValueError):
        ctx = {}
    if not isinstance(ctx, dict):
        return "UNKNOWN"
    nested = ctx.get("decision") if isinstance(ctx.get("decision"), dict) else {}
    regime_analysis = ctx.get("regime_analysis") if isinstance(ctx.get("regime_analysis"), dict) else {}
    for source in (ctx, nested, regime_analysis):
        for key in ("market_regime", "regime", "market_state", "regime_label", "trend_regime"):
            value = source.get(key)
            if isinstance(value, str) and value.strip():
                label = value.strip().upper().replace(" ", "_")[:40]
                aliases = {"BULL": "BULLISH", "BEAR": "BEARISH", "SIDEWAYS": "RANGING", "FLAT": "RANGING"}
                return aliases.get(label, label)
    return "UNKNOWN"



def _volatility_regime(context_json: str) -> str:
    """Use only volatility labels or ATR/price recorded when the trade was opened."""
    try:
        ctx = json.loads(context_json or "{}")
    except (TypeError, ValueError):
        ctx = {}
    if not isinstance(ctx, dict):
        return "UNKNOWN"
    nested = ctx.get("decision") if isinstance(ctx.get("decision"), dict) else {}
    sources = [ctx, nested]
    for key in ("volatility_analysis", "atr_analysis", "market_volatility"):
        value = ctx.get(key)
        if isinstance(value, dict):
            sources.append(value)
    for source in sources:
        for key in ("volatility_regime", "volatility_state", "volatility_label"):
            value = source.get(key)
            if isinstance(value, str) and value.strip():
                label = value.strip().upper().replace(" ", "_")[:30]
                aliases = {"LOW_VOLATILITY":"LOW", "HIGH_VOLATILITY":"HIGH", "MEDIUM_VOLATILITY":"MEDIUM", "NORMAL":"MEDIUM", "CALM":"LOW", "EXTREME":"HIGH"}
                if label in {"LOW", "MEDIUM", "HIGH", "UNKNOWN"}:
                    return label
                return aliases.get(label, "UNKNOWN")
    # ATR percent bands are intentionally conservative and explicitly auditable.
    for source in sources:
        atr = source.get("atr") or source.get("atr_value")
        price = source.get("price") or source.get("entry_price") or source.get("close")
        try:
            ratio = float(atr) / float(price) * 100.0
            if ratio > 0 and ratio < 100 and __import__("math").isfinite(ratio):
                return "LOW" if ratio < 1.0 else "MEDIUM" if ratio < 3.0 else "HIGH"
        except (TypeError, ValueError, ZeroDivisionError):
            pass
    return "UNKNOWN"


def rank_strategy_performance(events: list[dict], *, min_samples: int = 10) -> dict:
    """Rank strategy/symbol/market/timeframe/side cohorts; never train on open trades."""
    min_samples = max(1, min(500, int(min_samples)))
    groups = defaultdict(list)
    for e in events or []:
        try:
            pnl = float(e.get("net_pnl", 0))
            ret = float(e.get("return_pct", 0))
            if not __import__("math").isfinite(pnl) or not __import__("math").isfinite(ret):
                continue
            strategy = _strategy_name(e.get("context_json", "{}"))
            regime = _market_regime(e.get("context_json", "{}"))
            volatility = _volatility_regime(e.get("context_json", "{}"))
            key = (strategy, str(e.get("symbol", "")), str(e.get("market", "")),
                   str(e.get("timeframe", "")), str(e.get("side", "")), regime, volatility)
            groups[key].append((pnl, ret))
        except (TypeError, ValueError):
            continue
    ranked = []
    for key, values in groups.items():
        n = len(values); wins = sum(p > 0 for p, _ in values)
        positive = sum(p for p, _ in values if p > 0)
        negative = abs(sum(p for p, _ in values if p < 0))
        pf = positive / negative if negative else (99.0 if positive else None)
        expectancy = sum(p for p, _ in values) / n
        avg_return = sum(r for _, r in values) / n
        enough = n >= min_samples
        state = "REVIEWABLE" if enough and expectancy > 0 and (pf is None or pf > 1) else "COLLECTING" if not enough else "NO_POSITIVE_EDGE"
        # Sort key is descriptive, not a predictive score or authorization.
        ranked.append({"strategy": key[0], "symbol": key[1], "market": key[2],
            "timeframe": key[3], "side": key[4], "market_regime": key[5], "volatility_regime": key[6], "closed_trades": n,
            "wins": wins, "losses": n-wins, "win_rate_pct": round(wins/n*100, 2),
            "expectancy_usdt": round(expectancy, 8), "avg_return_pct": round(avg_return, 6),
            "profit_factor": round(pf, 6) if pf is not None else None,
            "total_net_pnl": round(sum(p for p, _ in values), 8), "learning_state": state,
            "ranking_score": round(expectancy * min(1.0, n/50.0), 8) if enough else None})
    ranked.sort(key=lambda x: (x["learning_state"] == "REVIEWABLE", x["ranking_score"] or float("-inf"), x["closed_trades"]), reverse=True)
    return {"groups": ranked, "group_count": len(ranked), "event_count": sum(len(v) for v in groups.values()),
            "min_samples": min_samples, "source": "REALIZED_CLOSED_PAPER_TRADES_ONLY",
            "regime_segmentation": "RECORDED_CONTEXT_ONLY",
            "volatility_segmentation": "RECORDED_LABEL_OR_ATR_PERCENT_AT_ENTRY_ONLY",
            "volatility_bands_atr_pct": {"LOW": "<1.0", "MEDIUM": "1.0-<3.0", "HIGH": ">=3.0"},
            "unknown_volatility_is_kept_separate": True,
            "unknown_regime_is_kept_separate": True,
            "ranking_is_profit_probability": False, "authorizes_entries": False,
            "real_orders_enabled": False}


def recommend_strategy_for_context(ranking: dict, *, symbol: str, market: str,
                                   timeframe: str, side: str, market_regime: str,
                                   volatility_regime: str, min_samples: int = 10) -> dict:
    """Read-only exact-context shortlist; never falls back across market conditions."""
    expected = {
        "symbol": str(symbol or "").upper().replace("/", "").strip(),
        "market": str(market or "").lower().strip(),
        "timeframe": str(timeframe or "").lower().strip(),
        "side": str(side or "").upper().strip(),
        "market_regime": str(market_regime or "UNKNOWN").upper().strip(),
        "volatility_regime": str(volatility_regime or "UNKNOWN").upper().strip(),
    }
    valid_regimes = {"BULLISH", "BEARISH", "RANGING", "UNKNOWN", "UPTREND", "DOWNTREND", "RANGE", "HIGH_VOLATILITY", "TRANSITION"}
    if expected["market"] not in {"spot", "perp"} or expected["side"] not in {"LONG", "SHORT"}:
        raise ValueError("market or side invalid")
    if expected["volatility_regime"] not in {"LOW", "MEDIUM", "HIGH", "UNKNOWN"}:
        raise ValueError("volatility_regime invalid")
    if expected["market_regime"] not in valid_regimes:
        raise ValueError("market_regime invalid")
    min_samples = max(1, min(500, int(min_samples)))
    matches = [g for g in (ranking or {}).get("groups", [])
               if all(g.get(k) == v for k, v in expected.items())]
    matches.sort(key=lambda g: (g.get("learning_state") == "REVIEWABLE",
                                g.get("ranking_score") if g.get("ranking_score") is not None else float("-inf"),
                                g.get("closed_trades", 0)), reverse=True)
    eligible = [g for g in matches if g.get("closed_trades", 0) >= min_samples
                and g.get("learning_state") == "REVIEWABLE"]
    return {"context": expected, "candidate_count": len(matches),
            "eligible_count": len(eligible), "min_samples": min_samples,
            "recommendation": eligible[0] if eligible else None,
            "state": "SHADOW_CANDIDATE" if eligible else "COLLECTING_EVIDENCE",
            "exact_context_only": True, "cross_regime_fallback": False,
            "authorizes_entries": False, "real_orders_enabled": False}
