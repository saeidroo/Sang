"""V21 — how much independent evidence does a training run really have?

Triple-barrier labels look TB_HORIZON bars ahead, so neighbouring rows share most of
their outcome. Real independent samples are ~ rows / horizon. With 3000 candles that is
~175 samples for 85 features: guaranteed over-fitting. This module reports that honestly
and caps the feature count so the model is not larger than its evidence.
"""
from __future__ import annotations

from .features import TB_HORIZON

TF_SECONDS = {'5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400, '1d': 86400}
MIN_FEATURES = 30
SAMPLES_PER_FEATURE = 3          # at least this many independent samples per kept feature
LABELED_FRAC = 0.80              # share of candles that end up with a usable label (estimate)
TRAIN_FRAC = 0.70                # temporal_split train fraction


def effective_samples(train_rows: int, horizon: int = TB_HORIZON) -> int:
    return max(0, int(train_rows) // max(1, int(horizon)))


def recommended_features(eff: int, max_features: int) -> int:
    """Largest feature count the evidence can support (bounded to [MIN_FEATURES, max])."""
    return int(max(MIN_FEATURES, min(int(max_features), int(eff) // SAMPLES_PER_FEATURE)))


def level_for(eff: int) -> tuple[str, str]:
    if eff < 150:
        return 'weak', 'ضعیف'
    if eff < 350:
        return 'medium', 'متوسط'
    if eff < 800:
        return 'good', 'خوب'
    return 'great', 'عالی'


def assess(limit: int, timeframe: str, max_features: int = 85, train_rows: int | None = None) -> dict:
    """Adequacy report from the candle count alone (UI) or from real train rows (trainer)."""
    sec = TF_SECONDS.get(timeframe, 3600)
    days = int(limit) * sec / 86400.0
    rows = int(train_rows) if train_rows is not None else int(int(limit) * LABELED_FRAC * TRAIN_FRAC)
    eff = effective_samples(rows)
    lvl, lvl_fa = level_for(eff)
    notes = []
    if days < 180:
        notes.append('کمتر از ۶ ماه داده؛ فقط یک رژیم بازار دیده می‌شود (روند/رنج/نوسان).')
    if lvl in ('weak', 'medium'):
        notes.append('نمونه‌ی مستقل کم است؛ برای نتیجه‌ی قابل‌اتکا کندل بیشتر (۱۰هزار+) بگیر.')
    return {'candles': int(limit), 'timeframe': timeframe, 'days': round(days, 1),
            'train_rows': rows, 'effective_samples': eff, 'level': lvl, 'level_fa': lvl_fa,
            'recommended_features': recommended_features(eff, max_features),
            'notes': notes}
