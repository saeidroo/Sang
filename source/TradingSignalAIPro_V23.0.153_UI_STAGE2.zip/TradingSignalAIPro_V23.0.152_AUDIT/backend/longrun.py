"""Unattended multi-hour training ("press one button and let it run").

What it does, in order, for every (market, timeframe) job — round-robin until the
time budget is used up or you press stop:

  1. Top up local candle history (public endpoints, NO API key). A source that does
     not answer is skipped quickly; a market that fails twice is dropped for the
     current pass — and RE-QUEUED when every other job has been processed, so a
     temporary internet drop no longer excludes markets for the rest of the run.
  2. Train with a randomised hyper-parameter search (every round uses a NEW random
     set, so hours of training keep exploring instead of repeating the same eight),
     5 walk-forward folds and a 3-seed final ensemble.
  3. Champion / challenger: the new model replaces the saved one only if it is not
     worse on bars that neither model has trained on. A bad round can never make a
     good model worse.
  4. AI coach (optional, V17.2): each finished round can be summarised to the
     configured LLM (default: Z.ai GLM) which returns short advice and safe
     hyper-parameter hints for the NEXT round of that market. Without an API key
     this step is silently skipped.

V17.2 — interruption-safe: the job table, counters and remaining time budget are
persisted after every round. Restarting the app no longer wipes hours of work:
``start(cfg, resume=True)`` (or the "ادامه‌ی آموزش نیمه‌کاره" button) restores
the previous run and continues where it stopped. Inside a single round the
trainer additionally checkpoints completed hyper-parameter trials, so a crash
mid-round does not redo the trials that already finished.

Nothing here can place orders. Results are research output, not a profit promise.
"""
from __future__ import annotations

import copy
import gc
import json
import re
import threading
import time
import traceback
import zlib
from collections import deque
from datetime import datetime
from pathlib import Path

ALLOWED_TFS = ('5m', '15m', '30m', '1h', '4h', '1d')
METALS = ('GOLD', 'SILVER', 'XAUUSD', 'XAGUSD', 'WTI', 'BRENT')
PRESETS = {
    'core5': ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT'],
    'top12': ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'ADAUSDT',
              'DOGEUSDT', 'LINKUSDT', 'AVAXUSDT', 'TRXUSDT', 'DOTUSDT', 'LTCUSDT'],
    'top12_metals': ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'ADAUSDT',
                     'DOGEUSDT', 'LINKUSDT', 'AVAXUSDT', 'TRXUSDT', 'DOTUSDT', 'LTCUSDT',
                     'GOLD', 'SILVER'],
    # V23.0.122: Saeed's requested seven-market research set (spot gold XAU/USD).
    'selected7': ['BTCUSDT', 'XAUUSD', 'ETHUSDT', 'DOGEUSDT', 'ICPUSDT', 'LINKUSDT', 'SOLUSDT'],
}
from .data import FUTURES_FAMOUS, is_futures_symbol  # V21
PRESETS['fut_core5'] = [x for x in FUTURES_FAMOUS if x[:-8] in ('BTC', 'ETH', 'SOL', 'BNB', 'XRP')]
PRESETS['fut_top12'] = FUTURES_FAMOUS[:12]
PRESETS['fut_all'] = list(FUTURES_FAMOUS)
MAX_FAILS = 2          # consecutive failures before a market is dropped for this pass
MAX_ROUNDS = 40        # safety cap of training rounds per market in one run
SYMBOL_RE = re.compile(r'^[A-Z0-9]{3,20}$')
RESUME_LOOKBACK_HOURS = 72   # a persisted run older than this is not resumable

_LOCK = threading.RLock()
_STOP = threading.Event()
_THREAD: threading.Thread | None = None
_LOG: deque = deque(maxlen=400)
_COACH_LOG: deque = deque(maxlen=40)
_STATE: dict = {
    'running': False, 'phase': 'idle', 'message': 'آماده', 'started_at': None,
    'deadline_ts': None, 'finished_at': None, 'hours': 0, 'config': None,
    'jobs': [], 'current': None, 'rounds_done': 0, 'trainings_done': 0,
    'promoted': 0, 'kept_old': 0, 'failed': 0, 'resumed_from': None,
    'run_id': None, 'coach_log': [],
}


# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------
def _log(msg: str):
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    with _LOCK:
        _LOG.append(line)
    print('[longrun]', msg, flush=True)


def _state_file() -> Path:
    from .storage import get_models_dir
    return get_models_dir() / 'longrun_state.json'


def _persist():
    """Write a compact summary so the result survives a restart/crash."""
    try:
        with _LOCK:
            snap = _public_state()
        tmp = _state_file().with_suffix('.tmp')
        tmp.write_text(json.dumps(snap, ensure_ascii=False, indent=1, default=str), encoding='utf-8')
        tmp.replace(_state_file())
    except Exception:
        pass


def _public_state() -> dict:
    s = copy.deepcopy(_STATE)
    s['log'] = list(_LOG)[-120:]
    s['coach_log'] = list(_COACH_LOG)[-40:]
    now = time.time()
    if s.get('deadline_ts'):
        s['remaining_sec'] = max(0, int(s['deadline_ts'] - now)) if s['running'] else 0
    s['elapsed_sec'] = int(now - s['started_at']) if (s.get('started_at') and s['running']) else s.get('elapsed_sec', 0)
    return s


def resumable() -> dict | None:
    """Describe the last interrupted run, if it can be resumed (for the UI)."""
    try:
        saved = json.loads(_state_file().read_text(encoding='utf-8'))
    except Exception:
        return None
    jobs = saved.get('jobs') or []
    if not jobs or not isinstance(saved.get('config'), dict):
        return None
    started_at = saved.get('started_at')
    if not started_at or time.time() - float(started_at) > RESUME_LOOKBACK_HOURS * 3600:
        return None
    if saved.get('running'):
        saved['running'] = False
        if saved.get('phase') == 'running':
            saved['phase'] = 'interrupted'
    remaining = max(0, int(float(saved.get('deadline_ts') or 0) - time.time()))
    done = sum(1 for j in jobs if j.get('status') in ('trained', 'dropped'))
    return {
        'resumable': True,
        'run_id': saved.get('run_id'),
        'phase': saved.get('phase'),
        'config': saved.get('config'),
        # full per-job progress so start(resume=True) can restore rounds/fails
        'jobs': jobs,
        'trainings_done': saved.get('trainings_done', 0),
        'promoted': saved.get('promoted', 0),
        'kept_old': saved.get('kept_old', 0),
        'deadline_ts': saved.get('deadline_ts'),
        'jobs_total': len(jobs),
        'jobs_done': done,
        'rounds_done': saved.get('rounds_done', 0),
        'remaining_sec': remaining,
        'started_at': started_at,
        'interrupted': saved.get('phase') == 'interrupted',
        'message': ('اجرای قبلی نیمه‌کاره قطع شده است و می‌توانی ادامه‌اش بدهی.'
                    if saved.get('phase') == 'interrupted'
                    else 'اجرای قبلی کامل/متوقف شده است؛ ادامه دادن دورهای جدید ممکن است.'),
    }


def multihour_symbols() -> set:
    """V21: markets owned by the multi-hour trainer (running now, or last run < 72h ago).

    Single training ("یادگیری تکی") is reserved for NEW coins the user wants to peek at;
    anything listed here is trained by the multi-hour run instead.
    """
    with _LOCK:
        cfg = copy.deepcopy(_STATE.get('config'))
        running = bool(_STATE.get('running'))
        started = _STATE.get('started_at')
    fresh = bool(started) and (time.time() - float(started) <= RESUME_LOOKBACK_HOURS * 3600)
    if isinstance(cfg, dict) and cfg.get('symbols') and (running or fresh):
        return {str(x).upper() for x in cfg['symbols']}
    saved = resumable()
    if saved and isinstance(saved.get('config'), dict):
        return {str(x).upper() for x in (saved['config'].get('symbols') or [])}
    return set()


def status() -> dict:
    with _LOCK:
        if _STATE['started_at'] is None and not _STATE['running']:
            # nothing ran in this process: show the last persisted run, if any
            try:
                saved = json.loads(_state_file().read_text(encoding='utf-8'))
                saved['running'] = False
                if saved.get('phase') == 'running':
                    saved['phase'] = 'interrupted'
                    saved['message'] = 'اجرای قبلی نیمه‌کاره متوقف شده بود (برنامه بسته شده یا خطا رخ داده). با دکمه‌ی «ادامه آموزش» از همان‌جا ادامه بده.'
                saved['resumable_info'] = resumable()
                return saved
            except Exception:
                pass
        return _public_state()


def normalize_config(cfg: dict | None) -> dict:
    """Validate user input; raise ValueError with a Persian message."""
    cfg = dict(cfg or {})
    try:
        hours = float(cfg.get('hours', 8))
    except (TypeError, ValueError):
        raise ValueError('مدت آموزش نامعتبر است')
    if not 0.05 <= hours <= 72:
        raise ValueError('مدت آموزش باید بین ۳ دقیقه و ۷۲ ساعت باشد')
    symbols = cfg.get('symbols')
    if not symbols:
        symbols = PRESETS.get(str(cfg.get('preset', 'core5')), PRESETS['core5'])
    if not isinstance(symbols, (list, tuple)) or not 1 <= len(symbols) <= 60:
        raise ValueError('فهرست نمادها باید ۱ تا ۶۰ مورد باشد')
    symbols = [str(x).upper().strip() for x in symbols]
    for sym in symbols:
        if not (SYMBOL_RE.match(sym) or sym in METALS):
            raise ValueError(f'نماد نامعتبر: {sym}')
    symbols = list(dict.fromkeys(symbols))
    tfs = cfg.get('timeframes') or ['1h', '4h']
    if not isinstance(tfs, (list, tuple)) or not tfs or any(t not in ALLOWED_TFS for t in tfs):
        raise ValueError('تایم‌فریم‌ها نامعتبرند')
    tfs = list(dict.fromkeys(tfs))
    try:
        limit = int(cfg.get('limit', 10000))   # V21: more history = more independent samples
        trials = int(cfg.get('trials', 24))
    except (TypeError, ValueError):
        raise ValueError('تعداد کندل یا آزمون نامعتبر است')
    if not 1000 <= limit <= 50000:
        raise ValueError('تعداد کندل آموزش باید بین ۱۰۰۰ تا ۵۰۰۰۰ باشد')
    if not 8 <= trials <= 60:
        raise ValueError('تعداد آزمون ابرپارامتر باید بین ۸ تا ۶۰ باشد')
    return {'hours': hours, 'symbols': symbols, 'timeframes': tfs, 'limit': limit,
            'trials': trials, 'max_rounds': max(1, min(200, int(cfg.get('max_rounds', MAX_ROUNDS))))}


def _estimate_job_seconds(limit: int, trials: int) -> int:
    """Rough first guess before any job has been timed (refined after job #1)."""
    from .trainer import estimate_train_time
    base = estimate_train_time(limit)
    return int(base * (0.6 + 0.2 * trials / 8))


# ----------------------------------------------------------------------------
# data acquisition: archive first, public live sources second, cache last
# ----------------------------------------------------------------------------
def acquire_candles(symbol: str, timeframe: str, limit: int, log=_log):
    """Return (DataFrame, source_name). Raises RuntimeError when nothing worked."""
    from . import data as data_mod
    errors = []
    # V21: the local archive holds SPOT candles only; never mix them into a futures market.
    if symbol not in METALS and not is_futures_symbol(symbol):
        try:
            from .historical import ensure_recent_history, history_bounds
            ensure_recent_history(symbol, timeframe, limit)
            have = history_bounds(symbol, timeframe)['count']
            if have >= max(900, int(limit * 0.6)):
                df = data_mod.fetch_candles(symbol, timeframe, limit=min(limit, 100000), source='history')
                return df, 'history'
        except Exception as exc:  # fail soft: try live sources next
            errors.append(f'archive: {exc}')
    try:
        df = data_mod.fetch_candles(symbol, timeframe, limit=min(limit, 10000), source='auto')
        return df, df.attrs.get('source', 'auto')
    except Exception as exc:
        errors.append(str(exc)[:300])
    raise RuntimeError(' | '.join(errors) or 'no data')


# ----------------------------------------------------------------------------
# the worker
# ----------------------------------------------------------------------------
def _pick_job(jobs: list, max_rounds: int):
    eligible = [j for j in jobs if j['status'] != 'dropped' and j['rounds'] < max_rounds]
    if not eligible:
        return None
    return min(eligible, key=lambda j: (j['rounds'], j['last_end_ts'] or 0))


def _requeue_dropped(jobs: list, max_rounds: int) -> bool:
    """Give dropped markets another chance once every other job was processed.

    A two-failure drop was meant for *temporary* outages inside one pass; for a
    multi-hour (or 24h) run it permanently excluded markets after a short
    internet cut. Re-queueing keeps the run useful while the per-market
    ``max_rounds`` cap still bounds the total work.
    """
    retryable = [j for j in jobs if j['status'] == 'dropped' and j['rounds'] < max_rounds]
    if not retryable:
        return False
    for j in retryable:
        j['status'] = 'queued'
        j['fails'] = 0
    _log(f'↻ {len(retryable)} بازارِ قبلاً ناموفق دوباره به صف برگشت (احتمال برگشتن شبکه/منبع).')
    return True


def _plain(obj):
    """Make numpy scalars JSON-safe (np.int64 would break jsonify)."""
    return json.loads(json.dumps(obj, default=lambda o: o.item() if hasattr(o, 'item') else str(o)))


def _summarise(session_result: dict | None) -> dict:
    meta = (session_result or {}).get('meta') or {}
    sim = meta.get('sim_test') or {}
    gate = meta.get('gate_info') or {}
    return _plain({
        'val_acc': meta.get('val_acc'), 'balanced_acc': meta.get('balanced_acc'),
        'walk_forward_acc': meta.get('walk_forward_acc'),
        'edge_confirmed': meta.get('edge_confirmed'), 'best_threshold': meta.get('best_threshold'),
        'sim_win_rate': sim.get('win_rate'), 'sim_trades': sim.get('n_trades'),
        'sim_expectancy_pct': sim.get('expectancy_pct'),
        'promoted': meta.get('promoted', True), 'gate_message': gate.get('message'),
        'training_round': meta.get('training_round'), 'trials': meta.get('iterations'),
        'seconds': meta.get('training_time_sec'), 'data_points': meta.get('data_points'),
        'best_params': meta.get('best_params'),
    })


def _coach_round(job: dict, cfg: dict, summ: dict) -> None:
    """Ask the configured LLM for advice + next-round hints (optional, fail-soft)."""
    try:
        from . import ai_coach
        info = ai_coach.coach_available()
        with _LOCK:
            _STATE['coach_available'] = info['available']
        if not info['available']:
            return
        payload = {
            'symbol': job['symbol'], 'timeframe': job['timeframe'],
            'round': job['rounds'],
            'balanced_acc': summ.get('balanced_acc'), 'val_acc': summ.get('val_acc'),
            'walk_forward_acc': summ.get('walk_forward_acc'),
            'edge_confirmed': summ.get('edge_confirmed'),
            'best_threshold': summ.get('best_threshold'),
            'sim_test': {'win_rate': summ.get('sim_win_rate'),
                         'n_trades': summ.get('sim_trades'),
                         'expectancy_pct': summ.get('sim_expectancy_pct')},
            'promoted': summ.get('promoted'),
            'best_params': summ.get('best_params'),
            'note': 'financial labels are noisy; keep hints inside safe bounds',
        }
        reply = ai_coach.ask_coach(payload, log=_log)
        if not reply.get('available'):
            return
        entry = {
            'ts': time.time(), 'symbol': job['symbol'], 'timeframe': job['timeframe'],
            'model': reply.get('model'),
            'assessment_fa': reply.get('assessment_fa'),
            'verdict': reply.get('verdict'),
            'advice_fa': reply.get('advice_fa'),
            'hp_hints': reply.get('hp_hints'),
        }
        with _LOCK:
            _COACH_LOG.append(entry)
        job['coach_hints'] = [reply['hp_hints']] if reply.get('hp_hints') else []
        verdict_fa = {'keep': 'ادامه با همین تنظیمات', 'explore': 'کاوش بیشتر',
                      'tighten': 'سخت‌گیرانه‌تر'}.get(reply.get('verdict'), reply.get('verdict') or '')
        _log(f"🤖 مربی AI ({entry['model']}): {reply.get('assessment_fa') or ''}"
             + (f" | راهنما: {reply.get('advice_fa')}" if reply.get('advice_fa') else '')
             + (f" | تنظیم پیشنهادی دور بعد ثبت شد ({verdict_fa})" if job['coach_hints'] else ''))
    except Exception as exc:
        _log(f'⚠ مربی AI خطا داد (بی‌اثر بر آموزش): {str(exc)[:160]}')


def _run_one(job: dict, cfg: dict, session) -> None:
    from .trainer import make_hp_grid
    sym, tf = job['symbol'], job['timeframe']
    seed = job['rounds'] + 1
    with _LOCK:
        _STATE['current'] = {'symbol': sym, 'timeframe': tf, 'round': seed, 'stage': 'data',
                             'started_at': time.time()}
    _log(f'▶ {sym} {tf} — دور {seed}: دریافت داده…')
    df, src = acquire_candles(sym, tf, cfg['limit'])
    with _LOCK:
        if _STATE['current']:
            _STATE['current']['stage'] = 'training'
    _log(f'   داده: {len(df)} کندل از «{src}» — شروع آموزش ({cfg["trials"]} آزمون)')

    # a manual training could be running; wait briefly instead of crashing
    waited = 0
    while session.is_running and waited < 120 and not _STOP.is_set():
        time.sleep(2)
        waited += 2
    if _STOP.is_set():
        return
    if session.is_running:
        raise RuntimeError('آموزش قبلی پس از ۱۲۰ ثانیه هنوز فعال است؛ برای جلوگیری از اجرای هم‌زمان، این دور لغو شد.')
    # coach hints from the previous round go first (they are already sanitized
    # into the safe region by ai_coach.sanitize_hint)
    hints = [copy.deepcopy(h) for h in (job.get('coach_hints') or []) if h][:2]
    grid = make_hp_grid(cfg['trials'], seed=seed + 101 * (zlib.crc32(sym.encode()) % 97))
    if hints:
        grid = (hints + grid)[:cfg['trials']]
        _log(f'   💡 {len(hints)} پیکربندی پیشنهادیِ مربی AI ابتدای شبکه‌ی این دور گذاشته شد.')
    result = session.run(symbol=sym, timeframe=tf, limit=min(cfg['limit'], len(df)), source=src,
                         df=df, hp_grid=grid, n_folds=5, n_seeds=3, gate=True)
    summ = _summarise(result)
    job.update(last=summ, source=src)
    with _LOCK:
        _STATE['trainings_done'] += 1
        if summ.get('promoted'):
            _STATE['promoted'] += 1
        else:
            _STATE['kept_old'] += 1
    acc = (summ.get('balanced_acc') or 0) * 100
    edge = 'برتری تأیید شد ✓' if summ.get('edge_confirmed') else 'بدون برتری تأییدشده'
    verdict = 'ذخیره شد' if summ.get('promoted') else 'مدل قبلی نگه داشته شد'
    _log(f'✓ {sym} {tf}: دقت متوازن تست {acc:.1f}٪ | {edge} | {verdict}')
    # optional AI-coach review of the finished round (no API key -> skipped)
    _coach_round(job, cfg, summ)


def _worker(cfg: dict, resume_state: dict | None = None):
    from .trainer import get_session
    session = get_session()
    t0 = time.time()
    jobs = [{'symbol': s, 'timeframe': tf, 'rounds': 0, 'fails': 0, 'status': 'queued',
             'last_end_ts': None, 'last': None, 'error': None, 'coach_hints': None}
            for tf in cfg['timeframes'] for s in cfg['symbols']]
    deadline = t0 + cfg['hours'] * 3600
    counters = {'trainings_done': 0, 'promoted': 0, 'kept_old': 0, 'failed': 0}
    resumed_from = None
    if resume_state:
        old_jobs = resume_state.get('jobs') or []
        old_map = {(j.get('symbol'), j.get('timeframe')): j for j in old_jobs if isinstance(j, dict)}
        for job in jobs:
            old = old_map.get((job['symbol'], job['timeframe']))
            if not old:
                continue
            job['rounds'] = int(old.get('rounds') or 0)
            job['fails'] = 0                      # fresh process: allow 2 fresh attempts
            job['last'] = old.get('last')
            job['error'] = old.get('error')
            job['coach_hints'] = old.get('coach_hints')
            if job['rounds'] > 0 and job['status'] == 'queued':
                job['status'] = 'queued'
        counters['trainings_done'] = int(resume_state.get('trainings_done') or 0)
        counters['promoted'] = int(resume_state.get('promoted') or 0)
        counters['kept_old'] = int(resume_state.get('kept_old') or 0)
        counters['failed'] = 0                    # failures are per-process diagnostics
        old_deadline = float(resume_state.get('deadline_ts') or 0)
        remaining = old_deadline - t0
        if remaining > 300:
            deadline = t0 + remaining             # continue the same time budget
        resumed_from = {'trainings_done': counters['trainings_done'],
                        'remaining_sec': max(0, int(remaining)) if remaining > 0 else 0}
    with _LOCK:
        _STATE.update(running=True, phase='running', started_at=t0, deadline_ts=deadline,
                      finished_at=None, hours=(deadline - t0) / 3600, config=cfg, jobs=jobs,
                      current=None, rounds_done=sum(j['rounds'] for j in jobs),
                      resumed_from=resumed_from, coach_available=False,
                      run_id=time.strftime('%Y%m%d-%H%M%S'))
        _STATE.update(trainings_done=counters['trainings_done'],
                      promoted=counters['promoted'], kept_old=counters['kept_old'],
                      failed=counters['failed'])
    _persist()
    _LOG.clear()
    if resumed_from:
        _log(f'↩ ادامه‌ی اجرای قبلی: {resumed_from["trainings_done"]} آموزش انجام‌شده بازیابی شد؛ '
             f'{resumed_from["remaining_sec"] // 60} دقیقه از بودجه‌ی زمانی باقی مانده است.')
    else:
        _log(f'شروع: {len(jobs)} کار ({len(cfg["symbols"])} نماد × {len(cfg["timeframes"])} تایم‌فریم) '
             f'برای حداکثر {cfg["hours"]:g} ساعت')
    avg_job = _estimate_job_seconds(cfg['limit'], cfg['trials'])
    durations = []
    end_reason = 'complete'
    try:
        while not _STOP.is_set():
            job = _pick_job(jobs, cfg['max_rounds'])
            if job is None:
                # every job hit its round cap? then stop; otherwise give the
                # dropped markets another try (temporary outage recovery)
                if _requeue_dropped(jobs, cfg['max_rounds']):
                    continue
                end_reason = 'all_done'
                break
            remaining = deadline - time.time()
            if remaining <= 0:
                end_reason = 'time_up'
                break
            if remaining < avg_job * 0.5:
                _log('زمان باقی‌مانده برای یک دور آموزش کامل کافی نیست؛ پایان.')
                end_reason = 'time_up'
                break
            job['status'] = 'running'
            ts = time.time()
            try:
                _run_one(job, cfg, session)
                job['fails'] = 0
                job['error'] = None
                job['status'] = 'trained'
            except Exception as exc:
                if _STOP.is_set():
                    break
                job['fails'] += 1
                job['error'] = str(exc)[:300]
                with _LOCK:
                    _STATE['failed'] += 1
                _log(f'✖ {job["symbol"]} {job["timeframe"]}: {str(exc)[:160]}')
                if job['fails'] >= MAX_FAILS:
                    job['status'] = 'dropped'
                    _log(f'   ⏭ {job["symbol"]} {job["timeframe"]} پاسخ نداد/ناموفق بود — فعلاً کنار گذاشته شد (پس از یک دور کامل، دوباره امتحان می‌شود).')
                else:
                    job['status'] = 'queued'
            finally:
                job['rounds'] += 1
                job['last_end_ts'] = time.time()
                dur = time.time() - ts
                if job['status'] != 'dropped' and not job['error']:
                    durations.append(dur)
                    avg_job = sum(durations[-6:]) / len(durations[-6:])
                with _LOCK:
                    _STATE['current'] = None
                    _STATE['rounds_done'] = sum(j['rounds'] for j in jobs)
                _persist()
                gc.collect()
            time.sleep(2)
    except Exception as exc:  # never let the worker die silently
        _log(f'خطای غیرمنتظره: {exc}')
        _log(traceback.format_exc()[-1500:])
        end_reason = 'error'
    finally:
        stopped = _STOP.is_set()
        msgs = {
            'all_done': 'همه‌ی دورهای برنامه‌ریزی‌شده انجام شد.',
            'time_up': 'زمان تعیین‌شده تمام شد.',
            'error': 'با خطا متوقف شد؛ گزارش را ببین.', 'complete': 'تمام شد.'}
        with _LOCK:
            _STATE.update(running=False, phase='stopped' if stopped else 'finished',
                          finished_at=time.time(), current=None,
                          elapsed_sec=int(time.time() - t0),
                          message='با درخواست شما متوقف شد.' if stopped else msgs.get(end_reason, 'تمام شد.'))
        _log(_STATE['message'])
        _persist()


# ----------------------------------------------------------------------------
# public control API
# ----------------------------------------------------------------------------
def start(cfg: dict | None = None, resume: bool = False) -> dict:
    """Start the run in a background thread. Raises ValueError (bad config) or
    RuntimeError (something else is already training).

    resume=True continues the last persisted run: finished rounds and the
    remaining time budget are restored instead of starting from zero.
    """
    global _THREAD
    config = normalize_config(cfg)
    from .trainer import get_session
    restore_state = None
    if resume:
        restore_state = resumable()
        if restore_state is None:
            _log('درخواست ادامه دادن، اما اجرای قابل بازیابی‌ای پیدا نشد؛ آموزش تازه شروع می‌شود.')
        elif not restore_state.get('remaining_sec'):
            # time budget fully used: keep progress, start a new window
            _log('بودجه‌ی زمانی اجرای قبلی تمام شده بود؛ پیشرفت بازیابی و پنجره‌ی زمانی جدید باز می‌شود.')
        if restore_state and restore_state.get('jobs'):
            # V20: the UI no longer pre-selects timeframes/symbols, so a resume
            # from a fresh page would otherwise silently continue only the
            # markets the user happens to tick now. Union the old run's markets
            # with anything the user explicitly picked this time.
            old_syms = {j.get('symbol') for j in restore_state['jobs']
                        if isinstance(j, dict) and j.get('symbol')}
            old_tfs = {j.get('timeframe') for j in restore_state['jobs']
                       if isinstance(j, dict) and j.get('timeframe')}
            merged_syms = list(dict.fromkeys(list(config['symbols']) + sorted(old_syms)))[:60]
            merged_tfs = [t for t in ['5m', '15m', '30m', '1h', '4h', '1d']
                          if t in ({*config['timeframes'], *old_tfs})]
            if merged_syms != config['symbols'] or merged_tfs != config['timeframes']:
                _log('↩ نمادها/تایم‌فریم‌های اجرای قبلی هم به صف ادامه اضافه شدند.')
            config['symbols'] = merged_syms
            config['timeframes'] = merged_tfs
    with _LOCK:
        if _STATE['running']:
            raise RuntimeError('آموزش خودکار چندساعته از قبل در حال اجراست')
        if get_session().is_running:
            raise RuntimeError('یک آموزش دستی در حال اجراست؛ صبر کن تمام شود یا آن را متوقف کن')
        _STOP.clear()
        _STATE['running'] = True  # reserve before the thread starts
        _STATE['started_at'] = time.time()
    _THREAD = threading.Thread(target=_worker, args=(config, restore_state),
                               daemon=True, name='longrun-worker')
    _THREAD.start()
    return config


def stop() -> bool:
    _STOP.set()
    try:
        from .trainer import get_session
        sess = get_session()
        if sess.is_running:
            sess.cancel = True
    except Exception:
        pass
    return True


def config_from_env(env=None) -> dict:
    """Build a config from the same environment variables the .bat launcher sets."""
    import os
    env = env or os.environ
    syms = [x.strip().upper() for x in env.get('AUTO_RETRAIN_SYMBOLS', '').split(',') if x.strip()]
    syms = [x for x in syms if x not in ('ALL', 'ALL_USDT', 'ALL_CRYPTO')] or None
    tfs = [x.strip() for x in env.get('AUTO_RETRAIN_TFS', '1h,4h').split(',') if x.strip()]
    return {'hours': float(env.get('AUTO_RETRAIN_DURATION_HOURS', '8') or 8),
            'symbols': syms, 'preset': env.get('AUTO_RETRAIN_PRESET', 'core5'),
            'timeframes': tfs, 'limit': int(env.get('AUTO_RETRAIN_LIMIT', '10000')),
            'trials': int(env.get('AUTO_RETRAIN_TRIALS', '24'))}
