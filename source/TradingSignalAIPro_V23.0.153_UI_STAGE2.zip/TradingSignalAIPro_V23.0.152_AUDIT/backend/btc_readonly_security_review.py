"""Static security review and manual acceptance record for BTC 4h read-only pilot code."""
from __future__ import annotations
import hashlib, json, os, re
from datetime import datetime, timezone
from pathlib import Path

MODULES=(
 'backend/btc_live_readonly.py','backend/btc_cross_source_readonly.py',
 'backend/btc_live_snapshot.py','backend/btc_live_drift_monitor.py',
 'backend/btc_live_observability.py','backend/btc_readonly_pilot_gate.py',
 'backend/btc_readonly_pilot_exit.py','backend/btc_source_failover_gate.py',
 'backend/btc_readonly_review_bundle.py')
FORBIDDEN=(r'create_order\s*\(',r'cancel_order\s*\(',r'new_order\s*\(',
           r'/api/v3/order',r'/api/v5/trade/order',r'api_secret\s*=')
SECRET_MARKERS=('-----BEGIN PRIVATE KEY-----','-----BEGIN RSA PRIVATE KEY-----','api_secret =','secret_key =')


def _canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def _sha(value): return hashlib.sha256(_canonical(value)).hexdigest()


def evaluate_readonly_security_review(*, project_root):
    root=Path(project_root).expanduser().resolve(); findings=[]; inventory=[]
    for relative in MODULES:
        path=root/relative
        if not path.is_file():
            findings.append({'severity':'ERROR','code':'readonly_module_missing','path':relative}); continue
        raw=path.read_bytes(); text=raw.decode('utf-8',errors='replace')
        inventory.append({'path':relative,'sha256':hashlib.sha256(raw).hexdigest()})
        for pattern in FORBIDDEN:
            if re.search(pattern,text,re.I):
                findings.append({'severity':'ERROR','code':'forbidden_order_or_secret_pattern','path':relative,'pattern':pattern})
        if 'https://' not in text and 'urllib' in text:
            findings.append({'severity':'WARNING','code':'https_endpoint_not_obvious','path':relative})
        for marker in SECRET_MARKERS:
            if marker in text:
                findings.append({'severity':'ERROR','code':'embedded_secret_marker','path':relative})
    status='PASS' if not any(x['severity']=='ERROR' for x in findings) else 'BLOCKED'
    report={'schema_version':'btc-4h-readonly-security-review-v1','status':status,
        'created_at_utc':datetime.now(timezone.utc).isoformat(),'modules_reviewed':len(inventory),
        'inventory':inventory,'findings':findings,'training_allowed':False,'live_orders':False,
        'scope':'static_review_of_readonly_pilot_modules_not_full_penetration_test'}
    report['report_sha256']=_sha(report)
    return report


def record_readonly_operator_acceptance(review_report: dict, *, decision, output_path):
    if not isinstance(review_report,dict) or review_report.get('schema_version')!='btc-4h-readonly-security-review-v1':
        raise ValueError('readonly_security_review_invalid')
    body=dict(review_report); declared=body.pop('report_sha256',None)
    if not declared or _sha(body)!=declared: raise ValueError('readonly_security_review_hash_mismatch')
    if review_report.get('status')!='PASS' and decision=='ACCEPT_READONLY':
        raise ValueError('readonly_security_review_blocked')
    if decision not in ('ACCEPT_READONLY','REJECT'):
        raise ValueError('readonly_operator_decision_invalid')
    acceptance={'schema_version':'btc-4h-readonly-operator-acceptance-v1',
        'decision':decision,'review_report_sha256':declared,
        'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'training_allowed':False,'live_orders':False,
        'scope':'read_only_pilot_only_no_training_or_order_execution'}
    acceptance['acceptance_sha256']=_sha(acceptance)
    path=Path(output_path).expanduser(); path.parent.mkdir(parents=True,exist_ok=True)
    raw=_canonical(acceptance)+b'\n'; fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as stream: stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    return {'saved':True,'path':str(path),'decision':decision,'acceptance_sha256':acceptance['acceptance_sha256']}
