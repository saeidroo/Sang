"""V22.3c causal BTC 4h feature and forward-label construction.

Features at row t use only OHLCV observations at or before t. Labels are
forward-looking by design and must never be passed to a model as features.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

VERSION = 'btc-4h-causal-features-labels-v1'
FEATURE_COLUMNS = (
    'log_return_1', 'log_return_3', 'log_return_6',
    'volatility_6', 'volatility_24', 'rsi_14',
    'ema_distance_12', 'ema_distance_26', 'macd', 'macd_signal',
    'atr_14_pct', 'volume_zscore_24', 'candle_body_pct',
    'candle_range_pct', 'upper_wick_pct', 'lower_wick_pct',
)


def build_btc_4h_features(candles, *, timestamp='t', volatility_windows=(6, 24),
                          volume_window=24):
    """Return a copy with strictly causal features; warmup rows remain NaN."""
    df = pd.DataFrame(candles).copy()
    required = [timestamp, 'open', 'high', 'low', 'close', 'volume']
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError('missing required columns: ' + ','.join(missing))
    for col in required:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    if df[required].isna().any().any():
        raise ValueError('timestamps and OHLCV must be numeric and non-null')
    if not np.isfinite(df[['open','high','low','close','volume']].to_numpy(float)).all():
        raise ValueError('OHLCV contains non-finite values')
    if (df[['open','high','low','close']].to_numpy(float) <= 0).any() or (df['volume'] < 0).any():
        raise ValueError('prices must be positive and volume non-negative')
    if df[timestamp].duplicated().any() or not df[timestamp].is_monotonic_increasing:
        raise ValueError('timestamps must be unique and chronological')

    o, h, l, c, v = (df[x].astype(float) for x in ('open','high','low','close','volume'))
    logc = np.log(c)
    out = pd.DataFrame(index=df.index)
    out['log_return_1'] = logc.diff(1)
    out['log_return_3'] = logc.diff(3)
    out['log_return_6'] = logc.diff(6)
    for w in volatility_windows:
        if int(w) < 2: raise ValueError('volatility windows must be >=2')
        out[f'volatility_{int(w)}'] = out['log_return_1'].rolling(int(w), min_periods=int(w)).std(ddof=0)

    delta = c.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False, min_periods=14).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False, min_periods=14).mean()
    rs = gain / loss.replace(0, np.nan)
    rsi = 100 - 100 / (1 + rs)
    rsi = rsi.mask((loss == 0) & (gain > 0), 100.0)
    rsi = rsi.mask((gain == 0) & (loss == 0), 50.0)
    out['rsi_14'] = rsi

    ema12 = c.ewm(span=12, adjust=False, min_periods=12).mean()
    ema26 = c.ewm(span=26, adjust=False, min_periods=26).mean()
    macd = ema12 - ema26
    signal = macd.ewm(span=9, adjust=False, min_periods=9).mean()
    out['ema_distance_12'] = c / ema12 - 1
    out['ema_distance_26'] = c / ema26 - 1
    out['macd'] = macd / c
    out['macd_signal'] = signal / c

    prev_close = c.shift(1)
    tr = pd.concat([(h-l), (h-prev_close).abs(), (l-prev_close).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1/14, adjust=False, min_periods=14).mean()
    out['atr_14_pct'] = atr / c

    vmean = v.rolling(int(volume_window), min_periods=int(volume_window)).mean()
    vstd = v.rolling(int(volume_window), min_periods=int(volume_window)).std(ddof=0)
    out['volume_zscore_24'] = (v-vmean) / vstd.replace(0, np.nan)
    out['candle_body_pct'] = (c-o) / o
    out['candle_range_pct'] = (h-l) / c
    out['upper_wick_pct'] = (h - pd.concat([o,c], axis=1).max(axis=1)) / c
    out['lower_wick_pct'] = (pd.concat([o,c], axis=1).min(axis=1) - l) / c

    for col in out.columns:
        vals = out[col].to_numpy(dtype=float)
        if np.isinf(vals).any():
            raise ValueError(f'infinite feature values in {col}')
    result = df.copy()
    for col in out.columns: result[col] = out[col]
    result.attrs['feature_version'] = VERSION
    result.attrs['feature_columns'] = list(out.columns)
    result.attrs['causality'] = 'rolling/ewm use current and past rows only; no centered windows or backfill'
    return result


def build_direction_labels(candles, *, horizon_bars=6, threshold=0.002,
                           round_trip_cost=0.001, timestamp='t', drop_unlabelled=True):
    """Create 3-class labels from close[t+h]/close[t]-1 and label end positions.

    y=1 up, y=-1 down, y=0 neutral. Threshold is a minimum gross move;
    round_trip_cost is added to the hurdle on either side.
    """
    df = pd.DataFrame(candles).copy()
    h = int(horizon_bars); threshold = float(threshold); cost = float(round_trip_cost)
    if h < 1 or threshold < 0 or cost < 0:
        raise ValueError('horizon must be >=1 and thresholds/costs non-negative')
    if 'close' not in df: raise ValueError('close column missing')
    close = pd.to_numeric(df['close'], errors='coerce').astype(float)
    if close.isna().any() or not np.isfinite(close.to_numpy()).all() or (close <= 0).any():
        raise ValueError('close must contain finite positive values')
    n = len(df); pos = np.arange(n, dtype=int); end = pos + h
    future = close.shift(-h)
    ret = future / close - 1.0
    hurdle = threshold + cost
    label = np.where(ret > hurdle, 1, np.where(ret < -hurdle, -1, 0)).astype(float)
    valid = end < n
    label[~valid] = np.nan
    df['forward_return'] = ret
    df['label'] = label
    df['label_end_pos'] = np.where(valid, end, -1).astype(int)
    if timestamp in df.columns:
        df['label_end_t'] = df[timestamp].shift(-h)
    else:
        df['label_end_t'] = pd.Series([None] * n, index=df.index, dtype=object)
    df['label_valid'] = valid
    df.attrs['label_version'] = VERSION
    df.attrs['label_config'] = {'horizon_bars': h, 'threshold': threshold,
                                'round_trip_cost': cost, 'classes': {'down':-1,'neutral':0,'up':1}}
    if drop_unlabelled:
        df = df.loc[valid].copy()
    return df


def purge_training_indices(train_indices, label_end_positions, *, validation_start,
                            embargo_bars=0):
    """Actually remove training samples whose label interval reaches the embargo cutoff."""
    idx = np.asarray(train_indices, dtype=int)
    ends = np.asarray(label_end_positions, dtype=int)
    if idx.ndim != 1 or ends.ndim != 1 or (idx < 0).any() or (idx >= len(ends)).any():
        raise ValueError('invalid train indices or label end positions')
    if embargo_bars < 0 or validation_start < 0: raise ValueError('negative boundary/embargo')
    cutoff = int(validation_start) - int(embargo_bars)
    keep = idx[(ends[idx] >= 0) & (ends[idx] < cutoff)]
    removed = np.setdiff1d(idx, keep, assume_unique=False)
    return {'train_indices': keep.tolist(), 'purged_indices': removed.tolist(),
            'purged_count': int(len(removed)), 'cutoff_exclusive': cutoff,
            'max_kept_label_end_pos': int(ends[keep].max()) if len(keep) else None}
