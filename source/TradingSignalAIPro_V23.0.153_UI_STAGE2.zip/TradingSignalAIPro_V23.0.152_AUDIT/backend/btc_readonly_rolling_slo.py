"""Rolling reliability/SLO review for repeated read-only BTC 4h validations."""
from __future__ import annotations
import hashlib
from datetime import datetime, timezone
from backend.btc_live_environment_validation import _canonical
from backend.btc_live_validation_review import verify_live_validation_evidence, _parse_utc


def build_readonly_rolling_slo(reports, *, min_reports=10, operator_approved=False,
        min_source_availability=0.98, min_cross_source_agreement=0.99,
        min_validation_pass_rate=0.95, max_candle_age_hours=8,
        now_utc=None):
    if not isinstance(reports,(list,tuple)) or not reports:
        raise ValueError('rolling_slo_reports_required')
    if isinstance(min_reports,bool) or not isinstance(min_reports,int) or min_reports<3:
        raise ValueError('rolling_slo_min_reports_must_be_at_least_three')
    checks=[verify_live_validation_evidence(r,now_utc=now_utc) for r in reports]
    digests=[r['report_sha256'] for r in reports]
    if len(set(digests))!=len(digests): raise ValueError('rolling_slo_duplicate_report')
    times=[_parse_utc(r['created_at_utc']) for r in reports]
    if times!=sorted(times) or len(set(times))!=len(times):
        raise ValueError('rolling_slo_reports_not_chronological')
    source_stats={name:{'success':0,'attempts':len(reports),'known_freshness':0,'stale':0,'max_age_hours':None}
                  for name in ('Binance','OKX')}
    comparable=0; agreements=0; pass_count=0; freshness_unknown=0
    for report in reports:
        cross=report.get('cross_source') or {}
        if report.get('status')=='PASS': pass_count+=1
        errors=cross.get('errors') if isinstance(cross,dict) else None
        observations=cross.get('source_observations') if isinstance(cross,dict) else None
        errors=errors if isinstance(errors,dict) else {}
        observations=observations if isinstance(observations,dict) else {}
        successes=[]
        for name in ('Binance','OKX'):
            obs=observations.get(name)
            if isinstance(obs,dict) and obs.get('status')=='PASS':
                source_stats[name]['success']+=1; successes.append(name)
                age=obs.get('latest_age_hours')
                if isinstance(age,(int,float)) and not isinstance(age,bool) and age>=0:
                    source_stats[name]['known_freshness']+=1
                    previous=source_stats[name]['max_age_hours']
                    source_stats[name]['max_age_hours']=age if previous is None else max(previous,age)
                    if age>max_candle_age_hours: source_stats[name]['stale']+=1
                else: freshness_unknown+=1
            elif name not in errors and report.get('status')=='PASS':
                # Legacy PASS reports do not carry per-source observation evidence.
                freshness_unknown+=1
        if len(successes)==2:
            comparable+=1
            if isinstance(cross.get('reconciliation'),dict) and cross['reconciliation'].get('status')=='PASS':
                agreements+=1
    n=len(reports)
    availability={k:round(v['success']/n,4) for k,v in source_stats.items()}
    agreement_rate=(agreements/comparable) if comparable else None
    pass_rate=pass_count/n
    freshness_complete=freshness_unknown==0 and all(source_stats[k]['known_freshness']>0 for k in source_stats)
    threshold_breaches=[]
    for name,value in availability.items():
        if value<min_source_availability: threshold_breaches.append(f'{name.lower()}_availability_below_slo')
    if agreement_rate is None or agreement_rate<min_cross_source_agreement:
        threshold_breaches.append('cross_source_agreement_below_slo_or_unmeasured')
    if pass_rate<min_validation_pass_rate: threshold_breaches.append('validation_pass_rate_below_slo')
    if any(v['stale'] for v in source_stats.values()): threshold_breaches.append('stale_candle_observed')
    if len(reports)<min_reports or not freshness_complete:
        decision='REVIEW_REQUIRED'
    elif threshold_breaches:
        decision='STOP'
    elif not operator_approved:
        decision='REVIEW_REQUIRED'
    else:
        decision='CONTINUE_READONLY'
    result={
        'schema':'tekar.btc4h.readonly_rolling_slo.v1',
        'created_at_utc':(now_utc or datetime.now(timezone.utc)).isoformat(),
        'decision':decision,'window_report_count':n,'minimum_reports':min_reports,
        'pass_rate':round(pass_rate,4),'source_availability':availability,
        'source_observations':source_stats,'cross_source_comparable_runs':comparable,
        'cross_source_agreement_rate':round(agreement_rate,4) if agreement_rate is not None else None,
        'freshness_complete':freshness_complete,'freshness_unknown_observations':freshness_unknown,
        'thresholds':{'min_source_availability':min_source_availability,
            'min_cross_source_agreement':min_cross_source_agreement,
            'min_validation_pass_rate':min_validation_pass_rate,
            'max_candle_age_hours':max_candle_age_hours},
        'threshold_breaches':threshold_breaches,'operator_approved':operator_approved is True,
        'report_digests':digests,'verification':checks,
        'training_allowed':False,'paper_execution_allowed':False,'live_orders':False,
    }
    result['slo_sha256']=hashlib.sha256(_canonical(result)).hexdigest()
    return result


def verify_readonly_rolling_slo(result):
    if not isinstance(result,dict): raise ValueError('rolling_slo_result_invalid')
    payload=dict(result); supplied=payload.pop('slo_sha256',None)
    actual=hashlib.sha256(_canonical(payload)).hexdigest()
    if supplied!=actual: raise ValueError('rolling_slo_hash_mismatch')
    if result.get('decision') not in ('CONTINUE_READONLY','REVIEW_REQUIRED','STOP'):
        raise ValueError('rolling_slo_decision_invalid')
    if result.get('training_allowed') is not False or result.get('live_orders') is not False:
        raise ValueError('rolling_slo_safety_flags_invalid')
    if result['decision']=='CONTINUE_READONLY' and (not result.get('operator_approved') or result.get('threshold_breaches') or not result.get('freshness_complete')):
        raise ValueError('rolling_slo_continue_gate_invalid')
    return {'valid':True,'decision':result['decision'],'sha256':actual}
