"""V23.0.50 causal candlestick pattern confirmation for paper decisions.

Only the latest fully supplied candle is evaluated. Callers must pass closed,
exchange-aligned OHLCV candles. Shapes are descriptive evidence, not guarantees.
"""
from __future__ import annotations
import math
from typing import Any
import pandas as pd


def _num(row: Any, key: str) -> float:
    value = float(row[key])
    if not math.isfinite(value):
        raise ValueError(f"invalid_{key}")
    return value


def analyze_candlestick_patterns(candles: Any, *, side: str,
                                 volume_lookback: int = 20) -> dict:
    direction = str(side).upper()
    if direction not in ("LONG", "SHORT"):
        raise ValueError("side must be LONG or SHORT")
    if not isinstance(candles, pd.DataFrame):
        candles = pd.DataFrame(candles)
    required = {"open", "high", "low", "close"}
    if not required.issubset(candles.columns):
        return {"state": "UNAVAILABLE", "patterns": [], "blocking": False,
                "reason": "OHLC columns unavailable"}
    data = candles.copy()
    for col in required | ({"volume"} if "volume" in data.columns else set()):
        data[col] = pd.to_numeric(data[col], errors="coerce")
    data = data.replace([float("inf"), float("-inf")], float("nan")).dropna(subset=list(required))
    if len(data) < 3:
        return {"state": "UNAVAILABLE", "patterns": [], "blocking": False,
                "reason": "at least 3 closed candles required"}
    # Validate candle geometry; malformed rows fail closed rather than creating patterns.
    tail = data.tail(3).reset_index(drop=True)
    for _, r in tail.iterrows():
        o, h, l, c = (_num(r, k) for k in ("open", "high", "low", "close"))
        if min(o, h, l, c) <= 0 or h < max(o, c) or l > min(o, c) or h < l:
            return {"state": "INVALID", "patterns": [], "blocking": False,
                    "reason": "invalid OHLC geometry"}
    a, b, cur = tail.iloc[-3], tail.iloc[-2], tail.iloc[-1]
    o, h, l, c = (_num(cur, k) for k in ("open", "high", "low", "close"))
    body = abs(c-o); span = max(h-l, 1e-12)
    upper = h-max(o,c); lower = min(o,c)-l
    patterns = []
    if body/span <= 0.10:
        patterns.append({"name":"DOJI", "bias":"NEUTRAL", "strength":0.35})
    if lower >= max(body*2.0, span*0.55) and upper <= span*0.20 and c >= o:
        patterns.append({"name":"HAMMER", "bias":"BULLISH", "strength":0.70})
    if upper >= max(body*2.0, span*0.55) and lower <= span*0.20 and c <= o:
        patterns.append({"name":"SHOOTING_STAR", "bias":"BEARISH", "strength":0.70})
    po, pc = _num(b,"open"), _num(b,"close")
    if pc < po and c > o and o <= pc and c >= po:
        patterns.append({"name":"BULLISH_ENGULFING", "bias":"BULLISH", "strength":0.85})
    if pc > po and c < o and o >= pc and c <= po:
        patterns.append({"name":"BEARISH_ENGULFING", "bias":"BEARISH", "strength":0.85})
    # Three-candle reversal structures; middle candle is a small real body.
    ao, ac = _num(a,"open"), _num(a,"close")
    bbody = abs(pc-po); abody = abs(ac-ao)
    if ac < ao and bbody <= abody*0.45 and c > o and c >= (ao+ac)/2:
        patterns.append({"name":"MORNING_STAR", "bias":"BULLISH", "strength":0.90})
    if ac > ao and bbody <= abody*0.45 and c < o and c <= (ao+ac)/2:
        patterns.append({"name":"EVENING_STAR", "bias":"BEARISH", "strength":0.90})
    vol_confirmed = False; relative_volume = None
    if "volume" in data.columns and len(data) >= max(5, volume_lookback+1):
        vols = data["volume"].astype(float)
        baseline = float(vols.iloc[-volume_lookback-1:-1].mean())
        latest = float(vols.iloc[-1])
        if math.isfinite(baseline) and baseline > 0 and math.isfinite(latest) and latest >= 0:
            relative_volume = latest / baseline
            vol_confirmed = relative_volume >= 1.20
    opposing_bias = "BEARISH" if direction == "LONG" else "BULLISH"
    aligned_bias = "BULLISH" if direction == "LONG" else "BEARISH"
    opposing = [p for p in patterns if p["bias"] == opposing_bias and p["strength"] >= 0.70]
    aligned = [p for p in patterns if p["bias"] == aligned_bias]
    # Pattern only blocks when volume confirms participation; neutral/doji never blocks.
    blocking = bool(opposing and vol_confirmed)
    state = "OPPOSING_CONFIRMED" if blocking else "ALIGNED_PATTERN" if aligned else "PATTERN_WATCH" if patterns else "NO_PATTERN"
    return {"state":state, "side":direction, "patterns":patterns,
            "opposing_patterns":opposing, "aligned_patterns":aligned,
            "relative_volume":round(relative_volume,4) if relative_volume is not None else None,
            "volume_confirmed":vol_confirmed, "blocking":blocking,
            "evaluated_candle":"last supplied candle (must be closed)",
            "warning":"کندل‌خوانی به‌تنهایی جهت بازار را قطعی نمی‌کند."}
