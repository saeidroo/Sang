"""Conservative OHLC bracket execution for paper trades.

This is a candle-level simulator, not an exchange order-book execution model.
If both stop and target occur inside one candle, stop is assumed first.
"""
from __future__ import annotations
import math


def evaluate_bracket_candle(*, side: str, stop_price: float, target_price: float,
                            candle: dict) -> dict:
    side = str(side).upper()
    if side not in ("LONG", "SHORT"):
        raise ValueError("side must be LONG or SHORT")
    vals = {k: float(candle[k]) for k in ("open", "high", "low", "close")}
    stop, target = float(stop_price), float(target_price)
    if not all(math.isfinite(v) and v > 0 for v in [*vals.values(), stop, target]):
        raise ValueError("OHLC and bracket prices must be finite and positive")
    o, h, l, c = vals["open"], vals["high"], vals["low"], vals["close"]
    if h < max(o, c, l) or l > min(o, c, h) or h < l:
        raise ValueError("invalid OHLC candle bounds")

    if side == "LONG":
        stop_hit, target_hit = l <= stop, h >= target
        stop_gap = o <= stop
        target_gap = o >= target
    else:
        stop_hit, target_hit = h >= stop, l <= target
        stop_gap = o >= stop
        target_gap = o <= target

    if stop_hit:  # Conservative tie-break: stop wins if both touched.
        fill = o if stop_gap else stop
        return {"triggered": True, "reason": "STOP_LOSS", "fill_reference": fill,
                "stop_hit": True, "target_hit": bool(target_hit),
                "both_hit": bool(target_hit), "gap": bool(stop_gap),
                "policy": "STOP_FIRST_CONSERVATIVE"}
    if target_hit:
        # Never grant a favorable gap beyond the configured target.
        return {"triggered": True, "reason": "TAKE_PROFIT", "fill_reference": target,
                "stop_hit": False, "target_hit": True, "both_hit": False,
                "gap": bool(target_gap), "policy": "TARGET_CAPPED_AT_LEVEL"}
    return {"triggered": False, "reason": None, "fill_reference": None,
            "stop_hit": False, "target_hit": False, "both_hit": False,
            "gap": False, "policy": "NO_BRACKET_TOUCH"}
