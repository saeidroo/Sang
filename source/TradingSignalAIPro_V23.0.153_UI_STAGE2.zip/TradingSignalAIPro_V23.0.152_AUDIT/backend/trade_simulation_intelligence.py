"""V23.0.79 deterministic paper-trade plan preview; never opens positions."""
from __future__ import annotations
import math

VERSION = '23.0.79'
INITIAL_CAPITAL_USDT = 1000.0
RISK_PER_TRADE_PCT = 0.5
MAX_NOTIONAL_PCT = 20.0
FEE_BPS_PER_SIDE = 10.0
SLIPPAGE_BPS_PER_SIDE = 5.0


def _n(value):
    if isinstance(value, bool) or value is None:
        return None
    try:
        x = float(value)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError, OverflowError):
        return None


def preview_trade_plans(candidates, capital_usdt=INITIAL_CAPITAL_USDT):
    if not isinstance(candidates, list):
        raise ValueError('candidates must be a list')
    capital = _n(capital_usdt)
    if capital is None or capital <= 0 or capital > 1_000_000:
        raise ValueError('capital_usdt must be positive and <= 1000000')
    out = []
    for raw in candidates[:100]:
        if not isinstance(raw, dict):
            out.append({'decision': 'REJECTED', 'reason': 'INVALID_CANDIDATE'})
            continue
        symbol = str(raw.get('symbol') or '').upper().strip()[:30]
        decision = str(raw.get('decision') or '').upper().strip()
        side = 'LONG' if decision == 'PAPER_BUY_CANDIDATE' else 'SHORT' if decision == 'PAPER_SELL_CANDIDATE' else None
        price, atr = _n(raw.get('price')), _n(raw.get('atr'))
        if not symbol or not side:
            status, reason = 'NOT_ELIGIBLE', 'DECISION_NOT_A_PAPER_CANDIDATE'
        elif price is None or price <= 0:
            status, reason = 'INSUFFICIENT_DATA', 'VALID_REFERENCE_PRICE_REQUIRED'
        elif atr is not None and atr <= 0:
            status, reason = 'INSUFFICIENT_DATA', 'ATR_MUST_BE_POSITIVE'
        else:
            status, reason = 'PREVIEW_READY', 'PLAN_ONLY_NO_POSITION_CREATED'
        if status != 'PREVIEW_READY':
            out.append({'symbol': symbol, 'status': status, 'reason': reason,
                        'creates_position': False, 'creates_orders': False})
            continue
        stop_distance = max(atr * 1.5, price * 0.015) if atr is not None else price * 0.015
        target_distance = max(atr * 3.0, price * 0.03) if atr is not None else price * 0.03
        stop = price - stop_distance if side == 'LONG' else price + stop_distance
        target = price + target_distance if side == 'LONG' else price - target_distance
        risk_budget = capital * RISK_PER_TRADE_PCT / 100.0
        qty_by_risk = risk_budget / stop_distance
        qty_by_cap = capital * MAX_NOTIONAL_PCT / 100.0 / price
        qty = min(qty_by_risk, qty_by_cap)
        notional = qty * price
        fee = notional * (FEE_BPS_PER_SIDE / 10000.0) * 2
        slippage = notional * (SLIPPAGE_BPS_PER_SIDE / 10000.0) * 2
        out.append({'symbol': symbol, 'status': status, 'side': side,
                    'reference_entry': round(price, 10), 'quantity': round(qty, 10),
                    'notional_usdt': round(notional, 4), 'stop_loss': round(stop, 10),
                    'take_profit': round(target, 10), 'risk_budget_usdt': round(risk_budget, 4),
                    'estimated_round_trip_fee_usdt': round(fee, 4),
                    'estimated_round_trip_slippage_usdt': round(slippage, 4),
                    'estimated_total_execution_cost_usdt': round(fee + slippage, 4),
                    'reward_risk_ratio_before_costs': round(target_distance / stop_distance, 3),
                    'creates_position': False, 'creates_orders': False,
                    'entry_authorized': False, 'execution_authorized': False})
    return {'version': VERSION, 'count': len(out), 'results': out,
            'capital_usdt': round(capital, 2), 'paper_only': True,
            'real_orders_enabled': False, 'creates_orders': False,
            'creates_positions': False, 'entry_authorized': False,
            'disclaimer': 'این فقط پیش‌نمایش محاسبات معامله آزمایشی است؛ هیچ پوزیشنی باز یا بسته نمی‌شود.'}
