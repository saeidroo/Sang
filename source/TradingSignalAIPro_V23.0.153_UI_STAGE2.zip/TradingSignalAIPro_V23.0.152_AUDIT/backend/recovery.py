"""V22.2i consistent backup and isolated recovery drills."""
from __future__ import annotations
import hashlib, json, os, shutil, sqlite3, tempfile, uuid
from datetime import datetime, timezone
from pathlib import Path
from . import evaluation, experiment_registry
from .reproducible_run import sha256_file, verify_run_manifest

SCHEMA = 'v22-recovery-v1'

def _models_dir():
    from .storage import get_models_dir
    return Path(get_models_dir()).expanduser()

def _registry_path():
    return _models_dir() / 'experiments' / 'registry.jsonl'

def _manifest_dir():
    return _models_dir() / 'reproducible_runs'

def _paper_head(path: Path):
    if not path.exists(): return {'valid': True, 'checked_events': 0, 'legacy_unsealed_events': 0, 'errors': [], 'head_hash': '0'*64}
    old=os.environ.get('TRADING_AI_V22_PAPER_DB')
    os.environ['TRADING_AI_V22_PAPER_DB']=str(path)
    try: return evaluation.paper_v22_audit_integrity()
    finally:
        if old is None: os.environ.pop('TRADING_AI_V22_PAPER_DB',None)
        else: os.environ['TRADING_AI_V22_PAPER_DB']=old

def create_recovery_backup(destination: str | Path) -> dict:
    """Create a staged snapshot; SQLite is captured using its online backup API."""
    dest=Path(destination).expanduser().resolve(); dest.parent.mkdir(parents=True,exist_ok=True)
    stage=dest.parent/(dest.name+'.tmp-'+uuid.uuid4().hex)
    stage.mkdir()
    try:
        registry=_registry_path(); db=evaluation._db(); manifests=_manifest_dir()
        files={}
        if registry.is_file():
            target=stage/'registry.jsonl'; shutil.copy2(registry,target); files['registry.jsonl']={'sha256':sha256_file(target),'size_bytes':target.stat().st_size}
        if db.is_file():
            target=stage/'paper_v22.sqlite3'
            src=sqlite3.connect(str(db),timeout=30)
            dst=sqlite3.connect(str(target))
            try: src.backup(dst)
            finally: dst.close(); src.close()
            files['paper_v22.sqlite3']={'sha256':sha256_file(target),'size_bytes':target.stat().st_size}
        md=stage/'reproducible_runs'; md.mkdir()
        if manifests.is_dir():
            for item in sorted(manifests.glob('*.json')):
                if item.is_file(): shutil.copy2(item,md/item.name)
        manifest_files={p.name:{'sha256':sha256_file(p),'size_bytes':p.stat().st_size} for p in sorted(md.glob('*.json'))}
        reg_events=[]
        if (stage/'registry.jsonl').exists():
            reg_events=[json.loads(x) for x in (stage/'registry.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
        reg_audit=experiment_registry.audit_integrity(custom_dir=stage/'registry_temp') if False else None
        # Verify the copied registry directly, without touching the live registry path.
        from .audit_trail import verify_events
        reg_audit=verify_events(reg_events)
        paper_audit=_paper_head(stage/'paper_v22.sqlite3')
        body={'schema_version':SCHEMA,'created_at':datetime.now(timezone.utc).isoformat(),'files':files,
              'manifest_files':manifest_files,'registry_integrity':reg_audit,'paper_integrity':paper_audit,
              'registry_head_hash':reg_audit.get('head_hash'),'paper_head_hash':paper_audit.get('head_hash')}
        body['backup_sha256']=hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        (stage/'backup_manifest.json').write_text(json.dumps(body,sort_keys=True,indent=2)+'\n',encoding='utf-8')
        from .signed_anchor import sign_backup
        anchor=sign_backup(body['backup_sha256'],body.get('registry_head_hash') or '0'*64,body.get('paper_head_hash') or '0'*64)
        (stage/'anchor.json').write_text(json.dumps(anchor,sort_keys=True,indent=2)+'\n',encoding='utf-8')
        if dest.exists(): raise FileExistsError(f'backup destination already exists: {dest}')
        os.replace(stage,dest)
        return {'ok':True,'backup_path':str(dest),'manifest':body}
    except Exception:
        shutil.rmtree(stage,ignore_errors=True); raise

def verify_recovery_backup(backup: str | Path) -> dict:
    root=Path(backup).expanduser().resolve(); errors=[]
    try: m=json.loads((root/'backup_manifest.json').read_text(encoding='utf-8'))
    except Exception as exc: return {'valid':False,'errors':[f'manifest_unreadable:{exc}']}
    supplied=m.pop('backup_sha256',None)
    actual=hashlib.sha256(json.dumps(m,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    if supplied!=actual: errors.append('backup_manifest_hash_mismatch')
    try:
        from .signed_anchor import verify_anchor
        anchor=json.loads((root/'anchor.json').read_text(encoding='utf-8'))
        anchor_result=verify_anchor(anchor)
        if not anchor_result['valid']: errors.extend('anchor:'+x for x in anchor_result['errors'])
        if anchor.get('backup_sha256') != supplied: errors.append('anchor_backup_hash_mismatch')
        if anchor.get('registry_head_hash') != m.get('registry_head_hash') or anchor.get('paper_head_hash') != m.get('paper_head_hash'): errors.append('anchor_audit_head_mismatch')
    except Exception as exc:
        anchor_result={'valid':False,'errors':[f'anchor_unreadable:{exc}']}
        errors.extend(anchor_result['errors'])
    for name,meta in m.get('files',{}).items():
        p=root/name
        if not p.is_file() or sha256_file(p)!=meta['sha256'] or p.stat().st_size!=meta['size_bytes']: errors.append(f'file_invalid:{name}')
    for name,meta in m.get('manifest_files',{}).items():
        p=root/'reproducible_runs'/name
        if not p.is_file() or sha256_file(p)!=meta['sha256'] or p.stat().st_size!=meta['size_bytes']: errors.append(f'manifest_file_invalid:{name}')
        elif not verify_run_manifest(p)['valid']: errors.append(f'run_manifest_invalid:{name}')
    from .audit_trail import verify_events
    rp=root/'registry.jsonl'
    events=[json.loads(x) for x in rp.read_text(encoding='utf-8').splitlines() if x.strip()] if rp.exists() else []
    ra=verify_events(events)
    if not ra['valid']: errors.extend('registry:'+x for x in ra['errors'])
    pa=_paper_head(root/'paper_v22.sqlite3')
    if not pa['valid']: errors.extend('paper:'+x for x in pa['errors'])
    if ra.get('head_hash')!=m.get('registry_head_hash'): errors.append('registry_head_mismatch')
    if pa.get('head_hash')!=m.get('paper_head_hash'): errors.append('paper_head_mismatch')
    return {'valid':not errors,'errors':errors,'registry_integrity':ra,'paper_integrity':pa,'anchor_integrity':anchor_result,'backup_path':str(root)}

def restore_recovery_backup(backup: str | Path, destination: str | Path) -> dict:
    """Restore to a new isolated directory; never overwrites live application data."""
    checked=verify_recovery_backup(backup)
    if not checked['valid']: raise ValueError('backup verification failed: '+','.join(checked['errors']))
    dest=Path(destination).expanduser().resolve()
    if dest.exists(): raise FileExistsError(f'restore destination already exists: {dest}')
    dest.parent.mkdir(parents=True,exist_ok=True); stage=dest.parent/(dest.name+'.restore-'+uuid.uuid4().hex); stage.mkdir()
    try:
        root=Path(backup).expanduser().resolve()
        for name in ('registry.jsonl','paper_v22.sqlite3'):
            src=root/name
            if src.exists(): shutil.copy2(src,stage/name)
        if (root/'reproducible_runs').exists(): shutil.copytree(root/'reproducible_runs',stage/'reproducible_runs')
        for name in ('backup_manifest.json','anchor.json'):
            shutil.copy2(root/name,stage/name)
        os.replace(stage,dest)
        return {'ok':True,'restored_to':str(dest),'isolated':True,'integrity':verify_recovery_backup(root)}
    except Exception:
        shutil.rmtree(stage,ignore_errors=True); raise
