"""V22.3m: fail-closed provenance from immutable BTC snapshots to training runs."""
from __future__ import annotations
import hashlib, json, os
from pathlib import Path
from datetime import datetime, timezone

LINEAGE_VERSION = 'btc-4h-training-lineage-v1'

def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)

def _sha(value):
    return hashlib.sha256(_canonical(value).encode('utf-8')).hexdigest()

def _read_json(value):
    if isinstance(value, (str, Path)):
        p = Path(value)
        return json.loads(p.read_text(encoding='utf-8')), p
    if isinstance(value, dict):
        return value, None
    raise TypeError('expected_json_path_or_dict')

def _hash_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def build_lineage_manifest(snapshot, reconciliation, dataset_manifest, *, symbol=None, timeframe=None):
    """Verify snapshot and reconciliation, then bind them to the dataset manifest."""
    snap, snap_path = _read_json(snapshot)
    recon, recon_path = _read_json(reconciliation)
    rows = snap.get('candles')
    if not isinstance(rows, list) or not rows:
        raise ValueError('snapshot_candles_missing')
    data_hash = _sha(rows)
    if data_hash != snap.get('data_sha256'):
        raise ValueError('snapshot_hash_mismatch')
    if recon.get('status') != 'PASS' or recon.get('training_allowed') is not True:
        raise ValueError('btc_source_drift_blocks_training')
    # report hash covers the report exactly as persisted, excluding its self-hash.
    report_body = dict(recon); declared_report_hash = report_body.pop('report_sha256', None)
    if declared_report_hash and _sha(report_body) != declared_report_hash:
        raise ValueError('reconciliation_report_hash_mismatch')
    if recon.get('current_sha256') != data_hash:
        raise ValueError('reconciliation_snapshot_hash_mismatch')
    if not isinstance(dataset_manifest, dict) or not dataset_manifest.get('dataset_hash'):
        raise ValueError('dataset_manifest_missing_hash')
    feature_schema_hash = dataset_manifest.get('feature_schema_hash')
    if not feature_schema_hash:
        raise ValueError('feature_schema_hash_missing')
    lineage = {
        'version': LINEAGE_VERSION,
        'snapshot': {'file': snap_path.name if snap_path else None,
                     'file_sha256': _hash_file(snap_path) if snap_path else _sha(snap),
                     'data_sha256': data_hash, 'row_count': len(rows)},
        'reconciliation': {'report_file': recon_path.name if recon_path else None,
                           'report_sha256': declared_report_hash or _sha(recon),
                           'status': recon['status'], 'previous_sha256': recon.get('previous_sha256'),
                           'current_sha256': recon['current_sha256']},
        'source': {'symbol': symbol or snap.get('symbol', 'BTCUSDT'),
                   'timeframe': timeframe or snap.get('timeframe', '4h'),
                   'batch_hashes': list(snap.get('source_batches', []))},
        'dataset': {'dataset_hash': dataset_manifest['dataset_hash'],
                    'feature_schema_hash': feature_schema_hash,
                    'label_schema_hash': hashlib.sha256(_canonical(dataset_manifest.get('config', {})).encode()).hexdigest()},
    }
    lineage['lineage_sha256'] = _sha(lineage)
    return lineage

def require_training_lineage(lineage, *, expected_snapshot_hash=None):
    if not isinstance(lineage, dict):
        raise ValueError('training_lineage_required')
    body = dict(lineage); declared = body.pop('lineage_sha256', None)
    if not declared or _sha(body) != declared:
        raise ValueError('training_lineage_hash_mismatch')
    if body.get('version') != LINEAGE_VERSION:
        raise ValueError('training_lineage_version_unsupported')
    recon = body.get('reconciliation', {})
    snap = body.get('snapshot', {})
    if recon.get('status') != 'PASS' or recon.get('current_sha256') != snap.get('data_sha256'):
        raise ValueError('btc_source_drift_blocks_training')
    if expected_snapshot_hash and snap.get('data_sha256') != expected_snapshot_hash:
        raise ValueError('training_snapshot_hash_mismatch')
    for key in ('data_sha256', 'file_sha256'):
        value = snap.get(key)
        if not isinstance(value, str) or len(value) != 64:
            raise ValueError('invalid_snapshot_hash')
    return True

def create_training_run_artifact(dataset, lineage, *, model_name, run_id, output_path=None, metrics=None, training_environment=None):
    """Create deterministic-hash training provenance artifact (created_at excluded from digest)."""
    require_training_lineage(lineage)
    manifest = dataset.get('manifest', {}) if isinstance(dataset, dict) else {}
    if manifest.get('dataset_hash') != lineage.get('dataset', {}).get('dataset_hash'):
        raise ValueError('training_dataset_hash_mismatch')
    artifact = {'version': 'btc-4h-training-run-v1', 'run_id': str(run_id),
        'model_name': str(model_name), 'dataset_hash': manifest['dataset_hash'],
        'lineage_sha256': lineage['lineage_sha256'],
        'snapshot_data_sha256': lineage['snapshot']['data_sha256'],
        'snapshot_file_sha256': lineage['snapshot']['file_sha256'],
        'reconciliation_report_sha256': lineage['reconciliation']['report_sha256'],
        'feature_schema_hash': manifest['feature_schema_hash'],
        'metrics': metrics or {}, 'training_environment': training_environment or {}, 'live_orders': False}
    artifact['artifact_sha256'] = _sha(artifact)
    artifact['created_at_utc'] = datetime.now(timezone.utc).isoformat()
    if output_path:
        p = Path(output_path); p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(p.suffix + '.tmp')
        tmp.write_text(json.dumps(artifact, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False), encoding='utf-8')
        os.replace(tmp, p)
    return artifact
