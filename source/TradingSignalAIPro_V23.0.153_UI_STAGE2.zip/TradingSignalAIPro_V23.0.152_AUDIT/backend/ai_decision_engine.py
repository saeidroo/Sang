"""V23.0.78 AI decision layer. Advisory-only; never creates or authorizes orders."""
from __future__ import annotations
import math


def _num(v):
    if isinstance(v, bool) or v is None:
        return None
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError, OverflowError):
        return None


def decide_ai_candidates(candidates):
    if not isinstance(candidates, list):
        raise ValueError('candidates must be a list')
    results = []
    for raw in candidates[:100]:
        if not isinstance(raw, dict):
            results.append({'symbol': '', 'decision': 'INSUFFICIENT_DATA', 'score': 0,
                            'reasons': ['INVALID_CANDIDATE'], 'entry_authorized': False,
                            'creates_orders': False})
            continue
        symbol = str(raw.get('symbol') or '').upper().strip()[:30]
        m = raw.get('master_result') if isinstance(raw.get('master_result'), dict) else raw
        score = _num(m.get('score'))
        coverage = _num(m.get('coverage_pct'))
        conflict = _num(m.get('conflict_ratio'))
        direction = str(m.get('direction') or 'UNKNOWN').upper().strip()
        upstream = str(m.get('decision') or 'UNKNOWN').upper().strip()
        risk = raw.get('risk') if isinstance(raw.get('risk'), dict) else {}
        blockers = []
        if risk.get('high_risk') is True:
            blockers.append('HIGH_RISK_FLAG')
        if risk.get('portfolio_blocked') is True:
            blockers.append('PORTFOLIO_BLOCKED')
        if risk.get('new_listing_blocked') is True:
            blockers.append('NEW_LISTING_BLOCKED')
        if risk.get('entry_quality_pass') is False:
            blockers.append('ENTRY_QUALITY_FAILED')
        reasons = []
        if score is None or coverage is None or conflict is None or not (0 <= score <= 100 and 0 <= coverage <= 100 and 0 <= conflict <= 1):
            decision, reasons = 'INSUFFICIENT_DATA', ['INVALID_OR_MISSING_MASTER_METRICS']
            score_out = 0.0
        elif blockers:
            decision, reasons, score_out = 'REJECT_HIGH_RISK', blockers, round(score, 2)
        elif upstream in ('INSUFFICIENT_DATA', 'INSUFFICIENT_EVIDENCE') or coverage < 30:
            decision, reasons, score_out = 'WAIT_FOR_CONFIRMATION', ['INSUFFICIENT_EVIDENCE_COVERAGE'], round(score, 2)
        elif upstream == 'CONFLICTING_EVIDENCE' or conflict >= 0.4:
            decision, reasons, score_out = 'NO_ENTRY', ['CONFLICTING_MARKET_EVIDENCE'], round(score, 2)
        elif direction not in ('BULLISH', 'BEARISH'):
            decision, reasons, score_out = 'WAIT_FOR_CONFIRMATION', ['DIRECTION_NOT_CONFIRMED'], round(score, 2)
        elif score >= 75 and coverage >= 65 and conflict <= 0.2:
            decision = 'PAPER_BUY_CANDIDATE' if direction == 'BULLISH' else 'PAPER_SELL_CANDIDATE'
            reasons, score_out = ['MASTER_SCORE_AND_COVERAGE_THRESHOLD_MET', 'DIRECTIONAL_EVIDENCE_ALIGNED'], round(score, 2)
        elif score >= 55 and coverage < 65:
            decision, reasons, score_out = 'WAIT_FOR_CONFIRMATION', ['QUALITY_OR_COVERAGE_BELOW_CANDIDATE_THRESHOLD'], round(score, 2)
        else:
            decision, reasons, score_out = 'NO_ENTRY', ['LOW_COMPOSITE_QUALITY'], round(score, 2)
        results.append({'symbol': symbol, 'decision': decision, 'score': score_out,
                        'direction': direction if direction in ('BULLISH','BEARISH','NEUTRAL') else 'UNKNOWN',
                        'coverage_pct': round(coverage, 2) if coverage is not None else 0,
                        'conflict_ratio': round(conflict, 3) if conflict is not None else None,
                        'risk_blockers': blockers, 'reasons': reasons,
                        'advisory_only': True, 'entry_authorized': False,
                        'execution_authorized': False, 'creates_orders': False,
                        'real_orders_enabled': False})
    return {'version': '23.0.78', 'count': len(results), 'results': results,
            'decision_policy': {'candidate_score_min': 75, 'candidate_coverage_min_pct': 65,
                                'max_conflict_ratio': 0.2, 'watch_score_min': 55},
            'paper_only': True, 'capital_usdt': 1000, 'real_orders_enabled': False,
            'creates_orders': False, 'entry_authorized': False,
            'execution_authorized': False,
            'disclaimer': 'این خروجی صرفاً پیشنهاد تحلیلی برای بررسی معاملات آزمایشی است؛ هیچ سفارش یا معامله‌ای ایجاد یا مجاز نمی‌شود.'}
