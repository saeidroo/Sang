"""Advisory signal-quality score; not a probability of profit."""
from __future__ import annotations
import math


def analyze_signal_quality(confluence: dict | None, historical_stats: dict | None = None) -> dict:
    c = confluence if isinstance(confluence, dict) else {}
    evidence = c.get("evidence") if isinstance(c.get("evidence"), list) else []
    score = int(c.get("score", 0) or 0)
    aligned = sum(1 for x in evidence if isinstance(x, dict) and float(x.get("points", 0) or 0) > 0)
    opposing = sum(1 for x in evidence if isinstance(x, dict) and float(x.get("points", 0) or 0) < 0)
    # Saturating heuristic score, deliberately labelled as a quality index, not probability.
    raw = 50.0 + max(-35.0, min(35.0, score * 5.0))
    coverage = min(1.0, len(evidence) / 5.0)
    conflict_ratio = opposing / max(1, aligned + opposing)
    quality = 50.0 + (raw - 50.0) * (0.55 + 0.45 * coverage) - conflict_ratio * 12.0
    hist = historical_stats if isinstance(historical_stats, dict) else {}
    n = max(0, int(hist.get("closed_trades", 0) or 0))
    wr = hist.get("win_rate")
    if wr is not None and n > 0:
        try:
            wr = float(wr)
            if not math.isfinite(wr) or not 0 <= wr <= 1:
                raise ValueError
            # Small samples are heavily shrunk toward neutral; max influence is 20 points.
            reliability = min(1.0, n / 100.0)
            quality += (wr - 0.5) * 40.0 * reliability
        except (TypeError, ValueError):
            wr = None
    quality = round(max(0.0, min(100.0, quality)), 1)
    label = "HIGH" if quality >= 70 else "MEDIUM" if quality >= 55 else "LOW"
    return {"quality_index": quality, "quality_label": label,
            "aligned_sources": aligned, "opposing_sources": opposing,
            "evidence_coverage": round(coverage, 2),
            "history_sample_size": n, "historical_win_rate_used": wr if n else None,
            "confidence_is_probability": False,
            "policy": "ADVISORY_ONLY_NO_ENTRY_AUTHORIZATION",
            "data_policy": "CLOSED_CANDLES_AND_REALIZED_CLOSED_TRADE_STATS_ONLY"}
