"""V23.0.151: read-only, chronological sequence audit for Scout outcomes.

This module mines the order of previously observed Scout states before a
recommendation. It is descriptive only: no forecast, ranking change, or order
instruction is produced. Outcomes are joined only after their observation is
resolved, and only snapshots strictly earlier than the target sighting form
its sequence (no future leakage).
"""
from __future__ import annotations

import os
import sqlite3
from collections import defaultdict
from pathlib import Path

DEFAULT_DB = Path(os.getenv("TEKAR_STORM_LEARNING_DB", str(Path(__file__).resolve().parent.parent / "data" / "storm_learning.sqlite3")))
VALID_RESULTS = ("success", "fake", "neutral")


def _token(row) -> str:
    phase = str(row["phase"] or "unknown").strip().lower().replace(" ", "_")[:24]
    direction = str(row["direction"] or "unknown").strip().lower()
    direction = "down" if direction in ("down", "bear", "bearish", "sell", "short") else "up" if direction in ("up", "bull", "bullish", "buy", "long") else "unknown"
    pattern = str(row["pattern"] or "unknown").strip().lower().replace(" ", "_")[:32]
    regime = str(row["market_regime"] or "unknown").strip().lower()
    return f"{phase}:{direction}:{pattern}:{regime}"


def analyze_sequences(db_path: str | Path | None = None, horizon: str = "24h", lookback_hours: int = 24,
                      sequence_length: int = 3, min_samples: int = 5, limit: int = 30) -> dict:
    """Summarize observed prior-state sequences associated with resolved outcomes."""
    if horizon not in ("1h", "4h", "24h", "3d", "7d"):
        raise ValueError("horizon نامعتبر است")
    if not 1 <= int(sequence_length) <= 5:
        raise ValueError("sequence_length باید بین ۱ تا ۵ باشد")
    if not 1 <= int(lookback_hours) <= 168:
        raise ValueError("lookback_hours باید بین ۱ تا ۱۶۸ باشد")
    min_samples = max(1, min(int(min_samples), 10000))
    limit = max(1, min(int(limit), 100))
    path = Path(db_path) if db_path is not None else DEFAULT_DB
    if not path.exists():
        return {"status": "no_archive", "horizon": horizon, "sequences": [], "sample_count": 0,
                "is_forecast": False, "ranking_effect": 0.0,
                "note_fa": "آرشیو یادگیری موجود نیست؛ هیچ نتیجه یا الگویی ساخته نشد."}
    uri = path.resolve().as_uri() + "?mode=ro"
    try:
        con = sqlite3.connect(uri, uri=True, timeout=5)
        con.row_factory = sqlite3.Row
        # Check schema before querying so old/incomplete archives fail safely.
        tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {"scout_sightings", "scout_outcomes"}.issubset(tables):
            con.close()
            return {"status": "archive_schema_incomplete", "horizon": horizon, "sequences": [],
                    "sample_count": 0, "is_forecast": False, "ranking_effect": 0.0}
        targets = con.execute("""SELECT s.id,s.symbol,s.ts,s.phase,s.direction,s.verified,s.pattern,s.score,s.market_regime,
                                      o.result,o.return_pct
                               FROM scout_sightings s JOIN scout_outcomes o ON o.sighting_id=s.id
                               WHERE o.horizon=? AND o.resolved_ts IS NOT NULL
                                 AND o.result IN ('success','fake','neutral')
                               ORDER BY s.symbol,s.ts""", (horizon,)).fetchall()
        grouped = defaultdict(list)
        for row in targets:
            grouped[str(row["symbol"])].append(row)
        cohorts = defaultdict(list)
        eligible = 0
        for symbol, rows in grouped.items():
            all_history = con.execute("""SELECT id,symbol,ts,phase,direction,verified,pattern,score,market_regime
                                          FROM scout_sightings WHERE symbol=? ORDER BY ts,id""", (symbol,)).fetchall()
            history_index = 0
            prior = []
            for target in rows:
                ts = float(target["ts"])
                while history_index < len(all_history) and float(all_history[history_index]["ts"]) < ts:
                    item = all_history[history_index]
                    if ts - float(item["ts"]) <= lookback_hours * 3600:
                        prior.append(item)
                    history_index += 1
                prior = [p for p in prior if ts - float(p["ts"]) <= lookback_hours * 3600]
                if len(prior) < sequence_length:
                    continue
                sequence = prior[-sequence_length:]
                # Prevent repeated identical scan states from masquerading as
                # a meaningful sequence: retain order but collapse adjacent repeats.
                tokens = [_token(p) for p in sequence]
                if len(set(tokens)) == 1:
                    continue
                key = tuple(tokens)
                cohorts[(str(target["direction"]).lower(), key)].append(target)
                eligible += 1
        con.close()
    except sqlite3.Error:
        try:
            con.close()
        except Exception:
            pass
        return {"status": "archive_read_error", "horizon": horizon, "sequences": [],
                "sample_count": 0, "is_forecast": False, "ranking_effect": 0.0}

    result = []
    for (direction, tokens), rows in cohorts.items():
        n = len(rows)
        if n < min_samples:
            continue
        wins = sum(r["result"] == "success" for r in rows)
        failures = sum(r["result"] == "fake" for r in rows)
        neutral = sum(r["result"] == "neutral" for r in rows)
        returns = [float(r["return_pct"]) for r in rows if r["return_pct"] is not None]
        result.append({"direction": direction, "sequence": list(tokens), "samples": n,
                       "successes": wins, "failures": failures, "neutral": neutral,
                       "success_rate": round(wins / n, 4),
                       "avg_market_return_pct": round(sum(returns) / len(returns), 4) if returns else None,
                       "evidence": "descriptive_only"})
    result.sort(key=lambda x: (x["samples"], x["success_rate"]), reverse=True)
    return {"status": "ok", "horizon": horizon, "lookback_hours": int(lookback_hours),
            "sequence_length": int(sequence_length), "eligible_observations": eligible,
            "sample_count": sum(x["samples"] for x in result), "sequences": result[:limit],
            "minimum_samples": min_samples, "is_forecast": False, "ranking_effect": 0.0,
            "auto_tuning": False, "note_fa": "توالی‌ها فقط از مشاهدات قبلی همان نماد ساخته شده‌اند؛ گزارش توصیفی است و به‌تنهایی پیش‌بینی یا سیگنال تولید نمی‌کند."}
