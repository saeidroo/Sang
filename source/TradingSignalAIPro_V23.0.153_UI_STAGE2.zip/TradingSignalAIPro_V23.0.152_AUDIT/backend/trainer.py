"""
Trainer with trial-and-error hyperparameter search.

The "learning" pipeline:
  1. Fetch thousands of candles
  2. Build 130+ features from 35+ indicators
  3. Triple-barrier labels (TP/SL-aligned)
  4. Split: train (70%) / validation (15%) / test (15%) with temporal ordering
  5. Feature selection to top-K by quick RandomForest importance
  6. For each of 8 trials, train ensemble + rank by balanced accuracy and validation evidence
  7. Walk-forward check; optimal confidence threshold via trade simulation
  8. Final training with warm-start continuation + stacking meta-model
  9. Save model + metadata to ~/.trading_ai_models/
"""
import os
import hashlib
import json
import time
import threading
import numpy as np
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from sklearn.metrics import accuracy_score, balanced_accuracy_score
from sklearn.ensemble import RandomForestClassifier

from .model import TradingEnsemble, JOBS_FULL
from .features import (build_features, TB_UP_MULT, TB_DN_MULT, TB_HORIZON,
                       FEATURE_SCHEMA_VERSION)
from .data import fetch_candles
from .signal import simulate_trades, ATR_TP_MULT, ATR_SL_MULT
from .storage import (model_path, save_meta, load_meta, write_training_log,
                      get_models_dir)


def attach_realized_perp_funding(ind_rows: pd.DataFrame, *, symbol: str,
                                 timeframe: str, source: str, events=None) -> tuple[pd.DataFrame, dict]:
    """Attach public, realized perpetual funding events to the OHLC timeline.

    Funding timestamps are returned by the venue adapter in seconds while candle
    timestamps are normally milliseconds. Events are placed on the latest candle
    open at or before settlement. If the selected venue cannot provide a real
    settlement mark, the source history is incomplete, or multiple settlements
    share a candle row, every event is preserved independently in an event-list
    column; no settlement is aggregated or discarded.
    """
    from .data import is_futures_symbol, futures_base_symbol
    from .funding import fetch_funding_history, funding_history_complete

    if not is_futures_symbol(symbol):
        return ind_rows, {'market': 'spot', 'funding_events': 0, 'status': 'NOT_APPLICABLE'}
    source_name = str(source or '').lower().strip()
    exchange = source_name[:-4] if source_name.endswith('_fut') else ''
    supported = {'binance', 'bybit', 'okx', 'mexc', 'gateio', 'bitget'}
    if exchange not in supported:
        raise RuntimeError(f'برای بک‌تست Perpetual منبع Funding قابل اتکا مشخص نیست: {source_name or "unknown"}')
    if not isinstance(ind_rows, pd.DataFrame) or 't' not in ind_rows.columns or ind_rows.empty:
        raise RuntimeError('خط زمانی OHLC برای اتصال Funding معتبر نیست')

    candle_ts = pd.to_numeric(ind_rows['t'], errors='coerce').to_numpy(dtype=float)
    if (not np.isfinite(candle_ts).all() or np.any(np.diff(candle_ts) <= 0)):
        raise RuntimeError('timestamp کندل‌های Perpetual نامعتبر یا نامرتب است')
    scale = 1000.0 if float(np.nanmedian(candle_ts)) > 100_000_000_000 else 1.0
    start_seconds = float(candle_ts[0]) / scale
    end_seconds = float(candle_ts[-1]) / scale
    if events is None:
        events = fetch_funding_history(exchange, futures_base_symbol(symbol),
                                       start_seconds, end_seconds)
    if not isinstance(events, list):
        raise RuntimeError('پاسخ تاریخچه Funding ساختار نامعتبر دارد')
    if not funding_history_complete(exchange, events, start_seconds):
        raise RuntimeError('تاریخچه Funding به سقف صفحه‌بندی رسیده و کامل‌بودن آن تأیید نمی‌شود')
    if not events:
        raise RuntimeError('برای بازه داده Perpetual هیچ رویداد Funding دریافت نشد')

    out = ind_rows.copy()
    out['funding_rate'] = np.nan
    out['funding_mark_price'] = np.nan
    out['funding_settlement_ts'] = np.nan
    out['funding_events'] = [list() for _ in range(len(out))]
    seen_settlements = set()
    last_settlement = None
    valid_count = 0
    normalized_events = []
    for event in sorted(events, key=lambda row: float((row or {}).get('settlement_ts') or 0.0)):
        if not isinstance(event, dict):
            raise RuntimeError('رکورد Funding نامعتبر است')
        try:
            rate = float(event['funding_rate'])
            settlement_seconds = float(event['settlement_ts'])
            mark = float(event['mark_price'])
        except (KeyError, TypeError, ValueError, OverflowError):
            raise RuntimeError('Funding ناقص است؛ نرخ تسویه، timestamp و Mark Price واقعی لازم است')
        settlement_ts = settlement_seconds * scale
        if (not np.isfinite(rate) or abs(rate) > 0.10 or
                not np.isfinite(settlement_ts) or not np.isfinite(mark) or mark <= 0):
            raise RuntimeError('رکورد Funding شامل مقدار نامعتبر یا Mark Price مفقود است')
        if settlement_ts in seen_settlements:
            raise RuntimeError('timestamp تسویه Funding تکراری است')
        seen_settlements.add(settlement_ts)
        if last_settlement is not None and settlement_ts <= last_settlement:
            raise RuntimeError('ترتیب زمانی تسویه‌های Funding نامعتبر است')
        last_settlement = settlement_ts
        if not (candle_ts[0] < settlement_ts <= candle_ts[-1]):
            continue
        row_pos = int(np.searchsorted(candle_ts, settlement_ts, side='right') - 1)
        normalized_events.append((row_pos, {'funding_rate': rate,
                                            'settlement_ts': settlement_ts,
                                            'mark_price': mark}))
        valid_count += 1
    for row_pos, item in normalized_events:
        row_index = out.index[row_pos]
        out.at[row_index, 'funding_events'].append(item)
    # Keep legacy scalar columns populated only for single-event rows. Multi-event
    # rows are intentionally NaN there so legacy consumers cannot double-count.
    for row_pos, items in enumerate(out['funding_events'].tolist()):
        if len(items) == 1:
            row_index = out.index[row_pos]
            out.at[row_index, 'funding_rate'] = items[0]['funding_rate']
            out.at[row_index, 'funding_mark_price'] = items[0]['mark_price']
            out.at[row_index, 'funding_settlement_ts'] = items[0]['settlement_ts']
    if valid_count == 0:
        raise RuntimeError('هیچ رویداد Funding معتبر در محدوده کندل‌های بک‌تست قرار نگرفت')
    return out, {'market': 'perp', 'exchange': exchange, 'funding_events': valid_count,
                 'status': 'COMPLETE_FOR_RETURNED_WINDOW',
                 'timestamp_unit': 'milliseconds' if scale == 1000.0 else 'seconds',
                 'mark_price_policy': 'realized_settlement_mark_required'}


# Feature selection: keep top-K features by quick RF importance
TOP_K_FEATURES = 85   # V19.4: raised to make room for the new regime/tail-risk features

# Drop redundant features whose |correlation| with a stronger feature
# exceeds this (decorrelated inputs -> better ensemble diversity)
CORR_PRUNE = 0.95

# Final-fit upgrades
FINAL_N_SEEDS = 3      # V19.4: 3 seeds across every tree family (more variance reduction)
# Recency weighting A/B-tested on real BTC data: it OVERFITS the recent
# regime and degrades the high-confidence tiers (hi75: 58% -> 48%).
# Kept as an option but OFF by default.
FINAL_RECENCY = False

# Parallel learning: how many trials / walk-forward folds run at once.
# Workers = cores/2 (each worker's estimators use 1-2 threads).
try:
    _requested_workers = int(os.getenv('TS_AI_MAX_WORKERS', '1'))
except (TypeError, ValueError):
    _requested_workers = 1
PAR_WORKERS = max(1, min(4, (os.cpu_count() or 2) // 2, _requested_workers))

# Threshold optimization candidates (incl. the 85% precision tier)
THR_CANDIDATES = [0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85]
TRAINING_PROTOCOL_VERSION = '22.1.3-interval-purge-contiguous-backtest'


# ---------------------------------------------------------------------------
# Trial checkpoint (V17.2): a crash mid-training used to throw away every
# completed hyper-parameter trial. Completed trials are written to disk after
# each one finishes; the next run reuses them when the data window matches.
# ---------------------------------------------------------------------------
_CKPT_LOCK = threading.Lock()


def _checkpoint_path(symbol: str, timeframe: str):
    from .storage import get_models_dir
    safe = f"{symbol}_{timeframe}".replace('/', '_').replace('\\', '_')
    return get_models_dir() / 'checkpoints' / f'ckpt_{safe}.json'


def _load_checkpoint(symbol: str, timeframe: str) -> dict:
    try:
        path = _checkpoint_path(symbol, timeframe)
        if path.exists():
            data = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {}


def _save_checkpoint(symbol: str, timeframe: str, payload: dict) -> None:
    """Best-effort atomic checkpoint write; never breaks training."""
    try:
        path = _checkpoint_path(symbol, timeframe)
        path.parent.mkdir(parents=True, exist_ok=True)
        with _CKPT_LOCK:
            tmp = path.with_suffix('.tmp')
            tmp.write_text(json.dumps(payload, ensure_ascii=False, default=str), encoding='utf-8')
            tmp.replace(path)
    except Exception:
        pass


def _clear_checkpoint(symbol: str, timeframe: str) -> None:
    try:
        _checkpoint_path(symbol, timeframe).unlink()
    except OSError:
        pass


def _jsonify(obj):
    """Make numpy/tuple values JSON-safe for metadata and checkpoints."""
    return json.loads(json.dumps(obj, default=lambda o: o.item() if hasattr(o, 'item') else str(o)))


def _trial_score(trial: dict) -> float:
    """Recompute the trial ranking score from a persisted trial result.

    Must stay IDENTICAL to the in-loop formula so reused and freshly trained
    trials stay comparable after an interruption.
    """
    bal_acc = trial.get('val_balanced') or 0.0
    val_acc = trial.get('val_acc') or 0.0
    hi_acc = trial.get('val_high_conf_acc') or 0.0
    hi_cov = trial.get('val_high_conf_cov') or 0.0
    vh_acc = trial.get('val_very_high_conf_acc') or 0.0
    vh_cov = trial.get('val_very_high_conf_cov') or 0.0
    uh_acc = trial.get('val_ultra_conf_acc') or 0.0
    uh_cov = trial.get('val_ultra_conf_cov') or 0.0
    sim_bonus = 0.0
    if (trial.get('sim_trades_60') or 0) >= 10:
        sim_bonus = 0.6 * ((trial.get('sim_win_rate_60') or 0.5) - 0.5)
    return (0.70 * bal_acc + 0.30 * val_acc
            + 0.20 * max(0.0, hi_acc - bal_acc) * hi_cov
            + 0.25 * max(0.0, vh_acc - bal_acc) * vh_cov
            + 0.30 * max(0.0, uh_acc - bal_acc) * uh_cov
            + sim_bonus)


def _wilson_lb(wins: int, n: int, z: float = 1.96) -> float:
    """Wilson score lower bound — a conservative win-rate estimate that
    penalizes small samples. Using it (instead of the raw win rate) to pick
    the confidence threshold avoids overfitting the threshold to a few
    lucky OOF trades."""
    if n == 0:
        return 0.0
    p = wins / n
    denom = 1 + z * z / n
    center = p + z * z / (2 * n)
    margin = z * float(np.sqrt((p * (1 - p) + z * z / (4 * n)) / n))
    return (center - margin) / denom


def edge_consistency(probs, ind: pd.DataFrame, thr: float, blocks: int = 3,
                     min_trades: int = 6, market: str = 'spot') -> dict:
    """V21 — is the edge present across time, or did ONE lucky stretch create it?

    The OOF tail used for threshold selection is cut into ``blocks`` consecutive
    chunks and the same threshold is simulated in each. The edge is consistent only
    if at least two chunks have enough trades to judge AND at least 2/3 of the judged
    chunks have positive NET expectancy.
    """
    probs = np.asarray(probs, dtype=float)
    n = min(len(probs), len(ind))
    out = {'blocks': [], 'evaluated': 0, 'positive': 0, 'ok': False}
    if n < blocks * 20:
        return out
    edges = np.linspace(0, n, blocks + 1).astype(int)
    for a, b in zip(edges[:-1], edges[1:]):
        sim = simulate_trades(probs[a:b], ind.iloc[a:b].reset_index(drop=True), thr=thr, market=market)
        judged = sim['n_trades'] >= min_trades
        pos = bool(judged and float(sim.get('net_expectancy_pct') or 0.0) > 0.0)
        out['blocks'].append({'trades': int(sim['n_trades']), 'judged': judged,
                              'win_rate': round(float(sim['win_rate']), 4),
                              'net_expectancy_pct': round(float(sim.get('net_expectancy_pct') or 0.0), 4)})
        out['evaluated'] += int(judged)
        out['positive'] += int(pos)
    ev, po = out['evaluated'], out['positive']
    out['ok'] = bool(ev >= 2 and po >= int(np.ceil(ev * 2 / 3)))
    return out


def estimate_train_time(limit: int) -> int:
    """Training-time estimate in seconds for a given candle count.
    Calibrated on the parallel pipeline (trials + walk-forward run on
    multiple cores at once). Scales roughly linearly with candles; the
    constant also covers data fetching over the network."""
    return int(45 + limit / 1000 * 18)


def brain_feedback_summary(symbol: str, timeframe: str, min_samples: int = 10) -> dict | None:
    """V20 — close the learning loop: what did the central brain LEARN?

    Reads the matured ML-channel feedback that the central brain recorded for
    this exact (symbol, timeframe) since the previous training round. Returns
    None when the pair has not accumulated enough matured observations yet.
    Fail-soft by design: any storage problem just yields None.
    """
    try:
        from .brain import source_reliability
        rel = source_reliability(symbol, timeframe)
        comp = (rel or {}).get('components', {}).get('ml')
        if not comp or int(comp.get('mature_samples', 0)) < max(1, int(min_samples)):
            return None
        return {'hit_rate': comp.get('directional_hit_rate'),
                'samples': int(comp.get('mature_samples', 0)),
                'weight_multiplier': comp.get('weight_multiplier'),
                'wilson_lower_95': comp.get('wilson_lower_95'),
                'buckets': comp.get('buckets') or {},
                'adaptive': bool(comp.get('adaptive'))}
    except Exception:
        return None


# Hyperparameter grid - tuned to reduce overfitting on noisy financial data.
# All configs use shallow trees, strong regularization, and modest estimators.
HP_GRID = [
    # Trial 1: balanced shallow
    {
        'xgboost': {'n_estimators': 150, 'max_depth': 3, 'learning_rate': 0.05,
                    'subsample': 0.8, 'colsample_bytree': 0.8,
                    'min_child_weight': 8, 'reg_alpha': 0.3, 'reg_lambda': 2.0,
                    'gamma': 0.5},
        'lightgbm': {'n_estimators': 150, 'max_depth': 3, 'learning_rate': 0.05,
                     'num_leaves': 12, 'subsample': 0.8,
                     'colsample_bytree': 0.8, 'min_child_samples': 40,
                     'reg_alpha': 0.3, 'reg_lambda': 2.0, 'min_split_gain': 0.1},
        'random_forest': {'n_estimators': 150, 'max_depth': 5,
                          'min_samples_leaf': 15, 'min_samples_split': 30,
                          'max_features': 'sqrt'},
        'neural_net': {'hidden': (32, 16), 'alpha': 0.01,
                       'lr': 0.002, 'max_iter': 250},
    },
    # Trial 2: slightly deeper with more regularization
    {
        'xgboost': {'n_estimators': 200, 'max_depth': 4, 'learning_rate': 0.04,
                    'subsample': 0.75, 'colsample_bytree': 0.75,
                    'min_child_weight': 10, 'reg_alpha': 0.5, 'reg_lambda': 3.0,
                    'gamma': 0.8},
        'lightgbm': {'n_estimators': 200, 'max_depth': 4, 'learning_rate': 0.04,
                     'num_leaves': 15, 'subsample': 0.75,
                     'colsample_bytree': 0.75, 'min_child_samples': 50,
                     'reg_alpha': 0.5, 'reg_lambda': 3.0, 'min_split_gain': 0.2},
        'random_forest': {'n_estimators': 200, 'max_depth': 6,
                          'min_samples_leaf': 12, 'min_samples_split': 24,
                          'max_features': 0.7},
        'neural_net': {'hidden': (48, 24), 'alpha': 0.02,
                       'lr': 0.0015, 'max_iter': 300},
    },
    # Trial 3: very conservative (anti-overfit focus)
    {
        'xgboost': {'n_estimators': 120, 'max_depth': 2, 'learning_rate': 0.08,
                    'subsample': 0.85, 'colsample_bytree': 0.85,
                    'min_child_weight': 15, 'reg_alpha': 0.8, 'reg_lambda': 5.0,
                    'gamma': 1.0},
        'lightgbm': {'n_estimators': 120, 'max_depth': 2, 'learning_rate': 0.08,
                     'num_leaves': 8, 'subsample': 0.85,
                     'colsample_bytree': 0.85, 'min_child_samples': 60,
                     'reg_alpha': 0.8, 'reg_lambda': 5.0, 'min_split_gain': 0.3},
        'random_forest': {'n_estimators': 100, 'max_depth': 4,
                          'min_samples_leaf': 20, 'min_samples_split': 40,
                          'max_features': 'sqrt'},
        'neural_net': {'hidden': (24, 12), 'alpha': 0.05,
                       'lr': 0.003, 'max_iter': 200},
    },
    # Trial 4: deeper trees but extreme regularization
    {
        'xgboost': {'n_estimators': 250, 'max_depth': 5, 'learning_rate': 0.03,
                    'subsample': 0.7, 'colsample_bytree': 0.7,
                    'min_child_weight': 12, 'reg_alpha': 1.0, 'reg_lambda': 4.0,
                    'gamma': 0.6},
        'lightgbm': {'n_estimators': 250, 'max_depth': 5, 'learning_rate': 0.03,
                     'num_leaves': 20, 'subsample': 0.7,
                     'colsample_bytree': 0.7, 'min_child_samples': 45,
                     'reg_alpha': 1.0, 'reg_lambda': 4.0, 'min_split_gain': 0.15},
        'random_forest': {'n_estimators': 250, 'max_depth': 7,
                          'min_samples_leaf': 10, 'min_samples_split': 20,
                          'max_features': 0.5},
        'neural_net': {'hidden': (64, 32), 'alpha': 0.008,
                       'lr': 0.001, 'max_iter': 400},
    },
    # Trial 5: stump ensemble (very shallow, many trees)
    {
        'xgboost': {'n_estimators': 300, 'max_depth': 2, 'learning_rate': 0.06,
                    'subsample': 0.85, 'colsample_bytree': 0.85,
                    'min_child_weight': 6, 'reg_alpha': 0.4, 'reg_lambda': 2.5,
                    'gamma': 0.3},
        'lightgbm': {'n_estimators': 300, 'max_depth': 2, 'learning_rate': 0.06,
                     'num_leaves': 6, 'subsample': 0.85,
                     'colsample_bytree': 0.85, 'min_child_samples': 35,
                     'reg_alpha': 0.4, 'reg_lambda': 2.5, 'min_split_gain': 0.08},
        'random_forest': {'n_estimators': 200, 'max_depth': 5,
                          'min_samples_leaf': 8, 'min_samples_split': 16,
                          'max_features': 'sqrt'},
        'neural_net': {'hidden': (40, 20), 'alpha': 0.015,
                       'lr': 0.0018, 'max_iter': 350},
    },
    # Trial 6: medium depth, balanced subsampling
    {
        'xgboost': {'n_estimators': 180, 'max_depth': 3, 'learning_rate': 0.07,
                    'subsample': 0.82, 'colsample_bytree': 0.82,
                    'min_child_weight': 7, 'reg_alpha': 0.4, 'reg_lambda': 2.2,
                    'gamma': 0.4},
        'lightgbm': {'n_estimators': 180, 'max_depth': 3, 'learning_rate': 0.07,
                     'num_leaves': 10, 'subsample': 0.82,
                     'colsample_bytree': 0.82, 'min_child_samples': 35,
                     'reg_alpha': 0.4, 'reg_lambda': 2.2, 'min_split_gain': 0.12},
        'random_forest': {'n_estimators': 180, 'max_depth': 5,
                          'min_samples_leaf': 12, 'min_samples_split': 24,
                          'max_features': 0.6},
        'neural_net': {'hidden': (48, 24, 12), 'alpha': 0.012,
                       'lr': 0.0016, 'max_iter': 280},
    },
    # Trial 7: heavy ensemble (more trees, slightly deeper)
    {
        'xgboost': {'n_estimators': 220, 'max_depth': 4, 'learning_rate': 0.045,
                    'subsample': 0.78, 'colsample_bytree': 0.78,
                    'min_child_weight': 9, 'reg_alpha': 0.6, 'reg_lambda': 2.8,
                    'gamma': 0.55},
        'lightgbm': {'n_estimators': 220, 'max_depth': 4, 'learning_rate': 0.045,
                     'num_leaves': 14, 'subsample': 0.78,
                     'colsample_bytree': 0.78, 'min_child_samples': 42,
                     'reg_alpha': 0.6, 'reg_lambda': 2.8, 'min_split_gain': 0.18},
        'random_forest': {'n_estimators': 220, 'max_depth': 6,
                          'min_samples_leaf': 10, 'min_samples_split': 20,
                          'max_features': 0.55},
        'neural_net': {'hidden': (56, 28), 'alpha': 0.014,
                       'lr': 0.0014, 'max_iter': 320},
    },
    # Trial 8: minimal complexity (strongest anti-overfit)
    {
        'xgboost': {'n_estimators': 100, 'max_depth': 2, 'learning_rate': 0.1,
                    'subsample': 0.88, 'colsample_bytree': 0.88,
                    'min_child_weight': 20, 'reg_alpha': 1.2, 'reg_lambda': 6.0,
                    'gamma': 1.2},
        'lightgbm': {'n_estimators': 100, 'max_depth': 2, 'learning_rate': 0.1,
                     'num_leaves': 5, 'subsample': 0.88,
                     'colsample_bytree': 0.88, 'min_child_samples': 70,
                     'reg_alpha': 1.2, 'reg_lambda': 6.0, 'min_split_gain': 0.4},
        'random_forest': {'n_estimators': 120, 'max_depth': 3,
                          'min_samples_leaf': 25, 'min_samples_split': 50,
                          'max_features': 'sqrt'},
        'neural_net': {'hidden': (16, 8), 'alpha': 0.08,
                       'lr': 0.004, 'max_iter': 180},
    },
    # V19 Trial 9: stump-heavy with strong class-balance handling
    {
        'xgboost': {'n_estimators': 260, 'max_depth': 2, 'learning_rate': 0.045,
                    'subsample': 0.82, 'colsample_bytree': 0.86,
                    'min_child_weight': 9, 'reg_alpha': 0.55, 'reg_lambda': 3.2,
                    'gamma': 0.35},
        'lightgbm': {'n_estimators': 260, 'max_depth': 2, 'learning_rate': 0.045,
                     'num_leaves': 7, 'subsample': 0.82,
                     'colsample_bytree': 0.86, 'min_child_samples': 45,
                     'reg_alpha': 0.55, 'reg_lambda': 3.2, 'min_split_gain': 0.15},
        'random_forest': {'n_estimators': 220, 'max_depth': 4,
                          'min_samples_leaf': 18, 'min_samples_split': 36,
                          'max_features': 0.6},
        'extra_trees': {'n_estimators': 180, 'max_depth': 4,
                        'min_samples_leaf': 18, 'max_features': 'sqrt'},
        'hist_gb': {'max_iter': 140, 'learning_rate': 0.05, 'max_leaf_nodes': 8,
                    'min_samples_leaf': 35, 'l2': 2.2},
        'neural_net': {'hidden': (24, 12), 'alpha': 0.03, 'lr': 0.0022, 'max_iter': 260},
    },
    # V19 Trial 10: wider subsampling + heavy regularization (diversity focus)
    {
        'xgboost': {'n_estimators': 180, 'max_depth': 3, 'learning_rate': 0.06,
                    'subsample': 0.72, 'colsample_bytree': 0.62,
                    'min_child_weight': 14, 'reg_alpha': 0.9, 'reg_lambda': 4.5,
                    'gamma': 0.8},
        'lightgbm': {'n_estimators': 180, 'max_depth': 3, 'learning_rate': 0.06,
                     'num_leaves': 9, 'subsample': 0.72,
                     'colsample_bytree': 0.62, 'min_child_samples': 55,
                     'reg_alpha': 0.9, 'reg_lambda': 4.5, 'min_split_gain': 0.25},
        'random_forest': {'n_estimators': 160, 'max_depth': 5,
                          'min_samples_leaf': 14, 'min_samples_split': 28,
                          'max_features': 0.5},
        'extra_trees': {'n_estimators': 200, 'max_depth': 5,
                        'min_samples_leaf': 12, 'max_features': 0.5},
        'hist_gb': {'max_iter': 120, 'learning_rate': 0.06, 'max_leaf_nodes': 10,
                    'min_samples_leaf': 30, 'l2': 3.0},
        'neural_net': {'hidden': (32, 16), 'alpha': 0.02, 'lr': 0.0018, 'max_iter': 300},
    },
]


def make_hp_grid(n: int = 24, seed: int = 1) -> list:
    """Random hyper-parameter search space (every `seed` gives a NEW set).

    The fixed HP_GRID has only 8 entries, so hours of training would just repeat
    them. Here every round samples fresh, regularised configurations. Round 1
    (seed == 1) starts with the proven baseline entries so a first run is never
    worse than before. Ranges stay in the "shallow + strong regularisation"
    region because deep models overfit noisy financial labels.
    """
    import random
    n = max(1, int(n))
    rng = random.Random(int(seed) * 7919 + 13)
    grid = [copy_params(p) for p in HP_GRID[:min(n, len(HP_GRID))]] if int(seed) == 1 else []
    while len(grid) < n:
        depth = rng.choice([2, 3, 3, 4, 4, 5])
        lr = round(rng.uniform(0.025, 0.09), 4)
        n_est = rng.choice([120, 160, 200, 260, 320])
        sub = round(rng.uniform(0.65, 0.9), 2)
        col = round(rng.uniform(0.55, 0.9), 2)
        grid.append({
            'xgboost': {'n_estimators': n_est, 'max_depth': depth, 'learning_rate': lr,
                        'subsample': sub, 'colsample_bytree': col,
                        'min_child_weight': rng.choice([5, 8, 10, 15, 20]),
                        'reg_alpha': round(rng.uniform(0.1, 1.5), 2),
                        'reg_lambda': round(rng.uniform(1.0, 6.0), 2),
                        'gamma': round(rng.uniform(0.1, 1.2), 2)},
            'lightgbm': {'n_estimators': n_est, 'max_depth': depth, 'learning_rate': lr,
                         'num_leaves': rng.choice([5, 8, 12, 16, 20]),
                         'subsample': sub, 'colsample_bytree': col,
                         'min_child_samples': rng.choice([30, 40, 50, 60, 80]),
                         'reg_alpha': round(rng.uniform(0.1, 1.5), 2),
                         'reg_lambda': round(rng.uniform(1.0, 6.0), 2),
                         'min_split_gain': round(rng.uniform(0.05, 0.4), 2)},
            'random_forest': {'n_estimators': rng.choice([100, 150, 200, 250]),
                              'max_depth': rng.choice([3, 4, 5, 6, 7]),
                              'min_samples_leaf': rng.choice([8, 10, 15, 20, 25]),
                              'min_samples_split': rng.choice([16, 24, 30, 40, 50]),
                              'max_features': rng.choice(['sqrt', 0.5, 0.6, 0.7])},
            'extra_trees': {'n_estimators': rng.choice([120, 180, 240]),
                            'max_depth': rng.choice([4, 5, 6, 7]),
                            'min_samples_leaf': rng.choice([8, 10, 15, 20]),
                            'max_features': rng.choice(['sqrt', 0.5])},
            'hist_gb': {'max_iter': rng.choice([100, 140, 180]),
                        'learning_rate': round(rng.uniform(0.03, 0.09), 3),
                        'max_leaf_nodes': rng.choice([8, 12, 15, 20]),
                        'min_samples_leaf': rng.choice([20, 30, 40, 60]),
                        'l2': round(rng.uniform(0.5, 4.0), 2)},
            'neural_net': {'hidden': rng.choice([(16, 8), (24, 12), (32, 16), (48, 24), (40, 20, 10)]),
                           'alpha': round(rng.uniform(0.005, 0.08), 4),
                           'lr': round(rng.uniform(0.001, 0.004), 4),
                           'max_iter': rng.choice([180, 250, 320])},
        })
    return grid[:n]


def copy_params(p: dict) -> dict:
    import copy
    return copy.deepcopy(p)


def _raw_positions(frame: pd.DataFrame) -> np.ndarray:
    """Return immutable raw-candle positions carried by feature indexes."""
    try:
        values = frame.index.to_numpy(dtype=int)
    except (TypeError, ValueError) as exc:
        raise ValueError('feature index must preserve raw candle positions') from exc
    if len(values) and (np.diff(values) <= 0).any():
        raise ValueError('raw candle positions must be strictly increasing')
    return values


def _label_end_array(features: pd.DataFrame) -> np.ndarray:
    """Resolve each row's actual Triple-Barrier end position.

    Older callers without V22 metadata get a conservative fixed-horizon
    fallback. New build_features() outputs carry exact first-touch/timeout bars.
    """
    positions = _raw_positions(features)
    meta = features.attrs.get('v22_label_metadata') or {}
    end_map = (meta.get('label_end_positions')
               or features.attrs.get('label_end_positions') or {})
    if isinstance(end_map, dict) and end_map:
        return np.asarray([end_map.get(int(pos), np.nan) for pos in positions], dtype=float)
    return positions.astype(float) + float(TB_HORIZON)


def align_indicators_to_splits(ind_train: pd.DataFrame,
                                X_val: pd.DataFrame,
                                X_te: pd.DataFrame):
    """Align indicator rows by raw candle position, never by compressed length."""
    def take(split: pd.DataFrame, label: str) -> pd.DataFrame:
        if split.empty:
            return ind_train.iloc[0:0].copy()
        positions = _raw_positions(split)
        if positions.min() in ind_train.index and positions.max() in ind_train.index:
            aligned = ind_train.loc[positions].copy()
        else:
            # Legacy fallback for frames whose indexes are a simple RangeIndex.
            if positions.min() < 0 or positions.max() >= len(ind_train):
                raise IndexError(f'{label} raw positions fall outside indicator rows')
            aligned = ind_train.iloc[positions].copy()
        if len(aligned) != len(split):
            raise RuntimeError(f'{label} indicator alignment length mismatch')
        return aligned

    return take(X_val, 'validation'), take(X_te, 'test')


def temporal_split(features: pd.DataFrame, y: pd.Series,
                   train_frac=0.70, val_frac=0.15,
                   embargo: int = TB_HORIZON, return_details: bool = False):
    """Chronological split using raw bars and actual label intervals.

    Purge removes any sample whose [entry_pos, label_end_pos] interval crosses
    the next segment boundary. Embargo additionally skips the first N raw bars
    after each boundary. Neutral/ambiguous labels remain in the timeline and
    therefore cannot compress time or make a false 12-row purge.
    """
    if not isinstance(features, pd.DataFrame) or not isinstance(y, pd.Series):
        raise TypeError('features must be a DataFrame and y must be a Series')
    if len(features) != len(y) or not features.index.equals(y.index):
        y = y.reindex(features.index)
    positions = _raw_positions(features)
    if len(positions) < 10:
        raise ValueError('not enough raw candle rows for temporal split')
    if not (0.0 < float(train_frac) < 1.0 and
            0.0 < float(val_frac) < 1.0 and train_frac + val_frac < 1.0):
        raise ValueError('invalid temporal split fractions')
    embargo = max(0, int(embargo))
    meta = features.attrs.get('v22_label_metadata') or {}
    raw_start = int(meta.get('raw_start_pos', positions.min()))
    raw_end = int(meta.get('raw_end_pos', positions.max()))
    span = raw_end - raw_start + 1
    train_boundary = raw_start + int(span * float(train_frac))
    val_boundary = raw_start + int(span * float(train_frac + val_frac))
    label_ends = _label_end_array(features)
    y_num = pd.to_numeric(y, errors='coerce')
    valid = y_num.notna().to_numpy()

    train_mask = ((positions < train_boundary) &
                  np.isfinite(label_ends) & (label_ends < train_boundary) & valid)
    val_start = train_boundary + embargo
    val_mask = ((positions >= val_start) & (positions < val_boundary) &
                np.isfinite(label_ends) & (label_ends < val_boundary) & valid)
    test_start = val_boundary + embargo
    test_mask = ((positions >= test_start) & np.isfinite(label_ends) &
                 (label_ends <= raw_end) & valid)

    X_tr, y_tr = features.loc[train_mask].copy(), y_num.loc[train_mask].astype(int).copy()
    X_val, y_val = features.loc[val_mask].copy(), y_num.loc[val_mask].astype(int).copy()
    X_te, y_te = features.loc[test_mask].copy(), y_num.loc[test_mask].astype(int).copy()

    details = {
        'raw_start_pos': raw_start, 'raw_end_pos': raw_end,
        'train_boundary_pos': train_boundary,
        'validation_boundary_pos': val_boundary,
        'validation_start_pos': val_start,
        'test_start_pos': test_start,
        'embargo_bars': embargo,
        'train_features_full': features.loc[positions < train_boundary].copy(),
        'validation_features_full': features.loc[(positions >= val_start) &
                                                  (positions < val_boundary)].copy(),
        'test_features_full': features.loc[positions >= test_start].copy(),
        'train_purged_count': int(np.sum((positions < train_boundary) & valid &
                                         (~np.isfinite(label_ends) | (label_ends >= train_boundary)))),
        'validation_purged_count': int(np.sum((positions >= val_start) &
                                              (positions < val_boundary) & valid &
                                              (~np.isfinite(label_ends) | (label_ends >= val_boundary)))),
        'train_label_count': int(train_mask.sum()),
        'validation_label_count': int(val_mask.sum()),
        'test_label_count': int(test_mask.sum()),
        'label_interval_policy': 'purge_by_actual_label_end_pos_plus_embargo',
    }
    if return_details:
        return X_tr, y_tr, X_val, y_val, X_te, y_te, details
    return X_tr, y_tr, X_val, y_val, X_te, y_te


def _purged_inner_split(X: pd.DataFrame, y: pd.Series,
                        embargo: int = TB_HORIZON, train_frac: float = 0.80):
    """Create an early-stopping split that also respects actual label ends."""
    if X.empty:
        return X.copy(), y.iloc[0:0].copy(), X.copy(), y.iloc[0:0].copy()
    positions = _raw_positions(X)
    cut = int(positions.min() + (positions.max() - positions.min() + 1) * train_frac)
    ends = _label_end_array(X)
    yy = pd.to_numeric(y.reindex(X.index), errors='coerce')
    valid = yy.notna().to_numpy() & np.isfinite(ends)
    fit_mask = (positions < cut) & (ends < cut) & valid
    val_mask = (positions >= cut + max(0, int(embargo))) & valid
    return (X.loc[fit_mask].copy(), yy.loc[fit_mask].astype(int).copy(),
            X.loc[val_mask].copy(), yy.loc[val_mask].astype(int).copy())


def walk_forward_eval(features: pd.DataFrame, y: pd.Series, params: dict,
                      n_folds=4, embargo: int = TB_HORIZON) -> float:
    """Expanding-window evaluation purged by each sample's actual label end."""
    if len(features) < 600:
        return 0.0
    positions = _raw_positions(features)
    raw_start, raw_end = int(positions.min()), int(positions.max())
    span = raw_end - raw_start + 1
    fold_size = span // (int(n_folds) + 1)
    ends = _label_end_array(features)
    yy = pd.to_numeric(y.reindex(features.index), errors='coerce')
    accs = []
    for f in range(1, int(n_folds) + 1):
        boundary = raw_start + f * fold_size
        test_start = boundary + max(0, int(embargo))
        test_end = min(raw_start + (f + 1) * fold_size, raw_end + 1)
        train_mask = (positions < boundary) & np.isfinite(ends) & (ends < boundary) & yy.notna().to_numpy()
        test_mask = ((positions >= test_start) & (positions < test_end) & yy.notna().to_numpy())
        X_tr, y_tr = features.loc[train_mask], yy.loc[train_mask].astype(int)
        X_te, y_te = features.loc[test_mask], yy.loc[test_mask].astype(int)
        if len(X_tr) < 200 or len(X_te) < 50:
            continue
        model = TradingEnsemble()
        try:
            model.fit(X_tr, y_tr, params=params)
            accs.append(accuracy_score(y_te, model.predict(X_te)))
        except Exception:
            continue
    return float(np.mean(accs)) if accs else 0.0


def walk_forward_full(features: pd.DataFrame, y: pd.Series,
                      ind: pd.DataFrame, params: dict, n_folds=4,
                      embargo: int = TB_HORIZON):
    """Leakage-aware walk-forward predictions on a contiguous raw-bar timeline.

    Probabilities are emitted for every bar in each test window, including bars
    whose labels are neutral/ambiguous. Such labels stay NaN for calibration,
    while the full OHLC path remains available to the trade simulator.
    """
    positions = _raw_positions(features)
    if len(positions) < 600 or len(ind) != len(features):
        return 0.0, np.array([]), np.array([]), pd.DataFrame()
    if not ind.index.equals(features.index):
        ind = ind.reindex(features.index)
    raw_start, raw_end = int(positions.min()), int(positions.max())
    span = raw_end - raw_start + 1
    fold_size = span // (int(n_folds) + 1)
    if fold_size < 50:
        return 0.0, np.array([]), np.array([]), pd.DataFrame()
    embargo = max(0, int(embargo))
    ends = _label_end_array(features)
    y_all = pd.to_numeric(y.reindex(features.index), errors='coerce')
    oof_start = min(raw_end + 1, raw_start + fold_size + embargo)
    oof_positions = np.arange(oof_start, raw_end + 1, dtype=int)
    oof_probs = np.full(len(oof_positions), np.nan, dtype=float)
    oof_y = y_all.reindex(oof_positions).to_numpy(dtype=float)
    if len(oof_positions) == 0:
        return 0.0, np.array([]), np.array([]), pd.DataFrame()
    oof_ind = ind.reindex(oof_positions).copy()
    oof_index = {int(pos): i for i, pos in enumerate(oof_positions)}
    fold_accs = []

    def run_fold(f):
        boundary = raw_start + f * fold_size
        test_start = boundary + embargo
        test_end = min(raw_start + (f + 1) * fold_size, raw_end + 1)
        if test_end - test_start < 30:
            return None
        train_mask = ((positions < boundary) & np.isfinite(ends) &
                      (ends < boundary) & y_all.notna().to_numpy())
        X_train_all = features.loc[train_mask]
        y_train_all = y_all.loc[train_mask].astype(int)
        if len(X_train_all) < 200:
            return None
        X_fit, y_fit, X_early, y_early = _purged_inner_split(
            X_train_all, y_train_all, embargo=embargo, train_frac=0.85)
        if len(X_fit) < 150:
            return None
        model = TradingEnsemble()
        try:
            if len(X_early) >= 30 and y_early.nunique() >= 2:
                model.fit(X_fit, y_fit, X_val=X_early, y_val=y_early,
                          params=params, use_stacking=False, parallel=True)
            else:
                model.fit(X_train_all, y_train_all, params=params,
                          use_stacking=False, parallel=True)
            test_positions = np.arange(test_start, test_end, dtype=int)
            X_test_all = features.reindex(test_positions)
            if X_test_all.isna().all(axis=1).any():
                return None
            probs = model.predict_proba_array(X_test_all)
            y_test = y_all.reindex(test_positions)
            valid_test = y_test.notna().to_numpy()
            fold_acc = None
            if valid_test.sum() >= 20:
                preds = (np.asarray(probs)[valid_test] >= 0.5).astype(int)
                fold_acc = float(accuracy_score(y_test.to_numpy()[valid_test].astype(int), preds))
            return int(f), test_positions, np.asarray(probs, dtype=float), fold_acc
        except Exception:
            return None

    results = {}
    with ThreadPoolExecutor(max_workers=min(max(1, int(n_folds)), PAR_WORKERS)) as executor:
        futures = {executor.submit(run_fold, f): f
                   for f in range(1, int(n_folds) + 1)}
        for future in as_completed(futures):
            fold = futures[future]
            try:
                results[fold] = future.result()
            except Exception:
                results[fold] = None

    for fold in sorted(results):
        result = results[fold]
        if result is None:
            continue
        _, test_positions, probs, fold_acc = result
        for pos, prob in zip(test_positions, probs):
            slot = oof_index.get(int(pos))
            if slot is not None:
                oof_probs[slot] = float(prob)
        if fold_acc is not None:
            fold_accs.append(fold_acc)

    acc = float(np.mean(fold_accs)) if fold_accs else 0.0
    return acc, oof_probs, oof_y, oof_ind


def champion_gate(champion, champ_meta: dict, challenger, features: pd.DataFrame,
                  X_te: pd.DataFrame, y_te: pd.Series, ind_te: pd.DataFrame,
                  challenger_thr: float, X_test_timeline: pd.DataFrame | None = None,
                  ind_test_timeline: pd.DataFrame | None = None,
                  market: str = 'spot') -> dict:
    """Champion / challenger comparison on bars NEITHER model has trained on.

    Both models were trained only on data before their own test windows, so every
    bar at or after max(champion test start, challenger test start) is unseen by
    both. The challenger replaces the champion unless it is clearly worse
    (balanced accuracy more than 1 point lower, or log-loss more than 0.005
    higher). A model with a confirmed out-of-sample edge is also never replaced by
    one without it unless the challenger's log-loss is clearly better.
    """
    from sklearn.metrics import log_loss
    info = {'promote': True, 'compared': False, 'n': 0, 'message': ''}
    if champion is None or not getattr(champion, 'is_fitted', False):
        info['message'] = 'مدل قبلی قابل بارگذاری نبود؛ مدل جدید ذخیره می‌شود.'
        return info
    start_ts = (champ_meta or {}).get('test_start_ts')
    if start_ts is None or 't' not in ind_te.columns:
        info.update(promote=False, message='نقطه‌ی شروع آزمون خارج‌ازنمونه‌ی مدل قبلی موجود نیست؛ برای جلوگیری از جایگزینی کورکورانه، مدل قبلی حفظ شد.')
        return info
    timeline_X = X_test_timeline if isinstance(X_test_timeline, pd.DataFrame) else X_te
    timeline_ind = ind_test_timeline if isinstance(ind_test_timeline, pd.DataFrame) else ind_te
    if 't' not in timeline_ind.columns or 't' not in ind_te.columns:
        info.update(promote=False, message='timestamp برای مقایسه‌ی خارج‌ازنمونه موجود نیست؛ مدل قبلی حفظ شد.')
        return info
    # Classification metrics use only mature labeled rows. Trade simulation
    # uses the full contiguous OHLC timeline, including neutral/ambiguous bars.
    valid_ind = ind_te.reindex(X_te.index)
    mask = valid_ind['t'].to_numpy(dtype=float) >= int(start_ts)
    n = int(mask.sum())
    info['n'] = n
    if n < 100:
        info.update(promote=False, message=f'فقط {n} نمونه‌ی برچسب‌دارِ دیده‌نشده برای مقایسه وجود دارد؛ برای جلوگیری از جایگزینی با شواهد ناکافی، مدل قبلی حفظ شد.')
        return info
    try:
        idx = X_te.index[mask]
        y_c = np.asarray(y_te)[mask].astype(int)
        Xn = X_te.loc[idx]
        Xc = features.loc[idx, champion.feature_names]
        timeline_mask = timeline_ind['t'].to_numpy(dtype=float) >= int(start_ts)
        timeline_ind_c = timeline_ind.iloc[np.flatnonzero(timeline_mask)].reset_index(drop=True)
        timeline_X_c = timeline_X.iloc[np.flatnonzero(timeline_mask)]
        res = {}
        for name, model, Xm, thr in (
                ('champion', champion, Xc, float((champ_meta or {}).get('best_threshold') or 0.60)),
                ('challenger', challenger, Xn, float(challenger_thr))):
            probs = model.predict_proba_array(Xm)
            if name == 'champion':
                sim_X = timeline_X_c[model.feature_names]
            else:
                sim_X = timeline_X_c[model.feature_names]
            sim_probs = model.predict_proba_array(sim_X)
            sim = simulate_trades(sim_probs, timeline_ind_c, thr=thr, market=market)
            res[name] = {
                'balanced_acc': float(balanced_accuracy_score(y_c, (probs >= 0.5).astype(int))),
                'log_loss': float(log_loss(y_c, np.clip(probs, 1e-4, 1 - 1e-4), labels=[0, 1])),
                'trades': sim['n_trades'], 'win_rate': sim['win_rate'],
                'net_expectancy_pct': sim.get('net_expectancy_pct', 0.0),
            }
    except Exception as exc:  # preserve the working model if comparison is uncertain
        info.update(promote=False, message=f'مقایسه با مدل قبلی ناموفق بود ({exc})؛ به‌جای ریسک جایگزینی، مدل قبلی حفظ شد.')
        return info
    ch, cp = res['challenger'], res['champion']
    ok_acc = ch['balanced_acc'] >= cp['balanced_acc'] - 0.01
    ok_ll = ch['log_loss'] <= cp['log_loss'] + 0.005
    keeps_edge = True
    if (champ_meta or {}).get('edge_confirmed') and ch['log_loss'] > cp['log_loss'] - 0.003:
        keeps_edge = bool(challenger_thr is not None and ch['trades'] >= 10
                          and ch['net_expectancy_pct'] >= cp['net_expectancy_pct'] - 0.02)
    promote = bool(ok_acc and ok_ll and keeps_edge)
    info.update(promote=promote, compared=True, champion=cp, challenger=ch)
    info['message'] = (
        f"مقایسه روی {n} کندل دیده‌نشده: دقت متوازن مدل قبلی {cp['balanced_acc']*100:.1f}٪ "
        f"در برابر مدل جدید {ch['balanced_acc']*100:.1f}٪ | لاگ‌لاس {cp['log_loss']:.4f} در برابر {ch['log_loss']:.4f} → "
        + ('مدل جدید جایگزین شد.' if promote else 'مدل قبلی نگه داشته شد (مدل جدید بهتر نبود).'))
    return info




def validate_training_batch(df: pd.DataFrame, symbol: str, timeframe: str,
                            source: str = 'unknown') -> tuple[pd.DataFrame, dict]:
    """Apply the strict V22 training gate to downloaded or caller-supplied OHLCV."""
    from .data_contract import validate_candles, DataContractError
    audit = dict(getattr(df, 'attrs', {}).get('normalization_audit') or {})
    result = validate_candles(df, symbol=symbol, timeframe=timeframe,
                              source=source, mode='research')
    # Chronological sorting and removal of byte-for-byte duplicate candles are
    # safe normalization. Training still rejects malformed rows and conflicting
    # OHLCV values sharing a timestamp.
    malformed_dropped = int(audit.get('malformed_rows_dropped', 0) or 0)
    duplicate_conflicts = int(audit.get('duplicate_conflict_groups', 0) or 0)
    hidden_bad = malformed_dropped + duplicate_conflicts
    if hidden_bad:
        raise DataContractError(
            f"آموزش متوقف شد؛ نرمال‌ساز {hidden_bad} ردیف معیوب/دارای OHLCV متعارض را حذف کرده است")
    if audit.get('missing_volume_rows') or not result.report.get('volume_available', True):
        raise DataContractError(
            'آموزش متوقف شد؛ داده حجم ناقص است و V21 از ویژگی‌های مبتنی بر حجم استفاده می‌کند')
    if result.status != 'PASS':
        raise DataContractError(
            'آموزش متوقف شد؛ Data Contract فقط PASS را می‌پذیرد: ' +
            '; '.join(result.report.get('warnings', []) + result.report.get('block_reasons', [])))
    clean = result.require_pass()
    clean.attrs.update(getattr(df, 'attrs', {}))
    clean.attrs['data_contract'] = result.report
    return clean, result.report

class TrainingSession:
    """Holds training state and progress callbacks."""

    def __init__(self):
        self.progress_log = []
        self.is_running = False
        self.cancel = False
        self.last_result = None

    def log(self, msg: str):
        ts = time.strftime('%H:%M:%S')
        line = f"[{ts}] {msg}"
        self.progress_log.append(line)
        return line

    def run(self, symbol: str, timeframe: str, limit: int = 3000,
            source: str = 'auto', custom_dir: str = None, df=None,
            hp_grid: list = None, n_folds: int = 4, n_seeds: int = None,
            gate: bool = False, seed_from: tuple = None, quick: bool = False) -> dict:
        """
        Full training pipeline.
        df       : pre-fetched candles (skips the download step)
        hp_grid  : custom list of hyper-parameter sets (default: the 8 fixed ones)
        n_folds  : walk-forward folds
        n_seeds  : XGBoost/LightGBM seeds in the final model
        gate     : champion/challenger — keep the saved model if the new one is
                   not at least as good on bars NEITHER model has trained on.
        Returns dict with results, or raises on error.
        """
        grid = list(hp_grid) if hp_grid else HP_GRID
        # V21: quick transfer mode = few trials/folds, warm-started from a neighbour's model.
        seed_model = None
        if seed_from:
            try:
                from .storage import model_path as _mp
                sm = TradingEnsemble.load(_mp(seed_from[0], seed_from[1], custom_dir))
                if (sm is not None and sm.is_fitted and sm.feature_names
                        and not model_path(symbol, timeframe, custom_dir).exists()):
                    seed_model = sm            # only for a market with NO model of its own
            except Exception:
                seed_model = None
            if seed_model is not None:
                # Transfer the neighbour's proven hyper-parameters as the FIRST trial.
                try:
                    bp = (load_meta(seed_from[0], seed_from[1], custom_dir) or {}).get('best_params')
                    if isinstance(bp, dict) and set(bp) == set(HP_GRID[0]):
                        grid = [bp] + [g for g in grid if g != bp]
                except Exception:
                    pass
        if quick:
            grid = list(grid)[:2]
            n_folds = 2
            n_seeds = 1
        n_seeds = int(n_seeds) if n_seeds else FINAL_N_SEEDS
        n_folds = max(2, int(n_folds))
        if self.is_running:
            raise RuntimeError("آموزش دیگری در حال اجراست")
        self.is_running = True
        self.cancel = False
        self.progress_log = []
        start_time = time.time()
        step_times = {}
        from .experiment_registry import start_experiment, finish_experiment
        _registry_experiment = None

        try:
            # Time estimate so the user knows how long to wait
            est_sec = estimate_train_time(limit)
            self.log(f"⏱ زمان تقریبی این آموزش: حدود {est_sec // 60} دقیقه "
                     f"(بسته به سرعت سیستم بین {max(1, int(est_sec*0.7) // 60)} "
                     f"تا {int(est_sec*1.5) // 60} دقیقه)")

            # === STEP 1: Fetch data ===
            t_step = time.time()
            self.log(f"۱. دریافت داده‌های {symbol} تایم‌فریم {timeframe}...")
            def data_progress(msg):
                self.log(f"   {msg}")
            if df is None:
                df = fetch_candles(symbol, timeframe, limit=limit,
                                   source=source, progress_cb=data_progress,
                                   validation_mode='research')
            elif 'source' not in df.attrs:
                df.attrs['source'] = source

            # Re-validate at the training boundary (including caller-supplied
            # frames). Training is stricter than chart/research display: WARN is
            # not accepted because gaps or synthetic volume can corrupt labels.
            data_source = str(df.attrs.get('source', source or 'unknown'))
            df, contract_report = validate_training_batch(
                df, symbol=symbol, timeframe=timeframe, source=data_source)
            df.attrs['source'] = data_source
            self.data_contract_report = contract_report
            step_times['fetch'] = round(time.time() - t_step, 1)
            self.log(f"   ✓ {len(df)} کندل دریافت شد از {data_source}")
            self.log(f"   ✓ Data Contract {contract_report['contract_version']}: PASS | حجم معتبر | بدون شکاف")
            # Hash the exact validated candle batch, not merely the requested window.
            try:
                _data_for_hash = df[[c for c in ('t','o','h','l','c','v') if c in df.columns]].to_dict('list')
                _registry_experiment = start_experiment(
                    'V22-H003', symbol=symbol, timeframe=timeframe,
                    data_hash=__import__('hashlib').sha256(json.dumps(_data_for_hash, sort_keys=True, default=str).encode()).hexdigest(),
                    config={'limit':limit,'source':data_source,'hp_grid':grid,'n_folds':n_folds,'n_seeds':n_seeds,'quick':quick,'protocol':TRAINING_PROTOCOL_VERSION},
                    seed=None, challenger_version=TRAINING_PROTOCOL_VERSION, custom_dir=custom_dir)
            except Exception as _registry_error:
                self.log(f"⚠ ثبت Experiment انجام نشد: {_registry_error}")

            if self.cancel:
                raise RuntimeError("لغو شد")

            # === STEP 2: Build features ===
            t_step = time.time()
            self.log("۲. ساخت ویژگی‌ها از ۳۵+ اندیکاتور (برچسب Triple-Barrier)...")
            (features, y, raw_ret, last_row, ind_train,
             features_full, ind_full, y_raw, raw_ret_full,
             amb_full) = build_features(df)
            from .data import is_futures_symbol
            market = 'perp' if is_futures_symbol(symbol) else 'spot'
            funding_audit = {'market': 'spot', 'funding_events': 0, 'status': 'NOT_APPLICABLE'}
            if market == 'perp':
                self.log('   دریافت و اعتبارسنجی Funding تسویه‌شده برای بک‌تست Perpetual...')
                ind_full, funding_audit = attach_realized_perp_funding(
                    ind_full, symbol=symbol, timeframe=timeframe,
                    source=str(df.attrs.get('source', source or 'unknown')))
                self.log(f"   ✓ Funding: {funding_audit['funding_events']} رویداد معتبر از {funding_audit['exchange']}")
            n_features = features.shape[1]
            step_times['features'] = round(time.time() - t_step, 1)
            self.log(f"   ✓ {len(features)} نمونه‌ی آموزش × {n_features} ویژگی")
            n_amb = int(amb_full.sum())
            self.log(f"   ✓ فیلتر نویز: {len(features_full) - len(features)} نمونه حذف شد "
                     f"(خنثی + {n_amb} نمونه‌ی مبهم TP/SL هم‌زمان)")
            self.log(f"   ✓ توزیع کلاس: up={int(y.sum())} ({y.mean()*100:.1f}%)")

            if len(features) < 500:
                raise RuntimeError(f"داده کافی نیست: فقط {len(features)} نمونه")

            if self.cancel:
                raise RuntimeError("لغو شد")

            # === STEP 3: Split ===
            self.log("۳. تقسیم زمانی: آموزش ۷۰٪ / اعتبارسنجی ۱۵٪ / تست ۱۵٪...")
            (X_tr, y_tr, X_val, y_val, X_te, y_te,
             split_info) = temporal_split(features_full, y_raw,
                                          embargo=TB_HORIZON, return_details=True)
            self.log(f"   آموزش: {len(X_tr)} | اعتبارسنجی: {len(X_val)} | تست: {len(X_te)}")
            self.log(f"   ✓ Purge بر اساس label_end_t + embargo {TB_HORIZON} کندل؛ "
                     f"حذف مرزی train={split_info['train_purged_count']} و "
                     f"validation={split_info['validation_purged_count']}")

            # Simulations use EVERY raw candle, including neutral/ambiguous rows.
            # Filtering labels must never compress the price path used for fills.
            X_val_full = split_info['validation_features_full']
            X_te_full = split_info['test_features_full']
            ind_va = ind_full.reindex(X_val_full.index).copy()
            ind_te = ind_full.reindex(X_te_full.index).copy()
            if len(ind_va) != len(X_val_full) or len(ind_te) != len(X_te_full):
                raise RuntimeError('هم‌ترازی timeline بک‌تست با کندل‌های خام ناموفق بود')
            self.log(f"   ✓ مسیر پیوسته‌ی بک‌تست: validation={len(ind_va)} و test={len(ind_te)} کندل خام")

            test_start_ts = None
            if len(ind_te) and 't' in ind_te.columns:
                test_start_ts = int(ind_te['t'].iloc[0])

            if self.cancel:
                raise RuntimeError("لغو شد")

            # === STEP 4: Feature selection (importance + correlation pruning) ===
            k = min(TOP_K_FEATURES, features.shape[1])
            # V21: never keep more features than the independent evidence can support.
            from .adequacy import assess as _assess_data
            adequacy = _assess_data(len(df), timeframe, max_features=k, train_rows=len(X_tr))
            if adequacy['recommended_features'] < k:
                self.log(f"   ⚖ نمونه‌ی مستقل ≈ {adequacy['effective_samples']} ({adequacy['level_fa']}) → "
                         f"تعداد ویژگی از {k} به {adequacy['recommended_features']} محدود شد (جلوگیری از بیش‌برازش)")
                k = adequacy['recommended_features']
            else:
                self.log(f"   ✓ نمونه‌ی مستقل ≈ {adequacy['effective_samples']} ({adequacy['level_fa']}) — "
                         "ظرفیت ویژگی کافی است")
            for note in adequacy['notes']:
                self.log(f"   ⚠ {note}")
            self.log(f"۴. انتخاب {k} ویژگی برتر از {features.shape[1]} "
                     f"+ حذف ویژگی‌های همبسته (حذف نویز)...")
            quick_rf = RandomForestClassifier(
                n_estimators=120, max_depth=6, n_jobs=JOBS_FULL, random_state=0)
            quick_rf.fit(X_tr, np.asarray(y_tr).astype(int))
            imp = pd.Series(quick_rf.feature_importances_, index=X_tr.columns)
            imp_order = list(imp.sort_values(ascending=False).index)

            # Greedy correlation pruning: keep the strongest feature of each
            # highly-correlated group (decorrelated inputs, ensemble diversity)
            n_corr_sample = min(len(X_tr), 4000)
            corr = X_tr[imp_order].iloc[:n_corr_sample].corr().abs().values
            kept, dropped = [], 0
            for i_f, feat in enumerate(imp_order):
                redundant = False
                for kf in kept:
                    j_f = imp_order.index(kf)
                    if corr[i_f, j_f] > CORR_PRUNE:
                        redundant = True
                        break
                if not redundant:
                    kept.append(feat)
                if len(kept) >= k:
                    break
            top_feats = kept
            seed_used = False
            if seed_model is not None:
                sf = list(seed_model.feature_names or [])
                if sf and all(f in X_tr.columns for f in sf):
                    top_feats = sf             # same columns, same order => booster can continue
                    seed_used = True
                    self.log(f"   ⚡ انتقال یادگیری: ویژگی‌ها از مدل {seed_from[0]}/{seed_from[1]} گرفته شد "
                             f"({len(sf)} ویژگی)")
                else:
                    self.log("   ⚠ ویژگی‌های مدل مبدأ با این داده نمی‌خواند؛ آموزش عادی انجام می‌شود.")
                    seed_model = None
            dropped = len(imp_order[:len(top_feats) + 20]) - len(top_feats)
            X_tr = X_tr[top_feats]
            X_val = X_val[top_feats]
            X_te = X_te[top_feats]
            self.log(f"   ✓ ویژگی‌های منتخب: {len(top_feats)} "
                     f"(مهم‌ترین: {top_feats[0]}, {top_feats[1]}, {top_feats[2]})")

            if self.cancel:
                raise RuntimeError("لغو شد")

            # === STEP 5: Trial-and-error hyperparameter search (PARALLEL) ===
            t_step = time.time()
            # V17.2: load the interruption checkpoint. Completed trials are
            # reused when the data window, feature selection AND the trial grid
            # are identical, so a crash mid-round no longer repeats the whole
            # search. A different grid/data invalidates the checkpoint.
            data_fp = f"{TRAINING_PROTOCOL_VERSION}|{limit}|{len(df)}|{int(df['t'].iloc[0])}|{int(df['t'].iloc[-1])}"
            grid_fp = hashlib.sha1(json.dumps(
                [{k: str(v) for k, v in p.items()} for p in grid],
                sort_keys=True, default=str).encode('utf-8')).hexdigest()
            ckpt = _load_checkpoint(symbol, timeframe)
            ckpt_ok = (isinstance(ckpt, dict)
                       and ckpt.get('data_fp') == data_fp
                       and ckpt.get('grid_fp') == grid_fp
                       and list(ckpt.get('top_feats') or []) == list(top_feats))
            reused_trials: dict = {}
            if ckpt_ok:
                reused_trials = {str(k): v for k, v in (ckpt.get('trials') or {}).items()
                                 if isinstance(v, dict)}
            elif ckpt:
                self.log("   ⚪ ایست بازرسی قبلی با داده‌ی جدید نمی‌خواند؛ دور تازه شروع می‌شود.")
            # running checkpoint store: loaded trials + every newly finished one
            ckpt_trials_all: dict = dict(reused_trials) if ckpt_ok else {}
            reused_results = [dict(reused_trials[str(i)], trial=i + 1)
                              for i in range(len(grid)) if str(i) in reused_trials]
            pending = [(i, params) for i, params in enumerate(grid)
                       if str(i) not in reused_trials]
            if reused_results:
                self.log(f"   ↩ {len(reused_results)} آزمون کامل‌شده‌ی قبلی از ایست بازرسی بازیابی شد "
                         f"(فقط {len(pending)} آزمون باقی مانده است)")

            self.log(f"۵. آزمون خطا روی {len(grid)} پیکربندی ابرپارامتر "
                     f"({PAR_WORKERS} آزمون همزمان روی {os.cpu_count() or 4} هسته)...")
            best_score = -1
            best_params = None
            best_idx = -1
            trial_results = [None] * len(grid)

            def run_trial(i, params):
                if self.cancel:
                    raise RuntimeError("لغو شد")
                t0 = time.time()
                ens = TradingEnsemble()
                ens.fit(X_tr, y_tr, X_val=X_val, y_val=y_val, params=params,
                        use_stacking=False, parallel=True)
                # honest validation metrics (log-odds pooling, no meta)
                val_metrics = ens.evaluate(X_val, y_val, use_meta=False)
                val_acc = val_metrics['accuracy']
                bal_acc = val_metrics['balanced_acc']
                hi_acc = val_metrics['high_conf_acc']
                vh_acc = val_metrics.get('very_high_conf_acc', 0)
                uh_acc = val_metrics.get('ultra_high_conf_acc', 0)
                # Simulated trade win-rate on validation (real KPI)
                probs_va = ens.predict_proba_array(X_val_full[top_feats], use_meta=False)
                sim60 = simulate_trades(probs_va, ind_va, thr=0.60, market=market)
                elapsed = time.time() - t0
                return (i, val_acc, bal_acc, hi_acc, vh_acc, uh_acc, sim60,
                        elapsed, val_metrics)

            if pending:
                with ThreadPoolExecutor(max_workers=PAR_WORKERS) as ex:
                    futs = [ex.submit(run_trial, i, params)
                            for i, params in pending]
                    n_done = 0
                    n_total = len(reused_results) + len(pending)
                    for fut in as_completed(futs):
                        n_done += 1
                        try:
                            (i, val_acc, bal_acc, hi_acc, vh_acc, uh_acc, sim60,
                             elapsed, val_metrics) = fut.result()
                        except Exception as e:
                            if str(e) == 'لغو شد':
                                raise
                            self.log(f"   ✖ یک آزمون ناموفق: {e}")
                            continue
                        trial_results[i] = {
                            'trial': i + 1,
                            'val_acc': val_acc,
                            'val_balanced': bal_acc,
                            'val_high_conf_acc': hi_acc,
                            'val_high_conf_cov': val_metrics['high_conf_cov'],
                            'val_very_high_conf_acc': vh_acc,
                            'val_very_high_conf_cov': val_metrics.get('very_high_conf_cov', 0),
                            'val_ultra_conf_acc': uh_acc,
                            'val_ultra_conf_cov': val_metrics.get('ultra_high_conf_cov', 0),
                            'sim_win_rate_60': sim60['win_rate'],
                            'sim_trades_60': sim60['n_trades'],
                            'time_sec': elapsed,
                        }
                        self.log(f"   ✓ آزمون {i+1}: دقت {(val_acc*100):.2f}% "
                                 f"| hi65: {(hi_acc*100):.1f}% | hi75: {(vh_acc*100):.1f}% "
                                 f"| hi85: {(uh_acc*100):.1f}% "
                                 f"| شبیه‌سازی thr60: برد {(sim60['win_rate']*100):.1f}% "
                                 f"روی {sim60['n_trades']} معامله | {elapsed:.1f}s "
                                 f"[{len(reused_results)+n_done}/{n_total}]")
                        # persist every finished trial so a crash cannot undo them
                        try:
                            ckpt_trials_all[str(i)] = trial_results[i]
                            _save_checkpoint(symbol, timeframe, {
                                'data_fp': data_fp, 'grid_fp': grid_fp,
                                'top_feats': list(top_feats),
                                'trials': ckpt_trials_all, 'symbol': symbol,
                                'timeframe': timeframe, 'saved_at': time.time(),
                            })
                        except Exception:
                            pass
                        hi_cov = val_metrics['high_conf_cov']
                        vh_cov = val_metrics.get('very_high_conf_cov', 0)
                        uh_cov = val_metrics.get('ultra_high_conf_cov', 0)
                        sim_bonus = 0.0
                        if sim60['n_trades'] >= 10:
                            sim_bonus = 0.6 * (sim60['win_rate'] - 0.5)
                        # Balanced accuracy receives the main weight so a skewed
                        # majority class cannot win trials by itself. High-confidence
                        # bonuses count only with meaningful coverage and enough trades.
                        score = (0.70 * bal_acc + 0.30 * val_acc
                                 + 0.20 * max(0.0, hi_acc - bal_acc) * hi_cov
                                 + 0.25 * max(0.0, vh_acc - bal_acc) * vh_cov
                                 + 0.30 * max(0.0, uh_acc - bal_acc) * uh_cov
                                 + sim_bonus)
                        if score > best_score:
                            best_score = score
                            best_params = grid[i]
                            best_idx = i

            # Merge reused trial results (checkpoint) and pick the best overall
            for r in reused_results:
                idx = int(r['trial']) - 1
                if 0 <= idx < len(trial_results) and trial_results[idx] is None:
                    trial_results[idx] = r
                    score = _trial_score(r)
                    if score > best_score:
                        best_score = score
                        best_params = grid[idx]
                        best_idx = idx

            # Drop failed trials from the results table
            trial_results = [t for t in trial_results if t is not None]

            if best_params is None:
                raise RuntimeError("هیچ پیکربندی کار نکرد")

            step_times['trials'] = round(time.time() - t_step, 1)
            self.log(f"   ✓ بهترین پیکربندی: آزمون {best_idx+1} "
                     f"(امتیاز: {best_score:.4f})")

            if self.cancel:
                raise RuntimeError("لغو شد")

            # === STEP 6: Walk-forward (leakage-free OOF, parallel folds) ===
            t_step = time.time()
            self.log(f"۶. آزمون walk-forward بدون نشتی داده "
                     f"({n_folds} فولد، {min(n_folds, PAR_WORKERS)} همزمان)...")
            wf_acc, oof_probs, oof_y, oof_ind = walk_forward_full(
                features_full[top_feats], y_raw, ind_full, best_params,
                n_folds=n_folds, embargo=TB_HORIZON)
            step_times['walk_forward'] = round(time.time() - t_step, 1)
            self.log(f"   ✓ دقت walk-forward: {(wf_acc*100):.2f}% "
                     f"(خط پایه تصادفی: 50٪)")

            if self.cancel:
                raise RuntimeError("لغو شد")

            # === STEP 7: Load existing model for warm-start, then retrain ===
            t_step = time.time()
            mp = model_path(symbol, timeframe, custom_dir)
            existing_meta = load_meta(symbol, timeframe, custom_dir)
            if existing_meta.get('feature_schema_version') == FEATURE_SCHEMA_VERSION:
                existing_model = TradingEnsemble.load(mp)
            else:
                existing_model = None
                if mp.exists():
                    self.log('   ⚠ مدل قبلی با معنای ویژگی‌های نسخه جدید سازگار نیست؛ آموزش از صفر انجام می‌شود.')
            warm_model = existing_model
            if (warm_model is None or not warm_model.is_fitted) and seed_model is not None:
                warm_model = seed_model        # transfer: NOT a champion, only a starting booster
                self.log(f"۷. آموزش نهایی با شروع از مدل {seed_from[0]}/{seed_from[1]} (انتقال یادگیری)...")
            elif existing_model is not None and existing_model.is_fitted:
                self.log(f"۷. آموزش نهایی با یادگیری تدریجی "
                         f"(دور فعلی: {existing_model.training_round + 1})...")
            else:
                self.log("۷. آموزش نهایی (آموزش اولیه)...")

            X_train_full = pd.concat([X_tr, X_val]).sort_index()
            y_train_full = pd.concat([y_tr, y_val]).sort_index()
            final_model = TradingEnsemble()
            # Internal early-stopping split is also purged by exact label ends.
            X_fit, y_fit, X_early, y_early = _purged_inner_split(
                X_train_full, y_train_full, embargo=TB_HORIZON, train_frac=0.80)
            if len(X_fit) < 200:
                raise RuntimeError('پس از purge داخلی نمونه‌ی مستقل کافی برای آموزش نهایی باقی نماند')
            if len(X_early) >= 50 and y_early.nunique() >= 2:
                final_model.fit(X_fit, y_fit, X_val=X_early, y_val=y_early,
                                params=best_params,
                                warm_start_model=warm_model,
                                n_seeds=n_seeds,
                                recency=FINAL_RECENCY)
            else:
                self.log('   ⚠ بلوک early-stopping مستقل کافی نبود؛ آموزش بدون validation داخلی انجام می‌شود.')
                final_model.fit(X_train_full, y_train_full,
                                params=best_params,
                                warm_start_model=warm_model,
                                n_seeds=n_seeds,
                                recency=FINAL_RECENCY)
            if n_seeds > 1:
                self.log(f"   ✓ Seed-Ensemble: XGBoost/LightGBM با "
                         f"{n_seeds} seed (کاهش واریانس)")
            if FINAL_RECENCY:
                self.log("   ✓ وزن‌دهی تازگی: کندل‌های جدید وزن بیشتر دارند")

            # (isotonic removed — collapsed the distribution. Sigmoid/Platt
            #  calibration fitted on leakage-free OOF probs instead, with an
            #  objective Brier-improvement guard inside fit_calibrator)
            calibrated = final_model.fit_calibrator(oof_probs, oof_y)
            if calibrated:
                self.log("   ✓ کالیبراسیون احتمال روی بخش آموزش OOF انجام شد و با بلوک زمانی جداگانه اعتبارسنجی شد")
            else:
                self.log("   ⚠ کالیبراسیون تأیید نشد؛ احتمال خام نگه داشته شد و برچسب اطمینان آن کالیبره‌شده نیست")

            # The meta-labeler must consume probabilities in the same calibrated
            # space used by inference. Train it only on the earlier OOF segment;
            # keep the final 30% for independent threshold selection below.
            t_meta = time.time()
            from .metalabel import MetaLabeler
            meta_labeler = MetaLabeler()
            meta_cut = int(len(oof_probs) * 0.70)
            if meta_cut >= 200 and len(oof_ind) >= len(oof_probs):
                from .evaluation import cost_model
                meta_costs = cost_model()
                meta_train_probs = final_model._apply_calibration(oof_probs[:meta_cut])
                meta_ok = meta_labeler.fit(meta_train_probs, oof_ind.iloc[:meta_cut].reset_index(drop=True),
                                           threshold=0.60, costs=meta_costs)
            else:
                meta_ok = False
            if meta_ok:
                # The final 30% OOF block is reserved for threshold selection only.
                # It is never used to fit the meta classifier.
                hold_probs = final_model._apply_calibration(oof_probs[meta_cut:])
                hold_ind = oof_ind.iloc[meta_cut:meta_cut+len(hold_probs)].reset_index(drop=True)
                hold_meta = np.asarray([meta_labeler.predict_meta(float(p), hold_ind.iloc[i])
                                        for i, p in enumerate(hold_probs)], dtype=float)
                meta_selection = meta_labeler.select_threshold(hold_probs, hold_meta, hold_ind,
                                                               costs=meta_costs, min_trades=20)
                if meta_selection.get('selected'):
                    final_model.meta_labeler = meta_labeler
                    final_model.meta_threshold = float(meta_labeler.threshold)
                    self.log(f"   ✓ Meta-Labeler: {meta_labeler.n_samples} نمونه آموزشی؛ آستانه {meta_labeler.threshold:.2f} روی OOF نگه‌داشته‌شده انتخاب شد")
                else:
                    meta_ok = False
                    self.log('   ⚠ بلوک OOF مستقل برای انتخاب آستانه کافی نبود؛ Meta-Labeler غیرفعال ماند')
            else:
                self.log('   ⚠ داده OOF کافی/متوازن برای Meta-Labeler نبود؛ فیلتر غیرفعال ماند')
            step_times['meta_labeling'] = round(time.time()-t_meta,1)
            step_times['final_fit'] = round(time.time() - t_step, 1)

            train_metrics = final_model.evaluate(X_train_full, y_train_full)
            test_metrics = final_model.evaluate(X_te, y_te)
            final_model.train_acc = train_metrics['accuracy']
            final_model.val_acc = test_metrics['accuracy']
            final_model.walk_forward_acc = wf_acc
            final_model.balanced_acc = test_metrics['balanced_acc']
            final_model.high_conf_acc = test_metrics['high_conf_acc']
            final_model.high_conf_cov = test_metrics['high_conf_cov']

            self.log(f"   ✓ دقت آموزش: {(train_metrics['accuracy']*100):.2f}%")
            self.log(f"   ✓ دقت تست (held-out): {(test_metrics['accuracy']*100):.2f}%")
            self.log(f"   ✓ دقت اطمینان-بالا (65%): {(test_metrics['high_conf_acc']*100):.2f}% "
                     f"({test_metrics['high_conf_cov']*100:.0f}% پوشش)")
            self.log(f"   ✓ دقت اطمینان-بالا (75%): {(test_metrics.get('very_high_conf_acc',0)*100):.2f}% "
                     f"({test_metrics.get('very_high_conf_cov',0)*100:.0f}% پوشش)")
            self.log(f"   ✓ دقت اطمینان-بسیار-بالا (85%): {(test_metrics.get('ultra_high_conf_acc',0)*100):.2f}% "
                     f"({test_metrics.get('ultra_high_conf_cov',0)*100:.0f}% پوشش)")
            self.log(f"   ✓ دقت حداکثر اطمینان (90%): {(test_metrics.get('max_conf_acc',0)*100):.2f}% "
                     f"({test_metrics.get('max_conf_cov',0)*100:.0f}% پوشش)")
            self.log(f"   ✓ هم‌رأیی مدل‌ها (اجماع): {(test_metrics.get('agree_acc',0)*100):.2f}% "
                     f"({test_metrics.get('agree_cov',0)*100:.0f}% پوشش)")

            # V20: honesty of the probability scale (ECE on the held-out test).
            calib_report = None
            try:
                calib_report = final_model.calibration_report(X_te, y_te)
                if calib_report.get('n'):
                    self.log(f"   → صداقت احتمال روی تست: ECE={(calib_report['ece']*100):.1f}% "
                             f"| Brier={calib_report['brier']:.4f}")
            except Exception:
                calib_report = None

            # V20: close the learning loop — report what the central brain has
            # measured about the PREVIOUS rounds of this exact market.
            brain_feedback = None
            try:
                brain_feedback = brain_feedback_summary(symbol, timeframe)
            except Exception:
                brain_feedback = None
            if brain_feedback:
                self.log(f"   🧠 بازخورد مغز: کانال ML این بازار در {brain_feedback['samples']} "
                         f"مشاهده‌ی بالغ‌شده {brain_feedback['hit_rate']*100:.0f}% جهتِ درست داشته "
                         f"(ضریب وزن فعلی: {brain_feedback['weight_multiplier']}×)")
            else:
                self.log("   🧠 بازخورد مغز: هنوز مشاهده‌ی بالغ‌شده‌ی کافی برای این بازار ثبت نشده است")

            if self.cancel:
                raise RuntimeError("لغو شد")

            # === STEP 8: Optimal confidence threshold via leakage-free OOF ===
            t_step = time.time()
            self.log("۸. انتخاب آستانه روی ۳۰٪ پایانی OOF (جدا از آموزش کالیبراتور و Meta-Labeler)...")
            probs_te_final = final_model.predict_proba_array(X_te_full[top_feats])

            # Baseline: with symmetric TP/SL=1.5xATR a RANDOM model wins ~50%
            best_thr, best_sim = None, None
            # Use the same calibrated probability scale as live prediction.
            oof_probs_cal = final_model._apply_calibration(oof_probs) if len(oof_probs) else np.array([])
            # Reserve the last 30% of chronological OOF predictions for threshold
            # selection. Calibration and meta-labeler fitting never see this tail.
            threshold_start = int(len(oof_probs_cal) * 0.70)
            threshold_probs = oof_probs_cal[threshold_start:]
            threshold_ind = oof_ind.iloc[threshold_start:].reset_index(drop=True) if len(oof_ind) else oof_ind
            BASELINE_WIN = ATR_SL_MULT / (ATR_TP_MULT + ATR_SL_MULT)
            for thr in THR_CANDIDATES:
                if len(threshold_probs) == 0:
                    break
                s = simulate_trades(threshold_probs, threshold_ind, thr=thr, market=market)
                # >= 30 closed trades AND Wilson lower bound above the random
                # baseline AND positive NET expectancy after costs -> a strategy
                # worth trading, not just a lucky win-rate (V19 gate).
                if (s['n_trades'] >= 30
                        and float(s.get('net_expectancy_pct', 0.0) or 0.0) > 0.0):
                    lb = _wilson_lb(s['wins'], s['n_trades'])
                    # V21: a single lucky stretch must not confirm an edge.
                    if lb > BASELINE_WIN + 0.02 and edge_consistency(
                            threshold_probs, threshold_ind, thr)['ok']:
                        if (best_sim is None or
                                _wilson_lb(s['wins'], s['n_trades']) >
                                _wilson_lb(best_sim['wins'], best_sim['n_trades'])):
                            best_thr, best_sim = thr, s
            edge_confirmed = best_thr is not None
            if not edge_confirmed:
                self.log("   → V19: گیت کیفیت استراتژی — امید ریاضی خالص مثبت هم لازم است")
            if best_thr is None:
                # no robust OOF edge: fall back to the default threshold
                best_thr = 0.60
                best_sim = {'win_rate': 0.0, 'n_trades': 0, 'wins': 0,
                            'losses': 0, 'ambiguous': 0, 'open_trades': 0,
                            'avg_win_pct': 0.0, 'avg_loss_pct': 0.0,
                            'expectancy_pct': 0.0}
                self.log("   → در بخش مستقل OOF حداقل شواهد لازم برای برتری پایدار پیدا نشد — سیگنال‌ها HOLD می‌مانند")

            consistency = (edge_consistency(threshold_probs, threshold_ind, best_thr, market=market)
                           if edge_confirmed else None)
            sim_test = simulate_trades(probs_te_final, ind_te, thr=best_thr, market=market)
            # V21: show how uncertain the held-out win rate is (small samples are noisy).
            _n = int(sim_test.get('n_trades') or 0)
            sim_test_ci = None
            if _n > 0:
                _w = int(sim_test.get('wins') or 0)
                sim_test_ci = {'n': _n, 'low': round(_wilson_lb(_w, _n), 4),
                               'high': round(1.0 - _wilson_lb(_n - _w, _n), 4)}
                self.log(f"   → بازه‌ی اطمینان ۹۵٪ نرخ برد تست: {sim_test_ci['low']*100:.0f}٪ تا "
                         f"{sim_test_ci['high']*100:.0f}٪ (روی {_n} معامله — عدد تک‌نقطه‌ای را جدی نگیر)")
            sim_test_default = simulate_trades(probs_te_final, ind_te, thr=0.60, market=market)

            # V19 strategy diagnostics: where does the edge actually live?
            # Trades from the OOF threshold segment are tagged by the trend
            # regime of their entry bar (close vs EMA20/50). This is honest,
            # per-trade attribution — informational, never a gate.
            strategy_diagnostics = {'regime_split': {}, 'expectancy_gate': 'passed' if edge_confirmed else 'failed'}
            try:
                per_trade = simulate_trades_per_trade(threshold_probs, threshold_ind, thr=best_thr)
                buckets: dict[str, list[int]] = {}
                for tr in per_trade:
                    idx = int(tr.get('idx', -1))
                    if idx < 0 or idx >= len(threshold_ind):
                        continue
                    row = threshold_ind.iloc[idx]
                    close = float(row.get('close', np.nan))
                    e20 = float(row.get('ema_20', np.nan))
                    e50 = float(row.get('ema_50', np.nan))
                    if not np.isfinite(close) or not np.isfinite(e20) or not np.isfinite(e50):
                        label = 'unknown'
                    elif close > e20 > e50:
                        label = 'uptrend'
                    elif close < e20 < e50:
                        label = 'downtrend'
                    else:
                        label = 'range'
                    buckets.setdefault(label, []).append(1 if tr.get('is_win') else 0)
                for label, results in buckets.items():
                    if results:
                        strategy_diagnostics['regime_split'][label] = {
                            'trades': len(results),
                            'win_rate': round(sum(results) / len(results), 4),
                        }
                if strategy_diagnostics['regime_split']:
                    split_txt = ' | '.join(
                        f"{k}: {v['win_rate']*100:.0f}% روی {v['trades']}"
                        for k, v in strategy_diagnostics['regime_split'].items())
                    self.log(f"   → تشخیص استراتژی (برد بر اساس رژیم ورود): {split_txt}")
            except Exception:
                pass

            self.log(f"   → خط پایه تصادفی: {(BASELINE_WIN*100):.1f}% برد")
            self.log(f"   → آستانه بهینه: {best_thr:.2f} | برد OOF: "
                     f"{(best_sim['win_rate']*100):.1f}% روی {best_sim['n_trades']} معامله")
            self.log(f"   → شبیه‌سازی تست (خارج از نمونه) با آستانه {best_thr:.2f}: "
                     f"برد {(sim_test['win_rate']*100):.1f}% روی {sim_test['n_trades']} معامله "
                     f"(امید ریاضی {sim_test['expectancy_pct']:+.3f}%)")
            self.log(f"   → شبیه‌سازی تست با آستانه پیش‌فرض 0.60: "
                     f"برد {(sim_test_default['win_rate']*100):.1f}% روی {sim_test_default['n_trades']} معامله "
                     f"(امید ریاضی {sim_test_default['expectancy_pct']:+.3f}%)")
            step_times['threshold'] = round(time.time() - t_step, 1)

            if final_model.warm_started:
                self.log(f"   ✓ یادگیری تدریجی فعال بود (دور {final_model.training_round})")

            # === STEP 9: Champion/challenger gate, then save ===
            gate_info = {'promote': True, 'compared': False, 'message': 'بدون دروازه‌ی مقایسه'}
            if gate:
                self.log("۹. مقایسه با مدل ذخیره‌شده‌ی قبلی (فقط روی کندل‌های دیده‌نشده)...")
                gate_info = champion_gate(existing_model, existing_meta, final_model, features,
                                          X_te, y_te, ind_te, best_thr,
                                          X_test_timeline=X_te_full,
                                          ind_test_timeline=ind_te, market=market)
                self.log(f"   → {gate_info['message']}")
            promoted = bool(gate_info.get('promote', True))
            if promoted:
                self.log("   ذخیره مدل...")
                final_model.save(mp)
                self.log(f"   ✓ مدل ذخیره شد: {mp}")
            else:
                self.log("   ⏭ مدل جدید ذخیره نشد؛ مدل قبلی که بهتر بود باقی ماند.")

            # Save metadata
            elapsed_total = time.time() - start_time
            meta = {
                'symbol': symbol,
                'timeframe': timeframe,
                'market': market,
                'funding_backtest': funding_audit,
                'source': df.attrs.get('source', '?'),
                'data_contract': getattr(self, 'data_contract_report', None),
                'labeling': 'triple_barrier',
                'tb_up_mult': TB_UP_MULT, 'tb_dn_mult': TB_DN_MULT,
                'tb_horizon': TB_HORIZON,
                'train_samples': len(X_train_full),
                'test_samples': len(X_te),
                'feature_count': len(top_feats),
                'feature_schema_version': FEATURE_SCHEMA_VERSION,
                'training_protocol_version': TRAINING_PROTOCOL_VERSION,
                'total_features_before_selection': n_features,
                'train_acc': train_metrics['accuracy'],
                'val_acc': test_metrics['accuracy'],
                'balanced_acc': test_metrics['balanced_acc'],
                'high_conf_acc': test_metrics['high_conf_acc'],
                'high_conf_cov': test_metrics['high_conf_cov'],
                'very_high_conf_acc': test_metrics.get('very_high_conf_acc', 0),
                'very_high_conf_cov': test_metrics.get('very_high_conf_cov', 0),
                'ultra_high_conf_acc': test_metrics.get('ultra_high_conf_acc', 0),
                'ultra_high_conf_cov': test_metrics.get('ultra_high_conf_cov', 0),
                'max_conf_acc': test_metrics.get('max_conf_acc', 0),
                'max_conf_cov': test_metrics.get('max_conf_cov', 0),
                'agree_acc': test_metrics.get('agree_acc', 0),
                'agree_cov': test_metrics.get('agree_cov', 0),
                'walk_forward_acc': wf_acc,
                'best_trial': best_idx + 1,
                'best_params': _jsonify(best_params),
                'trials': trial_results,
                'training_time_sec': round(elapsed_total, 1),
                'time_estimate_sec': estimate_train_time(limit),
                'step_times': step_times,
                'calibrated': calibrated,
                'calibrator_type': 'sigmoid' if calibrated else 'none',
                'purged_split': True,
                'purge_policy': 'actual_label_end_pos_before_segment_boundary',
                'embargo_bars': int(TB_HORIZON),
                'label_interval_policy': 'entry_to_first_barrier_touch_or_timeout',
                'label_end_t_available': True,
                'raw_bar_index_preserved': True,
                'backtest_uses_contiguous_raw_bars': True,
                'split_boundaries': {k: int(v) for k, v in split_info.items()
                                     if k.endswith('_pos') and isinstance(v, (int, np.integer))},
                'corr_prune': CORR_PRUNE,
                'parallel_workers': PAR_WORKERS,
                'n_seeds': final_model.n_seeds,
                'recency_weighting': FINAL_RECENCY,
                'iterations': len(grid),
                'data_points': len(df),
                'warm_started': final_model.warm_started,
                'training_round': final_model.training_round,
                'has_meta_model': final_model.meta_model is not None,
                'meta_labeler_active': bool(meta_ok),
                'meta_labeler_base_rate': meta_labeler.base_rate if meta_ok else None,
                'meta_labeler_samples': meta_labeler.n_samples if meta_ok else 0,
                'meta_labeler_version': getattr(meta_labeler, 'version', None) if meta_ok else None,
                'meta_labeler_metrics': getattr(meta_labeler, 'metrics', {}) if meta_ok else {},
                'meta_threshold': float(getattr(meta_labeler, 'threshold', 0.55)) if meta_ok else None,
                'best_threshold': best_thr,
                'edge_confirmed': edge_confirmed,
                'baseline_win_rate': ATR_SL_MULT / (ATR_TP_MULT + ATR_SL_MULT),
                'test_start_ts': test_start_ts,
                'ambiguous_labels_dropped': n_amb,
                'sim_oof': best_sim,
                'threshold_oof_samples': int(len(threshold_probs)),
                'threshold_oof_start': int(threshold_start),
                'sim_test': sim_test,
                'sim_test_default': sim_test_default,
                'strategy_diagnostics': strategy_diagnostics,
                'calibration_report': calib_report,
                'brain_feedback': brain_feedback,
                'conf_metrics': test_metrics.get('conf_metrics', {}),
                'promoted': promoted,
                'gate_info': gate_info,
                'seeded_from': (f'{seed_from[0]}/{seed_from[1]}' if seed_model is not None else None),
                'quick_mode': bool(quick),
                'data_adequacy': adequacy,
                'edge_consistency': consistency,
                'sim_test_ci': sim_test_ci,
                'transfer_mode': (None if seed_model is None else
                                  'xgb_booster' if final_model.warm_started else 'features+params'),
                'n_folds': n_folds,
            }
            if promoted:
                meta['experiment_id'] = (_registry_experiment or {}).get('experiment_id')
                meta['hypothesis_id'] = 'V22-H003'
                meta['data_hash'] = (_registry_experiment or {}).get('data_hash')
                meta['config_hash'] = (_registry_experiment or {}).get('config_hash')
                meta['trial_count'] = (_registry_experiment or {}).get('trial_count_at_start')
                save_meta(symbol, timeframe, meta, custom_dir)
            if _registry_experiment:
                finish_experiment(_registry_experiment['experiment_id'], 'ACCEPTED' if promoted else 'REJECTED',
                    metrics={'val_acc':test_metrics.get('accuracy'), 'balanced_acc':test_metrics.get('balanced_acc'), 'walk_forward_acc':wf_acc, 'sim_test':sim_test},
                    decision_reason=gate_info.get('message'), negative_result=None if promoted else gate_info.get('message'),
                    model_path=str(mp) if promoted else None, custom_dir=custom_dir)

            # Successful completion: the interruption checkpoint is obsolete now.
            _clear_checkpoint(symbol, timeframe)

            # Save training log
            log_text = "\n".join(self.progress_log)
            write_training_log(symbol, timeframe, log_text, custom_dir)

            self.log(f"✅ آموزش کامل شد در {elapsed_total:.1f} ثانیه")
            self.last_result = {
                'model_path': str(mp),
                'meta': meta,
                'trial_results': trial_results,
                'feature_names': final_model.feature_names,
                'last_row_features': last_row.to_dict(),
                'progress_log': self.progress_log,
                'training_time_sec': elapsed_total,
            }
            return self.last_result

        finally:
            self.is_running = False


# Singleton session for the app
_session = TrainingSession()


def get_session() -> TrainingSession:
    return _session
