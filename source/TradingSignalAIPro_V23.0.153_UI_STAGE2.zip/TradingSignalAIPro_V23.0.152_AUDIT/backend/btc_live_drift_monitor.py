"""Operator-facing drift alerts for BTC 4h read-only ingestion and reconciliation."""
from __future__ import annotations
import hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path

ZERO='0'*64


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

def _sha(value): return hashlib.sha256(_canonical(value)).hexdigest()


def evaluate_live_drift(*, live_report=None, reconciliation_report=None,
                         max_latest_age_hours=8, warn_revision_count=1):
    warnings=[]; errors=[]; metrics={}
    if live_report is not None:
        if not isinstance(live_report,dict): raise ValueError('live_drift_report_invalid')
        metrics['live_status']=live_report.get('status')
        metrics['latest_age_hours']=live_report.get('latest_age_hours')
        if live_report.get('status')!='PASS': errors.append('live_data_quality_not_pass')
        age=live_report.get('latest_age_hours')
        if age is not None and float(age)>max_latest_age_hours: errors.append('live_data_stale')
    if reconciliation_report is not None:
        if not isinstance(reconciliation_report,dict): raise ValueError('live_reconciliation_report_invalid')
        metrics['reconciliation_status']=reconciliation_report.get('status')
        metrics['revision_count']=int(reconciliation_report.get('revision_count',0))
        metrics['removed_count']=int(reconciliation_report.get('removed_count',0))
        metrics['added_count']=int(reconciliation_report.get('added_count',0))
        if reconciliation_report.get('status')=='BLOCKED' or metrics['removed_count']:
            errors.append('closed_candle_revision_or_removal_detected')
        elif metrics['revision_count'] >= max(1,warn_revision_count):
            warnings.append('revision_count_warning_threshold_reached')
        elif metrics['revision_count']:
            warnings.append('closed_candle_revision_observed')
    if live_report is None and reconciliation_report is None:
        raise ValueError('live_drift_evidence_required')
    status='CRITICAL' if errors else ('WARNING' if warnings else 'HEALTHY')
    return {'schema_version':'btc-4h-live-drift-alert-v1','status':status,
            'created_at_utc':datetime.now(timezone.utc).isoformat(),
            'metrics':metrics,'warnings':sorted(set(warnings)),
            'errors':sorted(set(errors)),'training_allowed':False,'live_orders':False}


def append_live_drift_alert(alert: dict, *, alerts_path):
    if not isinstance(alert,dict) or alert.get('schema_version')!='btc-4h-live-drift-alert-v1':
        raise ValueError('live_drift_alert_invalid')
    path=Path(alerts_path).expanduser(); path.parent.mkdir(parents=True,exist_ok=True)
    rows=[]
    if path.exists():
        for i,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
            try: rows.append(json.loads(line))
            except ValueError as exc: raise ValueError(f'live_drift_alert_log_corrupt_line:{i}') from exc
    audit_live_drift_alerts(rows)
    fingerprint=_sha(alert)
    if rows and rows[-1].get('alert_fingerprint')==fingerprint:
        return {'status':'UNCHANGED','sequence':rows[-1]['sequence'],'alert_fingerprint':fingerprint}
    record={'sequence':len(rows)+1,'previous_alert_sha256':rows[-1]['record_sha256'] if rows else ZERO,
            'alert_fingerprint':fingerprint,'alert':alert}
    record['record_sha256']=_sha(record)
    raw=_canonical(record)+b'\n'
    fd=os.open(str(path),os.O_CREAT|os.O_APPEND|os.O_WRONLY,0o600)
    try:
        written=os.write(fd,raw)
        if written!=len(raw): raise OSError('live_drift_alert_short_append')
        os.fsync(fd)
    finally: os.close(fd)
    return {'status':'APPENDED','sequence':record['sequence'],
            'alert_fingerprint':fingerprint,'record_sha256':record['record_sha256']}


def audit_live_drift_alerts(rows_or_path):
    if isinstance(rows_or_path,(str,Path)):
        path=Path(rows_or_path); rows=[]
        if path.exists():
            for i,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
                try: rows.append(json.loads(line))
                except ValueError as exc: raise ValueError(f'live_drift_alert_log_corrupt_line:{i}') from exc
    else: rows=list(rows_or_path)
    previous=ZERO
    for seq,row in enumerate(rows,1):
        body=dict(row); declared=body.pop('record_sha256',None)
        if row.get('sequence')!=seq or row.get('previous_alert_sha256')!=previous:
            raise ValueError('live_drift_alert_sequence_or_link_mismatch')
        if not declared or _sha(body)!=declared:
            raise ValueError('live_drift_alert_hash_mismatch')
        previous=declared
    return {'status':'PASS','alert_count':len(rows),'head_sha256':previous,
            'latest_status':rows[-1]['alert']['status'] if rows else None}
