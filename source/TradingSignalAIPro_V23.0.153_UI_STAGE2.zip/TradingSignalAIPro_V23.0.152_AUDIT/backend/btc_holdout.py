"""One-shot chronological holdout and cost-aware BTC 4h decision gate.

This module deliberately does not tune thresholds on holdout outcomes. Candidate
rules and execution costs are supplied before evaluation and recorded in output.
"""
from __future__ import annotations

import hashlib
import json

import numpy as np
import pandas as pd

VERSION = 'btc-4h-holdout-cost-gate-v1'


def _metrics(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    classes = (-1, 0, 1)
    recalls = [float(np.mean(y_true[y_true == c] == c)) for c in classes if np.any(y_true == c)]
    f1s = []
    for c in classes:
        tp = int(np.sum((y_true == c) & (y_pred == c)))
        fp = int(np.sum((y_true != c) & (y_pred == c)))
        fn = int(np.sum((y_true == c) & (y_pred != c)))
        f1s.append(2 * tp / (2 * tp + fp + fn) if (2 * tp + fp + fn) else 0.0)
    return {'n': int(len(y_true)), 'accuracy': float(np.mean(y_true == y_pred)),
            'balanced_accuracy': float(np.mean(recalls)) if recalls else None,
            'macro_f1': float(np.mean(f1s))}


def _simulate_cost_aware(predictions, metadata, *, probability_edge, fee_bps,
                         slippage_bps, spread_bps, min_trades):
    """Long/short/flat, non-overlapping trades using predeclared probability edge.

    forward_return is the label-horizon underlying return. Costs are round-trip
    estimates in bps. No holdout-derived threshold selection is performed.
    """
    p = np.asarray(predictions, dtype=float)
    if p.ndim != 2 or p.shape[1] != 3 or not np.isfinite(p).all():
        raise ValueError('invalid probability matrix')
    if (p < 0).any() or not np.allclose(p.sum(axis=1), 1.0, atol=1e-5):
        raise ValueError('probabilities must be normalized')
    if len(metadata) != len(p):
        raise ValueError('prediction/metadata length mismatch')
    cost = (2.0 * float(fee_bps) + 2.0 * float(slippage_bps) + float(spread_bps)) / 10000.0
    if min(fee_bps, slippage_bps, spread_bps) < 0 or not 0 <= probability_edge < 1:
        raise ValueError('invalid cost or probability_edge')

    rows = []
    last_exit = -1
    for i, row in enumerate(p):
        direction = 1 if row[2] - row[0] >= probability_edge else (-1 if row[0] - row[2] >= probability_edge else 0)
        pos = int(metadata.iloc[i]['sample_pos'])
        end = int(metadata.iloc[i]['label_end_pos'])
        if direction == 0 or pos <= last_exit:
            continue
        gross = direction * float(metadata.iloc[i]['forward_return'])
        net = gross - cost
        rows.append({'sample_pos': pos, 'label_end_pos': end, 'direction': direction,
                     'gross_return': gross, 'net_return': net})
        last_exit = end
    net_values = np.asarray([r['net_return'] for r in rows], dtype=float)
    compounded = float(np.prod(1.0 + net_values) - 1.0) if len(net_values) else 0.0
    wins = int(np.sum(net_values > 0))
    return {'trade_count': len(rows), 'gross_return_sum': float(sum(r['gross_return'] for r in rows)),
            'net_return_sum': float(net_values.sum()) if len(rows) else 0.0,
            'net_compounded_return': compounded,
            'win_rate': float(wins / len(rows)) if len(rows) else None,
            'estimated_round_trip_cost': cost, 'trades': rows,
            'minimum_trade_requirement': int(min_trades),
            'sufficient_trades': bool(len(rows) >= min_trades)}


def evaluate_btc_4h_holdout(dataset, *, holdout_fraction=0.20, embargo_bars=None,
                            probability_edge=0.08, fee_bps=5.0,
                            slippage_bps=3.0, spread_bps=2.0,
                            min_trades=10, min_net_return=0.0,
                            allow_logistic=True, random_state=42):
    """Fit fixed baselines on pre-holdout data and evaluate final tail once.

    The holdout is the final chronological block. Training rows are purged by
    each row's actual label_end_pos before any estimator is fitted.
    """
    try:
        from sklearn.dummy import DummyClassifier
        from sklearn.linear_model import LogisticRegression
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError('scikit-learn is required') from exc

    X = pd.DataFrame(dataset['X']).reset_index(drop=True)
    y = pd.Series(dataset['y']).astype(int).reset_index(drop=True)
    meta = pd.DataFrame(dataset['metadata']).reset_index(drop=True)
    if len(X) != len(y) or len(X) != len(meta) or len(X) < 40:
        raise ValueError('dataset is too small or misaligned for holdout')
    if not np.isfinite(X.to_numpy(dtype=float)).all():
        raise ValueError('non-finite features')
    if not 0.05 <= holdout_fraction <= 0.5:
        raise ValueError('holdout_fraction must be between 0.05 and 0.5')
    n_hold = max(1, int(np.ceil(len(X) * holdout_fraction)))
    hold_start_i = len(X) - n_hold
    hold_start_pos = int(meta.iloc[hold_start_i]['sample_pos'])
    embargo = int(embargo_bars if embargo_bars is not None else dataset['manifest']['config'].get('embargo_bars', 0))
    if embargo < 0:
        raise ValueError('embargo_bars must be non-negative')
    ends = meta['label_end_pos'].to_numpy(dtype=int)
    train_idx = np.flatnonzero((np.arange(len(X)) < hold_start_i) & (ends < hold_start_pos - embargo))
    hold_idx = np.arange(hold_start_i, len(X), dtype=int)
    if len(train_idx) < 20 or len(hold_idx) < 5:
        raise ValueError('insufficient train or holdout rows after purge')
    if not np.all(ends[train_idx] < hold_start_pos - embargo):
        raise ValueError('holdout purge failed')

    candidates = {'majority': DummyClassifier(strategy='most_frequent')}
    if allow_logistic and len(np.unique(y.iloc[train_idx])) >= 2:
        candidates['logistic_regression'] = make_pipeline(
            StandardScaler(), LogisticRegression(max_iter=1000, class_weight='balanced',
                                                   random_state=random_state))
    reports = {}
    for name, model in candidates.items():
        model.fit(X.iloc[train_idx], y.iloc[train_idx])
        pred = model.predict(X.iloc[hold_idx]).astype(int)
        if hasattr(model, 'predict_proba'):
            raw = model.predict_proba(X.iloc[hold_idx])
            classes = list(model.classes_) if hasattr(model, 'classes_') else list(model[-1].classes_)
            probs = np.zeros((len(hold_idx), 3), dtype=float)
            for j, cls in enumerate((-1, 0, 1)):
                if cls in classes:
                    probs[:, j] = raw[:, classes.index(cls)]
            sums = probs.sum(axis=1)
            probs[sums == 0] = 1/3
            sums[sums == 0] = 1
            probs /= sums[:, None]
        else:
            probs = np.full((len(hold_idx), 3), 1/3)
        sim = _simulate_cost_aware(probs, meta.iloc[hold_idx].reset_index(drop=True),
            probability_edge=probability_edge, fee_bps=fee_bps,
            slippage_bps=slippage_bps, spread_bps=spread_bps, min_trades=min_trades)
        passed = bool(sim['sufficient_trades'] and sim['net_compounded_return'] > min_net_return)
        reports[name] = {'classification': _metrics(y.iloc[hold_idx], pred),
                         'cost_aware': sim, 'decision_gate': 'PASS' if passed else 'FAIL',
                         'promotion_allowed': False}

    summary = {'version': VERSION, 'dataset_hash': dataset['manifest'].get('dataset_hash'),
        'holdout_policy': 'final_chronological_block_evaluated_once_per_invocation',
        'holdout_start_sample_index': int(hold_start_i), 'holdout_start_original_pos': hold_start_pos,
        'holdout_rows': int(len(hold_idx)), 'train_rows_after_purge': int(len(train_idx)),
        'max_train_label_end_pos': int(ends[train_idx].max()), 'embargo_bars': embargo,
        'costs_bps': {'fee_per_side': float(fee_bps), 'slippage_per_side': float(slippage_bps),
                      'spread_round_trip': float(spread_bps)},
        'probability_edge': float(probability_edge), 'min_trades': int(min_trades),
        'min_net_return': float(min_net_return), 'models': reports,
        'automatic_promotion': False,
        'warning': 'A holdout report is not proof of future profitability; do not repeatedly tune against this holdout.'}
    canonical = json.dumps(summary, sort_keys=True, separators=(',', ':'), allow_nan=False)
    summary['evaluation_hash'] = hashlib.sha256(canonical.encode()).hexdigest()
    return summary
