"""Explicit, fail-closed token contract identity checks using CoinGecko metadata.

A ticker/symbol match alone is never sufficient. Verification requires an exact
CoinGecko coin id plus a chain/platform and contract address supplied by the
caller, then an exact address match in CoinGecko's platform metadata.
"""
from __future__ import annotations
import re, time, threading
import requests

_BASE = 'https://api.coingecko.com/api/v3'
_SESSION = requests.Session()
_SESSION.headers.update({'User-Agent': 'TradingSignalAIPro/22.6.2', 'Accept': 'application/json'})
_CACHE: dict[tuple, tuple[float, dict]] = {}
_LOCK = threading.Lock()
TTL_SECONDS = 900
TIMEOUT = (3, 7)


def _valid_address(value: str) -> bool:
    value = str(value or '').strip()
    # EVM and common base58 chain addresses; deliberately reject malformed input.
    return bool(re.fullmatch(r'0x[a-fA-F0-9]{40}', value) or
                re.fullmatch(r'[1-9A-HJ-NP-Za-km-z]{32,64}', value))


def verify_token_contract(coin_id: str, platform: str, contract_address: str,
                          fetch_json=None, now: float | None = None) -> dict:
    coin_id, platform = str(coin_id or '').strip(), str(platform or '').strip().lower()
    address = str(contract_address or '').strip()
    if not coin_id or not platform or not _valid_address(address):
        return {'status': 'identity_unverified', 'verified': False,
                'reason': 'coin_id، platform و آدرس قرارداد معتبر الزامی‌اند.'}
    key = (coin_id, platform, address.lower())
    now = time.time() if now is None else float(now)
    with _LOCK:
        cached = _CACHE.get(key)
        if cached and now - cached[0] < TTL_SECONDS:
            return {**cached[1], 'cache': 'hit'}
    if fetch_json is None:
        def fetch_json(url):
            response = _SESSION.get(url, timeout=TIMEOUT)
            response.raise_for_status()
            return response.json()
    try:
        data = fetch_json(f'{_BASE}/coins/{coin_id}?localization=false&tickers=false&market_data=false&community_data=false&developer_data=false&sparkline=false')
        platforms = data.get('platforms') or {}
        listed = platforms.get(platform)
        if not listed:
            result = {'status': 'identity_unverified', 'verified': False,
                      'reason': 'این coin_id روی پلتفرم/شبکه درخواستی آدرس ثبت‌شده ندارد.'}
        elif str(listed).strip().lower() != address.lower():
            result = {'status': 'identity_mismatch', 'verified': False,
                      'reason': 'آدرس واردشده با آدرس ثبت‌شده در منبع مستقل تطبیق ندارد.'}
        else:
            result = {'status': 'identity_verified', 'verified': True,
                      'reason': 'coin_id، شبکه و آدرس قرارداد دقیقاً با metadata منبع مستقل تطبیق دارند.',
                      'coin_id': coin_id, 'platform': platform, 'contract_address': address}
    except Exception as exc:
        result = {'status': 'identity_check_unavailable', 'verified': False,
                  'reason': f'بررسی منبع مستقل ناموفق بود: {str(exc)[:120]}'}
    with _LOCK:
        _CACHE[key] = (now, result)
    return {**result, 'cache': 'miss'}
