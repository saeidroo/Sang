"""V22.3k: immutable BTC 4h snapshots, incremental merge, audit and replay."""
from __future__ import annotations
import hashlib, json, os
from pathlib import Path
from datetime import datetime, timezone
import pandas as pd
from backend.btc_walkforward import validate_btc_4h
from backend.btc_data_ingestion import require_training_quality

STORE_VERSION = "btc-4h-store-v1"
COLUMNS = ["t", "open", "high", "low", "close", "volume"]

def _canonical(rows):
    return json.dumps(rows, sort_keys=True, separators=(",", ":"), allow_nan=False)

def _sha(rows):
    return hashlib.sha256(_canonical(rows).encode()).hexdigest()

def _atomic_json(path, payload):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(tmp, path)

def _read_manifest(root):
    p = Path(root) / "manifest.json"
    if not p.exists():
        return {"version": STORE_VERSION, "snapshots": [], "latest_snapshot": None}
    data = json.loads(p.read_text(encoding="utf-8"))
    if data.get("version") != STORE_VERSION or not isinstance(data.get("snapshots"), list):
        raise ValueError("invalid_store_manifest")
    return data

def _load_latest(root, manifest):
    latest = manifest.get("latest_snapshot")
    if not latest: return []
    p = Path(root) / "snapshots" / latest
    payload = json.loads(p.read_text(encoding="utf-8"))
    rows = payload.get("candles")
    if not isinstance(rows, list) or _sha(rows) != payload.get("data_sha256"):
        raise ValueError("snapshot_hash_mismatch")
    if payload.get("data_sha256") != manifest.get("snapshots", [])[-1].get("data_sha256"):
        raise ValueError("manifest_snapshot_hash_mismatch")
    return rows

def _audit(root, event):
    p = Path(root) / "audit.jsonl"; p.parent.mkdir(parents=True, exist_ok=True)
    previous = "0" * 64
    if p.exists():
        lines = p.read_text(encoding="utf-8").splitlines()
        if lines:
            last = json.loads(lines[-1]); previous = last.get("event_sha256", "")
            check = dict(last); check.pop("event_sha256", None)
            if hashlib.sha256((previous if False else json.dumps(check, sort_keys=True, separators=(",", ":"))).encode()).hexdigest() != last.get("event_sha256"):
                raise ValueError("audit_chain_corrupt")
    item = {"previous_sha256": previous, **event}
    digest = hashlib.sha256(json.dumps(item, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    item["event_sha256"] = digest
    with p.open("a", encoding="utf-8") as f: f.write(json.dumps(item, sort_keys=True, ensure_ascii=False) + "\n")

def verify_audit(root):
    p = Path(root) / "audit.jsonl"
    if not p.exists(): return {"valid": True, "events": 0}
    prev = "0" * 64; count = 0
    for line in p.read_text(encoding="utf-8").splitlines():
        item = json.loads(line); digest = item.pop("event_sha256", None)
        if item.get("previous_sha256") != prev: return {"valid": False, "events": count}
        actual = hashlib.sha256(json.dumps(item, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        if actual != digest: return {"valid": False, "events": count}
        prev = digest; count += 1
    return {"valid": True, "events": count}

def append_ingestion(root, ingestion_result, *, allow_training=True):
    """Merge a PASS batch. Exact overlap is idempotent; conflicting overlap fails."""
    batch = require_training_quality(ingestion_result)
    root = Path(root); manifest = _read_manifest(root); existing = _load_latest(root, manifest)
    by_t = {int(r["t"]): r for r in existing}
    added = 0
    for raw in batch[COLUMNS].to_dict("records"):
        row = {k: (int(v) if k == "t" else float(v)) for k, v in raw.items()}
        ts = row["t"]
        if ts in by_t:
            if by_t[ts] != row: raise ValueError(f"conflicting_overlap:{ts}")
            continue
        by_t[ts] = row; added += 1
    rows = [by_t[k] for k in sorted(by_t)]
    if rows:
        quality = validate_btc_4h(pd.DataFrame(rows), timestamp="t", max_gap_bars=0, require_volume=True)
        if quality.get("status") != "PASS":
            raise ValueError("merged_snapshot_quality_blocked:" + ",".join(quality.get("reasons", [])))
    digest = _sha(rows)
    if manifest.get("snapshots") and manifest["snapshots"][-1].get("data_sha256") == digest:
        latest = manifest.get("latest_snapshot")
        _audit(root, {"action": "idempotent_no_change", "snapshot": latest,
                      "data_sha256": digest, "batch_sha256": ingestion_result.get("data_sha256"),
                      "added_rows": 0, "training_allowed": bool(allow_training)})
        return {"status": "PASS", "snapshot": latest, "row_count": len(rows),
                "added_rows": 0, "data_sha256": digest, "audit": verify_audit(root),
                "live_orders": False, "training_allowed": bool(allow_training),
                "idempotent": True}
    name = f"btc_4h_{digest[:16]}.json"
    payload = {"version": STORE_VERSION, "symbol": ingestion_result.get("symbol", "BTCUSDT"),
               "timeframe": "4h", "row_count": len(rows), "data_sha256": digest,
               "candles": rows, "created_at_utc": datetime.now(timezone.utc).isoformat(),
               "source_batches": [x.get("data_sha256") for x in manifest["snapshots"]] + [ingestion_result.get("data_sha256")],
               "safety": {"training_allowed": bool(allow_training), "live_orders": False}}
    snap_dir = root / "snapshots"; snap_dir.mkdir(parents=True, exist_ok=True)
    snap_path = snap_dir / name
    if not snap_path.exists(): _atomic_json(snap_path, payload)
    entry = {"file": name, "data_sha256": digest, "row_count": len(rows), "added_rows": added,
             "batch_sha256": ingestion_result.get("data_sha256"), "created_at_utc": payload["created_at_utc"]}
    manifest["snapshots"].append(entry); manifest["latest_snapshot"] = name
    _atomic_json(root / "manifest.json", manifest)
    _audit(root, {"action": "append", "snapshot": name, "data_sha256": digest,
                  "batch_sha256": ingestion_result.get("data_sha256"), "added_rows": added,
                  "training_allowed": bool(allow_training)})
    return {"status": "PASS", "snapshot": name, "row_count": len(rows), "added_rows": added,
            "data_sha256": digest, "audit": verify_audit(root), "live_orders": False,
            "training_allowed": bool(allow_training)}

def replay_snapshot(root, snapshot=None):
    """Load a stored snapshot offline and verify its content hash before returning rows."""
    root = Path(root); manifest = _read_manifest(root); name = snapshot or manifest.get("latest_snapshot")
    if not name: raise FileNotFoundError("no_snapshot_available")
    entries = [x for x in manifest["snapshots"] if x.get("file") == name]
    if len(entries) != 1: raise ValueError("snapshot_not_in_manifest_or_ambiguous")
    entry = entries[0]
    p = root / "snapshots" / name; payload = json.loads(p.read_text(encoding="utf-8"))
    rows = payload.get("candles", [])
    if not isinstance(rows, list) or _sha(rows) != payload.get("data_sha256"):
        raise ValueError("snapshot_hash_mismatch")
    if payload.get("data_sha256") != entry.get("data_sha256"):
        raise ValueError("snapshot_manifest_hash_mismatch")
    if len(rows) != payload.get("row_count") or len(rows) != entry.get("row_count"):
        raise ValueError("snapshot_row_count_mismatch")
    if payload.get("version") != STORE_VERSION or payload.get("timeframe") != "4h":
        raise ValueError("snapshot_contract_mismatch")
    if not verify_audit(root)["valid"]: raise ValueError("audit_chain_corrupt")
    return {"status": "PASS", "snapshot": name, "candles": rows, "row_count": len(rows),
            "data_sha256": payload["data_sha256"], "symbol": payload.get("symbol"),
            "timeframe": payload.get("timeframe"), "network_used": False, "live_orders": False,
            "training_allowed": payload.get("safety", {}).get("training_allowed", False)}
