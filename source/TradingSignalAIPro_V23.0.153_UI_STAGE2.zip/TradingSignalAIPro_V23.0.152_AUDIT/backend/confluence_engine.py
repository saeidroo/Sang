"""Conservative multi-evidence confluence scoring for paper-entry review."""
from __future__ import annotations


def analyze_entry_confluence(*, side: str, structure: dict | None = None,
                             liquidity: dict | None = None, divergence: dict | None = None,
                             pullback: dict | None = None, volume: dict | None = None,
                             supply_demand: dict | None = None) -> dict:
    direction = str(side).upper()
    if direction not in ("LONG", "SHORT"):
        raise ValueError("side must be LONG or SHORT")
    structure, liquidity, divergence = structure or {}, liquidity or {}, divergence or {}
    pullback, volume, supply_demand = pullback or {}, volume or {}, supply_demand or {}
    aligned, opposing, evidence = [], [], []

    def add(name: str, points: int, reason: str):
        target = aligned if points > 0 else opposing if points < 0 else None
        if target is not None:
            target.append({"source": name, "points": abs(points), "reason": reason})
        evidence.append({"source": name, "points": points, "reason": reason})

    trend = structure.get("trend")
    if trend in ("BULLISH", "BEARISH"):
        expected = "BULLISH" if direction == "LONG" else "BEARISH"
        add("market_structure", 2 if trend == expected else -2, f"trend={trend}")
    events = structure.get("events", [])
    for event in events if isinstance(events, list) else []:
        if event.get("type") in ("BOS", "CHOCH"):
            expected = "BULLISH" if direction == "LONG" else "BEARISH"
            points = 2 if event.get("direction") == expected else -2
            add("structure_event", points, f"{event.get('type')}:{event.get('direction')}")
    if liquidity.get("state") == "SWEEP_RECLAIMED":
        expected = "BULLISH_SUPPORT_SWEEP" if direction == "LONG" else "BEARISH_RESISTANCE_SWEEP"
        add("liquidity_sweep", 2 if liquidity.get("sweep_type") == expected else -2, str(liquidity.get("sweep_type")))
    div_block = bool(divergence.get("blocking"))
    if div_block:
        add("rsi_macd_divergence", -2, "opposing RSI/MACD divergence")
    else:
        names = (str(divergence.get("rsi_divergence", "")) + " " + str(divergence.get("macd_divergence", ""))).upper()
        expected = "BULLISH" if direction == "LONG" else "BEARISH"
        if expected in names:
            add("rsi_macd_divergence", 1, "direction-aligned divergence")
    if pullback.get("state") == "PULLBACK_CONFIRMED":
        add("pullback", 1, "confirmed retest")
    if volume.get("confirmed") is True:
        add("volume", 1, "volume confirmation")
    if supply_demand.get("blocking"):
        add("supply_demand", -2, "nearby opposing supply/demand zone")
    score = sum(x["points"] for x in evidence)
    # This is an advisory quality label only; existing independent safety gates remain authoritative.
    label = "STRONG_CONFLUENCE" if score >= 4 else "POSITIVE_CONFLUENCE" if score > 0 else "CONFLICTING_EVIDENCE" if score < 0 else "NEUTRAL_OR_INSUFFICIENT"
    return {"side": direction, "score": score, "label": label,
            "aligned_count": len(aligned), "opposing_count": len(opposing),
            "aligned_evidence": aligned, "opposing_evidence": opposing,
            "evidence": evidence, "blocking": False,
            "policy": "ADVISORY_ONLY_EXISTING_RISK_GATES_UNCHANGED",
            "data_policy": "CLOSED_CANDLES_ONLY"}
