"""V20 — Trending coins: **CoinMarketCap first**, then a fallback chain.

User request: the trending list must come from CoinMarketCap (not Binance).
Nothing is invented: if a source is unreachable we transparently try the next
one, and only report an error when every source fails.

Source chain (in order):
  1. CoinMarketCap (public web API, no key needed)
  2. CoinMarketCap Pro (if CMC_API_KEY is set in .env)
  3. CoinGecko
  4. CoinPaprika
  5. CryptoCompare
  6. Binance spot (last resort only)

Every adapter normalizes its payload into the Binance-like ticker format
(symbol / priceChangePercent / quoteVolume / lastPrice) so that the pure
ranking function `rank_tickers` stays unchanged and unit-testable.

A coin is "trending" when it moves a lot AND trades with real volume, so thin
illiquid pumps are filtered out. Only USDT spot pairs that the rest of the app
can actually fetch/train are returned.
"""
from __future__ import annotations

import math
import os
import re
import time
from typing import Any

import requests

_CACHE: dict[str, Any] = {'ts': 0.0, 'data': None}
CACHE_SEC = 60
MIN_QUOTE_VOLUME = 5_000_000.0          # USDT traded in 24h
_STABLES = {'USDC', 'FDUSD', 'TUSD', 'USDP', 'DAI', 'BUSD', 'USDE', 'EUR', 'EURI',
            'AEUR', 'USD1', 'XUSD', 'PYUSD', 'UST', 'USDS'}
_LEVERAGED = re.compile(r'(UP|DOWN|BULL|BEAR)$')

_TIMEOUT = (5, 12)
_HEADERS = {'User-Agent': 'Mozilla/5.0 TradingSignalAIPro/20.0', 'Accept': 'application/json'}


# ------------------------------------------------------------------ helpers
def _norm_tickers(rows: list[dict]) -> list[dict]:
    """Drop empty rows and keep only the four fields the ranker needs."""
    return [{'symbol': r['symbol'], 'priceChangePercent': r['priceChangePercent'],
             'quoteVolume': r['quoteVolume'], 'lastPrice': r['lastPrice']}
            for r in rows if r.get('symbol')]


def _get_json(urls: list[str] | str, params=None, headers=None) -> Any:
    """Try each mirror once; raise the last error if all fail."""
    if isinstance(urls, str):
        urls = [urls]
    last: Exception | None = None
    for url in urls:
        try:
            r = requests.get(url, params=params, headers={**_HEADERS, **(headers or {})},
                             timeout=_TIMEOUT)
            if r.status_code in (403, 418, 429, 451):
                raise RuntimeError(f'HTTP {r.status_code} (محدود/مسدود)')
            r.raise_for_status()
            return r.json()
        except Exception as exc:                 # noqa: BLE001 — try the next mirror
            last = exc
    raise RuntimeError(str(last)[:140] if last else 'خطای ناشناخته')


# ----------------------------------------------------------------- adapters
def _coinmarketcap_web() -> list[dict]:
    """Unofficial public listing endpoint of coinmarketcap.com (no key)."""
    d = _get_json(['https://api.coinmarketcap.com/data-api/v3/cryptocurrency/listing'],
                  params={'start': 1, 'limit': 500, 'sortBy': 'volume_24h', 'sortType': 'desc',
                          'convert': 'USD', 'cryptoType': 'all', 'tagType': 'all'})
    out: list[dict] = []
    for c in (d.get('data') or {}).get('cryptoCurrencyList', []):
        q = next((x for x in c.get('quotes', []) if x.get('name') == 'USD'), {})
        base = str(c.get('symbol', '')).upper()
        price, vol, chg = q.get('price'), q.get('volume24h'), q.get('percentChange24h')
        if price is None or vol is None or chg is None:
            continue
        out.append({'symbol': base + 'USDT', 'priceChangePercent': chg,
                    'quoteVolume': vol, 'lastPrice': price})
    return out


def _coinmarketcap_pro() -> list[dict]:
    key = os.getenv('CMC_API_KEY', '').strip()
    if not key:
        raise RuntimeError('CMC_API_KEY تنظیم نشده')
    d = _get_json(['https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest'],
                  headers={'X-CMC_PRO_API_KEY': key},
                  params={'limit': 500, 'convert': 'USD', 'sort': 'volume_24h'})
    out: list[dict] = []
    for c in d.get('data', []):
        q = (c.get('quote') or {}).get('USD') or {}
        base = str(c.get('symbol', '')).upper()
        if q.get('price') is None or q.get('volume_24h') is None or q.get('percent_change_24h') is None:
            continue
        out.append({'symbol': base + 'USDT', 'priceChangePercent': q['percent_change_24h'],
                    'quoteVolume': q['volume_24h'], 'lastPrice': q['price']})
    return out


def _coingecko() -> list[dict]:
    h = {'x-cg-demo-api-key': os.getenv('COINGECKO_API_KEY')} if os.getenv('COINGECKO_API_KEY') else None
    d = _get_json(['https://api.coingecko.com/api/v3/coins/markets'], headers=h, params={
        'vs_currency': 'usd', 'order': 'volume_desc', 'per_page': 250, 'page': 1,
        'price_change_percentage': '24h'})
    out: list[dict] = []
    for c in d:
        base = str(c.get('symbol', '')).upper()
        price, vol = c.get('current_price'), c.get('total_volume')
        chg = c.get('price_change_percentage_24h_in_currency')
        if price is None or vol is None or chg is None:
            continue
        out.append({'symbol': base + 'USDT', 'priceChangePercent': chg,
                    'quoteVolume': vol, 'lastPrice': price})
    return out


def _coinpaprika() -> list[dict]:
    d = _get_json(['https://api.coinpaprika.com/v1/tickers'], params={'quotes': 'USD'})
    out: list[dict] = []
    for c in d:
        q = (c.get('quotes') or {}).get('USD') or {}
        base = str(c.get('symbol', '')).upper()
        price, vol, chg = q.get('price'), q.get('volume_24h'), q.get('percent_change_24h')
        if price is None or vol is None or chg is None:
            continue
        out.append({'symbol': base + 'USDT', 'priceChangePercent': chg,
                    'quoteVolume': vol, 'lastPrice': price})
    return out


def _cryptocompare() -> list[dict]:
    d = _get_json(['https://min-api.cryptocompare.com/data/top/totalvolfull'],
                  params={'limit': 200, 'tsym': 'USD'})
    out: list[dict] = []
    for c in d.get('Data', []):
        raw = (c.get('RAW') or {}).get('USD') or {}
        base = str((c.get('CoinInfo') or {}).get('Name', '')).upper()
        price, vol, chg = raw.get('PRICE'), raw.get('TOTALVOLUME24HTO'), raw.get('CHANGEPCT24HOUR')
        if price is None or vol is None or chg is None:
            continue
        out.append({'symbol': base + 'USDT', 'priceChangePercent': chg,
                    'quoteVolume': vol, 'lastPrice': price})
    return out


def _binance() -> list[dict]:
    d = _get_json(['https://data-api.binance.vision/api/v3/ticker/24hr',
                   'https://api.binance.com/api/v3/ticker/24hr'])
    out: list[dict] = []
    for t in d:
        if not str(t.get('symbol', '')).endswith('USDT'):
            continue
        out.append({'symbol': t['symbol'], 'priceChangePercent': t.get('priceChangePercent'),
                    'quoteVolume': t.get('quoteVolume'), 'lastPrice': t.get('lastPrice')})
    return out


# source id -> (label shown in UI, callable, headers needed)
SOURCES: list[tuple[str, str, Any]] = [
    ('coinmarketcap', 'CoinMarketCap', _coinmarketcap_web),
    ('coinmarketcap_pro', 'CoinMarketCap Pro', _coinmarketcap_pro),
    ('coingecko', 'CoinGecko', _coingecko),
    ('coinpaprika', 'CoinPaprika', _coinpaprika),
    ('cryptocompare', 'CryptoCompare', _cryptocompare),
    ('binance', 'Binance', _binance),
]

_LAST_SOURCE: str = '—'
_LAST_SOURCE_CHAIN: list[dict] = []


def _fetch_tickers() -> list[dict]:
    """Walk the source chain; first success wins. Raises only if ALL fail."""
    global _LAST_SOURCE, _LAST_SOURCE_CHAIN
    _LAST_SOURCE_CHAIN = []
    for sid, label, fn in SOURCES:
        try:
            rows = _norm_tickers(fn())
            if len(rows) < 10:
                raise RuntimeError('پاسخ خیلی کوچک بود')
            _LAST_SOURCE = label
            _LAST_SOURCE_CHAIN.append({'source': label, 'ok': True, 'count': len(rows)})
            return rows
        except Exception as exc:                 # noqa: BLE001 — try the next source
            _LAST_SOURCE_CHAIN.append({'source': label, 'ok': False, 'error': str(exc)[:120]})
    raise RuntimeError(f'دریافت لیست ارزهای ترند از همه‌ی منابع ممکن نشد: '
                       f'{_LAST_SOURCE_CHAIN[-1].get("error", "")[:120] if _LAST_SOURCE_CHAIN else ""}')


def rank_tickers(tickers: list[dict], limit: int = 12) -> dict:
    """Pure function (unit-testable): turn raw 24h tickers into ranked lists."""
    rows = []
    for t in tickers or []:
        sym = str(t.get('symbol', '')).upper()
        if not sym.endswith('USDT') or not re.fullmatch(r'[A-Z0-9]{3,20}', sym):
            continue
        base = sym[:-4]
        if base in _STABLES or _LEVERAGED.search(base) or len(base) < 2:
            continue
        try:
            chg = float(t['priceChangePercent'])
            vol = float(t['quoteVolume'])
            last = float(t['lastPrice'])
        except (KeyError, TypeError, ValueError):
            continue
        if not all(math.isfinite(x) for x in (chg, vol, last)) or last <= 0 or vol < MIN_QUOTE_VOLUME:
            continue
        # trend strength: size of the move x log-liquidity (so volume matters, but doesn't dominate)
        score = abs(chg) * math.log10(vol)
        rows.append({'symbol': sym, 'base': base, 'price': last,
                     'change_pct': round(chg, 2), 'quote_volume': round(vol),
                     'trend_score': round(score, 2),
                     'direction': 'up' if chg > 0 else 'down' if chg < 0 else 'flat'})
    limit = max(1, min(int(limit), 30))
    trending = sorted(rows, key=lambda r: r['trend_score'], reverse=True)[:limit]
    gainers = sorted((r for r in rows if r['change_pct'] > 0), key=lambda r: r['change_pct'], reverse=True)[:limit]
    losers = sorted((r for r in rows if r['change_pct'] < 0), key=lambda r: r['change_pct'])[:limit]
    return {'trending': trending, 'gainers': gainers, 'losers': losers, 'universe': len(rows)}


def get_trending(limit: int = 12, force: bool = False) -> dict:
    now = time.time()
    if not force and _CACHE['data'] is not None and now - _CACHE['ts'] < CACHE_SEC:
        out = dict(_CACHE['data'])
    else:
        out = rank_tickers(_fetch_tickers(), 30)
        out['generated_at'] = int(now)
        out['source'] = _LAST_SOURCE            # e.g. 'CoinMarketCap'
        out['source_chain'] = [dict(x) for x in _LAST_SOURCE_CHAIN]
        _CACHE.update(ts=now, data=out)
        out = dict(out)
    n = max(1, min(int(limit), 30))
    for k in ('trending', 'gainers', 'losers'):
        out[k] = out[k][:n]
    out['min_quote_volume'] = MIN_QUOTE_VOLUME
    return out
