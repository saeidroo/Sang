"""V22.3l: reconcile successive BTC 4h snapshots and fail closed on revisions."""
from __future__ import annotations
import hashlib, json, os
from pathlib import Path
from datetime import datetime, timezone

FIELDS = ("open", "high", "low", "close", "volume")

def _digest(obj):
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode()).hexdigest()

def _index(rows):
    out = {}
    for row in rows:
        t = int(row["t"])
        if t in out:
            raise ValueError(f"duplicate_timestamp:{t}")
        vals = {k: float(row[k]) for k in FIELDS}
        if not all(__import__('math').isfinite(v) for v in vals.values()):
            raise ValueError(f"non_finite_value:{t}")
        out[t] = vals
    return out

def reconcile_candles(previous, current, *, abs_tolerance=0.0, rel_tolerance=0.0):
    """Compare timestamp-aligned OHLCV; additions are normal, revisions/removals are drift."""
    if abs_tolerance < 0 or rel_tolerance < 0:
        raise ValueError("tolerances_must_be_non_negative")
    old, new = _index(previous), _index(current)
    old_ts, new_ts = set(old), set(new)
    revised = []
    for t in sorted(old_ts & new_ts):
        changes = {}
        for field in FIELDS:
            a, b = old[t][field], new[t][field]
            delta = abs(b-a)
            allowed = abs_tolerance + rel_tolerance * max(abs(a), abs(b))
            if delta > allowed:
                changes[field] = {"previous": a, "current": b, "absolute_delta": delta}
        if changes:
            revised.append({"t": t, "changes": changes})
    added = sorted(new_ts-old_ts)
    removed = sorted(old_ts-new_ts)
    return {
        "status": "BLOCKED" if revised or removed else "PASS",
        "previous_rows": len(old), "current_rows": len(new),
        "added_timestamps": added, "removed_timestamps": removed,
        "revised_candles": revised, "revision_count": len(revised),
        "added_count": len(added), "removed_count": len(removed),
        "previous_sha256": _digest(previous), "current_sha256": _digest(current),
        "policy": {"abs_tolerance": abs_tolerance, "rel_tolerance": rel_tolerance,
                   "training_allowed": not (revised or removed)},
    }

def reconcile_store(root, *, snapshot=None, abs_tolerance=0.0, rel_tolerance=0.0):
    """Compare latest stored snapshot with an explicitly supplied snapshot file or rows."""
    root = Path(root)
    manifest = json.loads((root/"manifest.json").read_text(encoding="utf-8"))
    prior_name = manifest.get("latest_snapshot")
    if not prior_name:
        raise FileNotFoundError("no_previous_snapshot")
    prior_payload = json.loads((root/"snapshots"/prior_name).read_text(encoding="utf-8"))
    if _digest(prior_payload.get("candles", [])) != prior_payload.get("data_sha256"):
        raise ValueError("previous_snapshot_hash_mismatch")
    if isinstance(snapshot, (str, Path)):
        current_payload = json.loads(Path(snapshot).read_text(encoding="utf-8"))
        current = current_payload.get("candles", [])
    elif isinstance(snapshot, dict):
        current = snapshot.get("candles", [])
    else:
        current = snapshot
    if not isinstance(current, list):
        raise ValueError("current_snapshot_candles_required")
    report = reconcile_candles(prior_payload["candles"], current,
                               abs_tolerance=abs_tolerance, rel_tolerance=rel_tolerance)
    report.update({"created_at_utc": datetime.now(timezone.utc).isoformat(),
                   "previous_snapshot": prior_name,
                   "training_allowed": report["status"] == "PASS", "live_orders": False})
    report["report_sha256"] = _digest(report)
    path = root/"reconciliation"; path.mkdir(parents=True, exist_ok=True)
    target = path/(report["report_sha256"][:20]+".json")
    tmp = target.with_suffix(".tmp")
    tmp.write_text(json.dumps(report, sort_keys=True, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(tmp, target)
    return report

def require_reconciliation_clear(report):
    if not isinstance(report, dict) or report.get("status") != "PASS" or report.get("training_allowed") is not True:
        raise ValueError("btc_source_drift_blocks_training")
    return True
