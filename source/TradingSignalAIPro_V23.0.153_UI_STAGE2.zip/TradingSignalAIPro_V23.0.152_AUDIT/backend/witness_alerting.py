"""Operational metrics, webhook alerts and bounded scheduler-history retention (V22.2s)."""
from __future__ import annotations
import json, sqlite3, time
from datetime import datetime, timezone, timedelta
from urllib.request import Request, urlopen
from pathlib import Path


def _safe_url(url):
    if not (url.startswith('https://') or url.startswith('http://127.0.0.1') or url.startswith('http://localhost')):
        raise ValueError('webhook_requires_https')


def send_webhook(url, event, *, token=None, timeout=8):
    """Send a compact JSON alert; never include replication bearer credentials."""
    _safe_url(url)
    body=json.dumps(event,ensure_ascii=False,separators=(',',':')).encode()
    headers={'Content-Type':'application/json','User-Agent':'TradingSignalAIPro-Witness/22.2s'}
    if token: headers['Authorization']='Bearer '+token
    req=Request(url,data=body,headers=headers,method='POST')
    with urlopen(req,timeout=timeout) as response:
        if response.status < 200 or response.status >= 300: raise RuntimeError('webhook_http_error')
        return {'status':'sent','http_status':response.status}


def notify_if_needed(result, webhook_url=None, *, webhook_token=None):
    alerts=result.get('alerts') or []
    if not webhook_url or not alerts: return {'status':'skipped','reason':'no_webhook_or_alert'}
    event={'event':'witness_replication_alert','timestamp':datetime.now(timezone.utc).isoformat(),
           'severity':'critical' if result.get('status')=='failed' else 'warning',
           'alerts':alerts,'status':result.get('status'),'source_sequence':result.get('source_sequence'),
           'replica_sequence':result.get('replica_sequence'),'lag':result.get('lag'),
           'error':result.get('error')}
    try: return send_webhook(webhook_url,event,token=webhook_token)
    except Exception as exc: return {'status':'failed','error':f'{type(exc).__name__}: {exc}'[:500]}


def scheduler_metrics(state_db):
    p=Path(state_db)
    if not p.exists(): return {'runs_total':0,'success_total':0,'failed_total':0,'last_run_timestamp':0,'last_lag':None,'last_duration_seconds':None}
    with sqlite3.connect(p) as db:
        row=db.execute("SELECT COUNT(*),SUM(status='success'),SUM(status='failed') FROM replication_runs").fetchone()
        last=db.execute('SELECT finished_at,lag,duration_seconds,status FROM replication_runs ORDER BY id DESC LIMIT 1').fetchone()
    stamp=0
    if last:
        stamp=datetime.fromisoformat(last[0]).timestamp()
    return {'runs_total':row[0] or 0,'success_total':row[1] or 0,'failed_total':row[2] or 0,
            'last_run_timestamp':stamp,'last_lag':last[1] if last else None,
            'last_duration_seconds':last[2] if last else None,'last_status':last[3] if last else None}


def prometheus_metrics(state_db):
    m=scheduler_metrics(state_db)
    lines=['# HELP witness_replication_runs_total Total recorded replication runs.',
           '# TYPE witness_replication_runs_total counter',f"witness_replication_runs_total {m['runs_total']}",
           '# TYPE witness_replication_success_total counter',f"witness_replication_success_total {m['success_total']}",
           '# TYPE witness_replication_failed_total counter',f"witness_replication_failed_total {m['failed_total']}",
           '# TYPE witness_replication_last_run_timestamp_seconds gauge',f"witness_replication_last_run_timestamp_seconds {m['last_run_timestamp']}"]
    if m['last_lag'] is not None: lines += ['# TYPE witness_replication_lag gauge',f"witness_replication_lag {m['last_lag']}"]
    if m['last_duration_seconds'] is not None: lines += ['# TYPE witness_replication_last_duration_seconds gauge',f"witness_replication_last_duration_seconds {m['last_duration_seconds']}"]
    return '\n'.join(lines)+'\n'


def prune_scheduler_history(state_db, *, retention_days=30, max_rows=10000, vacuum=False, dry_run=False):
    if retention_days < 1 or max_rows < 1: raise ValueError('invalid_retention_policy')
    cutoff=(datetime.now(timezone.utc)-timedelta(days=retention_days)).isoformat()
    with sqlite3.connect(state_db) as db:
        old=db.execute('SELECT COUNT(*) FROM replication_runs WHERE finished_at < ?',(cutoff,)).fetchone()[0]
        total=db.execute('SELECT COUNT(*) FROM replication_runs').fetchone()[0]
        excess=max(0,total-old-max_rows)
        if not dry_run:
            db.execute('DELETE FROM replication_runs WHERE finished_at < ?',(cutoff,))
            if excess:
                db.execute('DELETE FROM replication_runs WHERE id IN (SELECT id FROM replication_runs ORDER BY id ASC LIMIT ?)',(excess,))
            db.commit()
    if vacuum and not dry_run:
        with sqlite3.connect(state_db) as db: db.execute('VACUUM')
    return {'dry_run':dry_run,'expired_rows':old,'excess_rows':excess,'deleted_rows':0 if dry_run else old+excess,
            'remaining_rows':total if dry_run else total-old-excess,'retention_days':retention_days,'max_rows':max_rows,'vacuumed':bool(vacuum and not dry_run)}
