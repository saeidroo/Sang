"""Deterministic closed-candle replay primitives for PAPER positions.

This module deliberately performs no network or database I/O. Callers must
supply validated, chronologically ordered, CLOSED OHLC candles from the
position's pinned exchange and timeframe. Missing candles fail closed.
"""
from __future__ import annotations

from typing import Iterable

from backend.bracket_execution import evaluate_bracket_candle


def replay_closed_candles(*, side: str, stop_price: float, target_price: float,
                          candles: Iterable[dict], timeframe_seconds: int,
                          last_processed_open_ms: int | None = None,
                          opened_at_ms: int | None = None,
                          now_ms: int | None = None,
                          max_bars: int = 10000,
                          horizon_bars: int | None = None,
                          trailing_trigger_pct: float | None = None,
                          trailing_distance_pct: float | None = None,
                          trailing_peak_price: float | None = None,
                          trailing_active: bool = False,
                          entry_price: float | None = None) -> dict:
    """Replay each unseen closed candle once, stopping at the first exit.

    Candle ``t`` is its UTC open timestamp in milliseconds. A candle is
    eligible only when ``t + timeframe_seconds*1000 <= now_ms``. The cursor
    is advanced only for candles actually evaluated. Gaps, duplicates,
    reordering, malformed timestamps, and excessive batches raise ValueError.
    """
    import math
    import time

    if isinstance(timeframe_seconds, bool) or int(timeframe_seconds) <= 0:
        raise ValueError("timeframe_seconds must be positive")
    step = int(timeframe_seconds) * 1000
    now = int(time.time() * 1000) if now_ms is None else int(now_ms)
    cursor = int(last_processed_open_ms) if last_processed_open_ms is not None else None
    opened = int(opened_at_ms) if opened_at_ms is not None else None
    rows = list(candles)
    if len(rows) > int(max_bars):
        raise ValueError("replay_batch_too_large")

    processed = 0
    exit_result = None
    # On the first replay, anchor continuity to the candle containing entry.
    # If entry happened mid-candle, that partial bar is skipped below and the
    # next complete candle is required; this prevents both look-ahead and a
    # silently missing first post-entry candle.
    if cursor is not None:
        expected = cursor + step
    elif opened is not None:
        expected = opened - (opened % step)
    else:
        expected = None
    active_stop = float(stop_price)
    peak = float(trailing_peak_price) if trailing_peak_price is not None else None
    trail_on = bool(trailing_active)
    if (trailing_trigger_pct is None) != (trailing_distance_pct is None):
        raise ValueError("trailing_parameters_must_be_paired")
    if trailing_trigger_pct is not None:
        trigger = float(trailing_trigger_pct)
        distance = float(trailing_distance_pct)
        if not math.isfinite(trigger) or trigger <= 0 or not math.isfinite(distance) or not 0 < distance < 100:
            raise ValueError("trailing_parameters_invalid")
    else:
        trigger = distance = None
    for row in rows:
        if not isinstance(row, dict) or "t" not in row:
            raise ValueError("candle_timestamp_missing")
        try:
            ts = int(row["t"])
        except (TypeError, ValueError, OverflowError):
            raise ValueError("candle_timestamp_invalid")
        if ts < 0 or (cursor is not None and ts <= cursor):
            raise ValueError("duplicate_or_reordered_candle")
        if expected is not None and ts != expected:
            raise ValueError("candle_gap_detected")
        if ts + step > now:
            # Do not process an in-progress candle or any later candle.
            break
        if opened is not None and ts < opened:
            cursor = ts
            expected = ts + step
            continue
        result = evaluate_bracket_candle(side=side, stop_price=active_stop,
                                         target_price=target_price, candle=row)
        cursor = ts
        expected = ts + step
        processed += 1
        if result["triggered"]:
            exit_result = dict(result)
            exit_result["candle_open_ms"] = ts
            break
        # Update trailing from the completed candle only after checking its
        # existing bracket. The newly tightened stop becomes active next bar;
        # this avoids inventing an intrabar high/low sequence.
        if trigger is not None:
            high = float(row["high"])
            low = float(row["low"])
            if not all(math.isfinite(v) and v > 0 for v in (high, low)) or low > high:
                raise ValueError("candle_ohlc_invalid")
            if str(side).upper() in ("LONG", "BUY"):
                peak = max(high, peak if peak is not None else high)
            else:
                peak = min(low, peak if peak is not None else low)
            if entry_price is not None:
                entry = float(entry_price)
                progress = ((peak / entry - 1.0) * 100.0 if str(side).upper() in ("LONG", "BUY")
                            else (entry / peak - 1.0) * 100.0)
                trail_on = trail_on or progress >= trigger
                if trail_on:
                    candidate = (peak * (1.0 - distance / 100.0) if str(side).upper() in ("LONG", "BUY")
                                 else peak * (1.0 + distance / 100.0))
                    tighter = candidate > active_stop if str(side).upper() in ("LONG", "BUY") else candidate < active_stop
                    safely_behind = candidate < float(row["close"]) if str(side).upper() in ("LONG", "BUY") else candidate > float(row["close"])
                    if tighter and safely_behind:
                        active_stop = candidate
        bars_elapsed = (max(1, int(math.ceil((ts + step - opened) / step)))
                        if opened is not None else processed)
        if horizon_bars is not None and bars_elapsed >= int(horizon_bars):
            exit_result = {"triggered": True, "reason": "TIME_EXIT",
                           "fill_reference": float(row["close"]), "stop_hit": False,
                           "target_hit": False, "candle_open_ms": ts}
            break

    return {
        "processed_count": processed,
        "last_processed_open_ms": cursor,
        "exit": exit_result,
        "status": "EXIT_TRIGGERED" if exit_result else "REPLAYED",
        "policy": "STOP_FIRST_CONSERVATIVE",
        "stop_price": active_stop,
        "trailing_peak_price": peak,
        "trailing_active": trail_on,
    }
