"""V23.0.138 read-only multi-interval order-flow absorption evidence.

Requires caller-supplied interval buy/sell aggressor volumes and price changes.
It does not infer hidden orders, participant identity, or intent.
"""
from __future__ import annotations
import math


def _num(value):
    if isinstance(value, bool) or value is None:
        return None
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except (TypeError, ValueError, OverflowError):
        return None


def _valid_samples(raw):
    if not isinstance(raw, list) or len(raw) > 500:
        return []
    out = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        buy = _num(item.get('aggressive_buy_volume'))
        sell = _num(item.get('aggressive_sell_volume'))
        move = _num(item.get('price_change_pct'))
        if buy is None or sell is None or move is None or buy < 0 or sell < 0 or buy + sell <= 0:
            continue
        out.append({'buy': buy, 'sell': sell, 'move': move,
                    'timestamp': item.get('timestamp')})
    return out


def analyze_absorption(candidates, *, dominance_ratio=1.8, max_adverse_move_pct=0.15,
                       min_samples=3, persistence_ratio=0.60):
    if not isinstance(candidates, list):
        raise ValueError('candidates must be a list')
    dominance = _num(dominance_ratio)
    adverse = _num(max_adverse_move_pct)
    persistence = _num(persistence_ratio)
    if dominance is None or not 1.1 <= dominance <= 10:
        raise ValueError('dominance_ratio must be between 1.1 and 10')
    if adverse is None or not 0.01 <= adverse <= 2:
        raise ValueError('max_adverse_move_pct must be between 0.01 and 2')
    if isinstance(min_samples, bool) or not isinstance(min_samples, int) or not 3 <= min_samples <= 50:
        raise ValueError('min_samples must be an integer between 3 and 50')
    if persistence is None or not 0.5 <= persistence <= 1:
        raise ValueError('persistence_ratio must be between 0.5 and 1')

    results = []
    for raw in candidates[:100]:
        if not isinstance(raw, dict):
            results.append({'decision': 'INSUFFICIENT_DATA', 'reasons': ['INVALID_CANDIDATE'],
                            'entry_authorized': False, 'execution_authorized': False})
            continue
        samples = _valid_samples(raw.get('samples'))
        symbol = str(raw.get('symbol') or '').upper().strip()
        if len(samples) < min_samples:
            results.append({'symbol': symbol, 'decision': 'INSUFFICIENT_DATA',
                            'reasons': ['INSUFFICIENT_VALID_FLOW_SAMPLES'],
                            'evidence': {'valid_samples': len(samples), 'required_samples': min_samples},
                            'entry_authorized': False, 'execution_authorized': False})
            continue

        bid_hits, ask_hits = [], []
        for sample in samples:
            buy, sell, move = sample['buy'], sample['sell'], sample['move']
            # Sell aggression fails to push price materially lower: possible bid absorption.
            if sell >= buy * dominance and move >= -adverse:
                bid_hits.append(sample)
            # Buy aggression fails to push price materially higher: possible ask absorption.
            if buy >= sell * dominance and move <= adverse:
                ask_hits.append(sample)

        bid_rate, ask_rate = len(bid_hits) / len(samples), len(ask_hits) / len(samples)
        bid_ok, ask_ok = bid_rate >= persistence, ask_rate >= persistence
        total_buy = sum(x['buy'] for x in samples)
        total_sell = sum(x['sell'] for x in samples)
        evidence = {
            'valid_samples': len(samples),
            'bid_absorption_intervals': len(bid_hits),
            'ask_absorption_intervals': len(ask_hits),
            'bid_absorption_persistence': round(bid_rate, 4),
            'ask_absorption_persistence': round(ask_rate, 4),
            'aggregate_aggressive_buy_volume': round(total_buy, 8),
            'aggregate_aggressive_sell_volume': round(total_sell, 8),
            'median_price_change_pct': round(sorted(x['move'] for x in samples)[len(samples)//2], 6),
            'dominance_ratio_required': dominance,
            'max_adverse_move_pct': adverse,
        }
        if bid_ok and ask_ok:
            decision, direction = 'CONFLICTING_ABSORPTION_EVIDENCE', 'BOTH'
        elif bid_ok:
            decision, direction = 'PERSISTENT_BID_ABSORPTION_CANDIDATE', 'POTENTIALLY_BULLISH'
        elif ask_ok:
            decision, direction = 'PERSISTENT_ASK_ABSORPTION_CANDIDATE', 'POTENTIALLY_BEARISH'
        else:
            decision, direction = 'NO_PERSISTENT_ABSORPTION_EVIDENCE', 'NONE'
        results.append({'symbol': symbol, 'decision': decision, 'context': direction,
                        'confidence': 'MODERATE' if bid_ok or ask_ok else 'LOW',
                        'evidence': evidence, 'reasons': [],
                        'entry_authorized': False, 'execution_authorized': False})

    return {'version': '23.0.138', 'count': len(results), 'results': results,
            'data_policy': 'REQUIRES_INTERVAL_AGGRESSOR_VOLUME_AND_PRICE_CHANGE',
            'paper_only': True, 'entry_authorized': False, 'execution_authorized': False,
            'creates_orders': False, 'real_orders_enabled': False,
            'disclaimer': 'جذب سفارش فقط یک فرضیه مبتنی بر جریان معاملات و واکنش قیمت است؛ سفارش پنهان، نهنگ یا قصد معامله‌گر را اثبات نمی‌کند.'}
