"""Scenario-based read-only source failover drill and operator gate."""
from __future__ import annotations
import hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path
from backend.btc_cross_source_readonly import select_readonly_failover

ZERO='0'*64

def _canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def _sha(value): return hashlib.sha256(_canonical(value)).hexdigest()

REQUIRED_SCENARIOS={
 'both_sources_agree':'PASS',
 'primary_source_down':'DEGRADED',
 'backup_source_down':'DEGRADED',
 'source_data_mismatch':'BLOCKED',
 'both_sources_down':'BLOCKED',
 'primary_source_recovery':'PASS',
}


def evaluate_source_failover_drill(*, scenarios, operator_approved=False):
    if not isinstance(scenarios,dict): raise ValueError('source_failover_scenarios_invalid')
    results={}; errors=[]
    for name,expected in REQUIRED_SCENARIOS.items():
        scenario=scenarios.get(name)
        if not isinstance(scenario,dict):
            errors.append(f'scenario_missing:{name}'); continue
        actual=select_readonly_failover(scenario.get('primary'),scenario.get('backup'))
        passed=actual.get('status')==expected
        if name=='primary_source_down': passed=passed and actual.get('selected_source')=='OKX' and actual.get('fallback_used') is True
        if name=='backup_source_down': passed=passed and actual.get('selected_source')=='Binance' and actual.get('fallback_used') is False
        if actual.get('training_allowed') is not False or actual.get('live_orders') is not False:
            passed=False
        if not passed: errors.append(f'scenario_expectation_failed:{name}')
        results[name]={'expected_status':expected,'actual_status':actual.get('status'),
            'selected_source':actual.get('selected_source'),'fallback_used':actual.get('fallback_used'),
            'passed':passed,'training_allowed':False,'live_orders':False}
    if operator_approved is not True: errors.append('operator_approval_missing')
    status='READY_READONLY_FAILOVER' if not errors else 'BLOCKED'
    evidence={'schema_version':'btc-4h-source-failover-drill-v1','status':status,
        'created_at_utc':datetime.now(timezone.utc).isoformat(),'scenario_results':results,
        'required_scenarios':REQUIRED_SCENARIOS,'operator_approved':operator_approved is True,
        'errors':errors,'training_allowed':False,'live_orders':False,
        'scope':'read_only_source_failover_only'}
    evidence['evidence_sha256']=_sha(evidence)
    return evidence


def append_source_failover_evidence(evidence: dict, *, log_path):
    if not isinstance(evidence,dict) or evidence.get('schema_version')!='btc-4h-source-failover-drill-v1':
        raise ValueError('source_failover_evidence_invalid')
    body=dict(evidence); declared=body.pop('evidence_sha256',None)
    if not declared or _sha(body)!=declared: raise ValueError('source_failover_evidence_hash_mismatch')
    path=Path(log_path).expanduser(); path.parent.mkdir(parents=True,exist_ok=True)
    rows=[]
    if path.exists():
        for i,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
            try: rows.append(json.loads(line))
            except ValueError as exc: raise ValueError(f'source_failover_log_corrupt_line:{i}') from exc
    previous=ZERO
    for seq,row in enumerate(rows,1):
        item=dict(row); digest=item.pop('record_sha256',None)
        if row.get('sequence')!=seq or row.get('previous_record_sha256')!=previous or not digest or _sha(item)!=digest:
            raise ValueError('source_failover_log_chain_invalid')
        previous=digest
    record={'sequence':len(rows)+1,'previous_record_sha256':previous,'evidence':evidence}
    record['record_sha256']=_sha(record)
    raw=_canonical(record)+b'\n'; fd=os.open(str(path),os.O_CREAT|os.O_APPEND|os.O_WRONLY,0o600)
    try:
        written=os.write(fd,raw)
        if written!=len(raw): raise OSError('source_failover_log_short_append')
        os.fsync(fd)
    finally: os.close(fd)
    return {'sequence':record['sequence'],'record_sha256':record['record_sha256'],'status':evidence['status']}
