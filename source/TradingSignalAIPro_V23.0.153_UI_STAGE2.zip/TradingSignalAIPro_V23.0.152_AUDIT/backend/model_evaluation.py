"""V22.3a: leakage-aware, chronological model evaluation primitives.

This module intentionally evaluates caller-supplied predictions. It never fits,
selects thresholds, or fetches market data, so the final test block stays untouched.
"""
from __future__ import annotations
import math
import re
import numpy as np
import pandas as pd

EVALUATION_VERSION = 'model-eval-v1'

# Explicitly suspicious names; heuristic only, never a proof of leakage.
_SUSPICIOUS = re.compile(r'(^|[_\W])(target|label|future|forward|lead|next_close|next_return|y_true)([_\W]|$)', re.I)


def audit_feature_schema(columns, *, target_column=None, timestamp_column=None):
    names = [str(c) for c in columns]
    if len(names) != len(set(names)):
        raise ValueError('duplicate feature column names')
    suspicious = [c for c in names if c != target_column and _SUSPICIOUS.search(c)]
    if target_column and target_column in names:
        suspicious.append(target_column)
    if timestamp_column and timestamp_column not in names:
        raise ValueError('timestamp_column is not present')
    return {
        'audit_version': 'feature-schema-audit-v1',
        'feature_count': len(names),
        'suspicious_columns': sorted(set(suspicious)),
        'status': 'WARN' if suspicious else 'PASS',
        'disclaimer': 'Name-based heuristic only; inspect feature construction and shift/rolling semantics manually.'
    }


def chronological_split(frame, *, timestamp_column, train_fraction=.70, validation_fraction=.15):
    """Stable chronological split; refuses duplicate or non-monotonic timestamps."""
    if not isinstance(frame, pd.DataFrame) or len(frame) < 20:
        raise ValueError('frame must be a DataFrame with at least 20 rows')
    if timestamp_column not in frame:
        raise ValueError('timestamp column missing')
    if not (0 < train_fraction < 1 and 0 < validation_fraction < 1 and train_fraction + validation_fraction < 1):
        raise ValueError('invalid split fractions')
    ts = pd.to_datetime(frame[timestamp_column], utc=True, errors='coerce')
    if ts.isna().any():
        raise ValueError('timestamps contain invalid values')
    if ts.duplicated().any():
        raise ValueError('duplicate timestamps are not allowed')
    if not ts.is_monotonic_increasing:
        raise ValueError('timestamps must already be chronological; implicit sorting is forbidden')
    n = len(frame); a = int(math.floor(n * train_fraction)); b = int(math.floor(n * (train_fraction + validation_fraction)))
    if a < 2 or b-a < 2 or n-b < 2:
        raise ValueError('each split must contain at least two rows')
    return {'train': frame.iloc[:a].copy(), 'validation': frame.iloc[a:b].copy(), 'test': frame.iloc[b:].copy(),
            'split_version': 'chronological-70-15-15-v1', 'boundaries': {'train_end': ts.iloc[a-1].isoformat(), 'validation_end': ts.iloc[b-1].isoformat(), 'test_start': ts.iloc[b].isoformat()},
            'n_rows': n}


def assert_label_horizon_purged(train_end_positions, validation_start_position, *, embargo_bars=0):
    """Reject training labels whose information horizon reaches validation."""
    p = np.asarray(train_end_positions, dtype=int)
    if p.ndim != 1 or not len(p) or (p < 0).any():
        raise ValueError('train_end_positions must be a non-empty non-negative vector')
    if int(validation_start_position) < 0 or int(embargo_bars) < 0:
        raise ValueError('positions and embargo must be non-negative')
    cutoff = int(validation_start_position) - int(embargo_bars)
    leaking = np.flatnonzero(p >= cutoff)
    return {'valid': len(leaking) == 0, 'cutoff_exclusive': cutoff, 'leaking_indices': leaking.tolist(),
            'purged_count_required': int(len(leaking))}


def classification_report(y_true, probabilities, *, threshold=.5):
    y = np.asarray(y_true); p = np.asarray(probabilities, dtype=float)
    if y.ndim != 1 or p.shape != y.shape or len(y) < 2 or not np.isfinite(p).all():
        raise ValueError('labels and probabilities must be aligned finite vectors with >=2 rows')
    if not np.isin(y, [0, 1]).all() or ((p < 0) | (p > 1)).any():
        raise ValueError('binary labels and probabilities in [0,1] required')
    if not 0 < float(threshold) < 1:
        raise ValueError('threshold must be between 0 and 1')
    pred = p >= threshold; y = y.astype(bool)
    tp = int(np.sum(pred & y)); tn = int(np.sum(~pred & ~y)); fp = int(np.sum(pred & ~y)); fn = int(np.sum(~pred & y))
    precision = tp/(tp+fp) if tp+fp else 0.0; recall = tp/(tp+fn) if tp+fn else 0.0
    return {'n': len(y), 'threshold': float(threshold), 'accuracy': float((tp+tn)/len(y)),
            'balanced_accuracy': float((recall + (tn/(tn+fp) if tn+fp else 0.0))/2),
            'precision': precision, 'recall': recall, 'f1': 2*precision*recall/(precision+recall) if precision+recall else 0.0,
            'brier': float(np.mean((p-y.astype(float))**2)), 'confusion': {'tp':tp,'tn':tn,'fp':fp,'fn':fn}}


def evaluate_binary_model(y_true, probabilities, *, threshold=.5, test_block='caller_asserted_untouched'):
    """Report model against constant prevalence and majority-class baselines."""
    report = classification_report(y_true, probabilities, threshold=threshold)
    y = np.asarray(y_true, dtype=int); prevalence = float(y.mean()); majority = int(prevalence >= .5)
    base_acc = float(np.mean(y == majority))
    return {'evaluation_version': EVALUATION_VERSION, 'test_block': test_block,
            'model': report, 'baselines': {'majority_class_accuracy': base_acc,
            'constant_prevalence_brier': float(np.mean((prevalence-y)**2)),
            'random_50_accuracy_expected': .5},
            'beats_majority_accuracy': bool(report['accuracy'] > base_acc),
            'warning': 'A single test block does not establish future profitability or stable predictive edge.'}
