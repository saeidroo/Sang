"""V20 — Pool of ALL trained models («از همه آموزش‌ها در تحلیل استفاده کن»).

When the user has trained several (symbol, timeframe) pairs — e.g. through the
multi-hour trainer — the analysis of ONE pair should also benefit from the
knowledge stored in EVERY other trained model:

  * primary model : exact (symbol, timeframe) match — dominant weight
  * same symbol, other timeframes : a multi-timeframe view of this market
  * same timeframe, other symbols : a cross-market regime vote
  * everything else               : general market knowledge

Design rules (matching the project's honesty culture):
  * The pool NEVER overrides the primary model. It blends a bounded share
    (max 30%) into the probability and adds a consensus note to the signal.
  * Only models saved with the CURRENT feature schema are used.
  * Every model vote is recorded and shown, so nothing is hidden.
  * When the exact pair has no trained model at all, the analysis can still
    run in a clearly-labelled ADVISORY mode (conservative gate) instead of
    failing — see advisory_gate().

V20.1 — feedback-weighted votes: the central brain records how the ML
channel of every trained pair actually performed over matured 12-bar
horizons (backend/brain.py). ``brain_track_records`` reads that ledger in
ONE pass and scales each candidate's quality by a bounded multiplier
(x0.85..x1.15). Models whose directional calls keep failing lose voting
weight; models that keep being right gain some. No data -> multiplier 1.0.
"""
from __future__ import annotations

import json
import os
import threading
from collections import OrderedDict
from pathlib import Path

import pandas as pd

from .storage import get_models_dir, load_meta
from .features import FEATURE_SCHEMA_VERSION

TF_ORDER = ['5m', '15m', '30m', '1h', '4h', '1d']

# Relation weights: how relevant a trained model is to the analysed pair.
W_SAME_SYMBOL_OTHER_TF = 1.00   # same market, different timeframe
W_SAME_TF_OTHER_SYMBOL = 0.70   # same timeframe, different market
W_TWIN_SAME_TF = 0.90          # V21: spot <-> perpetual of the SAME coin, same timeframe
W_TWIN_OTHER_TF = 0.60          # V21: spot <-> perpetual of the same coin, other timeframe
W_OTHER = 0.45                  # different market AND different timeframe

# Blend weight into the primary probability: grows with the number of votes
# but is hard-capped so the primary model always dominates.
BLEND_PER_VOTE = 0.08
BLEND_MAX = 0.30

MAX_POOL_MODELS = 8             # strongest models only — keeps latency sane

# Advisory gate (no primary model available)
ADVISORY_MIN_VOTES = 3
ADVISORY_MIN_AGREEMENT = 0.65
ADVISORY_MIN_EDGE_SHARE = 0.5   # weighted share of edge-confirmed voters

# V20.1: brain-feedback vote weighting (bounded, damping + mild amplification)
BRAIN_TRACK_MIN_SAMPLES = 20
BRAIN_MULT_MIN = 0.85
BRAIN_MULT_MAX = 1.15


_CACHE: "OrderedDict[str, object]" = OrderedDict()
_CACHE_MAX = 12
_CACHE_LOCK = threading.Lock()


def _load_model_cached(path: Path):
    """Load a TradingEnsemble once per process; cache the latest ones."""
    from .model import TradingEnsemble
    # V21 fix: key includes file mtime+size. Before, a retrained model kept voting with
    # its OLD cached copy until the app restarted.
    try:
        st = Path(path).stat()
        key = f'{path}|{st.st_mtime_ns}|{st.st_size}'
    except OSError:
        key = str(path)
    with _CACHE_LOCK:
        if key in _CACHE:
            _CACHE.move_to_end(key)
            return _CACHE[key]
        for old in [k for k in _CACHE if k.split('|', 1)[0] == str(path)]:
            _CACHE.pop(old, None)          # drop superseded versions of this file
    model = TradingEnsemble.load(path)
    if model is not None and getattr(model, 'is_fitted', False):
        with _CACHE_LOCK:
            _CACHE[key] = model
            while len(_CACHE) > _CACHE_MAX:
                _CACHE.popitem(last=False)
    return model


def _underlying(sym: str) -> str:
    s = str(sym).upper()
    return s[:-4] if s.endswith('USDTPERP') else s


def _relation_weight(sym: str, tf: str, pool_sym: str, pool_tf: str) -> float:
    # V21: BTCUSDT and BTCUSDTPERP are the same underlying coin, not strangers.
    if sym != pool_sym and _underlying(sym) == _underlying(pool_sym):
        return W_TWIN_SAME_TF if tf == pool_tf else W_TWIN_OTHER_TF
    if sym == pool_sym and tf != pool_tf:
        return W_SAME_SYMBOL_OTHER_TF
    if tf == pool_tf and sym != pool_sym:
        return W_SAME_TF_OTHER_SYMBOL
    return W_OTHER


def _quality(meta: dict, brain_mult: float = 1.0) -> float:
    """0..1 quality multiplier from the model's own saved validation stats,
    scaled by the central brain's matured feedback for that exact pair."""
    # V21 fix: taking the MAX of several validation numbers was optimistically biased.
    # Use the most honest available metric, in order: walk-forward > balanced > plain val.
    acc = None
    for key in ('walk_forward_acc', 'balanced_acc', 'val_acc'):
        try:
            v = float(meta.get(key))
        except (TypeError, ValueError):
            continue
        if v and 0 < v <= 1:
            acc = v
            break
    q = max(0.35, min(0.90, acc or 0.50))
    if meta.get('edge_confirmed'):
        q = min(1.0, q * 1.15)
    try:
        q = q * max(BRAIN_MULT_MIN, min(BRAIN_MULT_MAX, float(brain_mult)))
    except (TypeError, ValueError):
        pass
    return max(0.30, min(1.0, q))


def brain_track_records(pairs) -> dict:
    """V20.1 — matured ML-channel track record per (symbol, timeframe) pair.

    Reads the brain feedback ledger ONCE (single SQL pass, up to 20000 rows)
    and, with the same one-observation-per-horizon spacing rule as the brain,
    counts how often the stored ML score pointed in the same direction as the
    realised outcome. Pairs with fewer than BRAIN_TRACK_MIN_SAMPLES matured ML
    observations get multiplier 1.0 (no evidence -> no change). The Wilson
    lower bound is mapped to a bounded multiplier:

        lower 0.50 -> 1.00 | lower 0.575 -> BRAIN_MULT_MAX | lower 0.425 -> BRAIN_MULT_MIN

    Never raises: any storage problem returns {} (all multipliers 1.0).
    """
    wanted = {(str(s), str(t)) for s, t in (pairs or [])}
    if not wanted:
        return {}
    try:
        from .brain import TF_MS, HORIZON_BARS, _connection, _wilson_lower
    except Exception:
        return {}
    counts = {p: [0, 0] for p in wanted}
    last_used = {p: None for p in wanted}
    try:
        with _connection() as conn:
            rows = conn.execute(
                '''SELECT symbol,timeframe,bar_ts,components_json,realized_return
                   FROM brain_observations WHERE realized_return IS NOT NULL
                   ORDER BY bar_ts DESC LIMIT 20000''').fetchall()
    except Exception:
        return {}
    for sym, tf, bar_ts, raw, realized in rows:
        pair = (sym, tf)
        if pair not in wanted:
            continue
        try:
            ret = float(realized)
        except (TypeError, ValueError):
            continue
        if ret != ret or ret in (float('inf'), float('-inf')) or abs(ret) < 0.0002:
            continue
        try:
            comps = json.loads(raw)
        except Exception:
            continue
        if not isinstance(comps, dict):
            continue
        try:
            score = float(comps.get('ml'))
        except (TypeError, ValueError):
            continue
        if score != score or abs(score) < 0.15:
            continue
        spacing = TF_MS.get(tf, 0) * HORIZON_BARS
        prev = last_used[pair]
        if prev is not None and spacing and prev - int(bar_ts) < spacing:
            continue
        last_used[pair] = int(bar_ts)
        c = counts[pair]
        c[1] += 1
        if (score > 0 and ret > 0) or (score < 0 and ret < 0):
            c[0] += 1
    out = {}
    for pair, (wins, total) in counts.items():
        if total >= BRAIN_TRACK_MIN_SAMPLES:
            lower = _wilson_lower(wins, total)
            mult = 1.0 + (lower - 0.50) * 2.0
            mult = max(BRAIN_MULT_MIN, min(BRAIN_MULT_MAX, mult))
        else:
            mult = 1.0
        out[pair] = round(float(mult), 3)
    return out


def list_pool_candidates(symbol: str = None, timeframe: str = None,
                         max_models: int = MAX_POOL_MODELS) -> list:
    """Saved models compatible with the current feature schema, best first.

    Excludes the exact analysed pair (that one is the primary model) and ranks
    the rest by (edge_confirmed, quality). The analysed pair's own timeframe/
    symbol boosts relevance for the *order* of votes, not correctness.
    """
    d = get_models_dir()
    out = []
    for mp in sorted(d.glob('model_*.joblib')):
        name = mp.stem[len('model_'):]
        # filename pattern: model_<SYMBOL>_<TF>.joblib
        try:
            stem_sym, stem_tf = name.rsplit('_', 1)
        except ValueError:
            continue
        if symbol and stem_sym == symbol and stem_tf == timeframe:
            continue  # primary model is loaded separately
        meta = load_meta(stem_sym, stem_tf)
        if not meta:
            continue
        # Strict schema filter: a model saved by a different feature schema
        # would receive features it never saw — never vote with it.
        if meta.get('feature_schema_version') != FEATURE_SCHEMA_VERSION:
            continue
        out.append({
            'symbol': stem_sym,
            'timeframe': stem_tf,
            'path': mp,
            'quality': round(_quality(meta), 4),
            'edge_confirmed': bool(meta.get('edge_confirmed')),
            'walk_forward_acc': meta.get('walk_forward_acc'),
            'val_acc': meta.get('val_acc'),
            'training_round': meta.get('training_round', 1),
            'saved_at': meta.get('saved_at'),
        })
    # V20.1: scale each candidate's quality by the brain's matured feedback
    # for that exact pair (single ledger pass; no data -> 1.0).
    try:
        tracks = brain_track_records([(c['symbol'], c['timeframe']) for c in out])
    except Exception:
        tracks = {}
    for cand in out:
        cand['brain_mult'] = tracks.get((cand['symbol'], cand['timeframe']), 1.0)
        if cand['brain_mult'] != 1.0:
            cand['quality'] = round(max(0.30, min(1.0, cand['quality'] * cand['brain_mult'])), 4)
    out.sort(key=lambda m: (m['edge_confirmed'], m['quality']), reverse=True)
    return out[:max_models]


def pool_votes(symbol: str, timeframe: str, features_full: pd.DataFrame,
               max_models: int = MAX_POOL_MODELS) -> dict:
    """Ask every eligible trained model about the CURRENT bar.

    Returns {'votes': [...], 'n', 'weight_sum', 'consensus_prob',
             'consensus_dir', 'agreement', 'same_symbol_votes',
             'same_tf_votes', 'edge_share'} — empty 'votes' when nothing usable.
    Never raises: every per-model failure is recorded and skipped.
    """
    empty = {'votes': [], 'n': 0, 'weight_sum': 0.0, 'consensus_prob': None,
             'consensus_dir': None, 'agreement': None, 'same_symbol_votes': 0,
             'same_tf_votes': 0, 'edge_share': None, 'errors': []}
    if features_full is None or len(features_full) == 0:
        return empty
    candidates = list_pool_candidates(symbol, timeframe, max_models)
    if not candidates:
        return empty

    votes = []
    errors = []
    for cand in candidates:
        try:
            model = _load_model_cached(cand['path'])
            if model is None or not getattr(model, 'is_fitted', False):
                continue
            feats = model.feature_names or []
            if not feats:
                continue
            row = features_full.iloc[[-1]][feats]
            prob = float(model.predict_proba(row, use_meta=False))
            if not (0.0 <= prob <= 1.0):
                continue
            rel = _relation_weight(symbol, timeframe,
                                   cand['symbol'], cand['timeframe'])
            w = rel * cand['quality']
            votes.append({
                'symbol': cand['symbol'],
                'timeframe': cand['timeframe'],
                'prob': round(prob, 4),
                'dir': 'UP' if prob >= 0.5 else 'DOWN',
                'conf': round(abs(prob - 0.5) * 2, 4),
                'relation': ('twin_market' if rel in (W_TWIN_SAME_TF, W_TWIN_OTHER_TF)
                             else 'same_symbol_other_tf' if rel == W_SAME_SYMBOL_OTHER_TF
                             else 'same_tf_other_symbol' if rel == W_SAME_TF_OTHER_SYMBOL
                             else 'other'),
                'weight': round(w, 4),
                'quality': cand['quality'],
                'edge_confirmed': cand['edge_confirmed'],
                'brain_mult': cand.get('brain_mult', 1.0),
            })
        except Exception as exc:
            errors.append(f"{cand['symbol']}/{cand['timeframe']}: {str(exc)[:120]}")

    if not votes:
        out = dict(empty)
        out['errors'] = errors
        return out

    w_sum = sum(v['weight'] for v in votes) or 1.0
    consensus = sum(v['prob'] * v['weight'] for v in votes) / w_sum
    up_w = sum(v['weight'] for v in votes if v['dir'] == 'UP')
    consensus_dir = 'UP' if consensus >= 0.5 else 'DOWN'
    agree_w = up_w if consensus_dir == 'UP' else (w_sum - up_w)
    edge_w = sum(v['weight'] for v in votes if v['edge_confirmed'])

    return {
        'votes': sorted(votes, key=lambda v: v['weight'], reverse=True),
        'n': len(votes),
        'weight_sum': round(w_sum, 4),
        'consensus_prob': round(float(consensus), 4),
        'consensus_dir': consensus_dir,
        'agreement': round(float(agree_w / w_sum), 4),
        'same_symbol_votes': sum(1 for v in votes if v['symbol'] == symbol),
        'same_tf_votes': sum(1 for v in votes if v['timeframe'] == timeframe),
        'edge_share': round(float(edge_w / w_sum), 4),
        'errors': errors,
    }


def blend_probability(primary_prob: float, pool: dict) -> tuple[float, float]:
    """Blend the pool consensus into the primary probability, bounded.

    Returns (final_prob, blend_weight). With 0 votes the primary passes
    through untouched.
    """
    n = int(pool.get('n') or 0)
    cp = pool.get('consensus_prob')
    if not n or cp is None:
        return float(primary_prob), 0.0
    w = min(BLEND_MAX, BLEND_PER_VOTE * n)
    final = (1.0 - w) * float(primary_prob) + w * float(cp)
    return float(max(0.0, min(1.0, final))), float(w)


def advisory_gate(pool: dict) -> tuple[bool, str]:
    """May the pool (no primary model) produce a BUY/SELL at all?

    Conservative on purpose: enough voters, a clear weighted agreement and a
    majority of voting weight from edge-confirmed models. Otherwise HOLD.
    """
    n = int(pool.get('n') or 0)
    if n < ADVISORY_MIN_VOTES:
        return False, (f'فقط {n} مدل واجد رای دادن است؛ حداقل {ADVISORY_MIN_VOTES} مدل لازم است.')
    agreement = float(pool.get('agreement') or 0.0)
    if agreement < ADVISORY_MIN_AGREEMENT:
        return False, f'هم‌جهتی مدل‌ها فقط {agreement*100:.0f}٪ است؛ حداقل {ADVISORY_MIN_AGREEMENT*100:.0f}٪ لازم است.'
    edge_share = float(pool.get('edge_share') or 0.0)
    if edge_share < ADVISORY_MIN_EDGE_SHARE:
        return False, (f'وزن مدل‌های با لبه‌ی تأییدشده فقط {edge_share*100:.0f}٪ است؛ '
                       'اجماع بدون لبه‌ی اثبات‌شده سیگنال معامله نمی‌دهد.')
    return True, 'اجماع قوی و با لبه‌ی تأییدشده.'


def suggest_seed(symbol: str, timeframe: str):
    """V21 — best already-trained model to warm-start a NEW market from.

    Returns {'symbol','timeframe','relation','quality','edge_confirmed','path'} or None.
    Rank: relation weight (twin spot/futures > same timeframe > other) x model quality,
    edge-confirmed first. Only fitted, schema-compatible models qualify. With XGBoost the
    booster itself continues; otherwise the neighbour's features + best hyper-parameters transfer.
    """
    best, best_key = None, None
    for cand in list_pool_candidates(symbol, timeframe, max_models=60):
        try:
            model = _load_model_cached(cand['path'])
        except Exception:
            continue
        if model is None or not getattr(model, 'is_fitted', False):
            continue
        if not getattr(model, 'feature_names', None):
            continue
        rel = _relation_weight(symbol, timeframe, cand['symbol'], cand['timeframe'])
        key = (bool(cand['edge_confirmed']), rel * cand['quality'])
        if best_key is None or key > best_key:
            best_key = key
            best = {'symbol': cand['symbol'], 'timeframe': cand['timeframe'],
                    'relation': ('twin_market' if rel in (W_TWIN_SAME_TF, W_TWIN_OTHER_TF)
                                 else 'same_tf_other_symbol' if rel == W_SAME_TF_OTHER_SYMBOL
                                 else 'same_symbol_other_tf' if rel == W_SAME_SYMBOL_OTHER_TF else 'other'),
                    'quality': cand['quality'], 'edge_confirmed': bool(cand['edge_confirmed']),
                    'path': cand['path']}
    return best
