"""V22.3d reproducible, leakage-safe BTC 4h training dataset contract."""
from __future__ import annotations
import hashlib, json
import numpy as np
import pandas as pd
from backend.btc_features import FEATURE_COLUMNS, build_btc_4h_features, build_direction_labels, purge_training_indices
from backend.btc_walkforward import validate_btc_4h

VERSION = 'btc-4h-dataset-contract-v1'
FORBIDDEN_TOKENS = ('label', 'forward', 'future', 'target', 'outcome', 'profit', 'return_after')


def _timestamp_identity(value):
    """Normalize candle timestamp to a stable UTC ISO-8601 identity."""
    if isinstance(value, (int, np.integer)) or (isinstance(value, (float, np.floating)) and float(value).is_integer()):
        ts = pd.to_datetime(int(value), unit='ms', utc=True)
    else:
        ts = pd.to_datetime(value, utc=True, errors='raise')
    if pd.isna(ts):
        raise ValueError('dataset_timestamp_identity_invalid')
    return ts.isoformat().replace('+00:00', 'Z')


def _jsonable(value):
    if isinstance(value, (np.integer,)): return int(value)
    if isinstance(value, (np.floating,)): return float(value)
    if isinstance(value, (np.bool_,)): return bool(value)
    if pd.isna(value): return None
    return value


def build_btc_4h_dataset(candles, *, timestamp='t', horizon_bars=6, threshold=0.002,
                         round_trip_cost=0.001, embargo_bars=0, n_splits=5,
                         min_train_size=None, validation_size=None,
                         feature_columns=None, require_integrity=True, lineage_manifest=None):
    """Build X/y/metadata with strict allowlisting and a reproducible manifest.

    All positions in metadata and folds refer to the original candle rows.
    """
    raw = pd.DataFrame(candles).copy().reset_index(drop=True)
    if timestamp not in raw.columns:
        raise ValueError('dataset_timestamp_column_missing')
    source_ts = pd.to_numeric(raw[timestamp], errors='coerce').to_numpy(dtype=float)
    if not np.isfinite(source_ts).all():
        raise ValueError('dataset_timestamp_invalid')
    if pd.Series(source_ts).duplicated().any():
        raise ValueError('dataset_sample_timestamp_duplicate')
    if len(source_ts) > 1 and (np.diff(source_ts) <= 0).any():
        raise ValueError('dataset_sample_timestamp_order_invalid')
    integrity = validate_btc_4h(raw, timestamp=timestamp, max_gap_bars=0)
    if require_integrity and integrity['status'] == 'BLOCKED':
        raise ValueError('BTC 4h integrity blocked: ' + ';'.join(integrity['reasons']))
    requested = tuple(feature_columns or FEATURE_COLUMNS)
    if not requested or len(set(requested)) != len(requested):
        raise ValueError('feature_columns must be non-empty and unique')
    unsafe = [c for c in requested if any(token in c.lower() for token in FORBIDDEN_TOKENS)]
    unknown = [c for c in requested if c not in FEATURE_COLUMNS]
    if unsafe or unknown:
        raise ValueError(f'unsafe or unknown feature columns: {unsafe + unknown}')

    featured = build_btc_4h_features(raw, timestamp=timestamp)
    labelled = build_direction_labels(featured, horizon_bars=horizon_bars,
        threshold=threshold, round_trip_cost=round_trip_cost, timestamp=timestamp,
        drop_unlabelled=False)
    X_all = labelled.loc[:, list(requested)].replace([np.inf, -np.inf], np.nan)
    feature_ok = X_all.notna().all(axis=1).to_numpy()
    label_ok = labelled['label_valid'].to_numpy(dtype=bool) & labelled['label'].notna().to_numpy()
    eligible = feature_ok & label_ok
    sample_pos = np.flatnonzero(eligible)
    if len(sample_pos) < 30:
        raise ValueError(f'insufficient eligible samples after warmup/label horizon: {len(sample_pos)}')
    X = X_all.iloc[sample_pos].astype(float).reset_index(drop=True)
    y = labelled.iloc[sample_pos]['label'].astype('int8').reset_index(drop=True)
    # Stable row identity binds each eligible sample to its UTC candle timestamp and
    # the complete source candle row; it is independent of the eligible-sample ordinal.
    timestamp_identities = []
    row_identities = []
    sample_ids = []
    for original_pos in sample_pos:
        source_row = raw.iloc[int(original_pos)].to_dict()
        timestamp_utc = _timestamp_identity(source_row[timestamp])
        row_payload = {'timestamp_utc': timestamp_utc,
                       'source_row': {str(k): _jsonable(v) for k, v in source_row.items()}}
        row_blob = json.dumps(row_payload, sort_keys=True, separators=(',', ':'),
                              ensure_ascii=False, allow_nan=False, default=str)
        row_hash = hashlib.sha256(row_blob.encode('utf-8')).hexdigest()
        row_id = 'btc4h-row-' + row_hash
        timestamp_identities.append(timestamp_utc)
        row_identities.append(row_hash)
        sample_ids.append(row_id)
    metadata = pd.DataFrame({
        'sample_pos': sample_pos,
        'timestamp': labelled.iloc[sample_pos][timestamp].to_numpy(),
        'timestamp_utc': timestamp_identities,
        'row_identity_sha256': row_identities,
        'sample_id': sample_ids,
        'label_end_pos': labelled.iloc[sample_pos]['label_end_pos'].astype(int).to_numpy(),
        'label_end_t': labelled.iloc[sample_pos]['label_end_t'].to_numpy(),
        'forward_return': labelled.iloc[sample_pos]['forward_return'].to_numpy(dtype=float),
    })
    # Never silently sort or repair input. OOF sample identity is only meaningful
    # when the source candles and eligible samples preserve strict chronological order.
    if len(set(timestamp_identities)) != len(timestamp_identities):
        raise ValueError('dataset_sample_timestamp_duplicate')
    if timestamp_identities != sorted(timestamp_identities):
        raise ValueError('dataset_sample_timestamp_order_invalid')
    if len(set(sample_ids)) != len(sample_ids):
        raise ValueError('dataset_sample_identity_duplicate')
    if any(len(value) != 64 for value in row_identities):
        raise ValueError('dataset_row_identity_hash_invalid')

    # Expanding folds are formed in eligible-sample order; purging compares original candle positions.
    k = int(n_splits); e = int(embargo_bars)
    if k < 1 or e < 0: raise ValueError('n_splits must be >=1 and embargo_bars >=0')
    val_size = int(validation_size or max(1, len(sample_pos)//(k+2)))
    start0 = int(min_train_size or (len(sample_pos)-k*val_size))
    if start0 < 10 or start0 + k*val_size > len(sample_pos):
        raise ValueError('fold sizes do not fit eligible dataset')
    folds=[]
    ends = metadata['label_end_pos'].to_numpy(dtype=int)
    for i in range(k):
        vs = start0 + i*val_size; ve = min(len(sample_pos), vs+val_size)
        validation_start_original = int(sample_pos[vs])
        raw_train = np.arange(vs, dtype=int)
        purged = purge_training_indices(raw_train, ends, validation_start=validation_start_original,
                                        embargo_bars=e)
        if len(purged['train_indices']) < 2:
            raise ValueError('purge/embargo leaves insufficient training samples')
        folds.append({'fold': i+1, 'train_sample_indices': purged['train_indices'],
            'validation_sample_indices': list(range(vs,ve)),
            'train_original_positions': sample_pos[purged['train_indices']].tolist(),
            'validation_original_positions': sample_pos[vs:ve].tolist(),
            'purged_sample_indices': purged['purged_indices'],
            'purged_count': purged['purged_count'],
            'validation_start_original_pos': validation_start_original,
            'max_train_label_end_original_pos': purged['max_kept_label_end_pos']})

    config = {'timestamp_column':timestamp, 'horizon_bars':int(horizon_bars),
        'threshold':float(threshold), 'round_trip_cost':float(round_trip_cost),
        'embargo_bars':e, 'feature_columns':list(requested), 'n_splits':k,
        'min_train_size':start0, 'validation_size':val_size}
    digest_frame = raw.reindex(sorted(raw.columns), axis=1).to_json(orient='split', date_format='iso', double_precision=15)
    digest_payload = json.dumps({'version':VERSION,'config':config,'raw_sha256':hashlib.sha256(digest_frame.encode()).hexdigest()},
                                sort_keys=True, separators=(',',':'))
    manifest = {'version':VERSION, 'config':config,
        'input_rows':len(raw), 'eligible_rows':len(X),
        'warmup_or_invalid_feature_rows':int((~feature_ok).sum()),
        'unlabelled_tail_rows':int((~label_ok).sum()),
        'class_counts':{str(int(k)):int(v) for k,v in y.value_counts().sort_index().items()},
        'integrity_status':integrity['status'], 'integrity_warnings':integrity.get('warnings',[]),
        'feature_schema_hash':hashlib.sha256(json.dumps(list(requested)).encode()).hexdigest(),
        'dataset_hash':hashlib.sha256(digest_payload.encode()).hexdigest(),
        'label_columns_excluded_from_X':['label','label_end_pos','label_end_t','forward_return','label_valid'],
        'sample_identity_sha256': hashlib.sha256(json.dumps(
            [{'sample_id': a, 'timestamp_utc': b, 'row_identity_sha256': c}
             for a, b, c in zip(sample_ids, timestamp_identities, row_identities)],
            sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')).hexdigest()}
    if lineage_manifest is not None:
        from backend.btc_training_lineage import require_training_lineage
        require_training_lineage(lineage_manifest)
        if lineage_manifest.get('dataset', {}).get('dataset_hash') != manifest['dataset_hash']:
            raise ValueError('dataset_lineage_hash_mismatch')
        manifest['lineage'] = lineage_manifest
        manifest['lineage_sha256'] = lineage_manifest['lineage_sha256']
    return {'X':X, 'y':y, 'metadata':metadata, 'folds':folds, 'manifest':manifest}



def rebuild_btc_4h_dataset_from_snapshot(store_root, *, snapshot=None, **dataset_kwargs):
    """Rebuild a dataset offline from a verified immutable ingestion snapshot.

    Returns the normal dataset contract plus snapshot replay provenance. No network
    access, sorting, gap filling, or candle repair is performed.
    """
    from backend.btc_ingestion_store import replay_snapshot
    replay = replay_snapshot(store_root, snapshot=snapshot)
    dataset = build_btc_4h_dataset(replay['candles'], timestamp='t', **dataset_kwargs)
    identity_rows = dataset['metadata'][['sample_id', 'timestamp_utc', 'row_identity_sha256']].to_dict('records')
    identity_digest = hashlib.sha256(json.dumps(identity_rows, sort_keys=True,
        separators=(',', ':'), ensure_ascii=False).encode('utf-8')).hexdigest()
    if identity_digest != dataset['manifest'].get('sample_identity_sha256'):
        raise ValueError('snapshot_rebuild_sample_identity_mismatch')
    dataset['manifest']['snapshot_replay'] = {
        'snapshot': replay['snapshot'], 'snapshot_data_sha256': replay['data_sha256'],
        'row_count': replay['row_count'], 'network_used': False,
        'sample_identity_sha256': identity_digest}
    return dataset
