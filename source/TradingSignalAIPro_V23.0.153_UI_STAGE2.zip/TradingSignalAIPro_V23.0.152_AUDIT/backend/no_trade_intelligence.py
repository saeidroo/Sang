"""Conservative, read-only no-trade diagnostics for paper trading."""
from __future__ import annotations
import math


def build_no_trade_report(*, symbol, market='perp', timeframe='1h',
                          data_age_seconds=None, spread_pct=None, atr_pct=None,
                          volume_ratio=None, volatility_zscore=None,
                          signal_count=0, required_signal_count=2,
                          evidence_conflict=False, market_regime='UNKNOWN',
                          data_valid=True):
    symbol = str(symbol or '').upper().replace('/', '').strip()
    market = str(market or 'perp').lower().strip()
    timeframe = str(timeframe or '1h').lower().strip()
    if not symbol or not symbol.endswith('USDT') or market not in {'spot', 'perp'} or not timeframe:
        raise ValueError('symbol معتبر، market=spot|perp و timeframe لازم است')
    if not isinstance(data_valid, bool) or not isinstance(evidence_conflict, bool):
        raise ValueError('data_valid و evidence_conflict باید boolean باشند')
    def number(name, value, minimum=0):
        if value is None: return None
        try: value=float(value)
        except (TypeError, ValueError): raise ValueError(f'{name} باید عددی باشد')
        if not math.isfinite(value) or value < minimum: raise ValueError(f'{name} نامعتبر است')
        return value
    age=number('data_age_seconds', data_age_seconds)
    spread=number('spread_pct', spread_pct)
    atr=number('atr_pct', atr_pct)
    volume=number('volume_ratio', volume_ratio)
    vz=number('volatility_zscore', volatility_zscore)
    try: signals=int(signal_count); required=int(required_signal_count)
    except (TypeError, ValueError): raise ValueError('تعداد شواهد باید عدد صحیح باشد')
    if signals < 0 or not 1 <= required <= 20 or signals > 100:
        raise ValueError('تعداد شواهد خارج از محدوده است')
    reasons=[]; warnings=[]
    if not data_valid: reasons.append('INVALID_MARKET_DATA')
    if age is None: warnings.append('DATA_FRESHNESS_NOT_PROVIDED')
    elif age > 30: reasons.append('STALE_MARKET_DATA')
    if spread is None: warnings.append('SPREAD_NOT_PROVIDED')
    elif spread > 0.15: reasons.append('WIDE_SPREAD')
    if atr is None: warnings.append('VOLATILITY_NOT_PROVIDED')
    elif atr > 8: reasons.append('EXTREME_ATR_VOLATILITY')
    if vz is not None and vz >= 3: reasons.append('VOLATILITY_SPIKE')
    if volume is not None and volume < 0.25: reasons.append('ABNORMALLY_LOW_VOLUME')
    if evidence_conflict: reasons.append('CONFLICTING_SIGNAL_EVIDENCE')
    if signals < required: reasons.append('INSUFFICIENT_SIGNAL_CONFLUENCE')
    regime=str(market_regime or 'UNKNOWN').upper().strip()
    if regime in {'UNKNOWN','TRANSITION','UNDEFINED'}: warnings.append('MARKET_REGIME_UNCERTAIN')
    state='NO_TRADE' if reasons else ('CAUTION' if warnings else 'NO_BLOCKING_RISK_DETECTED')
    return {
      'symbol':symbol,'market':market,'timeframe':timeframe,'market_regime':regime,
      'decision_state':state,'should_stand_aside':bool(reasons),
      'block_reasons':reasons,'warnings':warnings,
      'observations':{'data_age_seconds':age,'spread_pct':spread,'atr_pct':atr,
        'volume_ratio':volume,'volatility_zscore':vz,'signal_count':signals,
        'required_signal_count':required,'evidence_conflict':evidence_conflict,'data_valid':data_valid},
      'policy':'A clear report is not a trade recommendation; missing inputs remain warnings, not proof of safety.',
      'read_only':True,'paper_only':True,'authorizes_entries':False,'real_orders_enabled':False
    }
