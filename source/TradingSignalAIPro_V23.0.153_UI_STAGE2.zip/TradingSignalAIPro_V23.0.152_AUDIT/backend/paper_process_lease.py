"""SQLite-backed singleton lease for the PAPER AutoPilot process.

The lease is coordination metadata only. It never places or authorizes exchange
orders. Expired leases are reclaimable after a process crash.
"""
from __future__ import annotations

import os
import socket
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Callable

LEASE_NAME = "paper_autopilot"
DEFAULT_TTL_SECONDS = 60


def _connect(db_path):
    conn = sqlite3.connect(str(db_path), timeout=30.0, isolation_level=None)
    conn.execute("PRAGMA busy_timeout=30000")
    conn.execute("PRAGMA synchronous=FULL")
    return conn


def _init(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS paper_process_leases (
        lease_name TEXT PRIMARY KEY,
        owner_token TEXT NOT NULL,
        owner_pid INTEGER NOT NULL,
        owner_host TEXT NOT NULL,
        acquired_at REAL NOT NULL,
        heartbeat_at REAL NOT NULL,
        expires_at REAL NOT NULL
    )""")


def claim_lease(db_path, *, owner_token=None, ttl_seconds=DEFAULT_TTL_SECONDS,
                now: Callable[[], float] = time.time):
    """Atomically claim an absent/expired lease; never steal a live lease."""
    ttl = float(ttl_seconds)
    if ttl < 5:
        raise ValueError("lease_ttl_must_be_at_least_5_seconds")
    token = str(owner_token or uuid.uuid4().hex)
    ts = float(now())
    conn = _connect(db_path)
    try:
        _init(conn)
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT owner_token, expires_at FROM paper_process_leases WHERE lease_name=?",
                           (LEASE_NAME,)).fetchone()
        if row and row[0] != token and float(row[1]) > ts:
            conn.rollback()
            return {"ok": False, "reason": "lease_held", "expires_at": float(row[1])}
        if row and row[0] == token:
            conn.execute("UPDATE paper_process_leases SET heartbeat_at=?, expires_at=?, owner_pid=?, owner_host=? WHERE lease_name=? AND owner_token=?",
                         (ts, ts + ttl, os.getpid(), socket.gethostname(), LEASE_NAME, token))
        else:
            conn.execute("INSERT INTO paper_process_leases(lease_name,owner_token,owner_pid,owner_host,acquired_at,heartbeat_at,expires_at) VALUES(?,?,?,?,?,?,?) "
                         "ON CONFLICT(lease_name) DO UPDATE SET owner_token=excluded.owner_token, owner_pid=excluded.owner_pid, owner_host=excluded.owner_host, acquired_at=excluded.acquired_at, heartbeat_at=excluded.heartbeat_at, expires_at=excluded.expires_at",
                         (LEASE_NAME, token, os.getpid(), socket.gethostname(), ts, ts, ts + ttl))
        conn.commit()
        return {"ok": True, "owner_token": token, "expires_at": ts + ttl, "ttl_seconds": ttl}
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def renew_lease(db_path, owner_token, *, ttl_seconds=DEFAULT_TTL_SECONDS,
                now: Callable[[], float] = time.time):
    ts = float(now())
    conn = _connect(db_path)
    try:
        _init(conn)
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute("UPDATE paper_process_leases SET heartbeat_at=?, expires_at=? "
                           "WHERE lease_name=? AND owner_token=? AND expires_at>?",
                           (ts, ts + float(ttl_seconds), LEASE_NAME, str(owner_token), ts))
        conn.commit()
        return {"ok": cur.rowcount == 1, "expires_at": ts + float(ttl_seconds) if cur.rowcount else None}
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def release_lease(db_path, owner_token):
    conn = _connect(db_path)
    try:
        _init(conn)
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute("DELETE FROM paper_process_leases WHERE lease_name=? AND owner_token=?",
                           (LEASE_NAME, str(owner_token)))
        conn.commit()
        return {"ok": cur.rowcount == 1}
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def lease_status(db_path, *, now: Callable[[], float] = time.time):
    conn = _connect(db_path)
    try:
        _init(conn)
        row = conn.execute("SELECT owner_pid,owner_host,heartbeat_at,expires_at FROM paper_process_leases WHERE lease_name=?",
                           (LEASE_NAME,)).fetchone()
        if not row:
            return {"held": False}
        return {"held": float(row[3]) > float(now()), "owner_pid": int(row[0]),
                "owner_host": str(row[1]), "heartbeat_at": float(row[2]), "expires_at": float(row[3])}
    finally:
        conn.close()
