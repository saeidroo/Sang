"""V23.0.70 read-only orchestration and learning-eligibility audit for PAPER trades."""
from __future__ import annotations
from backend.dynamic_position_manager import evaluate_open_paper_positions
from backend.exit_intelligence import evaluate_exit_intelligence


def evaluate_trade_lifecycle(positions, closed_trades=None, settings=None):
    """Unify management/exit advice and audit closed-trade learning eligibility.

    This is deliberately a preview: it never mutates positions, writes learning
    rows, or creates orders. The durable paper ledger remains the sole authority.
    """
    if not isinstance(positions, list):
        raise ValueError('positions باید فهرست باشد')
    if closed_trades is None:
        closed_trades = []
    if not isinstance(closed_trades, list):
        raise ValueError('closed_trades باید فهرست باشد')
    cfg = settings or {}
    if not isinstance(cfg, dict):
        raise ValueError('settings نامعتبر است')
    management = evaluate_open_paper_positions(positions, cfg.get('management', {}))
    exits = evaluate_exit_intelligence(positions, cfg.get('exit', {}))
    exit_by_id = {x['position_id']: x for x in exits['positions'] if x.get('position_id')}
    lifecycle = []
    for item in management['positions']:
        decision = exit_by_id.get(item['position_id'], {})
        if decision.get('decision') == 'EXIT_REVIEW_REQUIRED':
            state = 'EXIT_REVIEW_REQUIRED'
            next_step = 'بررسی خروج در موتور اجرای آزمایشی؛ این خروجی سفارش نیست.'
        elif decision.get('decision') == 'HOLD_NO_ACTION':
            state = 'HOLD_STALE_DATA'
            next_step = 'تا دریافت قیمت تازه هیچ تصمیم اجرایی نگیرید.'
        else:
            state = 'MANAGE_OR_HOLD'
            next_step = 'پیشنهاد مدیریت موقعیت را بررسی کنید.'
        lifecycle.append({'position_id': item['position_id'], 'symbol': item['symbol'],
            'lifecycle_state': state, 'management': item,
            'exit_assessment': decision, 'next_step': next_step})
    closed_audit = []
    seen = set()
    for i, trade in enumerate(closed_trades):
        if not isinstance(trade, dict):
            closed_audit.append({'index': i, 'eligible': False, 'reason': 'INVALID_RECORD'}); continue
        tid = str(trade.get('trade_id') or '').strip()
        reason = None
        if not tid or tid in seen: reason = 'MISSING_OR_DUPLICATE_TRADE_ID'
        elif str(trade.get('status', '')).upper() != 'CLOSED': reason = 'TRADE_NOT_CLOSED'
        elif trade.get('paper_only') is not True: reason = 'NOT_CONFIRMED_PAPER'
        elif trade.get('reconciled') is not True: reason = 'NOT_RECONCILED'
        elif trade.get('funding_status', 'NOT_APPLICABLE') not in ('SYNCED', 'NOT_APPLICABLE'): reason = 'FUNDING_NOT_RECONCILED'
        elif trade.get('net_pnl') is None: reason = 'NET_PNL_MISSING'
        else:
            try:
                import math
                if not math.isfinite(float(trade['net_pnl'])): reason = 'NET_PNL_INVALID'
            except (TypeError, ValueError, OverflowError): reason = 'NET_PNL_INVALID'
        if tid: seen.add(tid)
        closed_audit.append({'trade_id': tid or None, 'eligible': reason is None,
            'reason': 'READY_FOR_LEDGER_LEARNING_PIPELINE' if reason is None else reason,
            'writes_learning_data': False})
    return {'version': '23.0.70', 'lifecycle': lifecycle,
        'closed_trade_learning_audit': closed_audit,
        'summary': {'open_positions_received': len(positions),
            'positions_with_lifecycle_result': len(lifecycle),
            'exit_reviews_required': sum(x['lifecycle_state']=='EXIT_REVIEW_REQUIRED' for x in lifecycle),
            'closed_trades_received': len(closed_audit),
            'learning_eligible_candidates': sum(x['eligible'] for x in closed_audit)},
        'read_only': True, 'paper_only': True, 'recommendations_only': True,
        'writes_learning_data': False, 'creates_orders': False,
        'execution_authorized': False, 'real_orders_enabled': False,
        'capital_usdt': 1000.0}
