"""Small read-only cross-market snapshot (Yahoo Finance with CoinGecko fallback)."""
from __future__ import annotations
import time
import os
import requests

_ITEMS = {
    'BTC': {'label': 'بیت‌کوین', 'yahoo': 'BTC-USD', 'coingecko': 'bitcoin', 'kind': 'crypto'},
    'ETH': {'label': 'اتریوم', 'yahoo': 'ETH-USD', 'coingecko': 'ethereum', 'kind': 'crypto'},
    'GOLD': {'label': 'طلا', 'yahoo': 'GC=F', 'kind': 'commodity'},
    'OIL': {'label': 'نفت WTI', 'yahoo': 'CL=F', 'kind': 'commodity'},
}
_CACHE = {'at': 0.0, 'data': None}
_TTL = 60


def _yahoo(symbol: str) -> dict:
    url = f'https://query1.finance.yahoo.com/v8/finance/chart/{symbol}'
    r = requests.get(url, params={'range': '5d', 'interval': '1d'},
                     headers={'User-Agent': 'Mozilla/5.0'}, timeout=(4, 8))
    r.raise_for_status()
    result = (r.json().get('chart', {}).get('result') or [None])[0]
    if not result:
        raise RuntimeError('Yahoo Finance داده‌ای برنگرداند')
    meta = result.get('meta') or {}
    price = meta.get('regularMarketPrice')
    previous = meta.get('chartPreviousClose') or meta.get('previousClose')
    if price is None or not previous:
        closes = ((result.get('indicators') or {}).get('quote') or [{}])[0].get('close') or []
        closes = [float(x) for x in closes if x is not None]
        if len(closes) >= 2:
            price, previous = closes[-1], closes[-2]
    if price is None or not previous:
        raise RuntimeError('قیمت یا قیمت مبنا در پاسخ موجود نیست')
    price, previous = float(price), float(previous)
    return {'price': price, 'change_pct': (price / previous - 1) * 100,
            'source': 'Yahoo Finance', 'currency': meta.get('currency') or 'USD',
            'as_of': meta.get('regularMarketTime')}




def _twelvedata(symbol: str) -> dict:
    """Optional independent fallback; requires TWELVEDATA_API_KEY."""
    key = os.getenv('TWELVEDATA_API_KEY', '').strip()
    if not key:
        raise RuntimeError('TWELVEDATA_API_KEY تنظیم نشده است')
    r = requests.get('https://api.twelvedata.com/quote',
                     params={'symbol': symbol, 'apikey': key}, timeout=(4, 8))
    r.raise_for_status()
    row = r.json()
    if row.get('status') == 'error' or not row.get('close'):
        raise RuntimeError(str(row.get('message') or 'Twelve Data داده‌ای برنگرداند')[:120])
    price = float(row['close'])
    previous = float(row.get('previous_close') or row.get('open') or 0)
    if price <= 0 or previous <= 0:
        raise RuntimeError('قیمت یا قیمت مبنای Twelve Data نامعتبر است')
    return {'price': price, 'change_pct': (price / previous - 1) * 100,
            'source': 'Twelve Data', 'currency': row.get('currency') or 'USD',
            'as_of': int(time.time())}


def _coingecko(coin_id: str) -> dict:
    r = requests.get('https://api.coingecko.com/api/v3/simple/price',
                     params={'ids': coin_id, 'vs_currencies': 'usd', 'include_24hr_change': 'true'},
                     headers={'User-Agent': 'TradingSignalAIPro/23.0'}, timeout=(4, 8))
    r.raise_for_status()
    row = r.json().get(coin_id) or {}
    price, change = row.get('usd'), row.get('usd_24h_change')
    if price is None or change is None:
        raise RuntimeError('CoinGecko داده کامل برنگرداند')
    return {'price': float(price), 'change_pct': float(change),
            'source': 'CoinGecko', 'currency': 'USD', 'as_of': int(time.time())}


def get_market_overview(force: bool = False) -> dict:
    now = time.time()
    if not force and _CACHE['data'] is not None and now - _CACHE['at'] < _TTL:
        return dict(_CACHE['data'], cached=True)
    rows = []
    for key, item in _ITEMS.items():
        data, errors = None, []
        try:
            data = _yahoo(item['yahoo'])
        except Exception as exc:
            errors.append(f"Yahoo Finance: {str(exc)[:120]}")
        if data is None and item['kind'] == 'crypto':
            try:
                data = _coingecko(item['coingecko'])
            except Exception as exc:
                errors.append(f"CoinGecko: {str(exc)[:120]}")
        elif data is None and item['kind'] == 'commodity':
            # Yahoo futures are the first source; Twelve Data is an independent
            # fallback for spot gold and WTI when an API key is configured.
            td_symbol = {'GOLD': 'XAU/USD', 'OIL': 'WTI'}[key]
            try:
                data = _twelvedata(td_symbol)
            except Exception as exc:
                errors.append(f"Twelve Data: {str(exc)[:120]}")
        row = {'id': key, 'label': item['label'], 'status': 'ok' if data else 'unavailable'}
        if data:
            row.update(data)
        else:
            row['error'] = ' | '.join(errors)
        rows.append(row)
    payload = {'items': rows, 'updated_at': int(now), 'cached': False,
               'note': 'نمای کلی فقط‌خواندنی؛ قیمت‌ها با تأخیر احتمالی و صرفاً برای اطلاع هستند.'}
    _CACHE.update(at=now, data=payload)
    return payload
