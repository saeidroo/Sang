"""V19 — Causal divergence detection (RSI / MACD momentum vs price).

A divergence is bullish when price prints a LOWER low while the momentum
oscillator prints a HIGHER low (sellers exhausted), and bearish when price
prints a HIGHER high while the oscillator prints a LOWER high (buyers
exhausted). It is one of the few technical conditions that meaningfully
precedes trend exhaustion, so V19 promotes it to:

1. a first-class brain component (the ``divergence`` vote in brain.py), and
2. causal numeric features for the ML ensemble (features.py).

Causality contract (checked by tests):
- Only bars at or before the evaluation bar are ever read.
- Output is bounded: strength values are floats in [0, 1] and votes are in [-1, 1].
- Weak or ambiguous geometry returns strength 0 instead of guessing.

Noise robustness: instead of comparing the last two raw pivots (small wiggles
would dominate), the scanner picks the most significant confirmed pivot of the
recent window and the most significant confirmed pivot before it, and requires
a genuine counter-move (bounce/pullback) between the two extremes.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

# Lookback windows for pivots and divergence scanning (all causal).
PIVOT_SPAN = 3          # bars on each side that confirm a local pivot
RECENT_SPAN = 40        # the "current" extreme must live in the last N bars
MAX_BARS_BETWEEN = 60   # two extremes too far apart are unrelated
MIN_BARS_BETWEEN = 5    # ... and too close together are one move
BOUNCE_FRACTION = 0.003 # a real counter-move of >= 0.3% must separate them

_EPS = 1e-12


def _finite(value) -> float | None:
    try:
        x = float(value)
        return x if np.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def _pivot_lows(series: np.ndarray) -> list[int]:
    """Indices of confirmed local lows (lowest within PIVOT_SPAN on each side)."""
    out = []
    n = len(series)
    for i in range(PIVOT_SPAN, n - PIVOT_SPAN):
        seg = series[i - PIVOT_SPAN:i + PIVOT_SPAN + 1]
        if not np.isfinite(seg).all():
            continue
        if series[i] == seg.min() and (seg[:PIVOT_SPAN] > series[i]).all():
            out.append(i)
    merged: list[int] = []
    for idx in out:
        if merged and idx - merged[-1] < MIN_BARS_BETWEEN:
            if series[idx] < series[merged[-1]]:
                merged[-1] = idx
            continue
        merged.append(idx)
    return merged


def _pivot_highs(series: np.ndarray) -> list[int]:
    out = []
    n = len(series)
    for i in range(PIVOT_SPAN, n - PIVOT_SPAN):
        seg = series[i - PIVOT_SPAN:i + PIVOT_SPAN + 1]
        if not np.isfinite(seg).all():
            continue
        if series[i] == seg.max() and (seg[:PIVOT_SPAN] < series[i]).all():
            out.append(i)
    merged: list[int] = []
    for idx in out:
        if merged and idx - merged[-1] < MIN_BARS_BETWEEN:
            if series[idx] > series[merged[-1]]:
                merged[-1] = idx
            continue
        merged.append(idx)
    return merged


def _scan_side(price_v: np.ndarray, opp_v: np.ndarray, osc: np.ndarray,
               pivots: list[int], side: str) -> tuple[float, str]:
    """Scan one side of the divergence geometry.

    side='low'  -> bullish scan: current significant LOW vs previous
                   significant LOW (price lower low + oscillator higher low)
    side='high' -> bearish scan: current significant HIGH vs previous
                   significant HIGH (price higher high + oscillator lower high)

    ``price_v`` is the extreme series used for pivot geometry (lows or highs),
    ``opp_v`` is the opposite wick series used for the bounce filter.
    Returns (strength, kind); strength in [0, 1], 0 when geometry is weak.
    """
    if len(pivots) < 2 or len(price_v) < PIVOT_SPAN * 2 + MIN_BARS_BETWEEN:
        return 0.0, ''
    n = len(price_v)

    # 1) Current extreme: the most significant confirmed pivot of the recent span.
    recent = [i for i in pivots if i >= n - 1 - RECENT_SPAN]
    if not recent:
        recent = pivots[-1:]
    if side == 'low':
        i2 = min(recent, key=lambda i: price_v[i])
    else:
        i2 = max(recent, key=lambda i: price_v[i])

    # 2) Previous extreme: the most significant pivot before it, within reach.
    window = [i for i in pivots if i2 - MAX_BARS_BETWEEN <= i <= i2 - MIN_BARS_BETWEEN]
    if not window:
        return 0.0, ''
    if side == 'low':
        i1 = min(window, key=lambda i: price_v[i])
    else:
        i1 = max(window, key=lambda i: price_v[i])

    p1, p2 = _finite(price_v[i1]), _finite(price_v[i2])
    o1, o2 = _finite(osc[i1]), _finite(osc[i2])
    if None in (p1, p2, o1, o2):
        return 0.0, ''

    # 3) A genuine counter-move must separate the two extremes.
    between = opp_v[i1:i2 + 1]
    if len(between) == 0 or not np.isfinite(between).all():
        return 0.0, ''
    if side == 'low':
        bounce = float(np.max(between)) / max(p1, _EPS) - 1.0
        if bounce < BOUNCE_FRACTION:
            return 0.0, ''
    else:
        pullback = 1.0 - float(np.min(between)) / max(p1, _EPS)
        if pullback < BOUNCE_FRACTION:
            return 0.0, ''

    price_gap = abs(p2 - p1) / max(abs(p1), _EPS)
    osc_gap = abs(o2 - o1) / max(abs(o1), _EPS)
    if price_gap < 0.0015:
        return 0.0, ''

    # Recency decay: a divergence discovered long ago matters less today.
    age = n - 1 - i2
    recency = max(0.35, 1.0 - age / max(RECENT_SPAN, 1))
    strength_base = min(1.0, (0.45 + 1.8 * min(price_gap, 0.25)
                              + 1.2 * min(osc_gap, 0.35)) * recency)

    if side == 'low' and p2 < p1 and o2 > o1:
        return float(min(1.0, strength_base)), 'bull'
    if side == 'high' and p2 > p1 and o2 < o1:
        return float(min(1.0, strength_base)), 'bear'
    return 0.0, ''


def _osc_frame(ind: pd.DataFrame) -> pd.DataFrame | None:
    required = {'close', 'low', 'high', 'rsi_14', 'macd_hist'}
    if not isinstance(ind, pd.DataFrame) or not required.issubset(ind.columns):
        return None
    if len(ind) < PIVOT_SPAN * 2 + MIN_BARS_BETWEEN:
        return None
    frame = pd.DataFrame({
        'close': pd.to_numeric(ind['close'], errors='coerce'),
        'low': pd.to_numeric(ind['low'], errors='coerce'),
        'high': pd.to_numeric(ind['high'], errors='coerce'),
        'rsi': pd.to_numeric(ind['rsi_14'], errors='coerce'),
        'macd': pd.to_numeric(ind['macd_hist'], errors='coerce'),
    })
    frame = frame.replace([np.inf, -np.inf], np.nan).dropna()
    if len(frame) < PIVOT_SPAN * 2 + MIN_BARS_BETWEEN:
        return None
    return frame


def detect_divergences(ind: pd.DataFrame) -> dict:
    """Detect the most recent RSI and MACD-histogram divergences.

    ``ind`` must contain close, low, high, rsi_14 and macd_hist columns
    (the output of all_indicators). The LAST row is treated as "now";
    only data up to that row is used.

    Returns:
    {
      'available': bool,
      'rsi':  {'strength': float, 'kind': 'bull'|'bear'|''},
      'macd': {'strength': float, 'kind': 'bull'|'bear'|''},
      'combined': {'strength': float, 'kind': str, 'votes': int},
    }
    ``combined`` aggregates the two detectors: when both agree the strength
    is boosted (bounded), when they disagree the signal neutralizes.
    """
    empty = {'available': False,
             'rsi': {'strength': 0.0, 'kind': ''},
             'macd': {'strength': 0.0, 'kind': ''},
             'combined': {'strength': 0.0, 'kind': '', 'votes': 0}}
    frame = _osc_frame(ind)
    if frame is None:
        return empty

    lo = frame['low'].to_numpy(dtype=float)
    hi = frame['high'].to_numpy(dtype=float)
    rsi_v = frame['rsi'].to_numpy(dtype=float)
    macd_v = frame['macd'].to_numpy(dtype=float)

    scans = {
        'rsi': max(
            _scan_side(lo, hi, rsi_v, _pivot_lows(lo), 'low'),
            _scan_side(hi, lo, rsi_v, _pivot_highs(hi), 'high'),
            key=lambda x: x[0]),
        'macd': max(
            _scan_side(lo, hi, macd_v, _pivot_lows(lo), 'low'),
            _scan_side(hi, lo, macd_v, _pivot_highs(hi), 'high'),
            key=lambda x: x[0]),
    }

    kinds = [k for _, k in scans.values() if k]
    bull = sum(1 for k in kinds if k == 'bull')
    bear = sum(1 for k in kinds if k == 'bear')
    combined_strength = 0.0
    combined_kind = ''
    votes = 0
    if bull and not bear:
        votes = bull
        combined_kind = 'bull'
    elif bear and not bull:
        votes = bear
        combined_kind = 'bear'
    if votes:
        strengths = [s for s, k in scans.values() if k]
        combined_strength = sum(strengths) / len(strengths)
        if votes == 2:
            combined_strength = min(1.0, combined_strength * 1.25)

    available = bool(kinds)
    return {
        'available': available,
        'rsi': {'strength': round(float(scans['rsi'][0]), 4),
                'kind': scans['rsi'][1]},
        'macd': {'strength': round(float(scans['macd'][0]), 4),
                 'kind': scans['macd'][1]},
        'combined': {'strength': round(float(combined_strength), 4),
                     'kind': combined_kind, 'votes': int(votes)},
    }


def divergence_vote(ind: pd.DataFrame) -> tuple[float, dict]:
    """Central-brain vote (component ``divergence``).

    Score in [-1, 1]: positive for bullish divergence, negative for bearish.
    Only divergences with strength >= 0.20 cast a directional vote; weaker
    geometry stays out of the consensus instead of injecting noise.
    """
    det = detect_divergences(ind)
    if not det['available'] or det['combined']['votes'] == 0:
        return 0.0, {'available': False,
                     'reason': 'واگرایی جهت‌دار معتبری در پنجره‌ی بررسی نیست'}
    strength = det['combined']['strength']
    kind = det['combined']['kind']
    if strength < 0.20:
        return 0.0, {'available': False,
                     'reason': 'واگرایی پیدا شد اما قدرت آن زیر آستانه است',
                     'raw': det}
    sign = 1.0 if kind == 'bull' else -1.0
    score = sign * min(1.0, 0.30 + 0.70 * strength)
    return float(score), {'available': True, 'kind': kind,
                          'strength': strength,
                          'detectors': {'rsi': det['rsi'], 'macd': det['macd']}}


# ---------------------------------------------------------------------------
# Vectorized per-bar divergence FEATURES (for the ML ensemble).
# The exact per-frame detector above is O(window) per call; computing it at
# every historical bar would be quadratic. The feature builder below uses the
# same geometry (recent significant extreme vs previous significant extreme)
# evaluated with rolling argmin/argmax windows — causal, bounded, fast.
# ---------------------------------------------------------------------------
_FEATURE_W_RECENT = 40   # recent extreme window (matches RECENT_SPAN)
_GAP = 5                 # minimum separation between the two extremes


def _rolling_extreme_index(arr: np.ndarray, window: int, mode: str) -> tuple[np.ndarray, np.ndarray]:
    """For every window ending at bar i, return (index of extreme, extreme value).

    Only windows fully inside history are produced; the first `window-1` bars
    get index -1 / value NaN.
    """
    from numpy.lib.stride_tricks import sliding_window_view
    n = len(arr)
    idx = np.full(n, -1, dtype=np.int64)
    val = np.full(n, np.nan)
    if n < window:
        return idx, val
    win = sliding_window_view(arr, window)          # row i -> arr[i : i+window]
    if mode == 'min':
        off = win.argmin(axis=1)
        v = win.min(axis=1)
    else:
        off = win.argmax(axis=1)
        v = win.max(axis=1)
    start = window - 1
    idx[start:] = off + np.arange(len(win))
    val[start:] = v
    return idx, val


def divergence_feature_series(ind: pd.DataFrame) -> pd.DataFrame:
    """Per-bar divergence features aligned to ``ind`` (same length/order).

    Columns (all bounded in [0, 1]):
      div_rsi_bull / div_rsi_bear / div_macd_bull / div_macd_bear — per-detector
      strength when the divergence geometry holds at that bar, else 0.
    The last bar of this frame matches (approximately) what the exact
    per-frame detector sees, so train/inference semantics stay close.
    """
    names = ['div_rsi_bull', 'div_rsi_bear', 'div_macd_bull', 'div_macd_bear']
    frame = _osc_frame(ind)
    if frame is None:
        return pd.DataFrame({name: [0.0] * len(ind) for name in names}, index=ind.index)

    n = len(frame)
    low = frame['low'].to_numpy(dtype=float)
    high = frame['high'].to_numpy(dtype=float)
    out = pd.DataFrame(0.0, index=frame.index, columns=names)

    WR = _FEATURE_W_RECENT
    off = WR - 1 + _GAP   # previous window ends exactly _GAP bars before the recent one
    # Recent extreme per bar: argmin/argmax over [i-WR+1, i].
    j2_lo, low2 = _rolling_extreme_index(low, WR, 'min')
    j2_hi, high2 = _rolling_extreme_index(high, WR, 'max')
    # Previous extreme per bar: the SAME rolling window evaluated `off` bars
    # earlier, i.e. argmin over [i-WR+1-off, i-off].
    jW_lo, vW_lo = _rolling_extreme_index(low, WR, 'min')
    jW_hi, vW_hi = _rolling_extreme_index(high, WR, 'max')
    j1_lo = np.full(n, -1, dtype=np.int64)
    j1_hi = np.full(n, -1, dtype=np.int64)
    low1 = np.full(n, np.nan)
    high1 = np.full(n, np.nan)
    if n > off:
        j1_lo[off:] = jW_lo[:n - off]
        j1_hi[off:] = jW_hi[:n - off]
        low1[off:] = vW_lo[:n - off]
        high1[off:] = vW_hi[:n - off]

    # Bounce proxy: rolling max/min of the opposite wick over the combined span.
    span = WR + off
    _, high_span = _rolling_extreme_index(high, span, 'max')
    _, low_span = _rolling_extreme_index(low, span, 'min')

    bars = np.arange(n)
    age = bars - j2_lo
    recency = np.clip(1.0 - age / max(_FEATURE_W_RECENT, 1), 0.35, 1.0)

    def _strength(price_gap: np.ndarray, osc_gap: np.ndarray) -> np.ndarray:
        base = (0.45 + 1.8 * np.clip(price_gap, 0.0, 0.25)
                + 1.2 * np.clip(osc_gap, 0.0, 0.35)) * recency
        return np.clip(base, 0.0, 1.0)

    for osc_name, osc_arr in (('rsi', frame['rsi'].to_numpy(dtype=float)),
                              ('macd', frame['macd'].to_numpy(dtype=float))):
        eps = max(float(np.nanstd(osc_arr)), _EPS)
        # Bullish: recent price low BELOW previous low, oscillator higher low.
        valid_b = (j1_lo >= 0) & (j2_lo >= 0)
        gap_p = (low1 - low2) / np.maximum(np.abs(np.nan_to_num(low1, nan=1.0)), _EPS)
        o1 = np.where(j1_lo >= 0, osc_arr[np.clip(j1_lo, 0, n - 1)], np.nan)
        o2 = np.where(j2_lo >= 0, osc_arr[np.clip(j2_lo, 0, n - 1)], np.nan)
        gap_o = (o2 - o1) / eps
        bounce = (high_span / np.maximum(np.abs(np.nan_to_num(low1, nan=1.0)), _EPS) - 1.0) >= BOUNCE_FRACTION
        bull = valid_b & (low2 < low1) & (o2 > o1) & (gap_p > 0.0015) & bounce
        out[f'div_{osc_name}_bull'] = np.where(bull, _strength(gap_p, gap_o), 0.0)
        # Bearish: recent price high ABOVE previous high, oscillator lower high.
        valid_s = (j1_hi >= 0) & (j2_hi >= 0)
        gap_ps = (high2 - high1) / np.maximum(np.abs(np.nan_to_num(high1, nan=1.0)), _EPS)
        o1s = np.where(j1_hi >= 0, osc_arr[np.clip(j1_hi, 0, n - 1)], np.nan)
        o2s = np.where(j2_hi >= 0, osc_arr[np.clip(j2_hi, 0, n - 1)], np.nan)
        gap_os = (o1s - o2s) / eps
        pullback = 1.0 - low_span / np.maximum(np.abs(np.nan_to_num(high1, nan=1.0)), _EPS) >= BOUNCE_FRACTION
        bear = valid_s & (high2 > high1) & (o2s < o1s) & (gap_ps > 0.0015) & pullback
        out[f'div_{osc_name}_bear'] = np.where(bear, _strength(gap_ps, gap_os), 0.0)

    out = out.replace([np.inf, -np.inf], np.nan).fillna(0.0).clip(0.0, 1.0)
    # _osc_frame drops warmup/NaN rows; realign to the caller's index so the
    # feature frame always matches the indicator frame row-for-row.
    out = out.reindex(ind.index).fillna(0.0)
    return out
