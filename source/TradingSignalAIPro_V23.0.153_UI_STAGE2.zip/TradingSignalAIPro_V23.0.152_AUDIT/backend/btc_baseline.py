"""Leakage-aware baseline training and walk-forward OOF evaluation for BTC 4h."""
from __future__ import annotations

import hashlib
import json
from collections import Counter

import numpy as np
import pandas as pd

VERSION = 'btc-4h-baseline-evaluation-v1'
CLASSES = (-1, 0, 1)


def _aligned_probabilities(model, X, classes=CLASSES):
    raw = model.predict_proba(X)
    aligned = np.zeros((len(X), len(classes)), dtype=float)
    model_classes = list(model.classes_)
    for j, cls in enumerate(classes):
        if cls in model_classes:
            aligned[:, j] = raw[:, model_classes.index(cls)]
    sums = aligned.sum(axis=1)
    zero = sums <= 0
    if zero.any():
        aligned[zero] = 1.0 / len(classes)
        sums[zero] = 1.0
    return aligned / sums[:, None]


def _classification_metrics(y_true, y_pred, probabilities):
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    p = np.asarray(probabilities, dtype=float)
    cm = [[int(np.sum((y_true == a) & (y_pred == b))) for b in CLASSES] for a in CLASSES]
    recalls = []
    f1s = []
    for cls in CLASSES:
        tp = int(np.sum((y_true == cls) & (y_pred == cls)))
        fp = int(np.sum((y_true != cls) & (y_pred == cls)))
        fn = int(np.sum((y_true == cls) & (y_pred != cls)))
        support = int(np.sum(y_true == cls))
        recalls.append(tp / support if support else float('nan'))
        denom = 2 * tp + fp + fn
        f1s.append(2 * tp / denom if denom else 0.0)
    class_idx = {c: i for i, c in enumerate(CLASSES)}
    chosen = np.array([class_idx[v] for v in y_true], dtype=int)
    clipped = np.clip(p[np.arange(len(p)), chosen], 1e-12, 1.0)
    onehot = np.eye(len(CLASSES))[chosen]
    return {
        'n': int(len(y_true)),
        'accuracy': float(np.mean(y_true == y_pred)),
        'balanced_accuracy': float(np.nanmean(recalls)),
        'macro_f1': float(np.mean(f1s)),
        'log_loss': float(-np.mean(np.log(clipped))),
        'brier_score': float(np.mean(np.sum((p - onehot) ** 2, axis=1))),
        'confusion_matrix_labels': list(CLASSES),
        'confusion_matrix': cm,
        'class_support': {str(c): int(np.sum(y_true == c)) for c in CLASSES},
    }


def evaluate_btc_4h_baselines(dataset, *, include_logistic=True, random_state=42,
                              require_lineage=True, training_run_dir=None, run_id_prefix='btc4h-baseline', training_registry_dir=None):
    """Train only on each purged fold's train rows and emit OOF validation predictions.

    No final holdout is consumed here. The caller must reserve a chronological final
    holdout before tuning/selection and evaluate it exactly once in a later stage.
    """
    try:
        from sklearn.dummy import DummyClassifier
        from sklearn.linear_model import LogisticRegression
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
    except ImportError as exc:  # pragma: no cover - environment-specific
        raise RuntimeError('scikit-learn is required for BTC baseline evaluation') from exc

    # Provenance is enforced before any model.fit call. Exploratory legacy runs require an explicit require_lineage=False opt-out.
    manifest = dataset.get('manifest', {})
    lineage = manifest.get('lineage')
    if require_lineage and lineage is None:
        raise ValueError('training_lineage_required_for_baseline')
    if lineage is not None:
        from backend.btc_training_lineage import require_training_lineage
        require_training_lineage(lineage)
        if manifest.get('lineage_sha256') != lineage.get('lineage_sha256'):
            raise ValueError('dataset_lineage_digest_mismatch')
        if manifest.get('dataset_hash') != lineage.get('dataset', {}).get('dataset_hash'):
            raise ValueError('training_dataset_hash_mismatch')

    X = pd.DataFrame(dataset['X']).reset_index(drop=True)
    y = pd.Series(dataset['y']).astype(int).reset_index(drop=True)
    folds = dataset.get('folds') or []
    if not folds:
        raise ValueError('dataset contains no walk-forward folds')
    if len(X) != len(y) or X.empty or not np.isfinite(X.to_numpy(dtype=float)).all():
        raise ValueError('X/y mismatch or non-finite feature matrix')

    from backend.btc_oof_coverage import build_oof_coverage_contract
    coverage_contract = build_oof_coverage_contract(dataset)
    predictions = []
    fold_reports = []
    for fold in folds:
        tr = np.asarray(fold['train_sample_indices'], dtype=int)
        va = np.asarray(fold['validation_sample_indices'], dtype=int)
        if len(tr) < 2 or len(va) < 1 or (tr >= len(X)).any() or (va >= len(X)).any():
            raise ValueError('invalid fold indices')
        if set(tr).intersection(va):
            raise ValueError('train/validation overlap')
        train_pos = np.asarray(dataset['metadata'].iloc[tr]['sample_pos'], dtype=int)
        valid_start = int(fold['validation_start_original_pos'])
        train_end = np.asarray(dataset['metadata'].iloc[tr]['label_end_pos'], dtype=int)
        embargo = int(dataset['manifest']['config'].get('embargo_bars', 0))
        if len(train_end) and not np.all(train_end < valid_start - embargo):
            raise ValueError('fold contains unpurged training labels')

        models = {'majority': DummyClassifier(strategy='most_frequent')}
        if include_logistic and len(np.unique(y.iloc[tr])) >= 2:
            models['logistic_regression'] = make_pipeline(
                StandardScaler(), LogisticRegression(max_iter=1000, class_weight='balanced',
                                                       random_state=random_state))
        for name, model in models.items():
            model.fit(X.iloc[tr], y.iloc[tr])
            pred = model.predict(X.iloc[va]).astype(int)
            if hasattr(model, 'predict_proba'):
                probs = _aligned_probabilities(model, X.iloc[va])
            else:  # pragma: no cover - all configured models expose probabilities
                probs = np.full((len(va), 3), 1/3)
            metrics = _classification_metrics(y.iloc[va], pred, probs)
            fold_reports.append({'fold': int(fold['fold']), 'model': name,
                                 'train_n': int(len(tr)), 'validation_n': int(len(va)),
                                 'metrics': metrics})
            for local_i, sample_i in enumerate(va):
                predictions.append({'sample_index': int(sample_i),
                    'sample_pos': int(dataset['metadata'].iloc[sample_i]['sample_pos']),
                    'sample_id': str(dataset['metadata'].iloc[sample_i]['sample_id']),
                    'timestamp_utc': str(dataset['metadata'].iloc[sample_i]['timestamp_utc']),
                    'row_identity_sha256': str(dataset['metadata'].iloc[sample_i]['row_identity_sha256']),
                    'fold': int(fold['fold']), 'model': name,
                    'y_true': int(y.iloc[sample_i]), 'y_pred': int(pred[local_i]),
                    'p_down': float(probs[local_i, 0]), 'p_neutral': float(probs[local_i, 1]),
                    'p_up': float(probs[local_i, 2])})

    oof = pd.DataFrame(predictions)
    aggregate = {}
    for name, group in oof.groupby('model'):
        probs = group[['p_down', 'p_neutral', 'p_up']].to_numpy(float)
        aggregate[name] = _classification_metrics(group.y_true, group.y_pred, probs)
    # Capture seed and runtime dependencies so replay differences can be diagnosed.
    from backend.btc_replay_determinism import build_training_environment, prediction_digest
    training_environment = build_training_environment(random_state=random_state,
        model_config={'include_logistic': bool(include_logistic), 'logistic_max_iter': 1000,
                      'class_weight': 'balanced', 'scaler': 'StandardScaler'})
    # Improvement is descriptive only; it is not a model promotion gate.
    comparison = {}
    if 'majority' in aggregate:
        base = aggregate['majority']
        for name, metric in aggregate.items():
            comparison[name] = {
                'accuracy_delta_vs_majority': float(metric['accuracy'] - base['accuracy']),
                'macro_f1_delta_vs_majority': float(metric['macro_f1'] - base['macro_f1']),
                'log_loss_delta_vs_majority': float(metric['log_loss'] - base['log_loss']),
            }
    payload = {'version': VERSION, 'dataset_hash': dataset['manifest'].get('dataset_hash'),
               'models': sorted(aggregate), 'fold_count': len(folds),
               'oof_rows': int(len(oof)), 'metrics': aggregate, 'comparison_vs_majority': comparison,
               'training_environment': training_environment,
               'oof_prediction_sha256': prediction_digest(oof)}
    payload['evaluation_hash'] = hashlib.sha256(json.dumps(payload, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    training_runs = {}
    training_registry_records = {}
    if lineage is not None:
        from backend.btc_training_lineage import create_training_run_artifact
        for model_name, metrics in aggregate.items():
            run_id = f'{run_id_prefix}-{model_name}'
            output_path = None
            if training_run_dir is not None:
                from pathlib import Path
                output_path = Path(training_run_dir) / f'{run_id}.json'
            artifact = create_training_run_artifact(
                dataset, lineage, model_name=model_name, run_id=run_id,
                output_path=output_path, metrics=metrics, training_environment=training_environment)
            training_runs[model_name] = artifact
            if training_registry_dir is not None:
                from backend.btc_training_registry import register_training_run
                model_oof = oof[oof['model'] == model_name]
                model_folds = [r for r in fold_reports if r['model'] == model_name]
                registration = register_training_run(
                    artifact, lineage,
                    {'predictions': model_oof.to_dict(orient='records'),
                     'fold_reports': model_folds, 'evaluation_hash': payload['evaluation_hash']},
                    registry_dir=training_registry_dir,
                    expected_coverage_contract=coverage_contract)
                training_registry_records[model_name] = registration
    return {'version': VERSION, 'fold_reports': fold_reports, 'oof_predictions': oof,
            'aggregate_metrics': aggregate, 'comparison_vs_majority': comparison,
            'summary': payload, 'training_runs': training_runs,
            'training_registry_records': training_registry_records,
            'oof_coverage_contract': coverage_contract,
            'training_environment': training_environment,
            'oof_prediction_sha256': prediction_digest(oof),
            'lineage_enforced': lineage is not None,
            'holdout_status': 'NOT_USED — reserve a final chronological holdout for one-time evaluation'}
