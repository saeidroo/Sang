"""AI Coach (V17.2) — connect the training loop to a large language model.

This is the "train with your AI teacher" layer requested for V17.2: while the
multi-hour trainer is running, every finished round sends a compact summary
(metrics + the hyper-parameters that were tried) to an OpenAI-compatible chat
API. The default provider is **Z.ai GLM** (the same model family that powers
this assistant) through its public endpoint; any OpenAI-compatible provider
works by changing `AI_COACH_BASE_URL` / `AI_COACH_MODEL`.

What the coach may and may not do:
- MAY: assess the training round, suggest which regularised hyper-parameter
  configuration to try next (`hp_hints`), and give short advice.
- MAY NOT: invent data, disable the champion/challenger gate, bypass the
  out-of-sample edge gate, or touch live orders (there are none).
- The hints are sanitized and clipped into the same safe "shallow + strong
  regularisation" region the random search already uses, and they are only
  *candidates*: the champion gate still decides what is saved.

Everything is optional and fails soft: without an API key the trainer runs
exactly as before. Configure in `.env`:

    ZAI_API_KEY=your-key          # or AI_COACH_API_KEY
    AI_COACH_BASE_URL=https://api.z.ai/api/paas/v4/chat/completions
    AI_COACH_MODEL=glm-4.6
"""
from __future__ import annotations

import json
import math
import os
import re
import threading
import time

import requests

# ---------------------------------------------------------------------------
# configuration
# ---------------------------------------------------------------------------
LOCK = threading.Lock()
_LAST_CALL_TS = 0.0
MIN_CALL_INTERVAL = 45.0        # never spam the API: >= 45s between calls
REQUEST_TIMEOUT = 40.0

# ---------------------------------------------------------------------------
# persistent coach memory (so next rounds learn from previous ones)
# ---------------------------------------------------------------------------
_MEMORY_LOCK = threading.Lock()
_MEMORY_MAX = 40

def _memory_path():
    try:
        from backend.storage import get_models_dir
        p = get_models_dir() / 'coach_memory.json'
    except Exception:
        from pathlib import Path
        p = Path.home() / '.trading_ai_models' / 'coach_memory.json'
    p.parent.mkdir(parents=True, exist_ok=True)
    return p

def load_coach_memory(limit: int = 12) -> list:
    """Return recent coach session summaries (newest last)."""
    p = _memory_path()
    if not p.exists():
        return []
    try:
        with open(p, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, list):
            return []
        return data[-limit:]
    except Exception:
        return []

def save_coach_entry(entry: dict) -> None:
    """Append one round outcome + coach advice for future context."""
    if not isinstance(entry, dict):
        return
    with _MEMORY_LOCK:
        items = load_coach_memory(_MEMORY_MAX + 5)
        clean = {
            'ts': entry.get('ts') or time.time(),
            'symbol': str(entry.get('symbol') or '')[:20],
            'timeframe': str(entry.get('timeframe') or '')[:8],
            'balanced_acc': entry.get('balanced_acc'),
            'promoted': bool(entry.get('promoted')),
            'verdict': str(entry.get('verdict') or '')[:20],
            'assessment_fa': str(entry.get('assessment_fa') or '')[:220],
            'advice_fa': str(entry.get('advice_fa') or '')[:180],
            'hp_hints': entry.get('hp_hints') if isinstance(entry.get('hp_hints'), dict) else {},
        }
        items.append(clean)
        items = items[-_MEMORY_MAX:]
        try:
            with open(_memory_path(), 'w', encoding='utf-8') as f:
                json.dump(items, f, ensure_ascii=False, indent=1, default=str)
        except Exception:
            pass

def memory_context_text(symbol: str = '', timeframe: str = '', limit: int = 8) -> str:
    """Compact history string for the coach system/user prompt."""
    items = load_coach_memory(30)
    if not items:
        return ''
    # Prefer same symbol/tf, then fall back to global recent
    same = [x for x in items if x.get('symbol') == symbol and x.get('timeframe') == timeframe]
    pool = same[-limit:] if same else items[-limit:]
    lines = []
    for x in pool:
        acc = x.get('balanced_acc')
        acc_s = f"{acc*100:.1f}%" if isinstance(acc, (int, float)) else '—'
        lines.append(
            f"- {x.get('symbol')} {x.get('timeframe')}: acc={acc_s}, "
            f"promoted={x.get('promoted')}, verdict={x.get('verdict') or '—'}; "
            f"{(x.get('assessment_fa') or '')[:80]}"
        )
    return 'Previous training rounds (use to avoid repeating failed HPs and to continue what worked):\n' + '\n'.join(lines)


BASE_URL_DEFAULT = 'https://api.z.ai/api/paas/v4/chat/completions'
MODEL_DEFAULT = 'glm-4.6'


def _settings() -> dict:
    base = (os.getenv('AI_COACH_BASE_URL', '') or BASE_URL_DEFAULT).strip()
    model = (os.getenv('AI_COACH_MODEL', '') or MODEL_DEFAULT).strip()
    key = (os.getenv('ZAI_API_KEY', '') or os.getenv('AI_COACH_API_KEY', '') or '').strip()
    return {'base_url': base, 'model': model, 'api_key': key}


def coach_available() -> dict:
    s = _settings()
    return {
        'available': bool(s['api_key']),
        'provider': 'zai_glm' if 'z.ai' in s['base_url'] else 'openai_compatible',
        'base_url': s['base_url'],
        'model': s['model'],
        'key_configured': bool(s['api_key']),
        'note': ('کلید تنظیم شده است؛ در هر دور آموزش، خلاصه به مدل ارسال و راهنمایی دریافت می‌شود.'
                 if s['api_key'] else
                 'فعال نیست: ZAI_API_KEY (یا AI_COACH_API_KEY) را در فایل .env تنظیم کن. '
                 'بدون کلید، آموزش مثل قبل و کاملاً محلی اجرا می‌شود.'),
    }


# ---------------------------------------------------------------------------
# safe hyper-parameter hint handling
# ---------------------------------------------------------------------------
_RANGES = {
    'n_estimators': (80, 400),
    'max_iter': (120, 400),
    'max_leaf_nodes': (6, 24),
    'max_depth': (2, 6),
    'num_leaves': (4, 24),
    'learning_rate': (0.02, 0.10),
    'subsample': (0.60, 0.92),
    'colsample_bytree': (0.50, 0.92),
    'min_child_weight': (4, 24),
    'min_child_samples': (25, 90),
    'min_samples_leaf': (6, 30),
    'min_split_gain': (0.02, 0.45),
    'reg_alpha': (0.05, 1.6),
    'reg_lambda': (0.8, 7.0),
    'l2': (0.3, 5.0),
    'gamma': (0.05, 1.4),
    'alpha': (0.004, 0.09),
    'lr': (0.0008, 0.0045),
    'max_features': None,   # handled specially (sqrt/float)
}
_INTEGERS = {'n_estimators', 'max_iter', 'max_leaf_nodes', 'max_depth', 'num_leaves',
             'min_child_weight', 'min_child_samples', 'min_samples_leaf'}
_MODEL_KEYS = ('xgboost', 'lightgbm', 'random_forest', 'extra_trees', 'hist_gb', 'neural_net')


def _clip_value(key: str, value):
    """Clip one hyper-parameter into the safe region; None if unusable."""
    try:
        if key == 'max_features':
            if value in ('sqrt', 'log2'):
                return value
            value = float(value)
            return value if 0.4 <= value <= 0.9 else None
        value = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(value):
        return None
    lo, hi = _RANGES.get(key, (None, None))
    if lo is None:
        return None
    value = max(lo, min(hi, value))
    return int(round(value)) if key in _INTEGERS else round(value, 4)


def sanitize_hint(hint: dict) -> dict | None:
    """Turn a raw coach hint {model: {param: value}} into a safe HP entry."""
    if not isinstance(hint, dict):
        return None
    clean: dict = {}
    for model, params in hint.items():
        model = str(model).strip().lower()
        if model not in _MODEL_KEYS or not isinstance(params, dict):
            continue
        entry = {}
        for key, value in params.items():
            key = str(key).strip()
            if key in ('hidden',):
                continue  # neural shape handled by the random search
            clipped = _clip_value(key, value)
            if clipped is not None:
                entry[key] = clipped
        if entry:
            clean[model] = entry
    return clean or None


# ---------------------------------------------------------------------------
# prompt + call
# ---------------------------------------------------------------------------
_SYSTEM_PROMPT = (
    'You are the AI coach of a trading-signal ML trainer. You receive a JSON '
    'summary of one training round (balanced accuracy, walk-forward accuracy, '
    'out-of-sample trade simulation, best hyper-parameters). Reply with ONLY a '
    'single JSON object, no markdown, in this exact schema: '
    '{"assessment": "<2 Persian sentences>", "verdict": "<keep|explore|tighten>", '
    '"hp_hints": {"<xgboost|lightgbm|random_forest|extra_trees|hist_gb|neural_net>": '
    '{"<param>": <number>}}, "advice_fa": "<one Persian sentence>"}. '
    'hp_hints must stay inside these safe bounds: max_depth 2-6, learning_rate '
    '0.02-0.10, n_estimators 80-400, subsample 0.60-0.92, colsample_bytree '
    '0.50-0.92, min_child_weight 4-24, reg_alpha 0.05-1.6, reg_lambda 0.8-7.0, '
    'gamma 0.05-1.4, num_leaves 4-24. Prefer shallow trees with strong '
    'regularisation for noisy financial labels. Never claim guaranteed profit.'
)

_JSON_RE = re.compile(r'\{.*\}', re.DOTALL)


def _extract_json(text: str) -> dict | None:
    if not text:
        return None
    match = _JSON_RE.search(text)
    if not match:
        return None
    try:
        data = json.loads(match.group(0))
        return data if isinstance(data, dict) else None
    except (ValueError, TypeError):
        return None


def ask_coach(summary: dict, log=None) -> dict:
    """Send one round summary to the coach API; never raises.

    Returns {'available': bool, ...coach fields or 'error'}.
    """
    global _LAST_CALL_TS
    s = _settings()
    if not s['api_key']:
        return {'available': False, 'reason': 'کلید API تنظیم نشده است'}
    with LOCK:
        wait = MIN_CALL_INTERVAL - (time.time() - _LAST_CALL_TS)
        if wait > 0:
            time.sleep(min(wait, 20.0))
        _LAST_CALL_TS = time.time()

    sym = str((summary or {}).get('symbol') or '')
    tf = str((summary or {}).get('timeframe') or '')
    history = memory_context_text(sym, tf, limit=8)
    compact = json.dumps(summary, ensure_ascii=False, default=str)[:3200]
    user_content = compact
    if history:
        user_content = history + '\n\nCurrent round summary:\n' + compact
    payload = {
        'model': s['model'],
        'temperature': 0.35,
        'max_tokens': 700,
        'messages': [
            {'role': 'system', 'content': _SYSTEM_PROMPT +
             ' You receive a short history of previous training rounds. Prefer hyper-parameters '
             'that previously improved out-of-sample metrics and avoid configs that failed.'},
            {'role': 'user', 'content': user_content[:4500]},
        ],
    }
    headers = {'Authorization': f"Bearer {s['api_key']}",
               'Content-Type': 'application/json',
               'User-Agent': 'TradingSignalAIPro/19.0'}
    last_error = None
    for attempt in range(2):
        try:
            response = requests.post(s['base_url'], json=payload, headers=headers,
                                     timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            data = response.json()
            content = ''
            choices = data.get('choices') or []
            if choices:
                message = choices[0].get('message') or {}
                content = str(message.get('content') or '')
            parsed = _extract_json(content)
            if not parsed:
                raise ValueError('پاسخ مدل JSON قابل استخراج نداشت')
            hint = sanitize_hint(parsed.get('hp_hints') or {})
            result = {
                'available': True,
                'model': s['model'],
                'assessment_fa': str(parsed.get('assessment') or '')[:400],
                'verdict': str(parsed.get('verdict') or '').lower()[:20],
                'advice_fa': str(parsed.get('advice_fa') or '')[:300],
                'hp_hints': hint,
                'raw_hint_count': 1 if hint else 0,
            }
            # Persist for next rounds
            try:
                save_coach_entry({
                    'ts': time.time(),
                    'symbol': sym,
                    'timeframe': tf,
                    'balanced_acc': (summary or {}).get('balanced_acc') or (summary or {}).get('metrics', {}).get('balanced_acc'),
                    'promoted': bool((summary or {}).get('promoted')),
                    'verdict': result['verdict'],
                    'assessment_fa': result['assessment_fa'],
                    'advice_fa': result['advice_fa'],
                    'hp_hints': hint,
                })
            except Exception:
                pass
            return result
        except Exception as exc:
            last_error = f'{type(exc).__name__}: {exc}'[:220]
            if attempt == 0:
                time.sleep(3.0)
    if log:
        log(f'⚠ مربی هوش مصنوعی پاسخ نداد: {last_error}')
    return {'available': False, 'error': last_error or 'unknown'}
