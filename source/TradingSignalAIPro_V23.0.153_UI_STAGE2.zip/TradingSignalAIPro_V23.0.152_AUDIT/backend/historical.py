"""Persistent OHLCV data lake with Binance Spot crypto discovery and Yahoo Finance metal history.

This stores candles on disk (SQLite), independently of model training. It is
not a promise that every symbol has millions of bars: history starts where the
exchange lists the market, and practical totals depend on symbols/timeframes,
network, disk and exchange limits.
"""
from __future__ import annotations
import os, sqlite3, threading, time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
# Read project .env when the history CLI is used without importing backend.data.
_ENV_FILE = Path(__file__).resolve().parents[1] / '.env'
if _ENV_FILE.exists():
    for _line in _ENV_FILE.read_text(encoding='utf-8-sig').splitlines():
        _line=_line.strip()
        if _line and not _line.startswith('#') and '=' in _line:
            _k,_v=_line.split('=',1)
            os.environ.setdefault(_k.strip(),_v.strip().strip('"').strip("'"))
import pandas as pd
import requests

TIMEFRAME_MS = {'5m': 300_000, '15m': 900_000, '30m': 1_800_000, '1h': 3_600_000, '4h': 14_400_000, '1d': 86_400_000}
METAL_YAHOO_SYMBOLS = {'GOLD': 'GC=F', 'SILVER': 'SI=F'}
LEVERAGED_SUFFIXES = ('UPUSDT', 'DOWNUSDT', 'BULLUSDT', 'BEARUSDT')
DB_PATH = Path(os.getenv('TRADING_AI_HISTORY_DB', str(Path.home()/'.trading_ai_models'/'history'/'candles.sqlite3'))).expanduser()


def _new_session():
    session = requests.Session()
    session.headers.update({'User-Agent': 'TradingSignalAIPro/22.7.5 historical-data-client'})
    proxy = (os.getenv('TS_AI_PROXY') or os.getenv('SCOUT_PROXY') or '').strip()
    if proxy:
        session.proxies.update({'http': proxy, 'https': proxy})
    return session
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
_LOCK = threading.RLock()
_STOP = threading.Event()
_STATUS = {'running': False, 'cancelled': False, 'symbol': None, 'timeframe': None,
           'downloaded': 0, 'total_requests': 0, 'message': 'آماده', 'started_at': None,
           'last_error': None}


def _connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('PRAGMA synchronous=NORMAL')
    con.execute('''CREATE TABLE IF NOT EXISTS candles (
        symbol TEXT NOT NULL, timeframe TEXT NOT NULL, t INTEGER NOT NULL,
        open REAL NOT NULL, high REAL NOT NULL, low REAL NOT NULL,
        close REAL NOT NULL, volume REAL NOT NULL,
        PRIMARY KEY(symbol,timeframe,t))''')
    con.execute('CREATE INDEX IF NOT EXISTS idx_candles_lookup ON candles(symbol,timeframe,t)')
    con.commit()
    return con


@contextmanager
def _db():
    con=_connect()
    try:
        yield con
    finally:
        con.close()


def count_candles(symbol=None, timeframe=None):
    with _db() as con:
        q='SELECT COUNT(*) FROM candles WHERE 1=1'; p=[]
        if symbol: q+=' AND symbol=?'; p.append(symbol.upper())
        if timeframe: q+=' AND timeframe=?'; p.append(timeframe)
        return int(con.execute(q,p).fetchone()[0])


def history_bounds(symbol, timeframe):
    with _db() as con:
        row=con.execute('SELECT MIN(t),MAX(t),COUNT(*) FROM candles WHERE symbol=? AND timeframe=?',
                        (symbol.upper(),timeframe)).fetchone()
    return {'first_t': row[0], 'last_t': row[1], 'count': int(row[2] or 0)}


def load_history(symbol, timeframe, limit=100000):
    with _db() as con:
        rows=con.execute('''SELECT t,open,high,low,close,volume FROM candles
            WHERE symbol=? AND timeframe=? ORDER BY t DESC LIMIT ?''',
            (symbol.upper(),timeframe,int(limit))).fetchall()
    if not rows:
        return pd.DataFrame(columns=['t','open','high','low','close','volume'])
    return pd.DataFrame(rows,columns=['t','open','high','low','close','volume']).sort_values('t').reset_index(drop=True)


def _store_rows(symbol, timeframe, rows):
    if not rows: return 0
    with _db() as con:
        before=con.total_changes
        con.executemany('''INSERT OR REPLACE INTO candles
            (symbol,timeframe,t,open,high,low,close,volume) VALUES (?,?,?,?,?,?,?,?)''',
            [(symbol.upper(),timeframe,int(x[0]),float(x[1]),float(x[2]),float(x[3]),float(x[4]),float(x[5])) for x in rows])
        con.commit()
        return con.total_changes-before


def _date_ms(value):
    dt=datetime.fromisoformat(value.replace('Z','+00:00'))
    if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp()*1000)


def discover_binance_usdt_symbols():
    """Discover active Binance Spot USDT markets; never rely on a tiny hard-coded list."""
    errors=[]
    for url in ('https://data-api.binance.vision/api/v3/exchangeInfo',
                'https://api.binance.com/api/v3/exchangeInfo'):
        try:
            response=_new_session().get(url, timeout=(5,25))
            response.raise_for_status()
            payload=response.json()
            symbols=[]
            for item in payload.get('symbols', []):
                sym=str(item.get('symbol','')).upper()
                if (item.get('status') == 'TRADING' and item.get('quoteAsset') == 'USDT'
                    and item.get('isSpotTradingAllowed', True)
                    and sym.endswith('USDT') and not sym.endswith(LEVERAGED_SUFFIXES)
                    and item.get('baseAsset') not in {'USDT','USDC','BUSD','TUSD','FDUSD','USDP','DAI'}):
                    symbols.append(sym)
            if not symbols:
                raise RuntimeError('Binance exchangeInfo returned no eligible USDT spot markets')
            return sorted(set(symbols))
        except Exception as exc:
            errors.append(str(exc))
    raise RuntimeError('تعذر اكتشاف أزواج Binance: ' + ' | '.join(errors))


def expand_market_symbols(symbols):
    """Expand ALL_USDT/ALL_CRYPTO markers; include gold and silver only for all-market requests."""
    raw=[str(x).strip().upper() for x in symbols if str(x).strip()]
    wants_all=any(x in {'ALL','ALL_USDT','ALL_CRYPTO'} for x in raw)
    expanded=[]
    if wants_all:
        expanded.extend(discover_binance_usdt_symbols())
    expanded.extend(x for x in raw if x not in {'ALL','ALL_USDT','ALL_CRYPTO'})
    # Keep gold and silver separate from crypto exchange pairs.
    for metal in ('GOLD','SILVER'):
        if wants_all and metal not in expanded:
            expanded.append(metal)
    return list(dict.fromkeys(expanded))


def _fetch_yahoo_metal(symbol, timeframe, start):
    """Fetch and validate metal futures proxy history from Yahoo Finance.

    Yahoo supplies 1h candles for 4h requests, so only fully populated 4-bar
    buckets may be stored. Missing volume is not replaced with synthetic zero:
    the historical store feeds volume-dependent training and must fail closed.
    """
    from .data import _aggregate, _clean_candles

    ticker = METAL_YAHOO_SYMBOLS[symbol]
    start_s = max(0, int(_date_ms(start) / 1000))
    now_s = int(time.time())
    # Yahoo's practical intraday retention is limited; daily history is longer.
    if timeframe in ('5m', '15m', '30m'):
        start_s = max(start_s, now_s - 60 * 86400)
        interval = timeframe
    elif timeframe in ('1h', '4h'):
        start_s = max(start_s, now_s - 730 * 86400)
        interval = '1h'
    else:
        interval = '1d'
    url = f'https://query1.finance.yahoo.com/v8/finance/chart/{requests.utils.quote(ticker, safe="=^-_")}'
    response = _new_session().get(url, params={
        'period1': start_s, 'period2': now_s, 'interval': interval,
        'includePrePost': 'false'}, timeout=(5, 30))
    response.raise_for_status()
    payload = response.json()
    result = (payload.get('chart', {}).get('result') or [])
    if not result:
        error = payload.get('chart', {}).get('error') or {}
        raise RuntimeError(f"Yahoo Finance {symbol}: {error.get('description') or 'بدون داده'}")

    item = result[0]
    stamps = item.get('timestamp') or []
    quote = (item.get('indicators', {}).get('quote') or [{}])[0]
    volume_values = quote.get('volume')
    rows = []
    missing_volume_count = 0
    for i, stamp in enumerate(stamps):
        try:
            vals = [quote[k][i] for k in ('open', 'high', 'low', 'close')]
            if any(v is None for v in vals):
                continue
            volume = None
            if volume_values is not None:
                try:
                    volume = volume_values[i]
                except (IndexError, TypeError):
                    volume = None
            if volume is None:
                missing_volume_count += 1
            rows.append({
                't': int(stamp) * 1000, 'open': vals[0], 'high': vals[1],
                'low': vals[2], 'close': vals[3], 'volume': volume,
            })
        except (IndexError, TypeError, ValueError):
            continue

    if not rows:
        raise RuntimeError(f'Yahoo Finance {symbol}: هیچ کندل OHLC معتبری دریافت نشد')
    frame = _clean_candles(rows)
    audit = dict(frame.attrs.get('normalization_audit') or {})
    if missing_volume_count or not audit.get('volume_available', False):
        raise RuntimeError(
            f'Yahoo Finance {symbol}: حجم واقعی برای {missing_volume_count or audit.get("missing_volume_rows", 0)} کندل موجود نیست؛ '
            'برای جلوگیری از ثبت حجم مصنوعی، Backfill متوقف شد')
    if audit.get('malformed_rows_dropped', 0) or audit.get('duplicate_conflict_groups', 0):
        raise RuntimeError(
            f'Yahoo Finance {symbol}: دادهٔ ناقص یا timestamp متعارض دریافت شد؛ Backfill متوقف شد')

    base_step = {'5m': 300_000, '15m': 900_000, '30m': 1_800_000,
                 '1h': 3_600_000, '4h': 3_600_000, '1d': 86_400_000}[timeframe]
    frame = frame[frame['t'] + base_step <= int(time.time() * 1000)].reset_index(drop=True)
    if timeframe == '4h' and not frame.empty:
        frame = _aggregate(frame, 4 * 3600, source_seconds=3600)
    return frame.sort_values('t').reset_index(drop=True)


def backfill_symbol(symbol, timeframe, start='2017-01-01T00:00:00+00:00', progress=None):
    """Resume historical OHLCV collection for a crypto pair or GOLD/SILVER proxy."""
    if timeframe not in TIMEFRAME_MS: raise ValueError('تایم‌فریم پشتیبانی نمی‌شود')
    symbol=symbol.upper().strip()
    if symbol in METAL_YAHOO_SYMBOLS:
        frame=_fetch_yahoo_metal(symbol,timeframe,start)
        rows=list(frame[['t','open','high','low','close','volume']].itertuples(index=False,name=None))
        added=_store_rows(symbol,timeframe,rows)
        if progress and rows: progress(symbol,timeframe,len(rows),added,1,int(rows[-1][0]))
        return {'symbol':symbol,'timeframe':timeframe,'inserted':added,'pages':1 if rows else 0,
                'total_stored':count_candles(symbol,timeframe),'provider':'Yahoo Finance futures proxy',
                'cancelled':_STOP.is_set()}
    if not symbol.endswith('USDT') or not symbol[:-4].isalnum() or len(symbol)>24:
        raise ValueError('نماد نامعتبر است؛ برای فلزات از GOLD یا SILVER استفاده کن')
    step=TIMEFRAME_MS[timeframe]
    bounds=history_bounds(symbol,timeframe)
    cursor=int(bounds['last_t']) if bounds['last_t'] else _date_ms(start)
    now=int(time.time()*1000)
    sess=_new_session()
    added=0; pages=0
    while cursor < now and not _STOP.is_set():
        params={'symbol':symbol,'interval':timeframe,'startTime':cursor,'endTime':now,'limit':1000}
        response=None; error=None
        unreachable=False
        for attempt in range(5):
            try:
                response=sess.get('https://data-api.binance.vision/api/v3/klines',params=params,timeout=(5,25))
                if response.status_code in (418,429,500,502,503,504):
                    time.sleep(min(2**attempt,20)); continue
                response.raise_for_status(); break
            except (requests.ConnectTimeout,requests.ConnectionError) as exc:
                error=exc; unreachable=True; break      # host does not answer: skip, don't retry
            except Exception as exc:
                error=exc; time.sleep(min(2**attempt,20))
        if response is None or response.status_code != 200:
            try:
                response=sess.get('https://api.binance.com/api/v3/klines',params=params,timeout=(5,25))
                response.raise_for_status()
            except Exception as exc:
                # Fail over to the app's TradingView-first provider chain. This
                # preserves useful history when Binance is unreachable. Providers
                # have different retention limits, so report the actual source and
                # stored candle count rather than claiming a complete market lifetime.
                try:
                    from .data import fetch_candles
                    fallback = fetch_candles(symbol, timeframe, limit=10000,
                                             source='auto', validation_mode='research')
                    fallback_rows = list(fallback[['t','open','high','low','close','volume']].itertuples(index=False, name=None))
                    fallback_rows = [r for r in fallback_rows if int(r[0]) >= _date_ms(start)
                                     and int(r[0]) + step <= int(time.time()*1000)]
                    inserted = _store_rows(symbol, timeframe, fallback_rows)
                    provider = str(getattr(fallback, 'attrs', {}).get('source') or 'provider fallback')
                    if progress and fallback_rows:
                        progress(symbol, timeframe, len(fallback_rows), inserted, 1,
                                 int(fallback_rows[-1][0]) + step)
                    return {'symbol': symbol, 'timeframe': timeframe, 'inserted': inserted,
                            'pages': 1 if fallback_rows else 0,
                            'total_stored': count_candles(symbol, timeframe),
                            'provider': provider, 'fallback': True,
                            'primary_error': str(error or exc), 'cancelled': _STOP.is_set()}
                except Exception as fallback_exc:
                    raise RuntimeError(f'Binance history failed ({error or exc}); all fallback sources failed: {fallback_exc}')
        data=response.json()
        if not isinstance(data,list): raise RuntimeError(f'پاسخ تاریخی نامعتبر برای {symbol}')
        if not data: break
        rows=[(int(x[0]),x[1],x[2],x[3],x[4],x[5]) for x in data]
        # Drop the still-forming candle: its close/volume keep changing until the bar
        # ends, and a half-built bar must never be stored or trained on as if closed.
        rows=[r for r in rows if r[0]+step <= int(time.time()*1000)]
        if not rows: break
        added += _store_rows(symbol,timeframe,rows); pages+=1
        next_cursor=rows[-1][0]+step
        if next_cursor <= cursor: break
        cursor=next_cursor
        if progress: progress(symbol,timeframe,len(rows),added,pages,cursor)
        if len(data)<1000: break
        time.sleep(float(os.getenv('HISTORY_REQUEST_DELAY','0.12')))
    return {'symbol':symbol,'timeframe':timeframe,'inserted':added,'pages':pages,
            'total_stored':count_candles(symbol,timeframe),'provider':'Binance Spot', 'fallback':False,
            'cancelled':_STOP.is_set()}


def start_backfill(symbols, timeframes, start='2017-01-01T00:00:00+00:00'):
    try:
        symbols=expand_market_symbols(symbols)
    except Exception as exc:
        _STATUS.update(last_error=str(exc), message=f'خطا در شناسایی بازارها: {exc}')
        return False
    with _LOCK:
        if _STATUS['running']: return False
        _STOP.clear(); _STATUS.update(running=True,cancelled=False,downloaded=0,total_requests=0,
            message='شروع دریافت تاریخچه',started_at=datetime.now().isoformat(),last_error=None)
    def worker():
        try:
            for sym in symbols:
                for tf in timeframes:
                    if _STOP.is_set(): break
                    _STATUS.update(symbol=sym.upper(),timeframe=tf,message=f'دریافت {sym} {tf}')
                    def cb(s,t,n,added,pages,cursor):
                        _STATUS.update(downloaded=_STATUS['downloaded']+n,total_requests=pages,
                            message=f'{s} {t}: صفحه {pages}، مجموع جدید {added:,} کندل')
                    try:
                        result=backfill_symbol(sym,tf,start,cb)
                        _STATUS['message']=f"پایان {sym} {tf}: {result['total_stored']:,} کندل ذخیره‌شده | منبع: {result.get('provider','نامشخص')}"
                    except Exception as exc:
                        _STATUS['last_error']=str(exc)
                        _STATUS['message']=f'خطای {sym} {tf}: {exc}'
            _STATUS['cancelled']=_STOP.is_set()
            _STATUS['message']='دریافت تاریخچه لغو شد' if _STOP.is_set() else 'دریافت تاریخچه کامل شد'
        except Exception as exc:
            _STATUS['last_error']=str(exc); _STATUS['message']=f'خطا: {exc}'
        finally: _STATUS['running']=False
    threading.Thread(target=worker,daemon=True,name='history-backfill').start()
    return True


def stop_backfill():
    _STOP.set(); return True


def backfill_status():
    return {**_STATUS,'db_path':str(DB_PATH),'total_candles':count_candles()}



def purge_unclosed(symbol, timeframe):
    """Delete a stored candle that was still forming when it was saved (older versions)."""
    step=TIMEFRAME_MS[timeframe]; now=int(time.time()*1000)
    with _db() as con:
        cur=con.execute('DELETE FROM candles WHERE symbol=? AND timeframe=? AND t+?>?',
                        (symbol.upper(),timeframe,step,now))
        con.commit(); return cur.rowcount


def ensure_recent_history(symbol, timeframe, limit, start='2017-01-01T00:00:00+00:00'):
    """Make sure the local archive has about `limit` recent bars for this market.

    Only pages what is missing (resumes from the newest stored bar). If the first
    attempt fails the caller simply falls back to the live sources — a source that
    does not answer must never block training.
    """
    purge_unclosed(symbol,timeframe)
    have=history_bounds(symbol,timeframe)['count']
    if symbol.upper() in METAL_YAHOO_SYMBOLS or have < int(limit):
        # Walk back from `limit` bars ago instead of 2017 so a fresh install needs
        # one short download, not the whole multi-year archive.
        step=TIMEFRAME_MS[timeframe]
        lookback_ms=int(limit*1.15)*step
        begin=datetime.fromtimestamp(max(0,(time.time()*1000-lookback_ms))/1000,tz=timezone.utc).isoformat()
        if have == 0:
            start=begin
        backfill_symbol(symbol,timeframe,start)
    else:
        backfill_symbol(symbol,timeframe,start)  # top up the newest bars
    return history_bounds(symbol,timeframe)


def export_archive_bundle():
    """Create a consistent ZIP snapshot of the entire local candle archive.

    Returns (path, manifest). The caller must delete the temporary ZIP after
    the HTTP response has finished sending it. An empty archive returns (None, manifest).
    """
    import json, tempfile, zipfile
    from datetime import datetime, timezone

    with _db() as con:
        total = int(con.execute('SELECT COUNT(*) FROM candles').fetchone()[0])
        rows = con.execute("SELECT symbol, timeframe, MIN(t), MAX(t), COUNT(*) FROM candles "
                           "GROUP BY symbol, timeframe ORDER BY symbol, timeframe").fetchall()
        if total <= 0:
            return None, {'total_candles': 0, 'markets': [], 'error': 'آرشیو هنوز داده‌ای ندارد'}
        fd_db, db_path = tempfile.mkstemp(prefix='tsai-history-', suffix='.sqlite3')
        os.close(fd_db)
        fd_zip, zip_path = tempfile.mkstemp(prefix='TradingSignalAIPro_History_', suffix='.zip')
        os.close(fd_zip)
        try:
            dest = sqlite3.connect(db_path)
            try:
                con.backup(dest)
            finally:
                dest.close()
        except Exception:
            for path in (db_path, zip_path):
                try: os.unlink(path)
                except OSError: pass
            raise

    markets = [{
        'symbol': r[0], 'timeframe': r[1],
        'first_candle_utc': datetime.fromtimestamp(r[2] / 1000, tz=timezone.utc).isoformat(),
        'last_candle_utc': datetime.fromtimestamp(r[3] / 1000, tz=timezone.utc).isoformat(),
        'candles': int(r[4]),
    } for r in rows]
    manifest = {
        'application': 'TradingSignalAIPro', 'archive_format': 1,
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'total_candles': total, 'market_timeframe_count': len(markets),
        'database_file': 'candles.sqlite3', 'markets': markets,
        'note': 'Snapshot of all candles stored locally at export time; no live data is added by export.',
    }
    try:
        with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            zf.write(db_path, 'candles.sqlite3')
            zf.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
            zf.writestr('README.txt', 'این فایل شامل نسخه پشتیبان آرشیو کندل‌های ذخیره‌شده در برنامه است.\nبرای بازگردانی، برنامه را ببندید و فایل candles.sqlite3 را در مسیر آرشیو محلی خود جایگزین کنید؛ قبل از جایگزینی از فایل فعلی نسخه پشتیبان بگیرید.\n')
    except Exception:
        try: os.unlink(zip_path)
        except OSError: pass
        raise
    finally:
        try: os.unlink(db_path)
        except OSError: pass
    return zip_path, manifest
