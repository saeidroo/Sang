"""V22 Data Contract: auditable, fail-closed OHLCV validation.

This module is deliberately independent from providers and model code. It does not
silently repair, sort, or deduplicate candles. Callers receive a report and must
explicitly refuse BLOCKED batches before training or producing a tradable signal.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import math
import time

import numpy as np
import pandas as pd

from .data import TIMEFRAME_SECONDS

CONTRACT_VERSION = "22.1.0"
REQUIRED_COLUMNS = ("t", "open", "high", "low", "close")
OUTPUT_COLUMNS = ("t", "open", "high", "low", "close", "volume")
TRADING_MODES = {"paper", "live"}


@dataclass
class DataContractResult:
    """Validation result. `candles` is diagnostic output, not permission to trade."""
    candles: pd.DataFrame
    report: dict[str, Any]

    @property
    def status(self) -> str:
        return str(self.report["status"])

    @property
    def allowed(self) -> bool:
        return self.status == "PASS"

    def require_pass(self) -> pd.DataFrame:
        """Return candles only when the report is exactly PASS."""
        if not self.allowed:
            reasons = "; ".join(self.report.get("block_reasons", [])) or "; ".join(
                self.report.get("warnings", [])) or self.status
            raise DataContractError(f"Data Contract blocked batch: {reasons}")
        return self.candles.copy()

    def require_research_usable(self, *, require_volume: bool = True) -> pd.DataFrame:
        """Allow documented research WARNs, but never hidden/invalid data.

        Training requires real volume because V21 feature engineering includes
        volume-derived inputs. WARN caused by gaps is also rejected by default
        through require_pass at the trainer boundary.
        """
        if self.status == "BLOCKED":
            return self.require_pass()
        if require_volume and not self.report.get("volume_available", True):
            raise DataContractError("Data Contract blocked training: volume data is missing or was zero-filled")
        return self.candles.copy()


class DataContractError(ValueError):
    """Raised when a consumer attempts to use a non-PASS batch."""


def _as_numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def validate_candles(
    candles: pd.DataFrame | list[dict],
    *,
    symbol: str = "UNKNOWN",
    timeframe: str,
    source: str = "unknown",
    mode: str = "research",
    received_at_ms: int | None = None,
    now_ms: int | None = None,
    max_age_bars: int | None = None,
) -> DataContractResult:
    """Validate OHLCV without silent cleanup.

    `mode` is one of research, paper, live. Paper/live are fail-closed for cache
    sources and require an explicit freshness policy (`max_age_bars`). Historical
    internal gaps are reported as WARN; a trailing gap/stale final candle blocks
    paper/live. Duplicate, out-of-order, malformed OHLC and invalid prices block.
    """
    if timeframe not in TIMEFRAME_SECONDS:
        raise ValueError(f"Unsupported timeframe: {timeframe}")
    if mode not in {"research", "paper", "live"}:
        raise ValueError(f"Unsupported validation mode: {mode}")

    now = int(now_ms if now_ms is not None else time.time() * 1000)
    received = int(received_at_ms if received_at_ms is not None else now)
    step_ms = TIMEFRAME_SECONDS[timeframe] * 1000
    raw = pd.DataFrame(candles).copy()
    raw_count = len(raw)
    reasons: list[str] = []
    warnings: list[str] = []

    missing_cols = [c for c in REQUIRED_COLUMNS if c not in raw.columns]
    if missing_cols:
        reasons.append("missing_required_columns:" + ",".join(missing_cols))
        empty = pd.DataFrame(columns=OUTPUT_COLUMNS)
        return DataContractResult(empty, _report(
            symbol, timeframe, source, received, None, None, raw_count, 0,
            duplicate_count=0, malformed_count=raw_count, missing_volume_count=raw_count,
            gap_count=0, max_gap_bars=0, unclosed_count=0, cache_age_sec=None,
            status="BLOCKED", reasons=reasons, warnings=warnings,
        ))

    volume_present = "volume" in raw.columns
    if not volume_present:
        raw["volume"] = np.nan
    for col in OUTPUT_COLUMNS:
        raw[col] = _as_numeric(raw[col])

    # Count duplicates before any operation that could hide them.
    duplicate_count = int(raw["t"].duplicated(keep=False).sum()) if raw_count else 0
    numeric = raw[list(OUTPUT_COLUMNS)].to_numpy(dtype=float) if raw_count else np.empty((0, 6))
    required_numeric = raw[list(REQUIRED_COLUMNS)].to_numpy(dtype=float) if raw_count else np.empty((0, 5))
    finite_required = np.isfinite(required_numeric).all(axis=1) if raw_count else np.array([], dtype=bool)
    finite_volume_or_missing = (np.isfinite(numeric[:, 5]) | np.isnan(numeric[:, 5])) if raw_count else np.array([], dtype=bool)
    positive_prices = (required_numeric[:, 1:] > 0).all(axis=1) if raw_count else np.array([], dtype=bool)
    t_positive = required_numeric[:, 0] > 0 if raw_count else np.array([], dtype=bool)
    o, h, l, c = (raw[k].to_numpy(dtype=float) for k in ("open", "high", "low", "close")) if raw_count else (np.array([]),) * 4
    geometry = ((h >= np.maximum.reduce([o, c, l])) & (l <= np.minimum.reduce([o, c, h]))) if raw_count else np.array([], dtype=bool)
    vol = raw["volume"].to_numpy(dtype=float) if raw_count else np.array([])
    volume_ok = np.isnan(vol) | (np.isfinite(vol) & (vol >= 0)) if raw_count else np.array([], dtype=bool)
    valid_mask = finite_required & finite_volume_or_missing & positive_prices & t_positive & geometry & volume_ok
    malformed_count = int((~valid_mask).sum()) if raw_count else 0
    missing_volume_count = int(raw["volume"].isna().sum()) if raw_count else 0

    if duplicate_count:
        reasons.append(f"duplicate_timestamps:{duplicate_count}")
    if malformed_count:
        reasons.append(f"malformed_rows:{malformed_count}")
    if raw_count > 1:
        ts = raw["t"].to_numpy(dtype=float)
        if np.isfinite(ts).all() and np.any(np.diff(ts) <= 0):
            reasons.append("timestamps_not_strictly_increasing")

    # Keep original ordering and rows for diagnostics. Never auto-sort/deduplicate.
    clean = raw.loc[valid_mask, list(OUTPUT_COLUMNS)].copy()
    if not clean.empty:
        clean["t"] = clean["t"].astype("int64")

    # Missing volume is explicitly represented and consumers can disable volume features.
    volume_available = bool(volume_present and missing_volume_count == 0)
    if missing_volume_count:
        warnings.append("volume_missing; volume-dependent features must be disabled")

    # Check timestamp alignment and gaps only when timestamp values are valid.
    gap_count, max_gap_bars = 0, 0
    if len(clean) > 1:
        diffs = np.diff(clean["t"].to_numpy(dtype=np.int64))
        aligned = (clean["t"].to_numpy(dtype=np.int64) % step_ms == 0).all()
        if not aligned:
            reasons.append("timeframe_alignment_error")
        gap_diffs = diffs[diffs > step_ms]
        gap_count = int(len(gap_diffs))
        max_gap_bars = int(max((int(d // step_ms) - 1 for d in gap_diffs), default=0))
        if gap_count:
            warnings.append(f"internal_gaps:{gap_count}")
    elif len(clean) == 1 and int(clean.iloc[0]["t"]) % step_ms != 0:
        reasons.append("timeframe_alignment_error")

    # Exclude open/future candles from the consumable view, but report them.
    unclosed_count = 0
    last_closed_t = None
    if len(clean):
        is_closed = clean["t"].to_numpy(dtype=np.int64) + step_ms <= now
        unclosed_count = int((~is_closed).sum())
        closed = clean.loc[is_closed].copy()
        if unclosed_count:
            warnings.append(f"unclosed_candles_excluded:{unclosed_count}")
        clean = closed.reset_index(drop=True)
        if len(clean):
            last_closed_t = int(clean["t"].iloc[-1])

    cache_age_sec = None
    if str(source).strip().lower() == "cache":
        cache_age_sec = (max(0.0, (now - (last_closed_t + step_ms)) / 1000.0)
                         if last_closed_t is not None else None)
        if mode in TRADING_MODES:
            reasons.append("cache_source_forbidden_in_trading_mode")
    if mode in TRADING_MODES:
        if not str(source).strip() or str(source).strip().lower() == "unknown":
            reasons.append("source_identity_missing")
        if max_age_bars is None or max_age_bars < 1:
            reasons.append("freshness_policy_not_configured")
        elif last_closed_t is None:
            reasons.append("no_closed_candles")
        else:
            age_ms = now - (last_closed_t + step_ms)
            allowed_age_ms = max_age_bars * step_ms
            if age_ms > allowed_age_ms:
                reasons.append(f"stale_last_closed_candle:{int(age_ms / 1000)}s")
        # A trailing gap means the newest expected candle is absent.
        if last_closed_t is not None and now >= last_closed_t + 2 * step_ms:
            reasons.append("trailing_candle_gap")

    if reasons:
        status = "BLOCKED"
    elif warnings:
        status = "WARN"
    else:
        status = "PASS"

    report = _report(
        symbol, timeframe, source, received,
        int(clean["t"].iloc[0]) if len(clean) else None,
        last_closed_t, raw_count, len(clean), duplicate_count, malformed_count,
        missing_volume_count, gap_count, max_gap_bars, unclosed_count,
        cache_age_sec, status, reasons, warnings,
    )
    report["volume_available"] = volume_available
    report["mode"] = mode
    return DataContractResult(clean.reset_index(drop=True), report)


def _report(symbol, timeframe, source, received_at_ms, first_t, last_closed_t,
            raw_count, valid_count, duplicate_count, malformed_count,
            missing_volume_count, gap_count, max_gap_bars, unclosed_count,
            cache_age_sec, status, reasons, warnings):
    return {
        "contract_version": CONTRACT_VERSION,
        "symbol": symbol,
        "timeframe": timeframe,
        "source": source,
        "received_at": int(received_at_ms),
        "first_t": first_t,
        "last_closed_t": last_closed_t,
        "row_count_raw": int(raw_count),
        "row_count_valid": int(valid_count),
        "duplicate_count": int(duplicate_count),
        "malformed_count": int(malformed_count),
        "missing_volume_count": int(missing_volume_count),
        "gap_count": int(gap_count),
        "max_gap_bars": int(max_gap_bars),
        "unclosed_count": int(unclosed_count),
        "cache_age_sec": cache_age_sec,
        "status": status,
        "block_reasons": list(reasons),
        "warnings": list(warnings),
    }
