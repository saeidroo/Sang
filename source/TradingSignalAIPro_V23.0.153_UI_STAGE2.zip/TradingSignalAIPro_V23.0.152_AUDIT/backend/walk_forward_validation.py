"""Expanding-window walk-forward validation for closed paper-trade cohorts."""
from __future__ import annotations

from collections import defaultdict
import math

from backend.strategy_validation import _context, _metrics


def walk_forward_validate(events, *, min_total=30, min_train=10, min_test=3, folds=4):
    """Evaluate sequential future blocks using only the history before each block.

    Events are grouped by exact strategy/context and sorted by (closed_at, trade_id).
    Each fold trains conceptually on the expanding prefix and evaluates the next
    contiguous block. No shuffling, random split, or future-derived feature is used.
    """
    min_total = max(2, min(5000, int(min_total)))
    min_train = max(2, min(2000, int(min_train)))
    min_test = max(1, min(1000, int(min_test)))
    folds = max(2, min(10, int(folds)))
    groups = defaultdict(list)
    for row in events or []:
        try:
            pnl = float(row.get('net_pnl'))
            closed_at = str(row.get('closed_at') or '').strip()
            if not math.isfinite(pnl) or not closed_at:
                continue
            groups[_context(row)].append((closed_at, str(row.get('trade_id') or ''), pnl))
        except (TypeError, ValueError):
            continue

    reports = []
    for key, values in groups.items():
        values.sort(key=lambda x: (x[0], x[1]))
        n = len(values)
        # Reserve enough observations for a meaningful initial history and at
        # least one test block; split remaining observations into chronological blocks.
        if n < min_total or n < min_train + min_test:
            reports.append(_insufficient(key, n, min_total, min_train, min_test, folds))
            continue
        test_capacity = n - min_train
        actual_folds = min(folds, test_capacity // min_test)
        if actual_folds < 2:
            reports.append(_insufficient(key, n, min_total, min_train, min_test, folds))
            continue
        # Equal-ish contiguous test blocks; remainder is distributed to later folds.
        base, remainder = divmod(test_capacity, actual_folds)
        cursor = min_train
        fold_reports = []
        for index in range(actual_folds):
            block_size = base + (1 if index >= actual_folds - remainder and remainder else 0)
            train = values[:cursor]
            test = values[cursor:cursor + block_size]
            if not test:
                continue
            fold_reports.append({
                'fold': index + 1,
                'train_trades': len(train),
                'test_trades': len(test),
                'train_end': train[-1][0],
                'test_start': test[0][0],
                'test_end': test[-1][0],
                'train_metrics': _metrics([{'net_pnl': x[2]} for x in train]),
                'test_metrics': _metrics([{'net_pnl': x[2]} for x in test]),
                'chronology_valid': train[-1][:2] < test[0][:2],
            })
            cursor += block_size
        tested = sum(f['test_trades'] for f in fold_reports)
        positive_folds = sum(f['test_metrics']['expectancy_usdt'] > 0 for f in fold_reports)
        all_test = [x[2] for x in values[min_train:]]
        aggregate = _metrics([{'net_pnl': p} for p in all_test])
        enough = n >= min_total and len(fold_reports) >= 2 and tested >= 2 * min_test
        if not enough:
            state = 'INSUFFICIENT_EVIDENCE'
        elif aggregate['expectancy_usdt'] > 0 and positive_folds >= math.ceil(len(fold_reports) * 0.75):
            state = 'STABLE_ACROSS_WINDOWS'
        elif aggregate['expectancy_usdt'] > 0:
            state = 'MIXED_WINDOW_PERFORMANCE'
        else:
            state = 'UNSTABLE_OR_NEGATIVE'
        reports.append({
            'strategy': key[0], 'symbol': key[1], 'market': key[2],
            'timeframe': key[3], 'side': key[4], 'market_regime': key[5],
            'volatility_regime': key[6], 'closed_trades': n,
            'initial_history_trades': min_train, 'tested_trades': tested,
            'fold_count': len(fold_reports), 'positive_test_folds': positive_folds,
            'test_metrics_aggregate': aggregate, 'folds': fold_reports,
            'state': state, 'expanding_window': True,
            'chronological_no_shuffle': True, 'future_data_used_for_past': False,
            'closed_paper_trades_only': True,
        })
    reports.sort(key=lambda x: (x['state'] == 'STABLE_ACROSS_WINDOWS',
                                x.get('positive_test_folds', 0),
                                x.get('test_metrics_aggregate', {}).get('expectancy_usdt', 0)), reverse=True)
    return {
        'cohorts': reports, 'cohort_count': len(reports),
        'min_total': min_total, 'min_train': min_train,
        'min_test': min_test, 'requested_folds': folds,
        'split_method': 'EXPANDING_WINDOW_WALK_FORWARD_NO_SHUFFLE',
        'interpretation': 'Historical stability diagnostic only; not a forecast or proof of future profitability.',
        'authorizes_entries': False, 'real_orders_enabled': False,
        'paper_only': True, 'future_data_used_for_past': False,
    }


def _insufficient(key, n, min_total, min_train, min_test, folds):
    return {
        'strategy': key[0], 'symbol': key[1], 'market': key[2],
        'timeframe': key[3], 'side': key[4], 'market_regime': key[5],
        'volatility_regime': key[6], 'closed_trades': n,
        'initial_history_trades': min_train, 'tested_trades': 0,
        'fold_count': 0, 'positive_test_folds': 0, 'folds': [],
        'state': 'INSUFFICIENT_EVIDENCE', 'chronological_no_shuffle': True,
        'future_data_used_for_past': False, 'closed_paper_trades_only': True,
    }
