"""V23.0.152 read-only audit of time-to-first directional price threshold.

Uses only timestamped observations after a recorded Scout sighting and no later
than that sighting's configured outcome due time. It describes historical
latency; it does not forecast or alter ranking.
"""
from __future__ import annotations

import os
import sqlite3
from collections import defaultdict
from pathlib import Path
from statistics import median

DEFAULT_DB = Path(os.getenv("TEKAR_STORM_LEARNING_DB", str(Path(__file__).resolve().parent.parent / "data" / "storm_learning.sqlite3")))
HORIZON_SECONDS = {"1h": 3600, "4h": 14400, "24h": 86400, "3d": 259200, "7d": 604800}


def _direction(value: object) -> str:
    v = str(value or "").strip().lower()
    if v in {"up", "bull", "bullish", "buy", "long"}:
        return "up"
    if v in {"down", "bear", "bearish", "sell", "short"}:
        return "down"
    return "unknown"


def audit_event_timing(db_path: str | Path | None = None, horizon: str = "24h",
                       threshold_pct: float = 1.0, min_samples: int = 5,
                       limit: int = 100) -> dict:
    if horizon not in HORIZON_SECONDS:
        raise ValueError("horizon نامعتبر است")
    threshold_pct = float(threshold_pct)
    if not 0.05 <= threshold_pct <= 20:
        raise ValueError("threshold_pct باید بین ۰٫۰۵ تا ۲۰ باشد")
    min_samples = max(1, min(int(min_samples), 10000))
    limit = max(1, min(int(limit), 1000))
    path = Path(db_path) if db_path is not None else DEFAULT_DB
    base = {"horizon": horizon, "threshold_pct": threshold_pct,
            "is_forecast": False, "ranking_effect": 0.0, "auto_tuning": False,
            "read_only": True, "real_orders_enabled": False}
    if not path.exists():
        return {**base, "status": "no_archive", "directions": {}, "sample_count": 0,
                "note_fa": "آرشیو موجود نیست؛ زمان‌بندی تاریخی محاسبه نشد."}
    con = None
    try:
        con = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
        con.row_factory = sqlite3.Row
        tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        required = {"scout_sightings", "scout_outcomes", "scout_price_observations"}
        if not required.issubset(tables):
            return {**base, "status": "archive_schema_incomplete", "directions": {}, "sample_count": 0}
        rows = con.execute("""SELECT s.id AS sighting_id,s.symbol,s.ts AS spotted_ts,s.price AS spotted_price,
                                   s.direction,o.due_ts,o.resolved_ts,o.result
                            FROM scout_sightings s JOIN scout_outcomes o ON o.sighting_id=s.id
                            WHERE o.horizon=? AND o.resolved_ts IS NOT NULL
                              AND o.result IN ('success','fake','neutral')
                            ORDER BY s.ts LIMIT ?""", (horizon, limit * 10000)).fetchall()
        grouped = defaultdict(list)
        for row in rows:
            direction = _direction(row["direction"])
            start, price, due = float(row["spotted_ts"]), float(row["spotted_price"]), float(row["due_ts"])
            if direction == "unknown" or price <= 0 or due <= start:
                continue
            observations = con.execute("""SELECT ts,price FROM scout_price_observations
                WHERE symbol=? AND ts>? AND ts<=? ORDER BY ts,id""",
                (row["symbol"], start, due)).fetchall()
            first = None
            for obs in observations:
                p = float(obs["price"])
                if p <= 0:
                    continue
                ret = (p / price - 1.0) * 100.0
                signed = ret if direction == "up" else -ret
                if signed >= threshold_pct:
                    first = ("favorable", (float(obs["ts"]) - start) / 60.0)
                    break
                if signed <= -threshold_pct:
                    first = ("adverse", (float(obs["ts"]) - start) / 60.0)
                    break
            grouped[direction].append({"first_touch": first[0] if first else "not_touched",
                                       "minutes": first[1] if first else None,
                                       "outcome": str(row["result"])})
        directions = {}
        for direction, events in grouped.items():
            touches = [e for e in events if e["minutes"] is not None]
            favorable = [e["minutes"] for e in touches if e["first_touch"] == "favorable"]
            adverse = [e["minutes"] for e in touches if e["first_touch"] == "adverse"]
            not_touched = sum(e["first_touch"] == "not_touched" for e in events)
            directions[direction] = {
                "samples": len(events),
                "favorable_first": len(favorable),
                "adverse_first": len(adverse),
                "no_threshold_touch": not_touched,
                "favorable_first_rate": round(len(favorable) / len(events), 4) if events else None,
                "adverse_first_rate": round(len(adverse) / len(events), 4) if events else None,
                "median_minutes_to_favorable": round(median(favorable), 2) if favorable else None,
                "median_minutes_to_adverse": round(median(adverse), 2) if adverse else None,
                "timing_reliability": "insufficient_samples" if len(events) < min_samples else "descriptive",
            }
        return {**base, "status": "ok", "directions": directions,
                "sample_count": sum(len(v) for v in grouped.values()),
                "minimum_samples": min_samples,
                "note_fa": "زمان اولین برخورد قیمت با آستانه از داده‌های ثبت‌شده محاسبه شده؛ عبور ثبت‌نشده یا مسیر درون‌کندلی حدس زده نشده است. این گزارش پیش‌بینی یا سیگنال نیست."}
    except (sqlite3.Error, OSError, ValueError, TypeError):
        return {**base, "status": "archive_read_error", "directions": {}, "sample_count": 0}
    finally:
        if con is not None:
            con.close()
