"""Independent Witness replication and cross-checks (V22.2o)."""
from __future__ import annotations
import hashlib, json, sqlite3
from pathlib import Path
from backend.witness_server import record_anchor, verify_anchor_record
from backend.witness_ops import _records


def _verified_rows(db_path, public_key_path):
    rows = _records(db_path)
    verified = []
    for expected, row in enumerate(rows, 1):
        if row['sequence'] != expected:
            raise ValueError('witness_sequence_gap')
        anchor = json.loads(row['anchor_json'])
        digest = hashlib.sha256(json.dumps(anchor, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()
        if digest != row['anchor_digest']:
            raise ValueError('witness_anchor_payload_digest_mismatch')
        receipt = {k: row[k] for k in ('schema_version','witness_id','anchor_digest','sequence','timestamp','signature')}
        verify_anchor_record(receipt, public_key_path)
        verified.append((row, anchor))
    return verified


def compare_witnesses(primary_db, primary_public_key, secondary_db, secondary_public_key):
    """Compare logical anchor streams; signatures/timestamps are witness-specific."""
    a = _verified_rows(primary_db, primary_public_key)
    b = _verified_rows(secondary_db, secondary_public_key)
    common = min(len(a), len(b))
    mismatches = [i + 1 for i in range(common) if a[i][0]['anchor_digest'] != b[i][0]['anchor_digest']]
    return {
        'consistent': not mismatches and (len(a) == len(b) or len(a) > len(b)),
        'primary_count': len(a), 'secondary_count': len(b),
        'primary_head_digest': a[-1][0]['anchor_digest'] if a else None,
        'secondary_head_digest': b[-1][0]['anchor_digest'] if b else None,
        'common_prefix': common, 'mismatch_sequences': mismatches,
        'replication_lag': max(0, len(a) - len(b)),
        'secondary_ahead': max(0, len(b) - len(a)),
    }


def replicate_to_secondary(primary_db, primary_public_key, secondary_db, secondary_private_key, secondary_public_key, *, secondary_witness_id='ts-ai-witness-secondary'):
    """Verify source receipts, then append missing logical anchors to secondary.

    Existing secondary entries must be an exact digest prefix; divergent or
    ahead replicas are rejected rather than silently overwritten.
    """
    source = _verified_rows(primary_db, primary_public_key)
    target = _verified_rows(secondary_db, secondary_public_key) if Path(secondary_db).exists() else []
    for i in range(min(len(source), len(target))):
        if source[i][0]['anchor_digest'] != target[i][0]['anchor_digest']:
            raise ValueError(f'witness_replication_divergence_at_sequence:{i+1}')
    if len(target) > len(source):
        raise ValueError('secondary_witness_ahead_of_primary')
    appended = 0
    for row, anchor in source[len(target):]:
        receipt = record_anchor(secondary_db, secondary_private_key, anchor, witness_id=secondary_witness_id)
        if receipt['anchor_digest'] != row['anchor_digest']:
            raise ValueError('replicated_anchor_digest_mismatch')
        appended += 1
    report = compare_witnesses(primary_db, primary_public_key, secondary_db, secondary_public_key)
    if not report['consistent'] or report['replication_lag']:
        raise ValueError('witness_replication_postcheck_failed')
    report['appended'] = appended
    report['status'] = 'synchronized'
    return report


def accept_remote_entries(secondary_db, secondary_private_key, trusted_source_public_key, entries, *, witness_id='ts-ai-witness-secondary', after_sequence=0):
    """Accept a bounded contiguous chunk, including safe retries after partial commits."""
    from backend.witness_server import verify_anchor_record, record_anchor, SCHEMA
    if not isinstance(entries, list) or len(entries) > 5000: raise ValueError('replication_entries_must_be_bounded_list')
    if not isinstance(after_sequence, int) or after_sequence < 0: raise ValueError('replication_cursor_invalid')
    verified=[]
    for offset, entry in enumerate(entries, 1):
        if not isinstance(entry, dict) or not isinstance(entry.get('receipt'), dict) or not isinstance(entry.get('anchor'), dict):
            raise ValueError('replication_entry_invalid')
        receipt=entry['receipt']; expected=after_sequence+offset
        if receipt.get('sequence') != expected: raise ValueError('replication_source_sequence_gap')
        if receipt.get('schema_version') != SCHEMA: raise ValueError('replication_source_schema_unsupported')
        digest=hashlib.sha256(json.dumps(entry['anchor'],sort_keys=True,separators=(',', ':'),ensure_ascii=False).encode()).hexdigest()
        if digest != receipt.get('anchor_digest'): raise ValueError('replication_source_digest_mismatch')
        try: verify_anchor_record(receipt, trusted_source_public_key)
        except Exception as exc: raise ValueError('replication_source_signature_invalid') from exc
        verified.append((receipt, entry['anchor']))
    if not Path(secondary_db).exists():
        from backend.witness_server import init_db
        init_db(secondary_db)
    existing=_verified_rows(secondary_db, _secondary_public_key_from_private(secondary_private_key))
    appended=0
    for receipt, anchor in verified:
        seq=int(receipt['sequence'])
        if seq <= len(existing):
            if existing[seq-1][0]['anchor_digest'] != receipt['anchor_digest']:
                raise ValueError(f'remote_replication_divergence_at_sequence:{seq}')
            continue
        if seq != len(existing)+1: raise ValueError('remote_replication_cursor_gap')
        local=record_anchor(secondary_db,secondary_private_key,anchor,witness_id=witness_id)
        if local['anchor_digest'] != receipt['anchor_digest']: raise ValueError('remote_replication_digest_mismatch')
        # Add the just-committed row to the verified in-memory prefix. It was
        # signed locally by record_anchor; next request will verify full DB.
        existing.append(({'sequence':seq,'anchor_digest':local['anchor_digest']},anchor))
        appended+=1
    count=len(_records(secondary_db))
    rows=_records(secondary_db)
    return {'status':'synchronized' if count == (verified[-1][0]['sequence'] if verified else after_sequence) else 'partial',
            'source_count':verified[-1][0]['sequence'] if verified else after_sequence,
            'secondary_count':count,'sequence':count,
            'appended':appended,'head_digest':rows[-1]['anchor_digest'] if rows else None}


def _secondary_public_key_from_private(private_path):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    key=serialization.load_pem_private_key(Path(private_path).read_bytes(),password=None)
    if not isinstance(key,Ed25519PrivateKey): raise ValueError('secondary_key_must_be_ed25519')
    # Verification of the local replica is not needed to accept source signatures;
    # return its derived public key for local chain integrity validation.
    pub=key.public_key()
    pem=pub.public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)
    tmp=Path(private_path).with_suffix('.derived-public.tmp')
    tmp.write_bytes(pem)
    return tmp
