"""V23.0.76 read-only smart-money/volume-flow evidence analyzer.
Uses supplied OHLCV and optional taker-buy volume; does not infer actor identity.
"""
from __future__ import annotations
import math


def _num(v):
    if isinstance(v, bool) or v is None:
        return None
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError, OverflowError):
        return None


def _candles(raw):
    if not isinstance(raw, list) or len(raw) < 3 or len(raw) > 1000:
        return []
    out = []
    for row in raw:
        if not isinstance(row, dict):
            continue
        x = {k: _num(row.get(k)) for k in ('open', 'high', 'low', 'close', 'volume', 'taker_buy_volume')}
        if all(x[k] is not None and x[k] > 0 for k in ('open', 'high', 'low', 'close', 'volume')) and x['high'] >= max(x['open'], x['close']) and x['low'] <= min(x['open'], x['close']) and x['high'] >= x['low']:
            if x['taker_buy_volume'] is not None and not (0 <= x['taker_buy_volume'] <= x['volume']):
                x['taker_buy_volume'] = None
            out.append(x)
    return out


def analyze_smart_money_flow(candidates):
    if not isinstance(candidates, list):
        raise ValueError('candidates must be a list')
    results = []
    for raw in candidates[:100]:
        if not isinstance(raw, dict):
            results.append({'decision': 'INSUFFICIENT_DATA', 'score': 0, 'reasons': ['INVALID_CANDIDATE'], 'entry_authorized': False})
            continue
        symbol = str(raw.get('symbol') or '').upper().strip()
        cs = _candles(raw.get('candles'))
        evidence, warnings, reasons, score = {}, [], [], 0
        if len(cs) < 3:
            reasons.append('INSUFFICIENT_VALID_OHLCV')
            decision, label = 'INSUFFICIENT_DATA', 'UNKNOWN'
        else:
            recent = cs[-3:]
            prior = cs[:-3]
            base = sum(x['volume'] for x in prior[-20:]) / len(prior[-20:]) if prior else 0
            latest = recent[-1]
            vwap_proxy = sum(x['close'] * x['volume'] for x in recent) / sum(x['volume'] for x in recent)
            signed = sum((2 * (x['close'] - x['low']) / (x['high'] - x['low']) - 1) * x['volume'] if x['high'] > x['low'] else 0 for x in recent)
            total = sum(x['volume'] for x in recent)
            pressure = signed / total if total else 0
            evidence.update({'three_candle_volume': round(total, 8), 'three_candle_signed_volume_pressure': round(pressure, 4), 'recent_vwap_proxy': round(vwap_proxy, 8)})
            if base > 0:
                vr = latest['volume'] / base
                evidence['latest_volume_vs_prior_baseline'] = round(vr, 4)
                if vr >= 1.5: score += 25
                elif vr >= 1.2: score += 12
            else:
                warnings.append('NO_PRIOR_VOLUME_BASELINE')
            if abs(pressure) >= .25: score += 25
            if pressure > .12: label = 'BUY_PRESSURE'
            elif pressure < -.12: label = 'SELL_PRESSURE'
            else: label = 'NEUTRAL_OR_MIXED'
            closes_up = sum(1 for x in recent if x['close'] > x['open'])
            closes_down = sum(1 for x in recent if x['close'] < x['open'])
            if pressure > .15 and closes_up >= 2: score += 15
            if pressure < -.15 and closes_down >= 2: score += 15
            if latest['close'] > vwap_proxy and pressure > .1: score += 10
            if latest['close'] < vwap_proxy and pressure < -.1: score += 10
            tb = [x for x in recent if x['taker_buy_volume'] is not None]
            if len(tb) == 3:
                buy = sum(x['taker_buy_volume'] for x in tb); vol = sum(x['volume'] for x in tb)
                ratio = buy / vol if vol else .5
                evidence['taker_buy_volume_share'] = round(ratio, 4)
                if ratio >= .60 and pressure > 0: score += 15
                elif ratio <= .40 and pressure < 0: score += 15
                elif .45 <= ratio <= .55: warnings.append('TAKER_FLOW_NEAR_BALANCED')
            else:
                warnings.append('TAKER_BUY_VOLUME_UNAVAILABLE')
            benchmark = _num(raw.get('benchmark_return_pct'))
            asset_ret = (latest['close'] / recent[0]['open'] - 1) * 100 if recent[0]['open'] else None
            if benchmark is not None and asset_ret is not None:
                rel = asset_ret - benchmark
                evidence.update({'asset_return_pct': round(asset_ret, 4), 'benchmark_return_pct': round(benchmark, 4), 'relative_strength_pct': round(rel, 4)})
                if rel >= .5 and pressure > 0: score += 10
                elif rel <= -.5 and pressure < 0: score += 10
            else:
                warnings.append('BENCHMARK_COMPARISON_UNAVAILABLE')
            score = min(score, 100)
            if score >= 60: decision = 'STRONG_FLOW_WATCH'
            elif score >= 35: decision = 'FLOW_WATCH'
            else: decision = 'LOW_CONFIDENCE'
        results.append({'symbol': symbol, 'flow_direction': label, 'decision': decision, 'score': score,
                        'evidence': evidence, 'warnings': warnings, 'reasons': reasons,
                        'entry_authorized': False, 'execution_authorized': False})
    return {'version': '23.0.76', 'count': len(results), 'results': results, 'paper_only': True,
            'capital_usdt': 1000, 'entry_authorized': False, 'execution_authorized': False,
            'creates_orders': False, 'real_orders_enabled': False,
            'disclaimer': 'جریان پول از OHLCV و داده‌های اختیاری taker استخراج می‌شود؛ هویت بازارساز یا ورود سرمایه‌گذار نهادی اثبات نمی‌شود.'}
