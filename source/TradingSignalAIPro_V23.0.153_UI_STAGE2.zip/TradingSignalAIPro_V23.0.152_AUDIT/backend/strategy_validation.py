"""Chronological holdout audit to flag strategy overfitting in paper outcomes."""
from __future__ import annotations
import json
import math
from collections import defaultdict


def _context(row):
    try: ctx=json.loads(row.get('context_json') or '{}')
    except (TypeError, ValueError): ctx={}
    if not isinstance(ctx,dict): ctx={}
    nested=ctx.get('decision') if isinstance(ctx.get('decision'),dict) else {}
    def pick(*keys, default='UNKNOWN'):
        for src in (ctx,nested):
            for key in keys:
                value=src.get(key)
                if value is not None and str(value).strip(): return str(value).strip().upper()
        return default
    atr=None; price=None
    for src in (ctx,nested):
        atr=atr or src.get('atr') or src.get('atr_value')
        price=price or src.get('entry_price') or src.get('price') or src.get('close')
    vol=pick('volatility_regime','volatility_state','volatility_label')
    if vol not in {'LOW','MEDIUM','HIGH','UNKNOWN'}:
        try:
            ratio=float(atr)/float(price)*100
            vol='LOW' if 0<ratio<1 else 'MEDIUM' if ratio<3 else 'HIGH' if ratio>=3 else 'UNKNOWN'
        except (TypeError,ValueError,ZeroDivisionError): vol='UNKNOWN'
    return (pick('strategy_id','strategy','brain','strategy_name','signal_source'),
            str(row.get('symbol','')).upper().replace('/',''),str(row.get('market','')).lower(),
            str(row.get('timeframe','')).lower(),str(row.get('side','')).upper(),
            pick('market_regime','regime','market_state'),vol)


def _metrics(rows):
    pnls=[float(x['net_pnl']) for x in rows]
    wins=sum(x>0 for x in pnls); gross_win=sum(x for x in pnls if x>0); gross_loss=abs(sum(x for x in pnls if x<0))
    return {'trades':len(pnls),'win_rate_pct':round(100*wins/len(pnls),2),
            'expectancy_usdt':round(sum(pnls)/len(pnls),8),
            'profit_factor':round(gross_win/gross_loss,6) if gross_loss else (99.0 if gross_win else None)}


def audit_strategy_overfitting(events, *, min_total=20, min_holdout=5, train_fraction=0.70):
    """Use earliest chronological segment as development and latest as untouched holdout."""
    min_total=max(2,min(5000,int(min_total))); min_holdout=max(2,min(1000,int(min_holdout)))
    train_fraction=float(train_fraction)
    if not math.isfinite(train_fraction) or not 0.5 <= train_fraction <= 0.85: raise ValueError('train_fraction must be between 0.50 and 0.85')
    groups=defaultdict(list)
    for row in events or []:
        try:
            pnl=float(row.get('net_pnl'))
            if not math.isfinite(pnl): continue
            groups[_context(row)].append((str(row.get('closed_at') or ''),str(row.get('trade_id') or ''),pnl))
        except (TypeError,ValueError): continue
    reports=[]
    for key, values in groups.items():
        values.sort(key=lambda x:(x[0],x[1]))
        n=len(values); split=max(1,min(n-1,int(n*train_fraction)))
        train=[{'net_pnl':x[2]} for x in values[:split]]; hold=[{'net_pnl':x[2]} for x in values[split:]]
        enough=n>=min_total and len(hold)>=min_holdout
        tm=_metrics(train); hm=_metrics(hold)
        if not enough: state='INSUFFICIENT_EVIDENCE'
        elif tm['expectancy_usdt']>0 and hm['expectancy_usdt']>0 and (hm['profit_factor'] or 0)>1: state='HOLDOUT_SUPPORTED'
        elif tm['expectancy_usdt']>0 and hm['expectancy_usdt']<=0: state='POSSIBLE_OVERFIT'
        else: state='NO_CONFIRMED_EDGE'
        reports.append({'strategy':key[0],'symbol':key[1],'market':key[2],'timeframe':key[3],'side':key[4],
                        'market_regime':key[5],'volatility_regime':key[6],'development':tm,'holdout':hm,
                        'holdout_start':values[split][0] if hold else None,'state':state,
                        'chronological_split':True,'closed_paper_trades_only':True})
    reports.sort(key=lambda x:(x['state']=='HOLDOUT_SUPPORTED',x['holdout']['expectancy_usdt']),reverse=True)
    return {'cohorts':reports,'cohort_count':len(reports),'min_total':min_total,'min_holdout':min_holdout,
            'train_fraction':train_fraction,'split_method':'CHRONOLOGICAL_HOLDOUT_NO_SHUFFLE',
            'interpretation':'Research diagnostic only; holdout support is not proof of future profitability.',
            'authorizes_entries':False,'real_orders_enabled':False}
