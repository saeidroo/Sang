"""V22.6.4 persistent order-book wall change tracker (read-only, advisory)."""
from __future__ import annotations
import json, os, sqlite3, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.getenv('TEKAR_STORM_DB', str(ROOT / 'data' / 'storm_liquidity.sqlite3')))

def _db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con=sqlite3.connect(str(DB_PATH), timeout=5)
    con.execute('''CREATE TABLE IF NOT EXISTS orderbook_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT, exchange TEXT NOT NULL, symbol TEXT NOT NULL,
        ts REAL NOT NULL, bid_walls TEXT NOT NULL, ask_walls TEXT NOT NULL,
        bid_depth REAL, ask_depth REAL, spread_bps REAL)''')
    con.execute('CREATE INDEX IF NOT EXISTS idx_ob_key_ts ON orderbook_snapshots(exchange,symbol,ts)')
    return con

def _walls(levels, side, median_multiple=3.0, min_quote=5000.0):
    parsed=[]
    for item in levels or []:
        try:
            p=float(item.get('price')); q=float(item.get('quantity', item.get('qty')))
            quote=p*q
            if p>0 and q>0: parsed.append({'price':p,'quantity':q,'quote':quote})
        except (TypeError, ValueError, AttributeError):
            continue
    if not parsed: return []
    quotes=sorted(x['quote'] for x in parsed)
    med=quotes[len(quotes)//2]
    threshold=max(min_quote, med*median_multiple)
    return [{**x,'side':side} for x in parsed if x['quote']>=threshold]

def record_orderbook_snapshot(exchange: str, symbol: str, book: dict, timestamp: float|None=None) -> dict:
    ex=str(exchange or '').strip().lower(); sym=str(symbol or '').strip().upper()
    if not ex or not sym or not isinstance(book,dict) or book.get('status')!='depth_snapshot_ok':
        return {'status':'invalid_snapshot','entry_ready':False}
    ts=float(time.time() if timestamp is None else timestamp)
    bids=_walls(book.get('bid_levels'), 'bid'); asks=_walls(book.get('ask_levels'), 'ask')
    with _db() as con:
        last=con.execute('SELECT ts,bid_walls,ask_walls FROM orderbook_snapshots WHERE exchange=? AND symbol=? ORDER BY ts DESC LIMIT 1',(ex,sym)).fetchone()
        if last and ts<=last[0]: return {'status':'out_of_order_snapshot','entry_ready':False}
        if last and ts-last[0]<30: return {'status':'sample_too_soon','entry_ready':False,'next_sample_after':last[0]+30}
        con.execute('INSERT INTO orderbook_snapshots(exchange,symbol,ts,bid_walls,ask_walls,bid_depth,ask_depth,spread_bps) VALUES(?,?,?,?,?,?,?,?)',
                    (ex,sym,ts,json.dumps(bids),json.dumps(asks),book.get('bid_depth_quote'),book.get('ask_depth_quote'),book.get('spread_bps')))
    old_bids=json.loads(last[1]) if last else []; old_asks=json.loads(last[2]) if last else []
    def compare(old,new):
        events=[]; matched=set()
        for wall in new:
            match=next((i for i,o in enumerate(old) if i not in matched and abs(o['price']-wall['price'])/wall['price']<=0.0015),None)
            if match is None: events.append({'event':'appeared','side':wall['side'],'price':wall['price'],'quote':round(wall['quote'],2)})
            else:
                matched.add(match); events.append({'event':'persisted','side':wall['side'],'price':wall['price'],'quote':round(wall['quote'],2)})
        for i,wall in enumerate(old):
            if i not in matched: events.append({'event':'disappeared','side':wall['side'],'price':wall['price'],'quote':round(wall['quote'],2)})
        return events
    events=compare(old_bids,bids)+compare(old_asks,asks)
    counts={k:sum(e['event']==k for e in events) for k in ('appeared','persisted','disappeared')}
    return {'status':'wall_snapshot_recorded','exchange':ex,'symbol':sym,'timestamp':ts,'wall_counts':counts,
            'wall_events':events,'bid_walls':bids,'ask_walls':asks,'entry_ready':False,
            'warning':'ناپدیدشدن دیوار فقط تغییر دفتر سفارش را نشان می‌دهد؛ لغو سفارش، اجرا یا دستکاری را به‌تنهایی اثبات نمی‌کند.'}

def get_wall_history(exchange: str, symbol: str, limit: int=10) -> dict:
    with _db() as con:
        rows=con.execute('SELECT ts,bid_walls,ask_walls,bid_depth,ask_depth,spread_bps FROM orderbook_snapshots WHERE exchange=? AND symbol=? ORDER BY ts DESC LIMIT ?',
                         (str(exchange).lower(),str(symbol).upper(),max(1,min(int(limit),50)))).fetchall()
    return {'exchange':exchange,'symbol':symbol,'count':len(rows),'snapshots':[{'timestamp':r[0],'bid_walls':json.loads(r[1]),'ask_walls':json.loads(r[2]),'bid_depth_quote':r[3],'ask_depth_quote':r[4],'spread_bps':r[5]} for r in reversed(rows)],'entry_ready':False}
