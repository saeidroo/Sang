"""Shared PAPER trading contract for labels, backtests and paper execution.

The contract deliberately mirrors the model's triple-barrier geometry. It does
not enable or submit real exchange orders.
"""
from __future__ import annotations

import math
from typing import Any

ATR_TP_MULT = 1.5
ATR_SL_MULT = 1.5
TRADE_HORIZON_BARS = 12
TRAIL_TRIGGER_PCT = 1.5
TRAIL_DISTANCE_PCT = 1.0
TIMEFRAME_SECONDS = {"5m": 300, "15m": 900, "30m": 1800,
                     "1h": 3600, "4h": 14400, "1d": 86400}


def timeframe_seconds(timeframe: str) -> int:
    """Return seconds for a supported candle timeframe; reject unknown values."""
    try:
        return TIMEFRAME_SECONDS[str(timeframe).lower()]
    except KeyError as exc:
        raise ValueError(f"unsupported timeframe: {timeframe}") from exc


def trailing_stop_price(*, side: str, peak_price: float, distance_pct: float) -> float:
    """Calculate a trailing stop from the favourable extreme reached so far."""
    peak = float(peak_price)
    distance = float(distance_pct)
    if not math.isfinite(peak) or peak <= 0 or not math.isfinite(distance) or not 0 < distance < 100:
        raise ValueError("peak_price and distance_pct are invalid")
    if str(side).upper() in ("LONG", "BUY"):
        return peak * (1.0 - distance / 100.0)
    if str(side).upper() in ("SHORT", "SELL"):
        return peak * (1.0 + distance / 100.0)
    raise ValueError("side must be LONG/SHORT")


def atr_bracket(*, entry_price: float, atr_value: float, side: str,
                fee_bps_per_side: float = 0.0,
                slippage_bps_per_side: float = 0.0,
                entry_price_is_fill: bool = False) -> dict[str, Any]:
    """Return the canonical symmetric ATR barriers plus their net R/R estimate.

    Barrier geometry is shared by feature labels, backtests and paper execution.
    Execution costs affect the reported net reward/risk, never the barrier
    distances; changing the latter would silently make live-paper outcomes
    inconsistent with the model's training labels.
    """
    try:
        entry = float(entry_price)
        atr = float(atr_value)
        fee_bps = float(fee_bps_per_side)
        slippage_bps = float(slippage_bps_per_side)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("entry, ATR and execution costs must be numeric") from exc
    normalized_side = str(side).upper()
    if normalized_side in ("LONG", "BUY"):
        direction = 1
    elif normalized_side in ("SHORT", "SELL"):
        direction = -1
    else:
        raise ValueError("side must be LONG/SHORT")
    if (not all(math.isfinite(x) for x in (entry, atr, fee_bps, slippage_bps))
            or entry <= 0 or atr <= 0 or fee_bps < 0 or slippage_bps < 0):
        raise ValueError("entry, ATR and execution costs must be finite and valid")

    stop = entry - direction * ATR_SL_MULT * atr
    target = entry + direction * ATR_TP_MULT * atr
    if stop <= 0 or target <= 0:
        raise ValueError("ATR barrier price must remain positive")
    stop_pct = abs(entry - stop) / entry * 100.0
    target_pct = abs(target - entry) / entry * 100.0
    round_trip_cost_pct = 2.0 * (fee_bps + slippage_bps) / 100.0
    # Use the exact deterministic paper fill/fee calculation rather than only
    # subtracting a linear percentage approximation from both barriers.
    from .execution_model import net_return_fraction, net_return_from_filled_entry_fraction
    execution_cost_model = {
        "fee_bps_per_side": fee_bps,
        "total_adverse_price_bps_per_side": slippage_bps,
    }
    normalized_side = "LONG" if direction > 0 else "SHORT"
    if entry_price_is_fill:
        # paper_live has already applied entry-side spread/slippage to this
        # price; only the exit fill and both fees remain to be modeled.
        net_return = net_return_from_filled_entry_fraction
        reward = net_return(entry_fill=entry, exit_reference=target,
                            side=normalized_side, notional=1.0,
                            costs=execution_cost_model)
        stop_return = net_return(entry_fill=entry, exit_reference=stop,
                                 side=normalized_side, notional=1.0,
                                 costs=execution_cost_model)
    else:
        # General/reference-price callers need both entry and exit adverse fills.
        reward = net_return_fraction(
            entry_reference=entry, exit_reference=target, side=normalized_side,
            notional=1.0, costs=execution_cost_model)
        stop_return = net_return_fraction(
            entry_reference=entry, exit_reference=stop, side=normalized_side,
            notional=1.0, costs=execution_cost_model)
    net_reward_pct = 100.0 * reward
    net_stop_return_pct = 100.0 * stop_return
    net_risk_pct = -net_stop_return_pct
    if net_reward_pct <= 0 or net_risk_pct <= 0:
        raise ValueError("برآورد هزینه اجرا از سود هدف ATR بیشتر است؛ ورود متوقف شد")
    net_rr = net_reward_pct / net_risk_pct
    if not math.isfinite(net_rr) or net_rr <= 0:
        raise ValueError("نسبت سود به ریسک خالص ATR نامعتبر است")
    return {
        "entry_price": entry,
        "stop_price": stop,
        "target_price": target,
        "stop_loss_pct": stop_pct,
        "take_profit_pct": target_pct,
        "atr_value": atr,
        "atr_pct": atr / entry * 100.0,
        "stop_atr_multiplier": ATR_SL_MULT,
        "target_atr_multiplier": ATR_TP_MULT,
        "horizon_bars": float(TRADE_HORIZON_BARS),
        "round_trip_cost_pct": round_trip_cost_pct,
        "net_reward_pct": net_reward_pct,
        "net_risk_pct": net_risk_pct,
        "net_reward_risk": net_rr,
        "funding_included": False,
    }
