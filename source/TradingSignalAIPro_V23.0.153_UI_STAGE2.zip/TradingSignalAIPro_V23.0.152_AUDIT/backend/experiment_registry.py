"""Append-only experiment and hypothesis registry (V22.1 P4)."""
from __future__ import annotations
import hashlib, json, os, threading, uuid
from datetime import datetime, timezone
from pathlib import Path
from .storage import get_models_dir
from .audit_trail import seal_event, verify_events

_LOCK = threading.RLock()
STATUSES = {"PROPOSED", "PENDING", "RUNNING", "ACCEPTED", "REJECTED", "INCONCLUSIVE", "ROLLED_BACK", "FAILED"}

def _now(): return datetime.now(timezone.utc).isoformat(timespec="seconds")
def stable_hash(value):
    raw=json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()
def _path(custom_dir=None):
    base = Path(custom_dir).expanduser() if custom_dir else get_models_dir()
    p=base / "experiments" / "registry.jsonl"; p.parent.mkdir(parents=True, exist_ok=True); return p
def _append(event, custom_dir=None):
    event=dict(event); event.setdefault("event_id", str(uuid.uuid4())); event.setdefault("recorded_at", _now())
    with _LOCK:
        p=_path(custom_dir)
        existing=read_events(custom_dir)
        sealed=[e for e in existing if e.get("event_hash")]
        previous=sealed[-1]["event_hash"] if sealed else "0"*64
        event=seal_event(event,previous)
        line=json.dumps(event, ensure_ascii=False, sort_keys=True, default=str)
        # Append-only: write one complete chained record under process lock.
        fd=os.open(str(p), os.O_CREAT|os.O_APPEND|os.O_WRONLY, 0o600)
        try: os.write(fd, (line+"\n").encode("utf-8")); os.fsync(fd)
        finally: os.close(fd)
    return event
def read_events(custom_dir=None):
    p=_path(custom_dir)
    if not p.exists(): return []
    out=[]
    for line in p.read_text(encoding="utf-8").splitlines():
        try:
            item=json.loads(line)
            if isinstance(item,dict): out.append(item)
        except (ValueError, TypeError): continue
    return out
def audit_integrity(custom_dir=None):
    return verify_events(read_events(custom_dir))
def trial_count(hypothesis_id=None, custom_dir=None):
    events=read_events(custom_dir)
    return sum(1 for e in events if e.get("event_type")=="experiment_started" and (hypothesis_id is None or e.get("hypothesis_id")==hypothesis_id))
def register_hypothesis(hypothesis_id, title, hypothesis, scope=None, primary_metric=None, acceptance_criteria=None, custom_dir=None):
    if not hypothesis_id or not title or not hypothesis: raise ValueError("hypothesis_id, title and hypothesis are required")
    return _append({"event_type":"hypothesis_registered","hypothesis_id":str(hypothesis_id),"title":title,"hypothesis":hypothesis,"scope":scope or {},"primary_metric":primary_metric,"acceptance_criteria":acceptance_criteria or {},"status":"PROPOSED"},custom_dir)
def start_experiment(hypothesis_id, *, symbol, timeframe, data_hash, config, code_id=None, seed=None, baseline_version=None, challenger_version=None, custom_dir=None):
    if not hypothesis_id or not data_hash: raise ValueError("hypothesis_id and data_hash are required for reproducibility")
    cfg_hash=stable_hash(config)
    prior=trial_count(hypothesis_id,custom_dir)+1
    return _append({"event_type":"experiment_started","experiment_id":str(uuid.uuid4()),"hypothesis_id":hypothesis_id,"status":"RUNNING","scope":{"symbol":symbol,"timeframe":timeframe},"trial_number":prior,"trial_count_at_start":prior,"data_hash":data_hash,"config_hash":cfg_hash,"config":config,"code_commit":code_id or os.getenv("TS_AI_CODE_ID","working-tree"),"seed":seed,"baseline_version":baseline_version,"challenger_version":challenger_version},custom_dir)
def finish_experiment(experiment_id, status, metrics=None, decision_reason=None, negative_result=None, model_path=None, custom_dir=None):
    status=str(status).upper()
    if status not in STATUSES-{"PROPOSED","PENDING","RUNNING"}: raise ValueError(f"invalid terminal status: {status}")
    return _append({"event_type":"experiment_finished","experiment_id":experiment_id,"status":status,"metrics":metrics or {},"decision_reason":decision_reason,"negative_result":negative_result,"model_path":model_path},custom_dir)
def negative_results(custom_dir=None):
    events=read_events(custom_dir); starts={e.get("experiment_id"):e for e in events if e.get("event_type")=="experiment_started"}
    out=[]
    for e in events:
        if e.get("event_type")=="experiment_finished" and e.get("status") in {"REJECTED","INCONCLUSIVE","FAILED"}:
            out.append({**starts.get(e.get("experiment_id"),{}),**e})
    return out
