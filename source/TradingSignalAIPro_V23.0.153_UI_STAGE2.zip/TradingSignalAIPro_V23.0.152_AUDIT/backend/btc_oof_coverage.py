"""V22.3r: deterministic expected OOF coverage contract derived from dataset folds."""
from __future__ import annotations
import hashlib, json
from typing import Any


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def _sha(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode('utf-8')).hexdigest()


def build_oof_coverage_contract(dataset: dict) -> dict:
    """Derive exact model-independent fold->dataset-sample coverage from Trainer input."""
    if not isinstance(dataset, dict) or not isinstance(dataset.get('folds'), list) or not dataset['folds']:
        raise ValueError('oof_coverage_dataset_folds_required')
    manifest = dataset.get('manifest', {})
    dataset_hash = manifest.get('dataset_hash')
    if not isinstance(dataset_hash, str) or len(dataset_hash) != 64:
        raise ValueError('oof_coverage_dataset_hash_invalid')
    metadata = dataset.get('metadata')
    if metadata is None or not {'timestamp_utc', 'row_identity_sha256', 'sample_id'} <= set(metadata.columns):
        raise ValueError('oof_coverage_sample_identity_metadata_required')
    if len(metadata) == 0:
        raise ValueError('oof_coverage_sample_identity_metadata_empty')
    identities = {}
    for sample_index, row in metadata.iterrows():
        timestamp_utc = str(row['timestamp_utc'])
        row_hash = str(row['row_identity_sha256'])
        sample_id = str(row['sample_id'])
        if len(row_hash) != 64 or sample_id != 'btc4h-row-' + row_hash or not timestamp_utc.endswith('Z'):
            raise ValueError(f'oof_coverage_sample_identity_invalid:{sample_index}')
        identities[str(int(sample_index))] = {'sample_id': sample_id, 'timestamp_utc': timestamp_utc,
                                               'row_identity_sha256': row_hash}
    fold_map = {}
    seen_all = set()
    for fold in dataset['folds']:
        if not isinstance(fold, dict):
            raise ValueError('oof_coverage_fold_invalid')
        fid = str(int(fold['fold']))
        if fid in fold_map:
            raise ValueError('oof_coverage_duplicate_fold')
        indices = [int(x) for x in fold.get('validation_sample_indices', [])]
        if not indices or len(indices) != len(set(indices)) or any(x < 0 for x in indices):
            raise ValueError(f'oof_coverage_validation_indices_invalid:{fid}')
        overlap = seen_all.intersection(indices)
        if overlap:
            raise ValueError(f'oof_coverage_validation_overlap:{fid}:{sorted(overlap)}')
        seen_all.update(indices)
        fold_map[fid] = sorted(indices)
    body = {'schema_version': 'btc-oof-coverage-v1', 'dataset_hash': dataset_hash,
            'fold_sample_indices': {k: fold_map[k] for k in sorted(fold_map, key=int)},
            'expected_fold_ids': sorted((int(k) for k in fold_map)),
            'expected_sample_indices': sorted(seen_all),
            'expected_prediction_count_per_model': len(seen_all),
            'sample_identities': {str(i): identities[str(i)] for i in sorted(seen_all)},
            'source': 'dataset.folds.validation_sample_indices+metadata.sample_identity'}
    body['contract_sha256'] = _sha(body)
    return body


def require_oof_coverage_contract(contract: dict, *, dataset_hash: str | None = None) -> dict:
    if not isinstance(contract, dict) or contract.get('schema_version') != 'btc-oof-coverage-v1':
        raise ValueError('oof_coverage_contract_invalid')
    body = dict(contract); declared = body.pop('contract_sha256', None)
    if not declared or _sha(body) != declared:
        raise ValueError('oof_coverage_contract_hash_mismatch')
    if dataset_hash is not None and contract.get('dataset_hash') != dataset_hash:
        raise ValueError('oof_coverage_dataset_hash_mismatch')
    mapping = contract.get('fold_sample_indices')
    if not isinstance(mapping, dict) or not mapping:
        raise ValueError('oof_coverage_mapping_missing')
    normalized = {str(int(k)): sorted(int(x) for x in v) for k, v in mapping.items()}
    if len(normalized) != len(mapping) or any(not v or len(v) != len(set(v)) for v in normalized.values()):
        raise ValueError('oof_coverage_mapping_invalid')
    expected_folds = sorted(int(k) for k in normalized)
    expected_samples = sorted(x for values in normalized.values() for x in values)
    if len(expected_samples) != len(set(expected_samples)):
        raise ValueError('oof_coverage_sample_overlap')
    if expected_folds != contract.get('expected_fold_ids') or expected_samples != contract.get('expected_sample_indices'):
        raise ValueError('oof_coverage_summary_mismatch')
    if len(expected_samples) != contract.get('expected_prediction_count_per_model'):
        raise ValueError('oof_coverage_count_mismatch')
    identities = contract.get('sample_identities')
    if not isinstance(identities, dict) or set(identities) != {str(i) for i in expected_samples}:
        raise ValueError('fold_sample_coverage_mismatch:sample_identity_set_mismatch')
    for index, identity in identities.items():
        if (not isinstance(identity, dict) or identity.get('sample_id') != 'btc4h-row-' + str(identity.get('row_identity_sha256', ''))
                or len(str(identity.get('row_identity_sha256', ''))) != 64
                or not str(identity.get('timestamp_utc', '')).endswith('Z')):
            raise ValueError(f'oof_coverage_sample_identity_invalid:{index}')
    return contract
