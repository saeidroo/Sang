"""V22.3p: deterministic OOF audit and replay without retraining."""
from __future__ import annotations
import hashlib, json
from typing import Any


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False, default=str)


def _sha(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode('utf-8')).hexdigest()


def audit_oof_report(oof_report: dict, *, model_name: str | None = None,
                     expected_fold_ids: list[int] | None = None,
                     expected_sample_indices: list[int] | None = None,
                     expected_fold_sample_indices: dict | None = None,
                     expected_sample_identities: dict | None = None) -> dict:
    """Validate OOF uniqueness, fold coverage, sample coverage and fold-report consistency."""
    if not isinstance(oof_report, dict) or not isinstance(oof_report.get('predictions'), list):
        raise ValueError('oof_report_invalid')
    predictions = oof_report['predictions']
    fold_reports = oof_report.get('fold_reports', [])
    if not isinstance(fold_reports, list):
        raise ValueError('oof_fold_reports_invalid')
    seen = set(); folds = set(); samples = set(); errors = []
    for i, row in enumerate(predictions):
        if not isinstance(row, dict):
            errors.append(f'prediction_{i}_not_object'); continue
        if model_name is not None and row.get('model') != model_name:
            errors.append(f'prediction_{i}_model_mismatch')
        try:
            fold, sample = int(row['fold']), int(row['sample_index'])
        except (KeyError, TypeError, ValueError):
            errors.append(f'prediction_{i}_missing_identity'); continue
        if expected_sample_identities is not None:
            identity = expected_sample_identities.get(str(sample))
            if identity is None:
                errors.append(f'prediction_{i}_sample_identity_unexpected')
            else:
                for field, expected_field in (('sample_id', 'sample_id'), ('timestamp_utc', 'timestamp_utc'),
                                              ('row_identity_sha256', 'row_identity_sha256')):
                    if row.get(field) != identity.get(expected_field):
                        errors.append(f'prediction_{i}_{field}_mismatch')
        key = (row.get('model'), fold, sample)
        if key in seen:
            errors.append(f'duplicate_prediction:{key}')
        seen.add(key); folds.add(fold); samples.add(sample)
        for field in ('y_true', 'y_pred', 'p_down', 'p_neutral', 'p_up'):
            if field not in row:
                errors.append(f'prediction_{i}_missing_{field}')
        try:
            probs = [float(row[k]) for k in ('p_down', 'p_neutral', 'p_up')]
            if any(not (0.0 <= p <= 1.0) for p in probs) or abs(sum(probs)-1.0) > 1e-5:
                errors.append(f'prediction_{i}_invalid_probabilities')
        except (TypeError, ValueError, KeyError):
            errors.append(f'prediction_{i}_invalid_probabilities')
    fold_report_keys = set()
    for i, row in enumerate(fold_reports):
        if not isinstance(row, dict) or 'fold' not in row or 'model' not in row:
            errors.append(f'fold_report_{i}_invalid'); continue
        key = (row['model'], int(row['fold']))
        if key in fold_report_keys:
            errors.append(f'duplicate_fold_report:{key}')
        fold_report_keys.add(key)
        if model_name is not None and row['model'] != model_name:
            errors.append(f'fold_report_{i}_model_mismatch')
        # Trainer fold reports carry validation_n; enforce exact prediction coverage.
        if 'validation_n' in row:
            actual_n = sum(1 for pred in predictions
                           if isinstance(pred, dict) and pred.get('model') == row['model']
                           and str(pred.get('fold')) == str(row['fold']))
            try:
                expected_n = int(row['validation_n'])
                if expected_n < 0 or actual_n != expected_n:
                    errors.append(f'fold_prediction_coverage_mismatch:{row["model"]}:{row["fold"]}:expected={expected_n}:actual={actual_n}')
            except (TypeError, ValueError):
                errors.append(f'fold_report_{i}_invalid_validation_n')
    if expected_fold_ids is not None:
        expected = {int(x) for x in expected_fold_ids}
        if folds != expected:
            errors.append(f'fold_coverage_mismatch:expected={sorted(expected)}:actual={sorted(folds)}')
    if expected_sample_indices is not None:
        expected = {int(x) for x in expected_sample_indices}
        if samples != expected:
            errors.append(f'sample_coverage_mismatch:missing={sorted(expected-samples)}:unexpected={sorted(samples-expected)}')
    if expected_fold_sample_indices is not None:
        for expected_fold, expected_values in expected_fold_sample_indices.items():
            fid = int(expected_fold)
            expected_set = {int(x) for x in expected_values}
            actual_set = {int(row['sample_index']) for row in predictions
                          if isinstance(row, dict) and str(row.get('fold')) == str(expected_fold)
                          and 'sample_index' in row}
            if actual_set != expected_set:
                errors.append(f'fold_sample_coverage_mismatch:{fid}:missing={sorted(expected_set-actual_set)}:unexpected={sorted(actual_set-expected_set)}')
        unexpected_folds = folds - {int(x) for x in expected_fold_sample_indices}
        if unexpected_folds:
            errors.append(f'unexpected_fold_ids:{sorted(unexpected_folds)}')
    if model_name is not None:
        for fold in folds:
            if (model_name, fold) not in fold_report_keys:
                errors.append(f'missing_fold_report:{model_name}:{fold}')
    result = {'status': 'PASS' if not errors else 'BLOCKED', 'model_name': model_name,
              'prediction_count': len(predictions), 'fold_ids': sorted(folds),
              'sample_count': len(samples), 'fold_report_count': len(fold_reports),
              'errors': errors, 'oof_sha256': _sha(oof_report)}
    result['audit_sha256'] = _sha(result)
    if errors:
        raise ValueError('oof_audit_blocked:' + '|'.join(errors))
    return result


def replay_oof_audit(run_id: str, *, registry_dir: str, expected_fold_ids: list[int] | None = None,
                     expected_sample_indices: list[int] | None = None,
                     expected_fold_sample_indices: dict | None = None,
                     expected_sample_identities: dict | None = None) -> dict:
    """Reload stored run, verify registry hashes, then re-audit persisted OOF; never fits a model."""
    from backend.btc_training_registry import load_training_run
    record = load_training_run(run_id, registry_dir=registry_dir)
    audit = audit_oof_report(record['oof_report'], model_name=record['model_name'],
                             expected_fold_ids=expected_fold_ids,
                             expected_sample_indices=expected_sample_indices)
    return {'run_id': str(run_id), 'record_sha256': record['record_sha256'],
            'dataset_hash': record['artifact'].get('dataset_hash'),
            'lineage_sha256': record['lineage']['lineage_sha256'],
            'oof_sha256': record['oof']['sha256'], 'audit': audit,
            'replay_mode': 'OFFLINE_AUDIT_ONLY_NO_RETRAINING'}


def compare_oof_reports(left: dict, right: dict) -> dict:
    """Compare two persisted OOF payloads; exact content match is deterministic replay equivalence."""
    left_hash, right_hash = _sha(left), _sha(right)
    left_rows, right_rows = left.get('predictions', []), right.get('predictions', [])
    def keyed(rows):
        out = {}
        for row in rows:
            if not isinstance(row, dict):
                raise ValueError('oof_comparison_invalid_prediction')
            key = (row.get('model'), int(row.get('fold', -1)), int(row.get('sample_index', -1)))
            if key in out:
                raise ValueError(f'oof_comparison_duplicate_key:{key}')
            out[key] = row
        return out
    a, b = keyed(left_rows), keyed(right_rows)
    keys_a, keys_b = set(a), set(b)
    changed = sorted([k for k in keys_a & keys_b if _canonical(a[k]) != _canonical(b[k])], key=str)
    return {'status': 'IDENTICAL' if left_hash == right_hash else 'DIFFERENT',
            'left_sha256': left_hash, 'right_sha256': right_hash,
            'left_rows': len(left_rows), 'right_rows': len(right_rows),
            'missing_from_right': [list(k) for k in sorted(keys_a-keys_b, key=str)],
            'missing_from_left': [list(k) for k in sorted(keys_b-keys_a, key=str)],
            'changed_keys': [list(k) for k in changed],
            'replay_equivalent': left_hash == right_hash}
