"""V23.0.77 evidence fusion. Read-only aggregation; scores are advisory, not orders."""
from __future__ import annotations
import math

_WEIGHTS = {
    'technical': 0.22,
    'smart_money_flow': 0.18,
    'liquidity': 0.14,
    'market_trap': 0.14,
    'absorption': 0.10,
    'opportunity': 0.14,
    'market_context': 0.08,
}

def _derived_directional_sources(raw):
    """Translate optional V136-V138 detector outputs into advisory sources.

    Inputs are already-computed detector result objects under `market_signals`;
    this function does not fetch data or infer missing evidence.
    """
    signals = raw.get('market_signals') if isinstance(raw.get('market_signals'), dict) else {}
    derived = {}
    trap = signals.get('trap') if isinstance(signals.get('trap'), dict) else {}
    trap_type = str(trap.get('trap_type') or '').upper()
    if trap_type in ('BEAR_TRAP_CANDIDATE', 'BULL_TRAP_CANDIDATE'):
        direction = 'BULLISH' if trap_type == 'BEAR_TRAP_CANDIDATE' else 'BEARISH'
        score = _number(trap.get('score'))
        score = max(50.0, min(90.0, score if score is not None else 50.0))
        derived['market_trap'] = {'score': score, 'direction': direction,
            'confidence': 0.75 if trap.get('confirmed_by_follow_through') else 0.55,
            'status': 'CONFIRMED_FOLLOW_THROUGH' if trap.get('confirmed_by_follow_through') else 'CANDIDATE'}

    sweep = signals.get('liquidity_sweep') if isinstance(signals.get('liquidity_sweep'), dict) else {}
    sweep_type = str(sweep.get('sweep_type') or '').upper()
    if sweep_type in ('SELL_SIDE', 'BUY_SIDE'):
        direction = 'BULLISH' if sweep_type == 'SELL_SIDE' else 'BEARISH'
        confirmed = 'CONFIRMED' in str(sweep.get('decision') or '').upper()
        score = max(50.0, min(95.0, _number(sweep.get('score')) or 50.0))
        derived['liquidity'] = {'score': score, 'direction': direction,
            'confidence': 0.78 if confirmed else 0.52,
            'status': 'CONFIRMED_SWEEP' if confirmed else 'SWEEP_CANDIDATE'}

    absorption = signals.get('absorption') if isinstance(signals.get('absorption'), dict) else {}
    context = str(absorption.get('context') or '').upper()
    decision = str(absorption.get('decision') or '').upper()
    if context in ('POTENTIALLY_BULLISH', 'POTENTIALLY_BEARISH'):
        direction = 'BULLISH' if context == 'POTENTIALLY_BULLISH' else 'BEARISH'
        derived['absorption'] = {'score': 68.0, 'direction': direction,
            'confidence': 0.58 if 'PERSISTENT' in decision else 0.45,
            'status': decision or 'ABSORPTION_CANDIDATE'}
    return derived
_POS = {'BUY', 'BULLISH', 'LONG', 'BUY_PRESSURE', 'BULLISH_BIAS', 'UP'}
_NEG = {'SELL', 'BEARISH', 'SHORT', 'SELL_PRESSURE', 'BEARISH_BIAS', 'DOWN'}


def _number(value):
    if isinstance(value, bool) or value is None:
        return None
    try:
        n = float(value)
        return n if math.isfinite(n) else None
    except (TypeError, ValueError, OverflowError):
        return None


def _source(item):
    if not isinstance(item, dict):
        return None
    score = _number(item.get('score'))
    if score is None or not 0 <= score <= 100:
        return None
    direction = str(item.get('direction') or item.get('bias') or item.get('flow_direction') or '').upper().strip()
    if direction in _POS:
        direction = 'BULLISH'
    elif direction in _NEG:
        direction = 'BEARISH'
    elif direction in ('NEUTRAL', 'MIXED', 'NEUTRAL_OR_MIXED'):
        direction = 'NEUTRAL'
    else:
        direction = 'UNKNOWN'
    confidence = _number(item.get('confidence'))
    if confidence is None:
        confidence = 0.65
    if not 0 <= confidence <= 1:
        return None
    return {'score': score, 'direction': direction, 'confidence': confidence,
            'status': str(item.get('status') or item.get('decision') or 'AVAILABLE')[:48]}


def analyze_master_market_intelligence(candidates):
    if not isinstance(candidates, list):
        raise ValueError('candidates must be a list')
    results = []
    for raw in candidates[:100]:
        if not isinstance(raw, dict):
            results.append({'symbol': '', 'decision': 'INSUFFICIENT_DATA', 'score': 0,
                            'reasons': ['INVALID_CANDIDATE'], 'entry_authorized': False})
            continue
        symbol = str(raw.get('symbol') or '').upper().strip()[:30]
        supplied = raw.get('evidence') if isinstance(raw.get('evidence'), dict) else {}
        # Optional detector outputs are fused alongside, never instead of, supplied evidence.
        supplied = {**supplied, **_derived_directional_sources(raw)}
        accepted, rejected = {}, []
        for key in _WEIGHTS:
            parsed = _source(supplied.get(key))
            if parsed:
                accepted[key] = parsed
            elif key in supplied:
                rejected.append(key)
        if not accepted:
            results.append({'symbol': symbol, 'decision': 'INSUFFICIENT_DATA', 'score': 0,
                            'coverage_pct': 0, 'evidence': {}, 'reasons': ['NO_VALID_EVIDENCE'],
                            'rejected_sources': rejected, 'entry_authorized': False})
            continue
        weight_sum = sum(_WEIGHTS[k] for k in accepted)
        raw_score = sum(_WEIGHTS[k] * v['score'] * v['confidence'] for k, v in accepted.items()) / sum(_WEIGHTS[k] * v['confidence'] for k, v in accepted.items())
        dirs = [v['direction'] for v in accepted.values() if v['direction'] in ('BULLISH', 'BEARISH')]
        bulls, bears = dirs.count('BULLISH'), dirs.count('BEARISH')
        conflict_ratio = min(bulls, bears) / max(1, len(dirs))
        score = max(0, min(100, round(raw_score - conflict_ratio * 25, 2)))
        coverage = round(weight_sum * 100, 1)
        if len(accepted) < 2 or coverage < 30:
            decision = 'INSUFFICIENT_EVIDENCE'
        elif conflict_ratio >= .4:
            decision = 'CONFLICTING_EVIDENCE'
        elif score >= 75 and coverage >= 65:
            decision = 'HIGH_CONVICTION_WATCH'
        elif score >= 55:
            decision = 'WATCH'
        else:
            decision = 'LOW_CONVICTION'
        direction = 'BULLISH' if bulls > bears else 'BEARISH' if bears > bulls else 'NEUTRAL'
        reasons = [f'SOURCE_{k.upper()}_INCLUDED' for k in accepted]
        if conflict_ratio:
            reasons.append('DIRECTIONAL_CONFLICT_PENALTY_APPLIED')
        if rejected:
            reasons.append('INVALID_SOURCE_EVIDENCE_IGNORED')
        results.append({'symbol': symbol, 'decision': decision, 'score': score,
                        'direction': direction, 'coverage_pct': coverage,
                        'conflict_ratio': round(conflict_ratio, 3),
                        'evidence': accepted, 'rejected_sources': rejected,
                        'reasons': reasons, 'entry_authorized': False,
                        'execution_authorized': False})
    return {'version': '23.0.139', 'count': len(results), 'results': results,
            'integration': 'V136_TRAPS_V137_LIQUIDITY_SWEEPS_V138_ABSORPTION',
            'source_weights': _WEIGHTS, 'paper_only': True, 'capital_usdt': 1000,
            'real_orders_enabled': False, 'creates_orders': False,
            'entry_authorized': False, 'execution_authorized': False,
            'disclaimer': 'امتیاز، ترکیب شواهد ورودی است و سیگنال قطعی یا تضمین سود نیست؛ منابع غایب یا نامعتبر حذف می‌شوند.'}
