"""FinRL-compatible crypto DRL engine for Trading Signal AI Pro V14.

Uses the Stable-Baselines3 algorithms used by FinRL (A2C/DDPG/PPO/TD3/SAC)
with a crypto-specific, cost-aware Gymnasium environment. No live orders are sent.
"""
from __future__ import annotations

import json
import os
import re
import math
import threading
import time
import traceback
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

try:
    import gymnasium as _gymnasium
    _GymEnv = _gymnasium.Env
except ImportError:
    _gymnasium = None
    _GymEnv = object

ROOT = Path(__file__).resolve().parents[1]
RL_DIR = Path(os.getenv('TRADING_AI_RL_DIR', str(Path.home() / '.trading_ai_models' / 'rl'))).expanduser()
RL_DIR.mkdir(parents=True, exist_ok=True)
ALGORITHMS = ('A2C', 'DDPG', 'PPO', 'TD3', 'SAC')
_LOCK = threading.RLock()
_STOP = threading.Event()
_JOB: dict[str, Any] = {'running': False, 'stage': 'idle', 'progress': 0, 'log': [], 'result': None, 'error': None}


def _log(message: str):
    with _LOCK:
        _JOB['log'] = (_JOB.get('log') or [])[-199:] + [f"{time.strftime('%H:%M:%S')} | {message}"]


def status() -> dict:
    with _LOCK:
        return {**_JOB, 'log': list(_JOB.get('log') or [])}


def request_stop():
    _STOP.set()
    return True


def _features(candles: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Causal, scale-stable state features; only past/current OHLCV is used."""
    d = candles.copy().reset_index(drop=True)
    close = pd.to_numeric(d.close, errors='coerce').astype(float)
    high = pd.to_numeric(d.high, errors='coerce').astype(float)
    low = pd.to_numeric(d.low, errors='coerce').astype(float)
    open_ = pd.to_numeric(d.open, errors='coerce').astype(float)
    volume = pd.to_numeric(d.volume, errors='coerce').astype(float)
    raw = np.column_stack([open_.to_numpy(), high.to_numpy(), low.to_numpy(),
                           close.to_numpy(), volume.to_numpy()])
    if (not np.isfinite(raw).all() or (close <= 0).any() or (open_ <= 0).any()
            or (high < np.maximum(open_, close)).any()
            or (low > np.minimum(open_, close)).any() or (volume < 0).any()):
        raise ValueError('داده OHLCV برای آموزش DRL نامعتبر یا دارای مقدار غیرمتناهی است')
    if 't' in d.columns:
        timestamps = pd.to_numeric(d['t'], errors='coerce').to_numpy(dtype=float)
        if (not np.isfinite(timestamps).all() or pd.Series(timestamps).duplicated().any()
                or (np.diff(timestamps) < 0).any()):
            raise ValueError('ترتیب زمانی کندل‌ها برای آموزش DRL نامعتبر است')
    ret = close.pct_change().replace([np.inf, -np.inf], np.nan)
    ema_fast = close.ewm(span=12, adjust=False).mean()
    ema_slow = close.ewm(span=26, adjust=False).mean()
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    rsi = 100 - 100 / (1 + gain / loss.replace(0, np.nan))
    tr = pd.concat([high-low, (high-close.shift()).abs(), (low-close.shift()).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1/14, adjust=False).mean()
    vol_mean = volume.rolling(30, min_periods=5).mean()
    vol_std = volume.rolling(30, min_periods=5).std()
    vol_z = ((volume-vol_mean)/(vol_std+1e-9)).clip(-5, 5)
    vol_20 = ret.rolling(20, min_periods=5).std()
    feats = pd.DataFrame({
        'ret1': ret.clip(-.2,.2),
        'ret3': close.pct_change(3).clip(-.4,.4),
        'ret12': close.pct_change(12).clip(-.6,.6),
        'ema_gap': ((ema_fast/ema_slow)-1).clip(-.5,.5),
        'price_ema': ((close/ema_fast)-1).clip(-.5,.5),
        'rsi': (rsi.fillna(50)-50)/50,
        'atr_pct': (atr/close).clip(0,.3),
        'volatility': vol_20.clip(0,.3),
        'volume_z': vol_z.fillna(0)/5,
        'candle_body': ((close-pd.to_numeric(d.open))/(high-low+1e-9)).clip(-1,1),
        'range_pct': ((high-low)/close).clip(0,.3),
    }).replace([np.inf,-np.inf],np.nan).fillna(0).astype('float32')
    # Next-bar close-to-close return is the reward target; not part of observation.
    next_ret = ret.shift(-1).fillna(0).to_numpy(dtype=np.float32)
    prices = close.to_numpy(dtype=np.float64)
    return feats.to_numpy(dtype=np.float32), next_ret, prices


class CryptoTradingEnv(_GymEnv):
    """Gymnasium-compatible single-asset target-position environment."""
    metadata = {'render_modes': []}

    def __init__(self, observations: np.ndarray, next_returns: np.ndarray,
                 fee_bps: float = 10.0, slippage_bps: float = 5.0,
                 drawdown_penalty: float = 0.02):
        if _gymnasium is None:
            raise RuntimeError('برای آموزش DRL، بسته gymnasium نصب نیست. install.bat را دوباره اجرا کنید.')
        from gymnasium import spaces
        super().__init__()
        self.observations = np.asarray(observations, dtype=np.float32)
        self.next_returns = np.asarray(next_returns, dtype=np.float32)
        if len(self.observations) < 20 or len(self.observations) != len(self.next_returns):
            raise ValueError('داده کافی یا هم‌ترازی ویژگی/بازده برای محیط DRL وجود ندارد')
        self.fee_rate = max(0, float(fee_bps)) / 10000
        self.slippage_rate = max(0, float(slippage_bps)) / 10000
        self.dd_penalty = max(0, float(drawdown_penalty))
        self.action_space = spaces.Box(low=np.array([-1.],dtype=np.float32), high=np.array([1.],dtype=np.float32), dtype=np.float32)
        self.observation_space = spaces.Box(low=-10, high=10, shape=(self.observations.shape[1]+2,), dtype=np.float32)
        self.reset()

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        if seed is not None:
            np.random.seed(seed)
        self.i = 0
        self.position = 0.0
        self.equity = 1.0
        self.peak = 1.0
        self.done = False
        return self._obs(), {}

    def _obs(self):
        dd = self.equity / max(self.peak, 1e-9) - 1
        return np.concatenate([self.observations[self.i], np.array([self.position, dd], dtype=np.float32)]).astype(np.float32)

    def step(self, action):
        target = float(np.clip(np.asarray(action).reshape(-1)[0], -1, 1))
        turnover = abs(target - self.position)
        cost = turnover * (self.fee_rate + self.slippage_rate)
        market_ret = float(np.clip(self.next_returns[self.i], -.5, .5))
        gross = target * market_ret
        net = gross - cost
        self.equity *= max(0.01, 1.0 + net)
        self.peak = max(self.peak, self.equity)
        dd = self.equity / max(self.peak, 1e-9) - 1
        reward = float(np.clip(np.log(max(1e-8, 1+net)) + self.dd_penalty * min(0.0, dd), -1, 1))
        self.position = target
        self.i += 1
        terminated = self.i >= len(self.observations)-1
        truncated = False
        self.done = terminated
        if not terminated:
            obs = self._obs()
        else:
            obs = np.zeros(self.observation_space.shape, dtype=np.float32)
        info = {'equity': self.equity, 'net_return': net, 'turnover': turnover, 'drawdown': dd, 'cost': cost}
        return obs, reward, terminated, truncated, info


def _evaluate(model, obs: np.ndarray, next_ret: np.ndarray, fee_bps: float, slip_bps: float) -> dict:
    fee = fee_bps / 10000; slip = slip_bps / 10000
    position = 0.; equity = 1.; peak = 1.; max_dd = 0.; trades = 0; wins = 0; total_cost = 0.
    for i in range(len(obs)-1):
        action, _ = model.predict(np.concatenate([obs[i], np.array([position, equity/peak-1],dtype=np.float32)]), deterministic=True)
        target = float(np.clip(np.asarray(action).reshape(-1)[0],-1,1))
        turnover = abs(target-position); cost = turnover*(fee+slip)
        r = float(np.clip(next_ret[i],-.5,.5)); net = target*r-cost
        if turnover > .05:
            trades += 1
            if net > 0: wins += 1
        equity *= max(.01,1+net); peak=max(peak,equity); dd=equity/peak-1
        max_dd=min(max_dd,dd); total_cost += cost; position=target
    return {'net_return_pct': (equity-1)*100, 'max_drawdown_pct': max_dd*100,
            'trade_events': trades, 'profitable_events': wins,
            'event_win_rate': wins/trades if trades else None,
            'total_cost_pct': total_cost*100, 'final_equity': equity}


def _algorithm_class(name: str):
    from stable_baselines3 import A2C, DDPG, PPO, SAC, TD3
    return {'A2C': A2C, 'DDPG': DDPG, 'PPO': PPO, 'SAC': SAC, 'TD3': TD3}[name]


def _train_worker(symbol: str, timeframe: str, candles: pd.DataFrame, algorithms: list[str],
                  timesteps: int, fee_bps: float, slippage_bps: float):
    try:
        import gymnasium  # noqa: F401
        import stable_baselines3  # noqa: F401
    except ImportError as exc:
        raise RuntimeError('وابستگی DRL نصب نیست. در محیط پروژه اجرا کنید: pip install "stable-baselines3[extra]>=2.3" "gymnasium>=0.29"') from exc
    from stable_baselines3.common.monitor import Monitor
    from stable_baselines3.common.callbacks import BaseCallback
    try:
        from finrl.agents.stablebaselines3.models import DRLAgent
    except ImportError as exc:
        raise RuntimeError('FinRL نصب نیست یا با محیط Python سازگار نیست؛ install_rl.bat را اجرا کنید.') from exc

    class StopOnRequest(BaseCallback):
        def _on_step(self) -> bool:
            return not _STOP.is_set()

    x, y, _ = _features(candles)
    n = len(x)
    if n < 600:
        raise ValueError(f'برای آموزش DRL حداقل ۶۰۰ کندل لازم است؛ اکنون {n} موجود است')
    # Strict chronological partitions: no shuffling and no validation/test leakage.
    a, b = int(n*.70), int(n*.85)
    x_train, y_train = x[:a], y[:a]
    x_val, y_val = x[a:b], y[a:b]
    x_test, y_test = x[b:], y[b:]
    if min(len(x_train),len(x_val),len(x_test)) < 30:
        raise ValueError('اندازه بخش‌های train/validation/test کافی نیست')

    results = {}
    best_name = None; best_score = -float('inf')
    total = len(algorithms)
    for idx, name in enumerate(algorithms):
        if _STOP.is_set():
            _log('درخواست توقف دریافت شد؛ آموزش بعدی آغاز نمی‌شود.')
            break
        _log(f'شروع آموزش {name} ({idx+1}/{total}) با {timesteps:,} گام')
        env = Monitor(CryptoTradingEnv(x_train, y_train, fee_bps, slippage_bps))
        # Use FinRL's official DRLAgent adapter; the environment is our crypto-specific Gymnasium env.
        agent = DRLAgent(env)
        model = agent.get_model(name.lower(), model_kwargs={}, seed=42, verbose=0)
        model.learn(total_timesteps=int(timesteps), progress_bar=False, callback=StopOnRequest())
        if _STOP.is_set():
            _log(f'آموزش {name} با درخواست توقف متوقف شد؛ نتیجه ناقص برای انتخاب ذخیره نمی‌شود.')
            break
        model_path = RL_DIR / f'{symbol}_{timeframe}_{name}'
        val = _evaluate(model, x_val, y_val, fee_bps, slippage_bps)
        test = _evaluate(model, x_test, y_test, fee_bps, slippage_bps)
        model.save(str(model_path))
        # Eligibility is determined on validation only; test is reported once and never used to select.
        eligible = (val['trade_events'] >= 10 and val['net_return_pct'] > 0
                    and val['max_drawdown_pct'] > -35)
        results[name] = {'validation': val, 'test': test, 'deployment_eligible': bool(eligible),
                         'model_file': model_path.name}
        score = val['net_return_pct'] + 0.35 * val['max_drawdown_pct']
        if eligible and score > best_score:
            best_score = score; best_name = name
        _log(f'{name}: بازده اعتبارسنجی {val["net_return_pct"]:.2f}%، افت {val["max_drawdown_pct"]:.2f}%، تست {test["net_return_pct"]:.2f}%')
        with _LOCK:
            _JOB['progress'] = int((idx+1)/total*100)
    result = {'symbol':symbol,'timeframe':timeframe,'algorithms':results,
              'selected_algorithm':best_name,
              'fees_bps':fee_bps,'slippage_bps':slippage_bps,
              'split':{'train':len(x_train),'validation':len(x_val),'test':len(x_test)},
              'selection_basis':'validation_only',
              'note':'بازده تست فقط گزارش شده و در انتخاب مدل دخالت ندارد؛ نتایج گذشته تضمین آینده نیست.'}
    # Keep the last run report separate from the active policy pointer. A run
    # with no validation-qualified agent must never disable a previously good one.
    report_path = RL_DIR / f'{symbol}_{timeframe}_last_run.json'
    report_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    if best_name:
        active_path = RL_DIR / f'{symbol}_{timeframe}_active.json'
        active_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        result['active_policy_updated'] = True
    else:
        result['active_policy_updated'] = False
        result['active_policy_message'] = 'هیچ عامل جدیدی معیارهای اعتبارسنجی را نگذراند؛ سیاست فعال قبلی (در صورت وجود) حفظ شد.'
        report_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    return result


def start_training(symbol: str, timeframe: str, candles: pd.DataFrame,
                   algorithms: list[str] | None = None, timesteps: int = 100_000,
                   fee_bps: float = 10.0, slippage_bps: float = 5.0):
    symbol = str(symbol).upper().strip()
    timeframe = str(timeframe).strip()
    if not re.fullmatch(r'[A-Z0-9]{3,20}USDT', symbol):
        raise ValueError('موتور DRL فعلاً فقط نمادهای رمزارزی با پسوند USDT را می‌پذیرد')
    if timeframe not in ('5m', '15m', '30m', '1h', '4h', '1d'):
        raise ValueError('تایم‌فریم DRL نامعتبر است')
    algorithms = list(dict.fromkeys(str(x).upper() for x in (algorithms or ALGORITHMS)))
    if not algorithms or any(x not in ALGORITHMS for x in algorithms):
        raise ValueError('الگوریتم نامعتبر است؛ فقط A2C/DDPG/PPO/TD3/SAC مجازند')
    if not 10_000 <= int(timesteps) <= 5_000_000:
        raise ValueError('تعداد گام آموزش باید بین ۱۰هزار تا ۵میلیون باشد')
    if (not math.isfinite(float(fee_bps)) or not math.isfinite(float(slippage_bps))
            or not 0 <= float(fee_bps) <= 500 or not 0 <= float(slippage_bps) <= 500):
        raise ValueError('کارمزد و لغزش باید اعداد معتبر بین صفر تا ۵۰۰ واحد پایه باشند')
    if not isinstance(candles, pd.DataFrame) or len(candles) < 600:
        raise ValueError('برای آموزش DRL حداقل ۶۰۰ کندل معتبر لازم است')
    with _LOCK:
        if _JOB.get('running'):
            return False
        _STOP.clear()
        _JOB.update({'running':True,'stage':'training','progress':0,'log':[],'result':None,'error':None})
    def run():
        try:
            result = _train_worker(symbol.upper(),timeframe,candles,algorithms,int(timesteps),float(fee_bps),float(slippage_bps))
            with _LOCK:
                _JOB.update({'running':False,'stage':'complete','progress':100,'result':result})
            _log('آموزش تمام شد؛ گزارش اعتبارسنجی و تست ذخیره شد.')
        except Exception as exc:
            with _LOCK:
                _JOB.update({'running':False,'stage':'error','error':str(exc)})
            _log('خطا: '+str(exc)); _log(traceback.format_exc()[-5000:])
    threading.Thread(target=run,daemon=True,name='v14-rl-trainer').start()
    return True


def load_active(symbol: str, timeframe: str):
    meta_path = RL_DIR / f'{symbol.upper()}_{timeframe}_active.json'
    if not meta_path.exists(): return None
    try:
        meta=json.loads(meta_path.read_text(encoding='utf-8'))
        name=meta.get('selected_algorithm')
        if not name: return None
        model_file=RL_DIR/f'{symbol.upper()}_{timeframe}_{name}.zip'
        if not model_file.exists(): return None
        cls=_algorithm_class(name)
        model=cls.load(str(model_file),device='auto')
        return model,meta,name
    except Exception:
        return None


def predict_position(symbol: str, timeframe: str, candles: pd.DataFrame):
    loaded=load_active(symbol,timeframe)
    if not loaded: return None
    model,meta,name=loaded
    x,_,_= _features(candles)
    if len(x)<1: return None
    # Position is estimated from the latest policy action; drawdown memory starts flat.
    action,_=model.predict(np.concatenate([x[-1],np.array([0.,0.],dtype=np.float32)]),deterministic=True)
    pos=float(np.clip(np.asarray(action).reshape(-1)[0],-1,1))
    return {'algorithm':name,'target_position':pos,
            'direction':'BUY' if pos>0.15 else 'SELL' if pos<-.15 else 'HOLD',
            'validation':meta.get('algorithms',{}).get(name,{}).get('validation'),
            'test':meta.get('algorithms',{}).get(name,{}).get('test'),
            'deployment_eligible':True}
