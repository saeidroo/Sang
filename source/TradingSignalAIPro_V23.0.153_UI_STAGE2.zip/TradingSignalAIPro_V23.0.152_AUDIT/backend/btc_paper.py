"""Deterministic, offline BTC 4h paper execution ledger (never sends live orders)."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = 'btc-4h-paper-ledger-v1'


def run_btc_4h_paper_simulation(candles, signals, *, initial_cash=10_000.0,
        position_fraction=0.10, horizon_bars=6, fee_bps=5.0,
        slippage_bps=3.0, spread_bps=2.0, ledger_path=None,
        stop_loss_pct=None, take_profit_pct=None, max_daily_loss_pct=None,
        max_drawdown_pct=None, emergency_stop=False, min_bars_between_entries=0,
        bars_per_day=6):
    """Simulate next-open entries and fixed-horizon next-open exits.

    `signals` requires signal_pos (original candle row) and direction (-1/0/+1).
    Signal is assumed known only after that candle closes. Each signal_id is
    idempotent within the input batch. No exchange/network/order API is called.
    """
    c = pd.DataFrame(candles).reset_index(drop=True)
    s = pd.DataFrame(signals).copy().reset_index(drop=True)
    required = {'open', 'high', 'low', 'close'}
    if not required.issubset(c.columns):
        raise ValueError('candles require open/high/low/close')
    if not {'signal_pos', 'direction'}.issubset(s.columns):
        raise ValueError('signals require signal_pos and direction')
    numeric = c[list(required)].to_numpy(dtype=float)
    if len(c) < 3 or not np.isfinite(numeric).all() or (numeric <= 0).any():
        raise ValueError('candles must contain finite positive OHLC prices')
    if not np.isfinite([initial_cash, position_fraction, fee_bps, slippage_bps, spread_bps]).all():
        raise ValueError('non-finite execution configuration')
    if initial_cash <= 0 or not 0 < position_fraction <= 1 or horizon_bars < 1:
        raise ValueError('invalid cash, position_fraction, or horizon_bars')
    if min(fee_bps, slippage_bps, spread_bps) < 0:
        raise ValueError('execution costs must be non-negative')
    for name, value in [('stop_loss_pct', stop_loss_pct), ('take_profit_pct', take_profit_pct),
                        ('max_daily_loss_pct', max_daily_loss_pct), ('max_drawdown_pct', max_drawdown_pct)]:
        if value is not None and (not np.isfinite(value) or not 0 < value < 1):
            raise ValueError(f'{name} must be between 0 and 1')
    if min_bars_between_entries < 0 or bars_per_day < 1:
        raise ValueError('invalid cooldown or bars_per_day')
    if s['signal_pos'].duplicated().any():
        # Multiple decisions on one close are ambiguous and can cause double entry.
        raise ValueError('duplicate signal_pos values are not allowed')
    if not s['direction'].isin([-1, 0, 1]).all():
        raise ValueError('direction must be -1, 0, or 1')
    if (s['signal_pos'] < 0).any() or (s['signal_pos'] >= len(c)).any():
        raise ValueError('signal_pos outside candle range')
    s = s.sort_values('signal_pos', kind='stable')

    cash = float(initial_cash)
    peak = cash
    max_dd = 0.0
    trades, events, equity_curve = [], [], [{'event_pos': -1, 'equity': cash}]
    used_ids, last_exit_pos, last_entry_pos = set(), -1, -10**12
    day_start_equity, halted_days = {}, set()
    risk_halted = False
    skipped = {'flat': 0, 'duplicate_id': 0, 'overlap': 0, 'no_future': 0,
               'daily_loss_limit': 0, 'drawdown_limit': 0, 'cooldown': 0, 'emergency_stop': 0}
    def day_key(bar_pos):
        if 'timestamp' in c.columns:
            return str(pd.Timestamp(c.iloc[bar_pos]['timestamp']).date())
        return f'day:{bar_pos // int(bars_per_day)}'
    for row in s.to_dict('records'):
        pos, direction = int(row['signal_pos']), int(row['direction'])
        sid = str(row.get('signal_id') or f'btc4h:{pos}:{direction}')
        if sid in used_ids:
            skipped['duplicate_id'] += 1
            continue
        used_ids.add(sid)
        if direction == 0:
            skipped['flat'] += 1
            continue
        if emergency_stop:
            skipped['emergency_stop'] += 1
            continue
        if risk_halted:
            skipped['drawdown_limit'] += 1
            continue
        dkey = day_key(pos)
        day_start_equity.setdefault(dkey, cash)
        if dkey in halted_days:
            skipped['daily_loss_limit'] += 1
            continue
        if (pos - last_entry_pos) < int(min_bars_between_entries):
            skipped['cooldown'] += 1
            continue
        entry_pos, exit_pos = pos + 1, pos + int(horizon_bars) + 1
        if exit_pos >= len(c):
            skipped['no_future'] += 1
            continue
        if entry_pos <= last_exit_pos:
            skipped['overlap'] += 1
            continue
        entry_ref, exit_ref = float(c.iloc[entry_pos]['open']), float(c.iloc[exit_pos]['open'])
        # Adverse execution on both sides; spread is split across entry/exit.
        half_cost = (float(fee_bps) + float(slippage_bps) + float(spread_bps) / 2.0) / 10000.0
        entry_fill = entry_ref * (1.0 + direction * half_cost)
        exit_reason, actual_exit_pos = 'HORIZON', exit_pos
        # Conservative OHLC barrier scan: if stop and target are both touched in
        # one candle, assume the stop was hit first. No intrabar path is invented.
        for scan_pos in range(entry_pos, exit_pos + 1):
            bar = c.iloc[scan_pos]
            stop_level = (entry_fill * (1.0 - float(stop_loss_pct)) if direction == 1 else
                          entry_fill * (1.0 + float(stop_loss_pct))) if stop_loss_pct is not None else None
            target_level = (entry_fill * (1.0 + float(take_profit_pct)) if direction == 1 else
                            entry_fill * (1.0 - float(take_profit_pct))) if take_profit_pct is not None else None
            stop_hit = stop_level is not None and (float(bar['low']) <= stop_level if direction == 1 else float(bar['high']) >= stop_level)
            target_hit = target_level is not None and (float(bar['high']) >= target_level if direction == 1 else float(bar['low']) <= target_level)
            if stop_hit:
                exit_ref, exit_reason, actual_exit_pos = float(stop_level), 'STOP_LOSS', scan_pos
                break
            if target_hit:
                exit_ref, exit_reason, actual_exit_pos = float(target_level), 'TAKE_PROFIT', scan_pos
                break
        exit_fill = exit_ref * (1.0 - direction * half_cost)
        notional = cash * float(position_fraction)
        quantity = notional / entry_fill
        gross_pnl = direction * quantity * (exit_ref - entry_ref)
        entry_cost = quantity * abs(entry_fill - entry_ref)
        exit_cost = quantity * abs(exit_fill - exit_ref)
        net_pnl = direction * quantity * (exit_fill - entry_fill)
        cash += net_pnl
        peak = max(peak, cash)
        drawdown = (cash / peak) - 1.0 if peak else 0.0
        max_dd = min(max_dd, drawdown)
        trade = {'signal_id': sid, 'signal_pos': pos, 'entry_pos': entry_pos,
            'exit_pos': actual_exit_pos, 'direction': direction, 'entry_reference': entry_ref,
            'entry_fill': entry_fill, 'exit_reference': exit_ref, 'exit_fill': exit_fill,
            'exit_reason': exit_reason,
            'quantity': quantity, 'notional': notional, 'gross_pnl': gross_pnl,
            'entry_cost_estimate': entry_cost, 'exit_cost_estimate': exit_cost,
            'net_pnl': net_pnl, 'return_on_allocated_notional': net_pnl / notional,
            'cash_after': cash, 'drawdown': drawdown}
        trades.append(trade)
        events.extend([
            {'event_id': sid + ':entry', 'signal_id': sid, 'type': 'PAPER_ENTRY',
             'bar_pos': entry_pos, 'direction': direction, 'reference_price': entry_ref,
             'fill_price': entry_fill, 'quantity': quantity, 'notional': notional},
            {'event_id': sid + ':exit', 'signal_id': sid, 'type': 'PAPER_EXIT',
             'bar_pos': actual_exit_pos, 'direction': direction, 'reference_price': exit_ref,
             'fill_price': exit_fill, 'quantity': quantity, 'net_pnl': net_pnl}])
        equity_curve.append({'event_pos': actual_exit_pos, 'equity': cash})
        last_exit_pos = actual_exit_pos
        last_entry_pos = entry_pos
        if max_daily_loss_pct is not None:
            day_equity = day_start_equity.setdefault(day_key(actual_exit_pos), cash - net_pnl)
            if (cash / day_equity - 1.0) <= -float(max_daily_loss_pct):
                halted_days.add(day_key(actual_exit_pos))
        if max_drawdown_pct is not None and (cash / peak - 1.0) <= -float(max_drawdown_pct):
            risk_halted = True

    pnl = np.asarray([t['net_pnl'] for t in trades], dtype=float)
    final_equity = float(cash)
    report = {'version': VERSION, 'mode': 'PAPER_ONLY_OFFLINE', 'live_orders_sent': False,
        'initial_cash': float(initial_cash), 'final_equity': final_equity,
        'net_pnl': float(pnl.sum()) if len(pnl) else 0.0,
        'net_return': final_equity / float(initial_cash) - 1.0,
        'trade_count': len(trades), 'win_rate': float(np.mean(pnl > 0)) if len(pnl) else None,
        'max_drawdown': float(max_dd), 'profit_factor': (float(pnl[pnl > 0].sum() / abs(pnl[pnl < 0].sum()))
            if np.any(pnl < 0) and np.any(pnl > 0) else None),
        'costs_bps': {'fee_per_side': float(fee_bps), 'slippage_per_side': float(slippage_bps),
                      'spread_round_trip': float(spread_bps)},
        'horizon_bars': int(horizon_bars), 'position_fraction': float(position_fraction),
        'risk_controls': {'stop_loss_pct': stop_loss_pct, 'take_profit_pct': take_profit_pct,
            'max_daily_loss_pct': max_daily_loss_pct, 'max_drawdown_pct': max_drawdown_pct,
            'emergency_stop': bool(emergency_stop), 'min_bars_between_entries': int(min_bars_between_entries),
            'halted_days': sorted(halted_days), 'global_halt': bool(risk_halted)},
        'skipped': skipped, 'trades': trades, 'events': events, 'equity_curve': equity_curve,
        'safety': {'paper_only': True, 'network_access': False, 'exchange_order_submission': False}}
    canonical = json.dumps(report, sort_keys=True, separators=(',', ':'), allow_nan=False)
    report['ledger_hash'] = hashlib.sha256(canonical.encode()).hexdigest()
    if ledger_path is not None:
        path = Path(ledger_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + '.tmp')
        tmp.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
        tmp.replace(path)
    return report
