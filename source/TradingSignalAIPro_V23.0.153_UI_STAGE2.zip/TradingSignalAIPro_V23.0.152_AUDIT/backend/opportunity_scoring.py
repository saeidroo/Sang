"""Conservative multi-factor opportunity quality index; advisory and paper-only."""
from __future__ import annotations
import math

WEIGHTS = {
    'trend_structure': 0.16, 'volume_strength': 0.10,
    'support_resistance': 0.10, 'volatility_fit': 0.10,
    'historical_strategy': 0.16, 'execution_cost': 0.12,
    'risk_reward': 0.16, 'data_reliability': 0.10,
}


def score_trade_opportunity(*, symbol, market='perp', timeframe='1h', factors=None,
                            blockers=None, min_coverage=0.60):
    symbol = str(symbol or '').upper().replace('/', '').strip()
    market = str(market or 'perp').lower().strip()
    timeframe = str(timeframe or '').strip()
    if not symbol.endswith('USDT') or market not in {'spot', 'perp'} or not timeframe:
        raise ValueError('symbol معتبر، market=spot|perp و timeframe لازم است')
    try:
        min_coverage = float(min_coverage)
    except (TypeError, ValueError):
        raise ValueError('min_coverage نامعتبر است')
    if not math.isfinite(min_coverage) or not 0.1 <= min_coverage <= 1:
        raise ValueError('min_coverage باید بین 0.1 و 1 باشد')
    factors = factors if isinstance(factors, dict) else {}
    normalized, used_weight = {}, 0.0
    weighted_sum = 0.0
    for name, weight in WEIGHTS.items():
        value = factors.get(name)
        if value is None:
            normalized[name] = None
            continue
        try:
            value = float(value)
        except (TypeError, ValueError):
            raise ValueError(f'{name} باید عددی بین 0 تا 100 باشد')
        if not math.isfinite(value) or not 0 <= value <= 100:
            raise ValueError(f'{name} باید عددی بین 0 تا 100 باشد')
        normalized[name] = round(value, 2)
        weighted_sum += value * weight
        used_weight += weight
    coverage = used_weight
    # Missing dimensions are not silently treated as positive: shrink the partial score to neutral.
    raw = weighted_sum / used_weight if used_weight else 50.0
    score = 50.0 + (raw - 50.0) * coverage
    blockers = blockers or []
    if not isinstance(blockers, (list, tuple)) or any(not isinstance(x, str) or not x.strip() for x in blockers):
        raise ValueError('blockers باید فهرستی از علت‌های متنی باشد')
    blockers = list(dict.fromkeys(x.strip().upper() for x in blockers))
    if blockers:
        state = 'BLOCKED'
    elif coverage < min_coverage:
        state = 'INSUFFICIENT_EVIDENCE'
    elif score >= 75:
        state = 'STRONG_CANDIDATE'
    elif score >= 60:
        state = 'MODERATE_CANDIDATE'
    elif score >= 45:
        state = 'WEAK_CANDIDATE'
    else:
        state = 'POOR_OPPORTUNITY'
    return {
        'symbol': symbol, 'market': market, 'timeframe': timeframe,
        'opportunity_quality_index': round(max(0.0, min(100.0, score)), 1),
        'classification': state, 'factor_scores': normalized,
        'factor_weights': WEIGHTS, 'evidence_coverage': round(coverage, 3),
        'missing_factors': [k for k, v in normalized.items() if v is None],
        'blockers': blockers,
        'is_probability_of_profit': False,
        'authorizes_entries': False, 'read_only': True,
        'paper_only': True, 'real_orders_enabled': False,
        'policy': 'Heuristic quality index only; not a profit probability or trade instruction. Missing evidence is shrunk toward neutral.'
    }
