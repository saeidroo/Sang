"""Conservative, deterministic partial-exit accounting for paper positions."""
from __future__ import annotations
import math


def validate_partial_quantity(*, original_quantity: float, already_exited: float,
                              requested_quantity: float) -> float:
    values = [float(original_quantity), float(already_exited), float(requested_quantity)]
    if not all(math.isfinite(v) for v in values):
        raise ValueError("quantities must be finite")
    original, exited, requested = values
    remaining = original - exited
    if original <= 0 or exited < 0 or requested <= 0:
        raise ValueError("quantities must be positive and consistent")
    tolerance = max(1e-12, original * 1e-10)
    if exited >= original - tolerance:
        raise ValueError("position has no remaining quantity")
    if requested >= remaining - tolerance:
        raise ValueError("partial exit must leave a positive remainder; use full close")
    if requested > remaining + tolerance:
        raise ValueError("partial exit exceeds remaining quantity")
    return remaining - requested


def calculate_partial_exit(*, side: str, quantity: float, entry_fill: float,
                           entry_fee_allocated: float, exit_reference: float,
                           execution_costs: dict) -> dict:
    side = str(side).upper()
    if side not in ("LONG", "SHORT"):
        raise ValueError("side must be LONG or SHORT")
    q, entry, allocated_fee, reference = map(float,
        (quantity, entry_fill, entry_fee_allocated, exit_reference))
    if not all(math.isfinite(v) for v in (q, entry, allocated_fee, reference)):
        raise ValueError("partial exit inputs must be finite")
    if q <= 0 or entry <= 0 or reference <= 0 or allocated_fee < 0:
        raise ValueError("partial exit inputs are outside safe bounds")
    from backend.execution_model import fill_price
    exit_fill = fill_price(reference, side, "exit", execution_costs)
    fee_rate = float(execution_costs["fee_bps_per_side"]) / 10000.0
    exit_fee = q * exit_fill * fee_rate
    direction = 1 if side == "LONG" else -1
    gross = direction * q * (exit_fill - entry)
    net = gross - allocated_fee - exit_fee
    return {"quantity": q, "reference_exit": reference, "exit_fill": exit_fill,
            "entry_fee_allocated": allocated_fee, "exit_fee": exit_fee,
            "gross_pnl": gross, "net_pnl": net}
