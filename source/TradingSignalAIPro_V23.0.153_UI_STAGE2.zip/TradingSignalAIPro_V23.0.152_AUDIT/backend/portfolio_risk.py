"""V23.0.10 portfolio and ATR-aware stop-risk sizing helpers.

All values are in quote currency (USDT). The module is intentionally pure so
its arithmetic can be unit-tested independently of exchange/network code.
"""
from __future__ import annotations

import math
from collections import defaultdict
from typing import Any, Iterable


def _finite(value: Any, field: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        raise ValueError(f"مقدار {field} نامعتبر است")
    if not math.isfinite(number):
        raise ValueError(f"مقدار {field} نامعتبر است")
    return number


def estimate_stop_risk(row: Any, *, fee_bps_per_side: float = 10.0,
                       slippage_bps_per_side: float = 5.0) -> float:
    """Estimate loss at the current stop, including both-side fees/slippage.

    A stop already beyond breakeven has zero gross loss, but its execution
    costs remain included. Invalid/missing stop data raises instead of being
    silently treated as zero risk.
    """
    data = dict(row) if not isinstance(row, dict) else row
    side = str(data.get("side") or "").upper()
    if side not in ("LONG", "SHORT"):
        raise ValueError("جهت موقعیت برای محاسبه ریسک نامعتبر است")
    direction = 1.0 if side == "LONG" else -1.0
    quantity = _finite(data.get("quantity"), "quantity")
    entry = _finite(data.get("entry_fill"), "entry_fill")
    stop = _finite(data.get("stop_price"), "stop_price")
    entry_fee = _finite(data.get("entry_fee", 0.0), "entry_fee")
    fee_rate = _finite(fee_bps_per_side, "fee_bps_per_side") / 10_000.0
    slip_rate = _finite(slippage_bps_per_side, "slippage_bps_per_side") / 10_000.0
    if quantity <= 0 or entry <= 0 or stop <= 0 or entry_fee < 0 or fee_rate < 0 or slip_rate < 0:
        raise ValueError("پارامترهای موقعیت برای محاسبه ریسک نامعتبرند")
    stop_fill = stop * (1.0 - direction * slip_rate)
    gross_loss = max(0.0, direction * (entry - stop_fill)) * quantity
    exit_fee = quantity * stop_fill * fee_rate
    total = gross_loss + entry_fee + exit_fee
    if not math.isfinite(total) or total < 0:
        raise ValueError("ریسک موقعیت قابل محاسبه نیست")
    return total


def aggregate_open_risk(rows: Iterable[Any], *, fee_bps_per_side: float = 10.0,
                        slippage_bps_per_side: float = 5.0) -> dict:
    """Aggregate open stop-risk by portfolio, market, and direction."""
    total = 0.0
    by_market = defaultdict(float)
    by_side = defaultdict(float)
    count = 0
    invalid_ids = []
    for row in rows:
        data = dict(row) if not isinstance(row, dict) else row
        if str(data.get("status") or "OPEN").upper() != "OPEN":
            continue
        try:
            risk = estimate_stop_risk(data, fee_bps_per_side=fee_bps_per_side,
                                      slippage_bps_per_side=slippage_bps_per_side)
        except ValueError:
            invalid_ids.append(data.get("id"))
            continue
        market = str(data.get("market") or "").lower()
        side = str(data.get("side") or "").upper()
        if market not in ("spot", "perp") or side not in ("LONG", "SHORT"):
            invalid_ids.append(data.get("id"))
            continue
        total += risk
        by_market[market] += risk
        by_side[side] += risk
        count += 1
    return {
        "total": round(total, 8),
        "by_market": {k: round(v, 8) for k, v in by_market.items()},
        "by_side": {k: round(v, 8) for k, v in by_side.items()},
        "position_count": count,
        "invalid_position_ids": invalid_ids,
        "complete": not invalid_ids,
    }


def size_for_risk(*, equity: float, risk_budget_cash: float, stop_loss_pct: float,
                  max_position_notional_pct: float, available_balance: float,
                  fee_bps_per_side: float = 10.0,
                  slippage_bps_per_side: float = 5.0) -> dict:
    """Return a notional whose stop loss plus round-trip costs fits the budget."""
    values = {
        "equity": _finite(equity, "equity"),
        "risk_budget_cash": _finite(risk_budget_cash, "risk_budget_cash"),
        "stop_loss_pct": _finite(stop_loss_pct, "stop_loss_pct"),
        "max_position_notional_pct": _finite(max_position_notional_pct, "max_position_notional_pct"),
        "available_balance": _finite(available_balance, "available_balance"),
        "fee_bps_per_side": _finite(fee_bps_per_side, "fee_bps_per_side"),
        "slippage_bps_per_side": _finite(slippage_bps_per_side, "slippage_bps_per_side"),
    }
    if (values["equity"] <= 0 or values["risk_budget_cash"] <= 0 or
            values["stop_loss_pct"] <= 0 or values["max_position_notional_pct"] <= 0 or
            values["available_balance"] <= 0 or values["fee_bps_per_side"] < 0 or
            values["slippage_bps_per_side"] < 0):
        raise ValueError("بودجه ریسک یا ورودی‌های اندازه موقعیت نامعتبر است")
    friction = 2.0 * (values["fee_bps_per_side"] + values["slippage_bps_per_side"]) / 10_000.0
    risk_fraction = values["stop_loss_pct"] / 100.0 + friction
    if not math.isfinite(risk_fraction) or risk_fraction <= 0:
        raise ValueError("فاصله حدضرر برای اندازه‌گیری ریسک نامعتبر است")
    max_notional = values["equity"] * values["max_position_notional_pct"] / 100.0
    risk_notional = values["risk_budget_cash"] / risk_fraction
    notional = min(max_notional, risk_notional, values["available_balance"])
    return {
        "notional": round(max(0.0, notional), 8),
        "risk_fraction": risk_fraction,
        "estimated_stop_risk": round(max(0.0, notional) * risk_fraction, 8),
        "risk_notional_cap": round(risk_notional, 8),
        "max_notional_cap": round(max_notional, 8),
    }


def compute_atr_bracket(*, entry_price: float, atr_value: float, side: str,
                        fee_bps_per_side: float = 10.0,
                        slippage_bps_per_side: float = 5.0,
                        atr_stop_multiplier: float = 1.5,
                        min_stop_pct: float = 0.35,
                        max_stop_pct: float = 4.5,
                        target_net_rr: float = 1.8,
                        min_net_rr: float = 1.5,
                        max_target_pct: float = 15.0,
                        max_atr_pct: float = 3.0) -> dict:
    """Build entry-time ATR stop/target levels and verify net reward/risk.

    Percentages are fractions of notional. Round-trip fee and slippage are
    included on both the expected loss and reward sides. Funding is not
    included because public ticker data does not establish the funding paid
    over the eventual holding period.
    """
    entry = _finite(entry_price, "entry_price")
    atr_num = _finite(atr_value, "atr_value")
    fee_bps = _finite(fee_bps_per_side, "fee_bps_per_side")
    slip_bps = _finite(slippage_bps_per_side, "slippage_bps_per_side")
    multiplier = _finite(atr_stop_multiplier, "atr_stop_multiplier")
    min_stop = _finite(min_stop_pct, "min_stop_pct")
    max_stop = _finite(max_stop_pct, "max_stop_pct")
    desired_rr = _finite(target_net_rr, "target_net_rr")
    required_rr = _finite(min_net_rr, "min_net_rr")
    max_target = _finite(max_target_pct, "max_target_pct")
    max_atr = _finite(max_atr_pct, "max_atr_pct")
    direction = 1.0 if str(side).upper() == "LONG" else -1.0 if str(side).upper() == "SHORT" else 0.0
    if direction == 0:
        raise ValueError("جهت برای محاسبه حدضرر ATR نامعتبر است")
    if (entry <= 0 or atr_num <= 0 or fee_bps < 0 or slip_bps < 0 or multiplier <= 0
            or min_stop <= 0 or max_stop < min_stop or desired_rr <= 0
            or required_rr <= 0 or max_target <= 0 or max_atr <= 0):
        raise ValueError("ورودی‌های حدضرر و حدسود ATR نامعتبرند")

    atr_pct = atr_num / entry * 100.0
    if not math.isfinite(atr_pct) or atr_pct > max_atr:
        raise ValueError(f"نوسان ATR بیش از حد مجاز است ({atr_pct:.3f}% > {max_atr:.3f}%)")

    stop_pct = min(max_stop, max(min_stop, atr_pct * multiplier))
    # 1 bp = 0.01 percentage point. Friction is paid on entry and exit.
    round_trip_cost_pct = 2.0 * (fee_bps + slip_bps) / 100.0
    target_pct = desired_rr * (stop_pct + round_trip_cost_pct) + round_trip_cost_pct
    if target_pct > max_target:
        raise ValueError(f"هدف خالص لازم از سقف مجاز بیشتر است ({target_pct:.3f}% > {max_target:.3f}%)")
    net_reward_pct = target_pct - round_trip_cost_pct
    net_risk_pct = stop_pct + round_trip_cost_pct
    net_rr = net_reward_pct / net_risk_pct if net_risk_pct > 0 else 0.0
    if (not math.isfinite(net_rr) or net_rr < required_rr):
        raise ValueError(f"نسبت سود به ریسک خالص کافی نیست ({net_rr:.3f} < {required_rr:.3f})")

    stop_price = entry * (1.0 - direction * stop_pct / 100.0)
    target_price = entry * (1.0 + direction * target_pct / 100.0)
    if stop_price <= 0 or target_price <= 0 or not all(math.isfinite(x) for x in (stop_price, target_price)):
        raise ValueError("قیمت حدضرر/حدسود ATR نامعتبر است")
    return {
        "policy": "ATR14_STOP_1P5X_NET_RR_1P8",
        "atr_value": round(atr_num, 12),
        "atr_pct": round(atr_pct, 8),
        "atr_stop_multiplier": multiplier,
        "stop_loss_pct": round(stop_pct, 8),
        "take_profit_pct": round(target_pct, 8),
        "stop_price": round(stop_price, 12),
        "target_price": round(target_price, 12),
        "round_trip_cost_pct": round(round_trip_cost_pct, 8),
        "gross_reward_risk": round(target_pct / stop_pct, 8),
        "net_reward_risk": round(net_rr, 8),
        "min_net_reward_risk": required_rr,
        "funding_included": False,
    }


def validate_atr_bracket(*, entry_price: float, stop_price: float, target_price: float,
                         side: str, min_net_rr: float = 1.5,
                         fee_bps_per_side: float = 10.0,
                         slippage_bps_per_side: float = 5.0) -> dict:
    """Fail-closed validation of persisted stop/target geometry and net R:R."""
    entry = _finite(entry_price, "entry_price")
    stop = _finite(stop_price, "stop_price")
    target = _finite(target_price, "target_price")
    required = _finite(min_net_rr, "min_net_rr")
    fee = _finite(fee_bps_per_side, "fee_bps_per_side")
    slip = _finite(slippage_bps_per_side, "slippage_bps_per_side")
    direction = 1.0 if str(side).upper() == "LONG" else -1.0 if str(side).upper() == "SHORT" else 0.0
    if direction == 0 or min(entry, stop, target, required) <= 0 or fee < 0 or slip < 0:
        raise ValueError("پارامترهای اعتبارسنجی حدضرر/حدسود نامعتبرند")
    if not (direction * (entry - stop) > 0 and direction * (target - entry) > 0):
        raise ValueError("جهت حدضرر یا حدسود با موقعیت هم‌خوانی ندارد")
    cost_pct = 2.0 * (fee + slip) / 100.0
    stop_pct = abs(entry - stop) / entry * 100.0
    target_pct = abs(target - entry) / entry * 100.0
    net_risk = stop_pct + cost_pct
    net_reward = target_pct - cost_pct
    net_rr = net_reward / net_risk if net_risk > 0 else 0.0
    if net_reward <= 0 or not math.isfinite(net_rr) or net_rr + 1e-9 < required:
        raise ValueError(f"نسبت سود به ریسک خالص پس از قیمت‌گذاری نهایی کافی نیست ({net_rr:.3f} < {required:.3f})")
    return {"valid": True, "net_reward_risk": round(net_rr, 8),
            "stop_loss_pct": round(stop_pct, 8), "take_profit_pct": round(target_pct, 8),
            "round_trip_cost_pct": round(cost_pct, 8), "funding_included": False}


def analyze_support_resistance(candles: Any, *, side: str, reference_price: float,
                               lookback: int = 120, pivot_width: int = 3,
                               cluster_pct: float = 0.15) -> dict:
    """Find clustered swing levels using supplied CLOSED OHLC candles only.

    The caller is responsible for supplying closed candles and aligning their
    final timestamp with the signal candle. No future bars are consulted.
    """
    import pandas as pd
    side = str(side).upper()
    if side not in ("LONG", "SHORT"):
        raise ValueError("جهت تحلیل حمایت/مقاومت نامعتبر است")
    price = _finite(reference_price, "reference_price")
    width = int(pivot_width)
    if price <= 0 or width < 1 or width > 10:
        raise ValueError("پارامترهای تحلیل ساختار بازار نامعتبرند")
    frame = pd.DataFrame(candles).copy()
    required = {"high", "low", "close"}
    if not required.issubset(frame.columns):
        raise ValueError("دادهٔ کندل برای تحلیل حمایت/مقاومت ناقص است")
    frame = frame.tail(max(width * 2 + 5, int(lookback))).reset_index(drop=True)
    for col in ("high", "low", "close"):
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    frame = frame.dropna(subset=["high", "low", "close"])
    if len(frame) < width * 2 + 5:
        raise ValueError("تعداد کندل بسته‌شده برای تحلیل ساختار کافی نیست")
    if ((frame["high"] <= 0) | (frame["low"] <= 0) |
            (frame["high"] < frame["low"]) | (frame["close"] <= 0)).any():
        raise ValueError("OHLC برای تحلیل ساختار نامعتبر است")
    highs, lows = frame["high"].tolist(), frame["low"].tolist()
    raw = []
    # Exclude the last width bars: a pivot is confirmed only after right-side bars close.
    for i in range(width, len(frame) - width):
        if highs[i] >= max(highs[i-width:i+width+1]):
            raw.append(("RESISTANCE", highs[i]))
        if lows[i] <= min(lows[i-width:i+width+1]):
            raw.append(("SUPPORT", lows[i]))
    levels = []
    tolerance = cluster_pct / 100.0
    for kind in ("SUPPORT", "RESISTANCE"):
        values = sorted(v for k, v in raw if k == kind)
        clusters = []
        for value in values:
            if clusters and abs(value - clusters[-1][0]) / clusters[-1][0] <= tolerance:
                clusters[-1][1].append(value)
                clusters[-1][0] = sum(clusters[-1][1]) / len(clusters[-1][1])
            else:
                clusters.append([value, [value]])
        for center, members in clusters:
            if (kind == "SUPPORT" and center < price) or (kind == "RESISTANCE" and center > price):
                levels.append({"type": kind, "price": round(center, 12), "touches": len(members),
                               "distance_pct": round(abs(center-price)/price*100, 6)})
    supports = sorted((x for x in levels if x["type"] == "SUPPORT"), key=lambda x: x["price"], reverse=True)
    resistances = sorted((x for x in levels if x["type"] == "RESISTANCE"), key=lambda x: x["price"])
    ahead = resistances[0] if side == "LONG" and resistances else supports[0] if side == "SHORT" and supports else None
    return {"method": "CONFIRMED_SWING_PIVOTS_CLUSTERED", "side": side,
            "reference_price": price, "lookback": len(frame), "pivot_width": width,
            "supports": supports[:8], "resistances": resistances[:8],
            "nearest_obstacle": ahead, "data_policy": "CLOSED_CANDLES_ONLY"}



def detect_breakout_state(candles: Any, *, side: str, atr_value: float,
                          pivot_width: int = 3, buffer_atr: float = 0.10) -> dict:
    """Classify a closed-candle break of the nearest confirmed swing level.

    The final row is the just-closed signal candle; pivot levels are computed
    only from earlier rows, so the signal candle cannot define its own level.
    """
    import pandas as pd
    direction = str(side).upper()
    if direction not in ("LONG", "SHORT"):
        raise ValueError("جهت شکست نامعتبر است")
    atr_num = _finite(atr_value, "atr_value")
    width = int(pivot_width)
    buffer = _finite(buffer_atr, "buffer_atr")
    if atr_num <= 0 or width < 1 or width > 10 or buffer < 0:
        raise ValueError("پارامترهای تشخیص شکست نامعتبرند")
    frame = pd.DataFrame(candles).copy()
    if not {"high", "low", "close"}.issubset(frame.columns):
        raise ValueError("دادهٔ OHLC برای تشخیص شکست ناقص است")
    frame = frame.tail(160).reset_index(drop=True)
    for col in ("high", "low", "close"):
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    frame = frame.dropna(subset=["high", "low", "close"]).reset_index(drop=True)
    if len(frame) < width * 2 + 6:
        raise ValueError("تاریخچهٔ بسته‌شده برای تشخیص شکست کافی نیست")
    if ((frame[["high", "low", "close"]] <= 0).any().any() or
            (frame["high"] < frame["low"]).any()):
        raise ValueError("OHLC برای تشخیص شکست نامعتبر است")
    prior = frame.iloc[:-1].reset_index(drop=True)
    highs, lows = prior.high.tolist(), prior.low.tolist()
    pivots = []
    for i in range(width, len(prior) - width):
        if highs[i] >= max(highs[i-width:i+width+1]):
            pivots.append(("RESISTANCE", highs[i]))
        if lows[i] <= min(lows[i-width:i+width+1]):
            pivots.append(("SUPPORT", lows[i]))
    last, prev = frame.iloc[-1], frame.iloc[-2]
    level_type = "RESISTANCE" if direction == "LONG" else "SUPPORT"
    candidates = [v for kind, v in pivots if kind == level_type]
    if not candidates:
        return {"state": "NO_CONFIRMED_LEVEL", "side": direction, "level": None,
                "buffer_price": round(atr_num * buffer, 12), "data_policy": "CLOSED_CANDLES_ONLY"}
    # Select the most recently relevant level on the direction's breakout side.
    level = min(candidates, key=lambda v: abs(v - float(prev.close)))
    threshold = atr_num * buffer
    prev_close, close = float(prev.close), float(last.close)
    high, low = float(last.high), float(last.low)
    if direction == "LONG":
        crossed = prev_close <= level and close > level + threshold
        failed = prev_close > level and close < level - threshold
        retest = prev_close > level and low <= level + threshold and close >= level
    else:
        crossed = prev_close >= level and close < level - threshold
        failed = prev_close < level and close > level + threshold
        retest = prev_close < level and high >= level - threshold and close <= level
    state = "FALSE_BREAKOUT" if failed else "BREAKOUT_CONFIRMED" if crossed else "PULLBACK_RETEST" if retest else "NO_BREAKOUT"
    return {"state": state, "side": direction, "level_type": level_type,
            "level": round(level, 12), "previous_close": prev_close, "last_close": close,
            "buffer_price": round(threshold, 12), "data_policy": "CLOSED_CANDLES_ONLY"}

def validate_structure_room(structure: dict, *, side: str, entry_price: float,
                             target_price: float, min_clearance_pct: float = 0.10) -> dict:
    """Reject an ATR target placed beyond a nearby opposing swing level."""
    side = str(side).upper()
    entry, target = _finite(entry_price, "entry_price"), _finite(target_price, "target_price")
    clearance = _finite(min_clearance_pct, "min_clearance_pct")
    if side not in ("LONG", "SHORT") or entry <= 0 or target <= 0 or clearance < 0:
        raise ValueError("پارامترهای کنترل فضای ساختار نامعتبرند")
    obstacle = (structure or {}).get("nearest_obstacle")
    if not obstacle:
        return {"valid": True, "status": "NO_OPPOSING_LEVEL", "obstacle": None}
    level = _finite(obstacle.get("price"), "obstacle_price")
    direction = 1 if side == "LONG" else -1
    if direction * (level-entry) <= 0:
        raise ValueError("سطح ساختاری در جهت معامله معتبر نیست")
    room_pct = abs(level-entry)/entry*100.0
    target_pct = abs(target-entry)/entry*100.0
    if target_pct >= room_pct - clearance:
        raise ValueError(f"هدف ATR پشت/بسیار نزدیک سطح مخالف ساختار قرار می‌گیرد؛ فضای آزاد {room_pct:.3f}% و هدف {target_pct:.3f}%")
    return {"valid": True, "status": "CLEAR", "obstacle": obstacle,
            "room_pct": round(room_pct, 8), "target_pct": round(target_pct, 8)}


def detect_breakout_pullback(candles: Any, *, side: str, atr_value: float,
                             pivot_width: int = 3, buffer_atr: float = 0.10,
                             max_wait_bars: int = 8) -> dict:
    """Require a post-breakout retest and directional close before entry.

    The final row is the latest CLOSED candle. A breakout on that row is not
    treated as a pullback; the engine waits for a later retest candle.
    """
    import pandas as pd
    direction = str(side).upper()
    if direction not in ("LONG", "SHORT"):
        raise ValueError("جهت پولبک نامعتبر است")
    atr_num = _finite(atr_value, "atr_value")
    wait = int(max_wait_bars)
    buffer = _finite(buffer_atr, "buffer_atr")
    if atr_num <= 0 or wait < 1 or wait > 50 or buffer < 0:
        raise ValueError("پارامترهای موتور پولبک نامعتبرند")
    frame = pd.DataFrame(candles).copy().tail(160).reset_index(drop=True)
    needed = {"high", "low", "close"}
    if not needed.issubset(frame.columns):
        raise ValueError("داده OHLC برای پولبک ناقص است")
    for col in needed | ({"open"} if "open" in frame.columns else set()):
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    frame = frame.dropna(subset=list(needed)).reset_index(drop=True)
    if len(frame) < pivot_width * 2 + 6:
        raise ValueError("تاریخچه بسته‌شده برای تشخیص پولبک کافی نیست")
    if ((frame[["high", "low", "close"]] <= 0).any().any() or
            (frame["high"] < frame["low"]).any()):
        raise ValueError("OHLC برای تشخیص پولبک نامعتبر است")

    # Search only earlier closed candles for a confirmed breakout event.
    event = None
    first = max(pivot_width * 2 + 6, len(frame) - wait - 1)
    for end in range(first, len(frame)):
        result = detect_breakout_state(frame.iloc[:end], side=direction,
                                       atr_value=atr_num, pivot_width=pivot_width,
                                       buffer_atr=buffer_atr)
        if result.get("state") == "BREAKOUT_CONFIRMED":
            event = {"index": end - 1, "level": float(result["level"])}
    if event is None:
        latest = detect_breakout_state(frame, side=direction, atr_value=atr_num,
                                       pivot_width=pivot_width, buffer_atr=buffer_atr)
        if latest.get("state") == "BREAKOUT_CONFIRMED":
            return {"state": "WAITING_FOR_RETEST", "side": direction,
                    "level": latest.get("level"), "bars_since_breakout": 0,
                    "data_policy": "CLOSED_CANDLES_ONLY"}
        return {"state": "NO_RECENT_BREAKOUT", "side": direction, "level": None,
                "data_policy": "CLOSED_CANDLES_ONLY"}

    bars_since = len(frame) - 1 - int(event["index"])
    level = float(event["level"])
    last = frame.iloc[-1]
    close, high, low = float(last.close), float(last.high), float(last.low)
    threshold = atr_num * buffer
    if direction == "LONG":
        invalid = close < level - threshold
        touched = low <= level + threshold
        confirmed = touched and close >= level and ("open" not in frame or close >= float(last.get("open", close)))
    else:
        invalid = close > level + threshold
        touched = high >= level - threshold
        confirmed = touched and close <= level and ("open" not in frame or close <= float(last.get("open", close)))
    if bars_since > wait:
        state = "EXPIRED"
    elif invalid:
        state = "RETEST_FAILED"
    elif confirmed:
        state = "PULLBACK_CONFIRMED"
    else:
        state = "WAITING_FOR_RETEST"
    return {"state": state, "side": direction, "level": round(level, 12),
            "bars_since_breakout": bars_since, "retest_touched": bool(touched),
            "buffer_price": round(threshold, 12), "data_policy": "CLOSED_CANDLES_ONLY"}


def analyze_volume_confirmation(candles: Any, *, side: str, lookback: int = 20,
                                breakout_min_relative_volume: float = 1.20,
                                retest_min_relative_volume: float = 0.65) -> dict:
    """Assess closed-candle volume participation for a directional setup.

    Relative volume compares the latest closed candle with the preceding
    lookback candles (the current candle is excluded from the baseline). This
    is a participation filter, not proof of institutional or "smart-money" flow.
    """
    import pandas as pd
    direction = str(side).upper()
    if direction not in ("LONG", "SHORT"):
        raise ValueError("جهت تحلیل حجم نامعتبر است")
    n = int(lookback)
    breakout_min = _finite(breakout_min_relative_volume, "breakout_min_relative_volume")
    retest_min = _finite(retest_min_relative_volume, "retest_min_relative_volume")
    if n < 5 or n > 100 or breakout_min <= 0 or retest_min <= 0:
        raise ValueError("پارامترهای تحلیل حجم نامعتبرند")
    frame = pd.DataFrame(candles).copy().tail(n + 2).reset_index(drop=True)
    required = {"open", "close", "volume"}
    if not required.issubset(frame.columns):
        return {"state": "UNAVAILABLE", "confirmed": False, "reason": "VOLUME_COLUMN_MISSING",
                "data_policy": "CLOSED_CANDLES_ONLY"}
    for col in required:
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    if len(frame) < n + 1 or frame[list(required)].isna().any().any():
        return {"state": "UNAVAILABLE", "confirmed": False, "reason": "INSUFFICIENT_OR_INVALID_VOLUME",
                "data_policy": "CLOSED_CANDLES_ONLY"}
    baseline = frame["volume"].iloc[-(n + 1):-1]
    current = float(frame["volume"].iloc[-1])
    if (baseline < 0).any() or current <= 0 or float(baseline.mean()) <= 0:
        return {"state": "UNAVAILABLE", "confirmed": False, "reason": "NONPOSITIVE_VOLUME",
                "data_policy": "CLOSED_CANDLES_ONLY"}
    relative = current / float(baseline.mean())
    last = frame.iloc[-1]
    directional = float(last.close) > float(last.open) if direction == "LONG" else float(last.close) < float(last.open)
    # A five-bar price/volume comparison flags weakening participation only;
    # it is descriptive and does not independently create/reject a signal.
    prior = frame.iloc[-6:-1]
    prior_directional = float(prior.close.iloc[-1]) > float(prior.close.iloc[0]) if direction == "LONG" else float(prior.close.iloc[-1]) < float(prior.close.iloc[0])
    prior_avg = float(prior.volume.mean()) if len(prior) else 0.0
    divergence = bool(prior_directional and prior_avg > 0 and current < prior_avg * 0.75 and directional)
    threshold = breakout_min
    confirmed = directional and relative >= threshold
    state = "VOLUME_CONFIRMED" if confirmed else "WEAK_VOLUME"
    return {"state": state, "confirmed": bool(confirmed), "side": direction,
            "relative_volume": round(relative, 6), "baseline_volume": round(float(baseline.mean()), 8),
            "current_volume": current, "directional_candle": bool(directional),
            "participation_divergence": divergence,
            "breakout_threshold": breakout_min, "retest_threshold": retest_min,
            "data_policy": "CLOSED_CANDLES_ONLY",
            "note": "حجم نسبی مشارکت را می‌سنجد و اثبات ورود پول هوشمند نیست"}


def detect_liquidity_sweep(candles: Any, *, side: str, pivot_width: int = 3,
                           lookback: int = 120, sweep_buffer_atr: float = 0.05,
                           atr_value: float | None = None) -> dict:
    """Detect a wick through a previously confirmed swing level and close back.

    Only the final closed candle is evaluated; its own OHLC never creates the
    swing level being swept. This is a price-action proxy, not order-book data.
    """
    import pandas as pd
    direction = str(side).upper()
    if direction not in ("LONG", "SHORT"):
        raise ValueError("جهت تشخیص جمع‌آوری نقدینگی نامعتبر است")
    width, n = int(pivot_width), int(lookback)
    buffer_atr = _finite(sweep_buffer_atr, "sweep_buffer_atr")
    atr_num = None if atr_value is None else _finite(atr_value, "atr_value")
    if width < 1 or width > 10 or n < width * 2 + 6 or n > 500 or buffer_atr < 0 or (atr_num is not None and atr_num <= 0):
        raise ValueError("پارامترهای تشخیص نقدینگی نامعتبرند")
    frame = pd.DataFrame(candles).copy().tail(n + 1).reset_index(drop=True)
    needed = {"high", "low", "close"}
    if not needed.issubset(frame.columns):
        raise ValueError("داده OHLC برای تشخیص نقدینگی ناقص است")
    for col in needed:
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    frame = frame.dropna(subset=list(needed)).reset_index(drop=True)
    if len(frame) < width * 2 + 7 or (frame[["high", "low", "close"]] <= 0).any().any() or (frame.high < frame.low).any():
        raise ValueError("تاریخچه OHLC برای تشخیص نقدینگی کافی یا معتبر نیست")
    prior = frame.iloc[:-1]
    highs, lows = prior.high.tolist(), prior.low.tolist()
    pivots_high, pivots_low = [], []
    for i in range(width, len(prior) - width):
        if highs[i] >= max(highs[i-width:i+width+1]): pivots_high.append(float(highs[i]))
        if lows[i] <= min(lows[i-width:i+width+1]): pivots_low.append(float(lows[i]))
    last = frame.iloc[-1]
    threshold = (atr_num or float(last.close) * 0.001) * buffer_atr
    if direction == "LONG":
        levels = [x for x in pivots_low if x < float(last.close) + threshold]
        level = max(levels) if levels else None
        swept = level is not None and float(last.low) < level - threshold and float(last.close) > level
        kind = "BULLISH_SUPPORT_SWEEP"
    else:
        levels = [x for x in pivots_high if x > float(last.close) - threshold]
        level = min(levels) if levels else None
        swept = level is not None and float(last.high) > level + threshold and float(last.close) < level
        kind = "BEARISH_RESISTANCE_SWEEP"
    return {"state": "SWEEP_RECLAIMED" if swept else "NO_SWEEP",
            "side": direction, "sweep_type": kind if swept else None,
            "level": round(level, 12) if level is not None else None,
            "last_close": float(last.close), "buffer_price": round(threshold, 12),
            "data_policy": "CLOSED_CANDLES_ONLY",
            "interpretation": "قیمت سطح نقدینگی را با سایه عبور کرده و در همان کندل بسته‌شده به آن سوی سطح برگشته است؛ این فقط قرینه قیمتی است، نه اثبات سفارش‌های حدضرر."}


def analyze_rsi_macd_divergence(candles: Any, *, side: str, pivot_width: int = 3,
                                lookback: int = 160, min_price_move_pct: float = 0.10) -> dict:
    """Detect regular/hidden RSI and MACD divergence on confirmed pivots only.

    The latest candle is evaluated only after it is closed. Pivot points are
    accepted only when their right-hand confirmation window is present; no
    future bars are read. This is a technical indicator, not a standalone signal.
    """
    import pandas as pd
    direction = str(side).upper()
    if direction not in ("LONG", "SHORT"):
        raise ValueError("جهت تحلیل واگرایی نامعتبر است")
    width, n = int(pivot_width), int(lookback)
    min_move = _finite(min_price_move_pct, "min_price_move_pct")
    if width < 1 or width > 10 or n < 40 or n > 500 or min_move < 0:
        raise ValueError("پارامترهای تحلیل واگرایی نامعتبرند")
    frame = pd.DataFrame(candles).copy().tail(n).reset_index(drop=True)
    required = {"high", "low", "close"}
    if not required.issubset(frame.columns):
        return {"state":"UNAVAILABLE", "blocking":False, "reason":"OHLC_MISSING",
                "data_policy":"CLOSED_CANDLES_ONLY"}
    for col in required:
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    frame = frame.dropna(subset=list(required)).reset_index(drop=True)
    if len(frame) < max(40, width * 2 + 10) or (frame[list(required)] <= 0).any().any():
        return {"state":"UNAVAILABLE", "blocking":False, "reason":"INSUFFICIENT_OR_INVALID_CANDLES",
                "data_policy":"CLOSED_CANDLES_ONLY"}
    close = frame.close.astype(float)
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False, min_periods=14).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False, min_periods=14).mean()
    rs = gain / loss.replace(0, float('nan'))
    rsi = 100 - (100 / (1 + rs))
    rsi = rsi.where(loss != 0, 100.0).where(gain != 0, 0.0)
    ema12 = close.ewm(span=12, adjust=False, min_periods=12).mean()
    ema26 = close.ewm(span=26, adjust=False, min_periods=26).mean()
    macd = ema12 - ema26
    # Pivots include only points whose right confirmation bars are already closed.
    highs, lows = frame.high.astype(float).tolist(), frame.low.astype(float).tolist()
    pivot_highs, pivot_lows = [], []
    for i in range(width, len(frame) - width):
        if highs[i] >= max(highs[i-width:i+width+1]):
            pivot_highs.append(i)
        if lows[i] <= min(lows[i-width:i+width+1]):
            pivot_lows.append(i)
    def classify(indices, price_col, oscillator, kind):
        if len(indices) < 2:
            return "NONE"
        a, b = indices[-2], indices[-1]
        pa, pb = float(frame[price_col].iloc[a]), float(frame[price_col].iloc[b])
        oa, ob = float(oscillator.iloc[a]), float(oscillator.iloc[b])
        if not all(map(math.isfinite, (pa,pb,oa,ob))) or pa <= 0:
            return "NONE"
        moved = abs(pb / pa - 1.0) * 100 >= min_move
        if not moved: return "NONE"
        if kind == "LOW":
            if pb < pa and ob > oa: return "BULLISH_REGULAR"
            if pb > pa and ob < oa: return "BULLISH_HIDDEN"
        else:
            if pb > pa and ob < oa: return "BEARISH_REGULAR"
            if pb < pa and ob > oa: return "BEARISH_HIDDEN"
        return "NONE"
    rsi_low = classify(pivot_lows, "low", rsi, "LOW")
    rsi_high = classify(pivot_highs, "high", rsi, "HIGH")
    macd_low = classify(pivot_lows, "low", macd, "LOW")
    macd_high = classify(pivot_highs, "high", macd, "HIGH")
    bullish = direction == "LONG"
    regular = "BULLISH_REGULAR" if bullish else "BEARISH_REGULAR"
    hidden = "BULLISH_HIDDEN" if bullish else "BEARISH_HIDDEN"
    rsi_state = rsi_low if bullish else rsi_high
    macd_state = macd_low if bullish else macd_high
    opposing = "BEARISH_REGULAR" if bullish else "BULLISH_REGULAR"
    opposing_rsi = rsi_high if bullish else rsi_low
    opposing_macd = macd_high if bullish else macd_low
    blocking = opposing_rsi == opposing and opposing_macd == opposing
    if blocking: state = "DUAL_OPPOSING_REGULAR_DIVERGENCE"
    elif rsi_state == regular and macd_state == regular: state = "DUAL_SUPPORTIVE_REGULAR_DIVERGENCE"
    elif rsi_state == hidden or macd_state == hidden: state = "SUPPORTIVE_HIDDEN_DIVERGENCE"
    elif rsi_state == regular or macd_state == regular: state = "PARTIAL_SUPPORTIVE_REGULAR_DIVERGENCE"
    else: state = "NO_CONFIRMED_DIVERGENCE"
    return {"state":state, "side":direction, "rsi_divergence":rsi_state,
            "macd_divergence":macd_state, "opposing_rsi_divergence":opposing_rsi,
            "opposing_macd_divergence":opposing_macd, "blocking":bool(blocking),
            "rsi_value":round(float(rsi.iloc[-1]),4) if math.isfinite(float(rsi.iloc[-1])) else None,
            "macd_value":round(float(macd.iloc[-1]),8) if math.isfinite(float(macd.iloc[-1])) else None,
            "confirmed_price_pivots":{"highs":len(pivot_highs),"lows":len(pivot_lows)},
            "pivot_width":width,"lookback":n,"data_policy":"CLOSED_CANDLES_ONLY",
            "note":"واگرایی یک قرینه تکنیکال است؛ فقط واگرایی معمولی هم‌زمان RSI و MACD در جهت مخالف، مانع احتیاطی ورود است."}
