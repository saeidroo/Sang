"""Verify external incident anchors and drill recovery without mutating source evidence."""
from __future__ import annotations
import hashlib,json,os,time
from datetime import datetime,timezone
from pathlib import Path
from backend.btc_live_environment_validation import _canonical
from backend.btc_readonly_incident_export import verify_incident_export_bundle
from backend.btc_readonly_incidents import verify_incident_log_bytes
from backend.witness_server import digest_anchor,verify_anchor_record


def _expected_anchor(verified):
    m=verified['manifest']
    return {'schema_version':'ts-ai-readonly-incident-anchor-v1',
        'bundle_sha256':verified['bundle_sha256'],'manifest_sha256':m['manifest_sha256'],
        'incident_log_sha256':m['incident_log_sha256'],'incident_head_sha256':m['head_sha256'],
        'event_count':m['event_count'],'scope':'read_only_btc_4h_incident_audit',
        'training_allowed':False,'live_orders':False}


def _load_highwater(path):
    p=Path(path)
    if not p.exists(): return None
    if p.is_symlink() or not p.is_file(): raise ValueError('witness_highwater_path_invalid')
    state=json.loads(p.read_text(encoding='utf-8'))
    if state.get('schema')!='tekar.witness.highwater.v1': raise ValueError('witness_highwater_schema_invalid')
    return state


def verify_incident_witness_receipt(bundle_path, receipt, *, pinned_public_key_path, highwater_path=None):
    verified=verify_incident_export_bundle(bundle_path); expected=_expected_anchor(verified)
    if receipt.get('schema_version')!='ts-ai-external-witness-v1': raise ValueError('witness_receipt_schema_invalid')
    if receipt.get('anchor_digest')!=digest_anchor(expected): raise ValueError('witness_receipt_anchor_mismatch')
    verify_anchor_record(receipt,pinned_public_key_path)
    seq=receipt.get('sequence')
    if isinstance(seq,bool) or not isinstance(seq,int) or seq<1: raise ValueError('witness_receipt_sequence_invalid')
    try:
        ts=datetime.fromisoformat(receipt['timestamp'].replace('Z','+00:00'))
        if ts.tzinfo is None or ts.utcoffset() is None: raise ValueError
    except Exception as exc: raise ValueError('witness_receipt_timestamp_invalid') from exc
    if highwater_path is not None:
        high=Path(highwater_path); high.parent.mkdir(parents=True,exist_ok=True)
        lock=high.with_name(high.name+'.lock')
        try: fd=os.open(str(lock),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        except FileExistsError as exc: raise RuntimeError('witness_highwater_locked') from exc
        try:
            os.close(fd); state=_load_highwater(high)
            if state:
                if state.get('witness_id')!=receipt.get('witness_id'): raise ValueError('witness_highwater_identity_changed')
                old=int(state.get('highest_sequence',0)); old_digest=state.get('anchor_digest')
                if seq<old: raise ValueError('witness_receipt_rollback_detected')
                if seq==old and receipt['anchor_digest']!=old_digest: raise ValueError('witness_receipt_sequence_equivocation')
            if not state or seq>int(state.get('highest_sequence',0)):
                payload={'schema':'tekar.witness.highwater.v1','witness_id':receipt['witness_id'],
                    'highest_sequence':seq,'anchor_digest':receipt['anchor_digest'],
                    'updated_at_utc':datetime.now(timezone.utc).isoformat()}
                raw=_canonical(payload)+b'\n'; tmp=high.with_name(high.name+'.tmp')
                fd2=os.open(str(tmp),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
                with os.fdopen(fd2,'wb') as f: f.write(raw); f.flush(); os.fsync(f.fileno())
                os.replace(tmp,high)
        finally:
            try: lock.unlink()
            except FileNotFoundError: pass
    return {'valid':True,'witness_id':receipt['witness_id'],'sequence':seq,
        'anchor_digest':receipt['anchor_digest'],'bundle_sha256':verified['bundle_sha256'],
        'highwater_checked':highwater_path is not None}


def run_incident_recovery_drill(bundle_path, receipt, *, pinned_public_key_path,
        recovery_dir, highwater_path=None):
    verified=verify_incident_export_bundle(bundle_path)
    receipt_check=verify_incident_witness_receipt(bundle_path,receipt,
        pinned_public_key_path=pinned_public_key_path,highwater_path=highwater_path)
    from zipfile import ZipFile
    with ZipFile(bundle_path,'r') as z: raw=z.read('incidents.jsonl')
    state=verify_incident_log_bytes(raw)
    if hashlib.sha256(raw).hexdigest()!=verified['manifest']['incident_log_sha256']:
        raise ValueError('recovery_source_digest_mismatch')
    target=Path(recovery_dir).expanduser(); target.mkdir(parents=True,exist_ok=True)
    recovered=target/'recovered-incidents.jsonl'
    fd=os.open(str(recovered),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    with os.fdopen(fd,'wb') as f: f.write(raw); f.flush(); os.fsync(f.fileno())
    restored=verify_incident_log_bytes(recovered.read_bytes())
    if restored['head_sha256']!=state['head_sha256'] or restored['event_count']!=state['event_count']:
        raise ValueError('recovery_restored_chain_mismatch')
    tamper_detection=False
    try: verify_incident_log_bytes(raw+b'{tamper}\n')
    except ValueError: tamper_detection=True
    if not tamper_detection: raise ValueError('recovery_tamper_drill_failed')
    report={'schema':'tekar.btc4h.incident_recovery_drill.v1',
        'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'bundle_sha256':verified['bundle_sha256'],'incident_head_sha256':state['head_sha256'],
        'event_count':state['event_count'],'witness_receipt':receipt_check,
        'recovered_file':str(recovered),'recovered_sha256':hashlib.sha256(recovered.read_bytes()).hexdigest(),
        'restore_verification_passed':True,'tamper_detection_passed':tamper_detection,
        'training_allowed':False,'live_orders':False}
    report['report_sha256']=hashlib.sha256(_canonical(report)).hexdigest()
    return report
