"""Evidence-based exit review and operator handoff for BTC 4h read-only pilot."""
from __future__ import annotations
import hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path

ZERO='0'*64

def _canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def _sha(value): return hashlib.sha256(_canonical(value)).hexdigest()


def evaluate_readonly_pilot_exit(*, observability_report, failover_drill,
                                 pilot_gate_evidence, cross_source_reports,
                                 operator_decision=None, minimum_fetches=72,
                                 minimum_observation_hours=24,
                                 minimum_cross_source_passes=6):
    if not isinstance(observability_report,dict) or not isinstance(failover_drill,dict) or not isinstance(pilot_gate_evidence,dict) or not isinstance(cross_source_reports,list):
        raise ValueError('readonly_pilot_exit_evidence_invalid')
    metrics=observability_report.get('metrics',{})
    checks={
      'minimum_fetch_count_met':int(metrics.get('fetch_pass_count',0))>=minimum_fetches,
      'minimum_observation_window_met':float(metrics.get('observation_window_hours',0))>=minimum_observation_hours,
      'no_stale_reports':int(metrics.get('stale_report_count',0))==0,
      'no_removed_candles':int(metrics.get('removed_candle_count',0))==0,
      'no_critical_drift_alerts':int(metrics.get('drift_critical_count',0))==0,
      'failover_drill_passed':failover_drill.get('status')=='READY_READONLY_FAILOVER',
      'readonly_pilot_gate_passed':pilot_gate_evidence.get('status')=='READY_READONLY_PILOT',
      'cross_source_agreement_count_met':sum(r.get('status')=='PASS' for r in cross_source_reports if isinstance(r,dict))>=minimum_cross_source_passes,
    }
    errors=[name for name,passed in checks.items() if not passed]
    if errors: status='BLOCKED'
    elif operator_decision is None: status='REVIEW_REQUIRED'
    elif operator_decision=='CONTINUE_READONLY': status='CONTINUE_READONLY'
    elif operator_decision=='STOP': status='STOPPED'
    else: raise ValueError('readonly_pilot_operator_decision_invalid')
    evidence={'schema_version':'btc-4h-readonly-pilot-exit-v1','status':status,
        'created_at_utc':datetime.now(timezone.utc).isoformat(),'checks':checks,'errors':errors,
        'operator_decision':operator_decision,'metrics':metrics,
        'cross_source_pass_count':sum(r.get('status')=='PASS' for r in cross_source_reports if isinstance(r,dict)),
        'training_allowed':False,'live_orders':False,
        'scope':'read_only_pilot_exit_review_not_training_or_trading_authorization'}
    evidence['evidence_sha256']=_sha(evidence)
    return evidence


def append_readonly_pilot_handoff(evidence: dict, *, handoff_path):
    if not isinstance(evidence,dict) or evidence.get('schema_version')!='btc-4h-readonly-pilot-exit-v1':
        raise ValueError('readonly_pilot_handoff_invalid')
    body=dict(evidence); declared=body.pop('evidence_sha256',None)
    if not declared or _sha(body)!=declared: raise ValueError('readonly_pilot_handoff_hash_mismatch')
    path=Path(handoff_path).expanduser(); path.parent.mkdir(parents=True,exist_ok=True)
    rows=[]
    if path.exists():
        for i,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
            try: rows.append(json.loads(line))
            except ValueError as exc: raise ValueError(f'readonly_pilot_handoff_corrupt_line:{i}') from exc
    previous=ZERO
    for seq,row in enumerate(rows,1):
        record=dict(row); digest=record.pop('record_sha256',None)
        if row.get('sequence')!=seq or row.get('previous_record_sha256')!=previous or not digest or _sha(record)!=digest:
            raise ValueError('readonly_pilot_handoff_chain_invalid')
        previous=digest
    record={'sequence':len(rows)+1,'previous_record_sha256':previous,'evidence':evidence}
    record['record_sha256']=_sha(record)
    raw=_canonical(record)+b'\n'; fd=os.open(str(path),os.O_CREAT|os.O_APPEND|os.O_WRONLY,0o600)
    try:
        written=os.write(fd,raw)
        if written!=len(raw): raise OSError('readonly_pilot_handoff_short_append')
        os.fsync(fd)
    finally: os.close(fd)
    return {'sequence':record['sequence'],'record_sha256':record['record_sha256'],'status':evidence['status']}
