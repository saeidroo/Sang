"""V22.3o: append-only BTC 4h training-run registry with OOF lineage binding."""
from __future__ import annotations
import hashlib, json, os, threading
from pathlib import Path

_LOCK = threading.RLock()

def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False, default=str)

def _sha(value):
    return hashlib.sha256(_canonical(value).encode('utf-8')).hexdigest()

def _artifact_digest(artifact):
    body = dict(artifact)
    body.pop('artifact_sha256', None)
    body.pop('created_at_utc', None)
    return _sha(body)

def _registry_path(registry_dir):
    p = Path(registry_dir).expanduser() / 'btc_training_runs.jsonl'
    p.parent.mkdir(parents=True, exist_ok=True)
    return p

def _read(path):
    if not path.exists():
        return []
    rows = []
    for number, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        try:
            item = json.loads(line)
        except ValueError as exc:
            raise ValueError(f'training_registry_corrupt_line:{number}') from exc
        if not isinstance(item, dict):
            raise ValueError(f'training_registry_invalid_line:{number}')
        rows.append(item)
    return rows

def register_training_run(artifact, lineage, oof_report, *, registry_dir,
                          expected_fold_ids=None, expected_sample_indices=None, expected_coverage_contract=None):
    """Register one model run exactly once; OOF must pass audit before acceptance."""
    from backend.btc_training_lineage import require_training_lineage
    from backend.btc_oof_audit import audit_oof_report
    require_training_lineage(lineage)
    if not isinstance(artifact, dict) or artifact.get('artifact_sha256') != _artifact_digest(artifact):
        raise ValueError('training_run_artifact_hash_mismatch')
    expected = {
        'lineage_sha256': lineage['lineage_sha256'],
        'snapshot_data_sha256': lineage['snapshot']['data_sha256'],
        'snapshot_file_sha256': lineage['snapshot']['file_sha256'],
        'reconciliation_report_sha256': lineage['reconciliation']['report_sha256'],
    }
    if any(artifact.get(k) != v for k, v in expected.items()):
        raise ValueError('training_run_lineage_binding_mismatch')
    if not isinstance(oof_report, dict) or not isinstance(oof_report.get('predictions'), list):
        raise ValueError('oof_report_invalid')
    predictions = oof_report['predictions']
    for row in predictions:
        if not isinstance(row, dict) or row.get('model') != artifact.get('model_name'):
            raise ValueError('oof_prediction_model_mismatch')
    # Fail closed: registry acceptance is impossible without a PASS audit.
    if expected_coverage_contract is not None:
        from backend.btc_oof_coverage import require_oof_coverage_contract
        require_oof_coverage_contract(expected_coverage_contract, dataset_hash=artifact.get('dataset_hash'))
        if expected_fold_ids is not None or expected_sample_indices is not None:
            raise ValueError('oof_coverage_contract_conflicts_with_legacy_expectations')
        expected_fold_ids = expected_coverage_contract['expected_fold_ids']
        expected_sample_indices = expected_coverage_contract['expected_sample_indices']
        expected_fold_sample_indices = expected_coverage_contract['fold_sample_indices']
        expected_sample_identities = expected_coverage_contract['sample_identities']
    else:
        expected_fold_sample_indices = None
        expected_sample_identities = None
    audit = audit_oof_report(oof_report, model_name=artifact.get('model_name'),
                             expected_fold_ids=expected_fold_ids,
                             expected_sample_indices=expected_sample_indices,
                             expected_fold_sample_indices=expected_fold_sample_indices,
                             expected_sample_identities=expected_sample_identities)
    audit_artifact = {
        'schema_version': 'btc-oof-audit-v1',
        'status': audit['status'],
        'audit_sha256': audit['audit_sha256'],
        'oof_sha256': audit['oof_sha256'],
        'prediction_count': audit['prediction_count'],
        'fold_ids': audit['fold_ids'],
        'sample_count': audit['sample_count'],
        'fold_report_count': audit['fold_report_count'],
        'errors': audit['errors'],
    }
    audit_artifact['artifact_sha256'] = _sha(audit_artifact)
    oof_hash = _sha(oof_report)
    record = {
        'registry_version': 'btc-4h-training-registry-v1',
        'run_id': str(artifact.get('run_id', '')),
        'model_name': artifact.get('model_name'),
        'artifact': artifact,
        'lineage': lineage,
        'oof': {'sha256': oof_hash, 'row_count': len(predictions),
                'fold_reports': oof_report.get('fold_reports', []),
                'evaluation_hash': oof_report.get('evaluation_hash')},
        'oof_report': oof_report,
        'oof_audit': audit_artifact,
        'oof_coverage_contract': expected_coverage_contract,
    }
    if not record['run_id']:
        raise ValueError('training_run_id_required')
    record['record_sha256'] = _sha(record)
    path = _registry_path(registry_dir)
    with _LOCK:
        existing = _read(path)
        if any(r.get('run_id') == record['run_id'] for r in existing):
            raise ValueError('training_run_id_duplicate')
        fd = os.open(str(path), os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
        try:
            os.write(fd, (_canonical(record) + '\n').encode('utf-8'))
            os.fsync(fd)
        finally:
            os.close(fd)
    return {'run_id': record['run_id'], 'record_sha256': record['record_sha256'],
            'oof_sha256': oof_hash, 'oof_rows': len(predictions), 'registry_path': str(path)}

def load_training_run(run_id, *, registry_dir):
    """Retrieve and re-validate registry record, artifact digest, OOF digest and lineage."""
    from backend.btc_training_lineage import require_training_lineage
    path = _registry_path(registry_dir)
    with _LOCK:
        matches = [r for r in _read(path) if r.get('run_id') == str(run_id)]
    if not matches:
        raise KeyError('training_run_not_found')
    if len(matches) != 1:
        raise ValueError('training_run_registry_duplicate_id')
    record = matches[0]
    body = dict(record); declared = body.pop('record_sha256', None)
    if not declared or _sha(body) != declared:
        raise ValueError('training_registry_record_hash_mismatch')
    require_training_lineage(record.get('lineage'))
    artifact = record.get('artifact', {})
    if artifact.get('artifact_sha256') != _artifact_digest(artifact):
        raise ValueError('training_run_artifact_hash_mismatch')
    if _sha(record.get('oof_report')) != record.get('oof', {}).get('sha256'):
        raise ValueError('training_oof_hash_mismatch')
    from backend.btc_oof_audit import audit_oof_report
    coverage = record.get('oof_coverage_contract')
    if coverage is not None:
        from backend.btc_oof_coverage import require_oof_coverage_contract
        require_oof_coverage_contract(coverage, dataset_hash=artifact.get('dataset_hash'))
        audit = audit_oof_report(record['oof_report'], model_name=record.get('model_name'),
            expected_fold_ids=coverage['expected_fold_ids'],
            expected_sample_indices=coverage['expected_sample_indices'],
            expected_fold_sample_indices=coverage['fold_sample_indices'],
            expected_sample_identities=coverage['sample_identities'])
    else:
        audit = audit_oof_report(record['oof_report'], model_name=record.get('model_name'))
    stored_audit = record.get('oof_audit', {})
    audit_body = dict(stored_audit); audit_digest = audit_body.pop('artifact_sha256', None)
    if not audit_digest or _sha(audit_body) != audit_digest:
        raise ValueError('training_oof_audit_artifact_hash_mismatch')
    if (stored_audit.get('status') != 'PASS' or
        stored_audit.get('audit_sha256') != audit.get('audit_sha256') or
        stored_audit.get('oof_sha256') != audit.get('oof_sha256')):
        raise ValueError('training_oof_audit_mismatch')
    if artifact.get('lineage_sha256') != record['lineage'].get('lineage_sha256'):
        raise ValueError('training_run_lineage_binding_mismatch')
    return record

def list_training_runs(*, registry_dir):
    """Return compact run index; every record hash is checked before listing."""
    path = _registry_path(registry_dir)
    with _LOCK:
        rows = _read(path)
    result = []
    for row in rows:
        body = dict(row); declared = body.pop('record_sha256', None)
        if not declared or _sha(body) != declared:
            raise ValueError('training_registry_record_hash_mismatch')
        audit = row.get('oof_audit', {})
        audit_body = dict(audit); audit_digest = audit_body.pop('artifact_sha256', None)
        if not audit_digest or _sha(audit_body) != audit_digest or audit.get('status') != 'PASS':
            raise ValueError('training_oof_audit_artifact_hash_mismatch')
        result.append({'run_id': row['run_id'], 'model_name': row['model_name'],
                       'record_sha256': declared, 'oof_sha256': row['oof']['sha256'],
                       'oof_rows': row['oof']['row_count'],
                       'oof_audit_status': row.get('oof_audit', {}).get('status'),
                       'oof_audit_sha256': row.get('oof_audit', {}).get('artifact_sha256'),
                       'dataset_hash': row['artifact']['dataset_hash']})
    return result


def register_replay_artifact(replay_artifact, *, registry_dir):
    """Append an immutable replay artifact linked to an already registered original run."""
    if not isinstance(replay_artifact, dict):
        raise ValueError('replay_artifact_invalid')
    body = dict(replay_artifact)
    declared = body.pop('artifact_sha256', None)
    if not declared or _sha(body) != declared:
        raise ValueError('replay_artifact_hash_mismatch')
    original_id = str(replay_artifact.get('original_run_id', ''))
    replay_id = str(replay_artifact.get('replay_run_id', ''))
    if not original_id or not replay_id or original_id == replay_id:
        raise ValueError('replay_registry_run_identity_invalid')
    original = load_training_run(original_id, registry_dir=registry_dir)
    original_artifact = original.get('artifact', {})
    if (replay_artifact.get('dataset_hash') != original_artifact.get('dataset_hash') or
        replay_artifact.get('lineage_sha256') != original_artifact.get('lineage_sha256')):
        raise ValueError('replay_registry_lineage_binding_mismatch')
    comparisons = replay_artifact.get('comparisons')
    if not isinstance(comparisons, dict) or not comparisons:
        raise ValueError('replay_registry_comparisons_missing')
    status = 'PASS' if all(isinstance(v, dict) and v.get('deterministic') is True for v in comparisons.values()) else 'DIFFERENT'
    path = Path(registry_dir).expanduser() / 'btc_training_replays.jsonl'
    path.parent.mkdir(parents=True, exist_ok=True)
    with _LOCK:
        rows = _read(path)
        # Validate the complete existing chain before extending it.
        _audit_replay_rows(rows)
        if any(r.get('replay_run_id') == replay_id for r in rows):
            raise ValueError('replay_run_id_duplicate')
        previous = rows[-1]['chain_sha256'] if rows else '0' * 64
        record = {'registry_version':'btc-4h-replay-registry-v2',
                  'sequence':len(rows) + 1, 'previous_chain_sha256':previous,
                  'original_run_id':original_id, 'replay_run_id':replay_id,
                  'original_record_sha256':original['record_sha256'],
                  'dataset_hash':replay_artifact['dataset_hash'],
                  'lineage_sha256':replay_artifact['lineage_sha256'],
                  'replay_artifact':replay_artifact, 'comparison_status':status}
        record['chain_sha256'] = _sha(record)
        record['record_sha256'] = _sha(record)
        fd = os.open(str(path), os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
        try:
            payload = (_canonical(record) + '\n').encode('utf-8')
            written = os.write(fd, payload)
            if written != len(payload):
                raise OSError('replay_registry_short_append')
            os.fsync(fd)
        finally:
            os.close(fd)
    return {'replay_run_id':replay_id, 'original_run_id':original_id,
            'comparison_status':status, 'record_sha256':record['record_sha256'],
            'registry_path':str(path)}


def load_replay_run(replay_run_id, *, registry_dir):
    """Load a replay record and revalidate its immutable hashes and original-run binding."""
    path = Path(registry_dir).expanduser() / 'btc_training_replays.jsonl'
    with _LOCK:
        matches = [r for r in _read(path) if r.get('replay_run_id') == str(replay_run_id)]
    if not matches:
        raise KeyError('replay_run_not_found')
    if len(matches) != 1:
        raise ValueError('replay_registry_duplicate_id')
    record = matches[0]
    # A single-record load also audits the entire append-only chain.
    audit_replay_registry(registry_dir=registry_dir)
    body = dict(record); declared = body.pop('record_sha256', None)
    if not declared or _sha(body) != declared:
        raise ValueError('replay_registry_record_hash_mismatch')
    artifact = record.get('replay_artifact')
    if not isinstance(artifact, dict):
        raise ValueError('replay_artifact_invalid')
    artifact_body = dict(artifact); artifact_hash = artifact_body.pop('artifact_sha256', None)
    if not artifact_hash or _sha(artifact_body) != artifact_hash:
        raise ValueError('replay_artifact_hash_mismatch')
    original = load_training_run(record['original_run_id'], registry_dir=registry_dir)
    if (record.get('original_record_sha256') != original.get('record_sha256') or
        record.get('dataset_hash') != original.get('artifact', {}).get('dataset_hash') or
        record.get('lineage_sha256') != original.get('artifact', {}).get('lineage_sha256') or
        artifact.get('original_run_id') != record.get('original_run_id') or
        artifact.get('replay_run_id') != record.get('replay_run_id')):
        raise ValueError('replay_registry_lineage_binding_mismatch')
    comparisons = artifact.get('comparisons', {})
    status = 'PASS' if comparisons and all(isinstance(v, dict) and v.get('deterministic') is True for v in comparisons.values()) else 'DIFFERENT'
    if status != record.get('comparison_status'):
        raise ValueError('replay_registry_comparison_status_mismatch')
    return record


def list_replay_runs(*, registry_dir):
    """Return replay index; validate every record by loading it before listing."""
    path = Path(registry_dir).expanduser() / 'btc_training_replays.jsonl'
    with _LOCK:
        ids = [r.get('replay_run_id') for r in _read(path)]
    return [{'replay_run_id': rid,
             'original_run_id': (record := load_replay_run(rid, registry_dir=registry_dir))['original_run_id'],
             'comparison_status': record['comparison_status'],
             'record_sha256': record['record_sha256']}
            for rid in ids]


def _audit_replay_rows(rows):
    """Validate sequence, previous-link and per-record chain/record digests."""
    previous = '0' * 64
    seen = set()
    for expected_sequence, row in enumerate(rows, 1):
        if not isinstance(row, dict):
            raise ValueError('replay_registry_invalid_record')
        replay_id = row.get('replay_run_id')
        if not replay_id or replay_id in seen:
            raise ValueError('replay_registry_duplicate_or_missing_id')
        seen.add(replay_id)
        if row.get('sequence') != expected_sequence:
            raise ValueError('replay_registry_sequence_gap_or_reorder')
        if row.get('previous_chain_sha256') != previous:
            raise ValueError('replay_registry_chain_link_mismatch')
        body = dict(row)
        record_digest = body.pop('record_sha256', None)
        chain_digest = body.pop('chain_sha256', None)
        if not chain_digest or _sha(body) != chain_digest:
            raise ValueError('replay_registry_chain_hash_mismatch')
        with_chain = dict(body, chain_sha256=chain_digest)
        if not record_digest or _sha(with_chain) != record_digest:
            raise ValueError('replay_registry_record_hash_mismatch')
        previous = chain_digest
    return {'status':'PASS', 'record_count':len(rows), 'chain_head_sha256':previous,
            'first_replay_run_id': rows[0]['replay_run_id'] if rows else None,
            'last_replay_run_id': rows[-1]['replay_run_id'] if rows else None}


def audit_replay_registry(*, registry_dir):
    """Audit the full on-disk Replay chain; detects interior deletion and reordering."""
    path = Path(registry_dir).expanduser() / 'btc_training_replays.jsonl'
    with _LOCK:
        rows = _read(path)
        return _audit_replay_rows(rows)



def query_replay_runs(*, registry_dir, original_run_id=None, comparison_status=None,
                      replay_run_id=None, min_sequence=None, max_sequence=None):
    """Verified replay search with optional identity, status and sequence filters."""
    rows = list_replay_runs(registry_dir=registry_dir)
    result = []
    for item in rows:
        record = load_replay_run(item['replay_run_id'], registry_dir=registry_dir)
        if original_run_id is not None and record.get('original_run_id') != str(original_run_id):
            continue
        if comparison_status is not None and record.get('comparison_status') != str(comparison_status).upper():
            continue
        if replay_run_id is not None and record.get('replay_run_id') != str(replay_run_id):
            continue
        seq = record.get('sequence')
        if min_sequence is not None and seq < int(min_sequence):
            continue
        if max_sequence is not None and seq > int(max_sequence):
            continue
        result.append({'sequence': seq, 'replay_run_id': record['replay_run_id'],
                       'original_run_id': record['original_run_id'],
                       'comparison_status': record['comparison_status'],
                       'record_sha256': record['record_sha256'],
                       'chain_sha256': record['chain_sha256']})
    return result


def _anchor_path(anchor_path):
    path = Path(anchor_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _read_anchor_rows(path):
    if not path.exists():
        return []
    rows = []
    for number, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        try:
            row = json.loads(line)
        except ValueError as exc:
            raise ValueError(f'replay_anchor_corrupt_line:{number}') from exc
        if not isinstance(row, dict):
            raise ValueError(f'replay_anchor_invalid_line:{number}')
        rows.append(row)
    return rows


def _audit_anchor_rows(rows):
    previous = '0' * 64
    for sequence, row in enumerate(rows, 1):
        body = dict(row)
        declared = body.pop('anchor_sha256', None)
        if row.get('anchor_sequence') != sequence or row.get('previous_anchor_sha256') != previous:
            raise ValueError('replay_anchor_chain_sequence_or_link_mismatch')
        if not declared or _sha(body) != declared:
            raise ValueError('replay_anchor_hash_mismatch')
        previous = declared
    return {'status': 'PASS', 'anchor_count': len(rows),
            'latest_anchor_sha256': previous, 'latest': rows[-1] if rows else None}


def checkpoint_replay_registry(*, registry_dir, anchor_path):
    """Persist the current replay-chain head to a separately located append-only anchor log.

    Keep anchor_path outside registry_dir (ideally on a separately backed-up volume or host)
    to make tail truncation detectable even if the replay registry itself is rolled back.
    """
    path = _anchor_path(anchor_path)
    with _LOCK:
        audit = audit_replay_registry(registry_dir=registry_dir)
        anchors = _read_anchor_rows(path)
        anchor_audit = _audit_anchor_rows(anchors)
        latest = anchor_audit['latest']
        head = {'registry_record_count': audit['record_count'],
                'registry_chain_head_sha256': audit['chain_head_sha256']}
        if latest and latest.get('registry_record_count', 0) > audit['record_count']:
            raise ValueError('replay_registry_behind_existing_anchor')
        if latest and latest.get('registry_record_count') == audit['record_count']:
            if latest.get('registry_chain_head_sha256') != audit['chain_head_sha256']:
                raise ValueError('replay_registry_head_conflicts_with_anchor')
            return {'status': 'UNCHANGED', 'anchor_sequence': latest['anchor_sequence'],
                    'anchor_sha256': latest['anchor_sha256'], 'anchor_path': str(path), **head}
        record = {'anchor_version': 'btc-4h-replay-head-anchor-v1',
                  'anchor_sequence': len(anchors) + 1,
                  'previous_anchor_sha256': anchor_audit['latest_anchor_sha256'],
                  **head}
        record['anchor_sha256'] = _sha(record)
        payload = (_canonical(record) + '\n').encode('utf-8')
        fd = os.open(str(path), os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
        try:
            written = os.write(fd, payload)
            if written != len(payload):
                raise OSError('replay_anchor_short_append')
            os.fsync(fd)
        finally:
            os.close(fd)
        return {'status': 'ANCHORED', 'anchor_sequence': record['anchor_sequence'],
                'anchor_sha256': record['anchor_sha256'], 'anchor_path': str(path), **head}


def audit_replay_registry_anchor(*, registry_dir, anchor_path):
    """Audit the local replay chain against the latest separately stored head checkpoint."""
    path = _anchor_path(anchor_path)
    with _LOCK:
        registry = audit_replay_registry(registry_dir=registry_dir)
        anchors = _read_anchor_rows(path)
        anchor_audit = _audit_anchor_rows(anchors)
        latest = anchor_audit['latest']
        if latest is None:
            return {'status': 'UNANCHORED', 'registry': registry, 'anchor_count': 0}
        expected_count = int(latest.get('registry_record_count', -1))
        if expected_count < 0:
            raise ValueError('replay_anchor_record_count_invalid')
        if registry['record_count'] < expected_count:
            raise ValueError('replay_registry_tail_truncated_vs_anchor')
        if expected_count == 0:
            actual_head = '0' * 64
        else:
            rows = _read(Path(registry_dir).expanduser() / 'btc_training_replays.jsonl')
            actual_head = rows[expected_count - 1].get('chain_sha256')
        if actual_head != latest.get('registry_chain_head_sha256'):
            raise ValueError('replay_registry_head_mismatch_vs_anchor')
        return {'status': 'PASS', 'registry': registry, 'anchor_count': len(anchors),
                'anchor_sequence': latest['anchor_sequence'],
                'anchored_record_count': expected_count,
                'anchored_chain_head_sha256': actual_head,
                'registry_has_newer_records': registry['record_count'] > expected_count,
                'anchor_sha256': latest['anchor_sha256']}
