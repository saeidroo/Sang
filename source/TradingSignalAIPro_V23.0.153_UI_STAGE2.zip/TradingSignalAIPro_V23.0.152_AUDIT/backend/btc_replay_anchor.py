"""V22.3z signed BTC 4h replay-head anchors and external Witness publication."""
from __future__ import annotations
import base64, hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

SCHEMA = 'btc-4h-replay-signed-anchor-v1'
ZERO = '0' * 64


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')


def _key_id(public_key):
    raw = public_key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return hashlib.sha256(raw).hexdigest()


def sign_replay_head_anchor(checkpoint: dict, *, output_path):
    """Sign a previously generated V22.3y head checkpoint with the active rotatable key."""
    if not isinstance(checkpoint, dict):
        raise ValueError('replay_checkpoint_invalid')
    required = ('anchor_sequence', 'registry_record_count', 'registry_chain_head_sha256', 'anchor_sha256')
    if any(k not in checkpoint for k in required):
        raise ValueError('replay_checkpoint_fields_missing')
    body = dict(checkpoint); declared = body.pop('anchor_sha256', None)
    if not declared or hashlib.sha256(_canonical(body)).hexdigest() != declared:
        raise ValueError('replay_checkpoint_hash_mismatch')
    from backend import signed_anchor
    keypair = signed_anchor.ensure_keypair()
    sequence = signed_anchor._next_sequence()
    payload = {
        'schema_version': SCHEMA,
        'anchor_type': 'btc-4h-replay-registry-head',
        'anchor_sequence': int(checkpoint['anchor_sequence']),
        'registry_record_count': int(checkpoint['registry_record_count']),
        'registry_chain_head_sha256': str(checkpoint['registry_chain_head_sha256']),
        'external_anchor_sha256': declared,
        'key_id': keypair['key_id'],
        'signing_sequence': sequence,
        'signed_at_utc': datetime.now(timezone.utc).isoformat(),
    }
    signed = {**payload, 'signature': base64.b64encode(keypair['private'].sign(_canonical(payload))).decode('ascii')}
    path = Path(output_path).expanduser(); path.parent.mkdir(parents=True, exist_ok=True)
    raw = _canonical(signed) + b'\n'
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    except Exception:
        try: path.unlink()
        except OSError: pass
        raise
    return signed


def verify_signed_replay_head_anchor(anchor: dict, *, public_key_path=None):
    """Verify Ed25519 signature, key identity, revocation and signed payload shape."""
    try:
        if not isinstance(anchor, dict) or anchor.get('schema_version') != SCHEMA:
            raise ValueError('replay_signed_anchor_schema_invalid')
        from backend import signed_anchor
        kid = anchor.get('key_id', '')
        if not isinstance(kid, str) or len(kid) != 64:
            raise ValueError('replay_signed_anchor_key_id_invalid')
        revoked = set(signed_anchor._load_json(signed_anchor._revoked_file(), {'revoked': []}).get('revoked', []))
        if kid in revoked:
            raise ValueError('replay_signed_anchor_key_revoked')
        if public_key_path is None:
            public_key_path = signed_anchor._trusted_dir() / f'{kid}.public.pem'
        public = serialization.load_pem_public_key(Path(public_key_path).read_bytes())
        if not isinstance(public, Ed25519PublicKey) or _key_id(public) != kid:
            raise ValueError('replay_signed_anchor_trusted_key_mismatch')
        fields = ('schema_version', 'anchor_type', 'anchor_sequence', 'registry_record_count',
                  'registry_chain_head_sha256', 'external_anchor_sha256', 'key_id',
                  'signing_sequence', 'signed_at_utc')
        payload = {k: anchor[k] for k in fields}
        if payload['anchor_type'] != 'btc-4h-replay-registry-head':
            raise ValueError('replay_signed_anchor_type_invalid')
        if int(payload['anchor_sequence']) < 1 or int(payload['signing_sequence']) < 1:
            raise ValueError('replay_signed_anchor_sequence_invalid')
        if len(payload['registry_chain_head_sha256']) != 64 or len(payload['external_anchor_sha256']) != 64:
            raise ValueError('replay_signed_anchor_digest_invalid')
        signature = base64.b64decode(anchor['signature'], validate=True)
        public.verify(signature, _canonical(payload))
        return {'valid': True, 'key_id': kid, 'signing_sequence': payload['signing_sequence'], 'errors': []}
    except Exception as exc:
        return {'valid': False, 'errors': [str(exc)]}


def publish_signed_replay_head_anchor(anchor: dict, *, receipt_path=None, timeout=8.0):
    """Publish a verified signed anchor to the configured HTTPS Witness.

    Witness publication is optional and never changes local registry records.
    A verified receipt is saved exclusively when a receipt_path is supplied.
    """
    verified = verify_signed_replay_head_anchor(anchor)
    if not verified['valid']:
        raise ValueError('replay_signed_anchor_verification_failed:' + ';'.join(verified['errors']))
    from backend.external_anchor import submit_anchor
    result = submit_anchor(anchor, timeout=timeout)
    if not result.get('ok'):
        return {'published': False, 'error': result.get('error', 'witness_publish_failed'),
                'details': result.get('details', [])}
    if receipt_path is not None:
        path = Path(receipt_path).expanduser(); path.parent.mkdir(parents=True, exist_ok=True)
        raw = _canonical(result['receipt']) + b'\n'
        fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    return {'published': True, 'anchor_digest': result['anchor_digest'],
            'receipt': result['receipt'], 'verification': result['verification'],
            'receipt_path': str(receipt_path) if receipt_path is not None else None}


def create_replay_key_rotation_ceremony(*, output_path):
    """Rotate active key and produce an old+new dual-signed trust transition."""
    from backend import signed_anchor
    old = signed_anchor.ensure_keypair()
    old_id = old['key_id']
    rotation = signed_anchor.rotate_key(revoke_old=False)
    new = signed_anchor.ensure_keypair()
    old_private_path = signed_anchor._trusted_dir() / f'{old_id}.private.pem'
    old_private = serialization.load_pem_private_key(old_private_path.read_bytes(), password=None)
    if not isinstance(old_private, Ed25519PrivateKey):
        raise ValueError('rotation_old_private_key_type_invalid')
    new_public_pem = new['public_key_pem']
    old_public_pem = old['public_key_pem']
    payload = {'schema_version':'btc-4h-replay-key-rotation-v1',
               'old_key_id':old_id, 'new_key_id':new['key_id'],
               'old_public_key_pem':old_public_pem,
               'new_public_key_pem':new_public_pem,
               'created_at_utc':datetime.now(timezone.utc).isoformat()}
    raw = _canonical(payload)
    ceremony = {**payload,
                'old_key_signature':base64.b64encode(old_private.sign(raw)).decode('ascii'),
                'new_key_signature':base64.b64encode(new['private'].sign(raw)).decode('ascii')}
    path=Path(output_path).expanduser(); path.parent.mkdir(parents=True,exist_ok=True)
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        with os.fdopen(fd,'wb') as stream:
            stream.write(_canonical(ceremony)+b'\n'); stream.flush(); os.fsync(stream.fileno())
    except Exception:
        try: path.unlink()
        except OSError: pass
        raise
    return {'ceremony':ceremony,'old_key_id':old_id,'new_key_id':new['key_id'],
            'new_fingerprint_sha256':new['key_id'],'rotation':rotation,'path':str(path)}


def verify_replay_key_rotation_ceremony(ceremony: dict, *, trusted_old_public_key_path):
    """Verify both transition signatures against an independently pinned old key."""
    try:
        if not isinstance(ceremony,dict) or ceremony.get('schema_version')!='btc-4h-replay-key-rotation-v1':
            raise ValueError('rotation_ceremony_schema_invalid')
        payload_keys=('schema_version','old_key_id','new_key_id','old_public_key_pem','new_public_key_pem','created_at_utc')
        payload={k:ceremony[k] for k in payload_keys}; raw=_canonical(payload)
        old_pub=serialization.load_pem_public_key(Path(trusted_old_public_key_path).read_bytes())
        embedded_old=serialization.load_pem_public_key(payload['old_public_key_pem'].encode())
        new_pub=serialization.load_pem_public_key(payload['new_public_key_pem'].encode())
        if not isinstance(old_pub,Ed25519PublicKey) or not isinstance(embedded_old,Ed25519PublicKey) or not isinstance(new_pub,Ed25519PublicKey):
            raise ValueError('rotation_ceremony_key_type_invalid')
        if _key_id(old_pub)!=payload['old_key_id'] or _key_id(embedded_old)!=payload['old_key_id']:
            raise ValueError('rotation_old_key_fingerprint_mismatch')
        if _key_id(new_pub)!=payload['new_key_id']:
            raise ValueError('rotation_new_key_fingerprint_mismatch')
        old_pub.verify(base64.b64decode(ceremony['old_key_signature'],validate=True),raw)
        new_pub.verify(base64.b64decode(ceremony['new_key_signature'],validate=True),raw)
        return {'valid':True,'old_key_id':payload['old_key_id'],'new_key_id':payload['new_key_id'],
                'new_fingerprint_sha256':payload['new_key_id'],'errors':[]}
    except Exception as exc:
        return {'valid':False,'errors':[str(exc)]}


def import_rotated_replay_trust(ceremony: dict, *, trusted_old_public_key_path):
    """Import the new key only after the dual-signed transition is verified."""
    verified=verify_replay_key_rotation_ceremony(ceremony,trusted_old_public_key_path=trusted_old_public_key_path)
    if not verified['valid']:
        raise ValueError('rotation_ceremony_verification_failed:'+';'.join(verified['errors']))
    from backend import signed_anchor
    result=signed_anchor.import_trusted_public_key(ceremony['new_public_key_pem'],
        expected_fingerprint=verified['new_fingerprint_sha256'])
    return {'imported':True,**result}
