"""
Technical indicators library - 25+ indicators
All functions accept pandas Series/DataFrame and return same-length arrays.
"""
import numpy as np
import pandas as pd


# ---------- Moving Averages ----------

def sma(series: pd.Series, n: int) -> pd.Series:
    """Simple Moving Average"""
    return series.rolling(n, min_periods=n).mean()


def ema(series: pd.Series, n: int) -> pd.Series:
    """Exponential Moving Average"""
    return series.ewm(span=n, adjust=False, min_periods=n).mean()


def wma(series: pd.Series, n: int) -> pd.Series:
    """Weighted Moving Average (linear weights)"""
    weights = np.arange(1, n + 1, dtype=float)
    weights /= weights.sum()

    def _wma(x):
        if len(x) < n or np.isnan(x).any():
            return np.nan
        return np.dot(x[-n:], weights)
    return series.rolling(n, min_periods=n).apply(_wma, raw=True)


def hma(series: pd.Series, n: int) -> pd.Series:
    """Hull Moving Average - reduces lag, smooths noise"""
    half = max(2, n // 2)
    sqrt_n = max(2, int(np.sqrt(n)))
    wma1 = wma(series, half)
    wma2 = wma(series, n)
    diff = 2 * wma1 - wma2
    return wma(diff, sqrt_n)


def dema(series: pd.Series, n: int) -> pd.Series:
    """Double Exponential Moving Average"""
    e1 = ema(series, n)
    e2 = ema(e1, n)
    return 2 * e1 - e2


def tema(series: pd.Series, n: int) -> pd.Series:
    """Triple Exponential Moving Average"""
    e1 = ema(series, n)
    e2 = ema(e1, n)
    e3 = ema(e2, n)
    return 3 * e1 - 3 * e2 + e3


# ---------- Momentum ----------

def rsi(series: pd.Series, n: int = 14) -> pd.Series:
    """Relative Strength Index (Wilder smoothing)"""
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    avg_loss = loss.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    rs = avg_gain / (avg_loss + 1e-12)
    return 100 - 100 / (1 + rs)


def macd(series: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    """MACD line, signal line, histogram"""
    ema_fast = ema(series, fast)
    ema_slow = ema(series, slow)
    macd_line = ema_fast - ema_slow
    signal_line = ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist


def stochastic(high: pd.Series, low: pd.Series, close: pd.Series,
               k_period: int = 14, d_period: int = 3):
    """Stochastic Oscillator %K and %D"""
    low_n = low.rolling(k_period, min_periods=k_period).min()
    high_n = high.rolling(k_period, min_periods=k_period).max()
    k = 100 * (close - low_n) / (high_n - low_n + 1e-12)
    d = k.rolling(d_period, min_periods=d_period).mean()
    return k, d


def williams_r(high: pd.Series, low: pd.Series, close: pd.Series, n: int = 14) -> pd.Series:
    """Williams %R"""
    high_n = high.rolling(n, min_periods=n).max()
    low_n = low.rolling(n, min_periods=n).min()
    return -100 * (high_n - close) / (high_n - low_n + 1e-12)


def cci(high: pd.Series, low: pd.Series, close: pd.Series, n: int = 20) -> pd.Series:
    """Commodity Channel Index"""
    tp = (high + low + close) / 3
    sma_tp = sma(tp, n)
    mad = tp.rolling(n, min_periods=n).apply(
        lambda x: np.abs(x - x.mean()).mean(), raw=True)
    return (tp - sma_tp) / (0.015 * mad + 1e-12)


def roc(series: pd.Series, n: int) -> pd.Series:
    """Rate of Change"""
    return (series / series.shift(n) - 1) * 100


def mom(series: pd.Series, n: int) -> pd.Series:
    """Momentum"""
    return series - series.shift(n)


def trix(series: pd.Series, n: int = 15) -> pd.Series:
    """TRIX - rate of change of triple EMA"""
    e1 = ema(series, n)
    e2 = ema(e1, n)
    e3 = ema(e2, n)
    return (e3 / e3.shift(1) - 1) * 100


def uo(high: pd.Series, low: pd.Series, close: pd.Series,
      n1: int = 7, n2: int = 14, n3: int = 28) -> pd.Series:
    """Ultimate Oscillator"""
    prev_close = close.shift(1)
    tr = pd.concat([(high - low), (high - prev_close).abs(),
                    (low - prev_close).abs()], axis=1).max(axis=1)
    bp = close - pd.concat([low, prev_close], axis=1).min(axis=1)
    avg7 = bp.rolling(n1, min_periods=n1).sum() / tr.rolling(n1, min_periods=n1).sum()
    avg14 = bp.rolling(n2, min_periods=n2).sum() / tr.rolling(n2, min_periods=n2).sum()
    avg28 = bp.rolling(n3, min_periods=n3).sum() / tr.rolling(n3, min_periods=n3).sum()
    return 100 * (4 * avg7 + 2 * avg14 + avg28) / 7


def tsi(series: pd.Series, r: int = 25, s: int = 13) -> pd.Series:
    """True Strength Index"""
    m = series.diff()
    m1 = m.ewm(span=r, adjust=False).mean().ewm(span=s, adjust=False).mean()
    m2 = m.abs().ewm(span=r, adjust=False).mean().ewm(span=s, adjust=False).mean()
    return 100 * m1 / (m2 + 1e-12)


# ---------- Volatility ----------

def atr(high: pd.Series, low: pd.Series, close: pd.Series, n: int = 14) -> pd.Series:
    """Average True Range"""
    prev_close = close.shift(1)
    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low - prev_close).abs()
    ], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()


def bollinger_pct(series: pd.Series, n: int = 20, k: float = 2.0) -> pd.Series:
    """Position within Bollinger Bands (0=lower, 1=upper)"""
    mid = series.rolling(n, min_periods=n).mean()
    sd = series.rolling(n, min_periods=n).std()
    upper = mid + k * sd
    lower = mid - k * sd
    return (series - lower) / (upper - lower + 1e-12)


def bollinger_width(series: pd.Series, n: int = 20, k: float = 2.0) -> pd.Series:
    """Bollinger Bands width (normalized by mid)"""
    mid = series.rolling(n, min_periods=n).mean()
    sd = series.rolling(n, min_periods=n).std()
    return (2 * k * sd) / (mid + 1e-12)


def keltner_pct(high: pd.Series, low: pd.Series, close: pd.Series,
                n: int = 20, k: float = 1.5) -> pd.Series:
    """Position within Keltner Channel"""
    mid = ema(close, n)
    band = k * atr(high, low, close, n)
    return (close - (mid - band)) / (2 * band + 1e-12)


# ---------- Volume ----------

def obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    """On Balance Volume"""
    sign = np.sign(close.diff().fillna(0))
    return (sign * volume).cumsum()


def mfi(high: pd.Series, low: pd.Series, close: pd.Series,
        volume: pd.Series, n: int = 14) -> pd.Series:
    """Money Flow Index"""
    tp = (high + low + close) / 3
    mf = tp * volume
    pos = (tp.diff() > 0).astype(float)
    neg = (tp.diff() < 0).astype(float)
    pos_mf = (mf * pos).rolling(n, min_periods=n).sum()
    neg_mf = (mf * neg).rolling(n, min_periods=n).sum()
    return 100 - 100 / (1 + pos_mf / (neg_mf + 1e-12))


def cmf(high: pd.Series, low: pd.Series, close: pd.Series,
        volume: pd.Series, n: int = 20) -> pd.Series:
    """Chaikin Money Flow"""
    mfv = ((close - low) - (high - close)) / (high - low + 1e-12) * volume
    return mfv.rolling(n, min_periods=n).sum() / volume.rolling(n, min_periods=n).sum()


def vwap(high: pd.Series, low: pd.Series, close: pd.Series,
         volume: pd.Series, n: int = 20) -> pd.Series:
    """Volume Weighted Average Price (rolling)"""
    tp = (high + low + close) / 3
    return (tp * volume).rolling(n, min_periods=n).sum() / \
        volume.rolling(n, min_periods=n).sum()


def ad_line(high: pd.Series, low: pd.Series, close: pd.Series,
            volume: pd.Series) -> pd.Series:
    """Accumulation/Distribution Line"""
    mfv = ((close - low) - (high - close)) / (high - low + 1e-12) * volume
    return mfv.cumsum()


def force_index(close: pd.Series, volume: pd.Series, n: int = 13) -> pd.Series:
    """Force Index"""
    fi = close.diff() * volume
    return fi.ewm(span=n, adjust=False, min_periods=n).mean()


def ease_of_movement(high: pd.Series, low: pd.Series, close: pd.Series,
                     volume: pd.Series, n: int = 14) -> pd.Series:
    """Ease of Movement"""
    dm = ((high + low) / 2 - (high.shift(1) + low.shift(1)) / 2)
    br = (volume / 1e6) / (high - low + 1e-12)
    emv = dm / (br + 1e-12)
    return emv.rolling(n, min_periods=n).mean()


# ---------- Trend ----------

def adx(high: pd.Series, low: pd.Series, close: pd.Series, n: int = 14):
    """ADX, +DI, -DI"""
    up = high.diff()
    down = -low.diff()
    plus_dm = np.where((up > down) & (up > 0), up, 0.0)
    minus_dm = np.where((down > up) & (down > 0), down, 0.0)
    plus_dm = pd.Series(plus_dm, index=high.index)
    minus_dm = pd.Series(minus_dm, index=high.index)

    atr_ = atr(high, low, close, n)
    plus_di = 100 * plus_dm.ewm(alpha=1 / n, adjust=False).mean() / (atr_ + 1e-12)
    minus_di = 100 * minus_dm.ewm(alpha=1 / n, adjust=False).mean() / (atr_ + 1e-12)

    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di + 1e-12)
    adx_val = dx.ewm(alpha=1 / n, adjust=False).mean()
    return adx_val, plus_di, minus_di


def aroon(high: pd.Series, low: pd.Series, n: int = 25):
    """Aroon Up and Aroon Down (vectorized via rolling argmax/argmin)."""
    n = int(n)
    if n < 1:
        raise ValueError('Aroon period must be >= 1')
    window = n + 1
    # argmax/argmin are positions from oldest (0) to newest (n).
    # Aroon = 100 * position_of_extreme / n for both Up and Down.
    # We use rolling apply but with cached numpy arrays for speed.
    h_arr = high.to_numpy(dtype=float)
    l_arr = low.to_numpy(dtype=float)
    N = len(h_arr)
    up = np.full(N, np.nan)
    down = np.full(N, np.nan)
    for i in range(window - 1, N):
        w = h_arr[i - n:i + 1]
        if not np.isnan(w).all():
            argmax = int(np.nanargmax(w))
            up[i] = 100.0 * argmax / n
        w2 = l_arr[i - n:i + 1]
        if not np.isnan(w2).all():
            argmin = int(np.nanargmin(w2))
            down[i] = 100.0 * argmin / n
    return pd.Series(up, index=high.index), pd.Series(down, index=low.index)


def psar(high: pd.Series, low: pd.Series, close: pd.Series,
         af_start: float = 0.02, af_max: float = 0.2) -> pd.Series:
    """Parabolic SAR (simplified)"""
    n = len(close)
    psar_ = pd.Series(index=close.index, dtype=float)
    if n == 0:
        return psar_
    bull = True
    af = af_start
    ep = high.iloc[0]
    sar = low.iloc[0]
    psar_.iloc[0] = sar
    for i in range(1, n):
        prev_sar = sar
        sar = sar + af * (ep - sar)
        if bull:
            sar = min(sar, low.iloc[i - 1], low.iloc[i - 2] if i >= 2 else sar)
            if low.iloc[i] < sar:
                bull = False
                sar = ep
                ep = low.iloc[i]
                af = af_start
            else:
                if high.iloc[i] > ep:
                    ep = high.iloc[i]
                    af = min(af_max, af + af_start)
        else:
            sar = max(sar, high.iloc[i - 1], high.iloc[i - 2] if i >= 2 else sar)
            if high.iloc[i] > sar:
                bull = True
                sar = ep
                ep = high.iloc[i]
                af = af_start
            else:
                if low.iloc[i] < ep:
                    ep = low.iloc[i]
                    af = min(af_max, af + af_start)
        psar_.iloc[i] = sar
    return psar_


# ---------- Composite / Other ----------

def ichimoku(high: pd.Series, low: pd.Series, close: pd.Series,
             conv_n: int = 9, base_n: int = 26, span_n: int = 52):
    """Ichimoku Cloud - returns Tenkan, Kijun, SpanA, SpanB"""
    tenkan = (high.rolling(conv_n).max() + low.rolling(conv_n).min()) / 2
    kijun = (high.rolling(base_n).max() + low.rolling(base_n).min()) / 2
    span_a = (tenkan + kijun) / 2
    span_b = (high.rolling(span_n).max() + low.rolling(span_n).min()) / 2
    return tenkan, kijun, span_a, span_b


def supertrend(high: pd.Series, low: pd.Series, close: pd.Series,
               n: int = 10, mult: float = 3.0) -> pd.Series:
    """Supertrend indicator (+1 bull, -1 bear)"""
    atr_ = atr(high, low, close, n)
    mid = (high + low) / 2
    upper = mid + mult * atr_
    lower = mid - mult * atr_

    st = pd.Series(index=close.index, dtype=float)
    direction = pd.Series(index=close.index, dtype=float)
    if len(close) == 0:
        return direction
    st.iloc[0] = upper.iloc[0]
    direction.iloc[0] = -1
    for i in range(1, len(close)):
        if close.iloc[i] > st.iloc[i - 1]:
            direction.iloc[i] = 1
        elif close.iloc[i] < st.iloc[i - 1]:
            direction.iloc[i] = -1
        else:
            direction.iloc[i] = direction.iloc[i - 1]

        if direction.iloc[i] == 1:
            st.iloc[i] = min(lower.iloc[i], st.iloc[i - 1]
                             if direction.iloc[i - 1] == 1 else np.inf)
        else:
            st.iloc[i] = max(upper.iloc[i], st.iloc[i - 1]
                             if direction.iloc[i - 1] == -1 else -np.inf)
    return direction


def chaikin_osc(high: pd.Series, low: pd.Series, close: pd.Series,
                volume: pd.Series, fast: int = 3, slow: int = 10) -> pd.Series:
    """Chaikin Oscillator"""
    ad = ad_line(high, low, close, volume)
    return ema(ad, fast) - ema(ad, slow)


def coppock(series: pd.Series, wma_n: int = 10, roc1: int = 14, roc2: int = 11) -> pd.Series:
    """Coppock Curve"""
    return wma(roc(series, roc1) + roc(series, roc2), wma_n)


def zscore(series: pd.Series, n: int = 20) -> pd.Series:
    """Rolling z-score"""
    return (series - series.rolling(n).mean()) / (series.rolling(n).std() + 1e-12)


def pct_rank(series: pd.Series, n: int = 20) -> pd.Series:
    """Rolling percentile rank (0..1)"""
    def _rank(x):
        if len(x) < 2:
            return np.nan
        return (x[:-1] < x[-1]).sum() / (len(x) - 1)
    return series.rolling(n).apply(_rank, raw=True)


def vix_proxy(high: pd.Series, low: pd.Series, close: pd.Series, n: int = 20) -> pd.Series:
    """Simple volatility proxy: ATR/close annualized-ish"""
    return atr(high, low, close, n) / close * 100


# ---------- Additional indicators ----------

def alma(series: pd.Series, n: int = 9, offset: float = 0.85,
         sigma: float = 6.0) -> pd.Series:
    """Arnaud Legoux Moving Average - smooth, low lag."""
    m = offset * (n - 1)
    s = n / sigma
    weights = np.array([np.exp(-(i - m) ** 2 / (2 * s * s)) for i in range(n)])
    weights /= weights.sum()

    def _alma(x):
        if len(x) < n or np.isnan(x).any():
            return np.nan
        return np.dot(x[-n:], weights)
    return series.rolling(n, min_periods=n).apply(_alma, raw=True)


def tma(series: pd.Series, n: int = 20) -> pd.Series:
    """Triangular Moving Average - double smoothed SMA."""
    return sma(sma(series, n), n)


def donchian(high: pd.Series, low: pd.Series, n: int = 20):
    """Donchian Channels - upper, lower, mid."""
    upper = high.rolling(n, min_periods=n).max()
    lower = low.rolling(n, min_periods=n).min()
    mid = (upper + lower) / 2
    return upper, lower, mid


def kst(series: pd.Series) -> pd.Series:
    """Know Sure Thing oscillator."""
    r1 = roc(series, 10)
    r2 = roc(series, 15)
    r3 = roc(series, 20)
    r4 = roc(series, 30)
    kst_val = (sma(r1, 10) * 1 + sma(r2, 10) * 2 +
               sma(r3, 10) * 3 + sma(r4, 15) * 4)
    return kst_val


def dpo(series: pd.Series, n: int = 20) -> pd.Series:
    """Detrended Price Oscillator."""
    shifted = int(n / 2 + 1)
    return series.shift(shifted) - sma(series, n)


def pvt(close: pd.Series, volume: pd.Series) -> pd.Series:
    """Price Volume Trend."""
    return ((close.pct_change().fillna(0) * volume).cumsum()
            + close.iloc[0] * volume.iloc[0])


def nvi(close: pd.Series, volume: pd.Series) -> pd.Series:
    """Negative Volume Index."""
    n = len(close)
    out = pd.Series(np.nan, index=close.index, dtype=float)
    if n == 0:
        return out
    out.iloc[0] = 1000
    for i in range(1, n):
        if volume.iloc[i] < volume.iloc[i - 1]:
            out.iloc[i] = out.iloc[i - 1] * (close.iloc[i] / close.iloc[i - 1])
        else:
            out.iloc[i] = out.iloc[i - 1]
    return out


def pvi(close: pd.Series, volume: pd.Series) -> pd.Series:
    """Positive Volume Index."""
    n = len(close)
    out = pd.Series(np.nan, index=close.index, dtype=float)
    if n == 0:
        return out
    out.iloc[0] = 1000
    for i in range(1, n):
        if volume.iloc[i] > volume.iloc[i - 1]:
            out.iloc[i] = out.iloc[i - 1] * (close.iloc[i] / close.iloc[i - 1])
        else:
            out.iloc[i] = out.iloc[i - 1]
    return out


def vroc(volume: pd.Series, n: int = 14) -> pd.Series:
    """Volume Rate of Change."""
    return (volume / volume.shift(n) - 1) * 100


def heikinashi(open_: pd.Series, high: pd.Series, low: pd.Series,
               close: pd.Series):
    """Heikin-Ashi candlesticks. Returns (ha_open, ha_high, ha_low, ha_close)."""
    ha_close = (open_ + high + low + close) / 4
    ha_open = pd.Series(index=close.index, dtype=float)
    ha_open.iloc[0] = (open_.iloc[0] + close.iloc[0]) / 2
    for i in range(1, len(close)):
        ha_open.iloc[i] = (ha_open.iloc[i - 1] + ha_close.iloc[i - 1]) / 2
    ha_high = pd.concat([high, ha_open, ha_close], axis=1).max(axis=1)
    ha_low = pd.concat([low, ha_open, ha_close], axis=1).min(axis=1)
    return ha_open, ha_high, ha_low, ha_close


def median_price(high: pd.Series, low: pd.Series) -> pd.Series:
    """Median price = (high + low) / 2."""
    return (high + low) / 2


def typical_price(high: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
    """Typical price = (high + low + close) / 3."""
    return (high + low + close) / 3


def weighted_close(high: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
    """Weighted close = (high + low + 2*close) / 4."""
    return (high + low + 2 * close) / 4


def rvi(open_: pd.Series, high: pd.Series, low: pd.Series, close: pd.Series,
        n: int = 10):
    """Relative Vigor Index - returns rvi and signal."""
    num = close - open_
    den = high - low
    num_sma = sma(num, n)
    den_sma = sma(den, n)
    rvi_val = num_sma / (den_sma + 1e-9)
    signal = sma(rvi_val, 4)
    return rvi_val, signal


def awesome_oscillator(high: pd.Series, low: pd.Series) -> pd.Series:
    """Awesome Oscillator."""
    mid = (high + low) / 2
    return sma(mid, 5) - sma(mid, 34)


def ac(high: pd.Series, low: pd.Series) -> pd.Series:
    """Accelerator Oscillator."""
    ao = awesome_oscillator(high, low)
    return ao - sma(ao, 5)


def fisher(high: pd.Series, low: pd.Series, n: int = 10) -> pd.Series:
    """Fisher Transform."""
    mid = (high + low) / 2
    lowest = mid.rolling(n, min_periods=n).min()
    highest = mid.rolling(n, min_periods=n).max()
    value = 2 * ((mid - lowest) / (highest - lowest + 1e-12) - 0.5)
    value = value.clip(-0.999, 0.999)
    return 0.5 * np.log((1 + value) / (1 - value + 1e-12))


def chande_momentum(series: pd.Series, n: int = 14) -> pd.Series:
    """Chande Momentum Oscillator."""
    diff = series.diff()
    up = diff.clip(lower=0).rolling(n, min_periods=n).sum()
    down = (-diff.clip(upper=0)).rolling(n, min_periods=n).sum()
    return 100 * (up - down) / (up + down + 1e-12)


def all_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    Build a DataFrame with 55+ indicators attached (V19.4 adds a regime/tail-risk pack: choppiness, mass index, HV percentile, pivot distance, return skew/kurtosis, Hurst persistence).
    Input df must have columns: open, high, low, close, volume (and t as time).
    Returns a new DataFrame with all indicator columns added.
    """
    o, h, l, c, v = df['open'], df['high'], df['low'], df['close'], df['volume']

    out = df.copy()

    # Moving averages (multiple periods)
    for n in [10, 20, 50, 100, 200]:
        if len(c) >= n:
            out[f'sma_{n}'] = sma(c, n)
            out[f'ema_{n}'] = ema(c, n)
    out['dema_20'] = dema(c, 20)
    out['tema_20'] = tema(c, 20)
    out['hma_20'] = hma(c, 20)
    out['wma_20'] = wma(c, 20)

    # RSI multiple
    out['rsi_7'] = rsi(c, 7)
    out['rsi_14'] = rsi(c, 14)
    out['rsi_21'] = rsi(c, 21)

    # MACD
    macd_line, sig_line, hist = macd(c)
    out['macd_line'] = macd_line
    out['macd_signal'] = sig_line
    out['macd_hist'] = hist

    # Stochastic
    k, d = stochastic(h, l, c)
    out['stoch_k'] = k
    out['stoch_d'] = d

    # Williams %R
    out['williams_r_14'] = williams_r(h, l, c, 14)

    # CCI
    out['cci_20'] = cci(h, l, c, 20)

    # ROC & Momentum
    out['roc_5'] = roc(c, 5)
    out['roc_10'] = roc(c, 10)
    out['roc_20'] = roc(c, 20)
    out['mom_10'] = mom(c, 10)
    out['trix_15'] = trix(c, 15)

    # Ultimate oscillator & TSI
    out['uo'] = uo(h, l, c)
    out['tsi'] = tsi(c)

    # Volatility
    out['atr_14'] = atr(h, l, c, 14)
    out['atr_7'] = atr(h, l, c, 7)
    out['bb_pct'] = bollinger_pct(c)
    out['bb_width'] = bollinger_width(c)
    out['keltner_pct'] = keltner_pct(h, l, c)
    out['vix_proxy'] = vix_proxy(h, l, c)
    out['close_z_20'] = zscore(c, 20)
    out['close_z_50'] = zscore(c, 50)
    out['close_pct_rank_20'] = pct_rank(c, 20)

    # Volume
    out['volume_mean_20'] = v.rolling(20).mean()
    out['obv'] = obv(c, v)
    out['mfi_14'] = mfi(h, l, c, v, 14)
    out['cmf_20'] = cmf(h, l, c, v, 20)
    out['vwap_20'] = vwap(h, l, c, v, 20)
    out['ad_line'] = ad_line(h, l, c, v)
    out['force_index_13'] = force_index(c, v, 13)
    out['eom_14'] = ease_of_movement(h, l, c, v, 14)
    out['chaikin_osc'] = chaikin_osc(h, l, c, v)
    out['volume_z_20'] = zscore(v, 20)

    # Trend
    adx_val, plus_di, minus_di = adx(h, l, c)
    out['adx_14'] = adx_val
    out['plus_di'] = plus_di
    out['minus_di'] = minus_di
    aroon_up, aroon_down = aroon(h, l)
    out['aroon_up'] = aroon_up
    out['aroon_down'] = aroon_down
    out['psar'] = psar(h, l, c)
    out['supertrend'] = supertrend(h, l, c)

    # Ichimoku
    tenkan, kijun, span_a, span_b = ichimoku(h, l, c)
    out['ich_tenkan'] = tenkan
    out['ich_kijun'] = kijun
    out['ich_span_a'] = span_a
    out['ich_span_b'] = span_b

    # Coppock
    out['coppock'] = coppock(c)

    # Candle-shape features
    body = (c - o)
    rng = (h - l).replace(0, 1e-9)
    out['body_ratio'] = body / rng
    out['upper_wick'] = (h - np.maximum(o, c)) / rng
    out['lower_wick'] = (np.minimum(o, c) - l) / rng
    out['doji_score'] = 1 - (body.abs() / rng)

    # --- Additional indicators (15 more) ---
    # Moving averages
    out['alma_9'] = alma(c, 9)
    out['alma_20'] = alma(c, 20)
    out['tma_20'] = tma(c, 20)

    # Donchian channels
    don_up, don_low, don_mid = donchian(h, l, 20)
    out['donchian_upper'] = don_up
    out['donchian_lower'] = don_low
    out['donchian_pct'] = (c - don_low) / (don_up - don_low + 1e-9)

    # Oscillators
    out['kst'] = kst(c)
    out['dpo_20'] = dpo(c, 20)
    out['chande_momentum_14'] = chande_momentum(c, 14)
    out['fisher_10'] = fisher(h, l, 10)
    out['awesome_osc'] = awesome_oscillator(h, l)
    out['ac_osc'] = ac(h, l)

    # Volume indicators
    out['pvt'] = pvt(c, v)
    out['nvi'] = nvi(c, v)
    out['pvi'] = pvi(c, v)
    out['vroc_14'] = vroc(v, 14)

    # Heikin-Ashi
    ha_open, ha_high, ha_low, ha_close = heikinashi(o, h, l, c)
    out['ha_close'] = ha_close
    out['ha_open'] = ha_open
    out['ha_body_ratio'] = (ha_close - ha_open) / (ha_high - ha_low + 1e-9)

    # Price types
    out['median_price'] = median_price(h, l)
    out['typical_price'] = typical_price(h, l, c)
    out['weighted_close'] = weighted_close(h, l, c)

    # Relative Vigor Index
    rvi_val, rvi_sig = rvi(o, h, l, c)
    out['rvi'] = rvi_val
    out['rvi_signal'] = rvi_sig

    # Compact the base feature blocks before appending the v6 pack.
    out = out.copy()

    # v6 indicator pack
    kvo, kvo_sig = klinger_volume_osc(h, l, c, v)
    out['kvo'], out['kvo_signal'] = kvo, kvo_sig
    out['kvo_above_signal'] = (kvo > kvo_sig).astype(float)
    vp, vm = vortex(h,l,c); out['vortex_plus'], out['vortex_minus'] = vp, vm
    out['vortex_diff'] = vp-vm
    tr, tf, ts, tu, tl = tdi(c); out['tdi_rsi'],out['tdi_fast'],out['tdi_slow'],out['tdi_upper'],out['tdi_lower']=tr,tf,ts,tu,tl
    out['tdi_above_50']=(tr>50).astype(float)
    out['stc']=schaff_trend_cycle(c)
    wt, wts=wave_trend(h,l,c); out['wave_trend'],out['wave_trend_signal']=wt,wts
    out['chandelier_exit']=chandelier_exit(h,l,c)
    qr, qu, ql=qqe(c); out['qqe_rsi'],out['qqe_upper'],out['qqe_lower']=qr,qu,ql
    sq, sm=squeeze_momentum(h,l,c); out['squeeze_on'],out['squeeze_momentum']=sq,sm
    eb, er=elder_ray(h,l,c); out['elder_bull'],out['elder_bear']=eb,er
    out['balance_of_power']=balance_of_power(o,h,l,c)
    out['efficiency_ratio']=kaufman_efficiency_ratio(c)
    out['fractal_dim']=fractal_dimension(c)

    # V19.4 — stronger-brain indicator pack: regime/trend-persistence and
    # tail-risk features the model did not have before.
    out['choppiness_14'] = choppiness_index(h, l, c, 14)
    out['mass_index'] = mass_index(h, l)
    out['hv_percentile'] = historical_vol_percentile(c)
    out['pivot_dist'] = pivot_point_dist(h, l, c)
    out['ret_skew_30'], out['ret_kurt_30'] = rolling_skew_kurt(c, 30)
    out['hurst_100'] = hurst_persistence(c, 100)

    return out


# ---------- Additional indicators (v6) ----------
def klinger_volume_osc(high, low, close, volume, fast=34, slow=55, signal=13):
    """Klinger Volume Oscillator with recursive cumulative measurement."""
    dm = (high - low).astype(float)
    tp = (high + low + close) / 3.0
    trend = np.sign(tp.diff()).replace(0, np.nan).ffill().fillna(1.0)
    trend_prev = trend.shift(1).fillna(trend.iloc[0])
    cm = pd.Series(index=close.index, dtype=float)
    running = float(dm.iloc[0]) if len(dm) else 0.0
    for i in range(len(dm)):
        if i == 0 or trend.iloc[i] != trend_prev.iloc[i]:
            running = float(dm.iloc[i])
        else:
            running += float(dm.iloc[i])
        cm.iloc[i] = running
    ratio = (2.0 * (dm / cm.replace(0, np.nan)) - 1.0).abs()
    vf = volume * trend * ratio * 100.0
    line = ema(vf.fillna(0), fast) - ema(vf.fillna(0), slow)
    return line, ema(line, signal)

def vortex(high, low, close, n=14):
    tr = pd.concat([high-low, (high-close.shift()).abs(), (low-close.shift()).abs()], axis=1).max(axis=1)
    plus = (high-low.shift()).abs().rolling(n).sum() / tr.rolling(n).sum().replace(0, np.nan)
    minus = (high.shift()-low).abs().rolling(n).sum() / tr.rolling(n).sum().replace(0, np.nan)
    return plus, minus

def tdi(close, rsi_period=13, band_period=34, fast_ma=2, slow_ma=7):
    r = rsi(close, rsi_period); basis = sma(r, band_period); dev = r.rolling(band_period).std()
    return r, ema(r, fast_ma), ema(r, slow_ma), basis+2*dev, basis-2*dev

def schaff_trend_cycle(close, fast=23, slow=50, cycle=10):
    m = ema(close, fast)-ema(close, slow)
    lo=m.rolling(cycle).min(); hi=m.rolling(cycle).max()
    st=100*(m-lo)/(hi-lo+1e-9); k=ema(st,3)
    lo2=k.rolling(cycle).min(); hi2=k.rolling(cycle).max()
    return ema(100*(k-lo2)/(hi2-lo2+1e-9),3)

def wave_trend(high, low, close, n1=10, n2=21):
    ap=(high+low+close)/3; esa=ema(ap,n1); dev=ema((ap-esa).abs(),n1)
    tci=ema((ap-esa)/(0.015*dev+1e-9),n2)
    return tci, ema(tci,4)

def chandelier_exit(high, low, close, n=22, mult=3.0):
    return high.rolling(n).max()-mult*atr(high,low,close,n)

def qqe(close, rsi_period=14, sf=5, smooth=5):
    r=ema(rsi(close,rsi_period),sf); band=ema(r.diff().abs(),smooth)*4.236
    return r, r+band, r-band

def squeeze_momentum(high, low, close, n=20, mult_bb=2.0, mult_kc=1.5):
    mid=sma(close,n); sd=close.rolling(n).std(); a=atr(high,low,close,n)
    on=((mid+mult_bb*sd)<(ema(close,n)+mult_kc*a)) & ((mid-mult_bb*sd)>(ema(close,n)-mult_kc*a))
    return on.astype(float), (close-mid)/(mid.abs()+1e-9)

def elder_ray(high, low, close, n=13):
    e=ema(close,n); return high-e, low-e

def balance_of_power(open_, high, low, close):
    return (close-open_)/(high-low+1e-9)

def choppiness_index(high, low, close, n=14):
    """0..100. Near 100 = choppy/range-bound; near 0 = strongly trending.
    Lets the model tell 'range' markets apart from 'trend' markets."""
    tr = atr(high, low, close, 1) * 1.0            # true range per bar (n=1 atr == TR)
    sum_tr = tr.rolling(n).sum()
    hh, ll = high.rolling(n).max(), low.rolling(n).min()
    rng = (hh - ll).replace(0, np.nan)
    return 100 * np.log10((sum_tr / rng).replace(0, np.nan)) / np.log10(n)


def mass_index(high, low, n=9, n_sum=25):
    """Classic Mass Index: range (high-low) EMA ratio, summed — flags
    'reversal bulge' volatility expansions ahead of a possible turn."""
    rng = (high - low)
    ema1 = ema(rng, n)
    ema2 = ema(ema1, n)
    ratio = ema1 / (ema2 + 1e-9)
    return ratio.rolling(n_sum).sum()


def historical_vol_percentile(close, lookback=100, window=20):
    """Where today's realized volatility sits vs. its own recent history
    (0..1). High = unusually volatile right now for THIS market/timeframe."""
    vol = close.pct_change().rolling(window).std()
    return vol.rolling(lookback).rank(pct=True)


def pivot_point_dist(high, low, close):
    """Distance of the close from the classic floor-trader pivot (prior bar's
    H/L/C), normalised by that bar's range. Causal: uses only bar t-1."""
    pp = (high.shift(1) + low.shift(1) + close.shift(1)) / 3.0
    rng = (high.shift(1) - low.shift(1)).replace(0, np.nan)
    return (close - pp) / (rng + 1e-9)


def rolling_skew_kurt(close, n=30):
    """Skew/kurtosis of recent returns: captures asymmetric tail risk
    (e.g. a market that grinds up but crashes down has negative skew)."""
    ret = close.pct_change()
    return ret.rolling(n).skew(), ret.rolling(n).kurt()


def hurst_persistence(close, n=100):
    """Variance-scaling Hurst exponent (~0.5 random walk, >0.5
    trending/persistent, <0.5 mean-reverting). Operates on the LOG-PRICE path
    (not on returns — lagged differences of log-price ARE the multi-period
    log-returns, whose variance scales as lag^(2H) for fractional Brownian
    motion). Rolling, causal."""
    logp = np.log(close)

    def _h(x):
        x = np.asarray(x, dtype=float)
        if len(x) < 20 or not np.isfinite(x).all():
            return np.nan
        lags = range(2, min(20, len(x) // 2))
        tau = []
        for lag in lags:
            diffs = x[lag:] - x[:-lag]
            sd = np.std(diffs)
            tau.append(sd if sd > 0 else np.nan)
        tau = np.asarray(tau, dtype=float)
        ok = np.isfinite(tau) & (tau > 0)
        if ok.sum() < 4:
            return np.nan
        lag_arr = np.log(np.array(list(lags), dtype=float)[ok])
        poly = np.polyfit(lag_arr, np.log(tau[ok]), 1)
        return float(np.clip(poly[0], 0.0, 1.0))
    return logp.rolling(n).apply(_h, raw=True)


def kaufman_efficiency_ratio(close,n=10):
    return (close-close.shift(n)).abs()/(close.diff().abs().rolling(n).sum()+1e-9)

def fractal_dimension(close,n=30):
    def calc(x):
        x=np.asarray(x,dtype=float)
        if len(x)<10 or not np.isfinite(x).all(): return np.nan
        ks=np.arange(1,max(2,len(x)//2)); lengths=[]
        for k in ks:
            vals=[]
            for m in range(k):
                z=x[m::k]
                if len(z)>1: vals.append(np.abs(np.diff(z)).sum()*(len(x)-1)/(k*(len(z)-1)))
            lengths.append(np.mean(vals) if vals else np.nan)
        lengths=np.asarray(lengths); ok=np.isfinite(lengths)&(lengths>0)
        if ok.sum()<2:return np.nan
        return float(-np.polyfit(np.log(ks[ok]),np.log(lengths[ok]),1)[0])
    return close.rolling(n).apply(calc,raw=True)
