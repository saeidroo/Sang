"""Manual-approval gate for a read-only BTC 4h data pilot; never enables trading."""
from __future__ import annotations
import hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path

ZERO='0'*64


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

def _sha(value): return hashlib.sha256(_canonical(value)).hexdigest()


def evaluate_readonly_pilot_gate(*, live_report, ingestion_result, drift_alert,
                                 operator_approved=False):
    checks={
        'live_report_passed':isinstance(live_report,dict) and live_report.get('status')=='PASS' and live_report.get('read_only') is True,
        'snapshot_persisted':isinstance(ingestion_result,dict) and ingestion_result.get('status')=='PASS' and bool(ingestion_result.get('snapshot')),
        'training_disabled':isinstance(ingestion_result,dict) and ingestion_result.get('training_allowed') is False,
        'orders_disabled':isinstance(ingestion_result,dict) and ingestion_result.get('live_orders') is False,
        'drift_healthy':isinstance(drift_alert,dict) and drift_alert.get('status')=='HEALTHY',
        'operator_approved':operator_approved is True,
    }
    status='READY_READONLY_PILOT' if all(checks.values()) else 'BLOCKED'
    evidence={'schema_version':'btc-4h-readonly-pilot-gate-v1','status':status,
        'created_at_utc':datetime.now(timezone.utc).isoformat(),'checks':checks,
        'live_report_sha256':_sha(live_report) if isinstance(live_report,dict) else None,
        'ingestion_report_sha256':_sha(ingestion_result) if isinstance(ingestion_result,dict) else None,
        'drift_alert_sha256':_sha(drift_alert) if isinstance(drift_alert,dict) else None,
        'snapshot':ingestion_result.get('snapshot') if isinstance(ingestion_result,dict) else None,
        'training_allowed':False,'live_orders':False,
        'scope':'read_only_market_data_pilot_only_no_model_training_or_order_execution'}
    evidence['evidence_sha256']=_sha(evidence)
    return evidence


def append_readonly_pilot_evidence(evidence: dict, *, log_path):
    if not isinstance(evidence,dict) or evidence.get('schema_version')!='btc-4h-readonly-pilot-gate-v1':
        raise ValueError('readonly_pilot_evidence_invalid')
    body=dict(evidence); declared=body.pop('evidence_sha256',None)
    if not declared or _sha(body)!=declared: raise ValueError('readonly_pilot_evidence_hash_mismatch')
    path=Path(log_path).expanduser(); path.parent.mkdir(parents=True,exist_ok=True)
    rows=[]
    if path.exists():
        for i,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
            try: rows.append(json.loads(line))
            except ValueError as exc: raise ValueError(f'readonly_pilot_log_corrupt_line:{i}') from exc
    previous=ZERO
    for seq,row in enumerate(rows,1):
        record=dict(row); digest=record.pop('record_sha256',None)
        if row.get('sequence')!=seq or row.get('previous_record_sha256')!=previous or not digest or _sha(record)!=digest:
            raise ValueError('readonly_pilot_log_chain_invalid')
        previous=digest
    record={'sequence':len(rows)+1,'previous_record_sha256':previous,'evidence':evidence}
    record['record_sha256']=_sha(record)
    raw=_canonical(record)+b'\n'
    fd=os.open(str(path),os.O_CREAT|os.O_APPEND|os.O_WRONLY,0o600)
    try:
        written=os.write(fd,raw)
        if written!=len(raw): raise OSError('readonly_pilot_log_short_append')
        os.fsync(fd)
    finally: os.close(fd)
    return {'sequence':record['sequence'],'record_sha256':record['record_sha256'],'status':evidence['status']}
