"""
Model storage - persist trained models to a specific folder on disk.
Default location: ~/.trading_ai_models/
Each (symbol, timeframe) gets its own .joblib file.
"""
import os
import json
import time
from pathlib import Path
from datetime import datetime


def get_models_dir(custom_dir: str = None) -> Path:
    """
    Return path to models directory.
    Priority: env var TRADING_AI_MODELS_DIR > custom_dir > ~/.trading_ai_models
    Creates the directory if it doesn't exist.
    """
    env_dir = os.environ.get('TRADING_AI_MODELS_DIR')
    if env_dir:
        p = Path(env_dir).expanduser()
    elif custom_dir:
        p = Path(custom_dir).expanduser()
    else:
        p = Path.home() / '.trading_ai_models'

    p.mkdir(parents=True, exist_ok=True)
    return p


def get_logs_dir() -> Path:
    """Return path to logs directory."""
    p = get_models_dir() / 'logs'
    p.mkdir(parents=True, exist_ok=True)
    return p


def model_path(symbol: str, timeframe: str, custom_dir: str = None) -> Path:
    """Get full path for a (symbol, timeframe) model file."""
    safe_sym = symbol.replace('/', '_').replace('\\', '_')
    fname = f"model_{safe_sym}_{timeframe}.joblib"
    return get_models_dir(custom_dir) / fname


def meta_path(symbol: str, timeframe: str, custom_dir: str = None) -> Path:
    """Path for metadata JSON sidecar."""
    safe_sym = symbol.replace('/', '_').replace('\\', '_')
    fname = f"meta_{safe_sym}_{timeframe}.json"
    return get_models_dir(custom_dir) / fname


def save_meta(symbol: str, timeframe: str, meta: dict, custom_dir: str = None) -> Path:
    """Save metadata JSON next to model file."""
    p = meta_path(symbol, timeframe, custom_dir)
    meta = dict(meta)
    meta['saved_at'] = datetime.now().isoformat(timespec='seconds')
    meta['symbol'] = symbol
    meta['timeframe'] = timeframe
    with open(p, 'w', encoding='utf-8') as f:
        json.dump(meta, f, indent=2, ensure_ascii=False, default=str)
    return p


def load_meta(symbol: str, timeframe: str, custom_dir: str = None) -> dict:
    """Load metadata JSON."""
    p = meta_path(symbol, timeframe, custom_dir)
    if not p.exists():
        return {}
    try:
        with open(p, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def list_saved_models(custom_dir: str = None) -> list:
    """List all saved models with metadata."""
    d = get_models_dir(custom_dir)
    out = []
    for p in sorted(d.glob('meta_*.json')):
        try:
            with open(p, 'r', encoding='utf-8') as f:
                meta = json.load(f)
            out.append({
                'file': p.name,
                'symbol': meta.get('symbol', '?'),
                'timeframe': meta.get('timeframe', '?'),
                'saved_at': meta.get('saved_at', '?'),
                'val_acc': meta.get('val_acc', 0),
                'walk_forward_acc': meta.get('walk_forward_acc', 0),
                'ultra_high_conf_acc': meta.get('ultra_high_conf_acc', 0),
                'calibrated': meta.get('calibrated', False),
                'train_samples': meta.get('train_samples', 0),
                'feature_count': meta.get('feature_count', 0),
                'training_time_sec': meta.get('training_time_sec', 0),
                'iterations': meta.get('iterations', 0),
                'training_round': meta.get('training_round', 1),
                'warm_started': meta.get('warm_started', False),
                'best_threshold': meta.get('best_threshold', None),
                'sim_test_win_rate': (meta.get('sim_test') or {}).get('win_rate', None),
                'sim_test_trades': (meta.get('sim_test') or {}).get('n_trades', None),
            })
        except Exception:
            continue
    return out


def delete_model(symbol: str, timeframe: str, custom_dir: str = None) -> bool:
    """Delete a saved model and its metadata."""
    mp = model_path(symbol, timeframe, custom_dir)
    metap = meta_path(symbol, timeframe, custom_dir)
    deleted = False
    if mp.exists():
        mp.unlink()
        deleted = True
    if metap.exists():
        metap.unlink()
        deleted = True
    return deleted


def delete_all_models(custom_dir: str = None) -> int:
    """Delete all saved models. Returns count."""
    d = get_models_dir(custom_dir)
    count = 0
    for p in d.glob('model_*.joblib'):
        try:
            p.unlink()
            count += 1
        except Exception:
            pass
    for p in d.glob('meta_*.json'):
        try:
            p.unlink()
        except Exception:
            pass
    return count


def write_training_log(symbol: str, timeframe: str, log_text: str,
                       custom_dir: str = None) -> Path:
    """Append training log line to a per-symbol log file."""
    d = get_logs_dir()
    safe_sym = symbol.replace('/', '_')
    p = d / f"train_log_{safe_sym}_{timeframe}.txt"
    ts = datetime.now().isoformat(timespec='seconds')
    with open(p, 'a', encoding='utf-8') as f:
        f.write(f"\n[{ts}]\n{log_text}\n")
    return p


def models_dir_info() -> dict:
    """Return info about the models directory."""
    d = get_models_dir()
    models = list_saved_models()
    total_size = sum(p.stat().st_size for p in d.glob('model_*.joblib'))
    return {
        'path': str(d),
        'models_count': len(models),
        'total_size_mb': round(total_size / (1024 * 1024), 2),
        'models': models,
    }
