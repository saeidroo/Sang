"""V23.0.74 read-only order-book/liquidity behavior evidence analyzer.
Snapshot evidence is not proof of spoofing, intent, or market-maker identity.
"""
from __future__ import annotations
import math


def _num(v):
    if isinstance(v, bool) or v is None:
        return None
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError, OverflowError):
        return None


def _levels(raw, side):
    if not isinstance(raw, list) or not raw or len(raw) > 500:
        return []
    out = []
    for item in raw:
        if isinstance(item, dict):
            p, q = _num(item.get('price')), _num(item.get('qty'))
        elif isinstance(item, (list, tuple)) and len(item) >= 2:
            p, q = _num(item[0]), _num(item[1])
        else:
            continue
        if p is not None and q is not None and p > 0 and q > 0:
            out.append((p, q))
    return sorted(out, key=lambda z: z[0], reverse=(side == 'bids'))


def analyze_liquidity_behavior(candidates):
    if not isinstance(candidates, list):
        raise ValueError('candidates must be a list')
    results = []
    for raw in candidates[:100]:
        if not isinstance(raw, dict):
            results.append({'decision': 'INSUFFICIENT_DATA', 'reasons': ['INVALID_CANDIDATE'], 'score': 0})
            continue
        bids, asks = _levels(raw.get('bids'), 'bids'), _levels(raw.get('asks'), 'asks')
        reasons, warnings, evidence, score = [], [], {}, 0
        symbol = str(raw.get('symbol') or '').upper().strip()
        exchange = str(raw.get('exchange') or '').strip()
        if not symbol or not exchange:
            reasons.append('IDENTITY_MISSING')
        if not bids or not asks:
            warnings.append('ORDER_BOOK_MISSING_OR_INVALID')
        else:
            bb, ba = bids[0][0], asks[0][0]
            mid = (bb + ba) / 2
            spread = (ba - bb) / mid * 10000 if mid else None
            if ba <= bb:
                reasons.append('CROSSED_OR_INVALID_BOOK')
            elif spread is not None:
                evidence['spread_bps'] = round(spread, 4)
                if spread <= 35: score += 15
                else: reasons.append('WIDE_SPREAD')
            bvol, avol = sum(q for _, q in bids[:10]), sum(q for _, q in asks[:10])
            total = bvol + avol
            imbalance = (bvol - avol) / total if total else 0
            evidence.update({'best_bid': bb, 'best_ask': ba, 'bid_depth_10': bvol,
                             'ask_depth_10': avol, 'depth_imbalance': round(imbalance, 4)})
            if abs(imbalance) >= .20: score += 20
            else: warnings.append('NO_CLEAR_DEPTH_IMBALANCE')
            # A single oversized level is a wall concentration, not proof of spoofing.
            for label, levels, depth in [('bid', bids, bvol), ('ask', asks, avol)]:
                concentration = levels[0][1] / depth if depth else 0
                evidence[label + '_top_level_concentration'] = round(concentration, 4)
                if concentration >= .55:
                    warnings.append(label.upper() + '_WALL_CONCENTRATION')
            prior = raw.get('previous_book')
            if isinstance(prior, dict):
                pb = _levels(prior.get('bids'), 'bids'); pa = _levels(prior.get('asks'), 'asks')
                if pb and pa:
                    def wall_share(levels):
                        depth = sum(q for _, q in levels[:10])
                        return max((q / depth for _, q in levels[:10]), default=0) if depth else 0
                    unstable = max(abs(wall_share(bids)-wall_share(pb)), abs(wall_share(asks)-wall_share(pa)))
                    evidence['wall_concentration_change'] = round(unstable, 4)
                    if unstable >= .20: warnings.append('RAPID_WALL_CHANGE_POSSIBLE_CANCEL_OR_REFRESH')
                else: warnings.append('PREVIOUS_BOOK_INVALID')
            else:
                warnings.append('SPOOFING_NOT_ASSESSABLE_FROM_SINGLE_SNAPSHOT')
        trades = raw.get('recent_trades')
        if isinstance(trades, list) and trades:
            buy = sell = 0.0
            valid = 0
            for t in trades[:1000]:
                if not isinstance(t, dict): continue
                qty = _num(t.get('qty'))
                side = str(t.get('side') or '').lower()
                if qty is None or qty <= 0: continue
                if side in ('buy', 'b', 'buyer'): buy += qty; valid += 1
                elif side in ('sell', 's', 'seller'): sell += qty; valid += 1
            if valid:
                ratio = buy / sell if sell > 0 else (99.0 if buy > 0 else 1.0)
                evidence.update({'aggressive_buy_volume': buy, 'aggressive_sell_volume': sell,
                                 'aggressive_buy_sell_ratio': round(ratio, 4)})
                if ratio >= 1.5: score += 15
                elif ratio <= 1/1.5: score += 5
                else: warnings.append('NO_DOMINANT_AGGRESSOR')
                move = _num(raw.get('price_change_during_trades_pct'))
                if move is not None and abs(move) <= .15 and abs(ratio-1) >= .8:
                    warnings.append('POSSIBLE_ABSORPTION_REQUIRES_CONFIRMATION')
                if move is not None and abs(move) >= 1.0 and (ratio >= 2 or ratio <= .5):
                    warnings.append('AGGRESSIVE_FLOW_WITH_PRICE_DISPLACEMENT_POSSIBLE_SWEEP')
            else: warnings.append('TRADE_TAPE_INVALID')
        else: warnings.append('TRADE_TAPE_UNAVAILABLE')
        decision = 'INSUFFICIENT_DATA' if not bids or not asks else ('CAUTION' if reasons else ('WATCH' if score >= 30 else 'LOW_CONFIDENCE'))
        results.append({'symbol': symbol, 'exchange': exchange, 'decision': decision,
                        'score': min(score, 100), 'reasons': reasons, 'warnings': warnings,
                        'evidence': evidence, 'entry_authorized': False, 'execution_authorized': False})
    return {'version': '23.0.74', 'count': len(results), 'results': results,
            'paper_only': True, 'capital_usdt': 1000, 'entry_authorized': False,
            'execution_authorized': False, 'creates_orders': False, 'real_orders_enabled': False,
            'disclaimer': 'تحلیل دفتر سفارش و معاملات صرفاً شواهد لحظه‌ای است؛ spoofing، جذب سفارش یا هویت بازارساز را اثبات نمی‌کند.'}
