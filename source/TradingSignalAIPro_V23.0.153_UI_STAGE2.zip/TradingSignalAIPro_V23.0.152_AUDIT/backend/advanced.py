"""Research utilities: regime, horizons, pattern diagnostics, strategy lab and paper trading.
These are decision-support tools, not execution or profit guarantees.
"""
from __future__ import annotations
import json, math, os, sqlite3, time
from pathlib import Path
from typing import Dict, Any
import numpy as np
import pandas as pd


def market_regime(df: pd.DataFrame, timeframe: str = '1h') -> Dict[str, Any]:
    c = pd.to_numeric(df['close'], errors='coerce').dropna()
    if len(c) < 60:
        return {'regime':'unknown','confidence':0.0,'reason':'حداقل ۶۰ کندل لازم است'}
    ret = c.pct_change().dropna()
    periods_per_year = {'5m': 365*24*12, '15m': 365*24*4, '30m': 365*24*2, '1h': 365*24, '4h': 365*6, '1d': 365}.get(str(timeframe), 365*24)
    vol = float(ret.tail(30).std() * math.sqrt(periods_per_year))
    ma20, ma50 = float(c.rolling(20).mean().iloc[-1]), float(c.rolling(50).mean().iloc[-1])
    slope = float((c.iloc[-1] / c.iloc[-20] - 1) * 100)
    if vol > 1.2:
        regime = 'high_volatility'
    elif ma20 > ma50 * 1.005 and slope > 0.5:
        regime = 'bull'
    elif ma20 < ma50 * 0.995 and slope < -0.5:
        regime = 'bear'
    else:
        regime = 'sideways'
    strength = min(1.0, abs(slope)/5 + abs(ma20/ma50-1)*20)
    return {'regime':regime,'confidence':round(float(strength),3),'annualized_volatility':round(vol,4),'slope_20_pct':round(slope,3),'ma20':ma20,'ma50':ma50}


def multi_horizon_outlook(df: pd.DataFrame, horizons=(1, 4, 24, 72)) -> Dict[str, Any]:
    c = pd.to_numeric(df['close'], errors='coerce').dropna()
    if len(c) < 60: return {'error':'حداقل ۶۰ کندل لازم است'}
    r = c.pct_change().dropna(); drift=float(r.tail(30).mean()); vol=float(r.tail(30).std() or 0)
    rows=[]
    for h in horizons:
        mu=drift*int(h); sigma=vol*math.sqrt(int(h))
        rows.append({'bars':int(h),'expected_change_pct':round(mu*100,3),'lower_95_pct':round((mu-1.96*sigma)*100,3),'upper_95_pct':round((mu+1.96*sigma)*100,3),'method':'rolling-drift baseline'})
    return {'outlooks':rows,'warning':'برآورد آماری ساده از بازده اخیر است؛ پیش‌بینی مدل آموزش‌دیده نیست.'}


def detect_patterns(df: pd.DataFrame) -> list:
    if len(df)<3: return []
    x=df.tail(3).reset_index(drop=True); out=[]
    for i,row in x.iterrows():
        o,h,l,c=map(float,(row.open,row.high,row.low,row.close)); body=abs(c-o); span=max(h-l,1e-12)
        upper=h-max(o,c); lower=min(o,c)-l
        if body/span < .1: out.append({'pattern':'doji','bar':i-2,'bias':'indecision'})
        if lower > body*2 and upper < body: out.append({'pattern':'hammer_like','bar':i-2,'bias':'potential_bullish_reversal'})
        if upper > body*2 and lower < body: out.append({'pattern':'shooting_star_like','bar':i-2,'bias':'potential_bearish_reversal'})
    if len(x)>=2:
        a,b=x.iloc[-2],x.iloc[-1]
        if a.close<a.open and b.close>b.open and b.open<=a.close and b.close>=a.open:
            out.append({'pattern':'bullish_engulfing','bar':0,'bias':'potential_bullish_reversal'})
        if a.close>a.open and b.close<b.open and b.open>=a.close and b.close<=a.open:
            out.append({'pattern':'bearish_engulfing','bar':0,'bias':'potential_bearish_reversal'})
    return out


def early_trend_change(df: pd.DataFrame) -> Dict[str, Any]:
    c=pd.to_numeric(df.close,errors='coerce').dropna()
    if len(c)<60:return {'warning':'حداقل ۶۰ کندل لازم است','state':'unknown'}
    fast=c.ewm(span=8).mean(); slow=c.ewm(span=21).mean(); momentum=c.pct_change(5)
    cross_up=fast.iloc[-1]>slow.iloc[-1] and fast.iloc[-2]<=slow.iloc[-2]
    cross_dn=fast.iloc[-1]<slow.iloc[-1] and fast.iloc[-2]>=slow.iloc[-2]
    state='bullish_shift_watch' if cross_up else 'bearish_shift_watch' if cross_dn else 'no_confirmed_shift'
    return {'state':state,'momentum_5_pct':round(float(momentum.iloc[-1]*100),3),'fast_slow_gap_pct':round(float((fast.iloc[-1]/slow.iloc[-1]-1)*100),3),'warning':'هشدار زودهنگام است و ممکن است سیگنال کاذب باشد؛ تأیید روند محسوب نمی‌شود.'}


def strategy_lab(df: pd.DataFrame, fee_bps: float = 10.0,
                 slippage_bps: float = 5.0) -> Dict[str, Any]:
    """Compare a few EMA rules without selecting on the reported holdout.

    Hyperparameters are ranked only on the first 70% (training block). The
    final 30% is reported as a chronological holdout and never determines the
    selected row. Returns include turnover-based fee/slippage estimates.
    """
    c = pd.to_numeric(df['close'], errors='coerce').replace([np.inf, -np.inf], np.nan).dropna()
    if len(c) < 250:
        return {'error': 'برای مقایسه حداقل ۲۵۰ کندل لازم است'}
    if not (math.isfinite(float(fee_bps)) and math.isfinite(float(slippage_bps))
            and 0 <= fee_bps <= 500 and 0 <= slippage_bps <= 500):
        raise ValueError('کارمزد و لغزش باید بین صفر تا ۵۰۰ واحد پایه باشند')

    split = int(len(c) * 0.70)
    cost_rate = (float(fee_bps) + float(slippage_bps)) / 10000.0
    configs = [(8, 21), (12, 36), (20, 50)]
    results = []

    def score_block(position: pd.Series, returns: pd.Series) -> dict:
        turnover = position.diff().abs()
        if len(turnover):
            turnover.iloc[0] = abs(float(position.iloc[0]))
            # Charge an exit at the end of the measured block as well.
            turnover.iloc[-1] += abs(float(position.iloc[-1]))
        net = position * returns - turnover.fillna(0) * cost_rate
        equity = (1 + net.clip(lower=-0.99)).cumprod()
        peak = equity.cummax().clip(lower=1e-12)
        drawdown = equity / peak - 1
        total = float((equity.iloc[-1] - 1) * 100) if len(equity) else 0.0
        max_dd = float(drawdown.min() * 100) if len(drawdown) else 0.0
        score = total - 0.5 * abs(max_dd)
        return {'return_pct': round(total, 3), 'max_drawdown_pct': round(max_dd, 3),
                'turnover_events': int((turnover.fillna(0) > 1e-9).sum()),
                'cost_pct': round(float((turnover.fillna(0) * cost_rate).sum() * 100), 3),
                'selection_score': round(score, 3)}

    returns = c.pct_change().replace([np.inf, -np.inf], np.nan).fillna(0.0)
    for fast_n, slow_n in configs:
        fast = c.ewm(span=fast_n, adjust=False).mean()
        slow = c.ewm(span=slow_n, adjust=False).mean()
        # A signal calculated at bar t may only be held from bar t+1 onward.
        position = (fast > slow).astype(float).shift(1).fillna(0.0)
        train_metrics = score_block(position.iloc[:split], returns.iloc[:split])
        test_metrics = score_block(position.iloc[split:], returns.iloc[split:])
        results.append({'strategy': f'EMA {fast_n}/{slow_n}',
                        'training': train_metrics, 'holdout': test_metrics,
                        'buy_hold_holdout_return_pct': round(float((
                            (1 + returns.iloc[split:]).clip(lower=0.01).prod()
                            * max(0.01, 1 - cost_rate) ** 2 - 1) * 100), 3)})

    # Selection is deliberately based on training metrics, never holdout return.
    results.sort(key=lambda row: row['training']['selection_score'], reverse=True)
    return {
        'selection': 'training_block_only', 'best': results[0], 'results': results,
        'train_bars': int(split), 'holdout_bars': int(len(c) - split),
        'fee_bps_per_side': float(fee_bps), 'slippage_bps_per_side': float(slippage_bps),
        'limitations': [
            'فقط سه تنظیم EMA بررسی می‌شود؛ این ابزار جایگزین آزمون مستقل بلندمدت نیست',
            'کارمزد و لغزش به‌صورت تقریبی و بر اساس گردش موقعیت محاسبه شده‌اند',
            'بازده گذشته تضمین عملکرد آینده نیست',
        ],
    }


def risk_plan(equity: float, risk_pct: float, entry: float, stop: float) -> Dict[str, Any]:
    vals=[equity,risk_pct,entry,stop]
    if not all(math.isfinite(float(v)) for v in vals) or equity<=0 or not 0<risk_pct<=5 or entry<=0 or stop<=0 or entry==stop:
        raise ValueError('ورودی ریسک نامعتبر است؛ ریسک باید بین ۰ تا ۵ درصد باشد و حدضرر با ورود متفاوت باشد')
    risk_cash=equity*risk_pct/100; qty=risk_cash/abs(entry-stop)
    return {'risk_cash':risk_cash,'position_quantity':qty,'position_notional':qty*entry,'risk_pct':risk_pct,'warning':'محاسبه آموزشی؛ کارمزد، لغزش، اهرم و ریسک شکاف قیمت لحاظ نشده‌اند.'}


def _db_path():
    p=Path(os.getenv('TRADING_AI_PAPER_DB',str(Path.home()/'.trading_ai_models'/'paper_trading.sqlite3'))).expanduser(); p.parent.mkdir(parents=True,exist_ok=True); return p

def paper_init():
    with sqlite3.connect(_db_path()) as c:
        c.execute('CREATE TABLE IF NOT EXISTS trades(id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, symbol TEXT, side TEXT, qty REAL, entry REAL, stop REAL, note TEXT, status TEXT DEFAULT \'OPEN\', exit REAL, pnl REAL)')

def paper_open(symbol,side,qty,entry,stop,note=''):
    import re
    symbol=str(symbol).upper().strip()
    side=str(side).upper()
    qty,entry,stop=map(float,(qty,entry,stop))
    if not re.fullmatch(r'[A-Z0-9]{2,20}', symbol):
        raise ValueError('نماد معامله نامعتبر است')
    if (side not in ('LONG','SHORT') or not all(math.isfinite(v) for v in (qty,entry,stop))
        or min(qty,entry,stop)<=0 or (side=='LONG' and stop>=entry)
        or (side=='SHORT' and stop<=entry)):
        raise ValueError('مشخصات معامله نامعتبر است؛ حدضرر LONG باید پایین‌تر از ورود و حدضرر SHORT بالاتر از ورود باشد')
    paper_init()
    with sqlite3.connect(_db_path()) as c:
        cur=c.execute('INSERT INTO trades(ts,symbol,side,qty,entry,stop,note) VALUES(?,?,?,?,?,?,?)',(time.time(),symbol,side,qty,entry,stop,str(note)[:500]))
        return {'id':cur.lastrowid,'status':'OPEN'}

def paper_close(trade_id,exit_price):
    exit_price=float(exit_price)
    if not math.isfinite(exit_price) or exit_price<=0:
        raise ValueError('قیمت خروج باید عددی مثبت و معتبر باشد')
    with sqlite3.connect(_db_path(), timeout=10) as c:
        c.execute('BEGIN IMMEDIATE')
        row = c.execute("SELECT side,qty,entry,status FROM trades WHERE id=?", (int(trade_id),)).fetchone()
        if not row:
            raise ValueError('معامله پیدا نشد')
        side, qty, entry, status = row
        if status != 'OPEN':
            raise ValueError('معامله قبلاً بسته شده است')
        pnl = (float(exit_price) - entry) * qty * (1 if side == 'LONG' else -1)
        cur = c.execute("UPDATE trades SET status='CLOSED',exit=?,pnl=? WHERE id=? AND status='OPEN'",
                        (exit_price, pnl, int(trade_id)))
        if cur.rowcount != 1:
            raise ValueError('معامله هم‌زمان توسط درخواست دیگری بسته شده است')
        return {'id': int(trade_id), 'status': 'CLOSED', 'pnl': pnl}

def paper_list():
    paper_init()
    with sqlite3.connect(_db_path()) as c:
        c.row_factory=sqlite3.Row
        rows=[dict(r) for r in c.execute('SELECT * FROM trades ORDER BY id DESC LIMIT 300')]
    return {'trades':rows,'database':str(_db_path())}


def paper_stats():
    paper_init()
    with sqlite3.connect(_db_path()) as c:
        rows=c.execute("SELECT symbol,side,COUNT(*),SUM(CASE WHEN pnl>0 THEN 1 ELSE 0 END),SUM(COALESCE(pnl,0)),AVG(pnl) FROM trades WHERE status='CLOSED' GROUP BY symbol,side").fetchall()
        totals=c.execute("SELECT COUNT(*),SUM(CASE WHEN pnl>0 THEN 1 ELSE 0 END),SUM(COALESCE(pnl,0)),AVG(pnl) FROM trades WHERE status='CLOSED'").fetchone()
    return {'closed_trades':int(totals[0] or 0),'wins':int(totals[1] or 0),'net_pnl':float(totals[2] or 0),'average_pnl':float(totals[3] or 0),'win_rate':(float(totals[1] or 0)/int(totals[0])) if totals[0] else None,'by_symbol_side':[{'symbol':r[0],'side':r[1],'trades':r[2],'wins':r[3],'net_pnl':float(r[4] or 0),'average_pnl':float(r[5] or 0)} for r in rows]}


def derivatives_snapshot(symbol: str) -> Dict[str, Any]:
    """Best-effort Binance USD-M public derivatives context; crypto symbols only.

    Endpoints are requested concurrently with strict timeouts so one slow endpoint
    does not serialize the full central-brain analysis. Missing fields are omitted.
    """
    import requests
    import re
    from concurrent.futures import ThreadPoolExecutor, as_completed

    s = str(symbol).upper().replace('/', '').strip()
    if not re.fullmatch(r'[A-Z0-9]{3,20}USDT', s):
        return {'available': False, 'reason': 'نماد باید یک جفت معتبر با پسوند USDT باشد'}
    base = 'https://fapi.binance.com/fapi/v1/'
    endpoints = {
        'open_interest': ('openInterest', {}),
        'premium': ('premiumIndex', {}),
        'agg_trades': ('aggTrades', {'limit': 500}),
        'depth': ('depth', {'limit': 20}),
    }
    def get_one(name, spec):
        path, params = spec
        response = requests.get(base + path, params={'symbol': s, **params}, timeout=5)
        response.raise_for_status()
        return name, response.json(), None
    responses, errors = {}, {}
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(get_one, name, spec): name for name, spec in endpoints.items()}
        for future in as_completed(futures):
            endpoint_name = futures[future]
            try:
                name, payload, _ = future.result()
                responses[name] = payload
            except Exception as exc:
                errors[endpoint_name] = str(exc)[:160]
    out = {'available': bool(responses), 'source': 'Binance USD-M public endpoints', 'errors': errors}
    oi = responses.get('open_interest')
    premium = responses.get('premium')
    if isinstance(oi, dict):
        out['open_interest'] = oi.get('openInterest')
    if isinstance(premium, dict):
        out['funding_rate'] = premium.get('lastFundingRate')
    trades = responses.get('agg_trades')
    if isinstance(trades, list):
        try:
            notionals = [float(t.get('p', 0)) * float(t.get('q', 0)) for t in trades]
            threshold = max(100000.0, float(np.percentile(notionals, 95)) * 3 if notionals else 100000.0)
            large = [t for t, n in zip(trades, notionals) if n >= threshold]
            buy = sum(float(t.get('p', 0)) * float(t.get('q', 0)) for t in large if not t.get('m', False))
            sell = sum(float(t.get('p', 0)) * float(t.get('q', 0)) for t in large if t.get('m', False))
            out['large_trade_flow'] = {
                'large_trade_count': len(large), 'buy_notional': buy, 'sell_notional': sell,
                'net_buy_notional': buy - sell, 'threshold_usdt': threshold,
                'note': 'تقریب جریان معاملات بزرگ از aggTrades؛ شناسایی هویت نهنگ یا کیف‌پول نیست.'}
        except Exception as exc:
            out['large_trade_flow_error'] = str(exc)[:160]
    depth = responses.get('depth')
    if isinstance(depth, dict):
        try:
            bids = sum(float(x[1]) for x in depth.get('bids', []))
            asks = sum(float(x[1]) for x in depth.get('asks', []))
            out['order_book_imbalance'] = (bids - asks) / (bids + asks) if bids + asks else None
        except Exception as exc:
            out['order_book_error'] = str(exc)[:160]
    if not responses:
        out['reason'] = 'داده مشتقات از منبع عمومی در دسترس نبود'
    return out

