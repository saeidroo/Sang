"""Final controlled read-only pilot handoff gate; never enables training or orders."""
from __future__ import annotations
import hashlib,json,os
from pathlib import Path
from backend.btc_live_environment_validation import _canonical
from backend.btc_live_validation_review import load_live_validation_report,verify_live_validation_review
from backend.btc_readonly_rolling_slo import verify_readonly_rolling_slo
from backend.btc_readonly_incident_export import verify_incident_export_bundle
from backend.btc_readonly_incident_recovery import verify_incident_witness_receipt,run_incident_recovery_drill


def verify_recovery_drill_report(report, *, bundle_sha256=None):
    if not isinstance(report,dict): raise ValueError('handoff_recovery_report_invalid')
    payload=dict(report); supplied=payload.pop('report_sha256',None)
    actual=hashlib.sha256(_canonical(payload)).hexdigest()
    if supplied!=actual: raise ValueError('handoff_recovery_report_hash_mismatch')
    if report.get('restore_verification_passed') is not True or report.get('tamper_detection_passed') is not True:
        raise ValueError('handoff_recovery_drill_not_passed')
    if report.get('training_allowed') is not False or report.get('live_orders') is not False:
        raise ValueError('handoff_recovery_safety_flags_invalid')
    if bundle_sha256 and report.get('bundle_sha256')!=bundle_sha256:
        raise ValueError('handoff_recovery_bundle_mismatch')
    return {'valid':True,'sha256':actual}


def build_readonly_handoff(*, live_report_paths, operator_review_path, rolling_slo_path,
        incident_bundle_path, witness_receipt_path, witness_public_key_path,
        recovery_dir, highwater_path, operator_approved=False, output_path=None):
    blockers=[]; checks={}; reports=[]; recovery=None
    try:
        reports=[load_live_validation_report(p) for p in live_report_paths]
        checks['live_reports']={'valid':True,'count':len(reports),'digests':[r['report_sha256'] for r in reports]}
        if not reports or any(r.get('status')!='PASS' for r in reports): blockers.append('live_validation_reports_not_all_pass')
    except Exception as exc: blockers.append(f'live_reports:{type(exc).__name__}:{exc}')
    try:
        review=json.loads(Path(operator_review_path).read_text(encoding='utf-8'))
        verify_live_validation_review(review)
        checks['operator_review']={'valid':True,'decision':review['decision']}
        if review.get('decision')!='ACCEPT_READONLY': blockers.append('operator_review_not_accepted')
        if reports and review.get('report_digests')!=[r['report_sha256'] for r in reports]: blockers.append('operator_review_report_set_mismatch')
    except Exception as exc: blockers.append(f'operator_review:{type(exc).__name__}:{exc}')
    try:
        slo=json.loads(Path(rolling_slo_path).read_text(encoding='utf-8'))
        verify_readonly_rolling_slo(slo)
        checks['rolling_slo']={'valid':True,'decision':slo['decision']}
        if slo.get('decision')!='CONTINUE_READONLY': blockers.append('rolling_slo_not_continue_readonly')
        if reports and slo.get('report_digests')!=[r['report_sha256'] for r in reports]: blockers.append('rolling_slo_report_set_mismatch')
    except Exception as exc: blockers.append(f'rolling_slo:{type(exc).__name__}:{exc}')
    try:
        bundle=verify_incident_export_bundle(incident_bundle_path)
        checks['incident_bundle']={'valid':True,'bundle_sha256':bundle['bundle_sha256'],'event_count':bundle['event_count']}
        receipt=json.loads(Path(witness_receipt_path).read_text(encoding='utf-8'))
        receipt_check=verify_incident_witness_receipt(incident_bundle_path,receipt,
            pinned_public_key_path=witness_public_key_path,highwater_path=highwater_path)
        checks['witness_receipt']=receipt_check
        recovery=run_incident_recovery_drill(incident_bundle_path,receipt,
            pinned_public_key_path=witness_public_key_path,highwater_path=highwater_path,
            recovery_dir=recovery_dir)
        verify_recovery_drill_report(recovery,bundle_sha256=bundle['bundle_sha256'])
        checks['recovery_drill']={'valid':True,'report_sha256':recovery['report_sha256'],
            'restore_verification_passed':True,'tamper_detection_passed':True}
    except Exception as exc: blockers.append(f'incident_witness_recovery:{type(exc).__name__}:{exc}')
    if operator_approved is not True: blockers.append('final_operator_approval_missing')
    decision='GO_READONLY' if not blockers else 'NO_GO'
    result={'schema':'tekar.btc4h.readonly_pilot_handoff.v1',
        'decision':decision,'created_at_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
        'checks':checks,'blockers':blockers,'final_operator_approved':operator_approved is True,
        'recovery_report':recovery,'scope':'controlled_read_only_pilot_only',
        'training_allowed':False,'paper_execution_allowed':False,'live_orders':False}
    result['handoff_sha256']=hashlib.sha256(_canonical(result)).hexdigest()
    if output_path is not None:
        path=Path(output_path); path.parent.mkdir(parents=True,exist_ok=True)
        raw=_canonical(result)+b'\n'; fd=os.open(str(path),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        with os.fdopen(fd,'wb') as f: f.write(raw); f.flush(); os.fsync(f.fileno())
    return result


def verify_readonly_handoff(result):
    if not isinstance(result,dict): raise ValueError('readonly_handoff_invalid')
    payload=dict(result); supplied=payload.pop('handoff_sha256',None)
    actual=hashlib.sha256(_canonical(payload)).hexdigest()
    if supplied!=actual: raise ValueError('readonly_handoff_hash_mismatch')
    if result.get('decision') not in ('GO_READONLY','NO_GO'): raise ValueError('readonly_handoff_decision_invalid')
    if result.get('training_allowed') is not False or result.get('paper_execution_allowed') is not False or result.get('live_orders') is not False:
        raise ValueError('readonly_handoff_safety_flags_invalid')
    if result['decision']=='GO_READONLY' and result.get('blockers'):
        raise ValueError('readonly_handoff_go_with_blockers')
    if result['decision']=='GO_READONLY' and result.get('final_operator_approved') is not True:
        raise ValueError('readonly_handoff_go_without_operator_approval')
    return {'valid':True,'decision':result['decision'],'sha256':actual}
