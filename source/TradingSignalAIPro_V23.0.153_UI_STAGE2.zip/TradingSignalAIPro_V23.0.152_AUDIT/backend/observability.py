"""V22 observability primitives: append-only events and read-only summaries."""
from __future__ import annotations
import json, os, threading, uuid
from datetime import datetime, timezone
from pathlib import Path
from .storage import get_models_dir

_LOCK = threading.RLock()

def _now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def _event_path(custom_dir=None):
    root = Path(custom_dir).expanduser() if custom_dir else Path(get_models_dir())
    path = root / 'observability' / 'events.jsonl'
    path.parent.mkdir(parents=True, exist_ok=True)
    return path

def record_event(event_type, *, component='app', status='INFO', details=None, duration_ms=None, custom_dir=None):
    if not str(event_type).strip(): raise ValueError('event_type is required')
    item = {'event_id': str(uuid.uuid4()), 'timestamp': _now(), 'event_type': str(event_type),
            'component': str(component), 'status': str(status).upper(), 'details': details or {}}
    if duration_ms is not None: item['duration_ms'] = max(0.0, float(duration_ms))
    path = _event_path(custom_dir)
    line = (json.dumps(item, ensure_ascii=False, sort_keys=True, default=str) + '\n').encode()
    with _LOCK:
        fd = os.open(str(path), os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
        try: os.write(fd, line); os.fsync(fd)
        finally: os.close(fd)
    return item

def read_events(limit=100, custom_dir=None):
    limit = max(1, min(int(limit), 1000)); path = _event_path(custom_dir)
    if not path.exists(): return []
    rows=[]
    for line in path.read_text(encoding='utf-8', errors='replace').splitlines()[-limit:]:
        try:
            obj=json.loads(line)
            if isinstance(obj,dict): rows.append(obj)
        except (ValueError, TypeError): continue
    return rows[::-1]

def event_summary(custom_dir=None):
    rows=read_events(1000, custom_dir); counts={}; errors=0
    for row in rows:
        key=f"{row.get('component','app')}:{row.get('status','INFO')}"
        counts[key]=counts.get(key,0)+1
        if row.get('status') in {'ERROR','CRITICAL','FAILED'}: errors+=1
    return {'events_sampled':len(rows),'error_events_sampled':errors,'counts':counts,'latest_event':rows[0] if rows else None}
