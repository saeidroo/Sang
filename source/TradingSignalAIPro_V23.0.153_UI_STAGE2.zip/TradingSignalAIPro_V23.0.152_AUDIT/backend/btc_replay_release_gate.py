"""Fail-closed release gate for BTC 4h replay trust/operations evidence."""
from __future__ import annotations
from backend.btc_replay_trust_backup import audit_replay_trust_store
from backend.btc_replay_recovery import audit_replay_anchor_consistency


def evaluate_replay_trust_release_gate(*, registry_dir, anchor_path, signed_anchor,
                                       witness_receipt, witness_public_key_pem=None,
                                       high_water_path, trust_dir=None):
    checks={}
    errors=[]
    trust=audit_replay_trust_store(trust_dir=trust_dir)
    checks['trust_store_healthy']=bool(trust.get('healthy'))
    if not checks['trust_store_healthy']:
        errors.extend(trust.get('errors',[]))
    try:
        consistency=audit_replay_anchor_consistency(registry_dir=registry_dir,
            anchor_path=anchor_path,signed_anchor=signed_anchor,
            witness_receipt=witness_receipt,witness_public_key_pem=witness_public_key_pem,
            state_path=high_water_path)
        checks['local_external_signed_witness_consistent']=consistency.get('status')=='PASS' and bool(consistency.get('witness',{}).get('valid'))
        if not checks['local_external_signed_witness_consistent']:
            errors.append('replay_anchor_consistency_not_pass')
    except Exception as exc:
        consistency=None
        checks['local_external_signed_witness_consistent']=False
        errors.append(f'{type(exc).__name__}:{exc}')
    status='READY' if all(checks.values()) else 'BLOCKED'
    return {'schema_version':'btc-4h-replay-release-gate-v1','status':status,
            'checks':checks,'errors':errors,'trust_store':trust,
            'consistency':consistency,
            'scope':'integrity_and_operations_only_not_model_accuracy_or_live_trading_authorization'}
