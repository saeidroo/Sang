"""Small historical-pattern brain for Storm Scout.

Uses archived, completed 1h OHLCV candles only. It compares the current
market state with historical states and reports empirical outcomes; it does
not invent prices or issue trading instructions.
"""
from __future__ import annotations
import os
import sqlite3
import time
import json
import math
import os
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

try:
    import numpy as _np
except ImportError:  # A correctness-preserving pure-Python fallback remains available.
    _np = None

HISTORY_DB_PATH = Path(os.getenv(
    'TRADING_AI_HISTORY_DB',
    str(Path.home() / '.trading_ai_models' / 'history' / 'candles.sqlite3')
)).expanduser()
MIN_ANALOGS = 8
MAX_CANDLES = 250_000
HISTORY_SCAN_VERSION = '9'
HOURLY_TIMEFRAME_ALIASES = ('1h', '60m', '1hour', '1hr')
FEEDBACK_DB_PATH = Path(os.getenv('TRADING_AI_BRAIN_FEEDBACK_DB', str(HISTORY_DB_PATH.with_name('market_brain_feedback.sqlite3')))).expanduser()
FEEDBACK_HORIZONS = {'1h': 3600, '4h': 14400, '24h': 86400}
DIRECTIONAL_SIGNAL_HORIZONS = {'1h': 3600, '4h': 14400, '24h': 86400, '3d': 259200, '7d': 604800}
HISTORY_EXTREME_PCT = 10.0
_STARTUP_STATE = {'status': 'not_started', 'stage': 'idle', 'progress_pct': 0, 'symbols_done': 0, 'symbols_total': 0, 'workers': 0, 'accelerator': 'numpy' if _np is not None else 'python', 'started_ts': None, 'finished_ts': None, 'symbols': 0, 'candles': 0, 'pump_events': 0, 'dump_events': 0, 'patterns': 0, 'invalid_rows': 0, 'duplicate_timestamp_groups': 0, 'gap_breaks': 0, 'segments': 0, 'cache_hit': False, 'error': None}
_STARTUP_LOCK = __import__('threading').Lock()
_PREDICTION_CACHE_LOCK = __import__('threading').RLock()
_PREDICTION_CACHE = {'fingerprint': None, 'grouped': None, 'cross_asset_analogs': None, 'archive_quality': None, 'built_ts': None, 'next_close_ts': None, 'row_count': 0}


def _archive_fingerprint(path: str | Path) -> str:
    """Fingerprint the SQLite archive including uncheckpointed WAL writes.

    The historical data lake uses SQLite WAL mode. New committed candles may
    live in ``<db>-wal`` while the main database file's size and mtime remain
    unchanged. Ignoring the WAL can incorrectly reuse stale pump/dump counts.
    """
    archive = Path(path).expanduser().resolve()

    def stamp(candidate: Path) -> str:
        try:
            stat = candidate.stat()
        except FileNotFoundError:
            return 'absent'
        return ':'.join((str(stat.st_dev), str(stat.st_ino),
                         str(stat.st_size), str(stat.st_mtime_ns)))

    wal = Path(str(archive) + '-wal')
    return f'{HISTORY_SCAN_VERSION}:{archive}:{stamp(archive)}:wal={stamp(wal)}'


def _prepare_hourly_segments(rows, presorted: bool = False):
    """Validate hourly OHLCV rows, deduplicate timestamps and split at gaps.

    Input rows use the archive layout (symbol, t_ms, open, high, low, close,
    volume). No labels are allowed to look across a missing or malformed hour.
    When the SQL source is already ordered by timestamp, ``presorted=True``
    avoids a redundant O(n log n) sort; the order is still checked defensively.
    """
    valid = []
    invalid_rows = 0
    for row in rows:
        try:
            raw_t = float(row[1])
            values = [float(row[i]) for i in range(2, 7)]
            if (not raw_t.is_integer() or raw_t <= 0
                    or any(not math.isfinite(v) for v in values)):
                raise ValueError('invalid timestamp or non-finite OHLCV')
            ts = int(raw_t)
            op, high, low, close, volume = values
            if (min(op, high, low, close) <= 0 or volume < 0
                    or high < max(op, close, low) or low > min(op, close, high)):
                raise ValueError('invalid OHLCV bounds')
            valid.append((row[0], ts, op, high, low, close, volume))
        except (TypeError, ValueError, IndexError, OverflowError):
            invalid_rows += 1

    ordered = bool(presorted)
    if ordered:
        ordered = all(valid[i][1] <= valid[i + 1][1] for i in range(len(valid) - 1))
    if not ordered:
        valid.sort(key=lambda r: int(r[1]))

    # Group duplicates in one linear pass. Exact duplicates collapse to one;
    # conflicting groups are discarded in full, matching the Stage 8 policy.
    deduplicated = []
    duplicate_groups = 0
    index = 0
    while index < len(valid):
        end = index + 1
        timestamp = valid[index][1]
        while end < len(valid) and valid[end][1] == timestamp:
            end += 1
        candidates = valid[index:end]
        if len(candidates) > 1:
            duplicate_groups += 1
            first = candidates[0]
            if all(tuple(candidate[2:]) == tuple(first[2:]) for candidate in candidates[1:]):
                deduplicated.append(first)
            else:
                invalid_rows += len(candidates)
        else:
            deduplicated.append(candidates[0])
        index = end

    segments = []
    current = []
    gap_breaks = 0
    for row in deduplicated:
        if current and int(row[1]) - int(current[-1][1]) != 3_600_000:
            segments.append(current)
            current = []
            gap_breaks += 1
        current.append(row)
    if current:
        segments.append(current)
    return segments, {
        'invalid_rows': invalid_rows,
        'duplicate_timestamp_groups': duplicate_groups,
        'gap_breaks': gap_breaks,
        'segments': len(segments),
        'valid_candles': sum(len(segment) for segment in segments),
    }


def _bucket_signature(rows, index):
    """Build a directional pre-move signature from completed hourly candles.

    Version 2 separates short/medium momentum, volume shock, volatility,
    candle pressure and trend consistency. Buckets deliberately stay coarse
    so historical samples can still accumulate without pretending precision.
    """
    if index < 24:
        return None
    window = rows[index-24:index+1]
    try:
        closes = [float(r[5]) for r in window]
        opens = [float(r[2]) for r in window]
        highs = [float(r[3]) for r in window]
        lows = [float(r[4]) for r in window]
        volumes = [max(0.0, float(r[6])) for r in window]
        price = closes[-1]
        if price <= 0 or closes[-5] <= 0 or closes[-13] <= 0 or closes[0] <= 0:
            return None
        mom4 = (price / closes[-5] - 1) * 100
        mom12 = (price / closes[-13] - 1) * 100
        mom24 = (price / closes[0] - 1) * 100
        avg_vol = sum(volumes[:-1]) / max(1, len(volumes)-1)
        vol_ratio = volumes[-1] / avg_vol if avg_vol > 0 else 0
        range_pct = (max(highs) - min(lows)) / price * 100
        body_pct = (closes[-1] / opens[-1] - 1) * 100 if opens[-1] > 0 else 0
        up_steps = sum(closes[i] > closes[i-1] for i in range(1, len(closes)))
        trend_ratio = up_steps / 24
    except (TypeError, ValueError, IndexError, ZeroDivisionError, OverflowError):
        return None

    def bucket(value, low, high, labels):
        return labels[0] if value <= low else labels[2] if value >= high else labels[1]

    m4 = bucket(mom4, -1.0, 1.0, ('down', 'flat', 'up'))
    m12 = bucket(mom12, -2.5, 2.5, ('down', 'flat', 'up'))
    m24 = bucket(mom24, -5.0, 5.0, ('down', 'flat', 'up'))
    vol = 'high' if vol_ratio >= 1.8 else 'low' if vol_ratio < 0.65 else 'normal'
    volatility = 'wide' if range_pct >= 8 else 'tight' if range_pct < 3 else 'normal'
    pressure = 'sell' if body_pct <= -0.5 else 'buy' if body_pct >= 0.5 else 'neutral'
    trend = 'bear' if trend_ratio < 0.38 else 'bull' if trend_ratio > 0.62 else 'mixed'
    return ('v2', m4, m12, m24, vol, volatility, pressure, trend)


def _iter_bucket_signatures_numpy(data):
    """Yield all (index, signature) pairs using vectorized rolling features.

    Values close to a bucket boundary are recalculated by the reference Python
    implementation to avoid changing labels due to floating-point summation.
    """
    if _np is None:
        for index in range(24, len(data) - 24):
            yield index, _bucket_signature(data, index)
        return
    if len(data) <= 48:
        return
    values = _np.asarray(
        [[float(row[2]), float(row[3]), float(row[4]), float(row[5]), float(row[6])]
         for row in data], dtype=_np.float64)
    opens, highs, lows, closes, volumes = (values[:, i] for i in range(5))
    indexes = _np.arange(24, len(data) - 24, dtype=_np.int64)
    if indexes.size == 0:
        return
    price = closes[indexes]
    mom4 = (price / closes[indexes - 4] - 1.0) * 100.0
    mom12 = (price / closes[indexes - 12] - 1.0) * 100.0
    mom24 = (price / closes[indexes - 24] - 1.0) * 100.0
    volume_prefix = _np.empty(len(volumes) + 1, dtype=_np.float64)
    volume_prefix[0] = 0.0
    _np.cumsum(volumes, out=volume_prefix[1:])
    average_volume = (volume_prefix[indexes] - volume_prefix[indexes - 24]) / 24.0
    vol_ratio = _np.divide(volumes[indexes], average_volume,
                           out=_np.zeros_like(average_volume), where=average_volume > 0)
    high_windows = _np.lib.stride_tricks.sliding_window_view(highs, 25)[:indexes.size]
    low_windows = _np.lib.stride_tricks.sliding_window_view(lows, 25)[:indexes.size]
    range_pct = (high_windows.max(axis=1) - low_windows.min(axis=1)) / price * 100.0
    body_pct = (closes[indexes] / opens[indexes] - 1.0) * 100.0
    up_steps = _np.empty(len(closes), dtype=_np.int64)
    up_steps[0] = 0
    up_steps[1:] = (closes[1:] > closes[:-1]).astype(_np.int64)
    trend_prefix = _np.empty(len(closes) + 1, dtype=_np.int64)
    trend_prefix[0] = 0
    _np.cumsum(up_steps, out=trend_prefix[1:])
    trend_ratio = (trend_prefix[indexes + 1] - trend_prefix[indexes - 23]) / 24.0

    def three_way(values_array, low, high, labels):
        result = _np.full(values_array.shape, labels[1], dtype=object)
        result[values_array <= low] = labels[0]
        result[values_array >= high] = labels[2]
        return result

    m4 = three_way(mom4, -1.0, 1.0, ('down', 'flat', 'up'))
    m12 = three_way(mom12, -2.5, 2.5, ('down', 'flat', 'up'))
    m24 = three_way(mom24, -5.0, 5.0, ('down', 'flat', 'up'))
    vol = _np.where(vol_ratio >= 1.8, 'high', _np.where(vol_ratio < 0.65, 'low', 'normal'))
    volatility = _np.where(range_pct >= 8.0, 'wide', _np.where(range_pct < 3.0, 'tight', 'normal'))
    pressure = _np.where(body_pct <= -0.5, 'sell', _np.where(body_pct >= 0.5, 'buy', 'neutral'))
    trend = _np.where(trend_ratio < 0.38, 'bear', _np.where(trend_ratio > 0.62, 'bull', 'mixed'))

    boundaries = ((mom4, (-1.0, 1.0)), (mom12, (-2.5, 2.5)),
                  (mom24, (-5.0, 5.0)), (vol_ratio, (0.65, 1.8)),
                  (range_pct, (3.0, 8.0)), (body_pct, (-0.5, 0.5)))
    near_edge_mask = _np.zeros(indexes.size, dtype=bool)
    for values_array, edges in boundaries:
        for edge in edges:
            near_edge_mask |= _np.abs(values_array - edge) <= 1e-8
    for offset, index in enumerate(indexes.tolist()):
        # Keep the established implementation authoritative at bucket edges.
        if near_edge_mask[offset]:
            signature = _bucket_signature(data, index)
        else:
            signature = ('v2', str(m4[offset]), str(m12[offset]), str(m24[offset]),
                         str(vol[offset]), str(volatility[offset]),
                         str(pressure[offset]), str(trend[offset]))
        yield index, signature


def _market_regime(signature: tuple | list | str | None) -> str:
    """Coarse market regime from the medium/long momentum buckets."""
    if not signature:
        return 'unknown'
    parts = signature.split('|') if isinstance(signature, str) else list(signature)
    if len(parts) < 4:
        return 'unknown'
    m12, m24 = str(parts[2]), str(parts[3])
    if m12 == 'up' and m24 == 'up':
        return 'bull'
    if m12 == 'down' and m24 == 'down':
        return 'bear'
    return 'sideways_mixed'


def _outcome(start, future):
    if start <= 0 or future <= 0:
        return None
    return (future / start - 1.0) * 100.0


def _classify_extreme_window(start_price: float, future_rows, threshold_pct: float = HISTORY_EXTREME_PCT) -> tuple[bool, bool]:
    """Detect both upside and downside excursions inside the next 24 closed bars.

    Uses intraperiod highs/lows, not only the final close. A volatile window may
    legitimately count as both a pump and a dump; the two directions are never
    forced into a single winner.
    """
    try:
        start = float(start_price)
        if start <= 0 or not future_rows:
            return False, False
        highs = [float(row[3]) for row in future_rows]
        lows = [float(row[4]) for row in future_rows]
        if not highs or not lows or any(v <= 0 for v in highs + lows):
            return False, False
        pump = (max(highs) / start - 1.0) * 100.0 >= float(threshold_pct)
        dump = (min(lows) / start - 1.0) * 100.0 <= -float(threshold_pct)
        return bool(pump), bool(dump)
    except (TypeError, ValueError, IndexError, OverflowError, ZeroDivisionError):
        return False, False


def _iter_extreme_events_python(data):
    """Yield only extreme candidate indexes using the reference Python path."""
    for i in range(24, len(data) - 24):
        pump_hit, dump_hit = _classify_extreme_window(float(data[i][5]), data[i + 1:i + 25])
        if pump_hit or dump_hit:
            yield i, bool(pump_hit), bool(dump_hit)


def _iter_extreme_events_numpy(data):
    """Vectorized 24-hour high/low scan; output semantics match the Python path."""
    if _np is None or len(data) <= 48:
        yield from _iter_extreme_events_python(data)
        return
    try:
        # A compact float64 matrix makes the rolling extrema scan run in NumPy's
        # native loops instead of allocating Python lists for every 24-bar window.
        values = _np.asarray(
            [[float(row[2]), float(row[3]), float(row[4]), float(row[5]), float(row[6])]
             for row in data], dtype=_np.float64)
        highs = values[:, 1]
        lows = values[:, 2]
        closes = values[:, 3]
        # For a candidate at i, the outcome window is [i+1, i+25).
        high_windows = _np.lib.stride_tricks.sliding_window_view(highs[1:], 24)
        low_windows = _np.lib.stride_tricks.sliding_window_view(lows[1:], 24)
        future_high = high_windows.max(axis=1)[24:len(data) - 24]
        future_low = low_windows.min(axis=1)[24:len(data) - 24]
        start = closes[24:len(data) - 24]
        pump_mask = ((future_high / start - 1.0) * 100.0) >= float(HISTORY_EXTREME_PCT)
        dump_mask = ((future_low / start - 1.0) * 100.0) <= -float(HISTORY_EXTREME_PCT)
        hits = _np.flatnonzero(pump_mask | dump_mask)
        for offset in hits.tolist():
            yield offset + 24, bool(pump_mask[offset]), bool(dump_mask[offset])
    except (TypeError, ValueError, IndexError, OverflowError, FloatingPointError):
        # Malformed data should never crash startup learning. The validator has
        # already filtered most bad rows; fall back to the reference path here.
        yield from _iter_extreme_events_python(data)


def _scan_symbol_segments(symbol_segments):
    """Learn pump and dump patterns for one symbol without crossing gaps."""
    counts = {}
    pumps = dumps = 0
    for data in symbol_segments:
        next_pump_window = next_dump_window = 0
        events = (_iter_extreme_events_numpy(data) if _np is not None
                  else _iter_extreme_events_python(data))
        for i, pump_hit, dump_hit in events:
            count_pump = bool(pump_hit and i >= next_pump_window)
            count_dump = bool(dump_hit and i >= next_dump_window)
            if not (count_pump or count_dump):
                continue
            if count_pump:
                next_pump_window = i + 24
            if count_dump:
                next_dump_window = i + 24
            signature = _bucket_signature(data, i)
            if signature is None:
                continue
            item = counts.setdefault(signature, [0, 0])
            if count_pump:
                pumps += 1
                item[0] += 1
            if count_dump:
                dumps += 1
                item[1] += 1
    return pumps, dumps, counts


def _learning_worker_count(symbol_count: int) -> int:
    """Choose bounded CPU parallelism; explicit env setting can tune the cap."""
    cpu_count = max(1, os.cpu_count() or 1)
    try:
        requested = int(os.getenv('TRADING_AI_BRAIN_WORKERS', '0'))
    except (TypeError, ValueError):
        requested = 0
    workers = min(cpu_count, 8) if requested <= 0 else min(cpu_count, max(1, requested))
    return max(1, min(int(symbol_count), workers))


def _probability(values, positive=1.0, negative=-1.0):
    valid = [v for v in values if v is not None]
    if not valid:
        return None
    return {
        'up_pct': round(100 * sum(v >= positive for v in valid) / len(valid), 1),
        'down_pct': round(100 * sum(v <= negative for v in valid) / len(valid), 1),
        'avg_return_pct': round(sum(valid) / len(valid), 2),
    }



def historical_learning_status() -> dict:
    """Return the last startup historical scan status."""
    with _STARTUP_LOCK:
        return dict(_STARTUP_STATE)


def learn_historical_extremes(now: float | None = None) -> dict:
    """Scan archived hourly candles for severe +/-10% 24h moves and their
    preceding conditions. This is descriptive historical learning, not a
    promise that similar conditions will repeat. Safe to run at startup.
    """
    now = float(now if now is not None else time.time())
    with _STARTUP_LOCK:
        _STARTUP_STATE.update(status='running', stage='checking_cache', progress_pct=1,
                              symbols_done=0, symbols_total=0, workers=0,
                              accelerator='numpy' if _np is not None else 'python',
                              started_ts=now, finished_ts=None, symbols=0, candles=0,
                              pump_events=0, dump_events=0, patterns=0, invalid_rows=0,
                              duplicate_timestamp_groups=0, gap_breaks=0, segments=0,
                              cache_hit=False, error=None)
    if not HISTORY_DB_PATH.exists():
        with _STARTUP_LOCK:
            _STARTUP_STATE.update(status='no_history_archive', stage='blocked', progress_pct=100, finished_ts=time.time())
            return dict(_STARTUP_STATE)
    try:
        # Persist discovered patterns so normal restarts do not rescan an
        # unchanged archive. A changed archive fingerprint triggers a rebuild.
        fingerprint = _archive_fingerprint(HISTORY_DB_PATH)
        FEEDBACK_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        cache = sqlite3.connect(str(FEEDBACK_DB_PATH), timeout=5)
        try:
            cache.execute('''CREATE TABLE IF NOT EXISTS brain_historical_patterns (
                signature TEXT PRIMARY KEY, pump_count INTEGER NOT NULL, dump_count INTEGER NOT NULL)''')
            cache.execute('''CREATE TABLE IF NOT EXISTS brain_history_cache_meta (
                key TEXT PRIMARY KEY, value TEXT NOT NULL)''')
            previous = cache.execute("SELECT value FROM brain_history_cache_meta WHERE key='archive_fingerprint'").fetchone()
            cached = cache.execute('SELECT COUNT(*) FROM brain_historical_patterns').fetchone()[0]
            cached_symbols = cache.execute("SELECT value FROM brain_history_cache_meta WHERE key='symbols'").fetchone()
            cached_candles = cache.execute("SELECT value FROM brain_history_cache_meta WHERE key='candles'").fetchone()
            if previous and previous[0] == fingerprint and cached_symbols and cached_candles:
                totals = cache.execute('SELECT COALESCE(SUM(pump_count),0), COALESCE(SUM(dump_count),0) FROM brain_historical_patterns').fetchone()
                symbol_count, candle_count = int(cached_symbols[0]), int(cached_candles[0])
                cached_status = 'completed_cached' if symbol_count > 0 and candle_count > 0 else 'no_symbols'
                def cached_int(key):
                    row = cache.execute('SELECT value FROM brain_history_cache_meta WHERE key=?', (key,)).fetchone()
                    try:
                        return max(0, int(row[0])) if row else 0
                    except (TypeError, ValueError):
                        return 0
                with _STARTUP_LOCK:
                    _STARTUP_STATE.update(status=cached_status, stage='cache_ready', progress_pct=100,
                        symbols_done=symbol_count, symbols_total=symbol_count,
                        symbols=symbol_count, candles=candle_count,
                        pump_events=int(totals[0]), dump_events=int(totals[1]),
                        patterns=int(cached), invalid_rows=cached_int('invalid_rows'),
                        duplicate_timestamp_groups=cached_int('duplicate_timestamp_groups'),
                        gap_breaks=cached_int('gap_breaks'), segments=cached_int('segments'),
                        cache_hit=True,
                        error=None if symbol_count else 'آرشیو موجود است اما هیچ نماد/کندل معتبر ۱ساعته در آن پیدا نشد')
                    return dict(_STARTUP_STATE)
        finally:
            cache.close()
        with _STARTUP_LOCK:
            _STARTUP_STATE.update(stage='loading_archive', progress_pct=5)
        con = sqlite3.connect(HISTORY_DB_PATH.resolve().as_uri() + '?mode=ro', uri=True, timeout=5)
        try:
            con.execute('PRAGMA query_only=ON')
            con.execute('PRAGMA cache_size=-65536')
            table = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='candles'").fetchone()
            if not table:
                raise RuntimeError('جدول candles در آرشیو تاریخی وجود ندارد')
            columns = {str(r[1]).lower() for r in con.execute('PRAGMA table_info(candles)')}
            required = {'symbol', 'timeframe', 't', 'open', 'high', 'low', 'close', 'volume'}
            missing = sorted(required - columns)
            if missing:
                raise RuntimeError('ساختار جدول candles ناقص است؛ ستون‌های مفقود: ' + ', '.join(missing))
            placeholders = ','.join('?' for _ in HOURLY_TIMEFRAME_ALIASES)
            rows = con.execute(
                f"SELECT symbol,t,open,high,low,close,volume FROM candles "
                f"WHERE LOWER(TRIM(timeframe)) IN ({placeholders}) "
                "ORDER BY symbol,t LIMIT ?",
                (*HOURLY_TIMEFRAME_ALIASES, MAX_CANDLES),
            ).fetchall()
        finally:
            con.close()
        raw_grouped = defaultdict(list)
        for row in rows:
            raw_grouped[str(row[0]).upper()].append(row)
        grouped = {}
        quality = {'invalid_rows': 0, 'duplicate_timestamp_groups': 0,
                   'gap_breaks': 0, 'segments': 0, 'valid_candles': 0}
        for symbol, symbol_rows in raw_grouped.items():
            segments, audit = _prepare_hourly_segments(symbol_rows, presorted=True)
            for key in ('invalid_rows', 'duplicate_timestamp_groups', 'gap_breaks', 'segments', 'valid_candles'):
                quality[key] += audit[key]
            if segments:
                grouped[symbol] = segments
        if not grouped:
            with _STARTUP_LOCK:
                _STARTUP_STATE.update(status='no_symbols', stage='complete', progress_pct=100,
                    symbols_done=0, symbols_total=0, finished_ts=time.time(),
                    symbols=0, candles=0, pump_events=0, dump_events=0,
                    patterns=0, invalid_rows=quality['invalid_rows'],
                    duplicate_timestamp_groups=quality['duplicate_timestamp_groups'],
                    gap_breaks=quality['gap_breaks'], segments=quality['segments'],
                    cache_hit=False,
                    error='آرشیو پیدا شد اما هیچ نماد دارای کندل معتبر ۱ساعته وجود ندارد')
                return dict(_STARTUP_STATE)
        pattern_counts = defaultdict(lambda: {'pump': 0, 'dump': 0})
        pumps = dumps = 0
        candles = quality['valid_candles']
        workers = _learning_worker_count(len(grouped)) if _np is not None else 1
        with _STARTUP_LOCK:
            _STARTUP_STATE.update(stage='scanning_patterns', progress_pct=15,
                                  symbols_total=len(grouped), symbols_done=0, workers=workers)
        symbol_groups = list(grouped.values())
        if workers > 1 and len(symbol_groups) > 1:
            with ThreadPoolExecutor(max_workers=workers, thread_name_prefix='brain-learn') as pool:
                results = pool.map(_scan_symbol_segments, symbol_groups)
                for done, (local_pumps, local_dumps, local_counts) in enumerate(results, 1):
                    pumps += local_pumps
                    dumps += local_dumps
                    for signature, values in local_counts.items():
                        pattern_counts[signature]['pump'] += values[0]
                        pattern_counts[signature]['dump'] += values[1]
                    with _STARTUP_LOCK:
                        _STARTUP_STATE.update(symbols_done=done,
                            progress_pct=15 + int(75 * done / max(1, len(symbol_groups))))
        else:
            for done, symbol_segments in enumerate(symbol_groups, 1):
                local_pumps, local_dumps, local_counts = _scan_symbol_segments(symbol_segments)
                pumps += local_pumps
                dumps += local_dumps
                for signature, values in local_counts.items():
                    pattern_counts[signature]['pump'] += values[0]
                    pattern_counts[signature]['dump'] += values[1]
                with _STARTUP_LOCK:
                    _STARTUP_STATE.update(symbols_done=done,
                        progress_pct=15 + int(75 * done / max(1, len(symbol_groups))))
        with _STARTUP_LOCK:
            _STARTUP_STATE.update(stage='saving_cache', progress_pct=95)
        cache = sqlite3.connect(str(FEEDBACK_DB_PATH), timeout=5)
        try:
            cache.execute('DELETE FROM brain_historical_patterns')
            cache.executemany('INSERT INTO brain_historical_patterns(signature,pump_count,dump_count) VALUES(?,?,?)',
                [( '|'.join(sig), int(counts['pump']), int(counts['dump']))
                 for sig, counts in pattern_counts.items()])
            cache.execute("INSERT OR REPLACE INTO brain_history_cache_meta(key,value) VALUES('archive_fingerprint',?)", (fingerprint,))
            cache.execute("INSERT OR REPLACE INTO brain_history_cache_meta(key,value) VALUES('symbols',?)", (str(len(grouped)),))
            cache.execute("INSERT OR REPLACE INTO brain_history_cache_meta(key,value) VALUES('candles',?)", (str(candles),))
            for key in ('invalid_rows', 'duplicate_timestamp_groups', 'gap_breaks', 'segments'):
                cache.execute("INSERT OR REPLACE INTO brain_history_cache_meta(key,value) VALUES(?,?)", (key, str(quality[key])))
            cache.commit()
        finally:
            cache.close()
        with _STARTUP_LOCK:
            _STARTUP_STATE.update(status='completed', stage='complete', progress_pct=100,
                symbols_done=len(grouped), symbols_total=len(grouped),
                finished_ts=time.time(), symbols=len(grouped), candles=candles, pump_events=pumps,
                dump_events=dumps, patterns=len(pattern_counts),
                invalid_rows=quality['invalid_rows'],
                duplicate_timestamp_groups=quality['duplicate_timestamp_groups'],
                gap_breaks=quality['gap_breaks'], segments=quality['segments'],
                cache_hit=False, error=None)
            return dict(_STARTUP_STATE)
    except Exception as exc:
        with _STARTUP_LOCK:
            _STARTUP_STATE.update(status='error', stage='error', progress_pct=100, finished_ts=time.time(), error=str(exc)[:180])
            return dict(_STARTUP_STATE)


def start_startup_learning() -> bool:
    """Launch one non-blocking historical audit at app startup.

    Mark the task as starting before creating the thread. Otherwise two near-
    simultaneous callers can both observe ``not_started`` before the worker
    thread gets CPU time and launch duplicate full-archive scans.
    """
    import threading
    with _STARTUP_LOCK:
        if _STARTUP_STATE.get('status') in ('starting', 'running'):
            return False
        _STARTUP_STATE.update(status='starting', started_ts=time.time(),
                              finished_ts=None, error=None)
        try:
            worker = threading.Thread(target=learn_historical_extremes,
                                      name='market-brain-history', daemon=True)
            worker.start()
        except Exception as exc:
            _STARTUP_STATE.update(status='error', finished_ts=time.time(),
                                  error=str(exc)[:180])
            return False
        return True


def _summarize_extreme_counts(pump_count: int, dump_count: int) -> dict:
    """Interpret historical +/-10% 24h events for an exact pre-move pattern.

    This is evidence labeling only. A small or balanced sample is deliberately
    reported as uncertain rather than being converted into a directional call.
    """
    pump, dump = max(0, int(pump_count)), max(0, int(dump_count))
    total = pump + dump
    pump_share = round(100 * pump / total, 1) if total else None
    dump_share = round(100 * dump / total, 1) if total else None
    if total < 5:
        dominant, reliability = 'insufficient_samples', 'low'
    elif pump_share >= 65:
        dominant, reliability = 'pump_favored', 'moderate' if total < 20 else 'strong'
    elif dump_share >= 65:
        dominant, reliability = 'dump_favored', 'moderate' if total < 20 else 'strong'
    else:
        dominant, reliability = 'mixed', 'moderate' if total < 20 else 'strong'
    return {
        'pump_count': pump, 'dump_count': dump, 'samples': total,
        'pump_share_pct': pump_share, 'dump_share_pct': dump_share,
        'historical_bias': dominant, 'evidence_reliability': reliability,
        'event_definition': 'next_24_closed_1h_candles_high_low_excursion_at_least_10pct',
        'is_forecast': False,
    }


def _cached_extreme_pattern(signature: tuple[str, ...]) -> dict | None:
    """Read startup-learned severe-move counts for the current exact pattern."""
    if not FEEDBACK_DB_PATH.exists():
        return None
    try:
        con = sqlite3.connect(str(FEEDBACK_DB_PATH), timeout=2)
        try:
            row = con.execute(
                "SELECT pump_count,dump_count FROM brain_historical_patterns WHERE signature=?",
                ('|'.join(signature),),
            ).fetchone()
        finally:
            con.close()
        return _summarize_extreme_counts(*(row or (0, 0)))
    except (sqlite3.Error, OSError, ValueError, TypeError):
        return None


def _feedback_validation(summary: dict | None) -> dict:
    """Expose out-of-sample directional track record without rewriting forecasts."""
    horizons = (summary or {}).get('horizons') or {}
    result = {}
    for horizon in FEEDBACK_HORIZONS:
        stats = horizons.get(horizon) or {}
        calls = int(stats.get('directional_calls') or 0)
        correct = int(stats.get('directional_correct') or 0)
        accuracy = stats.get('directional_accuracy_pct')
        if calls < 20 or accuracy is None:
            label = 'insufficient_samples'
        elif float(accuracy) >= 55:
            label = 'historically_supportive'
        elif float(accuracy) <= 45:
            label = 'historically_weak'
        else:
            label = 'near_coin_flip'
        result[horizon] = {
            'directional_calls': calls, 'directional_correct': correct,
            'accuracy_pct': accuracy, 'reliability': label,
            'sample_reliability': stats.get('reliability', 'insufficient_samples'),
        }
    return result


def _pattern_feedback(signature: tuple | str | None, market_regime: str | None = None) -> dict:
    """Out-of-sample score for one signature within its current market regime.

    Uses only resolved 4h forecasts from the same regime; diagnostic/priority
    metadata only, never changes execution or eligibility.
    """
    empty = {'directional_calls': 0, 'directional_correct': 0, 'accuracy_pct': None,
             'weight': 1.0, 'reliability': 'insufficient_samples'}
    if not signature or not FEEDBACK_DB_PATH.exists():
        return dict(empty)
    key = '|'.join(signature) if isinstance(signature, (tuple, list)) else str(signature)
    try:
        con = sqlite3.connect(str(FEEDBACK_DB_PATH), timeout=2)
        try:
            columns = {r[1] for r in con.execute('PRAGMA table_info(brain_forecasts)')}
            if 'pattern_signature' not in columns:
                return dict(empty)
            has_regime = 'market_regime' in columns
            if market_regime and market_regime != 'unknown' and has_regime:
                row = con.execute("""SELECT
                    SUM(CASE WHEN outcome IN ('up','down') AND predicted_up != predicted_down THEN 1 ELSE 0 END),
                    SUM(CASE WHEN outcome IN ('up','down') AND predicted_up != predicted_down AND
                        ((predicted_up > predicted_down AND outcome='up') OR
                         (predicted_down > predicted_up AND outcome='down')) THEN 1 ELSE 0 END)
                    FROM brain_forecasts WHERE pattern_signature=? AND horizon='4h' AND market_regime=?""", (key, market_regime)).fetchone()
            else:
                row = con.execute("""SELECT
                    SUM(CASE WHEN outcome IN ('up','down') AND predicted_up != predicted_down THEN 1 ELSE 0 END),
                    SUM(CASE WHEN outcome IN ('up','down') AND predicted_up != predicted_down AND
                        ((predicted_up > predicted_down AND outcome='up') OR
                         (predicted_down > predicted_up AND outcome='down')) THEN 1 ELSE 0 END)
                    FROM brain_forecasts WHERE pattern_signature=? AND horizon='4h'""", (key,)).fetchone()
        finally:
            con.close()
        calls, correct = int(row[0] or 0), int(row[1] or 0)
        if calls == 0:
            return dict(empty)
        accuracy = round(100.0 * correct / calls, 1)
        if calls < 20:
            label, weight = 'insufficient_samples', 1.0
        elif accuracy >= 55:
            label, weight = 'historically_supportive', min(1.15, 1.0 + (accuracy - 55) / 100)
        elif accuracy <= 45:
            label, weight = 'historically_weak', max(0.75, 1.0 - (45 - accuracy) / 100)
        else:
            label, weight = 'near_coin_flip', 1.0
        return {'directional_calls': calls, 'directional_correct': correct,
                'accuracy_pct': accuracy, 'weight': round(weight, 3), 'reliability': label}
    except (sqlite3.Error, OSError, TypeError, ValueError):
        return dict(empty)


def _btc_lead_lag_summary(grouped: dict, symbol: str) -> dict:
    """Describe whether historical BTC 4h impulses preceded moves in an alt.

    Uses only completed candles. The alt observation window starts after the
    BTC impulse ends; timestamps must align within one hour. This is diagnostic
    evidence only and never changes signal eligibility or execution.
    """
    empty = {'status': 'insufficient_data', 'btc_4h_return_pct': None,
             'historical_events': 0, 'follow_through_4h_pct': None,
             'follow_through_12h_pct': None, 'note': 'برای بررسی تقدم زمانی BTC داده هم‌زمان کافی نیست.'}
    btc = grouped.get('BTCUSDT')
    alt = grouped.get(symbol)
    if not btc or not alt or len(btc) < 30 or len(alt) < 30:
        return dict(empty)
    try:
        btc_now = _outcome(float(btc[-5][5]), float(btc[-1][5]))
        if btc_now is None or abs(btc_now) < 2.0:
            result = dict(empty)
            result.update(status='no_current_btc_impulse', btc_4h_return_pct=round(btc_now or 0.0, 2))
            return result
        direction = 1 if btc_now > 0 else -1
        alt_times = [int(row[1]) for row in alt]
        import bisect
        follow4 = []
        follow12 = []
        events = 0
        for i in range(24, len(btc) - 13):
            impulse = _outcome(float(btc[i][5]), float(btc[i+4][5]))
            if impulse is None or (impulse >= 2.0 if direction > 0 else impulse <= -2.0) is False:
                continue
            target_ts = int(btc[i+4][1])
            pos = bisect.bisect_left(alt_times, target_ts)
            choices = [j for j in (pos-1, pos) if 0 <= j < len(alt)]
            if not choices:
                continue
            j = min(choices, key=lambda k: abs(alt_times[k] - target_ts))
            if abs(alt_times[j] - target_ts) > 3_600_000 or j + 12 >= len(alt):
                continue
            start = float(alt[j][5])
            r4 = _outcome(start, float(alt[j+4][5]))
            r12 = _outcome(start, float(alt[j+12][5]))
            if r4 is None or r12 is None:
                continue
            events += 1
            follow4.append(r4 * direction >= 1.0)
            follow12.append(r12 * direction >= 2.0)
        if events < MIN_ANALOGS:
            return {'status': 'insufficient_samples', 'btc_4h_return_pct': round(btc_now, 2),
                    'historical_events': events, 'follow_through_4h_pct': None,
                    'follow_through_12h_pct': None,
                    'note': 'حرکت BTC دیده شد، اما رخداد تاریخی هم‌زمان کافی برای نتیجه‌گیری وجود ندارد.'}
        return {'status': 'available', 'btc_4h_return_pct': round(btc_now, 2),
                'historical_events': events,
                'follow_through_4h_pct': round(100.0 * sum(follow4) / events, 1),
                'follow_through_12h_pct': round(100.0 * sum(follow12) / events, 1),
                'note': 'درصد رخدادهای تاریخی که پس از حرکت BTC، آلت‌کوین نیز در همان جهت حرکت کرده؛ پیش‌بینی قطعی نیست.'}
    except (TypeError, ValueError, IndexError, OverflowError):
        return dict(empty)


def predict(items: list[dict], now: float | None = None) -> dict:
    # Attach cached historical analog probabilities; no orders or side effects.
    now = float(now if now is not None else time.time())
    if not HISTORY_DB_PATH.exists():
        return {'status': 'no_history_archive', 'symbols_analyzed': 0, 'analogs_used': 0,
                'cache_hit': False}

    # A market scan runs frequently. Rebuilding 250k candle analogs on every scan
    # is wasteful; keep a read-only in-memory index and invalidate it whenever
    # the archive or its SQLite WAL changes.
    try:
        fingerprint = _archive_fingerprint(HISTORY_DB_PATH)
        with _PREDICTION_CACHE_LOCK:
            cache_hit = (_PREDICTION_CACHE.get('fingerprint') == fingerprint
                         and _PREDICTION_CACHE.get('grouped') is not None
                         and _PREDICTION_CACHE.get('cross_asset_analogs') is not None
                         and (_PREDICTION_CACHE.get('next_close_ts') is None
                              or now < _PREDICTION_CACHE.get('next_close_ts')))
            if cache_hit:
                grouped = _PREDICTION_CACHE['grouped']
                cross_asset_analogs = _PREDICTION_CACHE['cross_asset_analogs']
                archive_quality = _PREDICTION_CACHE['archive_quality'] or {}
                row_count = int(_PREDICTION_CACHE.get('row_count') or 0)
            else:
                con = sqlite3.connect(HISTORY_DB_PATH.resolve().as_uri() + '?mode=ro', uri=True, timeout=3)
                try:
                    con.execute('PRAGMA query_only=ON')
                    con.execute('PRAGMA cache_size=-65536')
                    rows = con.execute('''SELECT symbol,t,open,high,low,close,volume
                        FROM candles WHERE timeframe='1h'
                        ORDER BY symbol,t DESC LIMIT ?''',
                        (MAX_CANDLES,)).fetchall()
                finally:
                    con.close()

                raw_grouped = defaultdict(list)
                next_close_ts = None
                for row in rows:
                    try:
                        close_ts = float(row[1]) / 1000.0 + 3600
                        if close_ts <= now:
                            raw_grouped[str(row[0]).upper()].append(row)
                        elif next_close_ts is None or close_ts < next_close_ts:
                            next_close_ts = close_ts
                    except (TypeError, ValueError, OverflowError):
                        continue
                row_count = len(rows)
                grouped = {}
                all_segments = {}
                archive_quality = {'invalid_rows': 0, 'duplicate_timestamp_groups': 0,
                                   'gap_breaks': 0, 'segments': 0, 'valid_candles': 0}
                for symbol, symbol_rows in raw_grouped.items():
                    # Newest-first query keeps the most recent MAX_CANDLES rows.
                    # Reverse each symbol once for linear segment construction.
                    symbol_rows.reverse()
                    segments, audit = _prepare_hourly_segments(symbol_rows, presorted=True)
                    for key in archive_quality:
                        archive_quality[key] += audit[key]
                    if segments:
                        all_segments[symbol] = segments
                        grouped[symbol] = segments[-1]

                # One compact per-signature index stores (source symbol, return).
                # The separate duplicate analog list is unnecessary; all-sample
                # and cross-asset samples can be derived from this single index.
                cross_asset_analogs = defaultdict(lambda: {'1h': [], '4h': [], '24h': []})
                for symbol, symbol_segments in all_segments.items():
                    for data in symbol_segments:
                        for i, signature in _iter_bucket_signatures_numpy(data):
                            if signature is None:
                                continue
                            start_price = float(data[i][5])
                            for horizon, offset in (('1h', 1), ('4h', 4), ('24h', 24)):
                                ret = _outcome(start_price, float(data[i + offset][5]))
                                if ret is not None:
                                    cross_asset_analogs[signature][horizon].append((symbol, ret))
                cross_asset_analogs = dict(cross_asset_analogs)
                grouped = dict(grouped)
                archive_quality = dict(archive_quality)
                _PREDICTION_CACHE.update(
                    fingerprint=fingerprint, grouped=grouped,
                    cross_asset_analogs=cross_asset_analogs,
                    archive_quality=archive_quality, built_ts=time.time(),
                    next_close_ts=next_close_ts, row_count=row_count)
    except (sqlite3.Error, OSError, TypeError, ValueError, IndexError, OverflowError):
        return {'status': 'history_unavailable', 'symbols_analyzed': 0,
                'analogs_used': 0, 'cache_hit': False}

    used = 0
    analyzed = 0
    try:
        feedback = feedback_summary()
    except (sqlite3.Error, OSError):
        feedback = {'status': 'no_feedback_yet', 'horizons': {}}
    validation = _feedback_validation(feedback)
    for item in items:
        raw_symbol = str(item.get('symbol') or '').upper().replace('/', '').replace('-', '').replace('_', '')
        symbol = raw_symbol if raw_symbol.endswith('USDT') else raw_symbol + 'USDT'
        data = grouped.get(symbol)
        if not data:
            item['brain_prediction'] = {'status': 'no_symbol_history', 'message': 'برای این ارز تاریخچه کندلی کافی در آرشیو پیدا نشد.'}
            continue
        if not data or now - (float(data[-1][1]) / 1000.0 + 3600) > 3 * 3600:
            item['brain_prediction'] = {'status': 'stale_symbol_history', 'message': 'آخرین کندل آرشیوی این ارز قدیمی است؛ پیش‌بینی متوقف شد.'}
            continue
        sig = _bucket_signature(data, len(data)-1)
        if sig is None:
            item['brain_prediction'] = {'status': 'insufficient_current_candles', 'message': 'برای تحلیل وضعیت فعلی حداقل ۲۵ کندل یک‌ساعته لازم است.'}
            continue
        source_samples = cross_asset_analogs.get(sig, {})
        # Reconstruct only this candidate's bucket; the historical index remains
        # cached between live market scans.
        sample = {h: [ret for _, ret in source_samples.get(h, [])]
                  for h in ('1h', '4h', '24h')}
        # Cross-asset analogs deliberately exclude the candidate's own symbol.
        cross_sample = {h: [ret for source_symbol, ret in source_samples.get(h, [])
                             if source_symbol != symbol] for h in ('1h', '4h', '24h')}
        cross_n = len(cross_sample['4h'])
        cross_asset_summary = {
            'status': 'available' if cross_n >= MIN_ANALOGS else 'insufficient_samples',
            'analogs': cross_n,
            'source_symbols': len({source_symbol for source_symbol, _ in source_samples.get('4h', []) if source_symbol != symbol}),
            'horizons': ({h: _probability(cross_sample[h], positive=1.0 if h == '1h' else 2.0,
                                          negative=-1.0 if h == '1h' else -2.0)
                          for h in ('1h', '4h', '24h')} if cross_n >= MIN_ANALOGS else {}),
            'note': 'نمونه‌های ارزهای دیگر هستند و از تاریخچه همین ارز جدا نگه داشته شده‌اند.'
        }
        lead_lag_summary = _btc_lead_lag_summary(grouped, symbol)
        n = len(sample.get('4h', []))
        extreme_pattern = _cached_extreme_pattern(sig)
        current_regime = _market_regime(sig)
        # Regime-matched score is used for display priority; retain overall score
        # for transparency and backward-compatible diagnostics.
        pattern_learning_overall = _pattern_feedback(sig)
        pattern_learning = _pattern_feedback(sig, current_regime)
        analyzed += 1
        if n < MIN_ANALOGS:
            item['brain_prediction'] = {'status': 'few_historical_analogs', 'analogs': n,
                'historical_extremes': extreme_pattern, 'cross_asset_analogs': cross_asset_summary, 'btc_lead_lag': lead_lag_summary, 'feedback_validation': validation,
                'pattern_learning': pattern_learning, 'pattern_learning_overall': pattern_learning_overall,
                'pattern_signature': '|'.join(sig), 'market_regime': current_regime,
                'message': f'فقط {n} نمونه تاریخی مشابه پیدا شد؛ برای پیش‌بینی قابل اتکا کافی نیست.'}
            continue
        used += n
        item['brain_prediction'] = {
            'status': 'historical_analogs', 'analogs': n,
            'historical_extremes': extreme_pattern, 'cross_asset_analogs': cross_asset_summary, 'btc_lead_lag': lead_lag_summary,
            'feedback_validation': validation, 'pattern_learning': pattern_learning,
            'pattern_learning_overall': pattern_learning_overall, 'pattern_signature': '|'.join(sig), 'market_regime': current_regime,
            'similarity': 'الگوی جهت‌دار v2: مومنتوم ۴/۱۲/۲۴ساعته، حجم، نوسان، فشار کندل و پیوستگی روند',
            'horizons': {h: _probability(sample[h], positive=1.0 if h == '1h' else 2.0,
                                         negative=-1.0 if h == '1h' else -2.0)
                         for h in ('1h', '4h', '24h')},
            'note': 'احتمال‌ها از بازده نمونه‌های تاریخی مشابه محاسبه شده‌اند؛ تضمین آینده یا توصیه معامله نیستند.'
        }
    return {'status': 'ok' if row_count else 'empty_history_archive',
            'symbols_analyzed': analyzed, 'analogs_used': used,
            'historical_symbols': len(grouped), 'method': 'hourly_pattern_analogs_v2_directional',
            'archive_quality': archive_quality, 'cache_hit': cache_hit,
            'cache_built_ts': _PREDICTION_CACHE.get('built_ts')}


def record_feedback(items: list[dict], snapshots: dict | None = None, now: float | None = None) -> dict:
    """Persist brain forecasts and score them against later observed prices."""
    now = float(now if now is not None else time.time())
    FEEDBACK_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(FEEDBACK_DB_PATH), timeout=5)
    con.row_factory = sqlite3.Row
    try:
        con.execute("""CREATE TABLE IF NOT EXISTS brain_forecasts (
            id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, horizon TEXT NOT NULL,
            created_ts REAL NOT NULL, due_ts REAL NOT NULL, start_price REAL NOT NULL,
            predicted_up REAL NOT NULL, predicted_down REAL NOT NULL,
            observed_ts REAL, observed_return REAL, outcome TEXT, pattern_signature TEXT,
            market_regime TEXT, UNIQUE(symbol,horizon,created_ts))""")
        columns = {r[1] for r in con.execute('PRAGMA table_info(brain_forecasts)')}
        if 'pattern_signature' not in columns:
            con.execute('ALTER TABLE brain_forecasts ADD COLUMN pattern_signature TEXT')
        if 'market_regime' not in columns:
            con.execute('ALTER TABLE brain_forecasts ADD COLUMN market_regime TEXT')
        con.execute('CREATE INDEX IF NOT EXISTS idx_brain_feedback_pending ON brain_forecasts(outcome,due_ts)')
        prices = {}
        for key, value in (snapshots or {}).items():
            try:
                sym = str(key).upper().replace('/', '').replace('-', '').replace('_', '')
                sym = sym if sym.endswith('USDT') else sym + 'USDT'
                price = float(value.get('price'))
                if 0 < price < float('inf'):
                    prices[sym] = price
            except (AttributeError, TypeError, ValueError, OverflowError):
                continue
        for item in items:
            pred = item.get('brain_prediction') or {}
            if pred.get('status') != 'historical_analogs':
                continue
            symbol = str(item.get('symbol') or '').upper().replace('/', '').replace('-', '').replace('_', '')
            try:
                start_price = float(item.get('price'))
            except (TypeError, ValueError, OverflowError):
                continue
            if not symbol or not (0 < start_price < float('inf')):
                continue
            for horizon, seconds in FEEDBACK_HORIZONS.items():
                stats = (pred.get('horizons') or {}).get(horizon) or {}
                up, down = stats.get('up_pct'), stats.get('down_pct')
                if up is None or down is None:
                    continue
                con.execute("""INSERT OR IGNORE INTO brain_forecasts
                    (symbol,horizon,created_ts,due_ts,start_price,predicted_up,predicted_down,pattern_signature,market_regime)
                    VALUES(?,?,?,?,?,?,?,?,?)""", (symbol,horizon,now,now+seconds,start_price,float(up),float(down),
                    str(pred.get('pattern_signature') or '') or None, str(pred.get('market_regime') or 'unknown')))
        resolved = 0
        pending = con.execute('SELECT * FROM brain_forecasts WHERE outcome IS NULL AND due_ts<=?', (now,)).fetchall()
        for row in pending:
            price = prices.get(row['symbol'])
            if now > float(row['due_ts']) + max(7200, FEEDBACK_HORIZONS[row['horizon']] * 0.30):
                con.execute("UPDATE brain_forecasts SET outcome='missing_observation' WHERE id=?", (row['id'],))
                continue
            if price is None:
                continue
            ret = (price / row['start_price'] - 1.0) * 100.0
            outcome = 'up' if ret >= 1.0 else 'down' if ret <= -1.0 else 'neutral'
            con.execute('UPDATE brain_forecasts SET observed_ts=?,observed_return=?,outcome=? WHERE id=?',
                        (now, ret, outcome, row['id']))
            resolved += 1
        con.commit()
        totals = con.execute('SELECT COUNT(*) AS n, SUM(CASE WHEN outcome IS NOT NULL THEN 1 ELSE 0 END) AS resolved FROM brain_forecasts').fetchone()
        total = int(totals['n'] or 0); done = int(totals['resolved'] or 0)
        return {'forecasts_total': total, 'resolved_now': resolved, 'resolved_total': done, 'pending': total-done}
    finally:
        con.close()



def record_directional_signal_feedback(groups: dict, snapshots: dict | None = None, now: float | None = None) -> dict:
    """Track observed outcomes of directional scout lists independently of analog forecasts."""
    now = float(now if now is not None else time.time())
    FEEDBACK_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(FEEDBACK_DB_PATH), timeout=5)
    con.row_factory = sqlite3.Row
    try:
        con.execute("""CREATE TABLE IF NOT EXISTS directional_signal_feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, signal_type TEXT NOT NULL,
            direction TEXT NOT NULL, horizon TEXT NOT NULL, created_ts REAL NOT NULL,
            due_ts REAL NOT NULL, start_price REAL NOT NULL, observed_ts REAL,
            observed_return REAL, outcome TEXT, context_json TEXT, failure_reason TEXT,
            UNIQUE(symbol,signal_type,horizon,created_ts))""")
        columns = {r[1] for r in con.execute('PRAGMA table_info(directional_signal_feedback)')}
        if 'context_json' not in columns:
            con.execute('ALTER TABLE directional_signal_feedback ADD COLUMN context_json TEXT')
        if 'failure_reason' not in columns:
            con.execute('ALTER TABLE directional_signal_feedback ADD COLUMN failure_reason TEXT')
        con.execute('CREATE INDEX IF NOT EXISTS idx_directional_feedback_due ON directional_signal_feedback(outcome,due_ts)')
        prices = {}
        for key, value in (snapshots or {}).items():
            try:
                sym = str(key).upper().replace('/', '').replace('-', '').replace('_', '')
                sym = sym if sym.endswith('USDT') else sym + 'USDT'
                raw = value.get('price') if isinstance(value, dict) else value
                price = float(raw)
                if 0 < price < float('inf'):
                    prices[sym] = price
            except (AttributeError, TypeError, ValueError, OverflowError):
                continue
        inserted = 0
        for signal_type, rows in (groups or {}).items():
            direction = 'down' if 'dump' in signal_type else 'up'
            for item in rows or []:
                symbol = str(item.get('symbol') or '').upper().replace('/', '').replace('-', '').replace('_', '')
                try:
                    start = float(item.get('price'))
                except (TypeError, ValueError, OverflowError):
                    continue
                if not symbol or not (0 < start < float('inf')):
                    continue
                context_keys = ('pre_pump_score', 'pre_dump_score', 'active_dump_score',
                    'score', 'phase', 'trend', 'direction', 'pre_pump_grade', 'pre_dump_grade',
                    'pre_pump_price_change_1h_pct', 'pre_dump_price_change_1h_pct',
                    'active_dump_1h_change', 'active_dump_24h_change', 'buy_ratio', 'sell_ratio',
                    'volume_ratio', 'relative_strength', 'market_regime')
                context = {k: item.get(k) for k in context_keys if item.get(k) is not None}
                context_json = json.dumps(context, ensure_ascii=False, sort_keys=True, default=str)
                for horizon, seconds in DIRECTIONAL_SIGNAL_HORIZONS.items():
                    cur = con.execute("""INSERT OR IGNORE INTO directional_signal_feedback
                        (symbol,signal_type,direction,horizon,created_ts,due_ts,start_price,context_json)
                        VALUES(?,?,?,?,?,?,?,?)""", (symbol, signal_type, direction, horizon, now, now+seconds, start, context_json))
                    inserted += max(0, cur.rowcount)
        resolved = 0
        pending = con.execute('SELECT * FROM directional_signal_feedback WHERE outcome IS NULL AND due_ts<=?', (now,)).fetchall()
        for row in pending:
            price = prices.get(row['symbol'])
            grace = max(7200, DIRECTIONAL_SIGNAL_HORIZONS[row['horizon']] * 0.30)
            if now > float(row['due_ts']) + grace:
                con.execute("UPDATE directional_signal_feedback SET outcome='missing_observation' WHERE id=?", (row['id'],))
                continue
            if price is None:
                continue
            ret = (price / float(row['start_price']) - 1.0) * 100.0
            outcome = 'success' if (ret <= -1.0 if row['direction'] == 'down' else ret >= 1.0) else 'failure' if (ret >= 1.0 if row['direction'] == 'down' else ret <= -1.0) else 'neutral'
            if outcome == 'failure':
                failure_reason = 'opposite_move' if row['direction'] == 'down' else 'reversal_against_pump'
            elif outcome == 'neutral':
                failure_reason = 'no_follow_through'
            else:
                failure_reason = None
            con.execute('UPDATE directional_signal_feedback SET observed_ts=?,observed_return=?,outcome=?,failure_reason=? WHERE id=?', (now, ret, outcome, failure_reason, row['id']))
            resolved += 1
        con.commit()
        total = con.execute('SELECT COUNT(*) FROM directional_signal_feedback').fetchone()[0]
        done = con.execute("SELECT COUNT(*) FROM directional_signal_feedback WHERE outcome IS NOT NULL").fetchone()[0]
        return {'inserted': inserted, 'resolved_now': resolved, 'total': total, 'resolved_total': done, 'pending': total-done}
    finally:
        con.close()


def directional_signal_feedback_summary() -> dict:
    """Summarize success/failure by signal type and observation horizon."""
    if not FEEDBACK_DB_PATH.exists():
        return {'status': 'no_feedback_yet', 'signals': {}}
    con = sqlite3.connect(str(FEEDBACK_DB_PATH), timeout=3)
    con.row_factory = sqlite3.Row
    try:
        rows = con.execute("""SELECT signal_type,horizon,
            SUM(CASE WHEN outcome='success' THEN 1 ELSE 0 END) AS successes,
            SUM(CASE WHEN outcome='failure' THEN 1 ELSE 0 END) AS failures,
            SUM(CASE WHEN outcome='neutral' THEN 1 ELSE 0 END) AS neutral,
            SUM(CASE WHEN outcome='missing_observation' THEN 1 ELSE 0 END) AS missing,
            COUNT(*) AS total, AVG(observed_return) AS avg_return
            FROM directional_signal_feedback GROUP BY signal_type,horizon""").fetchall()
        result = {}
        for row in rows:
            signal = result.setdefault(row['signal_type'], {})
            resolved = int(row['successes'] or 0) + int(row['failures'] or 0) + int(row['neutral'] or 0)
            signal[row['horizon']] = {'successes': int(row['successes'] or 0), 'failures': int(row['failures'] or 0),
                'neutral': int(row['neutral'] or 0), 'missing_observation': int(row['missing'] or 0),
                'resolved': resolved, 'total': int(row['total'] or 0),
                'success_rate_pct': round(100*int(row['successes'] or 0)/resolved, 1) if resolved else None,
                'avg_return_pct': round(float(row['avg_return']), 3) if row['avg_return'] is not None else None}
        return {'status': 'ok', 'signals': result}
    finally:
        con.close()

def directional_failure_analysis(limit: int = 12) -> dict:
    """Explain resolved directional misses from stored signal-time context.

    This is observational only: it does not change scores, thresholds or trading.
    """
    if not FEEDBACK_DB_PATH.exists():
        return {'status': 'no_feedback_yet', 'groups': [], 'recent_failures': []}
    con = sqlite3.connect(str(FEEDBACK_DB_PATH), timeout=3)
    con.row_factory = sqlite3.Row
    try:
        rows = con.execute("""SELECT signal_type,horizon,failure_reason,COUNT(*) AS n,
            AVG(observed_return) AS avg_return
            FROM directional_signal_feedback
            WHERE outcome IN ('failure','neutral')
            GROUP BY signal_type,horizon,failure_reason
            ORDER BY n DESC,signal_type,horizon""").fetchall()
        groups = [{'signal_type': r['signal_type'], 'horizon': r['horizon'],
            'reason': r['failure_reason'] or 'unclassified', 'count': int(r['n']),
            'avg_return_pct': round(float(r['avg_return']), 3) if r['avg_return'] is not None else None}
            for r in rows]
        recent = con.execute("""SELECT symbol,signal_type,horizon,observed_return,outcome,
            failure_reason,context_json,created_ts FROM directional_signal_feedback
            WHERE outcome IN ('failure','neutral') ORDER BY observed_ts DESC LIMIT ?""", (max(1, min(int(limit), 50)),)).fetchall()
        recent_failures = []
        for r in recent:
            try:
                context = json.loads(r['context_json'] or '{}')
            except (TypeError, ValueError):
                context = {}
            recent_failures.append({'symbol': r['symbol'], 'signal_type': r['signal_type'],
                'horizon': r['horizon'], 'outcome': r['outcome'],
                'reason': r['failure_reason'] or 'unclassified',
                'observed_return_pct': round(float(r['observed_return']), 3) if r['observed_return'] is not None else None,
                'signal_context': context, 'created_ts': float(r['created_ts'])})
        return {'status': 'ok', 'groups': groups, 'recent_failures': recent_failures}
    finally:
        con.close()



def directional_failure_patterns(min_samples: int = 5) -> dict:
    """Find recurring signal-time conditions associated with poor outcomes.

    This is a diagnostic report only. It excludes missing observations and
    keeps each signal type/horizon separate to avoid mixing unlike outcomes.
    """
    if not FEEDBACK_DB_PATH.exists():
        return {'status': 'no_feedback_yet', 'min_samples': min_samples,
                'baseline': [], 'patterns': [], 'insufficient_samples': True}
    min_samples = max(3, min(int(min_samples), 100))
    con = sqlite3.connect(str(FEEDBACK_DB_PATH), timeout=3)
    con.row_factory = sqlite3.Row
    try:
        rows = con.execute("""SELECT signal_type,horizon,outcome,context_json
            FROM directional_signal_feedback
            WHERE outcome IN ('success','failure','neutral')""").fetchall()
        if not rows:
            return {'status': 'no_resolved_feedback', 'min_samples': min_samples,
                    'baseline': [], 'patterns': [], 'insufficient_samples': True}

        def bucket(key, value, signal_type):
            if value is None or value == '':
                return None
            if key in ('market_regime', 'phase'):
                return str(value).strip().lower()[:40]
            try:
                number = float(value)
            except (TypeError, ValueError, OverflowError):
                return None
            if key == 'sell_ratio':
                return '<0.45' if number < .45 else '0.45-0.55' if number < .55 else '0.55-0.65' if number < .65 else '>=0.65'
            if key == 'volume_ratio':
                return '<1.0' if number < 1 else '1.0-1.2' if number < 1.2 else '1.2-1.5' if number < 1.5 else '>=1.5'
            if key == 'score':
                return '<60' if number < 60 else '60-69' if number < 70 else '70-79' if number < 80 else '>=80'
            if key in ('pre_pump_score', 'pre_dump_score', 'active_dump_score'):
                return '<60' if number < 60 else '60-69' if number < 70 else '70-79' if number < 80 else '>=80'
            return None

        feature_keys = ('market_regime', 'phase', 'sell_ratio', 'volume_ratio',
                        'score', 'pre_pump_score', 'pre_dump_score', 'active_dump_score')
        buckets = defaultdict(lambda: {'n': 0, 'success': 0, 'failure': 0, 'neutral': 0})
        baselines = defaultdict(lambda: {'n': 0, 'success': 0, 'failure': 0, 'neutral': 0})
        for row in rows:
            outcome = row['outcome']
            base_key = (row['signal_type'], row['horizon'])
            base = baselines[base_key]
            base['n'] += 1; base[outcome] += 1
            try:
                context = json.loads(row['context_json'] or '{}')
            except (TypeError, ValueError):
                context = {}
            for key in feature_keys:
                value = bucket(key, context.get(key), row['signal_type'])
                if value is None:
                    continue
                group = buckets[(row['signal_type'], row['horizon'], key, value)]
                group['n'] += 1; group[outcome] += 1

        baseline_out = []
        baseline_rates = {}
        for key, counts in baselines.items():
            resolved = counts['n']
            fail_rate = counts['failure'] / resolved if resolved else 0.0
            baseline_rates[key] = fail_rate
            baseline_out.append({'signal_type': key[0], 'horizon': key[1],
                'resolved': resolved, 'successes': counts['success'],
                'failures': counts['failure'], 'neutral': counts['neutral'],
                'failure_rate_pct': round(fail_rate * 100, 1)})

        patterns = []
        for (signal_type, horizon, feature, value), counts in buckets.items():
            n = counts['n']
            if n < min_samples:
                continue
            rate = counts['failure'] / n
            baseline = baseline_rates.get((signal_type, horizon), 0.0)
            patterns.append({'signal_type': signal_type, 'horizon': horizon,
                'feature': feature, 'value': value, 'samples': n,
                'successes': counts['success'], 'failures': counts['failure'],
                'neutral': counts['neutral'], 'failure_rate_pct': round(rate * 100, 1),
                'baseline_failure_rate_pct': round(baseline * 100, 1),
                'failure_lift_pp': round((rate - baseline) * 100, 1),
                'evidence': 'exploratory'})
        patterns.sort(key=lambda x: (x['failure_lift_pp'], x['samples']), reverse=True)
        return {'status': 'ok', 'min_samples': min_samples, 'baseline': baseline_out,
                'patterns': patterns[:40],
                'insufficient_samples': not bool(patterns),
                'automatic_adjustment': False}
    finally:
        con.close()

def feedback_summary() -> dict:
    """Return compact historical forecast outcomes by horizon."""
    if not FEEDBACK_DB_PATH.exists():
        return {'status': 'no_feedback_yet', 'horizons': {}}
    con = sqlite3.connect(str(FEEDBACK_DB_PATH), timeout=3)
    con.row_factory = sqlite3.Row
    try:
        rows = con.execute("""SELECT horizon, outcome, COUNT(*) AS n, AVG(observed_return) AS avg_return
            FROM brain_forecasts WHERE outcome IN ('up','down','neutral') GROUP BY horizon,outcome""").fetchall()
        # Score only directional outcomes. Neutral outcomes are reported but do
        # not count as either a correct or incorrect directional call.
        directional_rows = con.execute("""SELECT horizon,
            SUM(CASE WHEN (predicted_up > predicted_down AND outcome='up') OR
                          (predicted_down > predicted_up AND outcome='down') THEN 1 ELSE 0 END) AS correct,
            SUM(CASE WHEN predicted_up != predicted_down THEN 1 ELSE 0 END) AS calls
            FROM brain_forecasts WHERE outcome IN ('up','down') GROUP BY horizon""").fetchall()
        directional = {r['horizon']: (int(r['correct'] or 0), int(r['calls'] or 0)) for r in directional_rows}
        out = {}
        for horizon in FEEDBACK_HORIZONS:
            subset = [r for r in rows if r['horizon'] == horizon]
            n = sum(int(r['n']) for r in subset)
            correct, calls = directional.get(horizon, (0, 0))
            accuracy = round(100 * correct / calls, 1) if calls else None
            # Reliability labels describe sample size, not forecast quality.
            reliability = 'insufficient_samples' if calls < 20 else 'developing' if calls < 50 else 'sample_established'
            out[horizon] = {'resolved': n, 'up': sum(int(r['n']) for r in subset if r['outcome']=='up'),
                            'down': sum(int(r['n']) for r in subset if r['outcome']=='down'),
                            'neutral': sum(int(r['n']) for r in subset if r['outcome']=='neutral'),
                            'avg_return_pct': round(sum(float(r['avg_return'] or 0)*int(r['n']) for r in subset)/n, 3) if n else None,
                            'directional_calls': calls, 'directional_correct': correct,
                            'directional_accuracy_pct': accuracy, 'reliability': reliability}
        forecast_columns = {row[1] for row in con.execute('PRAGMA table_info(brain_forecasts)')}
        regime_expr = 'market_regime' if 'market_regime' in forecast_columns else "'unknown'"
        regime_rows = con.execute(f"""SELECT {regime_expr} AS market_regime,horizon,
            SUM(CASE WHEN (predicted_up > predicted_down AND outcome='up') OR
                          (predicted_down > predicted_up AND outcome='down') THEN 1 ELSE 0 END) AS correct,
            SUM(CASE WHEN predicted_up != predicted_down THEN 1 ELSE 0 END) AS calls
            FROM brain_forecasts WHERE outcome IN ('up','down')
            GROUP BY {regime_expr},horizon""").fetchall()
        regimes = {}
        for row in regime_rows:
            regime = row['market_regime'] or 'unknown'
            bucket = regimes.setdefault(regime, {})
            calls = int(row['calls'] or 0); correct = int(row['correct'] or 0)
            bucket[row['horizon']] = {
                'directional_calls': calls, 'directional_correct': correct,
                'accuracy_pct': round(100 * correct / calls, 1) if calls else None,
                'reliability': 'insufficient_samples' if calls < 20 else 'sample_established'
            }
        return {'status': 'ok', 'horizons': out, 'market_regimes': regimes}
    finally:
        con.close()
