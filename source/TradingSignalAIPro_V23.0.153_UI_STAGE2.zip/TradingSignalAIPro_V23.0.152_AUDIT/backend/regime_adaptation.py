"""Read-only, exact-regime strategy evidence and transition diagnostics."""
from __future__ import annotations
from collections import defaultdict
import math
from backend.strategy_validation import _context, _metrics

ALLOWED = {"UPTREND", "DOWNTREND", "RANGE", "HIGH_VOLATILITY", "TRANSITION",
           "BULLISH", "BEARISH", "RANGING", "UNKNOWN"}


def build_regime_adaptation_report(events, *, symbol, timeframe, current_regime,
                                   previous_regime=None, market="perp", side="LONG",
                                   min_trades=8):
    symbol = str(symbol or "").upper().replace("/", "").strip()
    timeframe = str(timeframe or "").lower().strip()
    market = str(market or "perp").lower().strip()
    side = str(side or "LONG").upper().strip()
    current = str(current_regime or "").upper().strip()
    previous = str(previous_regime or "").upper().strip() or None
    if not symbol or not timeframe or market not in {"spot", "perp"} or side not in {"LONG", "SHORT"}:
        raise ValueError("symbol/timeframe معتبر و market=spot|perp و side=LONG|SHORT لازم است")
    if current not in ALLOWED or (previous and previous not in ALLOWED):
        raise ValueError("current_regime یا previous_regime نامعتبر است")
    min_trades = int(min_trades)
    if not 2 <= min_trades <= 500:
        raise ValueError("min_trades باید بین ۲ تا ۵۰۰ باشد")

    # Keep the complete strategy/context cohort identity; no cross-symbol or cross-TF pooling.
    groups = defaultdict(list)
    matching_events = 0
    for row in events or []:
        try:
            ctx = _context(row)
            strategy, row_symbol, row_market, row_tf, row_side, regime, volatility = ctx
            if (row_symbol, row_market, row_tf, row_side) != (symbol, market, timeframe, side):
                continue
            pnl = float(row.get("net_pnl"))
            closed = str(row.get("closed_at") or "").strip()
            if not math.isfinite(pnl) or not closed:
                continue
            groups[(strategy, regime, volatility)].append((closed, str(row.get("trade_id") or ""), pnl))
            matching_events += 1
        except (TypeError, ValueError):
            continue

    current_rows = []
    other_regimes = defaultdict(list)
    for (strategy, regime, volatility), values in groups.items():
        values.sort(key=lambda x: (x[0], x[1]))
        metrics = _metrics([{"net_pnl": x[2]} for x in values])
        item = {"strategy": strategy, "market_regime": regime,
                "volatility_regime": volatility, **metrics,
                "first_closed_at": values[0][0], "last_closed_at": values[-1][0],
                "sample_sufficient": len(values) >= min_trades}
        if regime == current:
            current_rows.append(item)
        else:
            other_regimes[regime].append(item)

    for item in current_rows:
        # Shrink expectancy toward zero to discourage small lucky samples.
        n = item["trades"]
        item["conservative_expectancy_usdt"] = round(item["expectancy_usdt"] * n / (n + 10.0), 8)
        if not item["sample_sufficient"]:
            item["evidence_state"] = "INSUFFICIENT_DATA"
        elif item["conservative_expectancy_usdt"] > 0 and (item["profit_factor"] or 0) > 1:
            item["evidence_state"] = "POSITIVE_HISTORICAL_EVIDENCE"
        else:
            item["evidence_state"] = "NO_CONFIRMED_EDGE"
    current_rows.sort(key=lambda x: (x["evidence_state"] == "POSITIVE_HISTORICAL_EVIDENCE",
                                    x["conservative_expectancy_usdt"], x["trades"]), reverse=True)

    regime_summaries = []
    for regime, items in other_regimes.items():
        trades = sum(x["trades"] for x in items)
        pnl_weighted = sum(x["expectancy_usdt"] * x["trades"] for x in items)
        regime_summaries.append({"regime": regime, "strategies": len(items), "trades": trades,
                                 "expectancy_usdt": round(pnl_weighted / trades, 8) if trades else None,
                                 "is_alternative_evidence_only": True})
    regime_summaries.sort(key=lambda x: x["regime"])
    changed = bool(previous and previous != current)
    return {
        "symbol": symbol, "market": market, "timeframe": timeframe, "side": side,
        "previous_regime": previous, "current_regime": current,
        "regime_transition_detected": changed,
        "transition": {"from": previous, "to": current} if changed else None,
        "current_regime_strategy_evidence": current_rows,
        "alternative_regime_history": regime_summaries,
        "recommended_action": ("NO_STRATEGY_HAS_SUFFICIENT_POSITIVE_EVIDENCE" if not any(
            x["evidence_state"] == "POSITIVE_HISTORICAL_EVIDENCE" for x in current_rows)
            else "REVIEW_CURRENT_REGIME_CANDIDATES_ONLY"),
        "matching_closed_trade_count": matching_events, "min_trades": min_trades,
        "exact_symbol_market_timeframe_side": True,
        "cross_regime_fallback": False, "automatic_strategy_switch": False,
        "source": "RECONCILED_CLOSED_PAPER_TRADES_ONLY",
        "read_only": True, "paper_only": True, "authorizes_entries": False,
        "real_orders_enabled": False,
        "warning": "این گزارش فقط شواهد تاریخی همان رژیم را نشان می‌دهد؛ عملکرد گذشته تضمین آینده نیست و تغییر خودکار استراتژی انجام نمی‌شود."
    }
