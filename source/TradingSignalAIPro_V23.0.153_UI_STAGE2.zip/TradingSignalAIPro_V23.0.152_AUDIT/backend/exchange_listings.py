"""Read-only exchange market coverage lookup for Storm Scout coins.

Only public market-list/ticker endpoints are used. A provider failure is
reported as UNKNOWN, never as NOT_LISTED. No account credentials or trading
endpoints are used.
"""
from __future__ import annotations

import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any, Callable

import requests

_TIMEOUT = (3.5, 5.5)
_CACHE_TTL = 300
_CACHE_LOCK = threading.RLock()
_CACHE: dict[str, Any] = {"expires": 0.0, "snapshot": None}
_SESSION = requests.Session()
_PROXY = (os.getenv("TS_AI_PROXY") or os.getenv("SCOUT_PROXY") or "").strip()
if _PROXY:
    _SESSION.proxies.update({"http": _PROXY, "https": _PROXY})

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; TradingSignalAIPro/22.7; market-listings)",
    "Accept": "application/json",
}

IRANIAN = [
    ("nobitex", "نوبیتکس", "https://nobitex.ir"),
    ("wallex", "والکس", "https://wallex.ir"),
    ("bitpin", "بیت‌پین", "https://bitpin.ir"),
    ("ramzinex", "رمزینکس", "https://ramzinex.ir"),
    ("tabdeal", "تبدیل", "https://tabdeal.org"),
    ("ompfinex", "او ام پی فینکس", "https://ompfinex.com"),
    ("exir", "اکسیر", "https://exir.io"),
    ("bit24", "بیت ۲۴", "https://bit24.cash"),
]
INTERNATIONAL = [
    ("binance", "Binance", "https://www.binance.com"),
    ("mexc", "MEXC", "https://www.mexc.com"),
    ("bybit", "Bybit", "https://www.bybit.com"),
    ("okx", "OKX", "https://www.okx.com"),
    ("gate", "Gate.io", "https://www.gate.io"),
]


def _get_json(url: str, params: dict | None = None) -> Any:
    response = _SESSION.get(url, params=params, timeout=_TIMEOUT, headers=_HEADERS)
    response.raise_for_status()
    return response.json()


def _base(value: Any) -> str:
    s = str(value or "").upper().strip()
    return s if re.fullmatch(r"[A-Z0-9]{2,15}", s) else ""


def _market(base: Any, quote: Any, symbol: Any = None, active: Any = True) -> dict | None:
    b = _base(base)
    q = str(quote or "").upper().strip()
    if not b or not q or active is False:
        return None
    qlabel = {
        "USDT": "تتر", "IRT": "تومان", "TMN": "تومان",
        "IRR": "ریال", "RLS": "ریال",
    }.get(q, q)
    return {"base": b, "quote": q, "quote_label": qlabel,
            "symbol": str(symbol or f"{b}/{q}"), "active": active is not False}


def parse_nobitex(payload: dict) -> list[dict]:
    out = []
    stats = payload.get("stats") or {}
    for pair, row in stats.items():
        base, sep, quote = str(pair).partition("-")
        if sep:
            m = _market(base, quote, pair.upper(), not bool((row or {}).get("isClosed")))
            if m: out.append(m)
    return out


def parse_wallex(payload: dict) -> list[dict]:
    symbols = ((payload.get("result") or {}).get("symbols") or {})
    if isinstance(symbols, list):
        rows = symbols
    else:
        rows = list(symbols.values())
    out = []
    for row in rows:
        if not isinstance(row, dict): continue
        out.append(_market(row.get("baseAsset"), row.get("quoteAsset"),
                           row.get("symbol"), row.get("status") not in ("CLOSED", "DISABLED", False)))
    return [x for x in out if x]


def parse_bitpin(payload: Any) -> list[dict]:
    rows = payload.get("results", []) if isinstance(payload, dict) else payload
    if isinstance(rows, dict): rows = rows.get("results", [])
    out = []
    for row in rows or []:
        if not isinstance(row, dict): continue
        symbol = str(row.get("symbol") or row.get("code") or "")
        base, sep, quote = symbol.replace("-", "_").partition("_")
        if sep:
            m = _market(base, quote, symbol, row.get("status") not in ("closed", "disabled", False))
            if m: out.append(m)
    return out


def parse_ramzinex(payload: dict) -> list[dict]:
    rows = payload.get("data", [])
    out = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict) or row.get("is_delist"): continue
        b = ((row.get("base_currency_symbol") or {}).get("en") or "").split()[0]
        q = ((row.get("quote_currency_symbol") or {}).get("en") or "").split()[0]
        m = _market(b, q, row.get("symbol") or f"{b}/{q}", row.get("is_active", True))
        if m: out.append(m)
    return out


def parse_tabdeal(payload: dict) -> list[dict]:
    currencies = payload.get("currencies") or {}
    out = []
    if isinstance(currencies, dict):
        for base, quotes in currencies.items():
            if isinstance(quotes, dict):
                for quote, item in quotes.items():
                    if item is not None and item is not False:
                        m = _market(base, quote, f"{base}{quote}")
                        if m: out.append(m)
    return out


def parse_ompfinex(payload: dict) -> list[dict]:
    rows = payload.get("data", [])
    out = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict): continue
        m = _market(row.get("baseCurrencyId"), row.get("quoteCurrencyId"),
                    row.get("symbol") or row.get("id"), row.get("status") == "LISTED")
        if m: out.append(m)
    return out


def parse_exir(payload: dict) -> list[dict]:
    out = []
    for pair in (payload or {}).keys():
        base, sep, quote = str(pair).partition("-")
        if sep:
            m = _market(base, quote, pair)
            if m: out.append(m)
    return out


def parse_binance(payload: dict) -> list[dict]:
    out = []
    for row in payload.get("symbols", []) or []:
        m = _market(row.get("baseAsset"), row.get("quoteAsset"), row.get("symbol"),
                    row.get("status") == "TRADING" and row.get("isSpotTradingAllowed", True))
        if m: out.append(m)
    return out


def parse_mexc(payload: dict) -> list[dict]:
    out = []
    for row in payload.get("symbols", []) or []:
        m = _market(row.get("baseAsset"), row.get("quoteAsset"), row.get("symbol"),
                    row.get("status") in ("1", 1, "ENABLED", "TRADING"))
        if m: out.append(m)
    return out


def parse_bybit(payload: dict) -> list[dict]:
    out = []
    for row in ((payload.get("result") or {}).get("list") or []):
        m = _market(row.get("baseCoin"), row.get("quoteCoin"), row.get("symbol"),
                    row.get("status") == "Trading")
        if m: out.append(m)
    return out


def parse_okx(payload: dict) -> list[dict]:
    out = []
    for row in payload.get("data", []) or []:
        base, sep, quote = str(row.get("instId") or "").partition("-")
        if sep:
            m = _market(base, quote, row.get("instId"), row.get("state") == "live")
            if m: out.append(m)
    return out


def parse_gate(payload: Any) -> list[dict]:
    out = []
    for row in payload if isinstance(payload, list) else []:
        base, sep, quote = str(row.get("id") or row.get("currency_pair") or "").partition("_")
        if sep:
            m = _market(base, quote, row.get("id") or row.get("currency_pair"),
                        row.get("trade_status", "tradable") == "tradable")
            if m: out.append(m)
    return out


def fetch_bit24_markets() -> list[dict]:
    """Bit24 market-list API is documented as API-key authenticated.

    Do not guess listing status when the operator has not configured credentials.
    The tooltip will show UNKNOWN rather than incorrectly saying not listed.
    """
    if not (os.getenv("BIT24_API_KEY") or "").strip():
        raise RuntimeError("Bit24 markets API نیازمند BIT24_API_KEY است؛ وضعیت نامشخص")
    # The documented endpoint is /v1/pro/capi/v1/markets. Authentication
    # details can vary by API account; keep this provider fail-closed if the
    # configured key is rejected instead of reporting a false negative.
    payload = _get_json(
        "https://rest.bit24.cash/v1/pro/capi/v1/markets",
        params={"page": 1},
    )
    rows = payload.get("results", []) if isinstance(payload, dict) else []
    out = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        m = _market(
            row.get("base_coin_symbol"), row.get("quote_coin_symbol"),
            f"{row.get('base_coin_symbol', '')}/{row.get('quote_coin_symbol', '')}",
            row.get("is_active", True) in (1, True, "1", "true"),
        )
        if m:
            out.append(m)
    return out


PROVIDERS: list[tuple[str, str, str, Callable[[], list[dict]]]] = [
    ("nobitex", "نوبیتکس", "https://nobitex.ir", lambda: parse_nobitex(_get_json("https://apiv2.nobitex.ir/market/stats"))),
    ("wallex", "والکس", "https://wallex.ir", lambda: parse_wallex(_get_json("https://api.wallex.ir/v1/markets"))),
    ("bitpin", "بیت‌پین", "https://bitpin.ir", lambda: parse_bitpin(_get_json("https://api.bitpin.ir/api/v1/mkt/tickers/"))),
    ("ramzinex", "رمزینکس", "https://ramzinex.ir", lambda: parse_ramzinex(_get_json("https://api.ramzinex.ir/exchange/api/v1.0/exchange/pairs"))),
    ("tabdeal", "تبدیل", "https://tabdeal.org", lambda: parse_tabdeal(_get_json("https://api-web.tabdeal.org/r/plots/currencies/dynamic-info/"))),
    ("ompfinex", "او ام پی فینکس", "https://ompfinex.com", lambda: parse_ompfinex(_get_json("https://api.ompfinex.com/v2/market"))),
    ("exir", "اکسیر", "https://exir.io", lambda: parse_exir(_get_json("https://api.exir.io/v2/ticker/all"))),
    ("bit24", "بیت ۲۴", "https://bit24.cash", fetch_bit24_markets),
    ("binance", "Binance", "https://www.binance.com", lambda: parse_binance(_get_json("https://data-api.binance.vision/api/v3/exchangeInfo"))),
    ("mexc", "MEXC", "https://www.mexc.com", lambda: parse_mexc(_get_json("https://api.mexc.com/api/v3/exchangeInfo"))),
    ("bybit", "Bybit", "https://www.bybit.com", lambda: parse_bybit(_get_json("https://api.bybit.com/v5/market/instruments-info", {"category": "spot", "limit": 1000}))),
    ("okx", "OKX", "https://www.okx.com", lambda: parse_okx(_get_json("https://www.okx.com/api/v5/public/instruments", {"instType": "SPOT"}))),
    ("gate", "Gate.io", "https://www.gate.io", lambda: parse_gate(_get_json("https://api.gateio.ws/api/v4/spot/currency_pairs"))),
]


def _snapshot(force: bool = False) -> dict:
    now = time.time()
    with _CACHE_LOCK:
        cached = _CACHE.get("snapshot")
        if not force and cached and _CACHE.get("expires", 0) > now:
            return cached
    results: dict[str, list[dict]] = {}
    statuses: dict[str, dict] = {}
    with ThreadPoolExecutor(max_workers=len(PROVIDERS)) as pool:
        futures = {pool.submit(fn): (key, name, site) for key, name, site, fn in PROVIDERS}
        for future in as_completed(futures):
            key, name, site = futures[future]
            try:
                markets = future.result()
                if not markets:
                    raise RuntimeError("فهرست بازار خالی یا ساختار پاسخ تغییر کرده است")
                results[key] = markets
                statuses[key] = {"id": key, "name": name, "site": site, "ok": True, "market_count": len(markets)}
            except Exception as exc:
                statuses[key] = {"id": key, "name": name, "site": site, "ok": False,
                                 "error": str(exc)[:120]}
    snap = {"markets": results, "providers": statuses,
            "checked_at": int(time.time()), "cache_ttl_seconds": _CACHE_TTL}
    with _CACHE_LOCK:
        _CACHE.update(snapshot=snap, expires=time.time() + _CACHE_TTL)
    return snap


def coin_listings(base: str, force: bool = False) -> dict:
    base = _base(base)
    if not base:
        raise ValueError("نماد ارز نامعتبر است")
    snap = _snapshot(force=force)
    groups = {"iranian": [], "international": []}
    for group, definitions in (("iranian", IRANIAN), ("international", INTERNATIONAL)):
        for key, name, site in definitions:
            provider = snap["providers"].get(key) or {"ok": False, "error": "منبع بررسی نشده"}
            markets = [m for m in snap["markets"].get(key, []) if m["base"] == base]
            if not provider.get("ok"):
                status = "unknown"
            elif markets:
                status = "listed"
            else:
                status = "not_listed"
            groups[group].append({"id": key, "name": name, "site": site, "status": status,
                                  "markets": sorted(markets, key=lambda m: m["quote"])})
    return {"base": base, "checked_at": snap["checked_at"], "cache_ttl_seconds": snap["cache_ttl_seconds"],
            "groups": groups,
            "summary": {"iranian_listed": sum(x["status"] == "listed" for x in groups["iranian"]),
                        "international_listed": sum(x["status"] == "listed" for x in groups["international"]),
                        "unknown": sum(x["status"] == "unknown" for xs in groups.values() for x in xs)}}
