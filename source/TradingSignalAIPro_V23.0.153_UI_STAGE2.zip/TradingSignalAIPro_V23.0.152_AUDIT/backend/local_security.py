"""Small dependency-free host validation for the unauthenticated local API."""
import ipaddress


def is_loopback_bind_host(host: str) -> bool:
    value = str(host or '').strip().lower()
    if value == 'localhost':
        return True
    try:
        return ipaddress.ip_address(value).is_loopback
    except ValueError:
        return False
