"""Read-only public BTCUSDT 4h candle fetch and quality gate; no order endpoints exist here."""
from __future__ import annotations
import hashlib, json, math, os, time, urllib.parse, urllib.request
from datetime import datetime, timezone
from pathlib import Path

BASE_URL='https://api.binance.com'
INTERVAL_MS=4*60*60*1000
MAX_RESPONSE_BYTES=2*1024*1024


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()


def validate_btc_4h_candles(candles, *, now_ms=None, max_age_hours=8,
                             require_closed=True, require_contiguous=True):
    if not isinstance(candles,list) or len(candles)<2:
        raise ValueError('live_candle_batch_too_small')
    now_ms=int(now_ms if now_ms is not None else time.time()*1000)
    rows=[]; prior=None
    for index,item in enumerate(candles):
        if not isinstance(item,dict): raise ValueError(f'live_candle_invalid_row:{index}')
        try:
            row={'t':int(item['t']),'open':float(item['open']),'high':float(item['high']),
                 'low':float(item['low']),'close':float(item['close']),'volume':float(item['volume']),
                 'close_time':int(item['close_time'])}
        except (KeyError,TypeError,ValueError) as exc: raise ValueError(f'live_candle_schema_invalid:{index}') from exc
        if row['t'] % INTERVAL_MS: raise ValueError(f'live_candle_timestamp_alignment_invalid:{index}')
        if prior is not None:
            if row['t'] <= prior: raise ValueError('live_candle_timestamp_duplicate_or_reordered')
            if require_contiguous and row['t']-prior != INTERVAL_MS: raise ValueError('live_candle_gap_detected')
        if not all(math.isfinite(row[k]) for k in ('open','high','low','close','volume')):
            raise ValueError(f'live_candle_non_finite_value:{index}')
        if row['low'] <= 0 or row['high'] < row['low'] or row['volume'] < 0:
            raise ValueError(f'live_candle_ohlcv_range_invalid:{index}')
        if not (row['low'] <= row['open'] <= row['high'] and row['low'] <= row['close'] <= row['high']):
            raise ValueError(f'live_candle_ohlc_inconsistent:{index}')
        if row['close_time'] != row['t']+INTERVAL_MS-1:
            raise ValueError(f'live_candle_close_time_invalid:{index}')
        if require_closed and row['close_time'] >= now_ms:
            raise ValueError(f'live_candle_not_closed:{index}')
        rows.append(row); prior=row['t']
    age_hours=(now_ms-rows[-1]['close_time'])/3600000
    if age_hours > max_age_hours: raise ValueError('live_candle_data_stale')
    if age_hours < 0: raise ValueError('live_candle_future_close_time')
    digest=hashlib.sha256(_canonical(rows)).hexdigest()
    return {'status':'PASS','symbol':'BTCUSDT','timeframe':'4h','row_count':len(rows),
            'first_open_time':rows[0]['t'],'last_open_time':rows[-1]['t'],
            'latest_age_hours':round(age_hours,4),'candles_sha256':digest,'candles':rows}


def fetch_binance_btc_4h_readonly(*, limit=200, timeout=10.0, now_ms=None,
                                   max_age_hours=8, require_contiguous=True):
    """Fetch public klines only. This function cannot place/cancel orders."""
    if isinstance(limit,bool) or not isinstance(limit,int) or not 2 <= limit <= 1000:
        raise ValueError('live_fetch_limit_out_of_range')
    query=urllib.parse.urlencode({'symbol':'BTCUSDT','interval':'4h','limit':limit})
    url=BASE_URL+'/api/v3/klines?'+query
    request=urllib.request.Request(url,headers={'Accept':'application/json','User-Agent':'TradingSignalAIPro-ReadOnly/22.4'},method='GET')
    try:
        with urllib.request.urlopen(request,timeout=timeout) as response:
            raw=response.read(MAX_RESPONSE_BYTES+1)
            if len(raw)>MAX_RESPONSE_BYTES: raise ValueError('live_response_too_large')
            if getattr(response,'status',200)!=200: raise ValueError(f'live_http_status:{response.status}')
        data=json.loads(raw.decode('utf-8'))
    except Exception as exc:
        if isinstance(exc,ValueError): raise
        raise RuntimeError(f'live_binance_readonly_request_failed:{type(exc).__name__}:{exc}') from exc
    if not isinstance(data,list): raise ValueError('live_binance_klines_payload_invalid')
    rows=[]
    for index,kline in enumerate(data):
        if not isinstance(kline,list) or len(kline)<7: raise ValueError(f'live_binance_kline_invalid:{index}')
        rows.append({'t':int(kline[0]),'open':float(kline[1]),'high':float(kline[2]),
                     'low':float(kline[3]),'close':float(kline[4]),'volume':float(kline[5]),
                     'close_time':int(kline[6])})
    report=validate_btc_4h_candles(rows,now_ms=now_ms,max_age_hours=max_age_hours,
                                   require_closed=True,require_contiguous=require_contiguous)
    report['source']='Binance public market-data REST API'
    report['fetched_at_utc']=datetime.now(timezone.utc).isoformat()
    report['read_only']=True
    report['endpoint_path']='/api/v3/klines'
    return report


def save_readonly_live_report(report, *, output_path):
    if not isinstance(report,dict) or report.get('status')!='PASS' or report.get('read_only') is not True:
        raise ValueError('live_readonly_report_not_passed')
    path=Path(output_path).expanduser(); path.parent.mkdir(parents=True,exist_ok=True)
    raw=_canonical(report)+b'\n'
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    return {'saved':True,'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),
            'row_count':report['row_count'],'read_only':True}
