"""Standalone append-only Witness service for V22.2m.

Deploy this module on a separately administered host. It is intentionally not
started by the trading application. SQLite provides transactional sequencing;
Ed25519 receipts let clients verify the server's statement independently.
"""
from __future__ import annotations
import base64, hashlib, json, os, secrets, sqlite3, stat
from datetime import datetime, timezone
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

SCHEMA = 'ts-ai-external-witness-v1'

def canonical(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')

def digest_anchor(anchor: dict) -> str:
    return hashlib.sha256(canonical(anchor)).hexdigest()

def _private_key(path: str | Path) -> Ed25519PrivateKey:
    raw = Path(path).read_bytes()
    key = serialization.load_pem_private_key(raw, password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise ValueError('witness_signing_key_must_be_ed25519')
    return key

def bootstrap_keys(private_path: str | Path, public_path: str | Path) -> dict:
    """Explicit one-time key creation. Refuses to overwrite existing material."""
    priv, pub = Path(private_path), Path(public_path)
    if priv.exists() or pub.exists():
        raise FileExistsError('refusing_to_overwrite_existing_witness_keys')
    priv.parent.mkdir(parents=True, exist_ok=True)
    pub.parent.mkdir(parents=True, exist_ok=True)
    key = Ed25519PrivateKey.generate()
    private_pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    public_pem = key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    fd = os.open(str(priv), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f: f.write(private_pem); f.flush(); os.fsync(f.fileno())
    fd = os.open(str(pub), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    with os.fdopen(fd, 'wb') as f: f.write(public_pem); f.flush(); os.fsync(f.fileno())
    fp = hashlib.sha256(public_pem).hexdigest()
    return {'public_key_fingerprint_sha256': fp, 'private_key_path': str(priv), 'public_key_path': str(pub)}

def init_db(db_path: str | Path) -> None:
    p = Path(db_path); p.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(p) as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('''CREATE TABLE IF NOT EXISTS anchors (
            sequence INTEGER PRIMARY KEY AUTOINCREMENT,
            witness_id TEXT NOT NULL,
            schema_version TEXT NOT NULL,
            anchor_digest TEXT NOT NULL UNIQUE,
            anchor_json TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            signature TEXT NOT NULL
        )''')
        db.executescript('''
        CREATE TRIGGER IF NOT EXISTS anchors_no_update BEFORE UPDATE ON anchors BEGIN SELECT RAISE(ABORT, 'append_only'); END;
        CREATE TRIGGER IF NOT EXISTS anchors_no_delete BEFORE DELETE ON anchors BEGIN SELECT RAISE(ABORT, 'append_only'); END;
        ''')

def record_anchor(db_path: str | Path, key_path: str | Path, anchor: dict, *, witness_id: str = 'ts-ai-witness') -> dict:
    if not isinstance(anchor, dict) or not anchor: raise ValueError('anchor_must_be_nonempty_object')
    dg = digest_anchor(anchor)
    key = _private_key(key_path)
    timestamp = datetime.now(timezone.utc).isoformat()
    p = Path(db_path); p.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(p, timeout=15, isolation_level=None)
    try:
        db.execute('PRAGMA busy_timeout=15000')
        db.execute('BEGIN IMMEDIATE')
        prior = db.execute('SELECT sequence, witness_id, schema_version, anchor_digest, timestamp, signature FROM anchors WHERE anchor_digest=?', (dg,)).fetchone()
        if prior:
            seq, wid, schema, ad, ts, sig = prior
            db.execute('COMMIT')
            return {'schema_version': schema, 'witness_id': wid, 'anchor_digest': ad, 'sequence': seq, 'timestamp': ts, 'signature': sig, 'duplicate': True}
        seq = db.execute('SELECT COALESCE(MAX(sequence),0)+1 FROM anchors').fetchone()[0]
        payload = {'schema_version': SCHEMA, 'witness_id': witness_id, 'anchor_digest': dg, 'sequence': seq, 'timestamp': timestamp}
        signature = base64.b64encode(key.sign(canonical(payload))).decode('ascii')
        db.execute('INSERT INTO anchors(sequence,witness_id,schema_version,anchor_digest,anchor_json,timestamp,signature) VALUES(?,?,?,?,?,?,?)',
                   (seq, witness_id, SCHEMA, dg, canonical(anchor).decode(), timestamp, signature))
        db.execute('COMMIT')
        return {**payload, 'signature': signature, 'duplicate': False}
    except Exception:
        if db.in_transaction: db.execute('ROLLBACK')
        raise
    finally: db.close()

def verify_anchor_record(receipt: dict, public_key_path: str | Path) -> bool:
    pub = serialization.load_pem_public_key(Path(public_key_path).read_bytes())
    payload = {k: receipt[k] for k in ('schema_version','witness_id','anchor_digest','sequence','timestamp')}
    pub.verify(base64.b64decode(receipt['signature'], validate=True), canonical(payload))
    return True

def backup_database(db_path: str | Path, backup_path: str | Path) -> dict:
    """Consistent SQLite online backup; refuses to overwrite an existing backup."""
    src, dst = Path(db_path), Path(backup_path)
    if dst.exists(): raise FileExistsError('backup_destination_exists')
    dst.parent.mkdir(parents=True, exist_ok=True)
    temp = dst.with_name(dst.name + '.tmp')
    if temp.exists(): temp.unlink()
    with sqlite3.connect(src) as source, sqlite3.connect(temp) as target:
        source.backup(target)
        target.execute('PRAGMA integrity_check')
    os.replace(temp, dst)
    h = hashlib.sha256(dst.read_bytes()).hexdigest()
    return {'path': str(dst), 'sha256': h, 'bytes': dst.stat().st_size}

def create_app(db_path: str | Path | None = None, key_path: str | Path | None = None, *, api_token: str | None = None, witness_id: str | None = None, trusted_source_public_key_path: str | Path | None = None):
    """Create the separately hosted Flask app. Flask is a deployment dependency."""
    from flask import Flask, jsonify, request
    db_path = db_path or os.getenv('TS_WITNESS_DB', 'witness-data/witness.sqlite3')
    key_path = key_path or os.getenv('TS_WITNESS_PRIVATE_KEY', 'witness-keys/witness-private.pem')
    token = api_token if api_token is not None else os.getenv('TS_WITNESS_API_TOKEN', '')
    token_file = os.getenv('TS_WITNESS_API_TOKEN_FILE', '')
    if api_token is None and token_file:
        token = Path(token_file).read_text(encoding='utf-8').strip()
    wid = witness_id or os.getenv('TS_WITNESS_ID', 'ts-ai-witness')
    trusted_source_public_key_path = trusted_source_public_key_path or os.getenv('TS_WITNESS_TRUSTED_SOURCE_PUBLIC_KEY', '')
    app = Flask(__name__)
    # Bound request bodies before Flask parses JSON. Keep payload limits configurable
    # but never allow an unbounded request body.
    try:
        max_body_bytes = int(os.getenv('TS_WITNESS_MAX_BODY_BYTES', '2097152'))
        rate_limit = int(os.getenv('TS_WITNESS_RATE_LIMIT', '120'))
        rate_window = int(os.getenv('TS_WITNESS_RATE_WINDOW_SECONDS', '60'))
    except ValueError as exc:
        raise ValueError('witness_security_configuration_invalid') from exc
    if not 1024 <= max_body_bytes <= 16 * 1024 * 1024:
        raise ValueError('witness_max_body_bytes_out_of_range')
    from backend.witness_security import FixedWindowRateLimiter, validate_json_shape
    limiter = FixedWindowRateLimiter(rate_limit, rate_window)
    app.config['MAX_CONTENT_LENGTH'] = max_body_bytes
    app.config['JSON_SORT_KEYS'] = True

    @app.before_request
    def security_gate():
        # Never trust X-Forwarded-For here: only use REMOTE_ADDR unless a trusted
        # proxy is explicitly configured at the deployment edge.
        identity = request.remote_addr or 'unknown'
        if not limiter.allow(identity):
            return jsonify({'error': 'rate_limit_exceeded'}), 429, {'Retry-After': str(rate_window)}
        if request.method in ('POST', 'PUT', 'PATCH') and request.path.startswith('/v1/'):
            if not request.is_json:
                return jsonify({'error': 'application_json_required'}), 415
            try:
                payload = request.get_json(silent=False)
                validate_json_shape(payload)
            except Exception as exc:
                return jsonify({'error': 'invalid_or_excessive_json', 'detail': str(exc)[:120]}), 400
        return None

    init_db(db_path)
    from backend.witness_security_ops import init_security_schema, record_security_event, security_status, verify_security_chain, inspect_key_pair, key_fingerprint
    init_security_schema(db_path)

    @app.after_request
    def security_audit_response(response):
        # Log denials and security-relevant successful operations only. Never log
        # Authorization headers, bodies, query strings, raw IPs or exception text.
        code = int(response.status_code)
        route = request.path
        category = None
        if code == 401: category = 'auth_denied'
        elif code == 403: category = 'access_denied'
        elif code == 429: category = 'rate_limited'
        elif code == 413: category = 'body_too_large'
        elif code == 415: category = 'content_type_rejected'
        elif code == 400: category = 'input_rejected'
        elif code < 400 and route.startswith('/v1/replication/'): category = 'replication_accepted'
        if category:
            try:
                record_security_event(db_path, category=category, method=request.method, route=route,
                                      status_code=code, client_identity=request.remote_addr or 'unknown')
            except Exception:
                app.logger.exception('security_event_persistence_failed')
        return response

    @app.get('/health')
    def health():
        return jsonify({'status':'ok','service':'ts-ai-witness','schema_version':SCHEMA})
    @app.get('/v1/ops/metrics')
    def ops_metrics():
        auth = request.headers.get('Authorization','')
        supplied = auth[7:] if auth.startswith('Bearer ') and len(auth) <= 4103 else ''
        if not token or len(token) > 4096 or not secrets.compare_digest(supplied, token): return jsonify({'error':'unauthorized'}), 401
        from backend.witness_ops import _records
        with sqlite3.connect(db_path) as conn:
            count=conn.execute('SELECT COUNT(*) FROM anchors').fetchone()[0]
            head=conn.execute('SELECT anchor_digest FROM anchors ORDER BY sequence DESC LIMIT 1').fetchone()
        return jsonify({'service':'ts-ai-witness','sequence':count,'head_digest':head[0] if head else None})

    @app.get('/metrics')
    def prometheus_witness_metrics():
        auth = request.headers.get('Authorization','')
        supplied = auth[7:] if auth.startswith('Bearer ') and len(auth) <= 4103 else ''
        if not token or len(token) > 4096 or not secrets.compare_digest(supplied, token): return 'unauthorized\n', 401, {'Content-Type':'text/plain; charset=utf-8'}
        with sqlite3.connect(db_path) as conn:
            count=conn.execute('SELECT COUNT(*) FROM anchors').fetchone()[0]
        body='\n'.join(['# HELP witness_anchor_records_total Total signed anchor records.','# TYPE witness_anchor_records_total gauge',f'witness_anchor_records_total {count}'])+'\n'
        return body, 200, {'Content-Type':'text/plain; version=0.0.4; charset=utf-8'}

    @app.get('/v1/ops/security')
    def ops_security():
        auth = request.headers.get('Authorization','')
        supplied = auth[7:] if auth.startswith('Bearer ') and len(auth) <= 4103 else ''
        if not token or len(token) > 4096 or not secrets.compare_digest(supplied, token): return jsonify({'error':'unauthorized'}), 401
        report = security_status(db_path, limit=request.args.get('limit', 100, type=int))
        report['chain_integrity'] = verify_security_chain(db_path)
        return jsonify(report)

    @app.get('/v1/ops/key-status')
    def ops_key_status():
        auth = request.headers.get('Authorization','')
        supplied = auth[7:] if auth.startswith('Bearer ') and len(auth) <= 4103 else ''
        if not token or len(token) > 4096 or not secrets.compare_digest(supplied, token): return jsonify({'error':'unauthorized'}), 401
        try:
            from cryptography.hazmat.primitives import serialization
            private = serialization.load_pem_private_key(Path(key_path).read_bytes(), password=None)
            derived = private.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
            signing_fp = hashlib.sha256(derived).hexdigest()
            trusted_fp = key_fingerprint(trusted_source_public_key_path) if trusted_source_public_key_path and Path(trusted_source_public_key_path).is_file() else None
            return jsonify({'signing_key_fingerprint_sha256': signing_fp,
                            'trusted_source_key_fingerprint_sha256': trusted_fp,
                            'trusted_source_key_configured': bool(trusted_fp),
                            'rotation_mode': 'offline_staged_restart_required'})
        except Exception:
            return jsonify({'error':'key_status_unavailable'}), 503

    @app.get('/v1/replication/status')
    def replication_status():
        if not token: return jsonify({'error':'server_api_token_not_configured'}), 503
        auth = request.headers.get('Authorization','')
        supplied = auth[7:] if auth.startswith('Bearer ') and len(auth) <= 4103 else ''
        if len(token) > 4096 or not secrets.compare_digest(supplied, token): return jsonify({'error':'unauthorized'}), 401
        with sqlite3.connect(db_path) as db:
            count = db.execute('SELECT COUNT(*) FROM anchors').fetchone()[0]
            head = db.execute('SELECT anchor_digest FROM anchors ORDER BY sequence DESC LIMIT 1').fetchone()
        return jsonify({'witness_id':wid,'sequence':count,'head_digest':head[0] if head else None})

    @app.post('/v1/replication/push')
    def replication_push():
        if not token: return jsonify({'error':'server_api_token_not_configured'}), 503
        auth = request.headers.get('Authorization','')
        supplied = auth[7:] if auth.startswith('Bearer ') and len(auth) <= 4103 else ''
        if len(token) > 4096 or not secrets.compare_digest(supplied, token): return jsonify({'error':'unauthorized'}), 401
        if not trusted_source_public_key_path or not Path(trusted_source_public_key_path).is_file():
            return jsonify({'error':'trusted_source_key_not_configured'}), 503
        data = request.get_json(silent=True)
        entries = data.get('entries') if isinstance(data, dict) else None
        after_sequence = data.get('after_sequence', 0) if isinstance(data, dict) else 0
        if not isinstance(entries, list) or not 1 <= len(entries) <= 500 or isinstance(after_sequence, bool) or not isinstance(after_sequence, int) or after_sequence < 0:
            return jsonify({'error':'invalid_replication_batch_or_cursor'}), 400
        try:
            from backend.witness_replication import accept_remote_entries
            result = accept_remote_entries(db_path, key_path, trusted_source_public_key_path, entries, witness_id=wid, after_sequence=after_sequence)
            return jsonify(result), 200
        except (ValueError, KeyError, TypeError) as exc:
            return jsonify({'error':'replication_rejected','detail':str(exc)}), 400
        except Exception as exc:
            return jsonify({'error':'replication_failed','detail':str(exc)}), 500

    @app.post('/v1/anchors')
    def anchors():
        if not token: return jsonify({'error':'server_api_token_not_configured'}), 503
        auth = request.headers.get('Authorization','')
        supplied = auth[7:] if auth.startswith('Bearer ') and len(auth) <= 4103 else ''
        if len(token) > 4096 or not secrets.compare_digest(supplied, token): return jsonify({'error':'unauthorized'}), 401
        data = request.get_json(silent=True)
        if not isinstance(data, dict) or data.get('schema_version') != SCHEMA or not isinstance(data.get('anchor'), dict) or not data['anchor']:
            return jsonify({'error':'invalid_request'}), 400
        actual = digest_anchor(data['anchor'])
        if data.get('anchor_digest') != actual: return jsonify({'error':'anchor_digest_mismatch'}), 400
        try: return jsonify(record_anchor(db_path, key_path, data['anchor'], witness_id=wid)), 200
        except Exception as exc: return jsonify({'error':'witness_record_failed','detail':str(exc)}), 500
    return app
