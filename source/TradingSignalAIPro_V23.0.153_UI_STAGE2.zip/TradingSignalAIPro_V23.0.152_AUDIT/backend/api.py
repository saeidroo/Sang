"""
Flask API backend - exposes endpoints for data fetching, analysis,
training (learning), and model management.
"""
import os
import re
import sys
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
from flask import Flask, jsonify, request, send_from_directory, send_file, Response

# Ensure backend module is importable
HERE = Path(__file__).parent
sys.path.insert(0, str(HERE.parent))

from backend.data import (fetch_candles, to_display, COMMODITIES_YAHOO,
                          source_catalog, SOURCE_FUNCS, SOURCE_LABELS)
from backend.features import build_features, FEATURE_SCHEMA_VERSION
from backend.model import TradingEnsemble
from backend.signal import compute_signal, backtest_signals, apply_oos_edge_gate
from backend.strength import normalize_strength, PROFILES as STRENGTH_PROFILES
from backend.trainer import (get_session, HP_GRID, estimate_train_time,
                             temporal_split)
from backend.storage import (list_saved_models, delete_model,
                             models_dir_info, model_path, load_meta,
                             get_models_dir)
from backend.indicators import all_indicators, ema, rsi, atr
from backend.news import build_news_alert
from backend.consensus import pool_votes, blend_probability, advisory_gate
from backend.observability import record_event, read_events, event_summary

app = Flask(__name__, static_folder=None)

# Bounded, credential-redacted application log; no request bodies are logged.
from backend.logging_setup import configure_logging
_LOG_FILE = configure_logging()
app.logger.info('application_logging_ready path=%s', _LOG_FILE)


# --- V19.1 security guard ---------------------------------------------------
# The API has no login. Without this guard any web page open in the user's
# browser could silently POST to http://127.0.0.1:8765 (CSRF) because every
# route accepts bodies with force=True, and a DNS-rebinding page could reach it
# through a foreign Host header. State-changing requests must therefore be
# same-origin, and a loopback-bound server only answers to loopback host names.
_LOOPBACK_HOSTS = {'127.0.0.1', 'localhost', '::1', '[::1]'}
app.config.setdefault('LOOPBACK_ONLY', True)


def _host_only(value: str) -> str:
    value = (value or '').strip().lower()
    if value.startswith('['):                       # [::1]:8765
        return value.split(']')[0] + ']'
    return value.split(':')[0]


@app.before_request
def _local_security_guard():
    if app.config.get('LOOPBACK_ONLY') and _host_only(request.host) not in _LOOPBACK_HOSTS:
        return jsonify({'error': 'Host header نامعتبر است (فقط دسترسی محلی مجاز است).'}), 403
    if request.method in ('POST', 'PUT', 'PATCH', 'DELETE'):
        if request.headers.get('Sec-Fetch-Site', '').lower() == 'cross-site':
            return jsonify({'error': 'درخواست بین‌سایتی رد شد.'}), 403
        origin = request.headers.get('Origin')
        if origin and origin != 'null':
            from urllib.parse import urlparse
            if urlparse(origin).netloc.lower() != (request.host or '').lower():
                return jsonify({'error': 'Origin نامعتبر؛ درخواست رد شد.'}), 403
        elif origin == 'null':
            return jsonify({'error': 'Origin نامعتبر؛ درخواست رد شد.'}), 403
    return None
app.config['JSON_SORT_KEYS'] = False


def _paper_ledger_lease_guard():
    """Fail closed when an AutoPilot process owns the shared PAPER ledger.

    This is an API-boundary guard for manual endpoints. AutoPilot's own worker
    functions do not pass through Flask and remain governed by their process
    lease and lifecycle locks.
    """
    try:
        from backend import paper_live, paper_process_lease
        lease = paper_process_lease.lease_status(paper_live._db_path())
    except Exception as exc:
        app.logger.exception('paper ledger lease guard failed')
        return jsonify({
            'ok': False, 'blocked': True,
            'reason': 'paper_ledger_lease_status_unavailable',
            'error': str(exc)[:180], 'paper_only': True,
            'real_orders_enabled': False,
        }), 503
    if lease.get('held'):
        return jsonify({
            'ok': False, 'blocked': True,
            'reason': 'paper_ledger_owned_by_autopilot',
            'lease_expires_at': lease.get('expires_at'),
            'paper_only': True, 'real_orders_enabled': False,
        }), 409
    return None


from backend.brain import BRAIN_VERSION  # V21: single source of truth for the label
APP_VERSION = '23.0.152'
TIMEFRAMES_ALLOWED_FOR_ADEQUACY = ('5m', '15m', '30m', '1h', '4h', '1d')

_ALLOWED_TIMEFRAMES = {'5m', '15m', '30m', '1h', '4h', '1d'}
_SYMBOL_RE = re.compile(r'^[A-Z0-9]{3,20}$')
_ALLOWED_SOURCES = {'auto', 'history', *SOURCE_FUNCS.keys(), 'yahoo'}


def _validated_market(symbol, timeframe, source='auto'):
    symbol = str(symbol or '').upper().strip()
    timeframe = str(timeframe or '').strip()
    source = str(source or 'auto').strip()
    if not _SYMBOL_RE.fullmatch(symbol):
        raise ValueError('نماد بازار نامعتبر است')
    if timeframe not in _ALLOWED_TIMEFRAMES:
        raise ValueError('تایم‌فریم نامعتبر است')
    if source not in _ALLOWED_SOURCES:
        raise ValueError('منبع داده نامعتبر است')
    return symbol, timeframe, source


def _collect_brain_context(symbol, timeframe, source, primary_df):
    """Fetch independent context feeds without making their failure fatal."""
    from backend.advanced import (market_regime, detect_patterns,
                                  early_trend_change, multi_horizon_outlook,
                                  derivatives_snapshot)
    from backend.brain import TF_MS

    context = {
        'regime': {}, 'patterns': [], 'early_trend': {}, 'outlook': {},
        'multi_timeframe': [],
        'derivatives': {'available': False, 'reason': 'not requested'},
        'feed_errors': [],
    }
    try:
        context['regime'] = market_regime(primary_df, timeframe)
        context['patterns'] = detect_patterns(primary_df)
        context['early_trend'] = early_trend_change(primary_df)
        context['outlook'] = multi_horizon_outlook(primary_df)
    except Exception as exc:
        context['feed_errors'].append('primary_context: ' + str(exc)[:160])

    frame_map = {
        '5m': ['15m', '1h', '4h'],
        '15m': ['1h', '4h', '1d'],
        '30m': ['15m', '1h', '4h'],
        '1h': ['15m', '4h', '1d'],
        '4h': ['1h', '1d'],
        '1d': ['4h', '1h'],
    }
    wanted = [tf for tf in frame_map.get(timeframe, []) if tf in TF_MS]

    def fetch_frame(tf):
        mode = 'research' if source == 'history' else 'paper'
        try:
            freshness = int(os.getenv('TS_AI_SIGNAL_MAX_AGE_BARS', '2'))
        except (TypeError, ValueError):
            freshness = 0
        if mode == 'paper' and freshness < 1:
            raise RuntimeError('invalid signal freshness policy')
        frame = fetch_candles(symbol, tf, limit=420, source=source,
                              validation_mode=mode,
                              max_age_bars=(None if mode == 'research' else freshness))
        report = frame.attrs.get('data_contract') or {}
        if report.get('status') != 'PASS':
            raise RuntimeError('secondary timeframe Data Contract did not PASS')
        close = pd.to_numeric(frame.get('close'), errors='coerce').replace([np.inf, -np.inf], np.nan).dropna()
        if len(close) < 60:
            raise ValueError(f'کمتر از ۶۰ کندل معتبر در {tf}')
        fast = float(close.ewm(span=20, adjust=False).mean().iloc[-1])
        slow = float(close.ewm(span=50, adjust=False).mean().iloc[-1])
        price = float(close.iloc[-1])
        momentum = float(close.iloc[-1] / close.iloc[-6] - 1.0) if close.iloc[-6] > 0 else 0.0
        trend = 1.0 if price > fast > slow else -1.0 if price < fast < slow else 0.0
        gap = (fast / slow - 1.0) if slow > 0 else 0.0
        score = float(np.clip(0.55 * trend + 0.25 * np.tanh(gap * 80.0) + 0.20 * np.tanh(momentum * 18.0), -1, 1))
        return {'timeframe': tf, 'score': score,
                'confidence': float(min(1.0, abs(score) * 1.25)),
                'available': True, 'candles': int(len(close)),
                'price': price, 'momentum_5_pct': round(momentum * 100, 4)}

    # A bounded pool prevents a slow auxiliary provider from serializing the analysis.
    if wanted:
        with ThreadPoolExecutor(max_workers=min(3, len(wanted))) as pool:
            futures = {pool.submit(fetch_frame, tf): tf for tf in wanted}
            for future in as_completed(futures):
                tf = futures[future]
                try:
                    context['multi_timeframe'].append(future.result())
                except Exception as exc:
                    context['feed_errors'].append(f'{tf}: ' + str(exc)[:140])
        context['multi_timeframe'].sort(key=lambda x: wanted.index(x['timeframe']))

    # V19.2: always add a 5m / 30m short-term read (best effort, never fabricated).
    context['short_term'] = []
    short_wanted = [tf for tf in ('5m', '30m') if tf in TF_MS]
    with ThreadPoolExecutor(max_workers=len(short_wanted) or 1) as pool:
        futures = {pool.submit(fetch_frame, tf): tf for tf in short_wanted}
        for future in as_completed(futures):
            tf = futures[future]
            try:
                context['short_term'].append(future.result())
            except Exception as exc:
                context['feed_errors'].append(f'{tf}: ' + str(exc)[:140])
    context['short_term'].sort(key=lambda x: short_wanted.index(x['timeframe']))

    # Derivatives are an optional, low-weight evidence stream for supported crypto pairs.
    from backend.data import futures_base_symbol
    deriv_symbol = futures_base_symbol(symbol)      # V21: BTCUSDTPERP -> BTCUSDT
    if re.fullmatch(r'[A-Z0-9]{3,18}USDT', deriv_symbol):
        try:
            context['derivatives'] = derivatives_snapshot(deriv_symbol)
        except Exception as exc:
            context['derivatives'] = {'available': False, 'reason': str(exc)[:160]}
    return context


# ---------------- Static ----------------

@app.route('/')
def index():
    """Serve the frontend index.html"""
    fe = HERE.parent / 'frontend'
    return send_from_directory(fe, 'index.html')


@app.route('/<path:path>')
def static_files(path):
    """Serve static frontend files"""
    fe = HERE.parent / 'frontend'
    full = fe / path
    if full.is_file():
        return send_from_directory(fe, path)
    # Never turn a missing API endpoint into index.html: clients expect JSON.
    if path == 'api' or path.startswith('api/'):
        return jsonify({'error': 'API endpoint not found', 'path': '/' + path,
                        'app_version': APP_VERSION}), 404
    # fallback to index.html for SPA-style routes
    return send_from_directory(fe, 'index.html')


# ---------------- API ----------------

@app.route('/api/advanced/market-state')
def advanced_market_state():
    from backend.advanced import market_regime, detect_patterns, early_trend_change, multi_horizon_outlook
    try:
        symbol, tf, source = _validated_market(request.args.get('symbol','BTCUSDT'), request.args.get('timeframe','1h'), request.args.get('source','auto'))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    try:
        df=fetch_candles(symbol,tf,limit=1200,source=source)
        return jsonify({'symbol':symbol,'timeframe':tf,'regime':market_regime(df, tf),'patterns':detect_patterns(df),'early_trend':early_trend_change(df),'multi_horizon':multi_horizon_outlook(df)})
    except Exception as exc: return jsonify({'error':str(exc)}),502

@app.route('/api/advanced/derivatives/<symbol>')
def advanced_derivatives(symbol):
    from backend.advanced import derivatives_snapshot
    try:
        if not re.fullmatch(r'[A-Za-z0-9]{3,20}USDT', str(symbol).strip()):
            return jsonify({'available':False,'error':'نماد باید یک جفت معتبر با پسوند USDT باشد'}), 400
        return jsonify(derivatives_snapshot(symbol))
    except Exception as exc: return jsonify({'available':False,'error':str(exc)}),502

@app.route('/api/advanced/strategy-lab')
def advanced_strategy_lab():
    from backend.advanced import strategy_lab
    try:
        symbol, tf, source = _validated_market(request.args.get('symbol','BTCUSDT'), request.args.get('timeframe','1h'), request.args.get('source','auto'))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    try:
        limit = int(request.args.get('limit', 3000))
        fee_bps = float(request.args.get('fee_bps', 10))
        slippage_bps = float(request.args.get('slippage_bps', 5))
        if not 300 <= limit <= 10000:
            raise ValueError('تعداد کندل باید بین ۳۰۰ تا ۱۰۰۰۰ باشد')
        if not (np.isfinite(fee_bps) and np.isfinite(slippage_bps)
                and 0 <= fee_bps <= 500 and 0 <= slippage_bps <= 500):
            raise ValueError('کارمزد و لغزش باید اعداد معتبر بین صفر تا ۵۰۰ واحد پایه باشند')
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    try:
        df=fetch_candles(symbol,tf,limit=limit,source=source)
        return jsonify({'symbol':symbol,'timeframe':tf,**strategy_lab(df, fee_bps=fee_bps, slippage_bps=slippage_bps)})
    except Exception as exc: return jsonify({'error':str(exc)}),502

@app.route('/api/risk/position-size',methods=['POST'])
def risk_position_size():
    from backend.advanced import risk_plan
    data=request.get_json(force=True,silent=True) or {}
    try: return jsonify(risk_plan(float(data['equity']),float(data['risk_pct']),float(data['entry']),float(data['stop'])))
    except Exception as exc: return jsonify({'error':str(exc)}),400

@app.route('/api/paper/trades',methods=['GET','POST'])
def paper_trades():
    from backend.advanced import paper_list,paper_open
    if request.method=='GET': return jsonify(paper_list())
    data=request.get_json(force=True,silent=True) or {}
    try: return jsonify(paper_open(data['symbol'],data['side'],data['qty'],data['entry'],data['stop'],data.get('note',''))),201
    except Exception as exc: return jsonify({'error':str(exc)}),400

@app.route('/api/paper/stats')
def paper_trade_stats():
    from backend.advanced import paper_stats
    return jsonify(paper_stats())

@app.route('/api/paper/trades/<int:trade_id>/close',methods=['POST'])
def paper_trade_close(trade_id):
    from backend.advanced import paper_close
    data=request.get_json(force=True,silent=True) or {}
    try: return jsonify(paper_close(trade_id,float(data['exit'])))
    except Exception as exc: return jsonify({'error':str(exc)}),400

@app.route('/api/paper-live/config', methods=['GET'])
def paper_live_config():
    """Fixed safe preset for live-market-data paper trading; read-only."""
    from backend.paper_live import SETTINGS, VERSION, EXCHANGE_NAMES
    return jsonify({'version': VERSION, 'settings': SETTINGS,
                    'exchanges': [{'id': k, 'name': v} for k, v in EXCHANGE_NAMES.items()]})


@app.route('/api/paper-live/connections', methods=['GET'])
def paper_live_connections():
    from backend.paper_live import check_connections
    symbol = str(request.args.get('symbol', 'BTCUSDT')).upper().strip()
    market = str(request.args.get('market', 'spot')).lower().strip()
    try:
        return jsonify(check_connections(symbol, market))
    except Exception as exc:
        return jsonify({'error': str(exc)}), 502


@app.route('/api/paper-live/quote', methods=['GET'])
def paper_live_quote():
    from backend.paper_live import get_quote
    try:
        symbol = str(request.args.get('symbol', 'BTCUSDT')).upper().strip()
        market = str(request.args.get('market', 'spot')).lower().strip()
        exchange = str(request.args.get('exchange', 'auto')).lower().strip()
        return jsonify(get_quote(symbol, market, exchange))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc), 'connected': False}), 502


@app.route('/api/paper-live/state', methods=['GET'])
def paper_live_state():
    blocked = _paper_ledger_lease_guard()
    if blocked is not None:
        return blocked
    from backend.paper_live import get_state
    try:
        return jsonify(get_state(refresh_quotes=request.args.get('refresh', '1') != '0', sync_funding=request.args.get('refresh', '1') != '0'))
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/positions', methods=['POST'])
def paper_live_open_position():
    blocked = _paper_ledger_lease_guard()
    if blocked is not None:
        return blocked
    from backend.paper_live import open_position
    data = request.get_json(force=True, silent=True) or {}
    try:
        result = open_position(data.get('symbol', ''), data.get('side', ''),
                               data.get('market', 'spot'), data.get('exchange', 'auto'),
                               data.get('timeframe', '1h'),
                               decision_context=data.get('decision_context') if isinstance(data.get('decision_context'), dict) else None,
                               idempotency_key=data.get('idempotency_key'))
        return jsonify(result), (200 if result.get('idempotent_replay') else 201)
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc), 'connected': False}), 502


@app.route('/api/paper-live/positions/<int:position_id>/close', methods=['POST'])
def paper_live_close_position(position_id):
    blocked = _paper_ledger_lease_guard()
    if blocked is not None:
        return blocked
    from backend.paper_live import close_position
    try:
        return jsonify(close_position(position_id))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc), 'connected': False}), 502


@app.route('/api/paper-live/positions/<int:position_id>/partial-close', methods=['POST'])
def paper_live_partial_close_position(position_id):
    blocked = _paper_ledger_lease_guard()
    if blocked is not None:
        return blocked
    from backend.paper_live import partial_close_position
    data = request.get_json(force=True, silent=True) or {}
    try:
        result = partial_close_position(position_id, data.get('quantity'),
            idempotency_key=data.get('idempotency_key', ''),
            reason=data.get('reason', 'PARTIAL_MANUAL'))
        return jsonify(result), (200 if result.get('idempotent_replay') else 201)
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc), 'connected': False}), 502


@app.route('/api/paper-live/positions/<int:position_id>/funding-audit', methods=['GET'])
def paper_live_funding_audit(position_id):
    from backend.paper_live import get_funding_audit
    try:
        return jsonify(get_funding_audit(position_id))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 404
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/reconciliation', methods=['GET'])
def paper_live_reconciliation():
    """Read-only PnL and funding reconciliation for simulated trades."""
    from backend.paper_live import reconcile_trade_pnl
    raw_id = request.args.get('trade_id')
    try:
        trade_id = int(raw_id) if raw_id is not None else None
        if trade_id is not None and trade_id <= 0:
            raise ValueError("شناسه معامله نامعتبر است")
        return jsonify(reconcile_trade_pnl(trade_id))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/account-reconciliation', methods=['GET'])
def paper_live_account_reconciliation():
    """Read-only simulated-account equity reconciliation."""
    from backend.paper_live import reconcile_account_equity
    try:
        return jsonify(reconcile_account_equity())
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/equity-history', methods=['GET'])
def paper_live_equity_history():
    """Read-only persisted equity and drawdown history."""
    from backend.paper_live import get_equity_history
    try:
        limit = int(request.args.get('limit', 200))
        if limit < 1 or limit > 1000:
            raise ValueError('limit باید بین ۱ تا ۱۰۰۰ باشد')
        return jsonify(get_equity_history(limit=limit))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/performance-analytics', methods=['GET'])
def paper_live_performance_analytics():
    """Read-only period and strategy performance statistics for paper trades."""
    from backend.paper_live import get_performance_analytics
    try:
        return jsonify(get_performance_analytics(period=request.args.get('period', 'all')))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/strategy-rankings', methods=['GET'])
def paper_live_strategy_rankings():
    """Read-only confidence-aware ranking of observed paper-trade scopes."""
    from backend.paper_live import get_strategy_rankings
    try:
        min_trades = int(request.args.get('min_trades', 5))
        return jsonify(get_strategy_rankings(period=request.args.get('period', 'all'), min_trades=min_trades))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/strategy-adaptations', methods=['GET'])
def paper_live_strategy_adaptations():
    """Read-only historical multipliers used to order paper entry candidates."""
    from backend.paper_live import get_strategy_entry_adjustments
    try:
        min_trades = int(request.args.get('min_trades', 5))
        return jsonify(get_strategy_entry_adjustments(
            period=request.args.get('period', 'all'), min_trades=min_trades))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/market-regime', methods=['GET'])
def paper_live_market_regime():
    """Classify the latest validated OHLCV batch and report tagged paper outcomes."""
    from backend.market_regime import classify_market_regime
    from backend.paper_live import get_regime_performance
    try:
        symbol = str(request.args.get('symbol', 'BTCUSDT')).upper().strip()
        timeframe = str(request.args.get('timeframe', '1h')).lower().strip()
        source = str(request.args.get('source', 'auto')).lower().strip()
        frame = fetch_candles(symbol, timeframe, limit=300, source=source,
                              validation_mode='paper',
                              max_age_bars=int(os.getenv('TS_AI_SIGNAL_MAX_AGE_BARS', '2')))
        report = classify_market_regime(frame.tail(120))
        report.update({'symbol': symbol, 'timeframe': timeframe,
                       'data_source': str(frame.attrs.get('source', source)),
                       'historical_performance': get_regime_performance(
                           period=request.args.get('period', 'all'))})
        return jsonify(report)
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc), 'regime': 'UNAVAILABLE',
                        'real_orders_enabled': False}), 503


@app.route('/api/paper-live/multi-timeframe-regime', methods=['GET'])
def paper_live_multi_timeframe_regime():
    """Read-only 4h/1h/15m regime confirmation for one symbol."""
    from backend.market_regime import classify_market_regime, confirm_multi_timeframe_regimes
    try:
        symbol = str(request.args.get('symbol', 'BTCUSDT')).upper().strip()
        reports = {}
        sources = {}
        for tf in ('4h', '1h', '15m'):
            frame = fetch_candles(symbol, tf, limit=210, source='auto',
                                  validation_mode='paper',
                                  max_age_bars=int(os.getenv('TS_AI_SIGNAL_MAX_AGE_BARS', '2')))
            reports[tf] = classify_market_regime(frame.tail(120))
            sources[tf] = str(frame.attrs.get('source', 'auto'))
        result = confirm_multi_timeframe_regimes(reports)
        result.update({'symbol': symbol, 'data_sources': sources})
        return jsonify(result)
    except ValueError as exc:
        return jsonify({'error': str(exc), 'status': 'INSUFFICIENT_DATA',
                        'real_orders_enabled': False}), 400
    except Exception as exc:
        return jsonify({'error': str(exc), 'status': 'UNAVAILABLE',
                        'real_orders_enabled': False}), 503


@app.route('/api/paper-live/regime-strategy-selection', methods=['GET'])
def paper_live_regime_strategy_selection():
    """Read-only strategy adjustments conditioned on a caller-supplied regime."""
    from backend.paper_live import get_regime_aware_strategy_selection
    try:
        min_trades = int(request.args.get('min_trades', 5))
        return jsonify(get_regime_aware_strategy_selection(
            regime=request.args.get('regime', ''), period=request.args.get('period', 'all'),
            min_trades=min_trades))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/learning', methods=['GET'])
def paper_live_learning():
    """Read-only view of the independent simulated-trade learning memory."""
    from backend.paper_live import get_learning_state
    try:
        return jsonify(get_learning_state())
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/learning/strategy-ranking', methods=['GET'])
def paper_live_strategy_learning_ranking():
    """Read-only ranking of strategy cohorts from closed simulated trades."""
    from backend.paper_live import get_strategy_learning_ranking
    try:
        min_samples = int(request.args.get('min_samples', 10))
        return jsonify(get_strategy_learning_ranking(min_samples=min_samples))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/learning/strategy-recommendation', methods=['GET'])
def paper_live_strategy_recommendation():
    """Read-only exact-context strategy shortlist; never authorizes orders."""
    from backend.paper_live import get_strategy_learning_ranking
    from backend.strategy_learning import recommend_strategy_for_context
    try:
        ranking = get_strategy_learning_ranking(min_samples=max(1, min(500, int(request.args.get('min_samples', 10)))))
        result = recommend_strategy_for_context(
            ranking, symbol=request.args.get('symbol', ''), market=request.args.get('market', 'spot'),
            timeframe=request.args.get('timeframe', '1h'), side=request.args.get('side', 'LONG'),
            market_regime=request.args.get('market_regime', 'UNKNOWN'),
            volatility_regime=request.args.get('volatility_regime', 'UNKNOWN'),
            min_samples=int(request.args.get('min_samples', 10)))
        return jsonify(result)
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500




@app.route('/api/paper-live/learning/overfit-audit', methods=['GET'])
def paper_live_overfit_audit():
    """Chronological holdout audit of exact strategy/context cohorts; read-only."""
    from backend.paper_live import get_strategy_validation_events
    from backend.strategy_validation import audit_strategy_overfitting
    try:
        return jsonify(audit_strategy_overfitting(
            get_strategy_validation_events(),
            min_total=int(request.args.get('min_total', 20)),
            min_holdout=int(request.args.get('min_holdout', 5)),
            train_fraction=float(request.args.get('train_fraction', 0.70))))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/learning/walk-forward', methods=['GET'])
def paper_live_walk_forward_validation():
    """Read-only expanding-window validation on reconciled closed paper trades."""
    from backend.paper_live import get_strategy_validation_events
    from backend.walk_forward_validation import walk_forward_validate
    try:
        return jsonify(walk_forward_validate(
            get_strategy_validation_events(),
            min_total=int(request.args.get('min_total', 30)),
            min_train=int(request.args.get('min_train', 10)),
            min_test=int(request.args.get('min_test', 3)),
            folds=int(request.args.get('folds', 4))))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/learning/strategy-drift', methods=['GET'])
def paper_live_strategy_drift():
    """Read-only chronological strategy drift monitor over closed paper trades."""
    from backend.paper_live import get_strategy_validation_events
    from backend.strategy_drift import detect_strategy_drift
    try:
        return jsonify(detect_strategy_drift(
            get_strategy_validation_events(),
            min_baseline=int(request.args.get('min_baseline', 10)),
            min_recent=int(request.args.get('min_recent', 5)),
            recent_fraction=float(request.args.get('recent_fraction', 0.30)),
            win_rate_drop_pp=float(request.args.get('win_rate_drop_pp', 15)),
            expectancy_drop_pct=float(request.args.get('expectancy_drop_pct', 50))))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/learning/regime-adaptation', methods=['GET'])
def paper_live_regime_adaptation():
    """Read-only exact-context strategy evidence after a caller-supplied regime change."""
    from backend.paper_live import get_strategy_validation_events
    from backend.regime_adaptation import build_regime_adaptation_report
    try:
        return jsonify(build_regime_adaptation_report(
            get_strategy_validation_events(),
            symbol=request.args.get('symbol', 'BTCUSDT'),
            timeframe=request.args.get('timeframe', '1h'),
            current_regime=request.args.get('current_regime', ''),
            previous_regime=request.args.get('previous_regime'),
            market=request.args.get('market', 'perp'),
            side=request.args.get('side', 'LONG'),
            min_trades=int(request.args.get('min_trades', 8))))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc), 'real_orders_enabled': False}), 500


@app.route('/api/paper-live/no-trade-intelligence', methods=['GET'])
def paper_live_no_trade_intelligence():
    """Read-only conservative no-trade diagnostics; never authorizes execution."""
    from backend.no_trade_intelligence import build_no_trade_report
    try:
        def optional_float(key):
            value = request.args.get(key)
            return None if value in (None, '') else float(value)
        return jsonify(build_no_trade_report(
            symbol=request.args.get('symbol', 'BTCUSDT'),
            market=request.args.get('market', 'perp'),
            timeframe=request.args.get('timeframe', '1h'),
            data_age_seconds=optional_float('data_age_seconds'),
            spread_pct=optional_float('spread_pct'), atr_pct=optional_float('atr_pct'),
            volume_ratio=optional_float('volume_ratio'),
            volatility_zscore=optional_float('volatility_zscore'),
            signal_count=int(request.args.get('signal_count', 0)),
            required_signal_count=int(request.args.get('required_signal_count', 2)),
            evidence_conflict=request.args.get('evidence_conflict', 'false').lower() == 'true',
            market_regime=request.args.get('market_regime', 'UNKNOWN'),
            data_valid=request.args.get('data_valid', 'true').lower() == 'true'))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc), 'real_orders_enabled': False}), 400
    except Exception as exc:
        return jsonify({'error': str(exc), 'real_orders_enabled': False}), 500


@app.route('/api/paper-live/opportunity-score', methods=['GET'])
def paper_live_opportunity_score():
    """Read-only multi-factor opportunity quality index; never authorizes execution."""
    from backend.opportunity_scoring import score_trade_opportunity
    try:
        factor_names = ('trend_structure', 'volume_strength', 'support_resistance',
                        'volatility_fit', 'historical_strategy', 'execution_cost',
                        'risk_reward', 'data_reliability')
        factors = {}
        for name in factor_names:
            value = request.args.get(name)
            factors[name] = None if value in (None, '') else float(value)
        blockers = [x for x in request.args.get('blockers', '').split(',') if x.strip()]
        return jsonify(score_trade_opportunity(
            symbol=request.args.get('symbol', 'BTCUSDT'),
            market=request.args.get('market', 'perp'),
            timeframe=request.args.get('timeframe', '1h'), factors=factors,
            blockers=blockers,
            min_coverage=float(request.args.get('min_coverage', 0.60))))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc), 'real_orders_enabled': False}), 400
    except Exception as exc:
        return jsonify({'error': str(exc), 'real_orders_enabled': False}), 500


@app.route('/api/paper-live/opportunity-ranking', methods=['POST'])
def paper_live_opportunity_ranking():
    """Rank caller-supplied opportunity scores; POST is read-only and never executes trades."""
    from backend.opportunity_ranking import rank_opportunities
    try:
        payload = request.get_json(silent=True) or {}
        return jsonify(rank_opportunities(
            payload.get('candidates', []),
            limit=int(payload.get('limit', 10)),
            max_per_group=int(payload.get('max_per_group', 1)),
            min_score=float(payload.get('min_score', 45))))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc), 'read_only': True,
                        'paper_only': True, 'real_orders_enabled': False}), 400
    except Exception as exc:
        return jsonify({'error': str(exc), 'real_orders_enabled': False}), 500


@app.route('/api/paper-live/capital-allocation', methods=['POST'])
def paper_live_capital_allocation():
    """Read-only paper capital planner; never submits or authorizes orders."""
    from backend.capital_allocator import plan_paper_allocations
    try:
        payload = request.get_json(silent=True) or {}
        result = plan_paper_allocations(
            payload.get('candidates', []),
            equity=payload.get('equity', 1000.0),
            available_balance=payload.get('available_balance'),
            open_risk=payload.get('open_risk', 0.0),
            open_positions=payload.get('open_positions', 0),
            group_exposure=payload.get('group_exposure', {}),
            settings=payload.get('settings', {}))
        return jsonify(result)
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc), 'paper_only': True,
                        'real_orders_enabled': False, 'execution_authorized': False}), 400
    except Exception as exc:
        app.logger.exception('paper capital allocation failed')
        return jsonify({'error': str(exc), 'real_orders_enabled': False,
                        'execution_authorized': False}), 500


@app.route('/api/paper-live/learning/gate', methods=['GET'])
def paper_live_learning_gate():
    from backend.paper_live import get_learning_gate
    try:
        return jsonify(get_learning_gate(
            request.args.get('symbol', ''), request.args.get('market', 'spot'),
            request.args.get('timeframe', '1h'), request.args.get('side', 'LONG')))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/learning/rebuild', methods=['POST'])
def paper_live_learning_rebuild():
    """Recompute learning profiles from closed simulated trades only."""
    blocked = _paper_ledger_lease_guard()
    if blocked is not None:
        return blocked
    from backend.paper_live import rebuild_learning
    try:
        return jsonify(rebuild_learning())
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/paper-live/learning/export.csv', methods=['GET'])
def paper_live_learning_export():
    """Download append-only outcome examples for future audited training."""
    import csv
    import io
    from backend.paper_live import get_learning_export_rows
    try:
        rows = get_learning_export_rows()
        output = io.StringIO(newline='')
        fields = ['trade_id','closed_at','symbol','market','timeframe','exchange','side','exit_reason',
                  'outcome','net_pnl','return_pct','duration_seconds','notional','gross_pnl',
                  'total_fees','entry_fill','exit_fill','context_json']
        writer = csv.DictWriter(output, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
        return Response(output.getvalue(), mimetype='text/csv; charset=utf-8',
                        headers={'Content-Disposition': 'attachment; filename=paper_learning_dataset.csv',
                                 'Cache-Control': 'no-store'})
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


# --- V23.0.4 AutoPilot: quote integrity and accounting -----------------
# The engine lives in backend/autopilot.py; it opens/closes paper positions by
# itself and produces Persian periodic reports. Paper-only: no real orders.

@app.route('/api/autopilot/state', methods=['GET'])
def autopilot_state():
    from backend.autopilot import status
    try:
        return jsonify(status())
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/autopilot/config', methods=['POST'])
def autopilot_config():
    from backend.autopilot import update_config
    data = request.get_json(force=True, silent=True) or {}
    try:
        return jsonify(update_config(data))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/autopilot/start', methods=['POST'])
def autopilot_start():
    from backend.autopilot import start
    try:
        return jsonify(start())
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/autopilot/stop', methods=['POST'])
def autopilot_stop():
    from backend.autopilot import stop
    data = request.get_json(force=True, silent=True) or {}
    try:
        return jsonify(stop(close_all=bool(data.get('close_all'))))
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/autopilot/tick', methods=['POST'])
def autopilot_tick():
    """Run one full engine cycle synchronously (debugging / first-run demo)."""
    from backend.autopilot import run_manual_cycle
    try:
        return jsonify(run_manual_cycle())
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/autopilot/symbols', methods=['GET'])
def autopilot_symbols():
    from backend.autopilot import refresh_watchlist
    try:
        force = request.args.get('force', '0') == '1'
        return jsonify(refresh_watchlist(force=force))
    except Exception as exc:
        return jsonify({'error': str(exc)}), 502


@app.route('/api/autopilot/report', methods=['GET'])
def autopilot_report():
    from backend.autopilot import build_report
    try:
        kind = request.args.get('kind', 'session')
        day = request.args.get('day') or None
        return jsonify(build_report(kind, day))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/autopilot/report.csv', methods=['GET'])
def autopilot_report_csv():
    from backend.autopilot import autopilot_trades_csv
    try:
        return Response(autopilot_trades_csv(), mimetype='text/csv; charset=utf-8',
                        headers={'Content-Disposition': 'attachment; filename=autopilot_trades.csv',
                                 'Cache-Control': 'no-store'})
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/api/news/impact')
def news_impact():
    symbol = str(request.args.get('symbol', 'BTCUSDT')).upper().strip()
    if not _SYMBOL_RE.fullmatch(symbol):
        return jsonify({'error': 'نماد نامعتبر است'}), 400
    try:
        return jsonify(build_news_alert(symbol))
    except Exception as exc:
        return jsonify({'block_trading': False, 'alert_text': None, 'breaking': [],
                        'macro_events': [], 'sentiment': {'label':'neutral','score':0},
                        'fear_greed': {'value':50,'classification':'Neutral'},
                        'warning': str(exc)})


@app.route('/api/brain/reliability')
def brain_reliability():
    from backend.brain import reliability_status
    symbol = request.args.get('symbol')
    timeframe = request.args.get('timeframe')
    if symbol or timeframe:
        try:
            symbol, timeframe, _ = _validated_market(symbol, timeframe, 'auto')
        except ValueError as exc:
            return jsonify({'error': str(exc)}), 400
        return jsonify(reliability_status(symbol, timeframe))
    return jsonify(reliability_status())


@app.route('/api/version')
def version_info():
    return jsonify({'app': 'Trading Signal AI Pro', 'version': APP_VERSION,
                    'finrl_routes': ['/api/rl/train', '/api/rl/status', '/api/rl/stop']})


@app.route('/api/health')
def health():
    return jsonify({
        'status': 'ok',
        'version': APP_VERSION,
        'decision_brain': BRAIN_VERSION,
        'time': time.strftime('%Y-%m-%d %H:%M:%S'),
        'python': sys.version.split()[0],
        'models_dir': str(get_models_dir()),
    })


@app.route('/api/observability/health')
def observability_health():
    info = models_dir_info()
    try:
        free_bytes = __import__('shutil').disk_usage(str(get_models_dir())).free
        storage = {'available': True, 'free_bytes': int(free_bytes)}
    except Exception as exc:
        storage = {'available': False, 'error': str(exc)}
    sess = get_session()
    summary = event_summary()
    return jsonify({'status': 'ok', 'version': APP_VERSION,
                    'training': {'running': bool(sess.is_running)},
                    'storage': storage, 'models': {'count': info.get('models_count', 0),
                    'total_size_mb': info.get('total_size_mb', 0)},
                    'events': summary})


@app.route('/api/observability/events')
def observability_events():
    try: limit = int(request.args.get('limit', 100))
    except (TypeError, ValueError): return jsonify({'error': 'limit نامعتبر است'}), 400
    if limit < 1 or limit > 1000: return jsonify({'error': 'limit باید بین 1 تا 1000 باشد'}), 400
    return jsonify({'events': read_events(limit), 'count': len(read_events(limit))})


@app.route('/api/performance/center')
def performance_center():
    from backend.experiment_registry import read_events as read_experiments, negative_results, audit_integrity as registry_integrity
    from backend.reproducible_run import verify_run_manifest
    from backend.evaluation import paper_v22_events, paper_v22_audit_integrity
    rows = read_experiments()
    starts = {e.get('experiment_id'): e for e in rows if e.get('event_type') == 'experiment_started'}
    finished = [e for e in rows if e.get('event_type') == 'experiment_finished']
    recent=[]
    for e in finished[-100:]:
        start=starts.get(e.get('experiment_id'), {})
        recent.append({'experiment_id':e.get('experiment_id'),'hypothesis_id':start.get('hypothesis_id'),
                       'symbol':(start.get('scope') or {}).get('symbol'), 'timeframe':(start.get('scope') or {}).get('timeframe'),
                       'status':e.get('status'),'metrics':e.get('metrics') or {},
                       'recorded_at':e.get('recorded_at')})
    manifest_dir=Path(get_models_dir())/'reproducible_runs'
    manifests=sorted(manifest_dir.glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True) if manifest_dir.exists() else []
    latest_manifest=None
    if manifests:
        try:
            import json
            latest=json.loads(manifests[0].read_text(encoding='utf-8'))
            latest_manifest={'run_id':latest.get('run_id'),'created_at':latest.get('created_at'),
                'integrity':verify_run_manifest(manifests[0]),'trial_count':latest.get('trial_count'),
                'experiment_registry':latest.get('experiment_registry'), 'paper_ledger':latest.get('paper_ledger')}
        except Exception as exc: latest_manifest={'integrity':{'valid':False,'errors':[str(exc)]}}
    return jsonify({'status':'ok','total_experiments_started':len(starts),
                    'total_experiments_finished':len(finished),
                    'negative_results_count':len(negative_results()),
                    'latest_reproducible_run':latest_manifest,
                    'audit_integrity':{'experiment_registry':registry_integrity(),'paper_ledger':paper_v22_audit_integrity()},
                    'recent_experiments':recent[::-1], 'note':'نتایج توصیفی‌اند؛ رتبه‌بندی آماری یا تضمین سود ارائه نمی‌شود.'})




@app.route('/api/evaluation/baseline', methods=['POST'])
def evaluation_baseline():
    from backend.evaluation import baseline_returns, cost_model, net_returns, performance_metrics
    data=request.get_json(silent=True) or {}
    try:
        gross=baseline_returns(data.get('close', []), kind=data.get('kind','buy_hold'))
        costs=cost_model(**(data.get('costs') or {}))
        net=net_returns(gross,costs=costs)
        return jsonify({'status':'ok','baseline':data.get('kind','buy_hold'),'cost_model':costs,
                        'gross':performance_metrics(gross),'net':performance_metrics(net)})
    except (ValueError,TypeError) as exc:
        return jsonify({'error':str(exc)}),400

@app.route('/api/evaluation/robust', methods=['POST'])
def evaluation_robust():
    from backend.evaluation import compare_strategies
    data=request.get_json(silent=True) or {}
    try:
        returns=data.get('net_returns') or {}
        if data.get('returns_are_net') is not True:
            return jsonify({'error':'returns_are_net=true is required; supply net returns after one identical CostModel'}),400
        result=compare_strategies(returns,periods_per_year=int(data.get('periods_per_year',365)),
            bootstrap_samples=int(data.get('bootstrap_samples',2000)),mean_block_length=data.get('mean_block_length'),
            min_trades=int(data.get('min_trades',30)),trials=int(data.get('trials',1)),seed=int(data.get('seed',17)))
        result['cost_model_hash']=data.get('cost_model_hash')
        result['test_block_id']=data.get('test_block_id')
        return jsonify({'status':'ok','result':result})
    except (ValueError,TypeError) as exc:
        return jsonify({'error':str(exc)}),400


@app.route('/api/reproducibility/manifest', methods=['POST'])
def reproducibility_manifest():
    """Persist a hash-bound run manifest for a caller-supplied evaluation."""
    from backend.reproducible_run import create_run_manifest, save_run_manifest, link_run_provenance
    from backend.experiment_registry import read_events as read_experiment_events
    from backend.evaluation import paper_v22_events
    data=request.get_json(silent=True) or {}
    try:
        # run_id is shared with Paper Ledger; trial_count from request is deliberately ignored.
        manifest=create_run_manifest(data_hash=data.get('data_hash'), config=data.get('config') or {},
            cost_model=data.get('cost_model') or {}, test_block_id=data.get('test_block_id'),
            code_id=data.get('code_id'), seed=data.get('seed'), trial_count=None,
            model_artifacts=data.get('model_artifacts') or {}, run_id=data.get('run_id'))
        manifest=link_run_provenance(manifest, registry_events=read_experiment_events(),
            paper_events=paper_v22_events(run_id=manifest['run_id'],limit=2000),
            experiment_id=data.get('experiment_id'))
        target=Path(get_models_dir())/'reproducible_runs'
        saved=save_run_manifest(manifest,target)
        return jsonify({'status':'ok','manifest':manifest,'manifest_path':str(saved)}),201
    except (ValueError,TypeError,OSError) as exc:
        return jsonify({'error':str(exc)}),400


@app.route('/api/paper/v22/events', methods=['GET','POST'])
def paper_v22_events_route():
    from backend.evaluation import paper_v22_record, paper_v22_events
    if request.method=='POST':
        data=request.get_json(silent=True) or {}
        try: return jsonify(paper_v22_record(data.get('run_id'),data.get('event'),data.get('payload') or {},data.get('idempotency_key'))),201
        except (ValueError,TypeError) as exc: return jsonify({'error':str(exc)}),400
    return jsonify({'events':paper_v22_events(request.args.get('run_id'),request.args.get('limit',500))})


@app.route('/api/audit/integrity', methods=['GET'])
def audit_integrity_route():
    from backend.experiment_registry import audit_integrity as registry_integrity
    from backend.evaluation import paper_v22_audit_integrity
    return jsonify({'status':'ok','experiment_registry':registry_integrity(),'paper_ledger':paper_v22_audit_integrity()})


@app.route('/api/audit/report', methods=['GET'])
def audit_report_route():
    """Cross-check manifests against durable Registry and Paper Ledger records."""
    import json
    from backend.audit_report import build_audit_report
    from backend.experiment_registry import read_events as read_experiment_events, audit_integrity as registry_integrity
    from backend.evaluation import paper_v22_events, paper_v22_audit_integrity
    report = build_audit_report(registry_events=read_experiment_events(),
        paper_events=paper_v22_events(limit=2000),
        manifest_dir=Path(get_models_dir())/'reproducible_runs',
        registry_integrity=registry_integrity(), paper_integrity=paper_v22_audit_integrity())
    if request.args.get('download') == '1':
        payload=json.dumps(report,ensure_ascii=False,indent=2).encode('utf-8')
        return Response(payload,mimetype='application/json',headers={
            'Content-Disposition':'attachment; filename="trading_ai_audit_report.json"'})
    return jsonify(report)


@app.route('/api/status')
def status():
    """Get training status and models dir info."""
    sess = get_session()
    info = models_dir_info()
    return jsonify({
        'training_running': sess.is_running,
        'training_log': sess.progress_log[-50:] if sess.progress_log else [],
        'last_result': sess.last_result,
        'models_dir': info['path'],
        'models_count': info['models_count'],
        'total_size_mb': info['total_size_mb'],
        'models': info['models'],
        'hp_trials': len(HP_GRID),
        'history': __import__('backend.historical', fromlist=['backfill_status']).backfill_status(),
    })




@app.route('/api/brain/historical-extremes', methods=['GET'])
def brain_historical_extremes():
    """Read-only mining report for real archived pump and dump episodes."""
    from backend.historical_event_miner import scan_archive
    symbol = request.args.get('symbol') or None
    timeframe = request.args.get('timeframe', '1h')
    try:
        threshold = float(request.args.get('threshold_pct', 10.0))
        horizon = int(request.args.get('horizon_bars', 24))
        lookback = int(request.args.get('lookback', 24))
        limit = min(250000, max(100, int(request.args.get('max_candles', 250000))))
        result = scan_archive(symbol=symbol, timeframe=timeframe,
                              threshold_pct=threshold, horizon_bars=horizon,
                              lookback=lookback, max_candles=limit)
        return jsonify(result)
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        app.logger.exception('historical_extreme_scan_failed')
        return jsonify({'error': 'اسکن تاریخچه ناموفق بود', 'detail': str(exc)[:180]}), 500


@app.route('/api/history/status')
def history_status():
    from backend.historical import backfill_status
    return jsonify(backfill_status())


@app.route('/api/history/backfill', methods=['POST'])
def history_backfill():
    from backend.historical import start_backfill
    data=request.get_json(force=True,silent=True) or {}
    symbols=data.get('symbols',['ALL_USDT','GOLD','SILVER'])
    timeframes=data.get('timeframes',['1h','4h','1d'])
    start=str(data.get('start','2017-01-01T00:00:00+00:00'))
    if not isinstance(symbols,list) or not symbols or len(symbols)>100:
        return jsonify({'error':'symbols باید فهرستی با ۱ تا ۱۰۰ نماد باشد'}),400
    if not isinstance(timeframes,list) or not timeframes or any(x not in _ALLOWED_TIMEFRAMES for x in timeframes):
        return jsonify({'error':'timeframes نامعتبر است'}),400
    symbols=[str(x).upper().strip() for x in symbols]
    if not start_backfill(symbols,timeframes,start):
        return jsonify({'error':'دریافت تاریخچه دیگری در حال اجراست'}),409
    return jsonify({'started':True,'symbols':symbols,'timeframes':timeframes,'start':start})


@app.route('/api/history/stop', methods=['POST'])
def history_stop():
    from backend.historical import stop_backfill
    stop_backfill(); return jsonify({'stopping':True})


@app.route('/api/history/export', methods=['GET'])
def history_export():
    """Download a ZIP snapshot of every candle saved in the local archive."""
    import os
    from backend.historical import export_archive_bundle
    path = None
    try:
        path, manifest = export_archive_bundle()
        if not path:
            return jsonify({'error': manifest.get('error') or 'آرشیو خالی است؛ ابتدا دریافت تاریخچه را اجرا کن.',
                            'total_candles': 0}), 409
        response = send_file(path, mimetype='application/zip', as_attachment=True,
                             download_name='TradingSignalAIPro_History_Archive.zip',
                             conditional=True, max_age=0)
        response.headers['Cache-Control'] = 'no-store'
        response.headers['X-Archive-Candles'] = str(manifest['total_candles'])
        response.headers['X-Archive-Markets'] = str(manifest['market_timeframe_count'])
        response.call_on_close(lambda: os.path.exists(path) and os.unlink(path))
        return response
    except Exception as exc:
        if path and os.path.exists(path):
            try: os.unlink(path)
            except OSError: pass
        traceback.print_exc()
        return jsonify({'error': f'ساخت فایل آرشیو ناموفق بود: {str(exc)[:180]}'}), 500


@app.route('/api/market/overview')
def market_overview():
    """Read-only BTC/ETH/gold/oil snapshot from independent market data providers."""
    from backend.market_overview import get_market_overview
    try:
        return jsonify(get_market_overview(force=request.args.get('refresh') == '1'))
    except Exception as exc:
        return jsonify({'error': str(exc)[:200], 'items': []}), 502


@app.route('/api/symbols')
def symbols():
    """List supported symbols."""
    crypto = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT',
              'DOGEUSDT', 'ADAUSDT', 'LINKUSDT', 'AVAXUSDT', 'TONUSDT',
              'ICPUSDT', 'TRXUSDT', 'MATICUSDT', 'DOTUSDT', 'LTCUSDT',
              'NEARUSDT', 'APTUSDT', 'ARBUSDT', 'OPUSDT', 'INJUSDT']
    commodities = ['GOLD', 'SILVER', 'XAUUSD', 'XAGUSD', 'WTI', 'BRENT']
    from backend.data import FUTURES_FAMOUS, futures_label
    return jsonify({
        'crypto': crypto,
        'futures': list(FUTURES_FAMOUS),
        'futures_labels': {x: futures_label(x) for x in FUTURES_FAMOUS},
        'commodities': commodities,
        'commodity_labels': {
            'GOLD': 'طلا (قرارداد آتی GC=F؛ نماینده بازار طلا)',
            'SILVER': 'نقره (قرارداد آتی SI=F؛ نماینده بازار نقره)',
            'XAUUSD': 'طلا (XAU/USD)',
            'XAGUSD': 'نقره (XAG/USD)',
            'WTI': 'نفت WTI',
            'BRENT': 'نفت برنت',
        },
    })


@app.route('/api/trending')
def trending_coins():
    from backend import trending
    try:
        limit = int(request.args.get('limit', 12))
    except ValueError:
        return jsonify({'error': 'limit نامعتبر است'}), 400
    try:
        return jsonify(trending.get_trending(limit, force=request.args.get('refresh') == '1'))
    except Exception as exc:
        return jsonify({'error': str(exc)}), 502


@app.route('/api/scout')
def scout_state():
    from backend import scout
    return jsonify(scout.get_state())


@app.route('/api/scout/refresh', methods=['POST'])
def scout_refresh():
    from backend import scout
    return jsonify({'started': scout.trigger_refresh(), 'state': scout.get_state()})


@app.route('/api/scout/learning')
def scout_learning_summary():
    from backend import storm_learning
    return jsonify(storm_learning.summary())


@app.route('/api/scout/learning/performance')
def scout_learning_performance():
    from backend import storm_learning
    return jsonify(storm_learning.directional_performance_report())


@app.route('/api/scout/learning/failure-patterns')
def scout_learning_failure_patterns():
    from backend import storm_learning
    return jsonify(storm_learning.failure_pattern_audit(
        min_samples=request.args.get('min_samples', 5),
        limit=request.args.get('limit', 20)))


@app.route('/api/scout/learning/sequences')
def scout_learning_sequences():
    from backend import sequence_pattern_learning
    try:
        return jsonify(sequence_pattern_learning.analyze_sequences(
            horizon=request.args.get('horizon', '24h'),
            lookback_hours=int(request.args.get('lookback_hours', 24)),
            sequence_length=int(request.args.get('sequence_length', 3)),
            min_samples=int(request.args.get('min_samples', 5)),
            limit=int(request.args.get('limit', 30))))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400


@app.route('/api/scout/learning/event-timing')
def scout_learning_event_timing():
    from backend import event_timing_audit
    try:
        return jsonify(event_timing_audit.audit_event_timing(
            horizon=request.args.get('horizon', '24h'),
            threshold_pct=float(request.args.get('threshold_pct', 1.0)),
            min_samples=int(request.args.get('min_samples', 5)),
            limit=int(request.args.get('limit', 100))))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400


@app.route('/api/scout/followups')
def scout_followups():
    from backend import storm_learning
    return jsonify(storm_learning.followups(limit=request.args.get('limit', 40)))


@app.route('/api/scout/brain/status')
def scout_brain_status():
    from backend import market_brain
    return jsonify({'historical_learning': market_brain.historical_learning_status(),
                    'forecast_feedback': market_brain.feedback_summary()})


@app.route('/api/scout/exchanges')
def scout_coin_exchanges():
    """Read-only market-list lookup for an individual Storm Scout asset."""
    from backend.exchange_listings import coin_listings
    base = request.args.get('base', '')
    try:
        return jsonify(coin_listings(base, force=request.args.get('refresh') == '1'))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        traceback.print_exc()
        return jsonify({'error': str(exc)[:160], 'base': base.upper()}), 502


@app.route('/api/scout/new-listings')
def scout_new_listings():
    from backend.new_listing_hunter import discover_new_listings
    try:
        days = int(request.args.get('days', 30)); limit = int(request.args.get('limit', 30))
        return jsonify(discover_new_listings(days, limit))
    except (TypeError, ValueError):
        return jsonify({'error': 'پارامتر days یا limit نامعتبر است'}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)[:160], 'items': []}), 502


@app.route('/api/scout/new-listings/analyze')
def scout_analyze_new_listing():
    from backend.cold_start_analyzer import analyze_new_listing
    exchange = request.args.get('exchange', '')
    symbol = request.args.get('symbol', '')
    base = request.args.get('base', '')
    quote = request.args.get('quote', 'USDT')
    if not exchange or not symbol:
        return jsonify({'error': 'exchange و symbol الزامی هستند'}), 400
    try:
        # Independent contract check is opt-in and requires exact coin id, chain and address.
        identity = None
        coin_id = request.args.get('coin_id', '')
        platform = request.args.get('platform', '')
        contract = request.args.get('contract_address', '')
        verified = False
        if coin_id or platform or contract:
            from backend.token_identity import verify_token_contract
            identity = verify_token_contract(coin_id, platform, contract)
            verified = bool(identity.get('verified'))
        result = analyze_new_listing(exchange, symbol, base, quote, contract_verified=verified)
        result['contract_identity'] = identity or {
            'status': 'identity_unverified', 'verified': False,
            'reason': 'برای بررسی مستقل، coin_id، platform و contract_address باید هم‌زمان ارائه شوند.'}
        # Identity verification never makes an automated entry eligible.
        result['entry_ready'] = False
        return jsonify(result)
    except Exception as exc:
        return jsonify({'error': str(exc)[:160], 'entry_ready': False}), 502


@app.route('/api/scout/new-listings/liquidity', methods=['POST'])
def scout_new_listing_liquidity():
    from backend.liquidity_stability import TRACKER
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(TRACKER.record(payload.get('exchange', ''), payload.get('symbol', ''),
                                      payload.get('quote_volume'), payload.get('timestamp')))
    except Exception as exc:
        return jsonify({'error': str(exc)[:120], 'stable': False, 'entry_ready': False}), 400


@app.route('/api/scout/new-listings/depth')
def scout_new_listing_depth():
    from backend.storm_market_depth import fetch_orderbook
    exchange = request.args.get('exchange', '')
    symbol = request.args.get('symbol', '')
    if not exchange or not symbol:
        return jsonify({'error': 'exchange و symbol الزامی هستند', 'entry_ready': False}), 400
    try:
        levels = int(request.args.get('levels', 20))
        if levels < 5 or levels > 100:
            raise ValueError('levels باید بین 5 و 100 باشد')
        return jsonify(fetch_orderbook(exchange, symbol, levels))
    except ValueError as exc:
        return jsonify({'error': str(exc), 'entry_ready': False}), 400


@app.route('/api/scout/new-listings/walls', methods=['GET', 'POST'])
def scout_new_listing_walls():
    from backend.storm_wall_tracker import record_orderbook_snapshot, get_wall_history
    exchange, symbol = request.args.get('exchange', ''), request.args.get('symbol', '')
    if request.method == 'GET':
        if not exchange or not symbol:
            return jsonify({'error': 'exchange و symbol الزامی هستند'}), 400
        return jsonify(get_wall_history(exchange, symbol, request.args.get('limit', 10)))
    payload = request.get_json(silent=True) or {}
    exchange, symbol = payload.get('exchange', ''), payload.get('symbol', '')
    if not exchange or not symbol:
        return jsonify({'error': 'exchange و symbol الزامی هستند'}), 400
    from backend.storm_market_depth import fetch_orderbook
    book = fetch_orderbook(exchange, symbol, payload.get('levels', 20))
    if book.get('status') != 'depth_snapshot_ok':
        return jsonify(book), 502
    return jsonify(record_orderbook_snapshot(exchange, symbol, book, payload.get('timestamp')))


@app.route('/api/scout/new-listings/observations', methods=['GET', 'POST'])
def scout_new_listing_observations():
    from backend.storm_market_depth import record_observation, history
    if request.method == 'GET':
        exchange, symbol = request.args.get('exchange', ''), request.args.get('symbol', '')
        if not exchange or not symbol:
            return jsonify({'error': 'exchange و symbol الزامی هستند'}), 400
        return jsonify(history(exchange, symbol, request.args.get('limit', 12)))
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(record_observation(payload.get('exchange', ''), payload.get('symbol', ''),
            payload.get('quote_volume'), payload.get('bid_depth_quote'), payload.get('ask_depth_quote'),
            payload.get('spread_bps'), payload.get('timestamp')))
    except Exception as exc:
        return jsonify({'status':'snapshot_error','error':str(exc)[:140],'entry_ready':False}), 400


@app.route('/api/timeframes')
def timeframes():
    return jsonify({
        'timeframes': ['5m', '15m', '30m', '1h', '4h', '1d'],
        'labels': {'5m': '۵ دقیقه', '15m': '۱۵ دقیقه', '30m': '۳۰ دقیقه', '1h': '۱ ساعت',
                   '4h': '۴ ساعت', '1d': 'روزانه'}
    })


@app.route('/api/sources')
def sources():
    return jsonify({'sources': source_catalog(), 'auto_order': [
        'binance', 'bybit', 'okx', 'gateio', 'mexc', 'kucoin',
        'coinbase', 'nobitex', 'bit24', 'lbank', 'coinmarketcap'],
        'note': 'TradingView رابط نمودار است، نه منبع مستقل OHLC؛ داده نمودار از ارائه‌دهنده بازار تأمین می‌شود.'})


@app.route('/api/data/health')
def data_health():
    try:
        symbol, timeframe, _ = _validated_market(
            request.args.get('symbol', 'BTCUSDT'), request.args.get('timeframe', '1h'), 'auto')
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400

    from backend.data import reset_source_health
    reset_source_health()
    providers = []
    commodity_allowed = ('yahoo', 'tradingview', 'stooq', 'history')
    from backend.data import is_futures_symbol, FUTURES_AUTO_ORDER
    futures_mode = is_futures_symbol(symbol)
    for src, fn in SOURCE_FUNCS.items():
        if symbol in COMMODITIES_YAHOO and src not in commodity_allowed:
            continue
        # V21: futures symbols only probe futures feeds (+ local archive); spot never probes them.
        if futures_mode and src not in FUTURES_AUTO_ORDER and src != 'history':
            continue
        if not futures_mode and src in FUTURES_AUTO_ORDER:
            continue
        if src == 'coinmarketcap' and not os.getenv('CMC_API_KEY', '').strip():
            providers.append((src, None))
        elif (src == 'cryptocompare'
              and not os.getenv('CRYPTOCOMPARE_API_KEY', '').strip()):
            providers.append((src, None))
        elif src == 'stooq' and timeframe != '1d':
            continue
        else:
            providers.append((src, fn))

    def check_one(src, fn):
        if fn is None:
            key_name = ('CMC_API_KEY' if src == 'coinmarketcap'
                        else 'CRYPTOCOMPARE_API_KEY')
            return {'source': src, 'label': SOURCE_LABELS[src], 'ok': False,
                    'skipped': True, 'error': f'{key_name} تنظیم نشده است'}
        started = time.time()
        try:
            df = fn(symbol, timeframe, 250)
            count = int(len(df))
            return {'source': src, 'label': SOURCE_LABELS[src], 'ok': count >= 210,
                    'candles': count, 'latency_ms': int((time.time()-started)*1000),
                    'error': None if count >= 210 else 'کمتر از ۲۱۰ کندل'}
        except Exception as exc:
            return {'source': src, 'label': SOURCE_LABELS[src], 'ok': False,
                    'latency_ms': int((time.time()-started)*1000), 'error': str(exc)[:300]}

    results = []
    with ThreadPoolExecutor(max_workers=min(8, len(providers) or 1)) as pool:
        futures = [pool.submit(check_one, src, fn) for src, fn in providers]
        for future in as_completed(futures):
            results.append(future.result())
    order = {src: i for i, (src, _) in enumerate(providers)}
    results.sort(key=lambda item: order.get(item['source'], 999))
    return jsonify({'symbol': symbol, 'timeframe': timeframe, 'results': results})


@app.route('/api/models', methods=['GET'])
def models_list():
    return jsonify({'models': list_saved_models()})


@app.route('/api/models/info', methods=['GET'])
def models_info():
    return jsonify(models_dir_info())


@app.route('/api/models/<symbol>/<tf>', methods=['DELETE'])
def delete_one_model(symbol, tf):
    try:
        symbol, tf, _ = _validated_market(symbol, tf, 'auto')
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    ok = delete_model(symbol, tf)
    return jsonify({'deleted': ok})


@app.route('/api/learn/eligibility')
def learn_eligibility():
    """V21: may this symbol use single training? (not if multi-hour owns it)"""
    from backend import longrun
    symbol = str(request.args.get('symbol', '')).upper().strip()
    if not _SYMBOL_RE.fullmatch(symbol):
        return jsonify({'error': 'نماد بازار نامعتبر است'}), 400
    owned = symbol in longrun.multihour_symbols()
    return jsonify({'symbol': symbol, 'allowed': not owned, 'in_multihour': owned,
                    'reason': (f'{symbol} در آموزش چندساعته است' if owned else '')})


@app.route('/api/learn/adequacy')
def learn_adequacy():
    """V21: how many independent samples will this candle count give?"""
    from backend.adequacy import assess
    try:
        limit = int(request.args.get('limit', 10000))
        tf = str(request.args.get('timeframe', '1h'))
        if tf not in TIMEFRAMES_ALLOWED_FOR_ADEQUACY or not 200 <= limit <= 100000:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'error': 'limit یا timeframe نامعتبر است'}), 400
    return jsonify(assess(limit, tf))


@app.route('/api/learn/seed')
def learn_seed():
    """V21: which trained model could warm-start a NEW market (quick transfer training)?"""
    from backend.consensus import suggest_seed
    from backend.storage import model_path as _model_path
    try:
        symbol, timeframe, _ = _validated_market(request.args.get('symbol', ''),
                                                 request.args.get('timeframe', '1h'), 'auto')
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc) or 'ورودی نامعتبر'}), 400
    has_own = _model_path(symbol, timeframe).exists()
    seed = None if has_own else suggest_seed(symbol, timeframe)
    if seed:
        seed = {k: v for k, v in seed.items() if k != 'path'}
    return jsonify({'symbol': symbol, 'timeframe': timeframe, 'has_own_model': has_own,
                    'available': bool(seed), 'seed': seed})


@app.route('/api/learn', methods=['POST'])
def learn():
    """Trigger the training pipeline."""
    sess = get_session()
    from backend import longrun
    if sess.is_running or longrun.status().get('running'):
        return jsonify({'error': 'آموزش دیگری (یا آموزش خودکار چندساعته) در حال اجراست',
                        'running': True}), 409

    data = request.get_json(force=True, silent=True) or {}
    try:
        symbol, timeframe, source = _validated_market(
            data.get('symbol', 'BTCUSDT'), data.get('timeframe', '1h'), data.get('source', 'auto'))
        limit = int(data.get('limit', 3000))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc) or 'مقدار limit نامعتبر است'}), 400

    # V21: single training is for NEW coins only; multi-hour owns every market in its list.
    if symbol in longrun.multihour_symbols():
        return jsonify({'error': f'{symbol} در فهرست «آموزش چندساعته» است؛ یادگیری تکی فقط برای ارز جدید است. '
                                 'همان‌جا آموزشش بده یا ارز جدید را انتخاب کن.',
                        'in_multihour': True, 'symbol': symbol}), 409

    # Reject invalid limits instead of silently training on a different candle count.
    max_limit = 100000 if source == 'history' else 10000
    if limit < 500 or limit > max_limit:
        return jsonify({'error': f'برای منبع انتخاب‌شده تعداد کندل باید بین ۵۰۰ تا {max_limit:,} باشد. برای بیش از ۱۰هزار کندل، منبع «آرشیو تاریخی محلی» را انتخاب کن.'}), 400

    # V21: quick transfer training — only for a market with no model of its own.
    seed_from, quick = None, False
    if data.get('seed'):
        from backend.consensus import suggest_seed
        from backend.storage import model_path as _model_path
        if _model_path(symbol, timeframe).exists():
            return jsonify({'error': f'برای {symbol}/{timeframe} مدل اختصاصی وجود دارد؛ آموزش سریع فقط برای ارز بدون مدل است.',
                            'has_own_model': True}), 409
        found = suggest_seed(symbol, timeframe)
        if not found:
            return jsonify({'error': 'مدل آموزش‌دیده‌ی سازگاری برای شروع پیدا نشد؛ یادگیری عادی را بزن.',
                            'no_seed': True}), 409
        seed_from, quick = (found['symbol'], found['timeframe']), True

    # Start in background thread
    def run_in_thread():
        try:
            sess.run(symbol=symbol, timeframe=timeframe, limit=limit,
                     source=source, seed_from=seed_from, quick=quick)
        except Exception as e:
            sess.log(f"✖ خطا: {e}")
            sess.log(traceback.format_exc())

    t = threading.Thread(target=run_in_thread, daemon=True)
    t.start()
    est_sec = estimate_train_time(limit)
    est_min = max(1, int(round(est_sec / 60)))
    return jsonify({
        'started': True,
        'quick': quick,
        'seed_from': (f'{seed_from[0]}/{seed_from[1]}' if seed_from else None),
        'symbol': symbol,
        'timeframe': timeframe,
        'limit': limit,
        'trials': len(HP_GRID),
        'time_estimate_sec': est_sec,
        'message': f"آموزش شروع شد: {symbol} {timeframe} با {limit} کندل و {len(HP_GRID)} آزمون — "
                   f"زمان تقریبی: حدود {est_min} دقیقه"
    })


@app.route('/api/learn/progress')
def learn_progress():
    sess = get_session()
    return jsonify({
        'running': sess.is_running,
        'log': sess.progress_log[-80:] if sess.progress_log else [],
        'last_result': sess.last_result,
        'cancel': sess.cancel,
    })


@app.route('/api/learn/cancel', methods=['POST'])
def learn_cancel():
    sess = get_session()
    sess.cancel = True
    return jsonify({'cancel_requested': True})


@app.route('/api/rl/status')
def rl_status():
    try:
        from backend import rl_engine
        return jsonify(rl_engine.status())
    except Exception as exc:
        traceback.print_exc()
        return jsonify({'error': f'بارگذاری موتور DRL ناموفق بود: {exc}',
                        'app_version': APP_VERSION}), 500


@app.route('/api/rl/train', methods=['POST'])
def rl_train():
    data = request.get_json(force=True, silent=True) or {}
    try:
        from backend import rl_engine
    except Exception as exc:
        traceback.print_exc()
        return jsonify({'error': f'بارگذاری موتور DRL ناموفق بود: {exc}',
                        'app_version': APP_VERSION}), 500
    try:
        symbol, timeframe, source = _validated_market(
            data.get('symbol', 'BTCUSDT'), data.get('timeframe', '1h'), data.get('source', 'history'))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    try:
        limit = int(data.get('limit', 12000))
        if not 600 <= limit <= 100000:
            raise ValueError('تعداد کندل DRL باید بین ۶۰۰ تا ۱۰۰۰۰۰ باشد')
        timesteps = int(data.get('timesteps', 100000))
        fee_bps = float(data.get('fee_bps', 10))
        slippage_bps = float(data.get('slippage_bps', 5))
        candles = fetch_candles(symbol, timeframe, limit=limit, source=source,
                                validation_mode='research')
        from backend.trainer import validate_training_batch
        candles, _contract_report = validate_training_batch(
            candles, symbol=symbol, timeframe=timeframe,
            source=str(candles.attrs.get('source', source)))
        started = rl_engine.start_training(symbol, timeframe, candles,
            algorithms=data.get('algorithms'), timesteps=timesteps,
            fee_bps=fee_bps, slippage_bps=slippage_bps)
        if not started:
            return jsonify({'error': 'آموزش DRL دیگری در حال اجراست'}), 409
        return jsonify({'started': True, 'symbol': symbol, 'timeframe': timeframe,
                        'candles': len(candles), 'algorithms': data.get('algorithms') or list(rl_engine.ALGORITHMS),
                        'message': 'آموزش ترتیبی عامل‌های DRL آغاز شد؛ هیچ سفارش واقعی ارسال نمی‌شود.'})
    except Exception as exc:
        return jsonify({'error': str(exc)}), 400


@app.route('/api/rl/stop', methods=['POST'])
def rl_stop():
    try:
        from backend import rl_engine
        return jsonify({'stop_requested': rl_engine.request_stop()})
    except Exception as exc:
        traceback.print_exc()
        return jsonify({'error': f'توقف موتور DRL ناموفق بود: {exc}',
                        'app_version': APP_VERSION}), 500


# ---------------- One-button multi-hour training ----------------
@app.route('/api/longrun/start', methods=['POST'])
def longrun_start():
    """Start unattended training for N hours (data top-up + random search + gate).

    body may include "resume": true to continue the last interrupted run
    instead of starting from zero.
    """
    from backend import longrun
    cfg = dict(request.get_json(force=True, silent=True) or {})
    resume = bool(cfg.pop('resume', False))
    try:
        started = longrun.start(cfg, resume=resume)
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except RuntimeError as exc:
        return jsonify({'error': str(exc), 'running': True}), 409
    return jsonify({'started': True, 'resumed': bool(resume), 'config': started})


@app.route('/api/longrun/resume', methods=['POST'])
def longrun_resume():
    """Continue the last interrupted multi-hour run from where it stopped."""
    from backend import longrun
    cfg = dict(request.get_json(force=True, silent=True) or {})
    try:
        started = longrun.start(cfg, resume=True)
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except RuntimeError as exc:
        return jsonify({'error': str(exc), 'running': True}), 409
    return jsonify({'started': True, 'resumed': True, 'config': started})


@app.route('/api/longrun/resumable')
def longrun_resumable():
    """Info about the last interrupted run, for the resume button."""
    from backend import longrun
    info = longrun.resumable()
    if not info:
        return jsonify({'resumable': False,
                        'message': 'اجرای نیمه‌کاره‌ای برای ادامه دادن وجود ندارد.'})
    return jsonify(info)


@app.route('/api/longrun/status')
def longrun_status():
    from backend import longrun
    return jsonify(longrun.status())


@app.route('/api/longrun/stop', methods=['POST'])
def longrun_stop():
    from backend import longrun
    longrun.stop()
    return jsonify({'stop_requested': True})


@app.route('/api/longrun/presets')
def longrun_presets():
    from backend import longrun
    return jsonify({'presets': longrun.PRESETS})


@app.route('/api/ai/coach')
def ai_coach_status():
    """Status of the optional AI coach (Z.ai GLM) + recent coach messages."""
    from backend import ai_coach, longrun
    info = ai_coach.coach_available()
    try:
        live = longrun.status().get('coach_log') or []
    except Exception:
        live = []
    try:
        mem = ai_coach.load_coach_memory(12)
    except Exception:
        mem = []
    # Prefer live session log; fall back to persistent memory of past rounds
    info['recent'] = live if live else [
        {'symbol': m.get('symbol'), 'timeframe': m.get('timeframe'),
         'assessment_fa': m.get('assessment_fa'), 'advice_fa': m.get('advice_fa'),
         'ts': m.get('ts')} for m in mem
    ]
    info['memory_count'] = len(mem)
    return jsonify(info)



def _run_analysis(symbol: str, timeframe: str, source: str,
                  limit: int, threshold: float, strength: str) -> dict:
    """V19 core analysis pipeline, shared by /api/analyze and /api/analyst/report.

    Runs the full decision stack (data -> features -> model -> signal ->
    central brain) and additionally: matures + stores a market-memory
    snapshot, then builds the local narrative report. Returns the result dict.
    """
    # Fetch data. Signal generation is fail-closed: exchange sources must pass
    # paper-grade freshness/source checks; explicitly selected local history is
    # research mode and still must pass the Signal Engine's exact-PASS gate.
    validation_mode = 'research' if source == 'history' else 'paper'
    try:
        max_age_bars = int(os.getenv('TS_AI_SIGNAL_MAX_AGE_BARS', '2'))
    except (TypeError, ValueError) as exc:
        raise RuntimeError('TS_AI_SIGNAL_MAX_AGE_BARS must be a positive integer') from exc
    if max_age_bars < 1:
        raise RuntimeError('TS_AI_SIGNAL_MAX_AGE_BARS must be a positive integer')
    df = fetch_candles(
        symbol, timeframe, limit=limit, source=source,
        validation_mode=validation_mode,
        max_age_bars=(None if validation_mode == 'research' else max_age_bars))
    source_used = df.attrs.get('source', '?')
    data_contract_report = dict(df.attrs.get('data_contract') or {})
    if not data_contract_report:
        raise RuntimeError('Data Contract report is missing; signal generation blocked')

    # Build features and indicators (use full versions for backtest/signal)
    (features_train, y_train, raw_ret_train, last_row, ind_train,
     features_full, ind_full, y_raw, raw_ret_full,
     amb_full) = build_features(df)

    # Load saved model only when its feature semantics match this build.
    mp = model_path(symbol, timeframe)
    meta = load_meta(symbol, timeframe)
    model = TradingEnsemble.load(mp)

    if model is not None and meta.get('feature_schema_version') != FEATURE_SCHEMA_VERSION:
        return {
            'error': 'مدل ذخیره‌شده متعلق به نسخه قدیمی ویژگی‌هاست. برای جلوگیری از پیش‌بینی نادرست، این نماد را دوباره آموزش دهید.',
            'has_model': False,
            'requires_retrain': True,
            'feature_schema_version': FEATURE_SCHEMA_VERSION,
            'symbol': symbol,
            'timeframe': timeframe,
        }, 409

    if model is None or not model.is_fitted:
        # V20: before failing, ask ALL other trained models (advisory mode).
        try:
            _pool_probe = pool_votes(symbol, timeframe, features_full)
        except Exception:
            _pool_probe = {'votes': []}
        if not _pool_probe.get('votes'):
            return {
                'error': 'مدل آموزش‌دیده وجود ندارد. اول روی دکمه «یادگیری» بزنید.',
                'has_model': False,
                'symbol': symbol,
                'timeframe': timeframe,
            }, 404

    # V20: votes from EVERY other trained model ("از همه آموزش‌ها استفاده کن").
    try:
        pool = pool_votes(symbol, timeframe, features_full)
    except Exception as exc:
        pool = {'votes': [], 'n': 0, 'errors': [str(exc)[:160]]}

    advisory = (model is None or not model.is_fitted)
    primary_prob = None
    pool_weight = 0.0
    if advisory:
        # Pool consensus replaces the (missing) primary probability.
        prob = float(pool['consensus_prob'])
        pool_weight = 1.0
    else:
        # Predict on last row (use full features so we always have latest bar)
        last_features_df = features_full.iloc[[-1]][model.feature_names]
        primary_prob = float(model.predict_proba(last_features_df))
        # Blend the bounded pool consensus into the primary probability.
        prob, pool_weight = blend_probability(primary_prob, pool)
    news_alert = build_news_alert(symbol)
    brain_context = _collect_brain_context(symbol, timeframe, source, df)
    meta_probability = None
    meta_labeler = getattr(model, 'meta_labeler', None)
    if meta_labeler is not None and getattr(meta_labeler, 'is_fitted', False):
        try:
            meta_probability = meta_labeler.predict_meta(prob, ind_full.iloc[-1])
        except Exception:
            meta_probability = None

    # Model consensus: how much the base models agree on this bar
    # (low std = high agreement = historically higher accuracy)
    agr_std = None
    if not advisory:
        try:
            agr_std = float(model.predict_agreement(last_features_df)[0])
        except Exception:
            agr_std = None

    # Signal (use full ind so last row is "now")
    sig = compute_signal(ind_full, prob, threshold=threshold, news_alert=news_alert,
                         meta_probability=meta_probability,
                         meta_threshold=getattr(model, 'meta_threshold', 0.55),
                         strength=strength,
                         data_contract_report=data_contract_report)
    # OOS edge gate (primary mode) or the conservative pool gate (advisory).
    if advisory:
        allowed, gate_note = advisory_gate(pool)
        effective_threshold = threshold
        edge_confirmed = bool(allowed)   # pool consensus gate replaces per-model OOS gate
        if sig.get('kind') in ('BUY', 'SELL') and not allowed:
            sig['kind'] = 'HOLD'
            sig['levels_provisional'] = True
            sig['reason'] = f'تحلیل مشورتی: {gate_note} ورود مستقیم توصیه نمی‌شود.'
    else:
        sig, effective_threshold, edge_confirmed = apply_oos_edge_gate(
            sig, meta or {}, threshold, strength=strength)
        if edge_confirmed and effective_threshold > threshold + 1e-9:
            sig = compute_signal(
                ind_full, prob, threshold=effective_threshold,
                news_alert=news_alert, meta_probability=meta_probability,
                meta_threshold=getattr(model, 'meta_threshold', 0.55),
                strength=strength,
                data_contract_report=data_contract_report)

    # V20: pool consensus note attached to the signal (both modes).
    if pool.get('n'):
        _pool_dir_fa = 'صعودی' if pool['consensus_dir'] == 'UP' else 'نزولی'
        sig.setdefault('reasons', []).append(
            ('pos' if pool['consensus_dir'] == 'UP' else 'neg',
             f"اجماع {pool['n']} مدل آموزش‌دیده ({pool['same_symbol_votes']} هم‌نماد، "
             f"{pool['same_tf_votes']} هم‌تایم‌فریم): تمایل {_pool_dir_fa} با "
             f"P={pool['consensus_prob']:.3f} و هم‌جهتی {pool['agreement']*100:.0f}%"))
        sig['pool_consensus'] = {'n': pool['n'], 'consensus_prob': pool['consensus_prob'],
                                 'consensus_dir': pool['consensus_dir'],
                                 'agreement': pool['agreement'],
                                 'blend_weight': pool_weight}
    if advisory:
        sig['advisory'] = True
        if sig.get('kind') in ('BUY', 'SELL'):
            sig['levels_provisional'] = True
            sig['reason'] = ('تحلیل مشورتی از اجماع همه مدل‌های آموزش‌دیده — مدل اختصاصی '
                             'این نماد/تایم‌فریم هنوز آموزش ندیده؛ با حجم کم و احتیاط. '
                             + str(sig.get('reason', '')))
        else:
            sig['reason'] = str(sig.get('reason', '')) + ' (تحلیل مشورتی)'

    # Metadata contains the out-of-sample test-window start timestamp.
    test_start_ts = (meta or {}).get('test_start_ts')
    hist = (backtest_signals(ind_full, features_full, model,
                             threshold=effective_threshold, min_ts=test_start_ts)
            if edge_confirmed else [])

    ind_summary = _indicators_summary(ind_full)
    # Preserve the exact latest numeric feature row used by this analysis so
    # paper AutoPilot entries can later be audited/trained from their entry-time
    # feature state rather than attempting to reconstruct it from future data.
    latest_features = {}
    if len(features_full):
        try:
            last_feature_row = features_full.iloc[-1]
            for feature_name, feature_value in last_feature_row.items():
                try:
                    numeric_value = float(feature_value)
                except (TypeError, ValueError):
                    continue
                if np.isfinite(numeric_value):
                    latest_features[str(feature_name)] = numeric_value
                if len(latest_features) >= 256:
                    break
        except Exception:
            latest_features = {}

    wins = sum(1 for b in hist if b.get('result') == 'win')
    losses = sum(1 for b in hist if b.get('result') == 'loss')
    gross_wins = sum(1 for b in hist if b.get('gross_result') == 'win')
    ambiguous = sum(1 for b in hist if b.get('result') == 'ambiguous')
    opens = sum(1 for b in hist if b.get('result') == 'open')
    closed = wins + losses
    net_returns = [float(b['net_ret_pct']) for b in hist if b.get('net_ret_pct') is not None]
    backtest_stats = {
        'wins': wins, 'losses': losses, 'gross_wins': gross_wins, 'ambiguous': ambiguous,
        'open': opens,
        'win_rate': (wins / closed) if closed else None,
        'gross_win_rate': (gross_wins / closed) if closed else None,
        'net_return_sum_pct': float(sum(net_returns)),
        'average_net_trade_pct': float(np.mean(net_returns)) if net_returns else None,
        'round_trip_cost_pct': __import__('backend.signal', fromlist=['ROUND_TRIP_COST_PCT']).ROUND_TRIP_COST_PCT,
        'out_of_sample_only': test_start_ts is not None,
    }

    result = {
        'has_model': True,
        'advisory': advisory,
        'primary_prob': primary_prob,
        'blend_weight': pool_weight,
        'model_pool': {k: pool.get(k) for k in ('votes', 'n', 'consensus_prob',
                                                'consensus_dir', 'agreement',
                                                'same_symbol_votes', 'same_tf_votes',
                                                'edge_share', 'errors')},
        'symbol': symbol,
        'timeframe': timeframe,
        'source': source_used,
        'data_quality': data_contract_report,
        'source_label': df.attrs.get('source_label', source_used),
        'source_chain': df.attrs.get('fallback_chain', []),
        'candle_count': int(len(df)),
        'price': float(df['close'].iloc[-1]),
        'strength': strength,
        'change_pct': (float((df['close'].iloc[-1] / df['close'].iloc[-25] - 1) * 100)
                       if len(df) > 25 else 0.0),
        'signal': sig,
        'backtest': hist,
        'backtest_stats': backtest_stats,
        'edge_confirmed': edge_confirmed,
        'effective_threshold': effective_threshold,
        'indicators': ind_summary,
        'latest_features': latest_features,
        'model_feature_names': list(getattr(model, 'feature_names', []) or [])[:256] if model is not None else [],
        'model_meta': meta,
        'candles': to_display(df.tail(1000)),
        'emas': {
            'ema20': float(ema(df['close'], 20).iloc[-1]),
            'ema50': float(ema(df['close'], 50).iloc[-1]),
        },
        'rsi': float(rsi(df['close']).iloc[-1]),
        'atr': float(atr(df['high'], df['low'], df['close']).iloc[-1]),
    }

    if agr_std is not None:
        sig['agreement_std'] = agr_std
        sig['agreement'] = ('high' if agr_std < 0.05
                            else 'medium' if agr_std < 0.10 else 'low')

    try:
        from backend.rl_engine import predict_position
        rl_review = predict_position(symbol, timeframe, df)
    except Exception:
        rl_review = None
    if not rl_review:
        rl_review = {'available': False,
                     'message': 'برای این نماد/تایم‌فریم هنوز عامل DRL واجد شرایط فعال نشده است.'}

    # Central fusion (V19 brain v3: +divergence, +ichimoku, +volume,
    # confluence shaping, internal scenario plan attached to the signal).
    from backend.brain import make_brain_decision
    brain_base_signal = dict(sig)
    brain = make_brain_decision(
        symbol=symbol, timeframe=timeframe,
        bar_ts=int(ind_full['t'].iloc[-1]) if 't' in ind_full.columns else 0,
        price=float(df['close'].iloc[-1]), model_prob=prob,
        indicators=ind_full,
        regime=brain_context.get('regime'),
        mtf=brain_context.get('multi_timeframe'),
        patterns=brain_context.get('patterns'),
        derivatives=brain_context.get('derivatives'),
        outlook=brain_context.get('outlook'), news=news_alert,
        rl_review=rl_review if rl_review.get('deployment_eligible') else None,
        early_trend=brain_context.get('early_trend'), market_frame=df,
        # advisory mode: the pool gate (>=3 voters, agreement, edge-share) is the
        # edge check here — brain keeps all its own coverage/support vetoes.
        edge_confirmed=bool(edge_confirmed),
        base_signal=brain_base_signal,
        agreement_std=agr_std, strength=strength,
        # V20: the pool of ALL trained models becomes its own brain evidence
        # stream (bounded base weight) instead of only blending into the prob.
        pool=pool,
    )
    sig = brain_base_signal
    if rl_review.get('deployment_eligible') and rl_review.get('direction') == sig.get('kind'):
        sig['rl_confirmation'] = True
    if sig.get('kind') == 'HOLD' and brain.get('vetoes'):
        sig['reason'] = str(sig.get('reason', ''))
    result['signal'] = sig
    result['brain'] = brain
    result['rl_review'] = rl_review
    result['market_context'] = {
        'regime': brain_context.get('regime'),
        'patterns': brain_context.get('patterns'),
        'early_trend': brain_context.get('early_trend'),
        'multi_horizon': brain_context.get('outlook'),
        'multi_timeframe': brain_context.get('multi_timeframe'),
        'short_term': brain_context.get('short_term', []),
        'derivatives': brain_context.get('derivatives'),
        'feed_errors': brain_context.get('feed_errors', []),
    }

    # --- V19 market memory: mature older snapshots, store this one, report ---
    try:
        from backend import memory as market_memory
        market_memory.mature_snapshots(symbol, timeframe, df)
        current_price = float(df['close'].iloc[-1])
        market_memory.save_snapshot(
            symbol, timeframe,
            int(ind_full['t'].iloc[-1]) if 't' in ind_full.columns else 0,
            current_price, sig, brain, brain_context.get('regime'),
            brain.get('components') and {
                k: v.get('score') for k, v in brain['components'].items()},
        )
        result['memory'] = market_memory.memory_report(symbol, timeframe,
                                                       current_price=current_price)
    except Exception as exc:
        result['memory'] = {'available': False, 'error': str(exc)[:160]}

    # --- V19 local narrative report (fast, offline; deep is a separate call) ---
    try:
        from backend import analyst
        result['analyst_report'] = analyst.local_report(result, result.get('memory'))
    except Exception as exc:
        result['analyst_report'] = {'engine': 'local', 'sections': [],
                                    'error': str(exc)[:160]}

    return result, 200


@app.route('/api/analyze', methods=['POST'])
def analyze():
    """Run analysis: fetch data, load model, compute signal, brain, memory, report."""
    data = request.get_json(force=True, silent=True) or {}
    try:
        symbol, timeframe, source = _validated_market(
            data.get('symbol', 'BTCUSDT'), data.get('timeframe', '1h'), data.get('source', 'auto'))
        limit = int(data.get('limit', 1500))
        threshold = float(data.get('threshold', 0.6))
        strength = normalize_strength(data.get('strength'))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc) or 'مقدار limit یا threshold نامعتبر است'}), 400
    if not 210 <= limit <= 10000:
        return jsonify({'error': 'تعداد کندل باید بین ۲۱۰ تا ۱۰۰۰۰ باشد'}), 400
    if not np.isfinite(threshold) or not 0.5 <= threshold <= 0.99:
        return jsonify({'error': 'آستانه باید بین ۰٫۵۰ تا ۰٫۹۹ باشد'}), 400

    try:
        result, status = _run_analysis(symbol, timeframe, source, limit, threshold, strength)
        if status != 200:
            return jsonify(result), status
        return jsonify(result)
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e), 'hint': 'منبع را روی خودکار بگذارید یا وضعیت منابع را از /api/data/health بررسی کنید.'}), 502


@app.route('/api/chart', methods=['GET'])
def chart_data():
    """Fetch chart candles independently from model/signal analysis.

    Research validation allows a clearly-labelled cached/stale batch to be
    displayed for inspection, while /api/analyze remains paper-grade and
    fail-closed. This keeps a missing/old model from hiding an otherwise
    available price chart.
    """
    try:
        symbol, timeframe, source = _validated_market(
            request.args.get('symbol', 'BTCUSDT'),
            request.args.get('timeframe', '1h'),
            request.args.get('source', 'auto'))
        limit = int(request.args.get('limit', 1500))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc) or 'ورودی نمودار نامعتبر است'}), 400

    if not 210 <= limit <= 10000:
        return jsonify({'error': 'تعداد کندل نمودار باید بین ۲۱۰ تا ۱۰۰۰۰ باشد'}), 400

    try:
        # Chart feeds deliberately exclude TradingView. Use independent public
        # exchange/data vendors and local cache only; analysis/trading feeds stay unchanged.
        chart_source = 'auto' if source == 'tradingview' else source
        df = fetch_candles(symbol, timeframe, limit=limit, source=chart_source,
                           validation_mode='research', max_age_bars=None)
        contract = dict(df.attrs.get('data_contract') or {})
        if not contract:
            raise RuntimeError('گزارش Data Contract برای نمودار موجود نیست')
        candles = to_display(df.tail(1000))
        return jsonify({
            'symbol': symbol,
            'timeframe': timeframe,
            'source': df.attrs.get('source', source),
            'source_label': df.attrs.get('source_label', df.attrs.get('source', source)),
            'source_chain': df.attrs.get('fallback_chain', []),
            'candle_count': int(len(df)),
            'candles': candles,
            'price': float(df['close'].iloc[-1]),
            'data_quality': contract,
            'cache_saved_at': df.attrs.get('cache_saved_at'),
            'chart_only': True,
        })
    except Exception as exc:
        traceback.print_exc()
        return jsonify({
            'error': str(exc) or 'دریافت داده نمودار ناموفق بود',
            'hint': 'از دکمه «منابع» وضعیت صرافی‌ها را بررسی کن؛ برای آرشیو محلی، منبع «آرشیو محلی» را انتخاب کن.',
            'symbol': symbol, 'timeframe': timeframe,
        }), 502


@app.route('/api/analyst/status')
def analyst_status():
    """Status of the deep (GLM) report engine."""
    from backend import analyst
    return jsonify(analyst.deep_available())


@app.route('/api/analyst/report', methods=['POST'])
def analyst_report():
    """Narrative Persian report. `deep: true` uses GLM when a key is configured.

    Body: {symbol, timeframe, source?, limit?, threshold?, strength?, deep?}
    """
    data = request.get_json(force=True, silent=True) or {}
    try:
        symbol, timeframe, source = _validated_market(
            data.get('symbol', 'BTCUSDT'), data.get('timeframe', '1h'), data.get('source', 'auto'))
        limit = int(data.get('limit', 1500))
        threshold = float(data.get('threshold', 0.6))
        strength = normalize_strength(data.get('strength'))
        deep = bool(data.get('deep', False))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc) or 'ورودی نامعتبر است'}), 400
    if not 210 <= limit <= 10000:
        return jsonify({'error': 'تعداد کندل باید بین ۲۱۰ تا ۱۰۰۰۰ باشد'}), 400
    if not np.isfinite(threshold) or not 0.5 <= threshold <= 0.99:
        return jsonify({'error': 'آستانه باید بین ۰٫۵۰ تا ۰٫۹۹ باشد'}), 400

    try:
        result, status = _run_analysis(symbol, timeframe, source, limit, threshold, strength)
        if status != 200:
            return jsonify(result), status
        from backend import analyst
        if deep:
            report = analyst.deep_report(result, result.get('memory'))
        else:
            report = analyst.local_report(result, result.get('memory'))
        return jsonify({
            'report': report,
            'analysis_summary': {
                'symbol': symbol, 'timeframe': timeframe,
                'signal': result['signal'].get('kind'),
                'brain_confirmed': bool(result['signal'].get('brain_confirmed')),
                'price': result.get('price'),
                'strength': strength,
            },
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 502


@app.route('/api/memory')
def memory_endpoint():
    """Market memory report (latest snapshot, diff, matured outcome stats)."""
    from backend import memory as market_memory
    try:
        symbol, timeframe, _ = _validated_market(
            request.args.get('symbol', 'BTCUSDT'), request.args.get('timeframe', '1h'), 'auto')
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    price = request.args.get('price')
    try:
        price_f = float(price) if price is not None else None
    except (TypeError, ValueError):
        price_f = None
    return jsonify(market_memory.memory_report(symbol, timeframe, current_price=price_f))


@app.route('/api/feature_importance/<symbol>/<tf>')
def feature_importance(symbol, tf):
    """Return top features for a saved model."""
    try:
        symbol, tf, _ = _validated_market(symbol, tf, 'auto')
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    mp = model_path(symbol, tf)
    model = TradingEnsemble.load(mp)
    if model is None:
        return jsonify({'error': 'مدل وجود ندارد'}), 404
    imp = model.feature_importance()
    return jsonify({
        'top_20': imp.head(20).to_dict('records'),
        'total_features': len(model.feature_names),
    })


def _indicators_summary(ind: pd.DataFrame) -> dict:
    """Summarize last-row indicator values."""
    last = ind.iloc[-1]
    out = {}
    fields = [
        'rsi_14', 'rsi_7', 'rsi_21',
        'ema_20', 'ema_50', 'ema_100', 'ema_200',
        'sma_20', 'sma_50',
        'macd_line', 'macd_signal', 'macd_hist',
        'stoch_k', 'stoch_d',
        'williams_r_14', 'cci_20',
        'atr_14', 'atr_7',
        'bb_pct', 'bb_width',
        'mfi_14', 'cmf_20',
        'adx_14', 'plus_di', 'minus_di',
        'aroon_up', 'aroon_down',
        'obv', 'force_index_13',
        'supertrend',
        'ich_tenkan', 'ich_kijun',
        'coppock', 'tsi', 'uo',
    ]
    for f in fields:
        if f in ind.columns:
            v = last.get(f)
            if v is not None and not (isinstance(v, float) and (np.isnan(v) if hasattr(v, '__class__') else False)):
                try:
                    out[f] = float(v)
                except (TypeError, ValueError):
                    pass
    return out


# Optional: simple test endpoint to verify ML pipeline works without network
@app.route('/api/test/ml')
def test_ml():
    """Run a quick ML test on synthetic data."""
    import numpy as np
    n = 800
    np.random.seed(42)
    returns = np.random.normal(0, 0.01, n)
    closes = 100 * np.exp(np.cumsum(returns))
    df = __synth_df(closes)
    try:
        (features, y, _, last_row, ind_train,
         features_full, ind_full, y_raw, raw_ret_full, _) = build_features(df)
        X_tr, y_tr, X_val, y_val, X_te, y_te = temporal_split(features, y)
        m = TradingEnsemble()
        m.fit(X_tr, y_tr, X_val=X_val, y_val=y_val, params=HP_GRID[0])
        metrics = m.evaluate(X_te, y_te)
        return jsonify({
            'ok': True,
            'samples': len(features),
            'features': features.shape[1],
            'test_acc': metrics['accuracy'],
            'balanced_acc': metrics['balanced_acc'],
        })
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500


def __synth_df(closes):
    import pandas as pd
    n = len(closes)
    opens = closes * (1 + np.random.normal(0, 0.002, n))
    highs = np.maximum(opens, closes) * (1 + np.abs(np.random.normal(0, 0.003, n)))
    lows = np.minimum(opens, closes) * (1 - np.abs(np.random.normal(0, 0.003, n)))
    volumes = np.random.lognormal(10, 1, n)
    ts = (np.arange(n) * 3600 * 1000).astype(int)
    return pd.DataFrame({
        't': ts, 'open': opens, 'high': highs,
        'low': lows, 'close': closes, 'volume': volumes,
    })


# V22.2k trusted signing-key lifecycle (private keys are never exposed by API).
@app.route('/api/security/anchor/status', methods=['GET'])
def anchor_key_status():
    from backend import signed_anchor
    kp = signed_anchor.ensure_keypair()
    revoked = signed_anchor._load_json(signed_anchor._revoked_file(), {'revoked': []}).get('revoked', [])
    sequence = signed_anchor._load_json(signed_anchor._sequence_file(), {'highest_sequence': 0}).get('highest_sequence', 0)
    return jsonify({'active_key_id': kp['key_id'], 'revoked_key_ids': revoked, 'highest_sequence': sequence})

@app.route('/api/security/anchor/rotate', methods=['POST'])
def anchor_key_rotate():
    from backend import signed_anchor
    data = request.get_json(silent=True) or {}
    return jsonify(signed_anchor.rotate_key(revoke_old=bool(data.get('revoke_old', False))))

@app.route('/api/security/anchor/revoke', methods=['POST'])
def anchor_key_revoke():
    from backend import signed_anchor
    data = request.get_json(silent=True) or {}
    key_id = str(data.get('key_id', '')).lower().strip()
    if not key_id:
        return jsonify({'error': 'key_id is required'}), 400
    try:
        return jsonify(signed_anchor.revoke_key(key_id))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400

@app.route('/api/security/anchor/export/<key_id>', methods=['GET'])
def anchor_key_export(key_id):
    from backend import signed_anchor
    try:
        return jsonify(signed_anchor.export_public_key(key_id))
    except FileNotFoundError as exc:
        return jsonify({'error': str(exc)}), 404

@app.route('/api/security/anchor/import', methods=['POST'])
def anchor_key_import():
    from backend import signed_anchor
    data = request.get_json(silent=True) or {}
    try:
        result = signed_anchor.import_trusted_public_key(data.get('public_key_pem', ''), expected_fingerprint=str(data.get('fingerprint_sha256', '')))
        return jsonify(result)
    except Exception as exc:
        return jsonify({'error': str(exc)}), 400


# Run helper
def run_server(host='127.0.0.1', port=8765, debug=False):
    """Run the unauthenticated desktop API on loopback only."""
    from backend.local_security import is_loopback_bind_host
    if not is_loopback_bind_host(host):
        raise ValueError(
            'Remote binding is disabled: this API has no user authentication. '
            'Use 127.0.0.1, localhost, or ::1.'
        )
    app.config['LOOPBACK_ONLY'] = True
    debug = False  # debugger/reloader are never enabled for this local trading API
    print(f"Starting server on http://{host}:{port}")
    try:                                   # V19.3: storm scout retries until the internet is back
        from backend import scout
        if scout.start_background():
            print('[scout] دیده‌بان طوفان فعال شد (SCOUT_ENABLED=0 برای خاموش کردن).')
    except Exception as exc:
        print(f'[scout] could not start: {exc}')
    # AutoPilot is deliberately opt-in. Historical learning and the live
    # market-monitoring loop start independently above; app launch alone must
    # not silently enable even simulated paper entries.
    from backend.startup import start_autopilot_on_server_start
    start_autopilot_on_server_start()
    app.run(host=host, port=port, debug=debug, threaded=True,
            use_reloader=False, use_debugger=False)

# V22.2l external witness integration. The witness must be independently hosted
# and pinned via TS_AI_WITNESS_PUBLIC_KEY_PEM; no local fallback is presented as external.
@app.route('/api/security/anchor/external/status', methods=['GET'])
def external_anchor_status():
    from backend import external_anchor, signed_anchor
    return jsonify({'witness': external_anchor.config_status(), 'local_trust_store': signed_anchor.trust_store_health()})

@app.route('/api/security/anchor/external/submit', methods=['POST'])
def external_anchor_submit():
    from backend import external_anchor
    data = request.get_json(silent=True) or {}
    anchor = data.get('anchor')
    if not isinstance(anchor, dict):
        return jsonify({'ok': False, 'error': 'anchor_object_required'}), 400
    result = external_anchor.submit_anchor(anchor)
    return jsonify(result), (200 if result.get('ok') else 503)

@app.route('/api/paper-live/portfolio-guard', methods=['POST'])
def paper_live_portfolio_guard():
    """Read-only snapshot audit of open paper positions; never changes orders."""
    from backend.portfolio_guard import analyze_paper_portfolio
    try:
        payload = request.get_json(silent=True) or {}
        return jsonify(analyze_paper_portfolio(payload.get('positions', []),
            equity=payload.get('equity', 1000.0), peak_equity=payload.get('peak_equity'),
            settings=payload.get('settings', {})))
    except (TypeError, ValueError) as exc:
        return jsonify({'error':str(exc),'read_only':True,'paper_only':True,
                        'execution_authorized':False,'real_orders_enabled':False}),400
    except Exception:
        app.logger.exception('paper portfolio guard failed')
        return jsonify({'error':'portfolio audit failed','real_orders_enabled':False,
                        'execution_authorized':False}),500


@app.route('/api/paper-live/dynamic-position-management', methods=['POST'])
def paper_live_dynamic_position_management():
    """Read-only management recommendations for existing paper positions."""
    from backend.dynamic_position_manager import evaluate_open_paper_positions
    try:
        payload = request.get_json(silent=True) or {}
        return jsonify(evaluate_open_paper_positions(payload.get('positions', []), payload.get('settings', {})))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc), 'read_only': True, 'paper_only': True,
                        'execution_authorized': False, 'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('dynamic position management failed')
        return jsonify({'error': 'position evaluation failed', 'real_orders_enabled': False,
                        'execution_authorized': False}), 500


@app.route('/api/paper-live/exit-intelligence', methods=['POST'])
def paper_live_exit_intelligence():
    """Read-only exit risk assessment; never executes or mutates a position."""
    from backend.exit_intelligence import evaluate_exit_intelligence
    try:
        payload = request.get_json(silent=True) or {}
        return jsonify(evaluate_exit_intelligence(payload.get('positions', []), payload.get('settings', {})))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc), 'read_only': True, 'paper_only': True,
                        'execution_authorized': False, 'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('paper exit intelligence failed')
        return jsonify({'error': 'exit assessment failed', 'execution_authorized': False,
                        'real_orders_enabled': False}), 500


@app.route('/api/paper-live/trade-lifecycle/preview', methods=['POST'])
def paper_live_trade_lifecycle_preview():
    """Read-only orchestration of paper-position management and exit advice."""
    from backend.trade_lifecycle import evaluate_trade_lifecycle
    try:
        payload = request.get_json(silent=True) or {}
        return jsonify(evaluate_trade_lifecycle(payload.get('positions', []),
            payload.get('closed_trades', []), payload.get('settings', {})))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc), 'read_only': True, 'paper_only': True,
            'execution_authorized': False, 'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('paper trade lifecycle preview failed')
        return jsonify({'error': 'lifecycle preview failed', 'execution_authorized': False,
            'real_orders_enabled': False}), 500


@app.route('/api/paper-live/entry-quality-gate', methods=['POST'])
def paper_live_entry_quality_gate():
    """Read-only pre-entry screening; a pass never authorizes execution."""
    from backend.entry_quality_gate import evaluate_entry_quality
    try:
        payload = request.get_json(silent=True) or {}
        return jsonify(evaluate_entry_quality(payload.get('candidates', []), payload.get('settings', {})))
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc), 'read_only': True, 'paper_only': True,
            'entry_authorized': False, 'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('paper entry quality gate failed')
        return jsonify({'error': 'entry quality assessment failed', 'entry_authorized': False,
            'real_orders_enabled': False}), 500


@app.route('/api/scout/new-listings/risk-gate', methods=['POST'])
def scout_new_listing_risk_gate():
    """Read-only conservative risk triage for newly listed spot candidates."""
    from backend.new_listing_risk_gate import evaluate_new_listing_risk
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(evaluate_new_listing_risk(payload.get('candidates', []), payload.get('settings')))
    except ValueError as exc:
        return jsonify({'error': str(exc), 'entry_authorized': False,
                        'real_orders_enabled': False}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)[:160], 'entry_authorized': False,
                        'real_orders_enabled': False}), 400


@app.route('/api/scout/explosive-opportunities/screen', methods=['POST'])
def scout_explosive_opportunities_screen():
    """Read-only evidence screener; never authorizes or places trades."""
    from backend.explosive_opportunity_screener import screen_explosive_opportunities
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(screen_explosive_opportunities(payload.get('candidates', []), payload.get('settings')))
    except ValueError as exc:
        return jsonify({'error': str(exc), 'entry_authorized': False,
                        'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('explosive opportunity screen failed')
        return jsonify({'error': 'screening failed', 'entry_authorized': False,
                        'real_orders_enabled': False}), 500


@app.route('/api/scout/liquidity-behavior/analyze', methods=['POST'])
def scout_liquidity_behavior_analyze():
    """Read-only order-book behavior analysis; never authorizes or places trades."""
    from backend.liquidity_behavior_analyzer import analyze_liquidity_behavior
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(analyze_liquidity_behavior(payload.get('candidates', [])))
    except ValueError as exc:
        return jsonify({'error': str(exc), 'entry_authorized': False, 'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('liquidity behavior analysis failed')
        return jsonify({'error': 'analysis failed', 'entry_authorized': False, 'real_orders_enabled': False}), 500


@app.route('/api/scout/market-traps/detect', methods=['POST'])
def scout_market_traps_detect():
    """Read-only market-trap evidence detector; no trading or order execution."""
    from backend.market_trap_detector import detect_market_traps
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(detect_market_traps(payload.get('candidates', [])))
    except ValueError as exc:
        return jsonify({'error': str(exc), 'entry_authorized': False, 'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('market trap detection failed')
        return jsonify({'error': 'detection failed', 'entry_authorized': False, 'real_orders_enabled': False}), 500


@app.route('/api/scout/liquidity-sweeps/analyze', methods=['POST'])
def scout_liquidity_sweeps_analyze():
    """Read-only equal-high/low liquidity sweep analysis; no execution authority."""
    from backend.liquidity_sweep_intelligence import analyze_liquidity_sweeps
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(analyze_liquidity_sweeps(
            payload.get('candidates', []),
            tolerance_pct=payload.get('tolerance_pct', 0.15),
            lookback=payload.get('lookback', 30),
        ))
    except ValueError as exc:
        return jsonify({'error': str(exc), 'entry_authorized': False, 'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('liquidity sweep analysis failed')
        return jsonify({'error': 'analysis failed', 'entry_authorized': False, 'real_orders_enabled': False}), 500


@app.route('/api/scout/absorption/analyze', methods=['POST'])
def scout_absorption_analyze():
    """Read-only multi-interval absorption evidence; never authorizes orders."""
    from backend.absorption_intelligence import analyze_absorption
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(analyze_absorption(
            payload.get('candidates', []),
            dominance_ratio=payload.get('dominance_ratio', 1.8),
            max_adverse_move_pct=payload.get('max_adverse_move_pct', 0.15),
            min_samples=payload.get('min_samples', 3),
            persistence_ratio=payload.get('persistence_ratio', 0.60),
        ))
    except ValueError as exc:
        return jsonify({'error': str(exc), 'entry_authorized': False,
                        'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('absorption analysis failed')
        return jsonify({'error': 'analysis failed', 'entry_authorized': False,
                        'real_orders_enabled': False}), 500


@app.route('/api/scout/smart-money-flow/analyze', methods=['POST'])
def scout_smart_money_flow_analyze():
    """Read-only supplied-candle money-flow analysis; never places orders."""
    from backend.smart_money_flow import analyze_smart_money_flow
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(analyze_smart_money_flow(payload.get('candidates', [])))
    except ValueError as exc:
        return jsonify({'error': str(exc), 'entry_authorized': False, 'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('smart money flow analysis failed')
        return jsonify({'error': 'analysis failed', 'entry_authorized': False, 'real_orders_enabled': False}), 500


@app.route('/api/scout/master-market-intelligence/analyze', methods=['POST'])
def scout_master_market_intelligence_analyze():
    """Read-only fusion of supplied market evidence; never authorizes orders."""
    from backend.master_market_intelligence import analyze_master_market_intelligence
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(analyze_master_market_intelligence(payload.get('candidates', [])))
    except ValueError as exc:
        return jsonify({'error': str(exc), 'entry_authorized': False, 'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('master market intelligence analysis failed')
        return jsonify({'error': 'analysis failed', 'entry_authorized': False, 'real_orders_enabled': False}), 500


@app.route('/api/scout/ai-decision/evaluate', methods=['POST'])
def scout_ai_decision_evaluate():
    """Advisory decision layer over supplied master-intelligence metrics; no orders."""
    from backend.ai_decision_engine import decide_ai_candidates
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(decide_ai_candidates(payload.get('candidates', [])))
    except ValueError as exc:
        return jsonify({'error': str(exc), 'entry_authorized': False, 'real_orders_enabled': False, 'creates_orders': False}), 400
    except Exception:
        app.logger.exception('AI decision evaluation failed')
        return jsonify({'error': 'decision evaluation failed', 'entry_authorized': False, 'real_orders_enabled': False, 'creates_orders': False}), 500


@app.route('/api/paper-live/simulation/preview', methods=['POST'])
def paper_live_simulation_preview():
    """Calculate paper-trade sizing/brackets/costs without creating a position."""
    from backend.trade_simulation_intelligence import preview_trade_plans
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(preview_trade_plans(payload.get('candidates', []),
                                           payload.get('capital_usdt', 1000)))
    except ValueError as exc:
        return jsonify({'error': str(exc), 'creates_positions': False,
                        'creates_orders': False, 'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('paper simulation preview failed')
        return jsonify({'error': 'simulation preview failed', 'creates_positions': False,
                        'creates_orders': False, 'real_orders_enabled': False}), 500


@app.route('/api/paper-live/execution/preflight', methods=['POST'])
def paper_live_execution_preflight():
    """Validate a batch before paper execution; this endpoint is strictly read-only."""
    from backend.paper_execution_preflight import preflight_paper_candidates
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(preflight_paper_candidates(payload.get('candidates', [])))
    except ValueError as exc:
        return jsonify({'error': str(exc), 'creates_positions': False,
                        'creates_orders': False, 'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('paper execution preflight failed')
        return jsonify({'error': 'paper execution preflight failed',
                        'creates_positions': False, 'creates_orders': False,
                        'real_orders_enabled': False}), 500


@app.route('/api/paper-live/decision-execution', methods=['POST'])
def paper_live_decision_execution():
    """Explicitly armed bridge from qualified AI candidates to local paper positions."""
    blocked = _paper_ledger_lease_guard()
    if blocked is not None:
        return blocked
    from backend.paper_execution_orchestrator import execute_paper_candidates
    payload = request.get_json(silent=True) or {}
    try:
        result = execute_paper_candidates(
            payload.get('candidates', []),
            confirm_paper_execution=payload.get('confirm_paper_execution', False))
        return jsonify(result), 200
    except ValueError as exc:
        return jsonify({'error': str(exc), 'creates_orders': False,
                        'real_orders_enabled': False}), 400
    except Exception:
        app.logger.exception('paper decision execution failed')
        return jsonify({'error': 'paper decision execution failed', 'creates_orders': False,
                        'real_orders_enabled': False}), 500


@app.route('/api/paper-live/lifecycle/monitor', methods=['GET'])
def paper_live_lifecycle_monitor():
    """Refresh local paper positions; existing manager applies simulated brackets."""
    blocked = _paper_ledger_lease_guard()
    if blocked is not None:
        return blocked
    from backend.paper_live import get_state
    try:
        state = get_state(refresh_quotes=True, sync_funding=True)
        positions = state.get('positions', state.get('open_positions', []))
        return jsonify({'version': APP_VERSION, 'state': state,
                        'paper_only': True, 'capital_usdt': 1000,
                        'real_orders_enabled': False, 'creates_orders': False})
    except Exception:
        app.logger.exception('paper lifecycle monitor failed')
        return jsonify({'error': 'paper lifecycle monitor failed',
                        'real_orders_enabled': False, 'creates_orders': False}), 502


@app.route('/api/brain/historical-pattern-match', methods=['GET'])
def brain_historical_pattern_match():
    """Compare latest closed-candle context with read-only mined history."""
    from backend.historical_pattern_matcher import match_current_to_history
    try:
        result = match_current_to_history(
            symbol=request.args.get('symbol') or None,
            timeframe=request.args.get('timeframe', '1h'),
            threshold_pct=float(request.args.get('threshold_pct', 10.0)),
            horizon_bars=int(request.args.get('horizon_bars', 24)),
            lookback=int(request.args.get('lookback', 24)),
            max_candles=min(250000, max(100, int(request.args.get('max_candles', 250000)))),
            min_samples=int(request.args.get('min_samples', 5)))
        return jsonify(result)
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        app.logger.exception('historical_pattern_match_failed')
        return jsonify({'error':'مقایسه الگوهای تاریخی ناموفق بود','detail':str(exc)[:180]}), 500
