"""V23.0.13 AutoPilot — durable entries, portfolio risk, ATR net-R/R and funding reconciliation.

هوش معامله‌گر خودکار: سیگنال‌گیری → بازکردن خودکار → مدیریت موقعیت
(trailing/حدضرر/حدسود) → بستن خودکار → گزارش فارسی دوره‌ای.

SAFETY MODEL (unchanged from V22):
- Paper execution only. Fills and PnL are simulated locally in
  paper_live.sqlite3 while prices come from public exchange REST tickers.
- This module NEVER submits real exchange orders, never reads private
  balances and never needs API keys. `real_orders_enabled` stays False.
- Risk rails (max positions, per-trade sizing, daily loss stop, drawdown
  stop) are enforced inside paper_live.open_position with per-trade
  overrides provided by this module.
"""
from __future__ import annotations

import json
import math
import os
import sqlite3
import tempfile
import threading
import time
import traceback
import uuid
from functools import wraps
from collections import deque
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from backend.data import SESSION, fetch_candles
from backend.indicators import atr, ema, rsi
from backend.trade_contract import TRAIL_TRIGGER_PCT, TRAIL_DISTANCE_PCT

VERSION = "autopilot-v1.11-lifecycle-singleton"

# --------------------------------------------------------------------------
# Paths (same directory family as the models / paper-live DB)
# --------------------------------------------------------------------------
def _models_dir() -> Path:
    env_dir = os.environ.get("TRADING_AI_MODELS_DIR")
    base = Path(env_dir) if env_dir else Path.home() / ".trading_ai_models"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _db_path() -> Path:
    env = os.environ.get("TRADING_AI_PAPER_LIVE_DB")
    return Path(env) if env else _models_dir() / "paper_live.sqlite3"


def _config_path() -> Path:
    return _models_dir() / "autopilot_config.json"


def _log_path() -> Path:
    return _models_dir() / "autopilot_log.jsonl"


# --------------------------------------------------------------------------
# Default configuration (balanced preset chosen by the operator)
# --------------------------------------------------------------------------
LEGACY_RISK_PRESETS: dict[str, dict[str, float]] = {
    "conservative": {"max_open_positions": 3, "max_position_notional_pct": 5.0,
        "risk_per_trade_pct": 0.5, "stop_loss_pct": 1.0, "take_profit_pct": 2.0,
        "max_portfolio_risk_pct": 1.0, "max_spot_risk_pct": 0.75,
        "max_perp_risk_pct": 0.5, "max_directional_risk_pct": 0.75,
        "max_daily_loss_pct": 3.0, "max_drawdown_pct": 10.0},
    "balanced": {"max_open_positions": 5, "max_position_notional_pct": 10.0,
        "risk_per_trade_pct": 1.0, "stop_loss_pct": 1.5, "take_profit_pct": 3.0,
        "max_portfolio_risk_pct": 2.0, "max_spot_risk_pct": 1.5,
        "max_perp_risk_pct": 1.0, "max_directional_risk_pct": 1.5,
        "max_daily_loss_pct": 3.0, "max_drawdown_pct": 10.0},
    "assertive": {"max_open_positions": 8, "max_position_notional_pct": 20.0,
        "risk_per_trade_pct": 1.5, "stop_loss_pct": 2.0, "take_profit_pct": 4.0,
        "max_portfolio_risk_pct": 3.0, "max_spot_risk_pct": 2.0,
        "max_perp_risk_pct": 1.5, "max_directional_risk_pct": 2.0,
        "max_daily_loss_pct": 3.0, "max_drawdown_pct": 10.0},
}

RISK_PRESETS: dict[str, dict[str, Any]] = {
    # These profiles are deliberately bounded. AutoPilot-originated trades use
    # the shared ATR trade contract; percentage stops below remain a fallback
    # for manual paper entries and are not a second, competing ATR contract.
    "conservative": {
        "max_open_positions": 2, "max_position_notional_pct": 8.0,
        "risk_per_trade_pct": 0.25, "stop_loss_pct": 1.5, "take_profit_pct": 3.0,
        "max_daily_loss_pct": 1.0, "max_drawdown_pct": 5.0,
        "max_portfolio_risk_pct": 0.75, "max_spot_risk_pct": 0.75,
        "max_perp_risk_pct": 0.25, "max_directional_risk_pct": 0.50,
        "markets": ["spot"], "max_symbols": 5,
        "min_signal_confidence": 0.65, "cooldown_after_loss_minutes": 90,
    },
    "balanced": {
        "max_open_positions": 3, "max_position_notional_pct": 10.0,
        "risk_per_trade_pct": 0.50, "stop_loss_pct": 1.5, "take_profit_pct": 3.0,
        "max_daily_loss_pct": 1.5, "max_drawdown_pct": 7.5,
        "max_portfolio_risk_pct": 1.0, "max_spot_risk_pct": 1.0,
        "max_perp_risk_pct": 0.50, "max_directional_risk_pct": 0.75,
        "markets": ["spot"], "max_symbols": 8,
        "min_signal_confidence": 0.62, "cooldown_after_loss_minutes": 60,
    },
    "assertive": {
        "max_open_positions": 4, "max_position_notional_pct": 15.0,
        "risk_per_trade_pct": 0.75, "stop_loss_pct": 1.5, "take_profit_pct": 3.0,
        "max_daily_loss_pct": 2.0, "max_drawdown_pct": 10.0,
        "max_portfolio_risk_pct": 1.5, "max_spot_risk_pct": 1.0,
        "max_perp_risk_pct": 0.50, "max_directional_risk_pct": 1.0,
        "markets": ["spot", "perp"], "max_symbols": 10,
        "min_signal_confidence": 0.58, "cooldown_after_loss_minutes": 45,
    },
}

DEFAULT_CONFIG: dict[str, Any] = {
    "enabled": True,                # manager service should start with the server
    "entries_enabled": True,        # independent permission to open new paper positions
    "brain_mode": "hybrid",         # hybrid | ml_only | tech_only
    "timeframe": "1h",
    "markets": ["spot"],
    "max_symbols": 8,               # top-N 24h USDT volume pairs
    "risk_preset": "balanced",      # conservative | balanced | assertive | custom
    # Persisted risk controls. These keys must live in DEFAULT_CONFIG so that
    # UI edits survive validation and process restarts.
    "max_open_positions": 3,
    "max_position_notional_pct": 10.0,
    "risk_per_trade_pct": 0.5,
    "stop_loss_pct": 1.5,
    "take_profit_pct": 3.0,
    "max_daily_loss_pct": 1.5,
    "max_drawdown_pct": 7.5,
    # Aggregate account risk budgets, calculated from estimated loss at stops.
    "max_portfolio_risk_pct": 1.0,
    "max_spot_risk_pct": 1.0,
    "max_perp_risk_pct": 0.5,
    "max_directional_risk_pct": 0.75,
    "trailing_enabled": True,
    "trail_trigger_pct": TRAIL_TRIGGER_PCT,       # start trailing after this unrealized gain %
    "trail_distance_pct": TRAIL_DISTANCE_PCT,      # keep stop this % away from the best price
    "min_signal_confidence": 0.62,  # tech score / ML prob gate
    "cooldown_after_loss_minutes": 60,
    "manage_interval_seconds": 30,
    "entry_scan_interval_seconds": 300,
    "daily_report_enabled": True,
    "analysis_limit": 420,          # candles per technical scan (>=210)
    "signal_threshold": 0.60,       # ML threshold handed to _run_analysis
    "daily_start_balance": 1000.0,  # reporting base, mirrors paper account
    # Portfolio selection and diversification. These defaults are deliberately
    # conservative; UI may expose them in a later stage.
    "diversification_enabled": True,
    "max_positions_per_base": 1,
    "correlation_threshold": 0.82,
    "correlation_lookback": 60,
}

_RISK_KEYS = ("max_open_positions", "max_position_notional_pct", "risk_per_trade_pct",
              "stop_loss_pct", "take_profit_pct", "max_daily_loss_pct", "max_drawdown_pct",
              "max_portfolio_risk_pct", "max_spot_risk_pct", "max_perp_risk_pct",
              "max_directional_risk_pct")

_FALLBACK_SYMBOLS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "BNBUSDT",
                     "DOGEUSDT", "ADAUSDT", "LINKUSDT", "AVAXUSDT", "LTCUSDT"]
# Stable-to-stable and pegged pairs must never be trend-traded.
_STABLE_BASES = {"USDC", "FDUSD", "TUSD", "BUSD", "DAI", "EUR", "USDP", "AEUR",
                 "USD1", "RLUSD", "USDN", "USDD", "PYUSD", "GUSD", "USDE", "USDS",
                 "USDF", "EURI", "XUSD", "USDX", "USTC", "FRAX", "SUSD", "ALUSD"}
# Binance xStocks (tokenized equities) observed as high-volume spot pairs.
_STOCK_BASES = {"NVDAB", "TSLAB", "AAPLB", "MSTRB", "GOOGLB", "AMZNB", "METAB",
                "MSFTB", "ORCLB", "AVGOB", "COINB", "HOODB", "CRCLB", "SOXLB",
                "SPYB", "GLDB", "QQQB", "APPB", "TLNB", "SHOPB", "NFLXB"}
_LEVERAGED_SUFFIXES = ("UPUSDT", "DOWNUSDT", "BULLUSDT", "BEARUSDT")


def _is_excluded_base(base: str) -> bool:
    b = str(base).upper().strip()
    return (b in _STABLE_BASES or b in _STOCK_BASES or b.startswith("USD") or b.endswith("USD")
            or b.endswith(_LEVERAGED_SUFFIXES))

BRAIN_LABELS = {"ml": "مدل ML پروژه", "ml_pool": "رأی‌گیری مدل‌ها", "tech": "استراتژی تکنیکال", "hybrid": "توافق ML + تکنیکال"}
EXIT_LABELS = {"STOP_LOSS": "حدضرر", "TAKE_PROFIT": "حدسود", "MANUAL": "دستی",
               "TRAIL_STOP": "حدضرر متحرک", "SIGNAL_FLIP": "برگشت سیگنال"}


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _day_key(ts: float | None = None) -> str:
    return datetime.fromtimestamp(ts if ts is not None else time.time()).astimezone().strftime("%Y-%m-%d")


# --------------------------------------------------------------------------
# Mutable runtime state (guarded by _LOCK)
# --------------------------------------------------------------------------
_LOCK = threading.RLock()
# Serializes lifecycle transitions (start/stop/worker creation). Without this,
# two Flask request threads could both observe an unstarted Thread object and
# install competing scanner/manager workers before either calls Thread.start().
_LIFECYCLE_LOCK = threading.RLock()


def _lifecycle_serialized(fn):
    @wraps(fn)
    def _wrapped(*args, **kwargs):
        with _LIFECYCLE_LOCK:
            return fn(*args, **kwargs)
    return _wrapped


# Serializes the final permission check with a paper-entry request. A stop
# request waits for an in-flight open to finish, then guarantees no later open.
_ENTRY_EXEC_LOCK = threading.Lock()
_MANAGER_CYCLE_LOCK = threading.Lock()
_ENTRY_SCAN_LOCK = threading.Lock()
# Serializes synchronous UI/debug cycles against one another. Lifecycle lock
# additionally prevents start/stop transitions while a manual cycle is active.
_MANUAL_CYCLE_LOCK = threading.Lock()
_RUNTIME_PERSIST_LOCK = threading.RLock()
_RUNTIME_STATE_SCHEMA = 1
_PROCESS_LEASE_TOKEN: str | None = None


def _authorized_paper_writer(func):
    """Mark only trusted AutoPilot worker/lifecycle calls as ledger writers."""
    @wraps(func)
    def wrapped(*args, **kwargs):
        from backend import paper_live
        with paper_live.authorized_paper_writer():
            return func(*args, **kwargs)
    return wrapped
_PROCESS_LEASE_TTL_SECONDS = 60
_STATE: dict[str, Any] = {
    "running": False,             # backward-compatible alias for entries_enabled
    "thread": None,               # backward-compatible alias for entry_thread
    "stop_event": threading.Event(),
    "entry_thread": None,
    "manager_thread": None,
    "entry_stop_event": threading.Event(),
    "manager_stop_event": threading.Event(),
    "entries_enabled": False,
    "managing": False,
    "stop_after_flat": False,
    "started_at": None,
    "last_manage_at": 0.0,
    "last_entry_scan_at": 0.0,
    "last_cycle_error": "",
    "last_manage_error": "",
    "last_entry_error": "",
    "cycles": 0,
    "manage_cycles": 0,
    "entry_cycles": 0,
    "decisions": deque(maxlen=500),
    "trail_meta": {},        # trade_id -> {"peak_price": float}
    "cooldowns": {},         # "SYMBOL|market" -> until epoch
    "candle_seen": {},       # "SYMBOL|market|timeframe" -> last candle open ts processed
    "watchlist": [],         # [{"symbol": "BTCUSDT", "volume": 1e9}]
    "watchlist_at": 0.0,
    "watchlist_source": "fallback",
    "daily_reports_done": set(),
    "last_report_kind": None,
    "last_closed_check_ts": 0.0,
    "last_entry_summary": {},
    "runtime_state_loaded": False,
    "runtime_state_saved_at": 0.0,
    "runtime_state_error": "",
}
_CONFIG: dict[str, Any] = dict(DEFAULT_CONFIG)


def _runtime_state_db() -> Path:
    """Durable runtime checkpoint DB; kept separate from paper trade history."""
    return _models_dir() / "autopilot_runtime.sqlite3"


def _init_runtime_state_db() -> None:
    path = _runtime_state_db()
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path, timeout=15) as conn:
        conn.execute("PRAGMA busy_timeout=15000")
        conn.execute("""CREATE TABLE IF NOT EXISTS runtime_state (
            state_key TEXT PRIMARY KEY,
            schema_version INTEGER NOT NULL,
            value_json TEXT NOT NULL,
            updated_at REAL NOT NULL
        )""")
        conn.commit()


def _runtime_state_payload_locked() -> dict[str, Any]:
    """Build a JSON-safe snapshot. Caller must hold _LOCK."""
    now = time.time()
    cooldowns: dict[str, float] = {}
    for key, raw_value in (_STATE.get("cooldowns") or {}).items():
        try:
            value = float(raw_value)
            if isinstance(key, str) and len(key) <= 80 and math.isfinite(value) and value > now:
                cooldowns[key] = value
        except (TypeError, ValueError):
            continue
    candle_seen: dict[str, float] = {}
    for key, raw_value in (_STATE.get("candle_seen") or {}).items():
        try:
            value = float(raw_value)
            if isinstance(key, str) and len(key) <= 100 and math.isfinite(value) and value > 0:
                candle_seen[key] = value
        except (TypeError, ValueError):
            continue
    watchlist = []
    for item in (_STATE.get("watchlist") or [])[:100]:
        if not isinstance(item, dict):
            continue
        symbol = str(item.get("symbol") or "").upper().strip()
        try:
            volume = max(0.0, float(item.get("volume") or 0.0))
        except (TypeError, ValueError):
            continue
        if symbol and len(symbol) <= 32 and math.isfinite(volume):
            watchlist.append({"symbol": symbol, "volume": volume})
    summary = _STATE.get("last_entry_summary") or {}
    if not isinstance(summary, dict):
        summary = {}
    # Persist only the latest bounded shortlist, not arbitrary runtime objects.
    summary = dict(summary)
    summary["ranked"] = [x for x in (summary.get("ranked") or [])[:60] if isinstance(x, dict)]
    daily_done = sorted(str(x) for x in (_STATE.get("daily_reports_done") or set()))[-90:]
    return {
        "schema_version": _RUNTIME_STATE_SCHEMA,
        "saved_at": now,
        "cooldowns": cooldowns,
        "candle_seen": candle_seen,
        "watchlist": watchlist,
        "watchlist_at": float(_STATE.get("watchlist_at") or 0.0),
        "watchlist_source": str(_STATE.get("watchlist_source") or "fallback")[:40],
        "last_entry_scan_at": float(_STATE.get("last_entry_scan_at") or 0.0),
        "last_entry_summary": summary,
        "last_closed_check_ts": float(_STATE.get("last_closed_check_ts") or 0.0),
        "daily_reports_done": daily_done,
        "cycles": int(_STATE.get("cycles") or 0),
        "manage_cycles": int(_STATE.get("manage_cycles") or 0),
        "entry_cycles": int(_STATE.get("entry_cycles") or 0),
    }


def _persist_runtime_state() -> bool:
    """Atomically checkpoint restart-sensitive scanner/manager state.

    A checkpoint failure is visible to callers. Entry code uses this as a
    fail-closed barrier before it can open a simulated position.
    """
    try:
        with _RUNTIME_PERSIST_LOCK:
            with _LOCK:
                payload = _runtime_state_payload_locked()
            encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
            path = _runtime_state_db()
            path.parent.mkdir(parents=True, exist_ok=True)
            with sqlite3.connect(path, timeout=15) as conn:
                conn.execute("PRAGMA busy_timeout=15000")
                conn.execute("""CREATE TABLE IF NOT EXISTS runtime_state (
                    state_key TEXT PRIMARY KEY,
                    schema_version INTEGER NOT NULL,
                    value_json TEXT NOT NULL,
                    updated_at REAL NOT NULL
                )""")
                conn.execute("""INSERT INTO runtime_state(state_key,schema_version,value_json,updated_at)
                    VALUES('autopilot',?,?,?)
                    ON CONFLICT(state_key) DO UPDATE SET
                        schema_version=excluded.schema_version,
                        value_json=excluded.value_json,
                        updated_at=excluded.updated_at""",
                    (_RUNTIME_STATE_SCHEMA, encoded, payload["saved_at"]))
                conn.commit()
            with _LOCK:
                _STATE["runtime_state_saved_at"] = payload["saved_at"]
                _STATE["runtime_state_error"] = ""
        return True
    except Exception as exc:
        with _LOCK:
            _STATE["runtime_state_error"] = str(exc)[:300]
        return False


def _load_runtime_state() -> bool:
    """Restore bounded runtime checkpoints; never auto-resume entry workers."""
    try:
        path = _runtime_state_db()
        if not path.exists():
            _init_runtime_state_db()
            with _LOCK:
                _STATE["runtime_state_loaded"] = True
            return True
        with sqlite3.connect(path, timeout=15) as conn:
            row = conn.execute("SELECT schema_version,value_json,updated_at FROM runtime_state WHERE state_key='autopilot'").fetchone()
        if not row:
            with _LOCK:
                _STATE["runtime_state_loaded"] = True
            return True
        schema_version, raw, updated_at = row
        if int(schema_version) > _RUNTIME_STATE_SCHEMA:
            raise ValueError("نسخهٔ دیتابیس وضعیت از نسخهٔ برنامه جدیدتر است")
        payload = json.loads(raw)
        if not isinstance(payload, dict):
            raise ValueError("ساختار وضعیت ذخیره‌شده معتبر نیست")
        now = time.time()
        timeframe = str(_CONFIG.get("timeframe", "1h"))
        cooldowns = {}
        for key, value in (payload.get("cooldowns") or {}).items():
            try:
                expiry = float(value)
                if isinstance(key, str) and len(key) <= 80 and math.isfinite(expiry) and expiry > now:
                    cooldowns[key] = expiry
            except (TypeError, ValueError):
                continue
        candle_seen = {}
        for key, value in (payload.get("candle_seen") or {}).items():
            try:
                ts = float(value)
                if not isinstance(key, str) or not math.isfinite(ts) or ts <= 0:
                    continue
                # Migrate V23.0.6 keys (SYMBOL|market) to timeframe-scoped keys.
                parts = key.split("|")
                if len(parts) == 2:
                    key = f"{parts[0]}|{parts[1]}|{timeframe}"
                if len(key) <= 100:
                    candle_seen[key] = max(candle_seen.get(key, 0.0), ts)
            except (TypeError, ValueError):
                continue
        watchlist = []
        for item in (payload.get("watchlist") or [])[:100]:
            if not isinstance(item, dict):
                continue
            symbol = str(item.get("symbol") or "").upper().strip()
            try:
                volume = max(0.0, float(item.get("volume") or 0.0))
            except (TypeError, ValueError):
                continue
            if symbol and len(symbol) <= 32 and math.isfinite(volume):
                watchlist.append({"symbol": symbol, "volume": volume})
        watchlist_at = float(payload.get("watchlist_at") or 0.0)
        if not math.isfinite(watchlist_at) or watchlist_at > now + 300:
            watchlist_at = 0.0
        summary = payload.get("last_entry_summary") or {}
        if not isinstance(summary, dict):
            summary = {}
        summary = dict(summary)
        summary["ranked"] = [x for x in (summary.get("ranked") or [])[:60] if isinstance(x, dict)]
        done = set(str(x) for x in (payload.get("daily_reports_done") or [])[-90:])
        with _LOCK:
            _STATE.update({
                "cooldowns": cooldowns,
                "candle_seen": candle_seen,
                "watchlist": watchlist,
                "watchlist_at": watchlist_at,
                "watchlist_source": str(payload.get("watchlist_source") or "fallback")[:40],
                "last_entry_scan_at": max(0.0, float(payload.get("last_entry_scan_at") or 0.0)),
                "last_entry_summary": summary,
                "last_closed_check_ts": max(0.0, float(payload.get("last_closed_check_ts") or 0.0)),
                "daily_reports_done": done,
                "cycles": max(0, int(payload.get("cycles") or 0)),
                "manage_cycles": max(0, int(payload.get("manage_cycles") or 0)),
                "entry_cycles": max(0, int(payload.get("entry_cycles") or 0)),
                "runtime_state_loaded": True,
                "runtime_state_saved_at": float(updated_at or payload.get("saved_at") or 0.0),
                "runtime_state_error": "",
            })
        return True
    except Exception as exc:
        with _LOCK:
            _STATE["runtime_state_loaded"] = False
            _STATE["runtime_state_error"] = str(exc)[:300]
        return False


def _candle_seen_key(symbol: str, market: str, timeframe: str | None = None) -> str:
    return f"{str(symbol).upper()}|{str(market).lower()}|{timeframe or _CONFIG.get('timeframe', '1h')}"


_CANDLE_TIMEFRAME_SECONDS = {"1m": 60, "3m": 180, "5m": 300, "15m": 900,
                             "30m": 1800, "1h": 3600, "2h": 7200,
                             "4h": 14400, "6h": 21600, "12h": 43200,
                             "1d": 86400, "1w": 604800}

def _candle_gap_info(previous_ts: float, current_ts: float, timeframe: str) -> dict[str, Any]:
    """Describe missing closed-bar intervals without replaying stale signals."""
    step = _CANDLE_TIMEFRAME_SECONDS.get(str(timeframe).lower())
    try:
        previous, current = float(previous_ts), float(current_ts)
    except (TypeError, ValueError):
        return {"valid": False, "missing_bars": None, "reason": "invalid_timestamp"}
    if not step or not math.isfinite(previous) or not math.isfinite(current) or previous <= 0 or current <= 0:
        return {"valid": False, "missing_bars": None, "reason": "unsupported_timeframe_or_timestamp"}
    # Candle timestamps in the market data layer are Unix milliseconds.
    scale = 1000.0 if max(previous, current) >= 100_000_000_000 else 1.0
    delta_seconds = (current - previous) / scale
    if delta_seconds <= 0:
        return {"valid": False, "missing_bars": 0, "reason": "non_monotonic"}
    intervals = int(round(delta_seconds / step))
    aligned = abs(delta_seconds - intervals * step) <= max(1.0, step * 0.001)
    if not aligned:
        return {"valid": False, "missing_bars": None, "reason": "off_interval"}
    return {"valid": True, "missing_bars": max(0, intervals - 1), "reason": "gap" if intervals > 1 else "contiguous"}


def _entry_idempotency_key(symbol: str, market: str, timeframe: str, candle_ts: float) -> str:
    """Stable opportunity identity: one entry at most per closed candle/scope.

    Direction is intentionally excluded: a changed BUY/SELL decision for the
    same candle must not create a second opposing paper entry.
    """
    ts = float(candle_ts)
    if not math.isfinite(ts) or ts <= 0:
        raise ValueError("شناسهٔ کندل برای ساخت کلید ورود معتبر نیست")
    return (f"autopilot-v23:{str(symbol).upper()}:{str(market).lower()}:"
            f"{str(timeframe).lower()}:{int(ts)}")


def _mark_candle_seen(key: str, candle_ts: float) -> bool:
    """Durably record a candle before allowing any entry from that candle."""
    with _LOCK:
        current = float(_STATE["candle_seen"].get(key) or 0.0)
        if float(candle_ts) <= current:
            return True
        _STATE["candle_seen"][key] = float(candle_ts)
    return _persist_runtime_state()


def _clear_candle_seen(key: str) -> bool:
    with _LOCK:
        _STATE["candle_seen"].pop(key, None)
    return _persist_runtime_state()


def _config_value(key: str, value: Any) -> Any:
    """Validate/coerce one persisted or user-supplied setting."""
    if key not in DEFAULT_CONFIG:
        raise ValueError(f"تنظیم ناشناخته است: {key}")
    if key in ("enabled", "entries_enabled", "trailing_enabled", "daily_report_enabled", "diversification_enabled"):
        if not isinstance(value, bool):
            raise ValueError(f"مقدار {key} باید روشن/خاموش باشد")
        return value
    if key == "markets":
        if not isinstance(value, list):
            raise ValueError("بازارها باید به‌صورت فهرست ارسال شوند")
        markets = list(dict.fromkeys(str(x).lower() for x in value))
        if not markets or any(x not in ("spot", "perp") for x in markets):
            raise ValueError("حداقل یکی از بازارهای spot یا perp را انتخاب کن")
        return markets
    if key == "brain_mode":
        if value not in ("hybrid", "ml_only", "tech_only"):
            raise ValueError("حالت مغز نامعتبر است")
        return value
    if key == "risk_preset":
        if value not in (*RISK_PRESETS.keys(), "custom"):
            raise ValueError("پریست ریسک نامعتبر است")
        return value
    if key == "timeframe":
        if value not in ("5m", "15m", "30m", "1h", "4h", "1d"):
            raise ValueError("تایم‌فریم نامعتبر است")
        return value
    int_ranges = {
        "max_open_positions": (1, 10), "max_symbols": (1, 30),
        "analysis_limit": (210, 5000), "manage_interval_seconds": (10, 600),
        "entry_scan_interval_seconds": (60, 3600),
        "cooldown_after_loss_minutes": (0, 1440),
        "max_positions_per_base": (1, 2), "correlation_lookback": (24, 240),
    }
    if key in int_ranges:
        if isinstance(value, bool):
            raise ValueError(f"مقدار {key} باید عددی باشد")
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"مقدار {key} باید عدد صحیح باشد")
        low, high = int_ranges[key]
        if not math.isfinite(numeric) or not numeric.is_integer() or not low <= numeric <= high:
            raise ValueError(f"مقدار {key} باید بین {low} و {high} باشد")
        return int(numeric)
    float_ranges = {
        "max_position_notional_pct": (1.0, 100.0),
        "risk_per_trade_pct": (0.05, 5.0),
        "stop_loss_pct": (0.1, 20.0), "take_profit_pct": (0.1, 50.0),
        "max_daily_loss_pct": (0.1, 20.0), "max_drawdown_pct": (0.1, 50.0),
        "trail_trigger_pct": (0.05, 20.0), "trail_distance_pct": (0.05, 20.0),
        "min_signal_confidence": (0.51, 0.99), "signal_threshold": (0.51, 0.99),
        "daily_start_balance": (10.0, 1_000_000_000.0),
        "correlation_threshold": (0.60, 0.98),
        "max_portfolio_risk_pct": (0.25, 10.0),
        "max_spot_risk_pct": (0.25, 10.0),
        "max_perp_risk_pct": (0.25, 10.0),
        "max_directional_risk_pct": (0.25, 10.0),
    }
    if key in float_ranges:
        if isinstance(value, bool):
            raise ValueError(f"مقدار {key} باید عددی باشد")
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"مقدار {key} باید عددی باشد")
        low, high = float_ranges[key]
        if not math.isfinite(numeric) or not low <= numeric <= high:
            raise ValueError(f"مقدار {key} باید بین {low:g} و {high:g} باشد")
        return numeric
    return value


def _sync_paper_initial_balance(value: float | None = None) -> None:
    """Apply the persisted AutoPilot capital to the local PAPER ledger settings."""
    from backend import paper_live
    amount = float(_CONFIG.get("daily_start_balance", 1000.0) if value is None else value)
    if not math.isfinite(amount) or amount < 10.0:
        raise ValueError("سرمایهٔ آزمایشی باید حداقل ۱۰ USDT باشد")
    paper_live.SETTINGS["initial_balance"] = amount


def _load_config() -> None:
    """Load and migrate persisted settings without dropping risk controls."""
    global _CONFIG
    cfg = dict(DEFAULT_CONFIG)
    try:
        p = _config_path()
        if p.exists():
            stored = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(stored, dict):
                # Migrate older files: named preset values are restored first,
                # then any persisted explicit per-field overrides are applied.
                stored_preset = stored.get("risk_preset", "balanced")
                legacy_values = LEGACY_RISK_PRESETS.get(stored_preset)
                migrating_named_preset = bool(legacy_values) and all(
                    stored.get(key, legacy_value) == legacy_value
                    for key, legacy_value in legacy_values.items())
                if stored_preset in RISK_PRESETS:
                    cfg.update(RISK_PRESETS[stored_preset])
                for key, raw in stored.items():
                    if key not in DEFAULT_CONFIG:
                        continue
                    # A previously untouched named preset is upgraded to the
                    # safer V23.0.82 profile. Any user-customized legacy values
                    # are preserved and then correctly labeled Custom below.
                    if migrating_named_preset and key in RISK_PRESETS[stored_preset]:
                        continue
                    try:
                        cfg[key] = _config_value(key, raw)
                    except ValueError:
                        # Keep the selected preset's safe value when present;
                        # otherwise fall back to the global default.
                        cfg[key] = cfg.get(key, DEFAULT_CONFIG[key])
                risk_keys = tuple(RISK_PRESETS["balanced"].keys())
                if cfg.get("risk_preset") in RISK_PRESETS:
                    preset_values = RISK_PRESETS[cfg["risk_preset"]]
                    if any(cfg.get(k) != preset_values[k] for k in risk_keys):
                        cfg["risk_preset"] = "custom"
    except Exception:
        # A corrupt config file must not prevent the application from starting.
        cfg = dict(DEFAULT_CONFIG)
    _CONFIG = cfg
    # Synchronize before paper_live initializes its SQLite account baseline.
    _sync_paper_initial_balance(float(cfg.get("daily_start_balance", 1000.0)))


def _save_config(config: dict[str, Any] | None = None) -> None:
    """Atomically persist config; never silently claim success on write failure."""
    payload = dict(_CONFIG if config is None else config)
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_name = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", newline="\n",
                                         dir=str(path.parent), prefix=path.name + ".",
                                         suffix=".tmp", delete=False) as handle:
            tmp_name = handle.name
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, path)
    except Exception:
        if tmp_name:
            try:
                os.unlink(tmp_name)
            except OSError:
                pass
        raise


def _persist_log(entry: dict) -> None:
    try:
        with _log_path().open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _log_decision(action: str, *, phase: str = "entry", symbol: str = "", market: str = "",
                  detail: str = "", brain: str = "", confidence: float | None = None,
                  trade_id: int | None = None, level: str = "info") -> None:
    entry = {"ts": time.time(), "iso": _now_iso(), "phase": phase, "action": action,
             "symbol": symbol, "market": market, "detail": detail[:300],
             "brain": brain, "confidence": confidence, "trade_id": trade_id, "level": level}
    with _LOCK:
        _STATE["decisions"].append(entry)
    _persist_log(entry)


# --------------------------------------------------------------------------
# Watchlist: top 24h USDT-volume spot pairs from Binance + Bybit
# --------------------------------------------------------------------------
def _fetch_binance_top(limit: int) -> list[tuple[str, float]]:
    url = "https://data-api.binance.vision/api/v3/ticker/24hr"
    r = SESSION.get(url, timeout=(3, 8))
    r.raise_for_status()
    rows = r.json() if isinstance(r.json(), list) else []
    out: list[tuple[str, float]] = []
    for row in rows:
        sym = str(row.get("symbol", "")).upper()
        if not sym.endswith("USDT") or sym.endswith(_LEVERAGED_SUFFIXES):
            continue
        if _is_excluded_base(sym[:-4]):
            continue
        try:
            vol = float(row.get("quoteVolume") or 0.0)
        except (TypeError, ValueError):
            continue
        if vol > 0:
            out.append((sym, vol))
    out.sort(key=lambda x: x[1], reverse=True)
    return out[:limit]


def _fetch_bybit_top(limit: int) -> list[tuple[str, float]]:
    url = "https://api.bybit.com/v5/market/tickers?category=spot"
    r = SESSION.get(url, timeout=(3, 8))
    r.raise_for_status()
    rows = (((r.json() or {}).get("result") or {}).get("list")) or []
    out: list[tuple[str, float]] = []
    for row in rows:
        sym = str(row.get("symbol", "")).upper()
        if not sym.endswith("USDT") or sym.endswith(_LEVERAGED_SUFFIXES):
            continue
        if _is_excluded_base(sym[:-4]):
            continue
        try:
            vol = float(row.get("turnover24h") or 0.0)
        except (TypeError, ValueError):
            continue
        if vol > 0:
            out.append((sym, vol))
    out.sort(key=lambda x: x[1], reverse=True)
    return out[:limit]


def _perp_bases() -> set[str]:
    """Bases with USDT-margined perpetuals. Uses the intersection of Binance
    USDT-M futures and Bybit linear when both are reachable (drops tokenized
    stocks and one-off listings), otherwise whichever feed answers."""
    binance: set[str] = set()
    bybit: set[str] = set()
    try:
        r = SESSION.get("https://fapi.binance.com/fapi/v1/exchangeInfo", timeout=(3, 8))
        payload = r.json()
        binance = {str(s.get("symbol", "")).upper()
                   for s in (payload.get("symbols") or [])
                   if s.get("quoteAsset") == "USDT" and s.get("contractType") == "PERPETUAL"
                   and s.get("status") == "TRADING"}
    except Exception:
        pass
    try:
        r = SESSION.get("https://api.bybit.com/v5/market/tickers?category=linear", timeout=(3, 8))
        bybit = {str(t.get("symbol", "")).upper()
                 for t in ((r.json() or {}).get("result") or {}).get("list") or []}
    except Exception:
        pass
    if binance and bybit:
        return binance & bybit
    return binance or bybit


def refresh_watchlist(force: bool = False) -> dict:
    """Discover the top-N liquid USDT pairs; rank by Binance volume primarily."""
    with _LOCK:
        age_ok = (time.time() - _STATE["watchlist_at"]) < 6 * 3600
        if _STATE["watchlist"] and age_ok and not force:
            return _watchlist_view()
    limit = max(1, min(30, int(_CONFIG.get("max_symbols", 10))))
    ranked: dict[str, float] = {}
    source = "fallback"
    try:
        for sym, vol in _fetch_binance_top(limit * 2):
            ranked[sym] = vol
        source = "binance"
        try:
            bybit_syms = {sym for sym, _ in _fetch_bybit_top(limit * 2)}
            if ranked:
                # Keep pairs liquid on Binance; prefer ones confirmed by Bybit too,
                # then fill the rest by Binance volume ranking.
                confirmed = [s for s in ranked if s in bybit_syms]
                others = [s for s in ranked if s not in bybit_syms]
                ordered = sorted(confirmed, key=lambda s: ranked[s], reverse=True) + \
                          sorted(others, key=lambda s: ranked[s], reverse=True)
                ranked = {s: ranked[s] for s in ordered}
            source = "binance+bybit"
        except Exception:
            pass
        symbols = [s for s, _ in sorted(ranked.items(), key=lambda x: x[1], reverse=True)][:limit]
        # Prefer majors that also trade as USDT-M perpetuals (consistent spot+perp
        # coverage and automatically drops tokenized-stock one-offs).
        perp_bases = _perp_bases()
        if perp_bases and ranked:
            ordered = [s for s in symbols if s in perp_bases]
            ordered += [s for s in symbols if s not in perp_bases]
            symbols = ordered[:limit]
    except Exception as exc:
        _log_decision("WATCHLIST_FALLBACK", phase="system",
                      detail=f"دریافت لیست حجم ناموفق بود ({exc}); از لیست ثابت استفاده شد", level="warn")
        symbols = list(_FALLBACK_SYMBOLS)[:limit]
        source = "fallback"
    if not symbols:
        symbols = list(_FALLBACK_SYMBOLS)[:limit]
        source = "fallback"
    watchlist = [{"symbol": s, "volume": round(float(ranked.get(s, 0.0)), 0)} for s in symbols]
    with _LOCK:
        _STATE["watchlist"] = watchlist
        _STATE["watchlist_at"] = time.time()
        _STATE["watchlist_source"] = source
    _persist_runtime_state()
    _log_decision("WATCHLIST_UPDATED", phase="system",
                  detail=f"نمادها به‌روزرسانی شد ({source}): " + "، ".join(symbols))
    return _watchlist_view()


def _watchlist_view() -> dict:
    with _LOCK:
        return {"symbols": [x["symbol"] for x in _STATE["watchlist"]],
                "detail": list(_STATE["watchlist"]), "source": _STATE["watchlist_source"],
                "updated_at": _STATE["watchlist_at"],
                "age_seconds": time.time() - _STATE["watchlist_at"] if _STATE["watchlist_at"] else None}


# --------------------------------------------------------------------------
# Brains
# --------------------------------------------------------------------------
def _analysis_symbol(base: str, market: str) -> str:
    return base if market == "spot" else f"{base}PERP"


def _ml_signal(base: str, market: str, timeframe: str) -> dict | None:
    """Return a market-scoped ML decision.

    `None` means no trained model exists for this exact market scope, so the
    hybrid brain may use its explicitly documented technical-only fallback.
    A structured UNAVAILABLE result means a model exists but its pipeline
    failed; in that case hybrid must HOLD rather than silently bypass ML.
    Spot models are never borrowed for perpetual/futures decisions.
    """
    sym = _analysis_symbol(base, market)
    try:
        from backend.api import _run_analysis  # lazy: avoid circular import
        from backend.storage import model_path

        # A model is eligible only for the exact symbol + market scope.
        if not model_path(sym, timeframe).exists():
            return None

        result, status = _run_analysis(sym, timeframe, "auto",
                                       int(_CONFIG.get("analysis_limit", 420)),
                                       float(_CONFIG.get("signal_threshold", 0.60)),
                                       "balanced")
        if status != 200 or not isinstance(result, dict) or result.get("error"):
            reason = str((result or {}).get("error") or f"HTTP {status}")
            _log_decision("ML_BRAIN_UNAVAILABLE", phase="entry", symbol=base, market=market,
                          detail=f"مدل اختصاصی موجود است اما تحلیل ML ناموفق بود: {reason}", level="warn")
            return {"kind": "UNAVAILABLE", "brain": "ml", "confidence": None,
                    "edge_confirmed": False, "model_symbol": sym,
                    "detail": f"خطای پایپلاین مدل {sym}: {reason}"}

        sig = result.get("signal") or {}
        kind = str(sig.get("kind") or "HOLD").upper()
        prob = sig.get("prob")
        conf = max(float(prob), 1.0 - float(prob)) if isinstance(prob, (int, float)) else None
        used_pool = bool(result.get("pool") or (not result.get("has_model")))
        detail = f"prob={prob} · مدل اختصاصی {sym}"
        meta = result.get("model_meta") or {}
        # Missing/unknown edge status is fail-closed; do not invent approval.
        edge_confirmed = bool(meta.get("edge_confirmed", False))
        indicator_snapshot = result.get("indicators") if isinstance(result.get("indicators"), dict) else {}
        indicator_snapshot = {
            str(k): float(v) for k, v in list(indicator_snapshot.items())[:48]
            if isinstance(v, (int, float)) and math.isfinite(float(v))
        }
        model_snapshot = {
            key: meta.get(key) for key in (
                "feature_schema_version", "experiment_id", "data_hash", "test_start_ts",
                "walk_forward_acc", "edge_confirmed", "training_round", "training_protocol_version"
            ) if meta.get(key) is not None
        }
        data_quality = result.get("data_quality") if isinstance(result.get("data_quality"), dict) else {}
        quality_snapshot = {
            key: data_quality.get(key) for key in (
                "status", "source", "row_count_valid", "gap_count", "max_gap_bars", "warnings"
            ) if data_quality.get(key) is not None
        }
        pool = result.get("model_pool") if isinstance(result.get("model_pool"), dict) else {}
        pool_snapshot = {
            key: pool.get(key) for key in ("n", "consensus_prob", "consensus_dir", "agreement", "same_symbol_votes", "same_tf_votes")
            if pool.get(key) is not None
        }
        latest_features = result.get("latest_features") if isinstance(result.get("latest_features"), dict) else {}
        feature_snapshot = {
            str(k): float(v) for k, v in list(latest_features.items())[:256]
            if isinstance(v, (int, float)) and math.isfinite(float(v))
        }
        used_feature_names = result.get("model_feature_names") if isinstance(result.get("model_feature_names"), list) else []
        return {"kind": kind, "prob": prob, "confidence": conf,
                "brain": "ml_pool" if used_pool else "ml",
                "power": sig.get("power"), "candle_ts": _last_candle_ts(sym, timeframe),
                "detail": detail, "edge_confirmed": edge_confirmed,
                "model_symbol": sym,
                "ml_snapshot": {"prob": prob, "primary_prob": result.get("primary_prob"),
                                "indicators": indicator_snapshot, "features": feature_snapshot,
                                "model_feature_names": [str(x)[:100] for x in used_feature_names[:256]],
                                "model": model_snapshot,
                                "data_quality": quality_snapshot, "pool": pool_snapshot}}
    except Exception as exc:
        _log_decision("ML_BRAIN_SKIP", phase="entry", symbol=base, market=market,
                      detail=f"مدل اختصاصی موجود است اما مغز ML در دسترس نبود: {exc}", level="warn")
        # The exact-scope model was expected to be used. Returning an explicit
        # unavailable state prevents hybrid from silently switching to tech.
        try:
            from backend.storage import model_path
            exists = model_path(sym, timeframe).exists()
        except Exception:
            exists = False
        if exists:
            return {"kind": "UNAVAILABLE", "brain": "ml", "confidence": None,
                    "edge_confirmed": False, "model_symbol": sym,
                    "detail": f"خطای اجرای مدل {sym}: {exc}"}
        return None


def _last_candle_ts(sym: str, timeframe: str) -> float | None:
    try:
        df = fetch_candles(sym, timeframe, limit=220, source="auto",
                           validation_mode="paper", max_age_bars=3)
        return float(df["t"].iloc[-1])
    except Exception:
        return None


def _tech_signal(base: str, market: str, timeframe: str) -> dict | None:
    """Self-contained trend strategy: EMA21/55 + MACD-hist + RSI + momentum.

    Works on every symbol without a trained model so the autopilot is never
    blind; deterministic and fully explainable.
    """
    try:
        sym = _analysis_symbol(base, market)
        df = fetch_candles(sym, timeframe, limit=max(210, int(_CONFIG.get("analysis_limit", 420))),
                           source="auto", validation_mode="paper", max_age_bars=3)
        if len(df) < 120:
            return None
        close, high, low = df["close"], df["high"], df["low"]
        ema_fast = ema(close, 21)
        ema_slow = ema(close, 55)
        rsi14 = rsi(close, 14)
        atr14 = atr(high, low, close, 14)
        c = float(close.iloc[-1])
        f, s = float(ema_fast.iloc[-1]), float(ema_slow.iloc[-1])
        r = float(rsi14.iloc[-1])
        a = float(atr14.iloc[-1])
        mom = (c / float(close.iloc[-13]) - 1.0) * 100.0 if len(close) > 13 else 0.0

        # MACD histogram (12/26 + 9 signal)
        ema12, ema26 = ema(close, 12), ema(close, 26)
        macd_line = ema12 - ema26
        macd_sig = macd_line.ewm(span=9, adjust=False).mean()
        hist = float((macd_line - macd_sig).iloc[-1])

        atr_pct = a / c * 100.0 if c else 0.0
        score = 0.0
        trend_up = f > s and c > f
        trend_dn = f < s and c < f
        if trend_up:
            score += 0.35
        elif trend_dn:
            score += 0.35
        # MACD histogram must CONFIRM the trend direction.
        if trend_up and hist > 0:
            score += 0.2
        elif trend_dn and hist < 0:
            score += 0.2
        if 50 <= r < 75 and trend_up:
            score += 0.25
        elif 25 < r <= 50 and trend_dn:
            score += 0.25
        elif r >= 78:
            score -= 0.15          # exhaustion: stretched against continuation
        elif r <= 22 and trend_up:
            score -= 0.15
        if mom > 0 and trend_up:
            score += 0.2
        elif mom < 0 and trend_dn:
            score += 0.2
        score = max(0.0, min(1.0, score))
        kind = "HOLD"
        if trend_up and score >= float(_CONFIG.get("min_signal_confidence", 0.55)):
            kind = "BUY"
        elif trend_dn and score >= float(_CONFIG.get("min_signal_confidence", 0.55)):
            kind = "SELL"
        feature_snapshot = {
            "candle_ts": float(df["t"].iloc[-1]),
            "close": c, "ema_21": f, "ema_55": s, "rsi_14": r, "atr_14": a,
            "atr_pct": atr_pct, "macd_hist": hist, "momentum_12_pct": mom,
            "trend_up": bool(trend_up), "trend_down": bool(trend_dn), "score": score,
        }
        return {"kind": kind, "confidence": score, "brain": "tech",
                "candle_ts": float(df["t"].iloc[-1]),
                "detail": (f"EMA21/55={'بالا' if trend_up else ('پایین' if trend_dn else 'خنثی')} · "
                           f"RSI={r:.1f} · MACD_hist={hist:.4f} · ATR%={atr_pct:.2f} · مومنتوم={mom:+.2f}٪"),
                "atr_pct": atr_pct, "price": c, "feature_snapshot": feature_snapshot}
    except Exception as exc:
        _log_decision("TECH_BRAIN_SKIP", phase="entry", symbol=base, market=market,
                      detail=f"اسکن تکنیکال ناموفق: {exc}", level="warn")
        return None


def _decide_entry_raw(base: str, market: str) -> dict:
    """Fail-closed decision policy for one (symbol, market) scope.

    - tech_only: technical brain decides directly.
    - ml_only: exact-market ML model must emit an edge-confirmed direction.
    - hybrid: when an exact-market ML model exists, ML and technical brains
      must agree on direction and both clear the confidence threshold. A real
      ML HOLD / weak edge / pipeline error cannot be bypassed by technical.
      If no exact-market model exists, a clearly labelled technical-only
      fallback is allowed (never a spot model borrowed for perpetuals).
    """
    mode = str(_CONFIG.get("brain_mode", "hybrid"))
    tf = str(_CONFIG.get("timeframe", "1h"))
    min_conf = float(_CONFIG.get("min_signal_confidence", 0.55))

    if mode == "tech_only":
        tech = _tech_signal(base, market, tf)
        if tech and tech.get("kind") in ("BUY", "SELL") and float(tech.get("confidence") or 0) >= min_conf:
            return tech
        return {"kind": "HOLD", "brain": "tech", "confidence": (tech or {}).get("confidence"),
                "detail": (tech or {}).get("detail") or "استراتژی تکنیکال ورود را تأیید نکرد"}

    ml = _ml_signal(base, market, tf)
    if ml is None:
        if mode == "ml_only":
            return {"kind": "HOLD", "brain": "ml", "confidence": None,
                    "detail": f"مدل اختصاصی { _analysis_symbol(base, market) } برای این بازار و تایم‌فریم موجود نیست"}
        # Explicitly model-less scope: technical-only fallback is allowed.
        tech = _tech_signal(base, market, tf)
        if tech and tech.get("kind") in ("BUY", "SELL") and float(tech.get("confidence") or 0) >= min_conf:
            out = dict(tech)
            out["detail"] = f"بدون مدل ML اختصاصی؛ فالبک تکنیکال · {tech.get('detail', '')}"
            out["fallback_reason"] = "market_model_missing"
            return out
        return {"kind": "HOLD", "brain": "tech", "confidence": (tech or {}).get("confidence"),
                "detail": (tech or {}).get("detail") or "مدل اختصاصی موجود نیست و تکنیکال هم ورود را تأیید نکرد"}

    # A model exists but its inference failed. Never bypass with technical.
    if ml.get("kind") == "UNAVAILABLE":
        return {"kind": "HOLD", "brain": ml.get("brain", "ml"), "confidence": None,
                "detail": ml.get("detail") or "مدل ML موجود است اما در دسترس نیست؛ ورود متوقف شد"}

    ml_kind = str(ml.get("kind") or "HOLD").upper()
    ml_conf = float(ml.get("confidence") or 0.0)
    if ml_kind not in ("BUY", "SELL"):
        return {"kind": "HOLD", "brain": ml.get("brain", "ml"), "confidence": ml.get("confidence"),
                "detail": f"مدل اختصاصی {ml.get('model_symbol', _analysis_symbol(base, market))} صریحاً HOLD داده؛ فالبک تکنیکال مجاز نیست"}
    if not bool(ml.get("edge_confirmed", False)):
        return {"kind": "HOLD", "brain": ml.get("brain", "ml"), "confidence": ml.get("confidence"),
                "detail": "مدل ML برتری آماری تأییدشده ندارد؛ ورود خودکار مسدود شد"}
    if ml_conf < min_conf:
        return {"kind": "HOLD", "brain": ml.get("brain", "ml"), "confidence": ml.get("confidence"),
                "detail": f"اطمینان ML زیر حد مجاز است ({ml_conf:.3f} < {min_conf:.3f})"}

    if mode == "ml_only":
        return ml

    tech = _tech_signal(base, market, tf)
    tech_kind = str((tech or {}).get("kind") or "HOLD").upper()
    tech_conf = float((tech or {}).get("confidence") or 0.0)
    if tech_kind != ml_kind:
        return {"kind": "HOLD", "brain": "hybrid", "confidence": min(ml_conf, tech_conf) if tech else ml_conf,
                "detail": f"عدم توافق مغزها: ML={ml_kind} و تکنیکال={tech_kind}؛ ورود متوقف شد"}
    if tech_conf < min_conf:
        return {"kind": "HOLD", "brain": "hybrid", "confidence": min(ml_conf, tech_conf),
                "detail": f"تأیید تکنیکال کافی نیست ({tech_conf:.3f} < {min_conf:.3f})"}

    out = dict(ml)
    out["brain"] = "hybrid"
    out["confidence"] = min(ml_conf, tech_conf)
    out["detail"] = (f"توافق ML + تکنیکال · ML={ml_kind} · اطمینان ML={ml_conf:.3f} · "
                     f"اطمینان تکنیکال={tech_conf:.3f} · {ml.get('detail', '')} · "
                     f"{tech.get('detail', '')}")
    out["tech_confirmation"] = True
    out["technical_snapshot"] = dict(tech.get("feature_snapshot") or {})
    return out


def _learning_policy_for_decision(base: str, market: str, decision: dict) -> dict:
    """Apply closed-paper-history feedback to a candidate entry.

    Learning is a conservative statistical gate/risk scaler, not online model
    weight training. It only consumes matured, closed simulated trades in the
    exact symbol/market/timeframe/side scope.
    """
    out = dict(decision or {})
    kind = str(out.get("kind") or "HOLD").upper()
    if kind not in ("BUY", "SELL"):
        return out
    if market == "spot" and kind == "SELL":
        return out  # the entry engine rejects spot shorts separately

    timeframe = str(_CONFIG.get("timeframe", "1h"))
    side = "LONG" if kind == "BUY" else "SHORT"
    try:
        from backend.paper_live import get_learning_gate
        gate = get_learning_gate(base, market, timeframe, side)
    except Exception as exc:
        _log_decision("LEARNING_GATE_ERROR", phase="entry", symbol=base, market=market,
                      brain=str(out.get("brain") or ""), confidence=out.get("confidence"),
                      detail=f"دروازهٔ یادگیری در دسترس نیست؛ ورود مسدود شد: {exc}", level="warn")
        return {"kind": "HOLD", "brain": out.get("brain", "learning"),
                "confidence": out.get("confidence"), "learning_blocked": True,
                "detail": f"خطای حافظهٔ یادگیری؛ ورود ایمن متوقف شد: {exc}"}

    state = str(gate.get("learning_state") or "UNKNOWN")
    samples = int(gate.get("sample_count") or 0)
    avg_return = gate.get("avg_net_return_pct")
    if state == "NO_EDGE":
        return {"kind": "HOLD", "brain": out.get("brain", "learning"),
                "confidence": out.get("confidence"), "learning_blocked": True,
                "learning_gate": gate,
                "detail": (f"حافظهٔ معاملات برای {base}/{market}/{timeframe}/{side} برتری مثبت نشان نداده؛ "
                           f"ورود پس از {samples} معاملهٔ بسته مسدود شد")}

    # Cold-start and provisional scopes are allowed to gather evidence, but
    # start with reduced size. Mature positive evidence may use full configured
    # paper risk; a small negative sample lowers size further without overfitting.
    risk_scales = {
        "NO_DATA": 0.50,
        "COLLECTING": 0.50,
        "SHADOW_VALIDATION": 0.65,
        "PAPER_EVIDENCE_ONLY": 1.00,
    }
    if state not in risk_scales:
        return {"kind": "HOLD", "brain": out.get("brain", "learning"),
                "confidence": out.get("confidence"), "learning_blocked": True,
                "learning_gate": gate,
                "detail": f"وضعیت یادگیری نامعتبر ({state})؛ ورود ایمن مسدود شد"}
    risk_scale = risk_scales[state]
    if samples >= 10 and avg_return is not None and float(avg_return) < 0:
        risk_scale = min(risk_scale, 0.25)

    out["learning_gate"] = {**gate, "risk_scale": risk_scale,
                            "entry_policy": "EXPLORATION_REDUCED_RISK" if risk_scale < 1 else "PAPER_EVIDENCE"}
    out["learning_context"] = {
        "learning_state": state, "sample_count": samples,
        "win_rate_pct": gate.get("win_rate_pct"),
        "avg_net_return_pct": avg_return, "profit_factor": gate.get("profit_factor"),
        "risk_scale": risk_scale, "entry_policy": out["learning_gate"]["entry_policy"],
    }
    out["decision_context"] = {
        "schema_version": "paper-entry-context-v1",
        "timeframe": timeframe,
        "decision": {
            "kind": kind, "side": side, "brain": out.get("brain"),
            "confidence": out.get("confidence"), "prob": out.get("prob"),
            "edge_confirmed": bool(out.get("edge_confirmed", False)),
            "model_symbol": out.get("model_symbol"),
            "candle_ts": out.get("candle_ts"),
            "fallback_reason": out.get("fallback_reason"),
            "detail": str(out.get("detail") or "")[:500],
        },
        "learning": out["learning_context"],
        "model": out.get("ml_snapshot") or {},
        "technical": out.get("technical_snapshot") or out.get("feature_snapshot") or {},
    }
    return out


def _decide_entry(base: str, market: str) -> dict:
    """Market-scoped analysis followed by the paper-learning gate."""
    raw = _decide_entry_raw(base, market)
    return _learning_policy_for_decision(base, market, raw)


# --------------------------------------------------------------------------
# paper_live bridge helpers (small, backward-compatible additions live there)
# --------------------------------------------------------------------------
def _autopilot_open_positions(state: dict) -> list[dict]:
    out = []
    for pos in state.get("open_positions") or []:
        if pos.get("status") != "OPEN":
            continue
        ctx = {}
        try:
            ctx = json.loads(pos.get("entry_context_json") or "{}")
        except Exception:
            pass
        if str(ctx.get("entry_source") or "") == "autopilot":
            pos = dict(pos)
            pos["entry_context"] = ctx
            out.append(pos)
    return out


def _recent_autopilot_closes(state: dict, since_ts: float) -> list[dict]:
    out = []
    for t in state.get("recent_trades") or []:
        closed = t.get("closed_at")
        if not closed or float(closed) < since_ts:
            continue
        ctx = {}
        try:
            ctx = json.loads(t.get("entry_context_json") or "{}")
        except Exception:
            pass
        if str(ctx.get("entry_source") or "") == "autopilot":
            out.append(t)
    return out


def _cooldown_key(symbol: str, market: str) -> str:
    return f"{symbol}|{market}"


def _in_cooldown(symbol: str, market: str) -> float:
    with _LOCK:
        until = _STATE["cooldowns"].get(_cooldown_key(symbol, market), 0.0)
    return max(0.0, until - time.time())


# --------------------------------------------------------------------------
# Position management: trailing stop via stop_price tightening
# --------------------------------------------------------------------------
def _manage_trailing(positions: list[dict]) -> int:
    if not _CONFIG.get("trailing_enabled", True):
        return 0
    from backend import paper_live
    trail_trigger = float(_CONFIG.get("trail_trigger_pct", TRAIL_TRIGGER_PCT))
    trail_dist = float(_CONFIG.get("trail_distance_pct", TRAIL_DISTANCE_PCT))
    updated = 0
    for pos in positions:
        try:
            price = pos.get("last_price")
            if not price or pos.get("quote_status") == "DISCONNECTED":
                continue
            result = paper_live.update_trailing_state(
                int(pos["id"]), float(price), trigger_pct=trail_trigger,
                distance_pct=trail_dist)
            if not result["stop_updated"]:
                continue
            pos["stop_price"] = result["new_stop"]
            updated += 1
            _log_decision("TRAIL_STOP", phase="manage", symbol=pos["symbol"], market=pos["market"],
                          trade_id=int(pos["id"]),
                          detail=f"حدضرر متحرک به {result['new_stop']:.6g} منتقل شد "
                                 f"(قله ذخیره‌شده {result['peak_price']:.6g})")
        except Exception as exc:
            _log_decision("TRAIL_ERROR", phase="manage", symbol=pos.get("symbol", ""),
                          market=pos.get("market", ""), detail=str(exc), level="warn")
    return updated


# --------------------------------------------------------------------------
# Entry scan
# --------------------------------------------------------------------------
def _candidate_rank_score(candidate: dict, max_volume: float = 1.0) -> float:
    """Deterministic opportunity score (0..100) using only entry-time evidence.

    Confidence is the main component; model/brain quality and liquidity are
    small tie-breakers. Historical learning can adjust a mature candidate but
    cannot override a HOLD/NO_EDGE decision already enforced upstream.
    """
    decision = candidate.get("decision") or {}
    try:
        confidence = float(decision.get("confidence") or 0.0)
    except (TypeError, ValueError):
        confidence = 0.0
    confidence = max(0.0, min(1.0, confidence))
    score = 70.0 * confidence

    brain = str(decision.get("brain") or "")
    score += {"hybrid": 8.0, "ml": 6.0, "ml_pool": 5.0, "tech": 2.0}.get(brain, 0.0)
    if bool(decision.get("edge_confirmed")):
        score += 5.0
    if bool(decision.get("tech_confirmation")):
        score += 2.0

    ml_snapshot = decision.get("ml_snapshot") if isinstance(decision.get("ml_snapshot"), dict) else {}
    data_quality = ml_snapshot.get("data_quality") if isinstance(ml_snapshot.get("data_quality"), dict) else {}
    dq_status = str(data_quality.get("status") or "").upper()
    if dq_status == "PASS":
        score += 3.0
    elif dq_status and dq_status not in ("PASS", "OK"):
        score -= 5.0

    gate = decision.get("learning_gate") if isinstance(decision.get("learning_gate"), dict) else {}
    try:
        samples = int(gate.get("sample_count") or 0)
        avg_net = gate.get("avg_net_return_pct")
        if samples >= 10 and avg_net is not None:
            avg_net = float(avg_net)
            if math.isfinite(avg_net):
                score += max(-3.0, min(3.0, avg_net * 1.5))
    except (TypeError, ValueError):
        pass

    volume = max(0.0, float(candidate.get("volume_24h") or 0.0))
    # Relative log-liquidity bonus is normalized across this scan, capped at
    # five points, and cannot dominate signal quality. Missing volume gets 0.
    min_volume = max(0.0, float(candidate.get("min_volume_24h") or 0.0))
    if volume > 0 and max_volume > min_volume:
        low_log, high_log = math.log1p(min_volume), math.log1p(max_volume)
        ratio = max(0.0, min(1.0, (math.log1p(volume) - low_log) / max(1e-12, high_log - low_log)))
        score += 5.0 * ratio
    elif volume > 0 and max_volume > 0:
        score += 5.0
    return round(max(0.0, min(100.0, score)), 4)


def _recent_return_series(base: str, market: str, timeframe: str,
                          cache: dict | None = None) -> dict[int, float] | None:
    """Return timestamp-keyed close-to-close returns for correlation checks."""
    symbol = str(base).upper().strip()
    if not symbol.endswith("USDT"):
        symbol += "USDT"
    key = (symbol, str(market).lower(), str(timeframe))
    if cache is not None and key in cache:
        return cache[key]
    result = None
    try:
        sym = _analysis_symbol(symbol, market)
        df = fetch_candles(sym, timeframe,
                           limit=max(30, int(_CONFIG.get("correlation_lookback", 60)) + 2),
                           source="auto", validation_mode="paper", max_age_bars=3)
        if df is not None and len(df) >= 25 and {"t", "close"}.issubset(df.columns):
            rows = []
            for t, close in zip(df["t"].tolist(), df["close"].tolist()):
                try:
                    ts, px = int(float(t)), float(close)
                    if ts > 0 and math.isfinite(px) and px > 0:
                        rows.append((ts, px))
                except (TypeError, ValueError, OverflowError):
                    continue
            rows.sort(key=lambda x: x[0])
            # Remove duplicate timestamps deterministically, retaining last row.
            dedup = {}
            for ts, px in rows:
                dedup[ts] = px
            rows = sorted(dedup.items())
            returns = {}
            for (prev_ts, prev_px), (ts, px) in zip(rows, rows[1:]):
                if prev_px > 0:
                    r = px / prev_px - 1.0
                    if math.isfinite(r):
                        returns[ts] = r
            lookback = int(_CONFIG.get("correlation_lookback", 60))
            if len(returns) >= 24:
                result = dict(list(sorted(returns.items()))[-lookback:])
    except Exception as exc:
        _log_decision("CORRELATION_DATA_UNAVAILABLE", phase="entry", symbol=base,
                      market=market, detail=f"تاریخچهٔ هم‌بستگی در دسترس نیست: {exc}", level="warn")
    if cache is not None:
        cache[key] = result
    return result


def _pearson_aligned(left: dict[int, float] | None,
                     right: dict[int, float] | None,
                     min_points: int = 24) -> float | None:
    """Pearson correlation over common candle timestamps; positive corr only is penalized."""
    if not left or not right:
        return None
    common = sorted(set(left).intersection(right))
    if len(common) < min_points:
        return None
    xs = [float(left[k]) for k in common]
    ys = [float(right[k]) for k in common]
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    dx = [x - mx for x in xs]
    dy = [y - my for y in ys]
    vx = sum(x * x for x in dx)
    vy = sum(y * y for y in dy)
    if vx <= 1e-24 or vy <= 1e-24:
        return None
    corr = sum(x * y for x, y in zip(dx, dy)) / math.sqrt(vx * vy)
    return max(-1.0, min(1.0, corr)) if math.isfinite(corr) else None



def _entry_atr_context(base: str, market: str, timeframe: str, decision: dict) -> dict:
    """Return ATR(14) from the exact closed candle used for the entry decision.

    Technical-only/hybrid decisions reuse the technical snapshot. ML-only
    decisions fetch the same market/timeframe candle series and calculate ATR.
    Missing, stale or misaligned ATR data blocks the candidate.
    """
    expected_ts = float(decision.get("candle_ts") or 0.0)
    if not math.isfinite(expected_ts) or expected_ts <= 0:
        raise ValueError("زمان کندل تصمیم برای محاسبه ATR معتبر نیست")

    snapshots = []
    for key in ("technical_snapshot", "feature_snapshot"):
        value = decision.get(key)
        if isinstance(value, dict):
            snapshots.append(value)
    ml_snapshot = decision.get("ml_snapshot") if isinstance(decision.get("ml_snapshot"), dict) else {}
    indicators = ml_snapshot.get("indicators") if isinstance(ml_snapshot.get("indicators"), dict) else {}
    if indicators:
        snapshots.append(indicators)

    atr_value = None
    close_value = None
    snapshot_ts = None
    used_snapshot = False
    for snapshot in snapshots:
        raw_atr = snapshot.get("atr_14", snapshot.get("atr14", snapshot.get("atr")))
        raw_close = snapshot.get("close", snapshot.get("price"))
        raw_ts = snapshot.get("candle_ts", snapshot.get("last_closed_t"))
        try:
            if raw_atr is not None and raw_close is not None and raw_ts is not None:
                a, c, ts = float(raw_atr), float(raw_close), float(raw_ts)
                if math.isfinite(a) and math.isfinite(c) and math.isfinite(ts) and a > 0 and c > 0:
                    atr_value, close_value, snapshot_ts = a, c, ts
                    used_snapshot = True
                    break
        except (TypeError, ValueError, OverflowError):
            continue

    sym = _analysis_symbol(base, market)
    # Fetch one aligned closed-candle series for both ATR fallback and market structure.
    df = fetch_candles(sym, timeframe, limit=max(210, int(_CONFIG.get("analysis_limit", 420))),
                       source="auto", validation_mode="paper", max_age_bars=3)
    if df is None or len(df) < 30:
        raise ValueError("برای محاسبه ATR و ساختار بازار تاریخچهٔ کندل کافی نیست")
    candle_ts_from_feed = float(df["t"].iloc[-1])
    if atr_value is None:
        atr_series = atr(df["high"], df["low"], df["close"], 14)
        atr_value = float(atr_series.iloc[-1])
        close_value = float(df["close"].iloc[-1])
        snapshot_ts = candle_ts_from_feed
    elif abs(candle_ts_from_feed - expected_ts) > 1e-6:
        raise ValueError("تاریخچهٔ ساختار بازار با کندل تصمیم هم‌تراز نیست")

    if abs(snapshot_ts - expected_ts) > 1e-6:
        raise ValueError("ATR با زمان کندل تصمیم هم‌تراز نیست؛ ورود مسدود شد")
    if not all(math.isfinite(x) and x > 0 for x in (atr_value, close_value)):
        raise ValueError("مقدار ATR یا قیمت مبنا نامعتبر است")
    atr_pct = atr_value / close_value * 100.0
    if not math.isfinite(atr_pct) or atr_pct <= 0:
        raise ValueError("درصد ATR نامعتبر است")
    from backend.portfolio_risk import analyze_support_resistance, detect_breakout_state, detect_breakout_pullback, analyze_volume_confirmation, detect_liquidity_sweep, analyze_rsi_macd_divergence
    side = "LONG" if str(decision.get("kind", "")).upper() == "BUY" else "SHORT"
    structure = analyze_support_resistance(df, side=side, reference_price=close_value,
                                           lookback=120, pivot_width=3)
    breakout = detect_breakout_state(df, side=side, atr_value=atr_value, pivot_width=3)
    pullback = detect_breakout_pullback(df, side=side, atr_value=atr_value, pivot_width=3)
    volume = analyze_volume_confirmation(df, side=side, lookback=20)
    liquidity_sweep = detect_liquidity_sweep(df, side=side, atr_value=atr_value, pivot_width=3)
    divergence = analyze_rsi_macd_divergence(df, side=side, pivot_width=3, lookback=160)
    from backend.candlestick_patterns import analyze_candlestick_patterns
    candlestick_patterns = analyze_candlestick_patterns(df, side=side, volume_lookback=20)
    from backend.supply_demand import analyze_supply_demand
    supply_demand = analyze_supply_demand(df, side=side, atr_value=atr_value, lookback=160, pivot_width=3)
    from backend.market_structure_advanced import analyze_bos_choch
    advanced_structure = analyze_bos_choch(df, side=side, lookback=180, pivot_width=3)
    from backend.confluence_engine import analyze_entry_confluence
    entry_confluence = analyze_entry_confluence(
        side=side, structure=advanced_structure, liquidity=liquidity_sweep,
        divergence=divergence, pullback=pullback, volume=volume,
        supply_demand=supply_demand)
    from backend.signal_quality import analyze_signal_quality
    signal_quality = analyze_signal_quality(entry_confluence)
    return {
        "market_structure": structure,
        "breakout_analysis": breakout,
        "pullback_analysis": pullback,
        "volume_analysis": volume,
        "liquidity_sweep_analysis": liquidity_sweep,
        "divergence_analysis": divergence,
        "candlestick_pattern_analysis": candlestick_patterns,
        "supply_demand_analysis": supply_demand,
        "advanced_market_structure": advanced_structure,
        "entry_confluence": entry_confluence,
        "signal_quality": signal_quality,
        "atr_value": atr_value,
        "atr_pct": atr_pct,
        "reference_close": close_value,
        "candle_ts": snapshot_ts,
        "timeframe": timeframe,
        "market_symbol": _analysis_symbol(base, market),
        "source": "decision_snapshot" if used_snapshot else "closed_candles",
    }


def _entry_scan(*, allow_when_stopped: bool = False) -> dict:
    """Evaluate all eligible scopes, rank the candidates, then open a diversified shortlist."""
    from backend import paper_live
    wl = _watchlist_view()
    symbols = wl["symbols"] or list(_FALLBACK_SYMBOLS)[:int(_CONFIG.get("max_symbols", 10))]
    markets = [m for m in _CONFIG.get("markets", ["spot", "perp"]) if m in ("spot", "perp")]
    state = paper_live.get_state(refresh_quotes=False)
    open_positions = [p for p in (state.get("open_positions") or []) if p.get("status") == "OPEN"]
    open_map = {f"{p['symbol']}|{p['market']}": p for p in open_positions}
    open_bases: dict[str, int] = {}
    for p in open_positions:
        base = str(p.get("symbol") or "").upper().removesuffix("USDT")
        if base:
            open_bases[base] = open_bases.get(base, 0) + 1

    volumes = {str(x.get("symbol", "")).upper(): max(0.0, float(x.get("volume") or 0.0))
               for x in (wl.get("detail") or []) if isinstance(x, dict)}
    candidates: list[dict] = []
    summary = {"evaluated": 0, "candidates": 0, "opened": 0, "rejected": 0,
               "skipped": 0, "capacity_blocked": 0, "diversity_blocked": 0,
               "base_exposure_blocked": 0, "candle_gaps": [], "ranked": []}

    # Phase A: analyze every available symbol/market before any new entry is opened.
    for sym in symbols:
        if not allow_when_stopped:
            with _LOCK:
                if not _STATE.get("entries_enabled"):
                    summary["stopped"] = True
                    break
        if _is_excluded_base(sym[:-4] if sym.endswith("USDT") else sym):
            summary["skipped"] += 1
            continue
        for market in markets:
            key = _cooldown_key(sym, market)
            candle_key = _candle_seen_key(sym, market)
            if _in_cooldown(sym, market) > 0 or key in open_map:
                summary["skipped"] += 1
                continue
            decision = _decide_entry(sym, market)
            summary["evaluated"] += 1
            candle_ts = decision.get("candle_ts")
            try:
                candle_ts = float(candle_ts)
            except (TypeError, ValueError):
                candle_ts = 0.0
            if not math.isfinite(candle_ts) or candle_ts <= 0:
                summary["skipped"] += 1
                _log_decision("CANDLE_ID_UNAVAILABLE", phase="entry", symbol=sym, market=market,
                              detail="شناسهٔ کندل بسته‌شده معتبر نیست؛ برای جلوگیری از ورود تکراری، معامله باز نشد",
                              level="warn")
                continue
            with _LOCK:
                seen = _STATE["candle_seen"].get(candle_key)
            if seen and candle_ts > float(seen):
                gap = _candle_gap_info(float(seen), candle_ts, str(_CONFIG.get("timeframe", "1h")))
                if gap.get("valid") and int(gap.get("missing_bars") or 0) > 0:
                    gap_row = {"symbol": sym, "market": market, "timeframe": str(_CONFIG.get("timeframe", "1h")),
                               "previous_candle_ts": float(seen), "current_candle_ts": candle_ts,
                               "missing_bars": int(gap["missing_bars"])}
                    summary["candle_gaps"].append(gap_row)
                    _log_decision("CANDLE_HISTORY_GAP", phase="entry", symbol=sym, market=market,
                                  detail=f"بین دو اسکن {gap_row['missing_bars']} کندل جاافتاده شناسایی شد؛ سیگنال‌های قدیمی بازپخش نمی‌شوند", level="warn")
            if seen and candle_ts <= float(seen):
                summary["skipped"] += 1
                continue

            if decision.get("kind") not in ("BUY", "SELL"):
                # A HOLD is a completed evaluation for this closed candle.
                if not _mark_candle_seen(candle_key, candle_ts):
                    summary["rejected"] += 1
                    _log_decision("STATE_CHECKPOINT_REJECT", phase="entry", symbol=sym, market=market,
                                  detail="ذخیرهٔ کندل HOLD ناموفق بود؛ ورودی‌های بعدی ایمن متوقف می‌شوند",
                                  level="warn")
                    continue
                _log_decision("HOLD", phase="entry", symbol=sym, market=market,
                              brain=BRAIN_LABELS.get(decision.get("brain", ""), decision.get("brain", "")),
                              confidence=decision.get("confidence"),
                              detail=decision.get("detail", "بدون سیگنال"))
                continue
            timeframe = str(_CONFIG.get("timeframe", "1h"))
            try:
                atr_context = _entry_atr_context(sym, market, timeframe, decision)
            except Exception as exc:
                _mark_candle_seen(candle_key, candle_ts)
                summary["rejected"] += 1
                _log_decision("ATR_RISK_REJECT", phase="entry", symbol=sym, market=market,
                              confidence=decision.get("confidence"),
                              detail=f"حدضرر/حدسود تطبیقی قابل محاسبه نیست؛ ورود مسدود شد: {exc}", level="warn")
                continue
            decision["atr_risk_input"] = atr_context
            breakout = (atr_context.get("breakout_analysis") or {})
            if breakout.get("state") == "FALSE_BREAKOUT":
                _mark_candle_seen(candle_key, candle_ts)
                summary["rejected"] += 1
                _log_decision("FALSE_BREAKOUT_REJECT", phase="entry", symbol=sym, market=market,
                              confidence=decision.get("confidence"),
                              detail=f"شکست جعلی سطح {breakout.get('level')} تشخیص داده شد؛ ورود آزمایشی مسدود شد", level="warn")
                continue
            pullback = (atr_context.get("pullback_analysis") or {})
            if breakout.get("state") == "BREAKOUT_CONFIRMED" or pullback.get("state") in ("WAITING_FOR_RETEST", "RETEST_FAILED", "EXPIRED"):
                _mark_candle_seen(candle_key, candle_ts)
                summary["rejected"] += 1
                _log_decision("PULLBACK_WAIT", phase="entry", symbol=sym, market=market,
                              confidence=decision.get("confidence"),
                              detail=f"ورود عجولانه متوقف شد؛ وضعیت پولبک: {pullback.get('state', 'WAITING_FOR_RETEST')}، سطح: {pullback.get('level')}", level="info")
                continue
            divergence = (atr_context.get("divergence_analysis") or {})
            if divergence.get("blocking"):
                _mark_candle_seen(candle_key, candle_ts)
                summary["rejected"] += 1
                _log_decision("OPPOSING_DIVERGENCE_REJECT", phase="entry", symbol=sym, market=market,
                              confidence=decision.get("confidence"),
                              detail=f"واگرایی مخالف هم‌زمان RSI و MACD تشخیص داده شد؛ ورود آزمایشی مسدود شد (RSI={divergence.get('opposing_rsi_divergence')}, MACD={divergence.get('opposing_macd_divergence')})", level="warn")
                continue
            candle_patterns = (atr_context.get("candlestick_pattern_analysis") or {})
            if candle_patterns.get("blocking"):
                _mark_candle_seen(candle_key, candle_ts)
                summary["rejected"] += 1
                names = ", ".join(p.get("name", "pattern") for p in candle_patterns.get("opposing_patterns", []))
                _log_decision("OPPOSING_CANDLE_PATTERN_REJECT", phase="entry", symbol=sym, market=market,
                              confidence=decision.get("confidence"),
                              detail=f"الگوی برگشتی مخالف با تأیید حجم ({names}) تشخیص داده شد؛ ورود آزمایشی مسدود شد", level="warn")
                continue
            advanced_structure = (atr_context.get("advanced_market_structure") or {})
            if advanced_structure.get("blocking"):
                _mark_candle_seen(candle_key, candle_ts)
                summary["rejected"] += 1
                event = next((e for e in advanced_structure.get("events", []) if e.get("type") == "CHOCH"), {})
                _log_decision("OPPOSING_CHOCH_REJECT", phase="entry", symbol=sym, market=market,
                              confidence=decision.get("confidence"),
                              detail=f"تغییر ساختار مخالف (CHOCH) در سطح {event.get('level')} تأیید شد؛ ورود آزمایشی متوقف شد", level="warn")
                continue
            supply_demand = (atr_context.get("supply_demand_analysis") or {})
            if supply_demand.get("blocking"):
                zone = supply_demand.get("nearest_opposing_zone") or {}
                _mark_candle_seen(candle_key, candle_ts)
                summary["rejected"] += 1
                _log_decision("OPPOSING_SUPPLY_DEMAND_REJECT", phase="entry", symbol=sym, market=market,
                              confidence=decision.get("confidence"),
                              detail=f"منطقه مخالف {zone.get('type')} در فاصله {zone.get('distance_atr')} ATR با قدرت {zone.get('strength')} تشخیص داده شد؛ ورود آزمایشی متوقف شد", level="info")
                continue
            liquidity_sweep = (atr_context.get("liquidity_sweep_analysis") or {})
            if liquidity_sweep.get("state") == "SWEEP_RECLAIMED":
                _mark_candle_seen(candle_key, candle_ts)
                summary["rejected"] += 1
                _log_decision("LIQUIDITY_SWEEP_WAIT", phase="entry", symbol=sym, market=market,
                              confidence=decision.get("confidence"),
                              detail=f"جمع‌آوری نقدینگی و بازپس‌گیری سطح {liquidity_sweep.get('level')} تشخیص داده شد؛ برای تأیید کندل بعدی صبر می‌کنیم", level="info")
                continue
            volume_analysis = (atr_context.get("volume_analysis") or {})
            if pullback.get("state") == "PULLBACK_CONFIRMED" and not volume_analysis.get("confirmed", False):
                _mark_candle_seen(candle_key, candle_ts)
                summary["rejected"] += 1
                _log_decision("WEAK_VOLUME_REJECT", phase="entry", symbol=sym, market=market,
                              confidence=decision.get("confidence"),
                              detail=f"پولبک تأیید شد اما حجم مشارکت کافی نیست؛ وضعیت حجم: {volume_analysis.get('state', 'UNAVAILABLE')}، RVOL: {volume_analysis.get('relative_volume', 'N/A')}", level="info")
                continue
            side = "LONG" if decision["kind"] == "BUY" else "SHORT"
            if market == "spot" and side == "SHORT":
                if not _mark_candle_seen(candle_key, candle_ts):
                    summary["rejected"] += 1
                    continue
                _log_decision("REJECT", phase="entry", symbol=sym, market=market,
                              detail="سیگنال شورت در اسپات قابل اجرا نیست (فقط خرید مجاز است)")
                summary["rejected"] += 1
                continue
            if side == "SHORT" and not _short_allowed(market):
                _mark_candle_seen(candle_key, candle_ts)
                summary["rejected"] += 1
                continue
            try:
                idempotency_key = _entry_idempotency_key(sym, market, timeframe, candle_ts)
            except ValueError:
                summary["rejected"] += 1
                continue
            candidate = {"symbol": sym, "market": market, "side": side,
                         "decision": decision, "volume_24h": volumes.get(sym, 0.0),
                         "candle_ts": candle_ts, "candle_key": candle_key,
                         "idempotency_key": idempotency_key,
                         "min_volume_24h": min((v for v in volumes.values() if v > 0), default=0.0)}
            candidate["score"] = _candidate_rank_score(candidate, max(volumes.values() or [1.0]))
            candidates.append(candidate)

    summary["candidates"] = len(candidates)
    # Historical paper outcomes adjust opportunity ordering only. They cannot
    # create a signal, bypass upstream decision gates, or force an entry.
    try:
        history = paper_live.get_strategy_entry_adjustments(period="all", min_trades=5)
        adjustment_map = history.get("adjustments", {})
    except Exception as exc:
        adjustment_map = {}
        _log_decision("STRATEGY_ADAPTATION_UNAVAILABLE", phase="entry",
                      detail=f"تعدیل تاریخی اعمال نشد؛ رتبه‌بندی پایه حفظ شد: {exc}", level="warn")
    mtf_cache = {}
    for candidate in candidates:
        key = (str(candidate["symbol"]).upper(), str(candidate["market"]).lower(),
               str(_CONFIG.get("timeframe", "1h")).lower(), str(candidate["side"]).upper())
        # Classify the same symbol/timeframe from validated closed candles. Failure is neutral,
        # never a reason to fabricate a regime or block an otherwise valid paper candidate.
        regime_report = None
        regime_evidence = None
        try:
            from backend.market_regime import classify_market_regime
            regime_frame = fetch_candles(candidate["symbol"], str(_CONFIG.get("timeframe", "1h")),
                                         limit=120, source="auto", validation_mode="paper", max_age_bars=3)
            regime_report = classify_market_regime(regime_frame.tail(120))
            regime_history = paper_live.get_regime_aware_strategy_selection(
                regime=regime_report["regime"], period="all", min_trades=5)
            regime_evidence = regime_history.get("adjustments", {}).get(key)
        except Exception as exc:
            _log_decision("REGIME_ADAPTATION_UNAVAILABLE", phase="entry", symbol=candidate["symbol"],
                          detail=f"تعدیل رژیم اعمال نشد؛ امتیاز خنثی حفظ شد: {exc}", level="warn")
        candidate["market_regime"] = regime_report or {"regime": "UNAVAILABLE", "confidence_pct": 0.0}
        # Confirm broader trend (4h), operating context (1h), and entry context (15m).
        # Cache per symbol for this scan so spot/perp candidates do not duplicate requests.
        mtf_key = str(candidate["symbol"]).upper()
        if mtf_key not in mtf_cache:
            try:
                from backend.market_regime import classify_market_regime, confirm_multi_timeframe_regimes
                mtf_reports = {}
                mtf_frames = {}
                for mtf in ("4h", "1h", "15m"):
                    mtf_frame = fetch_candles(mtf_key, mtf, limit=210, source="auto",
                                              validation_mode="paper", max_age_bars=3)
                    mtf_frames[mtf] = mtf_frame.tail(120)
                    mtf_reports[mtf] = classify_market_regime(mtf_frames[mtf])
                mtf_cache[mtf_key] = confirm_multi_timeframe_regimes(mtf_reports)
                from backend.entry_timing import evaluate_entry_timing
                mtf_cache[mtf_key]["entry_timing"] = evaluate_entry_timing(
                    mtf_frames["15m"], candidate["side"])

            except Exception as exc:
                mtf_cache[mtf_key] = {"status": "INSUFFICIENT_DATA", "ranking_multiplier": 1.0,
                                      "timeframes": {}, "confidence_pct": 0.0,
                                      "read_only": True, "real_orders_enabled": False,
                                      "warning": f"تأیید چندتایم‌فریمی در دسترس نیست: {exc}"}
                _log_decision("MTF_CONFIRMATION_UNAVAILABLE", phase="entry", symbol=mtf_key,
                              detail="دادهٔ معتبر همه تایم‌فریم‌ها موجود نیست؛ تعدیل خنثی حفظ شد", level="warn")
        candidate["multi_timeframe_confirmation"] = dict(mtf_cache[mtf_key])
        candidate["regime_historical_adjustment"] = regime_evidence or {
            "multiplier": 1.0, "trade_count": 0, "eligible": False,
            "reliability_pct": 0.0, "status": "بدون سابقه معتبر همین رژیم؛ خنثی"}
        evidence = adjustment_map.get(key)
        candidate["historical_adjustment"] = evidence or {
            "multiplier": 1.0, "trade_count": 0, "eligible": False,
            "adjusted_expectancy_usdt": None, "reliability_pct": 0.0,
            "status": "بدون سابقه؛ امتیاز خنثی"}
        candidate["base_score"] = float(candidate["score"])
        candidate["score"] = round(candidate["base_score"] *
                                    float(candidate["historical_adjustment"].get("multiplier", 1.0)) *
                                    float(candidate["regime_historical_adjustment"].get("multiplier", 1.0)) *
                                    float(candidate["multi_timeframe_confirmation"].get("ranking_multiplier", 1.0)) *
                                    float((candidate["multi_timeframe_confirmation"].get("entry_timing") or {}).get("ranking_multiplier", 1.0)), 4)
    candidates.sort(key=lambda c: (-float(c["score"]), -float(c.get("volume_24h") or 0.0),
                                   str(c["symbol"]), str(c["market"])))
    summary["ranked"] = [{"rank": i + 1, "symbol": c["symbol"], "market": c["market"],
                          "side": c["side"], "score": c["score"], "base_score": c["base_score"],
                          "historical_adjustment": c["historical_adjustment"],
                          "multi_timeframe_confirmation": c.get("multi_timeframe_confirmation"),
                          "entry_timing": (c.get("multi_timeframe_confirmation") or {}).get("entry_timing"),
                          "confidence": c["decision"].get("confidence"),
                          "volume_24h": c.get("volume_24h"), "selected": False,
                          "reason": "رتبه‌بندی با تعدیل محدود سابقه؛ در صف بررسی ریسک پرتفوی"}
                         for i, c in enumerate(candidates[:60])]

    # Phase B: greedily choose highest-scoring opportunities under portfolio limits.
    max_positions = int(_CONFIG.get("max_open_positions", 5))
    max_per_base = int(_CONFIG.get("max_positions_per_base", 1))
    corr_enabled = bool(_CONFIG.get("diversification_enabled", True))
    corr_threshold = float(_CONFIG.get("correlation_threshold", 0.82))
    slots = max(0, max_positions - len(open_positions))
    if slots == 0 and candidates:
        # Per-candidate accounting happens in the selection loop below.
        for row in summary["ranked"]:
            row["reason"] = "ظرفیت موقعیت‌های باز تکمیل شده است"
    corr_cache: dict = {}
    reference_series: list[tuple[str, str, str, dict[int, float] | None]] = []
    if corr_enabled and candidates and open_positions:
        for pos in open_positions:
            p_symbol = str(pos.get("symbol") or "").upper()
            pbase = p_symbol.removesuffix("USDT")
            pmarket = str(pos.get("market") or "spot")
            pside = str(pos.get("side") or "LONG").upper()
            reference_series.append((pbase, pmarket, pside,
                _recent_return_series(p_symbol, pmarket,
                                      str(_CONFIG.get("timeframe", "1h")), corr_cache)))

    selected: list[dict] = []
    selected_bases = dict(open_bases)
    for candidate in candidates:
        if len(selected) >= slots:
            summary["capacity_blocked"] += 1
            _mark_candle_seen(candidate["candle_key"], candidate["candle_ts"])
            ranked_row = next((r for r in summary["ranked"] if r["symbol"] == candidate["symbol"] and r["market"] == candidate["market"]), None)
            if ranked_row:
                ranked_row.update(selected=False, reason="ظرفیت موقعیت‌های باز تکمیل شده است")
            continue
        if not allow_when_stopped:
            with _LOCK:
                if not _STATE.get("entries_enabled"):
                    summary["stopped"] = True
                    break
        sym, market, side = candidate["symbol"], candidate["market"], candidate["side"]
        base = str(sym).upper().removesuffix("USDT")
        if selected_bases.get(base, 0) >= max_per_base:
            _mark_candle_seen(candidate["candle_key"], candidate["candle_ts"])
            summary["base_exposure_blocked"] += 1
            ranked_row = next((r for r in summary["ranked"] if r["symbol"] == sym and r["market"] == market), None)
            if ranked_row:
                ranked_row.update(selected=False, reason="ریسک پایهٔ همین ارز از قبل در پرتفوی وجود دارد")
            _log_decision("BASE_EXPOSURE_REJECT", phase="entry", symbol=sym, market=market,
                          confidence=candidate["decision"].get("confidence"),
                          detail=f"حداکثر {max_per_base} موقعیت برای پایهٔ {base} مجاز است")
            continue

        # Positive correlation above threshold means duplicated directional risk.
        # Negative/low correlation is not penalized; unavailable history is logged
        # but does not block all trading during a source outage.
        corr_block = None
        corr_evidence = False
        diversification_status = "DISABLED" if not corr_enabled else "NO_REFERENCE"
        if corr_enabled and reference_series:
            cand_series = _recent_return_series(sym, market, str(_CONFIG.get("timeframe", "1h")), corr_cache)
            comparable_refs = 0
            if not cand_series:
                diversification_status = "UNAVAILABLE"
            else:
                for ref_base, ref_market, ref_side, ref_series in reference_series:
                    if ref_base == base or ref_side != side:
                        continue
                    if not ref_series:
                        continue
                    comparable_refs += 1
                    corr = _pearson_aligned(cand_series, ref_series)
                    if corr is not None:
                        corr_evidence = True
                        if corr >= corr_threshold:
                            corr_block = (ref_base, ref_market, corr)
                            break
                if corr_evidence:
                    diversification_status = "CHECKED"
                elif comparable_refs:
                    diversification_status = "INSUFFICIENT_OVERLAP"
                else:
                    diversification_status = "NO_COMPARABLE_DIRECTIONAL_REFERENCE"
        if corr_block:
            _mark_candle_seen(candidate["candle_key"], candidate["candle_ts"])
            summary["diversity_blocked"] += 1
            ranked_row = next((r for r in summary["ranked"] if r["symbol"] == sym and r["market"] == market), None)
            if ranked_row:
                ranked_row.update(selected=False,
                    reason=f"هم‌بستگی مثبت {corr_block[2]:.2f} با {corr_block[0]} بالاتر از حد {corr_threshold:.2f}")
            _log_decision("DIVERSITY_REJECT", phase="entry", symbol=sym, market=market,
                          confidence=candidate["decision"].get("confidence"),
                          detail=f"هم‌بستگی {corr_block[2]:.2f} با {corr_block[0]}؛ ریسک تکراری رد شد")
            continue

        decision = dict(candidate["decision"])
        rank_index = next((i + 1 for i, x in enumerate(candidates) if x is candidate), 0)
        opportunity = {"rank": rank_index, "score": candidate["score"],
                       "volume_24h": candidate.get("volume_24h"),
                       "diversification_status": diversification_status,
                       "correlation_threshold": corr_threshold if corr_enabled else None}
        decision_context = dict(decision.get("decision_context") or {})
        decision_context["opportunity"] = opportunity
        decision_context["atr_risk_input"] = dict(decision.get("atr_risk_input") or {})
        decision_context["market_regime"] = str((candidate.get("market_regime") or {}).get("regime") or "").upper()
        decision_context["market_regime_confidence_pct"] = (candidate.get("market_regime") or {}).get("confidence_pct")
        decision_context["regime_historical_adjustment"] = dict(candidate.get("regime_historical_adjustment") or {})
        decision_context["multi_timeframe_confirmation"] = dict(candidate.get("multi_timeframe_confirmation") or {})
        decision["decision_context"] = decision_context

        try:
            with _ENTRY_EXEC_LOCK:
                with _LOCK:
                    still_enabled = bool(_STATE.get("entries_enabled"))
                if not allow_when_stopped and not still_enabled:
                    summary["stopped"] = True
                    break
                # Re-check the shared paper book under the final entry lock; a
                # manual entry may have changed capacity/base exposure mid-scan.
                fresh_state = paper_live.get_state(refresh_quotes=False)
                fresh_open = [p for p in (fresh_state.get("open_positions") or []) if p.get("status") == "OPEN"]
                fresh_base_count = sum(1 for p in fresh_open
                    if str(p.get("symbol") or "").upper().removesuffix("USDT") == base)
                if len(fresh_open) >= max_positions or fresh_base_count >= max_per_base:
                    _mark_candle_seen(candidate["candle_key"], candidate["candle_ts"])
                    summary["skipped"] += 1
                    ranked_row = next((r for r in summary["ranked"] if r["symbol"] == sym and r["market"] == market), None)
                    if ranked_row:
                        ranked_row.update(selected=False, reason="پرشدن ظرفیت هم‌زمان پرتفوی")
                    continue
                learning_gate = decision.get("learning_gate") or {}
                overrides = _apply_learning_risk_scale(_risk_overrides(), learning_gate)
                res = paper_live.open_position(
                    sym, side, market, "auto", str(_CONFIG.get("timeframe", "1h")),
                    overrides=overrides, entry_source="autopilot",
                    decision_context=decision_context,
                    idempotency_key=candidate["idempotency_key"],
                    atr_value=float(candidate["decision"]["atr_risk_input"]["atr_value"]),
                )
            # The DB commit is authoritative. If the process dies before this
            # checkpoint, the same key is replayed and resolves to the original
            # trade instead of creating a second one.
            checkpoint_ok = _mark_candle_seen(candidate["candle_key"], candidate["candle_ts"])
            if res.get("idempotent_replay"):
                summary["skipped"] += 1
                ranked_row = next((r for r in summary["ranked"] if r["symbol"] == sym and r["market"] == market), None)
                if ranked_row:
                    ranked_row.update(selected=False, reason="این فرصت قبلاً به‌صورت پایدار ثبت شده است")
                _log_decision("ENTRY_DEDUPLICATED", phase="entry", symbol=sym, market=market,
                              trade_id=res.get("id"), detail="درخواست تکراری شناسایی شد؛ معاملهٔ قبلی حفظ شد")
                if not checkpoint_ok:
                    _log_decision("STATE_CHECKPOINT_REJECT", phase="entry", symbol=sym, market=market,
                                  trade_id=res.get("id"), detail="معامله قبلاً ثبت شده؛ ذخیرهٔ نشانگر کندل ناموفق بود",
                                  level="warn")
                continue
            summary["opened"] += 1
            selected_bases[base] = selected_bases.get(base, 0) + 1
            selected.append(candidate)
            if not checkpoint_ok:
                _log_decision("STATE_CHECKPOINT_REJECT", phase="entry", symbol=sym, market=market,
                              trade_id=res.get("id"), detail="معامله ثبت شده، اما نشانگر کندل ذخیره نشد؛ کلید یکتای دیتابیس از تکرار جلوگیری می‌کند",
                              level="warn")
            ranked_row = next((r for r in summary["ranked"] if r["symbol"] == sym and r["market"] == market), None)
            if ranked_row:
                ranked_row.update(selected=True, reason="بهترین فرصتِ واجد شرایط پس از رتبه‌بندی")
            brain = BRAIN_LABELS.get(decision.get("brain", ""), decision.get("brain", ""))
            _log_decision("OPEN", phase="entry", symbol=sym, market=market,
                          brain=brain, confidence=decision.get("confidence"), trade_id=res["id"],
                          detail=(f"رتبه {rank_index} · امتیاز {candidate['score']:.2f}/100 · {side} باز شد · "
                                  f"ارزش {res['notional']:.2f} USDT · حدضرر {res['stop_price']:.6g} · "
                                  f"هدف {res['target_price']:.6g} · "
                                  f"Net R/R={float((res.get('atr_risk_bracket') or {}).get('net_reward_risk') or 0):.2f} · "
                                  f"{decision.get('detail', '')}"))
            if corr_enabled:
                reference_series.append((base, market, side,
                    _recent_return_series(sym, market, str(_CONFIG.get("timeframe", "1h")), corr_cache)))
        except ValueError as exc:
            summary["rejected"] += 1
            ranked_row = next((r for r in summary["ranked"] if r["symbol"] == sym and r["market"] == market), None)
            if ranked_row:
                ranked_row.update(selected=False, reason=f"رد اجرای مجازی: {str(exc)[:100]}")
            _log_decision("REJECT", phase="entry", symbol=sym, market=market,
                          confidence=decision.get("confidence"), detail=str(exc))
        except Exception as exc:
            summary["rejected"] += 1
            ranked_row = next((r for r in summary["ranked"] if r["symbol"] == sym and r["market"] == market), None)
            if ranked_row:
                ranked_row.update(selected=False, reason="خطا هنگام بازکردن معاملهٔ آزمایشی")
            _log_decision("OPEN_ERROR", phase="entry", symbol=sym, market=market,
                          detail=f"خطای بازکردن موقعیت: {exc}", level="warn")

    # Keep the top-ranked list visible in the dashboard for auditability.
    with _LOCK:
        _STATE["last_entry_summary"] = {
            "ts": time.time(), "evaluated": summary["evaluated"],
            "candidates": summary["candidates"], "opened": summary["opened"],
            "diversity_blocked": summary["diversity_blocked"],
            "base_exposure_blocked": summary["base_exposure_blocked"],
            "capacity_blocked": summary["capacity_blocked"],
            "ranked": summary["ranked"][:60],
        }
    _persist_runtime_state()
    return summary


def _short_allowed(market: str) -> bool:
    return market == "perp"


def _risk_overrides() -> dict:
    preset = str(_CONFIG.get("risk_preset", "balanced"))
    base = dict(RISK_PRESETS.get(preset, {})) if preset in RISK_PRESETS else {}
    for k in ("max_open_positions", "max_position_notional_pct", "risk_per_trade_pct",
              "stop_loss_pct", "take_profit_pct"):
        if k in _CONFIG and _CONFIG[k] is not None:
            base[k] = _CONFIG[k]
    for k in ("max_daily_loss_pct", "max_drawdown_pct", "max_portfolio_risk_pct",
              "max_spot_risk_pct", "max_perp_risk_pct", "max_directional_risk_pct"):
        if _CONFIG.get(k) is not None:
            base[k] = _CONFIG[k]
    # Presets also contain non-risk controls (e.g. markets, confidence and
    # cooldown). Only numeric risk-budget keys belong in the downstream sizing
    # override object; coercing the entire preset used to fail on its lists.
    return {k: float(base[k]) for k in _RISK_KEYS if k in base and base[k] is not None}


def _apply_learning_risk_scale(overrides: dict, learning_gate: dict | None) -> dict:
    """Apply a bounded historical-evidence multiplier to entry sizing only."""
    out = dict(overrides or {})
    try:
        scale = float((learning_gate or {}).get("risk_scale", 0.5))
    except (TypeError, ValueError):
        scale = 0.0
    if not math.isfinite(scale) or not 0.10 <= scale <= 1.0:
        raise ValueError("ضریب ریسک یادگیری نامعتبر است؛ ورود آزمایشی مسدود شد")
    for key in ("risk_per_trade_pct", "max_position_notional_pct"):
        if key in out:
            out[key] = float(out[key]) * scale
    return out


# --------------------------------------------------------------------------
# Reporting
# --------------------------------------------------------------------------
def _is_autopilot_trade(trade: dict) -> bool:
    try:
        context = json.loads(trade.get("entry_context_json") or "{}")
    except Exception:
        context = {}
    return str(context.get("entry_source") or "") == "autopilot"


def _closed_autopilot_trades(since: float | None = None, until: float | None = None) -> list[dict]:
    from backend import paper_live
    rows = paper_live.list_trades(status="CLOSED", since=since, until=until, limit=None)
    return [t for t in rows if _is_autopilot_trade(t)]


def daily_profit_target_for_capital(capital_usdt: float | None = None) -> float:
    """Return the configured daily *goal* tier; this is not a promised return.

    Tiers requested by the operator:
      * >= 1,000 USDT: 30 USDT
      * 200 to < 1,000 USDT: 20 USDT
      * < 200 USDT: 10 USDT

    The goal only pauses new entries after the realized net-PnL threshold is
    reached. It never raises position size, leverage, or risk to chase the goal.
    """
    if capital_usdt is None:
        capital_usdt = float(_CONFIG.get("daily_start_balance", 1000.0))
    try:
        capital = float(capital_usdt)
    except (TypeError, ValueError):
        raise ValueError("سرمایه برای محاسبه هدف روزانه معتبر نیست")
    if not math.isfinite(capital) or capital <= 0:
        raise ValueError("سرمایه برای محاسبه هدف روزانه باید مثبت و محدود باشد")
    if capital >= 1000.0:
        return 30.0
    if capital >= 200.0:
        return 20.0
    return 10.0


def daily_profit_goal_snapshot() -> dict[str, Any]:
    """Read today's realized AutoPilot net PnL and compare it to capital tier.

    Only CLOSED AutoPilot-originated trades count. Open/unrealized PnL is not
    counted. If the ledger cannot be read, the caller must fail closed for new
    entries rather than assume the goal has not been reached.
    """
    capital = float(_CONFIG.get("daily_start_balance", 1000.0))
    target = daily_profit_target_for_capital(capital)
    now_local = datetime.now().astimezone()
    day_start = now_local.replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
    try:
        rows = _closed_autopilot_trades(since=day_start)
        realized = 0.0
        for trade in rows:
            value = float(trade.get("net_pnl") or 0.0)
            if not math.isfinite(value):
                raise ValueError("مقدار سود/زیان بسته‌شده نامعتبر است")
            realized += value
        reached = realized >= target
        return {
            "enabled": True, "complete": True, "currency": "USDT",
            "capital_usdt": round(capital, 8), "target_usdt": target,
            "realized_net_pnl_usdt": round(realized, 8),
            "remaining_usdt": round(max(0.0, target - realized), 8),
            "reached": reached, "counted_trades": len(rows),
            "basis": "closed_autopilot_net_pnl_local_day",
            "action": "pause_new_entries_until_next_local_day" if reached else "no_change",
            "day_start_local": now_local.replace(hour=0, minute=0, second=0, microsecond=0).isoformat(),
        }
    except Exception as exc:
        return {
            "enabled": True, "complete": False, "currency": "USDT",
            "capital_usdt": round(capital, 8), "target_usdt": target,
            "realized_net_pnl_usdt": None, "remaining_usdt": None,
            "reached": None, "counted_trades": None,
            "basis": "closed_autopilot_net_pnl_local_day",
            "action": "block_new_entries_until_ledger_readable",
            "error": str(exc)[:240],
        }


def _open_autopilot_trades(since: float | None = None, until: float | None = None) -> list[dict]:
    from backend import paper_live
    rows = paper_live.list_trades(status="OPEN", since=since, until=until, limit=None)
    return [t for t in rows if _is_autopilot_trade(t)]


def _stats_from_trades(
    trades: list[dict],
    open_trades: list[dict] | None = None,
    starting_equity: float | None = None,
) -> dict:
    """Build realized-only stats with notional-based returns and an explicit baseline.

    `trades` contains closed rows; `open_trades` is supplied separately because
    report queries intentionally fetch closed and open positions independently.
    The equity curve includes its starting point so drawdown is measured from
    the actual period baseline, not from the first closed trade.
    """
    closed = [t for t in trades if t.get("status") == "CLOSED"]
    opened = [t for t in (open_trades or []) if t.get("status") == "OPEN"]
    wins = [t for t in closed if float(t.get("net_pnl") or 0) > 0]
    losses = [t for t in closed if float(t.get("net_pnl") or 0) < 0]
    breakeven = [t for t in closed if abs(float(t.get("net_pnl") or 0)) <= 1e-12]
    gross_win = sum(float(t.get("net_pnl") or 0) for t in wins)
    gross_loss = -sum(float(t.get("net_pnl") or 0) for t in losses)
    total_net = sum(float(t.get("net_pnl") or 0) for t in closed)
    fees = sum(float(t.get("entry_fee") or 0) + float(t.get("exit_fee") or 0) for t in closed)
    returns = []
    for t in closed:
        notional = float(t.get("notional") or 0)
        if notional > 0:
            returns.append(float(t.get("net_pnl") or 0) / notional * 100.0)
    by_symbol: dict[str, dict] = {}
    by_market: dict[str, dict] = {}
    by_exit: dict[str, int] = {}
    for t in closed:
        pnl = float(t.get("net_pnl") or 0)
        for bucket, key in ((by_symbol, t.get("symbol", "?")), (by_market, t.get("market", "?"))):
            b = bucket.setdefault(key, {"trades": 0, "wins": 0, "net_pnl": 0.0})
            b["trades"] += 1
            b["wins"] += 1 if pnl > 0 else 0
            b["net_pnl"] += pnl
        reason = t.get("exit_reason") or "?"
        by_exit[reason] = by_exit.get(reason, 0) + 1

    baseline = float(starting_equity if starting_equity is not None else _CONFIG.get("daily_start_balance", 1000.0))
    if not math.isfinite(baseline) or baseline <= 0:
        baseline = 1000.0
    equity = baseline
    curve = [{"ts": None, "equity": round(equity, 4), "kind": "START"}]
    for t in sorted(closed, key=lambda x: float(x.get("closed_at") or 0)):
        equity += float(t.get("net_pnl") or 0)
        curve.append({"ts": t.get("closed_at"), "equity": round(equity, 4), "kind": "CLOSED_TRADE"})
    peak = baseline
    max_dd = 0.0
    for point in curve:
        current_equity = float(point["equity"])
        peak = max(peak, current_equity)
        if peak > 0:
            max_dd = min(max_dd, (current_equity / peak - 1.0) * 100.0)

    total_count = len(closed) + len(opened)
    return {
        "trades": total_count,
        "closed_trades": len(closed),
        "open_trades": len(opened),
        "wins": len(wins), "losses": len(losses), "breakeven": len(breakeven),
        "win_rate_pct": (len(wins) / len(closed) * 100.0) if closed else None,
        "gross_win": round(gross_win, 4), "gross_loss": round(gross_loss, 4),
        "net_pnl": round(total_net, 4),
        "fees_paid": round(fees, 4),
        "profit_factor": (gross_win / gross_loss) if gross_loss > 0 else (None if gross_win == 0 else 999.0),
        "expectancy": round(total_net / len(closed), 4) if closed else None,
        "avg_return_pct": round(sum(returns) / len(returns), 4) if returns else None,
        "total_return_pct": round(total_net / baseline * 100.0, 4) if baseline > 0 else None,
        "starting_equity": round(baseline, 4),
        "ending_realized_equity": round(equity, 4),
        "best_trade": max((round(float(t.get("net_pnl") or 0), 4) for t in closed), default=None),
        "worst_trade": min((round(float(t.get("net_pnl") or 0), 4) for t in closed), default=None),
        "by_symbol": by_symbol, "by_market": by_market, "by_exit_reason": by_exit,
        "equity_curve": curve, "max_drawdown_pct": round(max_dd, 2),
        "duration_avg_minutes": round(
            sum(max(0.0, float(t.get("closed_at") or 0) - float(t.get("opened_at") or 0)) for t in closed)
            / max(1, len(closed)) / 60.0, 1) if closed else None,
    }


def _narrative(kind: str, title: str, stats: dict, watch: dict | None = None) -> str:
    lines: list[str] = []
    lines.append(f"«{title}»")
    if stats["closed_trades"] == 0:
        lines.append("در این بازه هیچ معامله‌ای بسته نشده است. یا سیگنال مطمئنی پیدا نشد یا همهٔ موقعیت‌ها هنوز باز هستند؛ این رفتار طبیعی موتور محافظه‌کار است.")
        if stats["open_trades"]:
            lines.append(f"تعداد {stats['open_trades']} موقعیت باز تحت پایش حدضرر/حدسود است.")
        return "\n".join(lines)
    wr = stats["win_rate_pct"]
    wr_txt = f"{wr:.1f}٪" if wr is not None else "—"
    pf = stats["profit_factor"]
    pf_txt = "نامحدود" if pf == 999.0 else (f"{pf:.2f}" if pf is not None else "—")
    lines.append(f"در این بازه {stats['closed_trades']} معامله بسته شد: {stats['wins']} سودده، {stats['losses']} زیان‌ده و {stats.get('breakeven', 0)} سربه‌سر (نرخ برد {wr_txt}).")
    if stats.get("open_trades", 0):
        lines.append(f"هم‌اکنون {stats['open_trades']} موقعیت باز نیز تحت پایش است؛ سود و زیان شناور آن‌ها در بازده تحقق‌یافتهٔ این گزارش جمع نشده است.")
    sign = "+" if stats["net_pnl"] >= 0 else ""
    lines.append(f"سود/زیان خالص بعد از کارمزد: {sign}{stats['net_pnl']:.2f} USDT · Profit Factor: {pf_txt} · امید ریاضی هر معامله: {sign}{stats['expectancy'] or 0:.2f} USDT.")
    if stats["by_symbol"]:
        best_sym = max(stats["by_symbol"].items(), key=lambda kv: kv[1]["net_pnl"])
        worst_sym = min(stats["by_symbol"].items(), key=lambda kv: kv[1]["net_pnl"])
        lines.append(f"بهترین نماد: {best_sym[0]} با {best_sym[1]['net_pnl']:+.2f} USDT · ضعیف‌ترین نماد: {worst_sym[0]} با {worst_sym[1]['net_pnl']:+.2f} USDT.")
    if stats["by_market"]:
        parts = [f"{'اسپات' if k == 'spot' else 'فیوچرز'}: {v['net_pnl']:+.2f} USDT در {v['trades']} معامله" for k, v in stats["by_market"].items()]
        lines.append("عملکرد به تفکیک بازار — " + " · ".join(parts))
    reasons = "، ".join(f"{EXIT_LABELS.get(k, k)}: {v}" for k, v in stats["by_exit_reason"].items())
    lines.append(f"علت‌های خروج — {reasons}.")
    lines.append(f"حداکثر افت سرمایهٔ منحنی سرمایه در این بازه: {stats['max_drawdown_pct']:.2f}٪.")
    if stats["net_pnl"] >= 0 and (pf is None or pf >= 1.15):
        lines.append("جمع‌بندی: موتور در این بازه لبهٔ مثبتی نشان داده است؛ ادامهٔ پایش با همین قواعد ریسک توصیه می‌شود.")
    elif stats["net_pnl"] < 0:
        lines.append("جمع‌بندی: نتیجهٔ این بازه منفی است. قواعد حدضرر جلوی بزرگ‌تر شدن ضرر را گرفته‌اند؛ اگر روند چند روز ادامه پیدا کند، تایم‌فریم یا آستانهٔ اطمینان را محافظه‌کارانه‌تر کن.")
    else:
        lines.append("جمع‌بندی: نتیجهٔ این بازه کمی مثبت است؛ برای اعتبار آماری به دادهٔ بیشتر نیاز است.")
    lines.append("هشدار همیشگی: این نتایج از شبیه‌سازی با قیمت واقعی است و هیچ تضمین سود در بازار واقعی وجود ندارد.")
    return "\n".join(lines)


def build_report(kind: str = "session", day: str | None = None) -> dict:
    """kind: session (since autopilot start) | daily (a calendar day) | full (all autopilot history)."""
    kind = str(kind or "session").lower()
    with _LOCK:
        started_at = _STATE["started_at"] or 0.0
    if kind == "daily":
        day = day or _day_key()
        day_start = datetime.fromisoformat(f"{day}T00:00:00").astimezone().timestamp()
        day_end = day_start + 86400
        trades = [t for t in _closed_autopilot_trades(since=day_start, until=day_end)
                  if day in _day_key(float(t.get("closed_at") or 0))]
        open_trades = [t for t in _open_autopilot_trades(since=day_start, until=day_end)
                       if day in _day_key(float(t.get("opened_at") or 0))]
        baseline_since = day_start
        title = f"گزارش روزانهٔ معامله‌گر خودکار — {day}"
        period = {"kind": "daily", "day": day, "since": day_start, "until": day_end}
    elif kind == "full":
        trades = _closed_autopilot_trades()
        open_trades = _open_autopilot_trades()
        baseline_since = None
        title = "گزارش کامل معامله‌گر خودکار (تمام تاریخچه)"
        period = {"kind": "full", "since": None, "until": None}
    else:
        trades = _closed_autopilot_trades(since=started_at)
        open_trades = _open_autopilot_trades(since=started_at)
        baseline_since = started_at
        title = "گزارش جلسهٔ معامله‌گر خودکار"
        period = {"kind": "session", "since": started_at, "until": time.time()}

    baseline = float(_CONFIG.get("daily_start_balance", 1000.0))
    if baseline_since is not None and baseline_since > 0:
        prior = _closed_autopilot_trades(until=baseline_since)
        baseline += sum(float(t.get("net_pnl") or 0.0) for t in prior)
    stats = _stats_from_trades(trades, open_trades=open_trades, starting_equity=baseline)
    from backend import paper_live
    try:
        state = paper_live.get_state(refresh_quotes=False)
        account = state.get("account") or {}
    except Exception:
        account = {}
    with _LOCK:
        open_positions = len(_STATE["trail_meta"])
        cooldowns = {k: max(0.0, v - time.time()) for k, v in _STATE["cooldowns"].items() if v > time.time()}
    report = {
        "version": VERSION, "title": title, "generated_at": _now_iso(),
        "period": period, "stats": stats,
        "account": account,
        "cooldowns": cooldowns,
        "config_snapshot": {k: _CONFIG.get(k) for k in ("brain_mode", "timeframe", "markets", "risk_preset",
                                                        "max_open_positions", "stop_loss_pct", "take_profit_pct",
                                                        "trailing_enabled", "min_signal_confidence")},
        "watchlist": _watchlist_view(),
    }
    report["narrative"] = _narrative(kind, title, stats)
    return report


def _save_daily_report(report: dict) -> None:
    try:
        init_reports_db()
        with sqlite3.connect(_reports_db(), timeout=15) as c:
            c.execute("""INSERT INTO autopilot_reports(kind,period_key,created_at,payload_json)
                         VALUES(?,?,?,?)""",
                      ("daily", report["period"].get("day"), time.time(),
                       json.dumps(report, ensure_ascii=False)))
    except Exception as exc:
        _log_decision("REPORT_SAVE_ERROR", phase="system", detail=str(exc), level="warn")


def _reports_db() -> Path:
    return _models_dir() / "autopilot.sqlite3"


def init_reports_db() -> None:
    with sqlite3.connect(_reports_db(), timeout=15) as c:
        c.execute("""CREATE TABLE IF NOT EXISTS autopilot_reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kind TEXT NOT NULL,
            period_key TEXT NOT NULL,
            created_at REAL NOT NULL,
            payload_json TEXT NOT NULL)""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_apr_kind ON autopilot_reports(kind, period_key)")


def _maybe_daily_report() -> None:
    if not _CONFIG.get("daily_report_enabled", True):
        return
    today = _day_key()
    with _LOCK:
        if today in _STATE["daily_reports_done"]:
            return
        _STATE["daily_reports_done"].add(today)
    # Report covers the PREVIOUS calendar day.
    yesterday = _day_key(time.time() - 86400)
    with _LOCK:
        if yesterday not in _STATE["daily_reports_done"]:
            _STATE["daily_reports_done"].add(yesterday)
    _persist_runtime_state()
    try:
        rep = build_report("daily", day=yesterday)
        if rep["stats"]["trades"] > 0 or rep["stats"]["closed_trades"] > 0:
            _save_daily_report(rep)
            _log_decision("DAILY_REPORT", phase="report", symbol="", market="",
                          detail=f"گزارش روزانهٔ {yesterday} ذخیره شد · خالص {rep['stats']['net_pnl']:+.2f} USDT")
    except Exception as exc:
        _log_decision("DAILY_REPORT_ERROR", phase="system", detail=str(exc), level="warn")


# --------------------------------------------------------------------------
# CSV export
# --------------------------------------------------------------------------
def autopilot_trades_csv() -> str:
    import csv as _csv
    import io as _io
    trades = _closed_autopilot_trades()
    buf = _io.StringIO(newline="")
    fields = ["trade_id", "opened_at", "closed_at", "symbol", "market", "timeframe", "exchange",
              "side", "notional", "entry_fill", "exit_fill", "stop_price", "target_price",
              "entry_fee", "exit_fee", "gross_pnl", "net_pnl", "return_pct", "exit_reason"]
    writer = _csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for t in trades:
        notional = float(t.get("notional") or 0)
        row = {k: t.get(k) for k in fields}
        row["opened_at"] = _day_key(float(t.get("opened_at") or 0)) + " " + datetime.fromtimestamp(
            float(t.get("opened_at") or 0)).strftime("%H:%M:%S")
        closed_at = t.get("closed_at")
        row["closed_at"] = (_day_key(float(closed_at)) + " " + datetime.fromtimestamp(float(closed_at)).strftime("%H:%M:%S")) if closed_at else ""
        row["return_pct"] = round(float(t.get("net_pnl") or 0) / notional * 100.0, 4) if notional > 0 else ""
        writer.writerow(row)
    return buf.getvalue()


# --------------------------------------------------------------------------
# Independent manager and entry workers
# --------------------------------------------------------------------------
@_authorized_paper_writer
def _manager_cycle_once_impl() -> dict:
    """Refresh/manage existing positions only; never scans or opens entries."""
    from backend import paper_live
    t0 = time.time()
    # A failed refresh must never fall back to stale prices for stop/target work.
    state = paper_live.get_state(refresh_quotes=True, sync_funding=True)
    last_check = float(_STATE.get("last_closed_check_ts", 0.0) or 0.0)
    closed_now = _recent_autopilot_closes(state, last_check or (time.time() - 120))
    cooldown_min = float(_CONFIG.get("cooldown_after_loss_minutes", 60))
    for trade in closed_now:
        pnl = float(trade.get("net_pnl") or 0)
        if pnl < 0 and cooldown_min > 0:
            with _LOCK:
                _STATE["cooldowns"][_cooldown_key(trade["symbol"], trade["market"])] = time.time() + cooldown_min * 60
            _log_decision("COOLDOWN", phase="manage", symbol=trade["symbol"], market=trade["market"],
                          trade_id=trade.get("id"),
                          detail=f"زیان {pnl:.2f} USDT؛ ورود جدید روی این محدوده تا {cooldown_min:.0f} دقیقه متوقف شد")
        else:
            _log_decision("AUTO_CLOSE", phase="manage", symbol=trade["symbol"], market=trade["market"],
                          trade_id=trade.get("id"),
                          detail=f"{EXIT_LABELS.get(trade.get('exit_reason'), trade.get('exit_reason'))} · خالص {pnl:+.2f} USDT")
    with _LOCK:
        _STATE["last_closed_check_ts"] = time.time()
    if closed_now:
        _persist_runtime_state()

    positions = _autopilot_open_positions(state)
    trailed = _manage_trailing(positions)
    _maybe_daily_report()
    with _LOCK:
        _STATE["cycles"] += 1
        _STATE["manage_cycles"] += 1
        _STATE["last_manage_at"] = time.time()
        _STATE["last_manage_error"] = ""
        _STATE["last_cycle_error"] = _STATE.get("last_entry_error") or ""
        entries_enabled = bool(_STATE.get("entries_enabled"))
        stop_after_flat = bool(_STATE.get("stop_after_flat"))
    # When entries are paused, the manager drains existing positions and exits
    # itself only after a successful refresh proves that the book is flat.
    if not entries_enabled and stop_after_flat and not positions:
        _finish_manager_when_flat()
    return {"duration_seconds": round(time.time() - t0, 2),
            "open_autopilot_positions": len(positions), "trailed": trailed,
            "closed_detected": len(closed_now)}


def _manager_cycle_once() -> dict:
    # The scheduled manager and the manual diagnostic tick must not refresh or
    # close the same paper position concurrently.
    with _MANAGER_CYCLE_LOCK:
        return _manager_cycle_once_impl()


@_authorized_paper_writer
def _entry_cycle_once_impl(*, allow_when_stopped: bool = False) -> dict:
    """Run one watchlist/analysis/entry pass; independent of position manager."""
    with _LOCK:
        runtime_loaded = bool(_STATE.get("runtime_state_loaded"))
        runtime_error = str(_STATE.get("runtime_state_error") or "")
        if not allow_when_stopped and not _STATE.get("entries_enabled"):
            return {"evaluated": 0, "opened": 0, "rejected": 0, "skipped": 0, "stopped": True}
    if not runtime_loaded:
        _log_decision("RUNTIME_STATE_UNAVAILABLE", phase="entry",
                      detail="وضعیت پایدار اسکن بارگذاری نشده؛ ورود جدید تا رفع مشکل متوقف است " + runtime_error,
                      level="warn")
        return {"evaluated": 0, "opened": 0, "rejected": 0, "skipped": 0,
                "stopped": True, "runtime_state_error": runtime_error}

    # Daily target is a one-way profit lock: reaching it pauses only NEW entries
    # until the next local calendar day. It does not close positions or increase
    # risk in an attempt to reach the target. Unknown PnL blocks entries.
    goal = daily_profit_goal_snapshot()
    if not goal.get("complete"):
        _log_decision("DAILY_PROFIT_GOAL_UNVERIFIED", phase="entry",
                      detail="دفتر سود روزانه قابل‌تأیید نیست؛ ورود جدید تا بازیابی دفتر مسدود شد: " +
                             str(goal.get("error") or "unknown"), level="warn")
        return {"evaluated": 0, "opened": 0, "rejected": 0, "skipped": 0,
                "profit_goal_unverified": True, "daily_profit_goal": goal}
    if goal.get("reached"):
        _log_decision("DAILY_PROFIT_GOAL_REACHED", phase="entry",
                      detail=(f"هدف سود خالص روزانهٔ {goal['target_usdt']:.2f} USDT محقق شد؛ "
                              "ورودهای جدید تا شروع روز محلی بعد متوقف می‌شوند"), level="info")
        return {"evaluated": 0, "opened": 0, "rejected": 0, "skipped": 0,
                "profit_goal_reached": True, "daily_profit_goal": goal}

    if not _persist_runtime_state():
        with _LOCK:
            runtime_error = str(_STATE.get("runtime_state_error") or "خطای ذخیره وضعیت")
        _log_decision("RUNTIME_CHECKPOINT_FAILED", phase="entry",
                      detail="ذخیرهٔ وضعیت پیش از اسکن ناموفق بود؛ ورود جدید متوقف شد " + runtime_error,
                      level="warn")
        return {"evaluated": 0, "opened": 0, "rejected": 0, "skipped": 0,
                "stopped": True, "runtime_state_error": runtime_error}
    if not _watchlist_view()["symbols"]:
        refresh_watchlist()
    result = _entry_scan(allow_when_stopped=allow_when_stopped)
    with _LOCK:
        _STATE["last_entry_scan_at"] = time.time()
        _STATE["entry_cycles"] += 1
        _STATE["last_entry_error"] = ""
    _persist_runtime_state()
    return result


def _entry_cycle_once(*, allow_when_stopped: bool = False) -> dict:
    # Prevent a manual test tick from duplicating the background entry scan.
    with _ENTRY_SCAN_LOCK:
        return _entry_cycle_once_impl(allow_when_stopped=allow_when_stopped)


def _finish_manager_when_flat() -> None:
    """Persist a fully drained/off state after a fresh quote pass proves flat."""
    global _CONFIG
    try:
        with _LOCK:
            cfg = dict(_CONFIG)
            cfg["enabled"] = False
            cfg["entries_enabled"] = False
            _save_config(cfg)
            _CONFIG = cfg
            _STATE["manager_stop_event"].set()
            _STATE["managing"] = False
        _log_decision("MANAGER_STOPPED", phase="system", detail="همهٔ موقعیت‌ها بسته شدند؛ مدیریت نیز خاموش شد")
    except Exception as exc:
        # Fail safe: keep the manager running if the disabled state could not be
        # persisted; it will retry the drain check on the next management pass.
        with _LOCK:
            _STATE["last_manage_error"] = f"ذخیره وضعیت توقف مدیریت ناموفق بود: {exc}"
        _log_decision("MANAGER_STOP_PERSIST_ERROR", phase="system", detail=str(exc), level="warn")


def _lease_heartbeat_loop(stop_event: threading.Event, owner_token: str) -> None:
    """Renew the process lease independently of slow exchange/network cycles."""
    from backend import paper_process_lease
    interval = max(2.0, _PROCESS_LEASE_TTL_SECONDS / 3.0)
    while not stop_event.wait(interval):
        try:
            result = paper_process_lease.renew_lease(_db_path(), owner_token,
                                                      ttl_seconds=_PROCESS_LEASE_TTL_SECONDS)
            if not result.get("ok"):
                raise RuntimeError("paper_autopilot_process_lease_lost")
        except Exception as exc:
            _log_decision("PROCESS_LEASE_LOST", phase="system", detail=str(exc)[:240], level="error")
            with _LOCK:
                _STATE["entries_enabled"] = False
                _STATE["running"] = False
                _STATE["last_cycle_error"] = "process_lease_lost: " + str(exc)[:180]
                _STATE["entry_stop_event"].set()
                _STATE["manager_stop_event"].set()
            return


def _manager_loop() -> None:
    global _PROCESS_LEASE_TOKEN
    stop_event = _STATE["manager_stop_event"]
    lease_token = _PROCESS_LEASE_TOKEN
    heartbeat_stop = threading.Event()
    heartbeat_thread = None
    if lease_token:
        heartbeat_thread = threading.Thread(target=_lease_heartbeat_loop,
            args=(heartbeat_stop, lease_token), name="autopilot-process-lease-heartbeat", daemon=True)
        heartbeat_thread.start()
    _log_decision("MANAGER_START", phase="system", detail="حلقهٔ مدیریت موقعیت‌های باز روشن شد")
    consecutive_errors = 0
    try:
        while not stop_event.is_set():
            try:
                _manager_cycle_once()
                consecutive_errors = 0
                wait_for = max(5, int(_CONFIG.get("manage_interval_seconds", 30)))
            except Exception as exc:
                consecutive_errors += 1
                with _LOCK:
                    _STATE["last_manage_error"] = str(exc)
                    _STATE["last_cycle_error"] = str(exc)
                _log_decision("MANAGE_ERROR", phase="manage", detail=str(exc)[:280], level="warn")
                # Management errors must not kill the manager or enable new entries.
                wait_for = min(120, max(5, 5 * consecutive_errors))
            stop_event.wait(wait_for)
    finally:
        heartbeat_stop.set()
        if heartbeat_thread is not None and heartbeat_thread is not threading.current_thread():
            heartbeat_thread.join(timeout=3.0)
        # Do not release process ownership while this process still has an entry
        # scanner capable of opening paper positions.
        with _LOCK:
            _STATE["managing"] = False
            _STATE["entry_stop_event"].set()
            entry_thread = _STATE.get("entry_thread")
        if _thread_alive(entry_thread) and entry_thread is not threading.current_thread():
            entry_thread.join(timeout=10.0)
        if lease_token:
            try:
                from backend import paper_process_lease
                paper_process_lease.release_lease(_db_path(), lease_token)
            except Exception as exc:
                _log_decision("PROCESS_LEASE_RELEASE_ERROR", phase="system", detail=str(exc)[:240], level="warn")
            finally:
                _PROCESS_LEASE_TOKEN = None
        _log_decision("MANAGER_EXIT", phase="system", detail="حلقهٔ مدیریت موقعیت‌ها متوقف شد")


def _entry_loop() -> None:
    stop_event = _STATE["entry_stop_event"]
    _log_decision("ENTRY_LOOP_START", phase="system", detail="حلقهٔ اسکن و ورود خودکار روشن شد")
    consecutive_errors = 0
    try:
        while not stop_event.is_set():
            with _LOCK:
                enabled = bool(_STATE.get("entries_enabled"))
            if not enabled:
                break
            try:
                result = _entry_cycle_once(allow_when_stopped=False)
                consecutive_errors = 0
                if result.get("stopped"):
                    break
                wait_for = max(30, int(_CONFIG.get("entry_scan_interval_seconds", 300)))
                if result.get("profit_goal_reached") or result.get("profit_goal_unverified"):
                    # Recheck periodically; at the next local day the target
                    # snapshot resets and normal entries may resume automatically.
                    wait_for = min(wait_for, 60)
            except Exception as exc:
                consecutive_errors += 1
                with _LOCK:
                    _STATE["last_entry_error"] = str(exc)
                    _STATE["last_cycle_error"] = str(exc)
                _log_decision("ENTRY_SCAN_ERROR", phase="entry", detail=str(exc)[:280], level="warn")
                wait_for = min(300, max(15, 15 * consecutive_errors))
            stop_event.wait(wait_for)
    finally:
        with _LOCK:
            _STATE["running"] = False
            # An unexpected worker exit must not leave the persisted permission
            # showing as active while no scanner is actually running.
            if _STATE.get("entries_enabled") and _STATE.get("entry_thread") is threading.current_thread():
                _STATE["entries_enabled"] = False
                try:
                    cfg = dict(_CONFIG)
                    cfg["entries_enabled"] = False
                    _save_config(cfg)
                    _CONFIG.update(cfg)
                except Exception as exc:
                    _STATE["last_entry_error"] = f"ذخیره توقف اضطراری اسکن ناموفق بود: {exc}"
        _log_decision("ENTRY_LOOP_EXIT", phase="system", detail="اسکن ورودهای جدید متوقف شد")


def _cycle_once() -> dict:
    """Synchronous complete cycle for explicit manual test/debug only."""
    t0 = time.time()
    manage_result = _manager_cycle_once()
    entry_result = _entry_cycle_once(allow_when_stopped=False)
    return {"duration_seconds": round(time.time() - t0, 2),
            "open_autopilot_positions": manage_result.get("open_autopilot_positions", 0),
            "trailed": manage_result.get("trailed", 0),
            "closed_detected": manage_result.get("closed_detected", 0),
            "entry": entry_result}


def _thread_alive(thread: Any) -> bool:
    return bool(thread is not None and thread.is_alive())


@_lifecycle_serialized
def _start_manager_worker() -> None:
    """Ensure exactly one manager worker owns the current stop event."""
    with _LOCK:
        old_thread = _STATE.get("manager_thread")
        old_event = _STATE.get("manager_stop_event")
    if _thread_alive(old_thread) and not old_event.is_set():
        return
    if _thread_alive(old_thread):
        old_thread.join(timeout=5.0)
        if _thread_alive(old_thread):
            raise RuntimeError("حلقهٔ مدیریت قبلی هنوز در حال خروج است؛ شروع مدیر دوم مجاز نیست")
    with _LOCK:
        # Recheck after the join to protect against another simultaneous start.
        current = _STATE.get("manager_thread")
        current_event = _STATE.get("manager_stop_event")
        if _thread_alive(current) and not current_event.is_set():
            return
        _STATE["manager_stop_event"] = threading.Event()
        _STATE["managing"] = True
        thread = threading.Thread(target=_manager_loop, name="autopilot-position-manager", daemon=True)
        _STATE["manager_thread"] = thread
    thread.start()


@_lifecycle_serialized
def start(resume_entries: bool = True) -> dict:
    """Start position management; optionally resume automatic new entries."""
    global _CONFIG
    _load_config()
    desired_entries = bool(resume_entries)

    # Validate the durable paper ledger before enabling any new simulated entry.
    # A damaged/inconsistent ledger is never silently repaired or guessed at.
    ledger_validation = None
    if desired_entries:
        try:
            from backend import paper_live
            ledger_validation = paper_live.validate_paper_ledger()
        except Exception as exc:
            ledger_validation = {"valid": False, "errors": [f"ledger_validation_error:{str(exc)[:240]}"],
                                "blocks_new_entries": True}
        if not ledger_validation.get("valid"):
            _log_decision("PAPER_LEDGER_RECOVERY_BLOCKED", phase="system",
                          detail="دفتر معاملات آزمایشی از آزمون یکپارچگی عبور نکرد؛ ورود جدید مسدود شد: " +
                                 ",".join(ledger_validation.get("errors") or []), level="error")
            return {"ok": False, "blocked": True, "entries_enabled": False,
                    "recovery_validation": ledger_validation, "state": status()}

    # A durable SQLite lease prevents a second OS process from starting another
    # AutoPilot manager/scanner against the same paper ledger.
    global _PROCESS_LEASE_TOKEN
    try:
        from backend import paper_process_lease
        if _PROCESS_LEASE_TOKEN:
            lease_result = paper_process_lease.renew_lease(
                _db_path(), _PROCESS_LEASE_TOKEN, ttl_seconds=_PROCESS_LEASE_TTL_SECONDS)
            if not lease_result.get("ok"):
                _PROCESS_LEASE_TOKEN = None
        if not _PROCESS_LEASE_TOKEN:
            lease_result = paper_process_lease.claim_lease(
                _db_path(), ttl_seconds=_PROCESS_LEASE_TTL_SECONDS)
            if not lease_result.get("ok"):
                return {"ok": False, "blocked": True, "reason": "autopilot_process_lease_held",
                        "lease": lease_result, "state": status()}
            _PROCESS_LEASE_TOKEN = lease_result["owner_token"]
    except Exception as exc:
        return {"ok": False, "blocked": True, "reason": "autopilot_process_lease_error",
                "error": str(exc)[:240], "state": status()}

    # A paused scanner may still be unwinding one network request. Wait for it
    # before installing a new event/thread pair; never create two scanners.
    with _LOCK:
        old_entry = _STATE.get("entry_thread")
        old_entry_event = _STATE.get("entry_stop_event")
    if _thread_alive(old_entry) and old_entry_event.is_set():
        old_entry.join(timeout=10.0)
        if _thread_alive(old_entry):
            raise RuntimeError("حلقهٔ قبلی اسکن هنوز متوقف نشده است؛ شروع دوباره برای جلوگیری از اسکن تکراری رد شد")

    entry = None
    with _ENTRY_EXEC_LOCK:
        with _LOCK:
            cfg = dict(_CONFIG)
            cfg["enabled"] = True
            cfg["entries_enabled"] = desired_entries
            _save_config(cfg)
            _CONFIG = cfg
            _STATE["entries_enabled"] = desired_entries
            _STATE["running"] = desired_entries
            _STATE["stop_after_flat"] = not desired_entries
            if _STATE["started_at"] is None or not desired_entries:
                _STATE["started_at"] = time.time()

            current_entry = _STATE.get("entry_thread")
            current_entry_event = _STATE.get("entry_stop_event")
            if desired_entries:
                if not _thread_alive(current_entry):
                    _STATE["entry_stop_event"] = threading.Event()
                    _STATE["stop_event"] = _STATE["entry_stop_event"]
                    entry = threading.Thread(target=_entry_loop, name="autopilot-entry-scanner", daemon=True)
                    _STATE["entry_thread"] = entry
                    _STATE["thread"] = entry
            else:
                current_entry_event.set()
                _STATE["stop_event"] = current_entry_event
                _STATE["thread"] = current_entry

        _start_manager_worker()
        if entry is not None:
            entry.start()

    _log_decision("STARTED", phase="system",
                  detail="ورود و مدیریت خودکار فعال شد" if desired_entries else "فقط مدیریت موقعیت‌های باز فعال شد")
    return {"ok": True, "already_running": entry is None and desired_entries,
            "recovery_validation": ledger_validation, "state": status()}


@_lifecycle_serialized
@_authorized_paper_writer
def stop(close_all: bool = False) -> dict:
    """Pause entries; keep manager alive until existing autopilot positions are flat.

    With close_all=True, try to close every open autopilot position now. If any
    cannot close (e.g. exchange quote unavailable), the manager remains active
    and continues stop/target/trailing checks until those positions are closed.
    """
    global _CONFIG
    closed: list[dict] = []
    # Wait for any already-authorized simulated open to finish before disabling
    # entries, so stop() has a strong no-more-new-positions guarantee.
    with _ENTRY_EXEC_LOCK:
        with _LOCK:
            _STATE["entries_enabled"] = False
            _STATE["running"] = False
            _STATE["entry_stop_event"].set()
            _STATE["stop_event"] = _STATE["entry_stop_event"]
            entry_thread = _STATE.get("entry_thread")
            cfg = dict(_CONFIG)
            cfg["entries_enabled"] = False
            cfg["enabled"] = True  # manager service remains enabled while draining
            try:
                _save_config(cfg)
                _CONFIG = cfg
            except Exception as exc:
                _STATE["last_entry_error"] = f"توقف ورود انجام شد، اما ذخیره وضعیت ناموفق بود: {exc}"
                _log_decision("STOP_CONFIG_PERSIST_ERROR", phase="system", detail=str(exc), level="warn")
    if _thread_alive(entry_thread) and entry_thread is not threading.current_thread():
        entry_thread.join(timeout=3.0)

    from backend import paper_live
    try:
        state = paper_live.get_state(refresh_quotes=bool(close_all))
    except Exception as exc:
        state = paper_live.get_state(refresh_quotes=False)
        _log_decision("STOP_STATE_ERROR", phase="manage", detail=str(exc), level="warn")
    positions = _autopilot_open_positions(state)
    if close_all:
        for pos in positions:
            try:
                result = paper_live.close_position(int(pos["id"]))
                closed.append({"id": pos["id"], "symbol": pos["symbol"], "net_pnl": result.get("net_pnl")})
                _log_decision("CLOSE_ON_STOP", phase="manage", symbol=pos["symbol"],
                              market=pos["market"], trade_id=pos["id"],
                              detail=f"بستن هنگام توقف · خالص {float(result.get('net_pnl') or 0):+.2f} USDT")
            except Exception as exc:
                _log_decision("CLOSE_ON_STOP_ERROR", phase="manage", symbol=pos.get("symbol", ""),
                              market=pos.get("market", ""), trade_id=pos.get("id"),
                              detail=str(exc), level="warn")
        try:
            state = paper_live.get_state(refresh_quotes=False)
            positions = _autopilot_open_positions(state)
        except Exception:
            pass

    with _LOCK:
        manager_thread = _STATE.get("manager_thread")
        _STATE["stop_after_flat"] = True
    if not positions:
        _finish_manager_when_flat()
    else:
        if not _thread_alive(manager_thread) or _STATE["manager_stop_event"].is_set():
            _start_manager_worker()
        _log_decision("MANAGER_DRAINING", phase="system", detail=
                      f"ورود جدید متوقف شد؛ مدیریت {len(positions)} موقعیت باز ادامه دارد")

    try:
        report = build_report("session")
        if report["stats"]["trades"] > 0:
            _save_daily_report({**report, "period": {"kind": "session", "day": _day_key(),
                "since": report["period"]["since"], "until": report["period"]["until"]}})
    except Exception:
        pass
    _log_decision("ENTRIES_PAUSED", phase="system", detail=
                  f"ورودهای جدید متوقف شد؛ {len(positions)} موقعیت برای مدیریت باقی مانده است")
    return {"ok": True, "entries_stopped": True, "closed": closed,
            "remaining_positions": len(positions), "managing": bool(positions),
            "full_stop": not bool(positions), "state": status()}

def update_config(patch: dict) -> dict:
    global _CONFIG
    if not isinstance(patch, dict):
        raise ValueError("بدنهٔ تنظیمات نامعتبر است")
    unknown = sorted(k for k in patch if k not in DEFAULT_CONFIG)
    if unknown:
        raise ValueError("تنظیمات ناشناخته: " + ", ".join(unknown))
    with _LOCK:
        cfg = dict(_CONFIG)
        preset = patch.get("risk_preset")
        if preset is not None:
            preset = _config_value("risk_preset", preset)
            if preset in RISK_PRESETS:
                cfg.update(RISK_PRESETS[preset])
            cfg["risk_preset"] = preset
        # Validate all patch fields before changing/persisting anything.
        for key, raw in patch.items():
            if key == "risk_preset":
                continue
            cfg[key] = _config_value(key, raw)

        risk_keys = tuple(RISK_PRESETS["balanced"].keys())
        explicitly_edited_risk = any(k in patch for k in risk_keys)
        if preset == "custom":
            cfg["risk_preset"] = "custom"
        elif preset in RISK_PRESETS:
            # The UI sends current values along with preset. If a user has
            # manually changed any preset-controlled value, label it custom.
            preset_values = RISK_PRESETS[preset]
            if explicitly_edited_risk and any(cfg.get(k) != preset_values[k] for k in risk_keys):
                cfg["risk_preset"] = "custom"
            else:
                cfg["risk_preset"] = preset
        elif explicitly_edited_risk:
            cfg["risk_preset"] = "custom"

        old_balance = float(_CONFIG.get("daily_start_balance", 1000.0))
        new_balance = float(cfg.get("daily_start_balance", old_balance))
        balance_changed = not math.isclose(old_balance, new_balance, rel_tol=0.0, abs_tol=1e-9)
        paper_live = None
        if balance_changed:
            # Changing account capital while workers or positions are active
            # would rebase risk budgets underneath live PAPER positions.
            with _LOCK:
                workers_active = (_thread_alive(_STATE.get("entry_thread"))
                                  or _thread_alive(_STATE.get("manager_thread")))
            if workers_active:
                raise ValueError("برای تغییر سرمایه، ابتدا موتور را کاملاً متوقف کن و صبر کن مدیریت موقعیت‌ها هم پایان یابد")
            from backend import paper_live as _paper_live
            paper_live = _paper_live
            paper_live.init_db()
            if paper_live.list_trades(status="OPEN", limit=None):
                raise ValueError("تا وقتی موقعیت آزمایشی باز داری، سرمایهٔ حساب قابل تغییر نیست؛ ابتدا موقعیت‌ها را ببند")
            paper_live.SETTINGS["initial_balance"] = new_balance
            try:
                paper_live.init_db()
                ledger_check = paper_live.reconcile_account_equity()
                if not ledger_check.get("valid"):
                    raise ValueError("پس از تغییر سرمایه، تطبیق دفتر حساب آزمایشی نامعتبر شد؛ تغییر لغو شد")
            except Exception:
                paper_live.SETTINGS["initial_balance"] = old_balance
                paper_live.init_db()
                raise

        try:
            _save_config(cfg)
        except Exception:
            if balance_changed and paper_live is not None:
                paper_live.SETTINGS["initial_balance"] = old_balance
                paper_live.init_db()
            raise
        _CONFIG = cfg
        if paper_live is not None:
            paper_live.SETTINGS["initial_balance"] = new_balance
    _log_decision("CONFIG_UPDATED", phase="system",
                  detail="تنظیمات ذخیره‌شده: " + json.dumps(cfg, ensure_ascii=False, sort_keys=True))
    return status()



@_lifecycle_serialized
def shutdown(timeout: float = 8.0) -> dict:
    """Stop all AutoPilot workers without closing paper positions.

    Existing positions remain in the paper ledger. On next boot the normal
    startup path restores the checkpoint and starts management-only mode.
    New entries are always disabled before any worker is signalled.
    """
    global _CONFIG
    timeout = max(0.0, min(float(timeout), 30.0))
    with _ENTRY_EXEC_LOCK:
        with _LOCK:
            _STATE["entries_enabled"] = False
            _STATE["running"] = False
            entry_event = _STATE.get("entry_stop_event")
            manager_event = _STATE.get("manager_stop_event")
            if entry_event is not None:
                entry_event.set()
            if manager_event is not None:
                manager_event.set()
            entry_thread = _STATE.get("entry_thread")
            manager_thread = _STATE.get("manager_thread")
            cfg = dict(_CONFIG)
            cfg["entries_enabled"] = False
            # Keep the service enabled only when an open paper position needs
            # management after restart. Never auto-resume fresh entries.
            try:
                from backend import paper_live
                paper_state = paper_live.get_state(refresh_quotes=False)
                open_positions = _autopilot_open_positions(paper_state)
            except Exception as exc:
                open_positions = None
                _STATE["last_manage_error"] = f"وضعیت موقعیت‌ها هنگام خاموشی نامشخص است: {exc}"
            cfg["enabled"] = bool(open_positions) if open_positions is not None else True
            _save_config(cfg)
            _CONFIG = cfg
            _STATE["stop_after_flat"] = True
    deadline = time.monotonic() + timeout
    for worker in (entry_thread, manager_thread):
        if _thread_alive(worker) and worker is not threading.current_thread():
            worker.join(timeout=max(0.0, deadline - time.monotonic()))
    checkpoint_ok = _persist_runtime_state()
    with _LOCK:
        _STATE["managing"] = False if not _thread_alive(manager_thread) else _STATE.get("managing", False)
        remaining = {
            "entry": _thread_alive(entry_thread),
            "manager": _thread_alive(manager_thread),
        }
    _log_decision("GRACEFUL_SHUTDOWN", phase="system",
                  detail=f"خاموشی کنترل‌شده؛ ورود جدید غیرفعال؛ checkpoint={'ok' if checkpoint_ok else 'failed'}")
    return {"ok": checkpoint_ok and not any(remaining.values()),
            "checkpoint_saved": checkpoint_ok, "workers_alive": remaining,
            "open_positions_detected": None if open_positions is None else len(open_positions),
            "position_check_error": bool(open_positions is None),
            "entries_enabled": False, "restart_mode": "manage_only" if cfg["enabled"] else "stopped"}

def status() -> dict:
    from backend import paper_live
    with _LOCK:
        entry_alive = _thread_alive(_STATE.get("entry_thread")) and bool(_STATE.get("entries_enabled"))
        manager_alive = _thread_alive(_STATE.get("manager_thread")) and not _STATE["manager_stop_event"].is_set()
        running = entry_alive
        started_at = _STATE["started_at"]
        cycles = _STATE["cycles"]
        manage_cycles = _STATE.get("manage_cycles", 0)
        entry_cycles = _STATE.get("entry_cycles", 0)
        last_manage_at = _STATE["last_manage_at"]
        last_error = _STATE["last_cycle_error"]
        last_manage_error = _STATE.get("last_manage_error", "")
        last_entry_error = _STATE.get("last_entry_error", "")
        entries_enabled = bool(entry_alive)
        entry_permission = bool(_STATE.get("entries_enabled"))
        entry_worker = _STATE.get("entry_thread")
        manager_worker = _STATE.get("manager_thread")
        worker_snapshot = {
            "entry": {"alive": _thread_alive(entry_worker),
                      "name": entry_worker.name if entry_worker else None,
                      "ident": entry_worker.ident if entry_worker else None},
            "manager": {"alive": _thread_alive(manager_worker),
                        "name": manager_worker.name if manager_worker else None,
                        "ident": manager_worker.ident if manager_worker else None},
        }
        decisions = list(_STATE["decisions"])[-80:]
        last_entry_summary = dict(_STATE.get("last_entry_summary") or {})
        cooldowns = {k: max(0.0, v - time.time()) for k, v in _STATE["cooldowns"].items() if v > time.time()}
        cfg = dict(_CONFIG)
        overrides = _risk_overrides()
    try:
        state = paper_live.get_state(refresh_quotes=False)
        account = state.get("account") or {}
        # The shared paper-live view uses its manual-entry defaults. AutoPilot
        # may be on a different persisted preset, so expose the actual limits
        # used by its entry engine in the AutoPilot status payload.
        risk_view = account.get("portfolio_risk")
        if isinstance(risk_view, dict):
            risk_base = account.get("equity")
            if risk_base is None:
                risk_base = account.get("known_realized_equity") or _CONFIG.get("daily_start_balance", 1000.0)
            try:
                risk_base = float(risk_base)
                if not math.isfinite(risk_base) or risk_base <= 0:
                    risk_base = float(_CONFIG.get("daily_start_balance", 1000.0))
            except (TypeError, ValueError):
                risk_base = float(_CONFIG.get("daily_start_balance", 1000.0))
            risk_limits = {
                "portfolio": float(overrides.get("max_portfolio_risk_pct", 2.0)),
                "spot": float(overrides.get("max_spot_risk_pct", 1.5)),
                "perp": float(overrides.get("max_perp_risk_pct", 1.0)),
                "directional": float(overrides.get("max_directional_risk_pct", 1.5)),
            }
            risk_view.update({
                "policy_source": "autopilot_persisted_config",
                "portfolio_cap_pct": risk_limits["portfolio"],
                "portfolio_cap_usdt": risk_base * risk_limits["portfolio"] / 100.0,
                "spot_cap_pct": risk_limits["spot"],
                "spot_cap_usdt": risk_base * risk_limits["spot"] / 100.0,
                "perp_cap_pct": risk_limits["perp"],
                "perp_cap_usdt": risk_base * risk_limits["perp"] / 100.0,
                "directional_cap_pct": risk_limits["directional"],
                "directional_cap_usdt": risk_base * risk_limits["directional"] / 100.0,
            })
            if risk_view.get("complete"):
                risk_view["remaining_portfolio_usdt"] = max(0.0, risk_view["portfolio_cap_usdt"] - float(risk_view.get("total") or 0.0))
                risk_view["remaining_spot_usdt"] = max(0.0, risk_view["spot_cap_usdt"] - float((risk_view.get("by_market") or {}).get("spot", 0.0)))
                risk_view["remaining_perp_usdt"] = max(0.0, risk_view["perp_cap_usdt"] - float((risk_view.get("by_market") or {}).get("perp", 0.0)))
                risk_view["remaining_long_usdt"] = max(0.0, risk_view["directional_cap_usdt"] - float((risk_view.get("by_side") or {}).get("LONG", 0.0)))
                risk_view["remaining_short_usdt"] = max(0.0, risk_view["directional_cap_usdt"] - float((risk_view.get("by_side") or {}).get("SHORT", 0.0)))
        ap_positions = _autopilot_open_positions(state)
        recent = [t for t in (state.get("recent_trades") or [])
                  if str((lambda s: (json.loads(s) if s else {}).get("entry_source", ""))(
                      t.get("entry_context_json") or "")) == "autopilot"][:20]
    except Exception as exc:
        account, ap_positions, recent = {"error": str(exc)}, [], []
    session_stats = None
    try:
        session_stats = _stats_from_trades(_closed_autopilot_trades(since=started_at or 0.0))
    except Exception:
        pass
    daily_goal = daily_profit_goal_snapshot()
    return {
        "version": VERSION, "running": running, "entries_enabled": entries_enabled,
        "entry_permission": entry_permission, "managing": manager_alive, "management_mode": "ACTIVE" if manager_alive and entries_enabled else ("DRAINING" if manager_alive else "STOPPED"),
        "cycles": cycles, "manage_cycles": manage_cycles, "entry_cycles": entry_cycles,
        "workers": worker_snapshot,
        "started_at": started_at, "last_manage_at": last_manage_at,
        "last_manage_error": last_manage_error, "last_entry_error": last_entry_error,
        "last_cycle_error": last_error, "config": cfg, "risk_overrides": overrides,
        "watchlist": _watchlist_view(), "cooldowns": cooldowns,
        "last_entry_summary": last_entry_summary,
        "runtime_state": {"loaded": bool(_STATE.get("runtime_state_loaded")),
                          "saved_at": float(_STATE.get("runtime_state_saved_at") or 0.0),
                          "error": str(_STATE.get("runtime_state_error") or "")},
        "account": account, "open_positions": ap_positions, "recent_trades": recent,
        "session_stats": session_stats,
        "daily_profit_goal": daily_goal,
        "decisions": decisions,
        "safety": {"paper_only": True, "real_orders_enabled": False, "public_market_data_only": True},
    }


@_lifecycle_serialized
def run_manual_cycle() -> dict:
    """Run one isolated PAPER cycle only when no background AutoPilot owns the ledger.

    The transient SQLite lease makes the UI/debug tick mutually exclusive with
    other OS processes. Within this process, lifecycle and manual-cycle locks
    prevent overlap with start/stop and with another manual tick.
    """
    global _PROCESS_LEASE_TOKEN
    if not _MANUAL_CYCLE_LOCK.acquire(blocking=False):
        return {"ok": False, "blocked": True, "reason": "manual_cycle_already_running",
                "state": status()}

    lease_token = None
    heartbeat_stop = threading.Event()
    heartbeat_thread = None
    try:
        with _LOCK:
            manager_thread = _STATE.get("manager_thread")
            entry_thread = _STATE.get("entry_thread")
            background_active = (_thread_alive(manager_thread) or _thread_alive(entry_thread)
                                 or bool(_PROCESS_LEASE_TOKEN))
        if background_active:
            return {"ok": False, "blocked": True,
                    "reason": "autopilot_background_worker_active", "state": status()}

        # Claim a short-lived lease for this one-shot cycle. It is not an order
        # permission; it only serializes access to the PAPER ledger.
        try:
            from backend import paper_process_lease
            claimed = paper_process_lease.claim_lease(_db_path(), ttl_seconds=_PROCESS_LEASE_TTL_SECONDS)
            if not claimed.get("ok"):
                return {"ok": False, "blocked": True,
                        "reason": "autopilot_process_lease_held", "lease": claimed,
                        "state": status()}
            lease_token = claimed["owner_token"]
        except Exception as exc:
            return {"ok": False, "blocked": True,
                    "reason": "autopilot_process_lease_error", "error": str(exc)[:240],
                    "state": status()}

        heartbeat_thread = threading.Thread(
            target=_lease_heartbeat_loop, args=(heartbeat_stop, lease_token),
            name="autopilot-manual-cycle-lease-heartbeat", daemon=True)
        heartbeat_thread.start()
        if not _watchlist_view()["symbols"]:
            refresh_watchlist()
        result = _cycle_once()
        return {"ok": True, "cycle": result, "state": status()}
    finally:
        heartbeat_stop.set()
        if heartbeat_thread is not None and heartbeat_thread is not threading.current_thread():
            heartbeat_thread.join(timeout=3.0)
        if lease_token:
            try:
                from backend import paper_process_lease
                paper_process_lease.release_lease(_db_path(), lease_token)
            except Exception as exc:
                _log_decision("MANUAL_CYCLE_LEASE_RELEASE_ERROR", phase="system",
                              detail=str(exc)[:240], level="warn")
        _MANUAL_CYCLE_LOCK.release()


# Boot-time load
_load_config()
_load_runtime_state()
