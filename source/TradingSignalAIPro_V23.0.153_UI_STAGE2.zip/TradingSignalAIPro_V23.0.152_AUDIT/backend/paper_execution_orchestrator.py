"""V23.0.80 explicitly armed paper-only execution bridge.

This module delegates fills, sizing, portfolio guards, persistence and lifecycle
management to backend.paper_live. It never accesses private exchange APIs.
"""
from __future__ import annotations

import re

VERSION = "23.0.80"
_ALLOWED_DECISIONS = {"PAPER_BUY_CANDIDATE": "LONG", "PAPER_SELL_CANDIDATE": "SHORT"}
_KEY_RE = re.compile(r"^[A-Za-z0-9:_|.\-]{8,180}$")


def execute_paper_candidates(candidates, *, confirm_paper_execution=False):
    if not isinstance(candidates, list):
        raise ValueError("candidates must be a list")
    if len(candidates) > 20:
        raise ValueError("حداکثر ۲۰ نامزد در هر درخواست مجاز است")
    if confirm_paper_execution is not True:
        return {
            "version": VERSION, "status": "ARMING_REQUIRED", "count": 0,
            "results": [], "paper_only": True, "capital_usdt": 1000,
            "real_orders_enabled": False, "creates_orders": False,
            "execution_authorized": False,
            "message": "برای ایجاد موقعیت شبیه‌سازی‌شده، تأیید صریح confirm_paper_execution=true لازم است.",
        }
    from backend.paper_live import open_position

    results = []
    seen_keys = set()
    seen_symbols = set()
    for raw in candidates:
        if not isinstance(raw, dict):
            results.append({"status": "REJECTED", "reason": "INVALID_CANDIDATE", "creates_orders": False})
            continue
        symbol = str(raw.get("symbol") or "").upper().replace("/", "").strip()
        decision = str(raw.get("decision") or "").upper().strip()
        side = _ALLOWED_DECISIONS.get(decision)
        score = raw.get("score")
        coverage = raw.get("coverage_pct")
        conflict = raw.get("conflict_ratio")
        blockers = raw.get("risk_blockers") or []
        key = str(raw.get("idempotency_key") or "").strip()
        try:
            score, coverage, conflict = float(score), float(coverage), float(conflict)
        except (TypeError, ValueError, OverflowError):
            score = coverage = conflict = None
        reason = None
        if not symbol or not re.fullmatch(r"[A-Z0-9]{3,24}", symbol):
            reason = "INVALID_SYMBOL"
        elif side is None:
            reason = "DECISION_NOT_EXECUTABLE"
        elif score is None or coverage is None or conflict is None:
            reason = "MISSING_DECISION_EVIDENCE"
        elif not (score >= 75 and 0 <= coverage <= 100 and coverage >= 65 and 0 <= conflict <= 0.2):
            reason = "DECISION_THRESHOLDS_NOT_MET"
        elif blockers:
            reason = "RISK_BLOCKERS_PRESENT"
        elif not _KEY_RE.fullmatch(key):
            reason = "VALID_IDEMPOTENCY_KEY_REQUIRED"
        if reason is None and key in seen_keys:
            reason = "DUPLICATE_IDEMPOTENCY_KEY_IN_BATCH"
        if reason is None and symbol in seen_symbols:
            reason = "DUPLICATE_SYMBOL_IN_BATCH"
        if reason:
            results.append({"symbol": symbol, "status": "REJECTED", "reason": reason,
                            "creates_position": False, "creates_orders": False})
            continue
        seen_keys.add(key)
        seen_symbols.add(symbol)
        try:
            result = open_position(
                symbol=symbol, side=side,
                market=str(raw.get("market") or "spot").lower(),
                exchange=str(raw.get("exchange") or "auto").lower(),
                timeframe=str(raw.get("timeframe") or "1h").lower(),
                entry_source="v23.0.80_ai_decision_engine",
                decision_context={"decision": decision, "score": score,
                                  "coverage_pct": coverage, "conflict_ratio": conflict,
                                  "risk_blockers": blockers, "paper_only": True},
                idempotency_key=key,
                atr_value=raw.get("atr"),
            )
            results.append({"symbol": symbol,
                            "status": "IDEMPOTENT_REPLAY" if result.get("idempotent_replay") else "PAPER_POSITION_OPENED",
                            "position": result, "creates_position": not bool(result.get("idempotent_replay")),
                            "creates_orders": False, "real_orders_enabled": False})
        except Exception as exc:
            results.append({"symbol": symbol, "status": "NOT_OPENED", "reason": str(exc)[:240],
                            "creates_position": False, "creates_orders": False})

    opened = sum(1 for x in results if x["status"] == "PAPER_POSITION_OPENED")
    replayed = sum(1 for x in results if x["status"] == "IDEMPOTENT_REPLAY")
    return {"version": VERSION, "status": "COMPLETED", "count": len(results),
            "opened": opened, "idempotent_replays": replayed, "results": results,
            "paper_only": True, "capital_usdt": 1000,
            "real_orders_enabled": False, "creates_orders": False,
            "execution_authorized": False,
            "disclaimer": "فقط موقعیت محلی شبیه‌سازی‌شده ایجاد می‌شود؛ هیچ سفارش واقعی به صرافی ارسال نمی‌شود."}
