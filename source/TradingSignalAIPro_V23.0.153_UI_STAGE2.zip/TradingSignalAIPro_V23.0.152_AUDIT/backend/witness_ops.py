"""Operational export, verification, checkpoint and recovery tools for Witness."""
from __future__ import annotations
import base64, hashlib, json, os, shutil, sqlite3, tempfile
from datetime import datetime, timezone
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from backend.witness_server import SCHEMA, canonical, verify_anchor_record

OPS_SCHEMA = 'ts-ai-witness-ops-v1'
ZERO_HASH = '0' * 64

def _pub(path):
    key=serialization.load_pem_public_key(Path(path).read_bytes())
    if not isinstance(key, Ed25519PublicKey): raise ValueError('witness_key_type_invalid')
    return key

def _records(db_path):
    with sqlite3.connect(db_path) as db:
        db.row_factory=sqlite3.Row
        return [dict(r) for r in db.execute('SELECT sequence,witness_id,schema_version,anchor_digest,anchor_json,timestamp,signature FROM anchors ORDER BY sequence')]

def export_receipts(db_path, public_key_path, output_path):
    rows=_records(db_path); previous=ZERO_HASH; lines=[]
    for expected,row in enumerate(rows,1):
        receipt={k:row[k] for k in ('schema_version','witness_id','anchor_digest','sequence','timestamp','signature')}
        if row['sequence'] != expected: raise ValueError('witness_sequence_gap')
        if row['schema_version'] != SCHEMA: raise ValueError('witness_schema_unsupported')
        if hashlib.sha256(row['anchor_json'].encode('utf-8')).hexdigest() != row['anchor_digest']: raise ValueError('witness_anchor_payload_digest_mismatch')
        verify_anchor_record(receipt,public_key_path)
        chain_hash=hashlib.sha256(bytes.fromhex(previous)+canonical(receipt)).hexdigest()
        entry={'receipt':receipt,'previous_hash':previous,'record_hash':chain_hash}
        lines.append(canonical(entry)); previous=chain_hash
    body=b'\n'.join(lines)+(b'\n' if lines else b'')
    out=Path(output_path); out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists(): raise FileExistsError('export_destination_exists')
    tmp=out.with_name(out.name+'.tmp')
    fd=os.open(str(tmp),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        with os.fdopen(fd,'wb') as f: f.write(body); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,out)
    except Exception:
        try: tmp.unlink()
        except OSError: pass
        raise
    return {'path':str(out),'records':len(rows),'head_sequence':len(rows),'head_hash':previous,'export_sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}

def verify_receipt_export(export_path, public_key_path):
    previous=ZERO_HASH; count=0
    raw=Path(export_path).read_bytes()
    for line in raw.splitlines():
        entry=json.loads(line); receipt=entry['receipt']
        if entry.get('previous_hash') != previous: raise ValueError('witness_export_previous_hash_mismatch')
        if receipt.get('sequence') != count+1: raise ValueError('witness_export_sequence_gap')
        verify_anchor_record(receipt,public_key_path)
        actual=hashlib.sha256(bytes.fromhex(previous)+canonical(receipt)).hexdigest()
        if entry.get('record_hash') != actual: raise ValueError('witness_export_record_hash_mismatch')
        previous=actual; count+=1
    return {'valid':True,'records':count,'head_sequence':count,'head_hash':previous,'export_sha256':hashlib.sha256(raw).hexdigest()}

def create_checkpoint(export_path, private_key_path, public_key_path, output_path, *, witness_id='ts-ai-witness'):
    verified=verify_receipt_export(export_path, public_key_path)
    payload={'schema_version':OPS_SCHEMA,'witness_id':witness_id,'head_sequence':verified['head_sequence'],'head_hash':verified['head_hash'],'export_sha256':verified['export_sha256'],'created_at':datetime.now(timezone.utc).isoformat()}
    key=serialization.load_pem_private_key(Path(private_key_path).read_bytes(),password=None)
    if not isinstance(key,Ed25519PrivateKey): raise ValueError('witness_key_type_invalid')
    checkpoint={**payload,'signature':base64.b64encode(key.sign(canonical(payload))).decode('ascii')}
    out=Path(output_path); out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists(): raise FileExistsError('checkpoint_destination_exists')
    tmp=out.with_name(out.name+'.tmp'); tmp.write_bytes(canonical(checkpoint)); os.replace(tmp,out)
    return checkpoint

def verify_checkpoint(checkpoint_path, public_key_path, export_path):
    checkpoint=json.loads(Path(checkpoint_path).read_text(encoding='utf-8'))
    payload={k:checkpoint[k] for k in ('schema_version','witness_id','head_sequence','head_hash','export_sha256','created_at')}
    if payload['schema_version'] != OPS_SCHEMA: raise ValueError('checkpoint_schema_unsupported')
    _pub(public_key_path).verify(base64.b64decode(checkpoint['signature'],validate=True),canonical(payload))
    exported=verify_receipt_export(export_path,public_key_path)
    for k in ('head_sequence','head_hash','export_sha256'):
        if payload[k] != exported[k]: raise ValueError('checkpoint_export_mismatch')
    return {'valid':True,**{k:payload[k] for k in ('witness_id','head_sequence','head_hash','export_sha256')}}

def health_diagnostics(db_path, public_key_path):
    p=Path(db_path)
    if not p.exists(): return {'healthy':False,'errors':['database_missing']}
    errors=[]
    try:
        with sqlite3.connect(p) as db:
            integrity=db.execute('PRAGMA integrity_check').fetchone()[0]
            if integrity!='ok': errors.append('sqlite_integrity_failed')
            count=db.execute('SELECT COUNT(*) FROM anchors').fetchone()[0]
            lo,hi=db.execute('SELECT MIN(sequence),MAX(sequence) FROM anchors').fetchone()
            if count and (lo!=1 or hi!=count): errors.append('sequence_gap_or_rollback')
            triggers={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='trigger'")}
            if not {'anchors_no_update','anchors_no_delete'}.issubset(triggers): errors.append('append_only_triggers_missing')
        with tempfile.TemporaryDirectory() as td:
            export=Path(td)/'receipts.jsonl'; export_receipts(p,public_key_path,export)
            verification=verify_receipt_export(export,public_key_path)
    except Exception as exc:
        errors.append(f'{type(exc).__name__}:{exc}'); verification=None; integrity='error'; count=0
    return {'healthy':not errors,'errors':errors,'sqlite_integrity':integrity,'records':count,'chain_verification':verification}

def restore_database(backup_path, destination_path, public_key_path):
    src,dst=Path(backup_path),Path(destination_path)
    if not src.is_file(): raise FileNotFoundError('witness_backup_missing')
    if dst.exists(): raise FileExistsError('restore_destination_exists')
    with sqlite3.connect(src) as db:
        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok': raise ValueError('witness_backup_integrity_failed')
    report=health_diagnostics(src,public_key_path)
    if not report['healthy']: raise ValueError('witness_backup_verification_failed:'+','.join(report['errors']))
    dst.parent.mkdir(parents=True,exist_ok=True)
    tmp=dst.with_name(dst.name+'.restore.tmp')
    shutil.copy2(src,tmp)
    with sqlite3.connect(tmp) as db:
        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok': raise ValueError('witness_restore_integrity_failed')
    os.replace(tmp,dst)
    return {'restored':True,'path':str(dst),'records':report['records'],'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()}
