"""
Feature engineering - converts raw candles + indicators into model features.
Builds 80+ features combining multiple indicator families and lookback windows.

Label strategy: predict whether price will be HIGHER after HORIZON candles
by more than NOISE_FRACTION * ATR. Rows where |return| < threshold are
excluded from training (the model only learns from meaningful moves).
"""
import warnings
import os

import numpy as np
import pandas as pd
from .indicators import all_indicators, ema, atr, rsi
from .divergence import divergence_feature_series
from .trade_contract import (ATR_TP_MULT, ATR_SL_MULT, TRADE_HORIZON_BARS,
                             TRAIL_TRIGGER_PCT, TRAIL_DISTANCE_PCT)
from .execution_model import round_trip_cost_pct

# Building 130+ feature columns one-by-one triggers pandas' DataFrame
# fragmentation PerformanceWarning on every insert; it is harmless here.
warnings.filterwarnings('ignore', message='DataFrame is highly fragmented')

# --- Label configuration ---
HORIZON = 3                # fallback horizon for raw forward return
NOISE_FRACTION = 0.5       # fallback noise filter fraction

# Triple-barrier labeling (López de Prado style):
# label 1 if upper barrier (+UP_MULT × ATR) is hit BEFORE lower barrier,
# label 0 if lower barrier (-DN_MULT × ATR) hit first,
# NaN (dropped) if neither hit within TB_HORIZON bars.
# AMBIGUOUS candles: if BOTH barriers are touched inside the SAME candle,
# the intrabar order is unknowable from OHLC — such rows get NaN labels
# and are flagged in a separate mask, excluded from training AND stats.
# TB(1.5, 1.5, 12) was selected by a measured experiment (see docs):
# short horizon + meaningful barriers = cleaner labels, ~80% coverage,
# and the best honest out-of-sample accuracy (val≈test, no overfit gap).
TB_UP_MULT = ATR_TP_MULT
TB_DN_MULT = ATR_SL_MULT
TB_HORIZON = TRADE_HORIZON_BARS

# Increment when feature meaning/order changes; old models must be retrained.
# V19 (schema 5): adds causal divergence features (RSI/MACD vs price pivots)
# and volume-dynamics features. Models saved with schema <= 4 must be retrained.
FEATURE_SCHEMA_VERSION = 8   # Stage1M: net-of-assumed-execution-cost outcome labels


def triple_barrier_labels(ind: pd.DataFrame, up_mult: float = TB_UP_MULT,
                          dn_mult: float = TB_DN_MULT,
                          horizon: int = TB_HORIZON,
                          return_details: bool = False,
                          execution_cost_pct: float = 0.0) -> tuple:
    """Create long-side labels using the PAPER barrier lifecycle.

    The fixed ATR target/stop are checked before updating the trailing stop,
    matching the backtest's candle ordering. A newly tightened trailing stop
    becomes active on the next candle. If no barrier is touched during a fully
    observed horizon, the timeout is labelled by the direction of the final
    close relative to entry. A candle touching both active barriers is
    ambiguous and remains excluded.
    """
    cost_pct = float(execution_cost_pct)
    if not np.isfinite(cost_pct) or cost_pct < 0 or cost_pct >= 25:
        raise ValueError("execution_cost_pct must be finite and in [0, 25)")
    cost_fraction = cost_pct / 100.0
    c = ind['close'].to_numpy(dtype=float)
    h = ind['high'].to_numpy(dtype=float)
    l = ind['low'].to_numpy(dtype=float)
    a = ind['atr_14'].to_numpy(dtype=float)
    n = len(c)
    y = np.full(n, np.nan)
    amb = np.zeros(n, dtype=bool)
    end_pos = np.full(n, np.nan, dtype=float)
    for i in range(n - 1):
        if not np.isfinite(c[i]) or c[i] <= 0:
            continue
        atr_i = a[i] if np.isfinite(a[i]) and a[i] > 0 else c[i] * 0.01
        up = c[i] + up_mult * atr_i
        stop = c[i] - dn_mult * atr_i
        end = min(n, i + 1 + horizon)
        if end > i + 1:
            end_pos[i] = float(end - 1)
        peak = c[i]
        result = None
        for j in range(i + 1, end):
            if not (np.isfinite(h[j]) and np.isfinite(l[j])):
                continue
            hit_up = h[j] >= up
            hit_stop = l[j] <= stop
            if hit_up and hit_stop:
                amb[i] = True
                end_pos[i] = float(j)
                result = 'ambiguous'
                break
            if hit_up:
                # Label the realized barrier outcome after estimated round-trip costs.
                gross_return = (up / c[i]) - 1.0
                y[i] = 1.0 if gross_return > cost_fraction else 0.0
                end_pos[i] = float(j)
                result = 'target'
                break
            if hit_stop:
                gross_return = (stop / c[i]) - 1.0
                y[i] = 1.0 if gross_return > cost_fraction else 0.0
                end_pos[i] = float(j)
                result = 'stop'
                break
            # Match backtest ordering: update trailing only after this candle
            # has been checked against the stop known at its open.
            peak = max(peak, h[j])
            progress_pct = (peak / c[i] - 1.0) * 100.0
            if progress_pct >= TRAIL_TRIGGER_PCT:
                candidate = peak * (1.0 - TRAIL_DISTANCE_PCT / 100.0)
                stop = max(stop, candidate)
        if result is None and end - i - 1 >= horizon:
            final_close = c[end - 1]
            if np.isfinite(final_close) and final_close > 0:
                # A time exit is a realised directional outcome, not an
                # unlabelled observation. Costs remain in net backtest PnL.
                net_return = (final_close / c[i]) - 1.0 - cost_fraction
                y[i] = 1.0 if net_return > 0.0 else 0.0
                end_pos[i] = float(end - 1)
    y_s = pd.Series(y, index=ind.index)
    amb_s = pd.Series(amb, index=ind.index)
    if not return_details:
        return y_s, amb_s
    if 't' in ind.columns:
        ts = pd.to_numeric(ind['t'], errors='coerce').to_numpy(dtype=float)
        end_t = np.full(n, np.nan, dtype=float)
        valid_end = np.isfinite(end_pos)
        end_t[valid_end] = ts[end_pos[valid_end].astype(int)]
    else:
        idx_values = np.asarray(ind.index)
        end_t = np.full(n, np.nan, dtype=float)
        valid_end = np.isfinite(end_pos)
        try:
            idx_numeric = pd.to_numeric(pd.Series(idx_values), errors='coerce').to_numpy(dtype=float)
            end_t[valid_end] = idx_numeric[end_pos[valid_end].astype(int)]
        except Exception:
            end_t[valid_end] = end_pos[valid_end]
    return (y_s, amb_s, pd.Series(end_pos, index=ind.index),
            pd.Series(end_t, index=ind.index))


def build_features(df: pd.DataFrame, horizon: int = HORIZON,
                   noise_fraction: float = NOISE_FRACTION,
                   tb_up: float = TB_UP_MULT, tb_dn: float = TB_DN_MULT,
                   tb_horizon: int = TB_HORIZON,
                   label_cost_pct: float | None = None) -> tuple:
    """
    Build feature matrix and labels from candle data.
    Returns (X_df, y_series, raw_returns, last_row_features, indicators_df_train,
             features_full, ind_full, y_raw_full, raw_ret_full, amb_full).

    Labels use the PAPER lifecycle: 1 = upper barrier first or positive timeout,
    0 = lower/trailing stop first or non-positive timeout; ambiguous rows remain NaN.
    Ambiguous rows (both barriers touched in the SAME candle) also get NaN —
    the intrabar order is unknowable from OHLC, so they are excluded from
    training and statistics (no optimistic bias).
    """
    if len(df) < 250:
        raise ValueError(f"حداقل ۲۵۰ کندل لازم است، فقط {len(df)} داده شد")

    ind = all_indicators(df)
    c = ind['close']
    v = ind['volume']

    # ----- Triple-barrier labels (aligned with trading TP/SL reality) -----
    if label_cost_pct is None:
        label_notional = float(os.getenv('TS_AI_BACKTEST_NOTIONAL_USDT', '1000'))
        label_cost_pct = round_trip_cost_pct(label_notional)
    y_raw, amb_raw, label_end_pos_raw, label_end_t_raw = triple_barrier_labels(
        ind, up_mult=tb_up, dn_mult=tb_dn, horizon=tb_horizon, return_details=True,
        execution_cost_pct=label_cost_pct)
    # raw forward return kept for API compatibility / reporting
    future_close = c.shift(-horizon)
    raw_ret = (future_close / c) - 1.0

    # ----- Feature construction -----
    features = pd.DataFrame(index=ind.index)

    # Normalize price-based features by recent volatility
    vol_20 = c.pct_change().rolling(20).std() + 1e-9
    vol_50 = c.pct_change().rolling(50).std() + 1e-9

    # 1. Returns at multiple horizons (normalized)
    for n in [1, 2, 3, 5, 8, 13, 21]:
        ret = c.pct_change(n)
        features[f'ret_{n}'] = ret / (vol_20 * np.sqrt(n) + 1e-9)

    # 2. Log returns
    log_ret = np.log(c / c.shift(1))
    features['logret_1'] = log_ret / vol_20
    features['logret_3'] = np.log(c / c.shift(3)) / (vol_20 * np.sqrt(3) + 1e-9)
    features['logret_5'] = np.log(c / c.shift(5)) / (vol_20 * np.sqrt(5) + 1e-9)
    features['logret_10'] = np.log(c / c.shift(10)) / (vol_20 * np.sqrt(10) + 1e-9)

    # 3. MA crossovers & distances
    for n in [10, 20, 50, 100, 200]:
        if f'ema_{n}' in ind.columns and not ind[f'ema_{n}'].isna().all():
            features[f'close_to_ema_{n}'] = (c / ind[f'ema_{n}'] - 1) / vol_20
            features[f'close_to_sma_{n}'] = (c / ind[f'sma_{n}'] - 1) / vol_20 if f'sma_{n}' in ind.columns else 0

    # MA pair crosses
    pairs = [(10, 20), (20, 50), (50, 100), (50, 200), (20, 200)]
    for a, b in pairs:
        ea = ind.get(f'ema_{a}')
        eb = ind.get(f'ema_{b}')
        if ea is not None and eb is not None:
            features[f'ema_{a}_over_{b}'] = (ea / eb - 1) / vol_20

    features['dema_20_dist'] = (c / ind['dema_20'] - 1) / vol_20
    features['tema_20_dist'] = (c / ind['tema_20'] - 1) / vol_20
    features['hma_20_dist'] = (c / ind['hma_20'] - 1) / vol_20
    features['hma_20_slope'] = ind['hma_20'].pct_change(5) / vol_20

    # 4. RSI family
    features['rsi_7_norm'] = (ind['rsi_7'] - 50) / 25
    features['rsi_14_norm'] = (ind['rsi_14'] - 50) / 25
    features['rsi_21_norm'] = (ind['rsi_21'] - 50) / 25
    features['rsi_7_minus_14'] = (ind['rsi_7'] - ind['rsi_14']) / 25
    features['rsi_14_minus_21'] = (ind['rsi_14'] - ind['rsi_21']) / 25
    features['rsi_14_slope_3'] = ind['rsi_14'].diff(3) / 25
    features['rsi_14_slope_5'] = ind['rsi_14'].diff(5) / 25

    # 5. MACD
    features['macd_line_norm'] = ind['macd_line'] / (c * vol_20)
    features['macd_hist_norm'] = ind['macd_hist'] / (c * vol_20)
    features['macd_hist_slope'] = ind['macd_hist'].diff(3) / (c * vol_20)
    features['macd_above_signal'] = (ind['macd_line'] > ind['macd_signal']).astype(float)

    # 6. Stochastic
    features['stoch_k_norm'] = (ind['stoch_k'] - 50) / 50
    features['stoch_d_norm'] = (ind['stoch_d'] - 50) / 50
    features['stoch_k_minus_d'] = (ind['stoch_k'] - ind['stoch_d']) / 50

    # 7. Bollinger
    features['bb_pct'] = ind['bb_pct']
    features['bb_width'] = ind['bb_width'] / vol_20
    features['bb_squeeze'] = (ind['bb_width'] < ind['bb_width'].rolling(50).mean() * 0.75).astype(float)
    features['bb_pct_slope_3'] = ind['bb_pct'].diff(3)

    # 8. Keltner
    features['keltner_pct'] = ind['keltner_pct']

    # 9. Williams %R
    features['williams_r_norm'] = (ind['williams_r_14'] + 50) / 50

    # 10. CCI
    features['cci_20_norm'] = ind['cci_20'] / 150
    features['cci_20_slope_3'] = ind['cci_20'].diff(3) / 150

    # 11. ROC/MOM/TRIX
    features['roc_5_norm'] = ind['roc_5'] / (vol_20 * 100)
    features['roc_10_norm'] = ind['roc_10'] / (vol_20 * 100)
    features['roc_20_norm'] = ind['roc_20'] / (vol_20 * 100)
    features['mom_10_norm'] = ind['mom_10'] / (c * vol_20)
    features['trix_15'] = ind['trix_15']
    features['trix_15_slope_3'] = ind['trix_15'].diff(3)

    # 12. Ultimate Oscillator & TSI
    features['uo_norm'] = (ind['uo'] - 50) / 50
    features['tsi_norm'] = ind['tsi'] / 50
    features['tsi_slope_3'] = ind['tsi'].diff(3) / 50

    # 13. ATR / volatility
    features['atr_14_pct'] = ind['atr_14'] / c
    features['atr_7_pct'] = ind['atr_7'] / c
    features['atr_ratio'] = ind['atr_7'] / (ind['atr_14'] + 1e-9)
    features['vix_proxy'] = ind['vix_proxy']
    features['vol_20_z'] = vol_20 / (vol_20.rolling(50).mean() + 1e-9)

    # 14. z-scores & ranks
    features['close_z_20'] = ind['close_z_20']
    features['close_z_50'] = ind['close_z_50']
    features['close_pct_rank_20'] = ind['close_pct_rank_20']

    # 15. Volume indicators
    features['volume_z_20'] = ind['volume_z_20']
    features['volume_ratio_20'] = v / (v.rolling(20).mean() + 1e-9)
    features['mfi_14_norm'] = (ind['mfi_14'] - 50) / 50
    features['cmf_20'] = ind['cmf_20']
    features['force_index_norm'] = ind['force_index_13'] / (c * v + 1e-9)
    features['eom_14'] = ind['eom_14']
    features['chaikin_osc_norm'] = ind['chaikin_osc'] / (v.rolling(50).mean() + 1e-9)
    features['obv_slope_10'] = ind['obv'].pct_change(10) / vol_20
    features['ad_slope_10'] = ind['ad_line'].pct_change(10)
    features['vwap_dist'] = (c / ind['vwap_20'] - 1) / vol_20

    # 16. Trend
    features['adx_14'] = ind['adx_14'] / 50
    features['di_diff'] = (ind['plus_di'] - ind['minus_di']) / 50
    features['di_sum'] = (ind['plus_di'] + ind['minus_di']) / 100
    features['aroon_diff'] = (ind['aroon_up'] - ind['aroon_down']) / 100
    features['supertrend_dir'] = ind['supertrend']
    features['psar_above'] = (c > ind['psar']).astype(float)

    # 17. Ichimoku
    features['ich_above_cloud'] = ((c > ind['ich_span_a']) & (c > ind['ich_span_b'])).astype(float)
    features['ich_below_cloud'] = ((c < ind['ich_span_a']) & (c < ind['ich_span_b'])).astype(float)
    features['ich_tenkan_kijun'] = (ind['ich_tenkan'] - ind['ich_kijun']) / (c * vol_20)

    # 18. Candle shape
    features['body_ratio'] = ind['body_ratio']
    features['upper_wick'] = ind['upper_wick']
    features['lower_wick'] = ind['lower_wick']
    features['doji_score'] = ind['doji_score']
    features['body_ratio_z'] = (ind['body_ratio'] - ind['body_ratio'].rolling(20).mean()) / (ind['body_ratio'].rolling(20).std() + 1e-9)

    # 19. Coppock
    features['coppock'] = ind['coppock']
    features['coppock_slope_5'] = ind['coppock'].diff(5)

    # 20. Higher-order features (interaction terms)
    features['rsi_x_volume'] = features['rsi_14_norm'] * features['volume_z_20']
    features['macd_x_trend'] = features['macd_hist_norm'] * features['adx_14']
    features['bb_x_rsi'] = features['bb_pct'] * features['rsi_14_norm']
    features['ret_5_x_atr'] = features['ret_5'] * features['atr_14_pct']

    # Defragment before appending derived rolling/interaction columns.
    features = features.copy()

    # 21. Multi-timeframe aggregated features (rolling means of features)
    for col in ['rsi_14_norm', 'macd_hist_norm', 'bb_pct']:
        features[f'{col}_mean_5'] = features[col].rolling(5).mean()
        features[f'{col}_mean_10'] = features[col].rolling(10).mean()

    # 22. Additional indicator features (from new indicators)
    if 'alma_9' in ind.columns:
        features['alma_9_dist'] = (c / ind['alma_9'] - 1) / vol_20
        features['alma_20_dist'] = (c / ind['alma_20'] - 1) / vol_20
        features['alma_9_slope'] = ind['alma_9'].pct_change(3) / vol_20
    if 'tma_20' in ind.columns:
        features['tma_20_dist'] = (c / ind['tma_20'] - 1) / vol_20
    if 'donchian_pct' in ind.columns:
        features['donchian_pct'] = ind['donchian_pct']
        features['donchian_pct_slope_3'] = ind['donchian_pct'].diff(3)
    if 'kst' in ind.columns:
        features['kst_norm'] = ind['kst'] / 100
        features['kst_slope_3'] = ind['kst'].diff(3) / 100
    if 'dpo_20' in ind.columns:
        features['dpo_20_norm'] = ind['dpo_20'] / (c * vol_20)
    if 'chande_momentum_14' in ind.columns:
        features['chande_mom_norm'] = ind['chande_momentum_14'] / 100
    if 'fisher_10' in ind.columns:
        features['fisher_10'] = ind['fisher_10']
        features['fisher_slope_3'] = ind['fisher_10'].diff(3)
    if 'awesome_osc' in ind.columns:
        features['awesome_osc_norm'] = ind['awesome_osc'] / (c * vol_20)
    if 'ac_osc' in ind.columns:
        features['ac_osc_norm'] = ind['ac_osc'] / (c * vol_20)
    if 'pvt' in ind.columns:
        features['pvt_slope_10'] = ind['pvt'].pct_change(10)
    if 'nvi' in ind.columns:
        features['nvi_slope_10'] = ind['nvi'].pct_change(10)
    if 'pvi' in ind.columns:
        features['pvi_slope_10'] = ind['pvi'].pct_change(10)
    if 'vroc_14' in ind.columns:
        features['vroc_14_norm'] = ind['vroc_14'] / 100
    if 'ha_body_ratio' in ind.columns:
        features['ha_body_ratio'] = ind['ha_body_ratio']
    if 'rvi' in ind.columns:
        features['rvi_norm'] = ind['rvi']
        features['rvi_above_signal'] = (ind['rvi'] > ind['rvi_signal']).astype(float)

    # 23. Multi-period slope features (rate of change of MAs)
    for n in [10, 20, 50]:
        if f'ema_{n}' in ind.columns:
            features[f'ema_{n}_slope_3'] = ind[f'ema_{n}'].pct_change(3) / vol_20
            features[f'ema_{n}_slope_10'] = ind[f'ema_{n}'].pct_change(10) / vol_20

    # Drop warmup rows
    warmup = 210
    raw_positions = np.arange(warmup, len(features), dtype=int)
    features = features.iloc[warmup:].copy()
    y_raw = y_raw.iloc[warmup:].copy()
    amb_raw = amb_raw.iloc[warmup:].copy()
    raw_ret = raw_ret.iloc[warmup:].copy()
    label_end_pos = label_end_pos_raw.iloc[warmup:].copy()
    label_end_t = label_end_t_raw.iloc[warmup:].copy()
    ind = ind.iloc[warmup:].copy()
    # Keep raw candle positions as the index. This is essential: filtering
    # neutral/ambiguous labels must never compress time for purging or backtests.
    for frame in (features, y_raw, amb_raw, raw_ret, label_end_pos, label_end_t, ind):
        frame.index = raw_positions

    # Filter out NaN labels (noise rows + ambiguous rows) but keep features
    # for prediction on last row. For training, we drop rows where y is NaN.
    valid_mask = y_raw.notna()

    # Replace inf with NaN then fill with 0
    # v6.0 indicator features (all causal / normalized where price-scaled)
    c_v6 = ind['close']; v_v6 = ind['volume']
    features['kvo_norm'] = ind['kvo'] / (v_v6.rolling(20).mean()+1e-9)
    features['kvo_above_signal'] = ind['kvo_above_signal']
    features['vortex_diff'] = ind['vortex_diff']
    features['vortex_above_zero'] = (ind['vortex_diff']>0).astype(float)
    features['tdi_norm'] = (ind['tdi_rsi']-50)/50
    features['tdi_fast_minus_slow'] = (ind['tdi_fast']-ind['tdi_slow'])/50
    features['tdi_above_50'] = ind['tdi_above_50']
    features['stc_norm'] = (ind['stc']-50)/50
    features['stc_slope_3'] = ind['stc'].diff(3)/50
    features['wave_trend_norm'] = ind['wave_trend']/50
    features['wave_trend_cross'] = ((ind['wave_trend']>ind['wave_trend_signal']) & (ind['wave_trend'].shift(1)<=ind['wave_trend_signal'].shift(1))).astype(float)
    features['chandelier_dist'] = (c_v6/(ind['chandelier_exit'].abs()+1e-9)-1)/(c_v6.pct_change().rolling(20).std()+1e-9)
    features['qqe_norm'] = (ind['qqe_rsi']-50)/50
    features['qqe_above_upper'] = (ind['qqe_rsi']>ind['qqe_upper']).astype(float)
    features['squeeze_on'] = ind['squeeze_on']
    features['squeeze_momentum'] = ind['squeeze_momentum']
    features['elder_bull_norm'] = ind['elder_bull']/(c_v6*(c_v6.pct_change().rolling(20).std()+1e-9)+1e-9)
    features['elder_bear_norm'] = ind['elder_bear']/(c_v6*(c_v6.pct_change().rolling(20).std()+1e-9)+1e-9)
    features['elder_ray_diff'] = (ind['elder_bull']-ind['elder_bear'])/(c_v6*(c_v6.pct_change().rolling(20).std()+1e-9)+1e-9)
    features['bop'] = ind['balance_of_power']
    features['bop_mean_5'] = ind['balance_of_power'].rolling(5).mean()
    features['efficiency_ratio'] = ind['efficiency_ratio']
    features['fractal_dim'] = ind['fractal_dim']

    # --- V19: causal divergence features (price vs RSI / MACD pivots) ---
    # Same geometry the central brain uses for its ``divergence`` vote, so the
    # model can LEARN how much a divergence actually matters per market.
    div_feats = divergence_feature_series(ind)
    for col in ('div_rsi_bull', 'div_rsi_bear', 'div_macd_bull', 'div_macd_bear'):
        features[col] = div_feats[col].to_numpy()

    # --- V19: volume dynamics features ---
    # Directional volume push: high relative volume WITH a directional candle.
    v_rel = v / (v.rolling(20).mean() + 1e-9)
    dir_sign = np.sign(c.diff(1)).replace(0, 0.0)
    features['vol_thrust'] = (v_rel * dir_sign / 5.0).clip(-3, 3)
    features['mfi_14_slope_5'] = (ind['mfi_14'].diff(5) / 50).clip(-3, 3)
    features['obv_slope_5'] = ind['obv'].pct_change(5).clip(-3, 3)
    # Volume trend vs price trend disagreement (divergence of flows)
    features['obv_x_ret'] = np.sign(ind['obv'].diff(5)) * np.sign(c.diff(5))

    # --- V19.4: regime / tail-risk features (stronger-brain indicator pack) ---
    # Tell the model apart: is this a trending market or a choppy range?
    # (choppiness/hurst/ADX agreeing is a much stronger regime read than any
    # single one of them.)
    features['choppiness_14'] = ind['choppiness_14'] / 100.0
    features['mass_index'] = (ind['mass_index'] - 27.0) / 2.0   # ~27 is the classic "bulge" threshold
    features['hv_percentile'] = ind['hv_percentile']
    features['pivot_dist'] = ind['pivot_dist'].clip(-5, 5)
    features['ret_skew_30'] = ind['ret_skew_30'].clip(-5, 5)
    features['ret_kurt_30'] = ind['ret_kurt_30'].clip(-5, 10)
    features['hurst_100'] = (ind['hurst_100'] - 0.5) * 2.0       # centred: >0 trending, <0 mean-reverting
    # Interaction: a breakout (close vs pivot) that happens during low
    # choppiness (= real trend, not noise) is a materially different signal
    # than the same breakout inside a choppy range.
    features['pivot_x_trend'] = features['pivot_dist'] * (1.0 - features['choppiness_14'])

    features = features.replace([np.inf, -np.inf], np.nan)
    features = features.ffill().fillna(0)
    features = features.copy()
    # Captured only now: after the v6 columns exist and inf/NaN are cleaned
    # (it used to be taken earlier, so it was missing ~20 columns and had NaNs).
    last_row = features.iloc[-1].copy()

    # Return filtered versions for training, plus full features for prediction
    features_train = features.loc[valid_mask].copy()
    y_train = y_raw.loc[valid_mask].astype(int).copy()
    raw_ret_train = raw_ret.loc[valid_mask].copy()
    # Keep only label-valid rows for model fitting, but retain the original
    # candle index and full contiguous indicator frame for simulation.
    ind_train = ind.loc[valid_mask].copy()
    label_end_map = {int(k): float(v) for k, v in label_end_pos.items()}
    label_end_t_map = {int(k): float(v) for k, v in label_end_t.items()}
    metadata = {
        'label_interval': 'left-closed-entry_to_first-touch_or_directional-timeout',
        'label_policy_version': 2,
        'trailing_policy': {'trigger_pct': TRAIL_TRIGGER_PCT, 'distance_pct': TRAIL_DISTANCE_PCT, 'activates_next_bar': True},
        'timeout_policy': 'direction_of_final_close_vs_entry',
        'ambiguous_policy': 'exclude_both_barriers_same_candle',
        'label_horizon_bars': int(tb_horizon),
        'label_end_positions': label_end_map,
        'label_end_t': label_end_t_map,
        'raw_start_pos': int(raw_positions[0]) if len(raw_positions) else None,
        'raw_end_pos': int(raw_positions[-1]) if len(raw_positions) else None,
        'warmup_bars': int(warmup),
    }
    for frame in (features_train, features, ind_train, ind, y_train, y_raw):
        frame.attrs['v22_label_metadata'] = metadata
    features_train.attrs['label_end_positions'] = label_end_map
    features.attrs['label_end_positions'] = label_end_map
    ind_train.attrs['label_end_positions'] = label_end_map
    ind.attrs['label_end_positions'] = label_end_map

    return (features_train, y_train, raw_ret_train, last_row, ind_train,
            features, ind, y_raw, raw_ret, amb_raw)


def get_feature_names(features: pd.DataFrame) -> list:
    """Return list of feature names."""
    return list(features.columns)
