"""V22.2a: reproducible cost-aware evaluation primitives and versioned paper ledger."""
from __future__ import annotations
import hashlib, json, math, os, sqlite3, time, uuid
from pathlib import Path
from .audit_trail import canonical_hash, GENESIS
import numpy as np

COST_MODEL_VERSION = 'cost-v1'

def cost_model(fee_bps=5.0, slippage_bps=2.0, spread_bps=1.0):
    vals = [float(fee_bps), float(slippage_bps), float(spread_bps)]
    if any(not math.isfinite(x) or x < 0 or x > 500 for x in vals):
        raise ValueError('cost inputs must be finite bps in [0, 500]')
    cfg={'version':COST_MODEL_VERSION,'fee_bps':vals[0],'slippage_bps':vals[1],'spread_bps':vals[2]}
    cfg['cost_hash']=hashlib.sha256(json.dumps(cfg,sort_keys=True).encode()).hexdigest()
    return cfg

def net_returns(gross_returns, *, costs=None, turnover=None):
    c=costs or cost_model(); r=np.asarray(gross_returns,dtype=float)
    if r.ndim != 1 or not np.isfinite(r).all(): raise ValueError('gross_returns must be a finite 1-D array')
    t=np.ones_like(r) if turnover is None else np.asarray(turnover,dtype=float)
    if t.shape != r.shape or not np.isfinite(t).all() or (t<0).any(): raise ValueError('turnover must be finite, non-negative and match returns')
    bps=c['fee_bps']+c['slippage_bps']+c['spread_bps']
    return r - t*(bps/10000.0)

def baseline_returns(close, *, kind='buy_hold'):
    p=np.asarray(close,dtype=float)
    if p.ndim!=1 or len(p)<2 or not np.isfinite(p).all() or (p<=0).any(): raise ValueError('close must contain at least two finite positive prices')
    r=np.diff(p)/p[:-1]
    if kind=='buy_hold': return r
    if kind=='flat': return np.zeros_like(r)
    if kind=='always_long': return r
    if kind=='always_short': return -r
    raise ValueError('unknown baseline kind')

def calibration_metrics(y_true, probabilities, bins=10):
    y=np.asarray(y_true,dtype=float); p=np.asarray(probabilities,dtype=float)
    if y.ndim!=1 or p.shape!=y.shape or len(y)==0 or not np.isfinite(y).all() or not np.isfinite(p).all(): raise ValueError('invalid calibration arrays')
    if not np.isin(y,[0,1]).all() or ((p<0)|(p>1)).any(): raise ValueError('labels must be binary and probabilities in [0,1]')
    brier=float(np.mean((p-y)**2)); ece=0.; bucket=[]
    edges=np.linspace(0,1,max(2,int(bins))+1)
    for i in range(len(edges)-1):
        mask=(p>=edges[i]) & ((p<edges[i+1]) if i<len(edges)-2 else (p<=edges[i+1]))
        if mask.any():
            conf=float(p[mask].mean()); acc=float(y[mask].mean()); ece+=mask.mean()*abs(conf-acc)
            bucket.append({'lower':float(edges[i]),'upper':float(edges[i+1]),'n':int(mask.sum()),'confidence':conf,'accuracy':acc})
    return {'n':len(y),'brier':brier,'ece':float(ece),'buckets':bucket}

def _stationary_bootstrap_indices(n, rng, mean_block_length):
    """Politis-Romano stationary bootstrap with circular continuation."""
    if n < 2: raise ValueError('at least two observations required')
    L=float(mean_block_length)
    if not math.isfinite(L) or L < 1: raise ValueError('mean_block_length must be >= 1')
    out=np.empty(n,dtype=int); out[0]=int(rng.integers(n))
    restart=min(1.0,1.0/L)
    for i in range(1,n):
        out[i]=int(rng.integers(n)) if rng.random()<restart else (out[i-1]+1)%n
    return out

def _sharpe_stats(r, periods_per_year=365):
    r=np.asarray(r,dtype=float); sd=float(r.std(ddof=1)); mu=float(r.mean())
    if sd <= 0: return None, 0.0, 3.0
    z=(r-mu)/sd; skew=float(np.mean(z**3)); kurt=float(np.mean(z**4))
    return mu/sd*math.sqrt(periods_per_year), skew, kurt

def probabilistic_sharpe_ratio(returns, *, benchmark_sharpe=0.0, periods_per_year=365):
    """Bailey-López de Prado PSR; benchmark and annualization are explicit."""
    from scipy.stats import norm
    r=np.asarray(returns,dtype=float)
    if r.ndim!=1 or len(r)<3 or not np.isfinite(r).all(): raise ValueError('at least three finite returns required')
    sr,skew,kurt=_sharpe_stats(r,periods_per_year)
    if sr is None: return {'psr':0.5,'sharpe':None,'benchmark_sharpe':float(benchmark_sharpe),'n':len(r),'reason':'zero_volatility'}
    variance=(1.0-skew*sr/math.sqrt(periods_per_year)+((kurt-1.0)/4.0)*(sr**2/periods_per_year))/(len(r)-1)
    if variance<=0 or not math.isfinite(variance): raise ValueError('PSR variance is not positive/finite')
    z=(sr-float(benchmark_sharpe))/math.sqrt(variance)
    return {'psr':float(norm.cdf(z)),'sharpe':float(sr),'benchmark_sharpe':float(benchmark_sharpe),'n':len(r),'skewness':skew,'kurtosis':kurt,'standard_error':math.sqrt(variance)}

def deflated_sharpe_ratio(returns, *, trials=1, periods_per_year=365):
    """DSR against expected max Sharpe from the stated number of trials."""
    from scipy.stats import norm
    if int(trials)<1: raise ValueError('trials must be >= 1')
    ntr=int(trials); benchmark=0.0
    if ntr>1:
        euler=0.5772156649015329
        benchmark=(1-euler)*norm.ppf(1-1/ntr)+euler*norm.ppf(1-1/(ntr*math.e))
        benchmark=max(0.0,float(benchmark))
    out=probabilistic_sharpe_ratio(returns,benchmark_sharpe=benchmark,periods_per_year=periods_per_year)
    out.update({'dsr':out['psr'],'trials':ntr,'expected_max_sharpe_benchmark':float(benchmark)})
    return out

def compare_strategies(test_returns, *, periods_per_year=365, bootstrap_samples=2000, mean_block_length=None, min_trades=30, trials=1, seed=17):
    """Compare aligned strategies on a caller-designated untouched test block.

    Inputs must be per-bar net returns after the identical cost model. This function
    deliberately does not select thresholds or fit models.
    """
    if not isinstance(test_returns,dict) or len(test_returns)<2: raise ValueError('provide at least two named strategies')
    arrays={k:np.asarray(v,dtype=float) for k,v in test_returns.items()}
    lengths={len(v) for v in arrays.values()}
    if len(lengths)!=1 or next(iter(lengths))<3: raise ValueError('strategies must have aligned arrays with >=3 observations')
    n=next(iter(lengths))
    if any(v.ndim!=1 or not np.isfinite(v).all() or (v<=-1).any() for v in arrays.values()): raise ValueError('returns must be finite 1-D values greater than -100%')
    L=float(mean_block_length or max(2,round(n**(1/3))))
    rng=np.random.default_rng(seed); names=list(arrays); sampled={name:[] for name in names}
    # One shared index sequence per replicate preserves paired strategy comparison.
    for _ in range(max(200,int(bootstrap_samples))):
        idx=_stationary_bootstrap_indices(n,rng,L)
        for name in names: sampled[name].append(float(np.mean(arrays[name][idx])))
    summaries={}
    for name,r in arrays.items():
        metrics=performance_metrics(r,periods_per_year=periods_per_year,bootstrap_samples=bootstrap_samples,seed=seed,mean_block_length=L)
        dsr=deflated_sharpe_ratio(r,trials=trials,periods_per_year=periods_per_year)
        summaries[name]={'metrics':metrics,'dsr':dsr}
    reference=names[0]; comparisons={}
    for name in names[1:]:
        diffs=arrays[name]-arrays[reference]
        boot=np.asarray(sampled[name])-np.asarray(sampled[reference])
        lo,hi=np.quantile(boot,[.025,.975]); p=float(np.mean(boot>0))
        comparisons[name+'_vs_'+reference]={'mean_net_return_difference':float(diffs.mean()),'block_bootstrap_ci95':[float(lo),float(hi)],'probability_superior':p,'reference':reference,'challenger':name}
    # Promotion is intentionally conservative and only evaluated against first strategy.
    promotions={}
    for name in names[1:]:
        c=comparisons[name+'_vs_'+reference]; trade_count=int(np.count_nonzero(arrays[name]))
        promotions[name]={'eligible':bool(trade_count>=int(min_trades) and c['block_bootstrap_ci95'][0]>0 and summaries[name]['dsr']['dsr']>=.95),
                          'trade_count_proxy_nonzero_bars':trade_count,'minimum_trades':int(min_trades),
                          'reason':'evidence_passed' if trade_count>=int(min_trades) and c['block_bootstrap_ci95'][0]>0 and summaries[name]['dsr']['dsr']>=.95 else 'no_promotion_insufficient_statistical_evidence'}
    return {'evaluation_version':'robust-eval-v1','test_block':'caller_asserted_untouched','n_bars':n,'bootstrap_method':'stationary_bootstrap_paired','mean_block_length':L,'cost_policy':'all inputs must be net returns using identical versioned CostModel','strategies':summaries,'paired_comparisons':comparisons,'promotion_gates':promotions}

def performance_metrics(returns, *, periods_per_year=365, bootstrap_samples=500, seed=7, mean_block_length=None):
    r=np.asarray(returns,dtype=float)
    if r.ndim!=1 or len(r)<2 or not np.isfinite(r).all() or (r<=-1).any(): raise ValueError('at least two finite returns greater than -100% are required')
    if periods_per_year<=0: raise ValueError('periods_per_year must be positive')
    mu=float(r.mean()); sd=float(r.std(ddof=1)); downside=float(np.sqrt(np.mean(np.minimum(r,0)**2)))
    equity=np.cumprod(1+r); peak=np.maximum.accumulate(np.r_[1.,equity])[1:]
    dd=float(np.min(equity/peak-1))
    L=float(mean_block_length or max(2,round(len(r)**(1/3))))
    rng=np.random.default_rng(seed); n=max(100,int(bootstrap_samples)); means=np.empty(n)
    for i in range(n): means[i]=np.mean(r[_stationary_bootstrap_indices(len(r),rng,L)])
    return {'n':len(r),'total_return':float(equity[-1]-1),'annualized_return':float((equity[-1]**(periods_per_year/len(r))-1) if equity[-1]>0 else -1),
            'annualized_volatility':float(sd*np.sqrt(periods_per_year)),'sharpe':float(mu/sd*np.sqrt(periods_per_year)) if sd else None,
            'sortino':float(mu/downside*np.sqrt(periods_per_year)) if downside else None,'max_drawdown':dd,
            'mean_return_ci95':[float(np.quantile(means,.025)),float(np.quantile(means,.975))],
            'bootstrap_method':'stationary_bootstrap; serial dependence preserved probabilistically','mean_block_length':L}

def _db():
    p=Path(os.getenv('TRADING_AI_V22_PAPER_DB',str(Path.home()/'.trading_ai_models'/'paper_v22.sqlite3'))).expanduser(); p.parent.mkdir(parents=True,exist_ok=True); return p

def paper_v22_init():
    with sqlite3.connect(_db()) as c:
        c.execute('''CREATE TABLE IF NOT EXISTS paper_events(event_id TEXT PRIMARY KEY, run_id TEXT NOT NULL, ts REAL NOT NULL, event TEXT NOT NULL, payload TEXT NOT NULL, schema_version TEXT NOT NULL)''')
        cols={r[1] for r in c.execute('PRAGMA table_info(paper_events)').fetchall()}
        for name,decl in [('previous_hash','TEXT'),('event_hash','TEXT'),('idempotency_key','TEXT')]:
            if name not in cols: c.execute(f'ALTER TABLE paper_events ADD COLUMN {name} {decl}')
        c.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_paper_idempotency ON paper_events(idempotency_key) WHERE idempotency_key IS NOT NULL')

def paper_v22_record(run_id, event, payload, idempotency_key=None):
    if not run_id or not event: raise ValueError('run_id and event required')
    paper_v22_init(); payload=payload or {}
    # Serialize writers before reading the chain head or checking idempotency.
    # This closes the read-then-write race between concurrent requests.
    with sqlite3.connect(_db(), timeout=30, isolation_level=None) as c:
        c.execute('PRAGMA busy_timeout=30000')
        c.execute('BEGIN IMMEDIATE')
        try:
            if idempotency_key:
                prior=c.execute('SELECT event_id,run_id,ts,event,payload,schema_version,previous_hash,event_hash FROM paper_events WHERE idempotency_key=?',(str(idempotency_key),)).fetchone()
                if prior:
                    c.execute('COMMIT')
                    return {'event_id':prior[0],'run_id':prior[1],'timestamp':prior[2],'event':prior[3],'payload':json.loads(prior[4]),'schema_version':prior[5],'previous_hash':prior[6],'event_hash':prior[7],'duplicate':True}
            last=c.execute('SELECT event_hash FROM paper_events WHERE event_hash IS NOT NULL ORDER BY rowid DESC LIMIT 1').fetchone()
            previous=last[0] if last else GENESIS
            event_id=str(uuid.uuid4()); ts=time.time(); body={'event_id':event_id,'run_id':str(run_id),'timestamp':ts,'event':str(event),'payload':payload,'schema_version':'paper-v1','previous_hash':previous}
            digest=canonical_hash(body)
            c.execute('INSERT INTO paper_events(event_id,run_id,ts,event,payload,schema_version,previous_hash,event_hash,idempotency_key) VALUES(?,?,?,?,?,?,?,?,?)',(event_id,str(run_id),ts,str(event),json.dumps(payload,sort_keys=True,default=str),'paper-v1',previous,digest,str(idempotency_key) if idempotency_key else None))
            c.execute('COMMIT')
        except Exception:
            if c.in_transaction: c.execute('ROLLBACK')
            raise
    return {**body,'event_hash':digest,'duplicate':False}

def paper_v22_audit_integrity():
    paper_v22_init(); errors=[]; previous=GENESIS; checked=legacy=0
    with sqlite3.connect(_db()) as c:
        rows=c.execute('SELECT event_id,run_id,ts,event,payload,schema_version,previous_hash,event_hash FROM paper_events ORDER BY rowid').fetchall()
    for i,row in enumerate(rows):
        eid,rid,ts,event,payload,version,prev,digest=row
        if not digest: legacy+=1; continue
        body={'event_id':eid,'run_id':rid,'timestamp':ts,'event':event,'payload':json.loads(payload),'schema_version':version,'previous_hash':prev}
        if prev!=previous: errors.append(f'chain_break:{i}')
        if canonical_hash(body)!=digest: errors.append(f'event_hash_mismatch:{i}')
        previous=digest; checked+=1
    return {'valid':not errors,'checked_events':checked,'legacy_unsealed_events':legacy,'errors':errors,'head_hash':previous}

def paper_v22_events(run_id=None, limit=500):
    paper_v22_init(); limit=max(1,min(int(limit),2000))
    with sqlite3.connect(_db()) as c:
        if run_id: rows=c.execute('SELECT event_id,run_id,ts,event,payload,schema_version,previous_hash,event_hash FROM paper_events WHERE run_id=? ORDER BY ts DESC LIMIT ?', (str(run_id),limit)).fetchall()
        else: rows=c.execute('SELECT event_id,run_id,ts,event,payload,schema_version,previous_hash,event_hash FROM paper_events ORDER BY ts DESC LIMIT ?', (limit,)).fetchall()
    return [{'event_id':x[0],'run_id':x[1],'timestamp':x[2],'event':x[3],'payload':json.loads(x[4]),'schema_version':x[5],'previous_hash':x[6],'event_hash':x[7]} for x in rows]
