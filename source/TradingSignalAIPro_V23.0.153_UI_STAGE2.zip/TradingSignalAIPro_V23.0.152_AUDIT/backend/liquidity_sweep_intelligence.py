"""V23.0.137 read-only liquidity-pool and stop-sweep evidence analysis.

Equal highs/lows are treated as candidate liquidity pools, never proof of
stop orders, whale activity, manipulation, or participant identity.
Candles must be supplied chronologically and must be closed candles.
"""
from __future__ import annotations
import math


def _num(value):
    if isinstance(value, bool) or value is None:
        return None
    try:
        x = float(value)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError, OverflowError):
        return None


def _candles(raw):
    if not isinstance(raw, list) or len(raw) > 500:
        return []
    out = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        row = {k: _num(item.get(k)) for k in ('open', 'high', 'low', 'close', 'volume')}
        if (all(row[k] is not None for k in ('open', 'high', 'low', 'close'))
                and row['low'] > 0
                and row['high'] >= max(row['open'], row['close'])
                and row['low'] <= min(row['open'], row['close'])
                and row['high'] >= row['low']):
            out.append(row)
    return out


def _pool(levels, tolerance_pct, side):
    """Return the outermost repeated pool (highest highs or lowest lows)."""
    if len(levels) < 2:
        return None
    clusters = []
    for level in levels:
        cluster = [x for x in levels if abs(x - level) / level * 100 <= tolerance_pct]
        if len(cluster) >= 2:
            center = sum(cluster) / len(cluster)
            candidate = {'level': center, 'touches': len(cluster)}
            if not any(abs(candidate['level'] - x['level']) / x['level'] * 100 <= tolerance_pct for x in clusters):
                clusters.append(candidate)
    if not clusters:
        return None
    return max(clusters, key=lambda x: x['level']) if side == 'high' else min(clusters, key=lambda x: x['level'])


def analyze_liquidity_sweeps(candidates, *, tolerance_pct=0.15, lookback=30):
    if not isinstance(candidates, list):
        raise ValueError('candidates must be a list')
    tol = _num(tolerance_pct)
    if tol is None or not 0.01 <= tol <= 1.0:
        raise ValueError('tolerance_pct must be between 0.01 and 1.0')
    if isinstance(lookback, bool) or not isinstance(lookback, int) or not 5 <= lookback <= 100:
        raise ValueError('lookback must be an integer between 5 and 100')

    results = []
    for raw in candidates[:100]:
        if not isinstance(raw, dict):
            results.append({'decision': 'INSUFFICIENT_DATA', 'score': 0,
                            'reasons': ['INVALID_CANDIDATE'], 'entry_authorized': False,
                            'execution_authorized': False})
            continue
        rows = _candles(raw.get('candles'))
        symbol = str(raw.get('symbol') or '').upper().strip()
        reasons, evidence = [], {}
        score = 0
        if len(rows) < 8:
            reasons.append('INSUFFICIENT_VALID_CLOSED_CANDLES')
            results.append({'symbol': symbol, 'decision': 'INSUFFICIENT_DATA', 'score': 0,
                            'evidence': evidence, 'reasons': reasons,
                            'entry_authorized': False, 'execution_authorized': False})
            continue

        # Use only candles before the potential sweep candle to build pools.
        prior = rows[-(lookback + 1):-1]
        highs = [x['high'] for x in prior]
        lows = [x['low'] for x in prior]
        buy_pool = _pool(highs, tol, 'high')
        sell_pool = _pool(lows, tol, 'low')
        current = rows[-1]
        if buy_pool:
            evidence['buy_side_pool'] = buy_pool
        if sell_pool:
            evidence['sell_side_pool'] = sell_pool

        # A sweep requires a penetration and a close back inside the pool.
        bear_sweep = bool(buy_pool and current['high'] > buy_pool['level']
                          and current['close'] < buy_pool['level'])
        bull_sweep = bool(sell_pool and current['low'] < sell_pool['level']
                          and current['close'] > sell_pool['level'])
        if bear_sweep:
            evidence['buy_side_liquidity_swept'] = True
            score += 35
        if bull_sweep:
            evidence['sell_side_liquidity_swept'] = True
            score += 35

        # Confirmation is evaluated only when a sweep occurred on the prior
        # candle and the latest candle closes in the expected displacement direction.
        if len(rows) >= 9:
            sweep_candle, confirm = rows[-2], rows[-1]
            if buy_pool and sweep_candle['high'] > buy_pool['level'] and sweep_candle['close'] < buy_pool['level']:
                if confirm['close'] < sweep_candle['low']:
                    evidence['bearish_displacement_confirmation'] = True
                    score += 30
            if sell_pool and sweep_candle['low'] < sell_pool['level'] and sweep_candle['close'] > sell_pool['level']:
                if confirm['close'] > sweep_candle['high']:
                    evidence['bullish_displacement_confirmation'] = True
                    score += 30

        # Relative volume is supporting evidence only; no claim of whale activity.
        volumes = [x['volume'] for x in prior if x['volume'] is not None and x['volume'] > 0]
        if current['volume'] is not None and volumes:
            base = sorted(volumes)[len(volumes) // 2]
            if base > 0:
                ratio = current['volume'] / base
                evidence['volume_ratio_vs_prior_median'] = round(ratio, 4)
                if ratio >= 1.5 and (bear_sweep or bull_sweep):
                    score += 10
                elif ratio < 0.8:
                    reasons.append('LOW_RELATIVE_VOLUME')
        if bear_sweep and bull_sweep:
            decision, sweep_type = 'CONFLICTING_EVIDENCE', 'BOTH_SIDES'
        elif evidence.get('bearish_displacement_confirmation'):
            decision, sweep_type = 'CONFIRMED_BEARISH_SWEEP', 'BUY_SIDE'
        elif evidence.get('bullish_displacement_confirmation'):
            decision, sweep_type = 'CONFIRMED_BULLISH_SWEEP', 'SELL_SIDE'
        elif bear_sweep:
            decision, sweep_type = 'WATCH_BEARISH_SWEEP', 'BUY_SIDE'
        elif bull_sweep:
            decision, sweep_type = 'WATCH_BULLISH_SWEEP', 'SELL_SIDE'
        else:
            decision, sweep_type = 'NO_SWEEP_EVIDENCE', 'NONE'
        results.append({'symbol': symbol, 'decision': decision, 'sweep_type': sweep_type,
                        'score': min(score, 100), 'evidence': evidence, 'reasons': reasons,
                        'entry_authorized': False, 'execution_authorized': False})

    return {'version': '23.0.137', 'count': len(results), 'results': results,
            'data_policy': 'CLOSED_CANDLES_ONLY_BY_CALLER', 'paper_only': True,
            'entry_authorized': False, 'execution_authorized': False,
            'creates_orders': False, 'real_orders_enabled': False,
            'disclaimer': 'استخر نقدینگی از سقف‌ها و کف‌های مشابه تخمین زده می‌شود؛ این تحلیل وجود سفارش حدضرر، فعالیت نهنگ یا دستکاری بازار را اثبات نمی‌کند.'}
