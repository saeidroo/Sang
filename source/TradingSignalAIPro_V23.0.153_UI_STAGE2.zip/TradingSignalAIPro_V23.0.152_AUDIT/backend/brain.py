"""Central decision brain for Trading Signal AI Pro.

Combines independent evidence streams conservatively. It never fabricates a
vote for a missing feed, and it only allows an existing ML signal to pass when
independent evidence supports it. Component reliability is adapted from
matured, chronological forward outcomes stored locally (minimum sample gate).

V19 (central-brain-v3):
- Three new evidence components: ``divergence`` (RSI/MACD vs price pivots),
  ``ichimoku`` (cloud + tenkan/kijun) and ``volume`` (OBV/MFI flow).
- Confluence/conflict shaping: strong one-sided agreement sharpens the
  consensus score (bounded); genuine two-sided conflict dampens it.
- Every decision carries an internal scenario plan (entry/TP/SL/RR/expected
  value + invalidation) that the signal engine and the analyst report reuse —
  the strategy stays inside the signal instead of becoming a separate output.

V20 (central-brain-v4) — the learning brain closes its own loop:
- New component ``pool``: the consensus of ALL other trained models
  (backend/consensus.py) becomes the 14th independent evidence stream.
  Its base weight is deliberately small because the pool already blends a
  bounded share into the primary probability (partial overlap with ``ml``).
- ``recent_form``: the brain measures how its own reconstructed decisions
  performed over the most recent matured horizons for this exact market and
  applies a BOUNDED caution factor (x0.85..x1.00) — it only ever dampens,
  never amplifies, and never flips direction.
- ``source_reliability`` now also reports ML hit-rate buckets so the user
  can see WHERE the model's directional edge lives, not just on average.
"""
from __future__ import annotations

import json
import math
import os
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

BRAIN_VERSION = 'central-brain-v4'
HORIZON_BARS = 12
TF_MS = {'5m': 5 * 60_000, '15m': 15 * 60_000, '30m': 30 * 60_000, '1h': 60 * 60_000,
         '4h': 4 * 60 * 60_000, '1d': 24 * 60 * 60_000}
# V19: renormalised so the three new components join the consensus without
# letting any single feed dominate. Weights stay deliberately conservative.
BASE_WEIGHTS = {
    'ml': 0.26,
    'technical': 0.17,
    'regime': 0.07,
    'multi_timeframe': 0.12,
    'patterns': 0.04,
    'derivatives': 0.06,
    'horizon': 0.03,
    'sentiment': 0.02,
    'early_trend': 0.03,
    'drl': 0.03,
    'divergence': 0.05,
    'ichimoku': 0.04,
    'volume': 0.03,
    # V20: consensus of all other trained models. Small by design — the pool
    # already blends (max 30%) into the primary probability, so this vote is
    # a bounded *additional* multi-model view, not a second big ML channel.
    'pool': 0.05,
}

# Confluence/conflict shaping bounds (V19).
CONFLUENCE_MIN_SOURCES = 3      # sources with |score| >= CONFLUENCE_SCORE_MIN
CONFLUENCE_SCORE_MIN = 0.30
CONFLUENCE_STEP = 0.06          # per extra agreeing source
CONFLUENCE_MAX_FACTOR = 1.18    # never amplify more than +18%
CONFLICT_MIN_SIDES = 2          # >=2 sources each side = genuine conflict
CONFLICT_FACTOR = 0.90

# V20: recent-form caution bounds. Only damping is allowed (factor <= 1.0):
FORM_LOOKBACK = 20              # most recent independent matured horizons
FORM_MIN_SAMPLES = 10           # below this the prior stays untouched
FORM_HIT_KEEP = 0.48            # at/above this hit rate no damping at all
FORM_FACTOR_MIN = 0.85         # worst-case caution factor

# V20: ML score buckets reported inside source_reliability (informational).
ML_BUCKETS = ((0.15, 0.40), (0.40, 0.70), (0.70, 1.01))


def _finite(value: Any) -> float | None:
    try:
        x = float(value)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def _clip(value: float, low: float = -1.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def _db_path() -> Path:
    raw = os.getenv('TS_AI_BRAIN_DB')
    path = Path(raw).expanduser() if raw else Path.home() / '.trading_ai_models' / 'brain_feedback.sqlite3'
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _connect():
    conn = sqlite3.connect(_db_path(), timeout=10)
    conn.execute('''CREATE TABLE IF NOT EXISTS brain_observations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        symbol TEXT NOT NULL,
        timeframe TEXT NOT NULL,
        bar_ts INTEGER NOT NULL,
        entry_price REAL NOT NULL,
        components_json TEXT NOT NULL,
        realized_return REAL,
        created_at REAL NOT NULL,
        UNIQUE(symbol, timeframe, bar_ts)
    )''')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_brain_outcomes ON brain_observations(symbol,timeframe,realized_return,bar_ts)')
    return conn


@contextmanager
def _connection():
    conn = _connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _wilson_lower(wins: int, total: int, z: float = 1.96) -> float:
    if total <= 0:
        return 0.0
    p = wins / total
    den = 1 + z * z / total
    center = p + z * z / (2 * total)
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total)
    return max(0.0, (center - margin) / den)


def update_matured_outcomes(symbol: str, timeframe: str, bar_ts: int,
                            current_price: float, market_frame: pd.DataFrame | None = None) -> int:
    """Close predictions using the actual close at exactly the 12-bar horizon.

    If the target bar is not present in the supplied historical frame, the
    observation stays pending rather than being measured at an arbitrary later
    timestamp.
    """
    step = TF_MS.get(timeframe)
    if not step:
        return 0
    frame_prices = {}
    if isinstance(market_frame, pd.DataFrame) and {'t', 'close'}.issubset(market_frame.columns):
        frame = market_frame[['t', 'close']].copy()
        frame['t'] = pd.to_numeric(frame['t'], errors='coerce')
        frame['close'] = pd.to_numeric(frame['close'], errors='coerce')
        frame = frame.replace([np.inf, -np.inf], np.nan).dropna().sort_values('t')
        frame_prices = {int(t): float(c) for t, c in zip(frame['t'], frame['close'])
                        if float(c) > 0}
    # V21 fix: the current bar's own close was computed but never used, so without a
    # market frame no observation could ever mature. Seed it as a known price point.
    price = _finite(current_price)
    if price is not None and price > 0:
        frame_prices.setdefault(int(bar_ts), float(price))
    if not frame_prices:
        return 0
    cutoff = int(bar_ts) - step * HORIZON_BARS
    with _connection() as conn:
        rows = conn.execute("""SELECT id,bar_ts,entry_price FROM brain_observations
               WHERE symbol=? AND timeframe=? AND realized_return IS NULL AND bar_ts<=?""",
            (symbol, timeframe, cutoff)).fetchall()
        changed = 0
        for row_id, origin_ts, entry in rows:
            target_ts = int(origin_ts) + step * HORIZON_BARS
            target_price = frame_prices.get(target_ts)
            if target_price is None or not entry or entry <= 0:
                continue
            ret = target_price / float(entry) - 1.0
            conn.execute('UPDATE brain_observations SET realized_return=? WHERE id=? AND realized_return IS NULL',
                         (float(ret), int(row_id)))
            changed += 1
        return changed


def source_reliability(symbol: str, timeframe: str, min_samples: int = 30) -> dict:
    """Estimate directional hit-rates from mature observations, not in-sample fit.

    V20: additionally reports ``ml_buckets`` — the ML channel's hit rate by
    conviction bucket, so the user can see whether the model's strong calls
    are actually its best calls (informational; never changes weights).
    """
    counts: dict[str, list[int]] = {}
    ml_buckets: dict[str, list[int]] = {}
    last_used_ts: dict[str, int] = {}
    bucket_last_ts: dict[str, int] = {}
    min_spacing = TF_MS.get(timeframe, 0) * HORIZON_BARS
    with _connection() as conn:
        rows = conn.execute(
            '''SELECT bar_ts,components_json,realized_return FROM brain_observations
               WHERE symbol=? AND timeframe=? AND realized_return IS NOT NULL
               ORDER BY bar_ts DESC LIMIT 6000''', (symbol, timeframe)).fetchall()
    for bar_ts, raw, realized in rows:
        ret = _finite(realized)
        if ret is None or abs(ret) < 0.0002:
            continue
        try:
            component_scores = json.loads(raw)
        except Exception:
            continue
        if not isinstance(component_scores, dict):
            continue
        for name, score_raw in component_scores.items():
            score = _finite(score_raw)
            if score is None or abs(score) < 0.15:
                continue
            name = str(name)
            previous_ts = last_used_ts.get(name)
            # Adjacent 12-bar outcomes overlap. Use at most one observation per
            # horizon window for each component to avoid inflated confidence.
            if previous_ts is not None and min_spacing and previous_ts - int(bar_ts) < min_spacing:
                continue
            last_used_ts[name] = int(bar_ts)
            pair = counts.setdefault(name, [0, 0])
            pair[1] += 1
            if (score > 0 and ret > 0) or (score < 0 and ret < 0):
                pair[0] += 1
            # V20: per-conviction bucket accounting for the ML channel.
            if name == 'ml':
                magnitude = abs(score)
                bucket_key = None
                for lo, hi in ML_BUCKETS:
                    if lo <= magnitude < hi:
                        bucket_key = f'{lo:.2f}-{hi:.2f}'
                        break
                if bucket_key:
                    bts = bucket_last_ts.get(bucket_key)
                    if bts is None or min_spacing == 0 or bts - int(bar_ts) >= min_spacing:
                        bucket_last_ts[bucket_key] = int(bar_ts)
                        bpair = ml_buckets.setdefault(bucket_key, [0, 0])
                        bpair[1] += 1
                        if (score > 0 and ret > 0) or (score < 0 and ret < 0):
                            bpair[0] += 1
    report = {}
    multipliers = {}
    for name, (wins, total) in counts.items():
        hit_rate = wins / total if total else 0.0
        lower = _wilson_lower(wins, total)
        if total >= min_samples:
            # Conservative shrinkage around 1.0; weak evidence reduces influence.
            multiplier = _clip(0.70 + (lower - 0.50) * 4.0, 0.65, 1.30)
        else:
            multiplier = 1.0
        multipliers[name] = float(multiplier)
        entry = {
            'mature_samples': int(total), 'directional_hit_rate': round(hit_rate, 4),
            'wilson_lower_95': round(lower, 4),
            'weight_multiplier': round(float(multiplier), 3),
            'adaptive': bool(total >= min_samples),
        }
        if name == 'ml' and ml_buckets:
            entry['buckets'] = {
                key: {'samples': int(t), 'hit_rate': round(w / t, 4) if t else 0.0}
                for key, (w, t) in sorted(ml_buckets.items())
            }
        report[name] = entry
    return {'min_samples': int(min_samples), 'components': report,
            'multipliers': multipliers,
            'mode': 'adaptive_oos' if any(x['adaptive'] for x in report.values()) else 'conservative_prior'}


def recent_form(symbol: str, timeframe: str, lookback: int = FORM_LOOKBACK,
                min_samples: int = FORM_MIN_SAMPLES) -> dict:
    """V20 — how the brain's own recent calls for THIS market actually went.

    Reconstructs each matured bar's consensus direction from the stored
    component scores (fixed base weights — an approximation of the adaptive
    decision at that time) and compares it with the realised 12-bar outcome.
    At most one observation per horizon window (same spacing rule as
    ``source_reliability``). The result is a BOUNDED caution factor:

        hit_rate >= FORM_HIT_KEEP  -> factor 1.00 (no change)
        hit_rate  = 0              -> factor FORM_FACTOR_MIN (0.85)

    It only ever dampens the consensus magnitude; it never amplifies and
    never flips direction. Below ``min_samples`` the prior stays untouched.
    """
    unavailable = {'available': False, 'matured': 0, 'hit_rate': None,
                   'factor': 1.0, 'note': 'نمونه بالغ‌شده کافی نیست؛ فرم اخیر اعمال نشد'}
    if timeframe not in TF_MS:
        return unavailable
    min_spacing = TF_MS[timeframe] * HORIZON_BARS
    try:
        with _connection() as conn:
            rows = conn.execute(
                '''SELECT bar_ts,components_json,realized_return FROM brain_observations
                   WHERE symbol=? AND timeframe=? AND realized_return IS NOT NULL
                   ORDER BY bar_ts DESC LIMIT 6000''', (symbol, timeframe)).fetchall()
    except Exception:
        return unavailable
    hits: list[int] = []
    matured_seen = 0
    last_ts: int | None = None
    for bar_ts, raw, realized in rows:
        if last_ts is not None and min_spacing and last_ts - int(bar_ts) < min_spacing:
            continue
        ret = _finite(realized)
        if ret is None or abs(ret) < 0.0002:
            continue
        try:
            scores = json.loads(raw)
        except Exception:
            continue
        if not isinstance(scores, dict) or not scores:
            continue
        w_sum = 0.0
        s_sum = 0.0
        for key, val in scores.items():
            w = BASE_WEIGHTS.get(str(key))
            v = _finite(val)
            if w is None or v is None:
                continue
            w_sum += w
            s_sum += v * w
        if w_sum <= 0:
            continue
        consensus = s_sum / w_sum
        if abs(consensus) < 0.10:
            continue
        last_ts = int(bar_ts)
        matured_seen += 1
        hits.append(1 if (consensus > 0) == (ret > 0) else 0)
        if matured_seen >= max(1, int(lookback)):
            break
    if matured_seen < max(1, int(min_samples)) or not hits:
        out = dict(unavailable)
        out['matured'] = int(matured_seen)
        return out
    hit_rate = sum(hits) / len(hits)
    if hit_rate >= FORM_HIT_KEEP:
        factor = 1.0
    else:
        factor = FORM_FACTOR_MIN + (1.0 - FORM_FACTOR_MIN) * (hit_rate / FORM_HIT_KEEP)
    return {'available': True, 'matured': int(matured_seen), 'hit_rate': round(hit_rate, 4),
            'factor': round(float(factor), 4),
            'note': ('ضریب احتیاط فقط بزرگی اجماع را کم می‌کند؛ جهت تغییر نمی‌کند و هرگز تقویت نمی‌شود.')}


def record_observation(symbol: str, timeframe: str, bar_ts: int,
                       price: float, component_scores: dict) -> bool:
    p = _finite(price)
    if p is None or p <= 0 or timeframe not in TF_MS:
        return False
    clean = {str(k): _clip(v) for k, v in component_scores.items()
             if _finite(v) is not None}
    try:
        with _connection() as conn:
            cur = conn.execute(
                '''INSERT OR IGNORE INTO brain_observations
                   (symbol,timeframe,bar_ts,entry_price,components_json,created_at)
                   VALUES(?,?,?,?,?,?)''',
                (symbol, timeframe, int(bar_ts), p,
                 json.dumps(clean, separators=(',', ':'), sort_keys=True), time.time()))
            return cur.rowcount == 1
    except Exception:
        return False


def pool_consensus_vote(pool: dict | None) -> tuple[float, dict]:
    """V20 — vote of the consensus pool of ALL other trained models.

    ``pool`` is the dict produced by backend.consensus.pool_votes(). The
    direction comes from the pool's consensus probability; the magnitude is
    scaled by the pool's weighted agreement, so a 4-model 55% split votes
    much weaker than an 8-model 90% agreement. Missing/empty pool = no vote
    (never fabricated).
    """
    data = pool if isinstance(pool, dict) else None
    n = int(data.get('n') or 0) if data else 0
    cp = _finite(data.get('consensus_prob')) if data else None
    if not n or cp is None or not 0.0 <= cp <= 1.0:
        return 0.0, {'available': False,
                     'reason': 'استخر مدل‌های آموزش‌دیده خالی است یا رأی نداد'}
    agreement = _finite(data.get('agreement'))
    if agreement is None:
        agreement = 0.5
    score = _clip((cp - 0.5) * 2.0 * max(0.0, min(1.0, agreement)))
    return score, {'available': True, 'n': int(n), 'consensus_prob': cp,
                   'agreement': round(float(agreement), 4),
                   'consensus_dir': data.get('consensus_dir'),
                   'edge_share': data.get('edge_share'),
                   'note': 'هم‌پوشانی جزئی با کانال ml (ترکیب اجماع در احتمال اصلی)؛ وزن پایه عمداً کوچک است'}


def technical_vote(indicators: pd.DataFrame) -> tuple[float, dict]:
    if not isinstance(indicators, pd.DataFrame) or indicators.empty:
        return 0.0, {'available': False, 'reason': 'indicator data unavailable'}
    row = indicators.iloc[-1]
    votes: list[tuple[float, float, str]] = []
    price = _finite(row.get('close'))
    e20, e50 = _finite(row.get('ema_20')), _finite(row.get('ema_50'))
    if price and e20 and e50 and min(price, e20, e50) > 0:
        if price > e20 > e50:
            v = 1.0
        elif price < e20 < e50:
            v = -1.0
        elif price > e20:
            v = 0.35
        elif price < e20:
            v = -0.35
        else:
            v = 0.0
        votes.append((v, 0.34, 'EMA trend'))
    macd = _finite(row.get('macd_hist'))
    if macd is not None:
        votes.append((math.tanh(macd / max(abs(price or 1.0) * 0.001, 1e-12)), 0.24, 'MACD'))
    plus_di, minus_di = _finite(row.get('plus_di')), _finite(row.get('minus_di'))
    if plus_di is not None and minus_di is not None:
        votes.append((_clip((plus_di - minus_di) / 25.0), 0.20, 'Directional movement'))
    cmf = _finite(row.get('cmf_20'))
    if cmf is not None:
        votes.append((_clip(cmf / 0.25), 0.14, 'Chaikin money flow'))
    supertrend = _finite(row.get('supertrend'))
    if supertrend is not None and price and price > 0:
        votes.append((1.0 if supertrend < price else -1.0, 0.08, 'Supertrend'))
    if not votes:
        return 0.0, {'available': False, 'reason': 'no valid technical fields'}
    denom = sum(w for _, w, _ in votes)
    score = sum(v * w for v, w, _ in votes) / denom if denom else 0.0
    return _clip(score), {'available': True, 'subsignals': [n for _, _, n in votes]}


def timeframe_vote(contexts: list[dict]) -> tuple[float, dict]:
    vals = []
    for item in contexts or []:
        score = _finite(item.get('score'))
        if score is not None and item.get('available', True):
            vals.append((score, max(0.05, min(1.0, _finite(item.get('confidence')) or 0.5))))
    if not vals:
        return 0.0, {'available': False, 'frames': []}
    score = sum(v * c for v, c in vals) / sum(c for _, c in vals)
    return _clip(score), {'available': True, 'frames': len(vals)}


def pattern_vote(patterns: list[dict] | None) -> tuple[float, dict]:
    weights = {
        'bullish_engulfing': 1.0, 'potential_bullish_reversal': 0.55,
        'hammer_like': 0.55, 'bearish_engulfing': -1.0,
        'potential_bearish_reversal': -0.55, 'shooting_star_like': -0.55,
    }
    vals = []
    for item in patterns or []:
        name = str(item.get('pattern', ''))
        bias = str(item.get('bias', ''))
        value = weights.get(name, weights.get(bias, 0.0))
        if value:
            vals.append(value)
    if not vals:
        return 0.0, {'available': False, 'recognized': 0}
    return _clip(float(np.mean(vals))), {'available': True, 'recognized': len(vals)}


def derivatives_vote(snapshot: dict | None) -> tuple[float, dict]:
    if not isinstance(snapshot, dict) or not snapshot.get('available'):
        return 0.0, {'available': False, 'reason': (snapshot or {}).get('reason', 'not available')}
    votes = []
    imbalance = _finite(snapshot.get('order_book_imbalance'))
    if imbalance is not None:
        votes.append((_clip(imbalance), 0.45))
    flow = snapshot.get('large_trade_flow') or {}
    buy = _finite(flow.get('buy_notional'))
    sell = _finite(flow.get('sell_notional'))
    if buy is not None and sell is not None and buy + sell > 0:
        votes.append((_clip((buy - sell) / (buy + sell)), 0.55))
    funding = _finite(snapshot.get('funding_rate'))
    if funding is not None and abs(funding) >= 0.0005:
        # Extreme positive funding can mean crowded longs and vice versa; weak vote only.
        votes.append((-0.20 if funding > 0 else 0.20, 0.10))
    if not votes:
        return 0.0, {'available': False, 'reason': 'no valid derivatives fields'}
    score = sum(v * w for v, w in votes) / sum(w for _, w in votes)
    return _clip(score), {'available': True, 'fields_used': len(votes),
                          'open_interest_available': snapshot.get('open_interest') is not None,
                          'funding_rate_available': funding is not None}


def horizon_vote(outlook: dict | None) -> tuple[float, dict]:
    rows = (outlook or {}).get('outlooks') if isinstance(outlook, dict) else None
    if not rows:
        return 0.0, {'available': False}
    scores = []
    for row in rows:
        change = _finite(row.get('expected_change_pct'))
        lower = _finite(row.get('lower_95_pct'))
        upper = _finite(row.get('upper_95_pct'))
        if change is None:
            continue
        scale = max(abs(lower or 0), abs(upper or 0), 0.15)
        scores.append(_clip(change / scale))
    if not scores:
        return 0.0, {'available': False}
    return _clip(float(np.mean(scores))), {'available': True, 'horizons': len(scores),
                                           'method': 'weak rolling-drift context; not an ML forecast'}


def _fear_greed_vote(news: dict | None) -> tuple[float, dict]:
    fg = (news or {}).get('fear_greed') or {}
    sources = (news or {}).get('sources_status') or {}
    value = _finite(fg.get('value'))
    if value is None or sources.get('fear_greed') is False:
        return 0.0, {'available': False}
    # Tiny contrarian context only; this index must not overpower market evidence.
    score = 0.25 if value <= 15 else 0.12 if value <= 25 else -0.25 if value >= 85 else -0.12 if value >= 75 else 0.0
    return score, {'available': True, 'value': int(value), 'classification': fg.get('classification_fa') or fg.get('classification')}


def early_trend_vote(early: dict | None) -> tuple[float, dict]:
    state = (early or {}).get('state') if isinstance(early, dict) else None
    gap = _finite((early or {}).get('fast_slow_gap_pct')) if isinstance(early, dict) else None
    mom = _finite((early or {}).get('momentum_5_pct')) if isinstance(early, dict) else None
    if state not in ('bullish_shift_watch', 'bearish_shift_watch', 'no_confirmed_shift'):
        return 0.0, {'available': False}
    sign = 1.0 if state == 'bullish_shift_watch' else -1.0 if state == 'bearish_shift_watch' else 0.0
    strength = min(1.0, abs(gap or 0.0) * 0.25 + abs(mom or 0.0) * 0.08)
    return _clip(sign * max(0.15 if sign else 0.0, strength)), {
        'available': True, 'state': state, 'gap_pct': gap, 'momentum_5_pct': mom,
        'warning': (early or {}).get('warning')}


def ichimoku_vote(indicators: pd.DataFrame) -> tuple[float, dict]:
    """V19 — Ichimoku context vote (cloud position + tenkan/kijun).

    Deliberately mild: the cloud is a slow structure, so it confirms or denies
    trends rather than generating entries on its own.
    """
    if not isinstance(indicators, pd.DataFrame) or indicators.empty:
        return 0.0, {'available': False, 'reason': 'indicator data unavailable'}
    row = indicators.iloc[-1]
    price = _finite(row.get('close'))
    span_a = _finite(row.get('ich_span_a'))
    span_b = _finite(row.get('ich_span_b'))
    tenkan = _finite(row.get('ich_tenkan'))
    kijun = _finite(row.get('ich_kijun'))
    if price is None or price <= 0:
        return 0.0, {'available': False, 'reason': 'no price row'}
    if span_a is None and span_b is None and (tenkan is None or kijun is None):
        return 0.0, {'available': False, 'reason': 'no ichimoku fields'}
    votes: list[tuple[float, float]] = []
    if span_a is not None and span_b is not None:
        top, bottom = max(span_a, span_b), min(span_a, span_b)
        if price > top:
            votes.append((0.7, 0.45))
        elif price < bottom:
            votes.append((-0.7, 0.45))
        else:
            votes.append((0.0, 0.45))          # inside the cloud: neutral
    if tenkan is not None and kijun is not None:
        gap = (tenkan - kijun) / max(price * 0.004, 1e-12)
        votes.append((_clip(math.tanh(gap)), 0.35))
    if kijun is not None:
        votes.append((0.6 if price > kijun else -0.6, 0.20))
    if not votes:
        return 0.0, {'available': False, 'reason': 'no usable ichimoku fields'}
    denom = sum(w for _, w in votes)
    score = sum(v * w for v, w in votes) / denom if denom else 0.0
    return _clip(score), {'available': True, 'subsignals': ['cloud', 'tenkan_kijun', 'kijun_bias']}


def volume_vote(indicators: pd.DataFrame) -> tuple[float, dict]:
    """V19 — money-flow vote from OBV slope, MFI and relative volume thrust.

    All inputs come from the indicator frame; missing fields drop out of the
    weighted mean instead of voting zero.
    """
    if not isinstance(indicators, pd.DataFrame) or len(indicators) < 22:
        return 0.0, {'available': False, 'reason': 'indicator data unavailable'}
    row = indicators.iloc[-1]
    price = _finite(row.get('close'))
    votes: list[tuple[str, float, float]] = []
    if 'obv' in indicators.columns and price and price > 0:
        obv_diff = pd.to_numeric(indicators['obv'], errors='coerce').diff(10)
        delta = _finite(obv_diff.iloc[-1])
        scale = _finite(obv_diff.iloc[-60:].std()) if len(obv_diff.dropna()) >= 20 else None
        if scale is None or scale <= 0:
            scale = _finite(obv_diff.abs().mean()) or 0.0
        if delta is not None and scale > 0:
            votes.append(('obv', _clip(math.tanh(delta / (3.0 * scale))), 0.40))
    mfi = _finite(row.get('mfi_14'))
    if mfi is not None:
        # Strong inflow/outflow zones only; the mid-range is neutral.
        if mfi >= 65:
            votes.append(('mfi', 0.6, 0.30))
        elif mfi <= 35:
            votes.append(('mfi', -0.6, 0.30))
    v_now = _finite(row.get('volume'))
    prev_close = _finite(indicators['close'].iloc[-2]) if len(indicators) >= 2 else None
    if v_now is not None and prev_close is not None and prev_close > 0:
        v_mean = _finite(pd.to_numeric(indicators['volume'], errors='coerce')
                         .iloc[-21:-1].mean())
        if v_mean and v_mean > 0 and price:
            ratio = v_now / v_mean
            if ratio >= 1.6:
                # High volume thrust: direction comes from the candle sign,
                # magnitude from how extreme the volume spike is.
                direction = 1.0 if price >= prev_close else -1.0
                votes.append(('thrust', direction * min(1.0, (ratio - 1.0) / 2.0), 0.30))
    if not votes:
        return 0.0, {'available': False, 'reason': 'no usable volume fields'}
    denom = sum(w for _, _, w in votes)
    score = sum(v * w for _, v, w in votes) / denom if denom else 0.0
    return _clip(score), {'available': True, 'subsignals': [n for n, _, _ in votes]}


def build_component_scores(model_prob: float, indicators: pd.DataFrame,
                           regime: dict | None, mtf: list[dict] | None,
                           patterns: list[dict] | None, derivatives: dict | None,
                           outlook: dict | None, news: dict | None,
                           rl_review: dict | None, early_trend: dict | None = None,
                           pool: dict | None = None) -> tuple[dict, dict]:
    p = _finite(model_prob)
    if p is None or not 0 <= p <= 1:
        raise ValueError('ML probability must be finite in [0, 1]')
    technical, technical_meta = technical_vote(indicators)
    regime = regime or {}
    regime_name = regime.get('regime')
    regime_conf = _finite(regime.get('confidence')) or 0.0
    regime_score = (regime_conf if regime_name == 'bull' else
                    -regime_conf if regime_name == 'bear' else 0.0)
    mtf_score, mtf_meta = timeframe_vote(mtf or [])
    pat_score, pat_meta = pattern_vote(patterns)
    deriv_score, deriv_meta = derivatives_vote(derivatives)
    h_score, h_meta = horizon_vote(outlook)
    sentiment_score, sentiment_meta = _fear_greed_vote(news)
    early_score, early_meta = early_trend_vote(early_trend)
    # V19: the three new evidence streams. Divergence uses the shared causal
    # engine; failures are isolated so one broken detector cannot veto analysis.
    try:
        from .divergence import divergence_vote as _divergence_vote
        div_score, div_meta = _divergence_vote(indicators)
    except Exception as exc:
        div_score, div_meta = 0.0, {'available': False, 'reason': str(exc)[:120]}
    try:
        ich_score, ich_meta = ichimoku_vote(indicators)
    except Exception as exc:
        ich_score, ich_meta = 0.0, {'available': False, 'reason': str(exc)[:120]}
    try:
        vol_score, vol_meta = volume_vote(indicators)
    except Exception as exc:
        vol_score, vol_meta = 0.0, {'available': False, 'reason': str(exc)[:120]}
    # V20: consensus of all OTHER trained models as an independent stream.
    try:
        pool_score, pool_meta = pool_consensus_vote(pool)
    except Exception as exc:
        pool_score, pool_meta = 0.0, {'available': False, 'reason': str(exc)[:120]}
    rl_available = bool(isinstance(rl_review, dict) and rl_review.get('deployment_eligible')
                        and rl_review.get('direction') in ('BUY', 'SELL'))
    rl_score = (1.0 if rl_review.get('direction') == 'BUY' else -1.0) if rl_available else 0.0
    components = {
        'ml': {'score': _clip((p - 0.5) * 2), 'available': True, 'detail': {'probability_up': p}},
        'technical': {'score': technical, 'available': technical_meta['available'], 'detail': technical_meta},
        'regime': {'score': _clip(regime_score), 'available': regime_name in ('bull', 'bear', 'sideways', 'high_volatility'),
                   'detail': {'regime': regime_name, 'confidence': regime_conf}},
        'multi_timeframe': {'score': mtf_score, 'available': mtf_meta['available'], 'detail': mtf_meta},
        'patterns': {'score': pat_score, 'available': pat_meta['available'], 'detail': pat_meta},
        'derivatives': {'score': deriv_score, 'available': deriv_meta['available'], 'detail': deriv_meta},
        'horizon': {'score': h_score, 'available': h_meta['available'], 'detail': h_meta},
        'sentiment': {'score': sentiment_score, 'available': sentiment_meta['available'], 'detail': sentiment_meta},
        'early_trend': {'score': early_score, 'available': early_meta['available'], 'detail': early_meta},
        'drl': {'score': rl_score, 'available': rl_available,
                'detail': {'algorithm': (rl_review or {}).get('algorithm'), 'direction': (rl_review or {}).get('direction')}},
        'divergence': {'score': div_score, 'available': div_meta['available'], 'detail': div_meta},
        'ichimoku': {'score': ich_score, 'available': ich_meta['available'], 'detail': ich_meta},
        'volume': {'score': vol_score, 'available': vol_meta['available'], 'detail': vol_meta},
        'pool': {'score': pool_score, 'available': pool_meta['available'], 'detail': pool_meta},
    }
    meta = {'regime': regime, 'technical': technical_meta, 'multi_timeframe': mtf_meta,
            'patterns': pat_meta, 'derivatives': deriv_meta, 'horizon': h_meta,
            'sentiment': sentiment_meta, 'early_trend': early_meta,
            'divergence': div_meta, 'ichimoku': ich_meta, 'volume': vol_meta,
            'pool': pool_meta}
    return components, meta


def make_brain_decision(symbol: str, timeframe: str, bar_ts: int, price: float,
                        model_prob: float, indicators: pd.DataFrame,
                        regime: dict | None = None, mtf: list[dict] | None = None,
                        patterns: list[dict] | None = None, derivatives: dict | None = None,
                        outlook: dict | None = None, news: dict | None = None,
                        rl_review: dict | None = None, early_trend: dict | None = None,
                        market_frame: pd.DataFrame | None = None, edge_confirmed: bool = False,
                        base_signal: dict | None = None, agreement_std: float | None = None,
                        strength: str | None = None, pool: dict | None = None) -> dict:
    """Create weighted vote, update feedback, and apply a conservative signal gate.

    ``strength`` (V17.2) selects the consensus decisiveness profile
    (conservative / balanced / assertive). It only tunes how much independent
    consensus a CONFIRMED base signal needs; it never bypasses the
    out-of-sample edge gate, the news block or the meta-labeler.

    ``pool`` (V20) is the consensus-pool dict from backend.consensus.pool_votes();
    it joins the vote as its own bounded evidence stream (see BASE_WEIGHTS).
    """
    from .strength import normalize_strength, get_profile
    profile = get_profile(strength)
    strength_name = normalize_strength(strength)
    components, details = build_component_scores(model_prob, indicators, regime, mtf,
        patterns, derivatives, outlook, news, rl_review, early_trend, pool=pool)
    storage_warning = None
    try:
        update_matured_outcomes(symbol, timeframe, int(bar_ts), float(price), market_frame=market_frame)
        reliability = source_reliability(symbol, timeframe)
        form = recent_form(symbol, timeframe)
    except Exception as exc:
        storage_warning = str(exc)[:180]
        reliability = {'min_samples': 30, 'components': {}, 'multipliers': {},
                       'mode': 'conservative_prior'}
        form = {'available': False, 'matured': 0, 'hit_rate': None, 'factor': 1.0,
                'note': 'بازخورد محلی در دسترس نیست'}
    multipliers = reliability['multipliers']

    # Ensemble disagreement reduces only the ML channel's influence.
    if agreement_std is not None and math.isfinite(float(agreement_std)):
        agreement_factor = _clip(1.0 - max(0.0, float(agreement_std)) * 3.0, 0.55, 1.0)
    else:
        agreement_factor = 0.85

    weighted_sum = 0.0
    available_weight = 0.0
    total_weight = sum(BASE_WEIGHTS.values())
    support = 0
    used = {}
    component_scores = {}
    for name, item in components.items():
        score = _clip(item['score'])
        component_scores[name] = score
        if not item['available']:
            used[name] = {**item, 'base_weight': BASE_WEIGHTS[name], 'effective_weight': 0.0,
                          'reliability_multiplier': multipliers.get(name, 1.0)}
            continue
        multiplier = multipliers.get(name, 1.0)
        if name == 'ml':
            multiplier *= agreement_factor
        weight = BASE_WEIGHTS[name] * multiplier
        weighted_sum += score * weight
        available_weight += weight
        if abs(score) >= 0.15:
            support += 1
        used[name] = {**item, 'base_weight': BASE_WEIGHTS[name],
                      'effective_weight': round(weight, 5),
                      'reliability_multiplier': round(float(multiplier), 3)}

    score = weighted_sum / available_weight if available_weight else 0.0
    coverage = min(1.0, available_weight / total_weight) if total_weight else 0.0

    # --- V19: confluence / conflict shaping (bounded, symmetric) ---
    bull_sources = [n for n, s in component_scores.items()
                    if components.get(n, {}).get('available') and s >= CONFLUENCE_SCORE_MIN]
    bear_sources = [n for n, s in component_scores.items()
                    if components.get(n, {}).get('available') and s <= -CONFLUENCE_SCORE_MIN]
    shaping_factor = 1.0
    if len(bull_sources) >= CONFLUENCE_MIN_SOURCES and score > 0:
        shaping_factor = min(CONFLUENCE_MAX_FACTOR,
                             1.0 + CONFLUENCE_STEP * (len(bull_sources) - 2))
    elif len(bear_sources) >= CONFLUENCE_MIN_SOURCES and score < 0:
        shaping_factor = min(CONFLUENCE_MAX_FACTOR,
                             1.0 + CONFLUENCE_STEP * (len(bear_sources) - 2))
    if (len(bull_sources) >= CONFLICT_MIN_SIDES
            and len(bear_sources) >= CONFLICT_MIN_SIDES):
        shaping_factor *= CONFLICT_FACTOR
    shaped_score = _clip(score * shaping_factor)
    confluence_info = {
        'bull_sources': bull_sources, 'bear_sources': bear_sources,
        'shaping_factor': round(float(shaping_factor), 4),
        'raw_score': round(float(score), 4),
        'note': ('تقویت محدود اجماع یک‌جهته و تضعیف محدود تعارض دومنبه؛ '
                 'هرگز جهت را تغییر نمی‌دهد و سقف +۱۸٪ دارد.'),
    }
    score = shaped_score

    # --- V20: bounded recent-form caution (damping only) ---
    form_factor = float(form.get('factor') or 1.0)
    if 0.0 < form_factor < 1.0:
        score = _clip(score * form_factor)

    direction = ('BUY' if score >= profile['brain_direction_score']
                 else 'SELL' if score <= -profile['brain_direction_score'] else 'HOLD')
    confidence = min(1.0, abs(score))
    vetoes = []
    signal = base_signal or {}
    base_kind = signal.get('kind', 'HOLD')
    if not edge_confirmed:
        vetoes.append('برتری مدل در آزمون خارج‌ازنمونه تأیید نشده است')
    if news and news.get('block_trading'):
        vetoes.append('رویداد اقتصادی مهم نزدیک است')
    if signal.get('meta_blocked'):
        vetoes.append('Meta-Labeler کیفیت معامله را رد کرده است')
    if rl_review and rl_review.get('deployment_eligible'):
        rl_dir = rl_review.get('direction')
        if rl_dir in ('BUY', 'SELL') and base_kind in ('BUY', 'SELL') and rl_dir != base_kind:
            vetoes.append('عامل DRL با جهت مدل اصلی مخالف است')
    if isinstance(regime, dict) and regime.get('regime') == 'high_volatility':
        # Volatility itself is not a bearish vote; require stronger consensus only.
        if abs(score) < profile['high_vol_min_score']:
            vetoes.append('نوسان سالانه بسیار بالا و قدرت اجماع کافی نیست')
    if base_kind in ('BUY', 'SELL'):
        if direction != base_kind:
            vetoes.append('جهت اجماع مغز مرکزی با سیگنال پایه هم‌جهت نیست')
        if abs(score) < profile['brain_min_score']:
            vetoes.append('قدرت اجماع چندمنبعی به حداقل لازم نرسیده است')
        if coverage < profile['brain_min_coverage']:
            vetoes.append('پوشش منابع معتبر برای تصمیم کافی نیست')
        if support < profile['brain_min_support']:
            vetoes.append(f"کمتر از {profile['brain_min_support']} منبع مستقل جهت‌دار در دسترس است")
        if vetoes:
            signal['kind'] = 'HOLD'
            signal['levels_provisional'] = True
            signal['reason'] = str(signal.get('reason', '')) + ' | مغز مرکزی: ' + '؛ '.join(vetoes)
            signal['brain_veto'] = True
        else:
            signal['brain_confirmed'] = True
            # V17.2: stronger profiles let the confirmed signal keep more of its
            # base power instead of being clipped to the (lower) consensus score.
            base_power = float(signal.get('power', 0.0))
            blended = max(base_power, confidence) + profile['power_boost']
            signal['power'] = float(min(1.0, max(base_power, blended)))
            signal['strength_profile'] = strength_name
            signal['reason'] = str(signal.get('reason', '')) + ' | مغز مرکزی اجماع منابع را تأیید کرد.'
    else:
        # Preserve existing conservative HOLD. Never promote a HOLD to a trade.
        if not edge_confirmed:
            signal['brain_veto'] = True

    persisted_scores = dict(component_scores)
    if not edge_confirmed:
        persisted_scores.pop('ml', None)
    stored = record_observation(symbol, timeframe, int(bar_ts), float(price), persisted_scores)
    if not stored and storage_warning is None:
        storage_warning = 'ذخیره بازخورد این کندل انجام نشد یا قبلاً ثبت شده است'

    # --- V19: internal scenario plan (used inside the signal, not a separate output) ---
    scenario = _build_scenario(signal, price, model_prob, indicators, regime)
    if isinstance(scenario, dict):
        signal['scenario'] = scenario

    return {
        'version': BRAIN_VERSION, 'decision': direction,
        'strength_profile': strength_name,
        'final_signal': signal.get('kind', base_kind),
        'score': round(float(score), 4), 'confidence': round(float(confidence), 4),
        'coverage': round(float(coverage), 4), 'available_sources': sum(1 for x in components.values() if x['available']),
        'directional_sources': int(support), 'edge_confirmed': bool(edge_confirmed),
        'agreement_factor': round(float(agreement_factor), 3),
        'confluence': confluence_info,
        'recent_form': form,
        'components': used, 'vetoes': vetoes, 'reliability': reliability,
        'feedback': {'horizon_bars': HORIZON_BARS, 'stored_current_bar': bool(stored),
                     'storage_warning': storage_warning,
                     'note': 'وزن تطبیقی فقط پس از حداقل ۳۰ مشاهده بالغ‌شده و نتیجه‌دار فعال می‌شود.'},
        'not_used_as_directional_votes': {
            'strategy_lab': 'ابزار پژوهشی و بک‌تست است؛ خروجی آن سیگنال لحظه‌ای نیست.',
            'risk_manager': 'پس از تعیین جهت، برای اندازه موقعیت و ریسک استفاده می‌شود.',
            'paper_trading': 'ثبت و ارزیابی اجرای فرضی است؛ منبع پیش‌بینی جهت نیست.',
            'news_headlines': 'تا زمان وجود مدل احساسات معتبر، تیترها جهت‌سازی نمی‌کنند؛ رویداد پرریسک می‌تواند ورود را مسدود کند.',
        },
        'details': details,
        'limitations': [
            'وزن‌های اولیه محافظه‌کارانه‌اند و سودآوری را تضمین نمی‌کنند.',
            'کالیبراسیون منبعی بر اساس نتیجه جهت‌گیری ۱۲ کندل بعد انجام می‌شود، نه سود خالص معامله.',
            'داده‌های تایم‌فریم یا مشتقاتِ در دسترس‌نبوده از اجماع حذف می‌شوند و رأی صفر نمی‌گیرند.',
            'کانال «اجماع استخر مدل‌ها» هم به احتمال اصلی ترکیب شده و هم رأی کوچک مستقلی دارد؛ وزن پایه آن عمداً کوچک است.',
            'ضریب فرم اخیر فقط از نتایج بالغ‌شده‌ی همین بازار ساخته می‌شود و سقف آن ۱۵٪ تضعیف است؛ اگر نمونه کم باشد اعمال نمی‌شود.',
        ],
    }


def _build_scenario(signal: dict, price: float, model_prob: float,
                    indicators: pd.DataFrame, regime: dict | None) -> dict:
    """Internal trade scenario attached to the signal (V19).

    The TP/SL geometry stays exactly aligned with the training labels
    (±1.5×ATR / 12 bars); this helper only adds decision-support metadata:
    reward:risk, net expected value of the reference trade, a setup label and
    explicit invalidation levels. It NEVER changes the signal kind.
    """
    try:
        from .signal import ROUND_TRIP_COST_PCT
    except Exception:
        # Keep the fallback tied to the canonical PAPER execution model. A
        # historical 0.12% constant understated current spread/slippage/fees
        # and could make a marginal setup appear profitable.
        from .execution_model import round_trip_cost_pct
        ROUND_TRIP_COST_PCT = round_trip_cost_pct(1000.0)
    entry = _finite(signal.get('entry')) or _finite(price) or 0.0
    tp = _finite(signal.get('tp'))
    sl = _finite(signal.get('sl'))
    side = 1 if str(signal.get('levels_side', 'LONG')) == 'LONG' else -1
    if not entry or entry <= 0 or tp is None or sl is None:
        return {}
    reward = abs(tp - entry) / entry
    risk = abs(entry - sl) / entry
    if risk <= 0:
        return {}
    p = min(1.0, max(0.0, _finite(model_prob) or 0.5))
    # p is the calibrated P(hit TP first) under the label geometry, so the
    # expected value of the reference trade is directly computable.
    ev_gross_pct = (p * reward - (1.0 - p) * risk) * 100.0
    ev_net_pct = ev_gross_pct - float(ROUND_TRIP_COST_PCT)
    # Setup label from trend strength + volatility context.
    adx = _finite(indicators['adx_14'].iloc[-1]) if (
        isinstance(indicators, pd.DataFrame) and 'adx_14' in indicators.columns) else None
    regime_name = (regime or {}).get('regime') if isinstance(regime, dict) else None
    if regime_name == 'high_volatility':
        setup = 'high_vol_caution'
    elif (adx or 0) >= 22 and (signal.get('trend_up') or signal.get('trend_down')):
        setup = 'trend_continuation'
    elif (adx or 0) < 16:
        setup = 'range'
    elif bool(signal.get('trend_up')) or bool(signal.get('trend_down')):
        setup = 'trend_continuation'
    else:
        setup = 'reversal_watch'
    invalidation = (sl if side > 0 else tp)
    return {
        'setup': setup,
        'levels_side': 'LONG' if side > 0 else 'SHORT',
        'entry': float(entry), 'tp': float(tp), 'sl': float(sl),
        'reward_risk': round(reward / risk, 3),
        'prob_tp_first': round(float(p), 4),
        'ev_gross_pct': round(float(ev_gross_pct), 4),
        'ev_net_pct': round(float(ev_net_pct), 4),
        'cost_pct': float(ROUND_TRIP_COST_PCT),
        'invalidation': float(invalidation),
        'provisional': bool(signal.get('levels_provisional')),
        'note': ('سطوح و ارزش موردانتظار بر اساس هندسه‌ی برچسب آموزش (±1.5×ATR، ۱۲ کندل) است؛ '
                 'برای HOLD صرفاً سناریوی مرجع است، نه توصیه ورود.'),
    }


def reliability_status(symbol: str | None = None, timeframe: str | None = None) -> dict:
    if symbol and timeframe:
        return source_reliability(symbol, timeframe)
    with _connection() as conn:
        rows = conn.execute('''SELECT symbol,timeframe,COUNT(*),SUM(CASE WHEN realized_return IS NOT NULL THEN 1 ELSE 0 END)
                               FROM brain_observations GROUP BY symbol,timeframe ORDER BY symbol,timeframe''').fetchall()
    return {'database': str(_db_path()), 'horizon_bars': HORIZON_BARS,
            'markets': [{'symbol': r[0], 'timeframe': r[1], 'observations': int(r[2]),
                         'matured': int(r[3] or 0)} for r in rows]}
