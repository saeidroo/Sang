"""V23.0.73 evidence-based early-move screener; advisory only, no execution."""
from __future__ import annotations
import math


def _n(row, key):
    v = row.get(key)
    if isinstance(v, bool) or v is None:
        return None
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError, OverflowError):
        return None


def screen_explosive_opportunities(candidates, settings=None):
    if not isinstance(candidates, list):
        raise ValueError('candidates must be a list')
    cfg = {'min_volume_ratio': 1.8, 'max_spread_bps': 50.0,
           'max_change_pct': 18.0, 'min_relative_strength_pct': 0.0}
    if settings is not None:
        if not isinstance(settings, dict):
            raise ValueError('settings must be an object')
        for k, v in settings.items():
            if k not in cfg:
                raise ValueError(f'unknown setting: {k}')
            try: x = float(v)
            except (TypeError, ValueError): raise ValueError(f'invalid setting: {k}')
            if not math.isfinite(x) or x <= 0:
                raise ValueError(f'invalid setting: {k}')
            cfg[k] = x
    out = []
    for raw in candidates[:200]:
        if not isinstance(raw, dict):
            out.append({'decision':'INSUFFICIENT_DATA','score':0,'reasons':['INVALID_CANDIDATE']})
            continue
        r = dict(raw); reasons=[]; warnings=[]; score=0
        symbol = str(r.get('symbol') or '').upper().strip()
        exchange = str(r.get('exchange') or '').strip()
        if not symbol or not exchange: reasons.append('IDENTITY_MISSING')
        vol = _n(r,'volume_ratio'); spread = _n(r,'spread_bps')
        change = _n(r,'change_pct'); atr_pct = _n(r,'atr_pct')
        compression = _n(r,'range_compression_pct')
        breakout = r.get('breakout_confirmed')
        rel = _n(r,'relative_strength_vs_btc_pct')
        if vol is None: warnings.append('VOLUME_BASELINE_MISSING')
        elif vol >= cfg['min_volume_ratio']: score += 25
        else: reasons.append('NO_ABNORMAL_VOLUME')
        if compression is None: warnings.append('COMPRESSION_DATA_MISSING')
        elif 0 <= compression <= 35: score += 15
        else: warnings.append('NO_CLEAR_COMPRESSION')
        if breakout is True: score += 20
        elif breakout is False: warnings.append('BREAKOUT_NOT_CONFIRMED')
        else: warnings.append('BREAKOUT_EVIDENCE_MISSING')
        if rel is None: warnings.append('BTC_RELATIVE_STRENGTH_MISSING')
        elif rel >= cfg['min_relative_strength_pct']: score += 15
        else: reasons.append('UNDERPERFORMING_BTC')
        if spread is None: warnings.append('SPREAD_UNVERIFIED')
        elif spread <= cfg['max_spread_bps']: score += 10
        else: reasons.append('SPREAD_TOO_WIDE')
        if change is None: warnings.append('PRICE_CHANGE_MISSING')
        elif abs(change) <= cfg['max_change_pct']: score += 10
        else: reasons.append('LATE_OR_EXTREME_MOVE')
        if atr_pct is None: warnings.append('ATR_UNVERIFIED')
        elif 0 < atr_pct <= 12: score += 5
        else: reasons.append('VOLATILITY_UNSAFE')
        # Optional order-flow imbalance is supporting evidence only, never proof of accumulation.
        flow = _n(r,'buy_sell_volume_ratio')
        if flow is not None and flow >= 1.25: score += 5
        elif flow is None: warnings.append('ORDER_FLOW_NOT_AVAILABLE')
        decision = 'REJECT' if reasons else ('WATCH' if score >= 55 else 'LOW_CONFIDENCE')
        out.append({'symbol':symbol,'exchange':exchange,'decision':decision,'score':min(score,100),
                    'reasons':reasons,'warnings':warnings,'evidence':{
                    'volume_ratio':vol,'range_compression_pct':compression,'breakout_confirmed':breakout,
                    'relative_strength_vs_btc_pct':rel,'spread_bps':spread,'change_pct':change,
                    'atr_pct':atr_pct,'buy_sell_volume_ratio':flow},
                    'entry_authorized':False,'execution_authorized':False})
    return {'version':'23.0.73','count':len(out),'results':out,'paper_only':True,
            'capital_usdt':1000,'entry_authorized':False,'execution_authorized':False,
            'creates_orders':False,'real_orders_enabled':False,
            'disclaimer':'امتیاز صرفاً غربالگری شواهد است؛ پیش‌بینی پامپ یا تضمین حرکت قیمت نیست و مجوز ورود محسوب نمی‌شود.'}
