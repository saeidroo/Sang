"""V22.6a conservative candle analysis for newly listed spot pairs."""
from __future__ import annotations
from typing import Callable
import pandas as pd

EXCHANGE_SOURCE = {'Binance': 'binance', 'MEXC': 'mexc', 'Bybit': 'bybit'}
MIN_CANDLES = 210


def _analyze_frame(frame: pd.DataFrame, timeframe: str) -> dict:
    if frame is None or len(frame) < MIN_CANDLES:
        return {'timeframe': timeframe, 'status': 'insufficient_history',
                'candles': 0 if frame is None else len(frame), 'minimum': MIN_CANDLES,
                'advice': 'سابقه کندلی کافی نیست؛ فعلاً فقط پایش، بدون ورود.'}
    x = frame.copy()
    required = {'open', 'high', 'low', 'close', 'volume'}
    if not required.issubset(x.columns):
        return {'timeframe': timeframe, 'status': 'invalid_candle_schema', 'entry_ready': False}
    close = pd.to_numeric(x['close'], errors='coerce')
    high = pd.to_numeric(x['high'], errors='coerce')
    low = pd.to_numeric(x['low'], errors='coerce')
    vol = pd.to_numeric(x['volume'], errors='coerce')
    if close.tail(MIN_CANDLES).isna().any() or (close.tail(MIN_CANDLES) <= 0).any():
        return {'timeframe': timeframe, 'status': 'invalid_candles', 'entry_ready': False}
    ema20 = float(close.ewm(span=20, adjust=False).mean().iloc[-1])
    ema50 = float(close.ewm(span=50, adjust=False).mean().iloc[-1])
    last = float(close.iloc[-1])
    returns = float((close.iloc[-1] / close.iloc[-21] - 1) * 100)
    tr = pd.concat([high-low, (high-close.shift()).abs(), (low-close.shift()).abs()], axis=1).max(axis=1)
    atr_pct = float(tr.rolling(14).mean().iloc[-1] / last * 100)
    vbase = float(vol.iloc[-21:-1].median())
    vr = float(vol.iloc[-1] / vbase) if vbase > 0 else None
    if last > ema20 > ema50: trend = 'bullish'
    elif last < ema20 < ema50: trend = 'bearish'
    else: trend = 'mixed'
    return {'timeframe': timeframe, 'status': 'analysis_ready', 'candles': int(len(x)),
            'last_price': last, 'ema20': ema20, 'ema50': ema50, 'trend': trend,
            'return_20_bars_pct': round(returns, 3), 'atr14_pct': round(atr_pct, 3),
            'last_volume_vs_median20': round(vr, 3) if vr is not None else None,
            'entry_ready': False,
            'advice': 'ساختار صعودی اولیه؛ به‌دلیل ریسک بالای لیست جدید، فقط زیرنظر بگیر.' if trend == 'bullish' else
                      'ساختار نزولی؛ از تعقیب قیمت و ورود عجولانه پرهیز کن.' if trend == 'bearish' else
                      'ساختار هنوز روشن نیست؛ منتظر تثبیت و کندل‌های بیشتر بمان.'}


def analyze_new_listing(exchange: str, symbol: str, base: str = '', quote: str = 'USDT',
                        fetcher: Callable | None = None, contract_verified: bool = False) -> dict:
    """Fetch bounded 5m/15m/1h histories; never fabricates contract identity or entries."""
    exchange = str(exchange or '').strip()
    symbol = str(symbol or '').upper().strip()
    base, quote = str(base or '').upper().strip(), str(quote or '').upper().strip()
    source = EXCHANGE_SOURCE.get(exchange)
    if not source or not symbol or not symbol.endswith('USDT') or quote != 'USDT':
        return {'status': 'unsupported_pair', 'entry_ready': False, 'analyses': [],
                'advice': 'صرافی یا جفت‌ارز پشتیبانی نمی‌شود.'}
    if base and symbol != base + quote:
        return {'status': 'pair_identity_mismatch', 'entry_ready': False, 'analyses': [],
                'advice': 'نماد پایه و جفت معاملاتی با هم تطبیق ندارند.'}
    if fetcher is None:
        from backend.data import fetch_candles
        fetcher = fetch_candles
    analyses, errors = [], []
    for tf in ('5m', '15m', '1h'):
        try:
            frame = fetcher(symbol, tf, 300, source=source, validation_mode='research')
            result = _analyze_frame(frame, tf)
            result['data_source'] = source
            analyses.append(result)
        except Exception as exc:
            analyses.append({'timeframe': tf, 'status': 'data_unavailable', 'entry_ready': False})
            errors.append(f'{tf}:{str(exc)[:100]}')
    ready = all(a.get('status') == 'analysis_ready' for a in analyses)
    trends = [a.get('trend') for a in analyses if a.get('status') == 'analysis_ready']
    alignment = len(trends) == 3 and len(set(trends)) == 1
    identity = 'verified' if contract_verified else 'contract_identity_unverified'
    status = 'cold_start_analysis_ready' if ready and contract_verified else 'identity_unverified' if ready else 'insufficient_history'
    return {'exchange': exchange, 'symbol': symbol, 'base': base or symbol[:-4], 'quote': quote,
            'status': status, 'identity_status': identity, 'analyses': analyses,
            'multi_timeframe_alignment': alignment if ready else None,
            'entry_ready': False, 'errors': errors,
            'advice': ('کندل‌ها بررسی شدند، اما آدرس قرارداد/هویت توکن مستقل تأیید نشده؛ این تحلیل فقط مربوط به جفت معاملاتی صرافی است. ورود صادر نمی‌شود.'
                       if ready and not contract_verified else
                       'داده کافی در همه تایم‌فریم‌ها موجود نیست؛ نتیجه قطعی یا سطح ورود ارائه نمی‌شود.'),
            'disclaimer': 'تحلیل توصیفی و read-only است؛ روند یا هم‌جهتی تایم‌فریم‌ها احتمال سود نیست.'}
