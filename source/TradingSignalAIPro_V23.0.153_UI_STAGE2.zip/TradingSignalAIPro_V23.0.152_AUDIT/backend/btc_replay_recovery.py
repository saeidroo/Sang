"""V22.4a anti-rollback and recovery checks for BTC 4h replay anchors."""
from __future__ import annotations
import hashlib, json, os, shutil, tempfile
from pathlib import Path
from backend.btc_replay_anchor import verify_signed_replay_head_anchor, _canonical
from backend.btc_training_registry import _audit_replay_rows, _read_anchor_rows, _audit_anchor_rows

ZERO = '0' * 64


def _sha(value):
    return hashlib.sha256(_canonical(value)).hexdigest()


def _read_high_water(path):
    p = Path(path).expanduser()
    if not p.exists():
        return []
    rows=[]
    for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
        try: row=json.loads(line)
        except ValueError as exc: raise ValueError(f'replay_high_water_corrupt_line:{i}') from exc
        if not isinstance(row,dict): raise ValueError(f'replay_high_water_invalid_line:{i}')
        rows.append(row)
    previous=ZERO
    last_seq=0
    for row in rows:
        body=dict(row); digest=body.pop('record_sha256',None)
        seq=row.get('signing_sequence')
        if not isinstance(seq,int) or seq <= last_seq or row.get('previous_record_sha256') != previous:
            raise ValueError('replay_high_water_sequence_or_link_mismatch')
        if not digest or _sha(body) != digest:
            raise ValueError('replay_high_water_hash_mismatch')
        previous=digest; last_seq=seq
    return rows


def record_replay_anchor_high_water(signed_anchor: dict, *, state_path):
    """Append a monotonic signed-anchor sequence to separately protected storage."""
    verified=verify_signed_replay_head_anchor(signed_anchor)
    if not verified['valid']:
        raise ValueError('replay_high_water_signed_anchor_invalid:'+';'.join(verified['errors']))
    path=Path(state_path).expanduser(); path.parent.mkdir(parents=True,exist_ok=True)
    rows=_read_high_water(path)
    seq=int(signed_anchor['signing_sequence']); digest=_sha(signed_anchor)
    if rows:
        last=rows[-1]
        if seq < last['signing_sequence']:
            raise ValueError('replay_anchor_anti_rollback_detected')
        if seq == last['signing_sequence']:
            if digest != last['signed_anchor_sha256']:
                raise ValueError('replay_anchor_sequence_equivocation')
            return {'status':'UNCHANGED','signing_sequence':seq,'signed_anchor_sha256':digest}
    record={'state_version':'btc-replay-high-water-v1','signing_sequence':seq,
            'signed_anchor_sha256':digest,
            'previous_record_sha256':rows[-1]['record_sha256'] if rows else ZERO}
    record['record_sha256']=_sha(record)
    payload=_canonical(record)+b'\n'
    fd=os.open(str(path),os.O_CREAT|os.O_APPEND|os.O_WRONLY,0o600)
    try:
        written=os.write(fd,payload)
        if written != len(payload): raise OSError('replay_high_water_short_append')
        os.fsync(fd)
    finally: os.close(fd)
    return {'status':'RECORDED','signing_sequence':seq,'signed_anchor_sha256':digest,
            'record_sha256':record['record_sha256']}


def audit_replay_anchor_consistency(*, registry_dir, anchor_path, signed_anchor,
                                    witness_receipt=None, witness_public_key_pem=None,
                                    state_path=None):
    """Cross-check local chain, external head checkpoint, app signature and Witness receipt."""
    from backend.btc_training_registry import audit_replay_registry_anchor
    verified=verify_signed_replay_head_anchor(signed_anchor)
    if not verified['valid']:
        raise ValueError('replay_signed_anchor_invalid:'+';'.join(verified['errors']))
    local=audit_replay_registry_anchor(registry_dir=registry_dir,anchor_path=anchor_path)
    if local.get('status') != 'PASS':
        raise ValueError('replay_external_checkpoint_not_valid')
    payload=signed_anchor
    if (payload.get('anchor_sequence') != local.get('anchor_sequence') or
        payload.get('registry_record_count') != local.get('anchored_record_count') or
        payload.get('registry_chain_head_sha256') != local.get('anchored_chain_head_sha256') or
        payload.get('external_anchor_sha256') != local.get('anchor_sha256')):
        raise ValueError('replay_signed_anchor_local_checkpoint_mismatch')
    witness=None
    if witness_receipt is not None:
        from backend.external_anchor import verify_receipt, anchor_digest
        expected=anchor_digest(signed_anchor)
        witness=verify_receipt(witness_receipt,expected,public_key_pem=witness_public_key_pem)
        if not witness.get('valid'):
            raise ValueError('replay_witness_receipt_invalid:'+';'.join(witness.get('errors',[])))
    high_water=None
    if state_path is not None:
        high_water=record_replay_anchor_high_water(signed_anchor,state_path=state_path)
    return {'status':'PASS','local_anchor':local,'signature':verified,
            'witness':witness,'high_water':high_water}


def restore_replay_registry_from_backup(backup_path, destination_path, *, anchor_path):
    """Restore a verified JSONL replay registry only when it contains the externally anchored head."""
    from backend.btc_training_registry import _canonical
    source=Path(backup_path).expanduser(); destination=Path(destination_path).expanduser()
    if not source.is_file(): raise FileNotFoundError('replay_registry_backup_missing')
    if destination.exists(): raise FileExistsError('replay_registry_restore_destination_exists')
    rows=[]
    for i,line in enumerate(source.read_text(encoding='utf-8').splitlines(),1):
        try: row=json.loads(line)
        except ValueError as exc: raise ValueError(f'replay_backup_corrupt_line:{i}') from exc
        rows.append(row)
    audit=_audit_replay_rows(rows)
    anchors=_read_anchor_rows(Path(anchor_path).expanduser())
    anchor_audit=_audit_anchor_rows(anchors)
    latest=anchor_audit['latest']
    if latest is None: raise ValueError('replay_backup_requires_external_anchor')
    count=int(latest['registry_record_count'])
    if len(rows) < count: raise ValueError('replay_backup_missing_anchored_tail')
    actual='0'*64 if count==0 else rows[count-1]['chain_sha256']
    if actual != latest['registry_chain_head_sha256']:
        raise ValueError('replay_backup_anchor_head_mismatch')
    destination.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp_name=tempfile.mkstemp(prefix=destination.name+'.restore.',dir=str(destination.parent))
    try:
        with os.fdopen(fd,'wb') as stream:
            stream.write(source.read_bytes()); stream.flush(); os.fsync(stream.fileno())
        # Hard-link gives no-overwrite semantics on the same filesystem.
        os.link(tmp_name,destination)
    finally:
        try: os.unlink(tmp_name)
        except FileNotFoundError: pass
    return {'restored':True,'path':str(destination),'record_count':audit['record_count'],
            'chain_head_sha256':audit['chain_head_sha256'],'anchored_record_count':count}
