"""Verified, isolated backup/restore for the PAPER-ONLY live-market simulator DB.

This module never changes the configured live database during restore.
"""
from __future__ import annotations
import hashlib, json, os, shutil, sqlite3, uuid
from datetime import datetime, timezone
from pathlib import Path

SCHEMA_VERSION = "paper-live-backup-v1"
DB_FILENAME = "paper_live.sqlite3"


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _db_facts(path: Path) -> dict:
    with sqlite3.connect(str(path), timeout=30) as db:
        check = db.execute("PRAGMA integrity_check").fetchone()[0]
        tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        counts = {}
        for table in tables:
            safe = table.replace('"', '""')
            counts[table] = int(db.execute(f'SELECT COUNT(*) FROM "{safe}"').fetchone()[0])
        return {"integrity_check": check, "tables": tables, "row_counts": counts,
                "user_version": int(db.execute("PRAGMA user_version").fetchone()[0])}


def create_backup(source: str | Path, destination: str | Path) -> dict:
    src = Path(source).expanduser().resolve()
    dest = Path(destination).expanduser().resolve()
    if not src.is_file():
        raise FileNotFoundError(f"paper_live_database_missing: {src}")
    if src == dest or dest.exists():
        raise FileExistsError("backup_destination_must_be_new")
    dest.parent.mkdir(parents=True, exist_ok=True)
    stage = dest.parent / (dest.name + ".tmp-" + uuid.uuid4().hex)
    stage.mkdir()
    try:
        db_copy = stage / DB_FILENAME
        with sqlite3.connect(str(src), timeout=30) as source_db, sqlite3.connect(str(db_copy)) as target_db:
            source_db.backup(target_db)
        facts = _db_facts(db_copy)
        if facts["integrity_check"] != "ok":
            raise ValueError("backup_sqlite_integrity_failed")
        manifest = {
            "schema_version": SCHEMA_VERSION,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "source_name": src.name,
            "database": DB_FILENAME,
            "sha256": _sha256(db_copy),
            "size_bytes": db_copy.stat().st_size,
            "database_facts": facts,
        }
        canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()
        manifest["manifest_sha256"] = hashlib.sha256(canonical).hexdigest()
        (stage / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(stage, dest)
        return {"ok": True, "backup_path": str(dest), "manifest": manifest}
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        raise


def verify_backup(backup: str | Path) -> dict:
    root = Path(backup).expanduser().resolve()
    errors = []
    try:
        manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    except Exception as exc:
        return {"valid": False, "errors": [f"manifest_unreadable:{exc}"]}
    supplied = manifest.pop("manifest_sha256", None)
    canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()
    if supplied != hashlib.sha256(canonical).hexdigest():
        errors.append("manifest_hash_mismatch")
    if manifest.get("schema_version") != SCHEMA_VERSION:
        errors.append("unsupported_backup_schema")
    db_copy = root / DB_FILENAME
    if not db_copy.is_file():
        errors.append("database_missing")
        facts = None
    else:
        if _sha256(db_copy) != manifest.get("sha256") or db_copy.stat().st_size != manifest.get("size_bytes"):
            errors.append("database_hash_or_size_mismatch")
        try:
            facts = _db_facts(db_copy)
            if facts["integrity_check"] != "ok":
                errors.append("sqlite_integrity_check_failed")
            if facts != manifest.get("database_facts"):
                errors.append("database_facts_mismatch")
        except Exception as exc:
            facts = None
            errors.append(f"database_unreadable:{exc}")
    return {"valid": not errors, "errors": errors, "database_facts": facts, "backup_path": str(root)}


def restore_to_isolated_path(backup: str | Path, destination: str | Path) -> dict:
    checked = verify_backup(backup)
    if not checked["valid"]:
        raise ValueError("backup_verification_failed:" + ",".join(checked["errors"]))
    dest = Path(destination).expanduser().resolve()
    if dest.exists():
        raise FileExistsError("restore_destination_must_be_new")
    dest.parent.mkdir(parents=True, exist_ok=True)
    stage = dest.parent / (dest.name + ".restore-" + uuid.uuid4().hex)
    stage.mkdir()
    try:
        shutil.copy2(Path(backup).expanduser().resolve() / DB_FILENAME, stage / DB_FILENAME)
        facts = _db_facts(stage / DB_FILENAME)
        if facts["integrity_check"] != "ok":
            raise ValueError("restored_database_integrity_failed")
        os.replace(stage / DB_FILENAME, dest)
        stage.rmdir()
        return {"ok": True, "restored_to": str(dest), "isolated": True, "database_facts": facts}
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        raise
