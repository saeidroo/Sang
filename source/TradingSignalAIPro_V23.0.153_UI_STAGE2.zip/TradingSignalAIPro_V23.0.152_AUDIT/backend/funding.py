"""Public futures funding history adapter and idempotent paper cash-flow math.

No private credentials or order endpoints are used. Historical settlement rates
are taken from each venue's public market-data API.
"""
from __future__ import annotations

import math
import time
from typing import Any

from backend.data import SESSION

VERSION = "funding-engine-v2-partial-interval"
API_TIMEOUT = (4, 12)
MAX_PAGES = 12
BITGET_MAX_PAGES = 100  # Bitget documents cursor values up to 100 pages.
HISTORY_EVENT_LIMITS = {
    "binance": 1000 * MAX_PAGES, "bybit": 200 * MAX_PAGES, "okx": 400 * MAX_PAGES,
    "mexc": 1000 * MAX_PAGES, "gateio": 1000 * MAX_PAGES, "bitget": 100 * BITGET_MAX_PAGES,
}


def _get_json(url: str, params: dict[str, Any]) -> Any:
    response = SESSION.get(url, params=params, timeout=API_TIMEOUT)
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, (dict, list)):
        raise RuntimeError("پاسخ تاریخچهٔ Funding ساختار معتبری ندارد")
    return payload


def _finite(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if math.isfinite(number) else None



def quantity_at_settlement(original_quantity: float, partial_exits: list[dict],
                           settlement_ts: float) -> tuple[float, float]:
    """Return (open quantity, quantity exited) at a funding settlement instant.

    A partial exit is included only when its durable execution timestamp is at
    or before settlement. Thus a delayed history sync cannot charge the
    post-exit quantity for a settlement that happened earlier.
    """
    original = _finite(original_quantity)
    settle = _finite(settlement_ts)
    if original is None or original <= 0 or settle is None:
        raise ValueError("پارامترهای تخصیص مقداری Funding نامعتبر است")
    exited = 0.0
    for item in partial_exits or []:
        if not isinstance(item, dict):
            continue
        created = _finite(item.get("created_at"))
        quantity = _finite(item.get("quantity"))
        if created is None or quantity is None or quantity <= 0:
            raise ValueError("رکورد خروج جزئی برای تخصیص Funding نامعتبر است")
        if created <= settle:
            exited += quantity
    tolerance = max(1e-12, original * 1e-10)
    if exited > original + tolerance:
        raise ValueError("مجموع خروج‌های جزئی از مقدار اولیه بیشتر است")
    exited = min(original, exited)
    return max(0.0, original - exited), exited

def _ms(value: Any, *, seconds_allowed: bool = False) -> int | None:
    number = _finite(value)
    if number is None or number <= 0:
        return None
    if seconds_allowed and number < 100_000_000_000:
        number *= 1000
    return int(number)


def _record(rate: Any, timestamp: Any, *, mark_price: Any = None,
            rate_kind: str = "settled", timestamp_seconds: bool = False) -> dict | None:
    r = _finite(rate)
    ts = _ms(timestamp, seconds_allowed=timestamp_seconds)
    mark = _finite(mark_price)
    if r is None or ts is None or abs(r) > 0.10:
        return None
    if mark is not None and mark <= 0:
        mark = None
    return {"funding_rate": r, "settlement_ts": ts / 1000.0,
            "mark_price": mark, "rate_kind": rate_kind}


def _binance(symbol: str, start_ms: int, end_ms: int) -> list[dict]:
    out: list[dict] = []
    cursor = start_ms
    for _ in range(MAX_PAGES):
        payload = _get_json("https://fapi.binance.com/fapi/v1/fundingRate", {
            "symbol": symbol, "startTime": cursor, "endTime": end_ms, "limit": 1000,
        })
        if not isinstance(payload, list):
            raise RuntimeError("ساختار پاسخ Funding بایننس نامعتبر است")
        page = []
        for item in payload:
            if isinstance(item, dict):
                row = _record(item.get("fundingRate"), item.get("fundingTime"),
                              mark_price=item.get("markPrice"))
                if row:
                    page.append(row)
        out.extend(page)
        if len(payload) < 1000 or not page:
            break
        latest = max(int(x["settlement_ts"] * 1000) for x in page)
        if latest >= end_ms:
            break
        cursor = latest + 1
    return out


def _bybit(symbol: str, start_ms: int, end_ms: int) -> list[dict]:
    out: list[dict] = []
    cursor_end = end_ms
    for _ in range(MAX_PAGES):
        payload = _get_json("https://api.bybit.com/v5/market/funding/history", {
            "category": "linear", "symbol": symbol,
            "startTime": start_ms, "endTime": cursor_end, "limit": 200,
        })
        result = payload.get("result") if isinstance(payload, dict) else None
        rows = result.get("list") if isinstance(result, dict) else None
        if not isinstance(rows, list):
            raise RuntimeError("ساختار پاسخ Funding بای‌بیت نامعتبر است")
        page = []
        for item in rows:
            if isinstance(item, dict):
                row = _record(item.get("fundingRate"), item.get("fundingRateTimestamp"),
                              mark_price=item.get("markPrice"))
                if row:
                    page.append(row)
        out.extend(page)
        if len(rows) < 200 or not page:
            break
        oldest = min(int(x["settlement_ts"] * 1000) for x in page)
        if oldest <= start_ms:
            break
        cursor_end = oldest - 1
    return out


def _okx(symbol: str, start_ms: int, end_ms: int) -> list[dict]:
    base = symbol[:-4] + "-USDT-SWAP" if symbol.endswith("USDT") else symbol
    out: list[dict] = []
    after = None
    for _ in range(MAX_PAGES):
        params = {"instId": base, "limit": 400}
        if after is not None:
            params["after"] = after
        payload = _get_json("https://openapi.okx.com/api/v5/public/funding-rate-history", params)
        rows = payload.get("data") if isinstance(payload, dict) and payload.get("code") == "0" else None
        if not isinstance(rows, list):
            raise RuntimeError("ساختار پاسخ Funding اوکی‌ایکس نامعتبر است")
        page = []
        for item in rows:
            if isinstance(item, dict):
                # realizedRate is the actual rate applied at settlement. Never
                # substitute the predicted fundingRate for realized cash flow.
                row = _record(item.get("realizedRate"), item.get("fundingTime"),
                              rate_kind="realized")
                if row:
                    page.append(row)
        out.extend(page)
        if len(rows) < 400 or not page:
            break
        oldest = min(int(x["settlement_ts"] * 1000) for x in page)
        if oldest <= start_ms:
            break
        after = oldest
    return out


def _mexc(symbol: str, start_ms: int, end_ms: int) -> list[dict]:
    contract = symbol[:-4] + "_USDT" if symbol.endswith("USDT") else symbol
    out: list[dict] = []
    for page_no in range(1, MAX_PAGES + 1):
        payload = _get_json("https://contract.mexc.com/api/v1/contract/funding_rate/history", {
            "symbol": contract, "page_num": page_no, "page_size": 1000,
        })
        data = payload.get("data") if isinstance(payload, dict) and payload.get("success") else None
        rows = data.get("resultList") if isinstance(data, dict) else None
        if not isinstance(rows, list):
            raise RuntimeError("ساختار پاسخ Funding مکسی نامعتبر است")
        page = []
        for item in rows:
            if isinstance(item, dict):
                row = _record(item.get("fundingRate"), item.get("settleTime"))
                if row:
                    page.append(row)
        out.extend(page)
        if len(rows) < 1000 or not page:
            break
        if min(int(x["settlement_ts"] * 1000) for x in page) <= start_ms:
            break
    return out


def _gateio(symbol: str, start_ms: int, end_ms: int) -> list[dict]:
    contract = symbol[:-4] + "_USDT" if symbol.endswith("USDT") else symbol
    out: list[dict] = []
    cursor = start_ms // 1000
    end_seconds = end_ms // 1000
    for _ in range(MAX_PAGES):
        payload = _get_json("https://api.gateio.ws/api/v4/futures/usdt/funding_rate", {
            "contract": contract, "from": cursor, "to": end_seconds, "limit": 1000,
        })
        if not isinstance(payload, list):
            raise RuntimeError("ساختار پاسخ Funding گیت نامعتبر است")
        page = []
        for item in payload:
            if isinstance(item, dict):
                row = _record(item.get("r", item.get("funding_rate")),
                              item.get("t", item.get("time")),
                              mark_price=item.get("mark_price"), timestamp_seconds=True)
                if row:
                    page.append(row)
        out.extend(page)
        if len(payload) < 1000 or not page:
            break
        latest = max(int(x["settlement_ts"]) for x in page)
        if latest >= end_seconds:
            break
        cursor = latest + 1
    return out


def _bitget(symbol: str, start_ms: int, end_ms: int) -> list[dict]:
    out: list[dict] = []
    for page_no in range(1, BITGET_MAX_PAGES + 1):
        payload = _get_json("https://api.bitget.com/api/v3/market/history-fund-rate", {
            "category": "USDT-FUTURES", "symbol": symbol,
            "limit": 100, "cursor": str(page_no),
        })
        data = payload.get("data") if isinstance(payload, dict) and payload.get("code") == "00000" else None
        rows = data.get("resultList") if isinstance(data, dict) else None
        if not isinstance(rows, list):
            raise RuntimeError("ساختار پاسخ Funding بیت‌گت نامعتبر است")
        page = []
        for item in rows:
            if isinstance(item, dict):
                row = _record(item.get("fundingRate"), item.get("fundingRateTimestamp"),
                              rate_kind="settled")
                if row:
                    page.append(row)
        out.extend(page)
        if len(rows) < 100 or not page:
            break
    return out


_ADAPTERS = {
    "binance": _binance, "bybit": _bybit, "okx": _okx,
    "mexc": _mexc, "gateio": _gateio, "bitget": _bitget,
}


def fetch_funding_history(exchange: str, symbol: str, opened_at: float,
                          end_at: float | None = None) -> list[dict]:
    """Fetch actual settled rates after entry; returns deduplicated ascending events."""
    ex = str(exchange or "").lower().strip()
    sym = str(symbol or "").upper().replace("/", "").strip()
    if ex not in _ADAPTERS:
        raise ValueError(f"صرافی {ex or 'نامشخص'} برای Funding پشتیبانی نمی‌شود")
    start = _finite(opened_at)
    end = _finite(end_at) or time.time()
    if start is None or end <= start:
        return []
    rows = _ADAPTERS[ex](sym, int(start * 1000), int(end * 1000))
    unique: dict[int, dict] = {}
    for row in rows:
        ts = int(float(row["settlement_ts"]))
        if start < ts <= end:
            unique[ts] = row
    return [unique[k] for k in sorted(unique)]


def funding_cashflow(side: str, quantity: float, funding_rate: float,
                     *, mark_price: float | None = None,
                     entry_price: float | None = None) -> tuple[float, float, str]:
    """Return (cashflow, event notional, basis); positive cashflow is income."""
    q = _finite(quantity)
    rate = _finite(funding_rate)
    mark = _finite(mark_price)
    entry = _finite(entry_price)
    if q is None or q <= 0 or rate is None or abs(rate) > 0.10:
        raise ValueError("پارامترهای محاسبهٔ Funding نامعتبر است")
    if mark is not None and mark > 0:
        basis_price, basis = mark, "settlement_mark_price"
    elif entry is not None and entry > 0:
        basis_price, basis = entry, "entry_price_proxy"
    else:
        raise ValueError("قیمت مبنای Funding موجود نیست")
    normalized_side = str(side or "").upper()
    if normalized_side not in ("LONG", "SHORT"):
        raise ValueError("جهت موقعیت برای Funding نامعتبر است")
    # Positive rate: Long pays / Short receives. Negative rate reverses this.
    sign = -1.0 if normalized_side == "LONG" else 1.0
    notional = q * basis_price
    return notional * rate * sign, notional, basis


def funding_history_complete(exchange: str, events: list[dict], opened_at: float) -> bool:
    """Return False when a documented/page cap means earlier settlements may be missing."""
    ex = str(exchange or "").lower().strip()
    limit = HISTORY_EVENT_LIMITS.get(ex)
    if not limit or len(events) < limit or not events:
        return True
    earliest = min(float(row.get("settlement_ts") or 0.0) for row in events)
    return earliest <= float(opened_at)
