"""Tiny .env loader for Trading Signal AI Pro.

Bug fix (V17.2): the project shipped a `.env.example` telling users to put
CMC_API_KEY and other settings in a `.env` file, but the main application
never loaded it — only `backend/historical.py` had a private loader. Now the
whole app loads `.env` exactly once, before any module reads os.getenv.

Rules:
- Real environment variables always win over .env values (setdefault).
- Quotes and UTF-8 BOM are stripped; `#` comments and blank lines are ignored.
- The project root `.env` is used; a missing file is not an error.
"""
from __future__ import annotations

import os
from pathlib import Path

_LOADED = False


def _parse_line(line: str):
    line = line.strip()
    if not line or line.startswith('#'):
        return None
    if line.lower().startswith('export '):
        line = line[7:].strip()
    if '=' not in line:
        return None
    key, value = line.split('=', 1)
    key = key.strip()
    value = value.strip().strip('"').strip("'").strip()
    if not key or not key.replace('_', 'a').replace('.', 'a').isalnum():
        return None
    # allow inline comments for unquoted values:  KEY=value  # comment
    if not (value.startswith('"') or value.startswith("'")):
        if '  #' in value:
            value = value.split('  #', 1)[0].strip()
    return key, value


def load_dotenv(path: str | os.PathLike | None = None) -> list[str]:
    """Load `path` (default: project root .env) into os.environ.

    Returns the list of keys that were actually set from the file.
    Idempotent: repeated calls are no-ops unless a path is given explicitly.
    """
    global _LOADED
    if path is not None:
        candidates = [Path(path)]
    elif _LOADED:
        return []
    else:
        candidates = [Path(__file__).resolve().parents[1] / '.env']
        _LOADED = True
    applied: list[str] = []
    for candidate in candidates:
        try:
            if not candidate.exists():
                continue
            text = candidate.read_text(encoding='utf-8-sig')
        except OSError:
            continue
        for raw in text.splitlines():
            parsed = _parse_line(raw)
            if not parsed:
                continue
            key, value = parsed
            if key not in os.environ or os.environ.get(key, '') == '':
                os.environ[key] = value
                applied.append(key)
    return applied


# Load once at import time so every backend module sees the same environment.
load_dotenv()
