"""Bundle read-only BTC 4h pilot artifacts for independent external review."""
from __future__ import annotations
import hashlib, json, os, re, zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

SCHEMA='btc-4h-readonly-external-review-bundle-v1'
SECRET=re.compile(r'private|secret|token|password|credential|\.env',re.I)

def _canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def _sha(raw): return hashlib.sha256(raw).hexdigest()


def build_readonly_external_review_bundle(*, artifact_paths, output_path, release_version):
    if not isinstance(artifact_paths,(list,tuple)) or not artifact_paths:
        raise ValueError('review_bundle_artifacts_required')
    artifacts=[]; seen=set()
    for raw_path in artifact_paths:
        path=Path(raw_path).expanduser().resolve()
        if not path.is_file(): raise FileNotFoundError(f'review_bundle_artifact_missing:{path.name}')
        name=path.name
        if SECRET.search(name) or path.suffix.lower() in ('.pem','.key','.p12','.pfx'):
            raise ValueError(f'review_bundle_sensitive_artifact_rejected:{name}')
        if name in seen: raise ValueError('review_bundle_duplicate_artifact_name')
        seen.add(name)
        raw=path.read_bytes()
        if len(raw)>10*1024*1024: raise ValueError('review_bundle_artifact_too_large')
        artifacts.append({'name':name,'size_bytes':len(raw),'sha256':_sha(raw),'content':raw})
    entries=[{k:a[k] for k in ('name','size_bytes','sha256')} for a in artifacts]
    payload={'schema_version':SCHEMA,'release_version':str(release_version),
        'created_at_utc':datetime.now(timezone.utc).isoformat(),'artifact_count':len(entries),
        'artifacts':entries,'bundle_content_sha256':_sha(_canonical(entries))}
    manifest={**payload,'manifest_sha256':_sha(_canonical(payload))}
    output=Path(output_path).expanduser(); output.parent.mkdir(parents=True,exist_ok=True)
    if output.exists(): raise FileExistsError('review_bundle_destination_exists')
    temp=output.with_name(output.name+'.tmp')
    try:
        with zipfile.ZipFile(temp,'x',compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('manifest.json',_canonical(manifest)+b'\n')
            for artifact in artifacts: archive.writestr('artifacts/'+artifact['name'],artifact['content'])
        fd=os.open(str(temp),os.O_RDONLY)
        try: os.fsync(fd)
        finally: os.close(fd)
        os.link(temp,output)
    finally:
        try: temp.unlink()
        except FileNotFoundError: pass
    return {'created':True,'path':str(output),'artifact_count':len(entries),
        'manifest_sha256':manifest['manifest_sha256'],'bundle_content_sha256':manifest['bundle_content_sha256'],
        'bytes':output.stat().st_size}


def verify_readonly_external_review_bundle(path):
    with zipfile.ZipFile(path,'r') as archive:
        names=archive.namelist()
        if not names or names[0]!='manifest.json': raise ValueError('review_bundle_manifest_missing')
        manifest=json.loads(archive.read('manifest.json'))
        body=dict(manifest); declared=body.pop('manifest_sha256',None)
        if not declared or _sha(_canonical(body))!=declared: raise ValueError('review_bundle_manifest_hash_mismatch')
        entries=manifest.get('artifacts')
        if not isinstance(entries,list) or len(entries)!=manifest.get('artifact_count'):
            raise ValueError('review_bundle_artifact_index_invalid')
        expected={'manifest.json'}
        for entry in entries:
            name=entry.get('name','')
            safe=PurePosixPath(name)
            if not name or safe.name!=name or name in ('.','..') or SECRET.search(name) or name.lower().endswith(('.pem','.key','.p12','.pfx')):
                raise ValueError('review_bundle_artifact_name_unsafe')
            archive_name='artifacts/'+name; expected.add(archive_name)
            raw=archive.read(archive_name)
            if len(raw)!=entry.get('size_bytes') or _sha(raw)!=entry.get('sha256'):
                raise ValueError('review_bundle_artifact_hash_mismatch')
        if set(names)!=expected: raise ValueError('review_bundle_unindexed_files_present')
        if _sha(_canonical(entries))!=manifest.get('bundle_content_sha256'):
            raise ValueError('review_bundle_content_hash_mismatch')
        return {'valid':True,'release_version':manifest.get('release_version'),
            'artifact_count':len(entries),'manifest_sha256':declared,
            'bundle_content_sha256':manifest.get('bundle_content_sha256')}
