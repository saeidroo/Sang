"""Aggregated source reliability metrics for BTC 4h read-only pilot operations."""
from __future__ import annotations
import hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

def _sha(value): return hashlib.sha256(_canonical(value)).hexdigest()


def build_live_source_observability(*, live_reports, reconciliation_reports, drift_alerts,
                                    stale_threshold_hours=8, max_revision_rate=0.0):
    if not all(isinstance(x,list) for x in (live_reports,reconciliation_reports,drift_alerts)):
        raise ValueError('live_observability_inputs_must_be_lists')
    fetch_total=len(live_reports); fetch_pass=sum(r.get('status')=='PASS' and r.get('read_only') is True for r in live_reports if isinstance(r,dict))
    ages=[float(r['latest_age_hours']) for r in live_reports if isinstance(r,dict) and r.get('latest_age_hours') is not None]
    stale_count=sum(age>stale_threshold_hours for age in ages)
    revision_total=sum(int(r.get('revision_count',0)) for r in reconciliation_reports if isinstance(r,dict))
    removed_total=sum(int(r.get('removed_count',0)) for r in reconciliation_reports if isinstance(r,dict))
    compared=max(1,sum(int(r.get('previous_rows',0)) for r in reconciliation_reports if isinstance(r,dict)))
    revision_rate=revision_total/compared
    drift_critical=sum(a.get('status')=='CRITICAL' for a in drift_alerts if isinstance(a,dict))
    drift_warning=sum(a.get('status')=='WARNING' for a in drift_alerts if isinstance(a,dict))
    timestamps=[]
    for r in live_reports:
        if isinstance(r,dict) and r.get('fetched_at_utc'):
            try:
                dt=datetime.fromisoformat(str(r['fetched_at_utc']).replace('Z','+00:00'))
                if dt.tzinfo is not None: timestamps.append(dt.timestamp())
            except ValueError: pass
    timestamps.sort()
    intervals=[(b-a)/3600 for a,b in zip(timestamps,timestamps[1:])]
    metrics={'fetch_count':fetch_total,'fetch_pass_count':fetch_pass,
        'fetch_success_rate':round(fetch_pass/fetch_total,4) if fetch_total else None,
        'stale_report_count':stale_count,'stale_report_rate':round(stale_count/len(ages),4) if ages else None,
        'latest_age_hours':ages[-1] if ages else None,
        'reconciliation_count':len(reconciliation_reports),'revised_candle_count':revision_total,
        'removed_candle_count':removed_total,'revision_rate_per_previous_row':round(revision_rate,8),
        'drift_critical_count':drift_critical,'drift_warning_count':drift_warning,
        'observed_fetch_intervals_hours':intervals,
        'observation_window_hours':round((timestamps[-1]-timestamps[0])/3600,3) if len(timestamps)>1 else 0.0,
        'median_fetch_interval_hours':sorted(intervals)[len(intervals)//2] if intervals else None}
    errors=[]; warnings=[]
    if fetch_total and fetch_pass != fetch_total: errors.append('one_or_more_live_fetches_failed')
    if stale_count: errors.append('stale_live_reports_observed')
    if removed_total: errors.append('removed_closed_candles_observed')
    if drift_critical: errors.append('critical_drift_alerts_observed')
    if revision_rate>max_revision_rate: warnings.append('revision_rate_above_policy')
    if drift_warning: warnings.append('drift_warning_alerts_observed')
    status='CRITICAL' if errors else ('WARNING' if warnings else 'HEALTHY')
    result={'schema_version':'btc-4h-live-source-observability-v1','status':status,
        'generated_at_utc':datetime.now(timezone.utc).isoformat(),'metrics':metrics,
        'warnings':warnings,'errors':errors,'training_allowed':False,'live_orders':False}
    result['report_sha256']=_sha(result)
    return result


def _read_jsonl(path):
    if path is None: return []
    p=Path(path)
    if not p.exists(): return []
    rows=[]
    for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
        try: rows.append(json.loads(line))
        except ValueError as exc: raise ValueError(f'observability_input_corrupt_line:{p}:{i}') from exc
    return rows


def build_observability_from_jsonl(*, live_reports_path=None, reconciliation_reports_path=None,
                                   drift_alerts_path=None, stale_threshold_hours=8,
                                   max_revision_rate=0.0):
    return build_live_source_observability(
        live_reports=_read_jsonl(live_reports_path),
        reconciliation_reports=_read_jsonl(reconciliation_reports_path),
        drift_alerts=[x.get('alert',x) for x in _read_jsonl(drift_alerts_path)],
        stale_threshold_hours=stale_threshold_hours,max_revision_rate=max_revision_rate)


def save_live_source_observability(report: dict, *, output_path):
    if not isinstance(report,dict) or report.get('schema_version')!='btc-4h-live-source-observability-v1':
        raise ValueError('live_observability_report_invalid')
    body=dict(report); declared=body.pop('report_sha256',None)
    if not declared or _sha(body)!=declared: raise ValueError('live_observability_hash_mismatch')
    path=Path(output_path).expanduser(); path.parent.mkdir(parents=True,exist_ok=True)
    raw=_canonical(report)+b'\n'; fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as stream: stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    return {'saved':True,'path':str(path),'report_sha256':declared,'status':report['status']}
