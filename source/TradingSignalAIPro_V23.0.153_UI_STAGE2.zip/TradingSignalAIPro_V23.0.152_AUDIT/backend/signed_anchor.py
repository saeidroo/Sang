"""V22.2j/k Ed25519 detached anchors with rotation, revocation and anti-rollback.

Trust state is local and deliberately outside application data. For strong rollback
protection, place TS_AI_ANCHOR_KEY_DIR on protected/offline or monotonic storage.
"""
from __future__ import annotations
import base64, hashlib, json, os, tempfile
from datetime import datetime, timezone
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

SCHEMA='v22-ed25519-anchor-v2'
LEGACY_SCHEMA='v22-ed25519-anchor-v1'
ZERO='0'*64

def _key_dir() -> Path:
    override=os.getenv('TS_AI_ANCHOR_KEY_DIR')
    return Path(override).expanduser().resolve() if override else (Path.home()/'.trading_signal_ai'/'trust').resolve()
def _atomic(path: Path, data: bytes, mode=0o600):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f: f.write(data); f.flush(); os.fsync(f.fileno())
        os.chmod(tmp,mode); os.replace(tmp,path)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass
def _raw_id(pub):
    raw=pub.public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
    return hashlib.sha256(raw).hexdigest()
def _trusted_dir(): return _key_dir()/'trusted'
def _active_file(): return _key_dir()/'active_key.json'
def _revoked_file(): return _key_dir()/'revoked.json'
def _sequence_file(): return _key_dir()/'sequence.json'
def _load_json(p,default):
    try: return json.loads(p.read_text(encoding='utf-8'))
    except FileNotFoundError: return default

def _new_pair():
    key=Ed25519PrivateKey.generate(); pub=key.public_key(); kid=_raw_id(pub)
    td=_trusted_dir(); td.mkdir(parents=True,exist_ok=True)
    priv=key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
    pubpem=pub.public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)
    _atomic(td/f'{kid}.private.pem',priv,0o600); _atomic(td/f'{kid}.public.pem',pubpem,0o644)
    _atomic(_active_file(),json.dumps({'key_id':kid,'created_at':datetime.now(timezone.utc).isoformat()},sort_keys=True).encode()+b'\n')
    return kid

def ensure_keypair() -> dict:
    _key_dir().mkdir(parents=True,exist_ok=True)
    active=_load_json(_active_file(),None)
    if not active:
        oldpriv=_key_dir()/'anchor_ed25519_private.pem'; oldpub=_key_dir()/'anchor_ed25519_public.pem'
        if oldpriv.exists() and oldpub.exists():
            oldkey=serialization.load_pem_private_key(oldpriv.read_bytes(),password=None); oldpublic=serialization.load_pem_public_key(oldpub.read_bytes())
            if not isinstance(oldkey,Ed25519PrivateKey) or not isinstance(oldpublic,Ed25519PublicKey) or _raw_id(oldkey.public_key())!=_raw_id(oldpublic): raise ValueError('legacy_keypair_mismatch')
            kid=_raw_id(oldpublic); td=_trusted_dir(); td.mkdir(parents=True,exist_ok=True)
            _atomic(td/f'{kid}.private.pem',oldpriv.read_bytes(),0o600); _atomic(td/f'{kid}.public.pem',oldpub.read_bytes(),0o644)
            _atomic(_active_file(),json.dumps({'key_id':kid,'migrated_from_v1':True},sort_keys=True).encode()+b'\n')
        else: _new_pair()
        active=_load_json(_active_file(),None)
    kid=active['key_id']; td=_trusted_dir(); privp=td/f'{kid}.private.pem'; pubp=td/f'{kid}.public.pem'
    # Migrate V1 default key files without changing its identity.
    oldpriv=_key_dir()/'anchor_ed25519_private.pem'; oldpub=_key_dir()/'anchor_ed25519_public.pem'
    if not privp.exists() and oldpriv.exists() and oldpub.exists():
        key=serialization.load_pem_private_key(oldpriv.read_bytes(),password=None); pub=serialization.load_pem_public_key(oldpub.read_bytes())
        if not isinstance(key,Ed25519PrivateKey) or not isinstance(pub,Ed25519PublicKey) or _raw_id(key.public_key())!=kid or _raw_id(pub)!=kid: raise ValueError('legacy_keypair_mismatch')
        td.mkdir(parents=True,exist_ok=True); _atomic(privp,oldpriv.read_bytes(),0o600); _atomic(pubp,oldpub.read_bytes(),0o644)
    if not privp.exists() or not pubp.exists(): raise RuntimeError('active_anchor_key_missing')
    private=serialization.load_pem_private_key(privp.read_bytes(),password=None); public=serialization.load_pem_public_key(pubp.read_bytes())
    if not isinstance(private,Ed25519PrivateKey) or not isinstance(public,Ed25519PublicKey) or _raw_id(public)!=kid or _raw_id(private.public_key())!=kid: raise ValueError('anchor_keypair_mismatch')
    return {'private':private,'public':public,'key_id':kid,'public_key_pem':public.public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo).decode()}

def rotate_key(*, revoke_old=False) -> dict:
    old=ensure_keypair()['key_id']; new=_new_pair()
    if revoke_old: revoke_key(old)
    return {'rotated':True,'old_key_id':old,'new_key_id':new,'old_key_revoked':bool(revoke_old)}

def revoke_key(key_id: str) -> dict:
    if len(key_id)!=64 or any(c not in '0123456789abcdef' for c in key_id): raise ValueError('invalid_key_id')
    p=_revoked_file(); state=_load_json(p,{'revoked':[]}); rows=set(state.get('revoked',[])); rows.add(key_id)
    _atomic(p,json.dumps({'revoked':sorted(rows),'updated_at':datetime.now(timezone.utc).isoformat()},sort_keys=True).encode()+b'\n')
    return {'revoked':True,'key_id':key_id}

def export_public_key(key_id: str|None=None) -> dict:
    kp=ensure_keypair(); kid=key_id or kp['key_id']; p=_trusted_dir()/f'{kid}.public.pem'
    if not p.is_file(): raise FileNotFoundError('trusted_public_key_not_found')
    return {'key_id':kid,'fingerprint_sha256':kid,'public_key_pem':p.read_text(encoding='utf-8')}

def import_trusted_public_key(public_key_pem: str, *, expected_fingerprint: str) -> dict:
    pub=serialization.load_pem_public_key(public_key_pem.encode() if isinstance(public_key_pem,str) else public_key_pem)
    if not isinstance(pub,Ed25519PublicKey): raise ValueError('trusted_anchor_key_type_invalid')
    kid=_raw_id(pub)
    if kid.lower()!=expected_fingerprint.lower(): raise ValueError('fingerprint_confirmation_mismatch')
    p=_trusted_dir()/f'{kid}.public.pem'; _atomic(p,pub.public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo),0o644)
    return {'imported':True,'key_id':kid,'fingerprint_sha256':kid}

def _next_sequence():
    p=_sequence_file(); state=_load_json(p,{'highest_sequence':0}); n=int(state.get('highest_sequence',0))+1
    _atomic(p,json.dumps({'highest_sequence':n,'updated_at':datetime.now(timezone.utc).isoformat()},sort_keys=True).encode()+b'\n')
    return n

def sign_backup(backup_sha256: str, registry_head_hash: str, paper_head_hash: str) -> dict:
    kp=ensure_keypair(); sequence=_next_sequence()
    payload={'schema_version':SCHEMA,'backup_sha256':backup_sha256,'registry_head_hash':registry_head_hash,'paper_head_hash':paper_head_hash,'key_id':kp['key_id'],'sequence':sequence,'signed_at':datetime.now(timezone.utc).isoformat()}
    raw=json.dumps(payload,sort_keys=True,separators=(',',':')).encode()
    return {**payload,'signature':base64.b64encode(kp['private'].sign(raw)).decode(),'public_key_pem':kp['public_key_pem']}

def verify_anchor(anchor: dict, *, trusted_public_key_path: str|Path|None=None, enforce_anti_rollback=True) -> dict:
    try:
        schema=anchor.get('schema_version')
        if schema not in (SCHEMA,LEGACY_SCHEMA): raise ValueError('anchor_schema_unsupported')
        kid=anchor.get('key_id')
        revoked=set(_load_json(_revoked_file(),{'revoked':[]}).get('revoked',[]))
        if kid in revoked: raise ValueError('anchor_key_revoked')
        if trusted_public_key_path is not None: pubpath=Path(trusted_public_key_path).expanduser().resolve()
        else: pubpath=_trusted_dir()/f'{kid}.public.pem'
        if not pubpath.is_file():
            # V1 compatibility for the original default trust pair.
            legacy=_key_dir()/'anchor_ed25519_public.pem'
            pubpath=legacy if legacy.is_file() and schema==LEGACY_SCHEMA else pubpath
        if not pubpath.is_file(): raise ValueError('trusted_anchor_public_key_missing')
        pub=serialization.load_pem_public_key(pubpath.read_bytes())
        if not isinstance(pub,Ed25519PublicKey): raise ValueError('trusted_anchor_key_type_invalid')
        if _raw_id(pub)!=kid: raise ValueError('anchor_key_id_mismatch')
        keys=('schema_version','backup_sha256','registry_head_hash','paper_head_hash','key_id')
        if schema==SCHEMA: keys+=('sequence','signed_at')
        payload={k:anchor[k] for k in keys}
        pub.verify(base64.b64decode(anchor['signature'],validate=True),json.dumps(payload,sort_keys=True,separators=(',',':')).encode())
        seq=int(anchor.get('sequence',0))
        if schema==SCHEMA and enforce_anti_rollback:
            state=_load_json(_sequence_file(),{'highest_sequence':0}); high=int(state.get('highest_sequence',0))
            if seq < high: raise ValueError(f'anchor_rollback_detected:sequence={seq}:highest={high}')
            if seq > high: _atomic(_sequence_file(),json.dumps({'highest_sequence':seq,'updated_at':datetime.now(timezone.utc).isoformat()},sort_keys=True).encode()+b'\n')
        return {'valid':True,'key_id':kid,'sequence':seq,'errors':[]}
    except Exception as exc: return {'valid':False,'key_id':anchor.get('key_id'),'errors':[str(exc)]}


def trust_store_health() -> dict:
    """Read-only trust-store diagnostic; never silently regenerates lost keys."""
    try:
        active = _load_json(_active_file(), None)
        if not active:
            return {'healthy': False, 'state': 'active_key_record_missing', 'errors': ['active_key_record_missing']}
        kid = active.get('key_id', '')
        if len(kid) != 64:
            return {'healthy': False, 'state': 'active_key_record_invalid', 'errors': ['active_key_id_invalid']}
        td = _trusted_dir(); privp = td / f'{kid}.private.pem'; pubp = td / f'{kid}.public.pem'
        if not privp.is_file() or not pubp.is_file():
            return {'healthy': False, 'state': 'active_key_material_missing', 'key_id': kid, 'errors': ['active_key_material_missing']}
        priv = serialization.load_pem_private_key(privp.read_bytes(), password=None)
        pub = serialization.load_pem_public_key(pubp.read_bytes())
        if not isinstance(priv, Ed25519PrivateKey) or not isinstance(pub, Ed25519PublicKey) or _raw_id(priv.public_key()) != kid or _raw_id(pub) != kid:
            return {'healthy': False, 'state': 'active_key_material_mismatch', 'key_id': kid, 'errors': ['active_key_material_mismatch']}
        revoked = set(_load_json(_revoked_file(), {'revoked': []}).get('revoked', []))
        if kid in revoked:
            return {'healthy': False, 'state': 'active_key_revoked', 'key_id': kid, 'errors': ['active_key_revoked']}
        return {'healthy': True, 'state': 'ok', 'key_id': kid, 'errors': []}
    except Exception as exc:
        return {'healthy': False, 'state': 'trust_store_unreadable', 'errors': [f'{type(exc).__name__}:{exc}']}
