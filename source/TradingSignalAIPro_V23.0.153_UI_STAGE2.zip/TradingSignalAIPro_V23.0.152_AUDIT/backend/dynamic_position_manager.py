"""V23.0.68 advisory dynamic management for PAPER positions; no execution."""
from __future__ import annotations
import math

DEFAULTS = {'breakeven_at_r': 1.0, 'trailing_start_r': 1.5, 'atr_multiple': 2.0,
            'partial_take_profit_r': 1.0, 'partial_fraction': 0.25,
            'fee_bps_round_trip': 20.0, 'slippage_bps_round_trip': 10.0}

def _num(v, name, minimum=0.0):
    try: x=float(v)
    except (TypeError, ValueError, OverflowError): raise ValueError(f'{name} نامعتبر است')
    if not math.isfinite(x) or x < minimum: raise ValueError(f'{name} نامعتبر است')
    return x

def _tighter(side, candidate, current):
    return max(candidate,current) if side=='LONG' else min(candidate,current)

def evaluate_open_paper_positions(positions, settings=None):
    if not isinstance(positions,list): raise ValueError('positions باید فهرست باشد')
    cfg=dict(DEFAULTS); cfg.update(settings or {})
    out=[]; seen=set(); errors=[]
    for i,p in enumerate(positions):
        if not isinstance(p,dict): errors.append({'index':i,'reason':'position نامعتبر'}); continue
        pid=str(p.get('position_id') or '').strip(); symbol=str(p.get('symbol') or '').upper().strip()
        side=str(p.get('side') or '').upper().strip()
        if not pid or not symbol or side not in ('LONG','SHORT'):
            errors.append({'index':i,'reason':'position_id، symbol یا side نامعتبر'}); continue
        if pid in seen: errors.append({'index':i,'reason':'شناسه موقعیت تکراری'}); continue
        seen.add(pid)
        try:
            entry=_num(p.get('entry_price'),'entry_price',1e-12); current=_num(p.get('current_price'),'current_price',1e-12)
            stop=_num(p.get('stop_price'),'stop_price',1e-12); atr=_num(p.get('atr'),'atr',1e-12)
            qty=_num(p.get('quantity'),'quantity',1e-12)
            fee=_num(cfg['fee_bps_round_trip'],'fee_bps_round_trip'); slip=_num(cfg['slippage_bps_round_trip'],'slippage_bps_round_trip')
            be_r=_num(cfg['breakeven_at_r'],'breakeven_at_r',1e-9); trail_r=_num(cfg['trailing_start_r'],'trailing_start_r',1e-9)
            atr_mult=_num(cfg['atr_multiple'],'atr_multiple',1e-9); part_r=_num(cfg['partial_take_profit_r'],'partial_take_profit_r',1e-9)
            fraction=_num(cfg['partial_fraction'],'partial_fraction',1e-9)
            if fraction>=1: raise ValueError('partial_fraction باید کمتر از ۱ باشد')
            initial=_num(p.get('initial_stop_price',stop),'initial_stop_price',1e-12)
            risk=abs(entry-initial)
            if (side=='LONG' and not initial<entry) or (side=='SHORT' and not initial>entry): raise ValueError('جهت حد ضرر اولیه با سمت معامله سازگار نیست')
            favorable=(current-entry) if side=='LONG' else (entry-current)
            r_multiple=favorable/risk
            # Round-trip friction is deducted conservatively from unrealized PnL estimate.
            gross_pnl=favorable*qty; friction=(entry*qty)*(fee+slip)/10000.0
            net_pnl=gross_pnl-friction
            candidate=stop; actions=[]
            if r_multiple>=be_r:
                cost_buffer=entry*(fee+slip)/10000.0
                be_price=entry+cost_buffer if side=='LONG' else entry-cost_buffer
                tightened=_tighter(side,be_price,candidate)
                if tightened!=candidate: candidate=tightened; actions.append('MOVE_STOP_TO_COST_ADJUSTED_BREAKEVEN')
            if r_multiple>=trail_r:
                trail=current-atr*atr_mult if side=='LONG' else current+atr*atr_mult
                tightened=_tighter(side,trail,candidate)
                if (side=='LONG' and tightened>candidate) or (side=='SHORT' and tightened<candidate):
                    candidate=tightened; actions.append('UPDATE_ATR_TRAILING_STOP')
            partial_key=f'{pid}:PARTIAL:{part_r:g}R'
            partial_done=bool(p.get('partial_take_profit_done',False))
            if r_multiple>=part_r and not partial_done: actions.append('PARTIAL_TAKE_PROFIT_RECOMMENDED')
            # Never loosen an existing stop; never generate executable order payloads.
            if not actions: actions=['HOLD_AND_MONITOR']
            out.append({'position_id':pid,'symbol':symbol,'side':side,'r_multiple':round(r_multiple,5),
                'estimated_gross_unrealized_pnl_usdt':round(gross_pnl,8),'estimated_round_trip_cost_usdt':round(friction,8),
                'estimated_net_unrealized_pnl_usdt':round(net_pnl,8),'recommended_stop_price':round(candidate,12),
                'stop_changed':candidate!=stop,'actions':actions,'partial_fraction':fraction if 'PARTIAL_TAKE_PROFIT_RECOMMENDED' in actions else 0.0,
                'partial_event_key':partial_key if 'PARTIAL_TAKE_PROFIT_RECOMMENDED' in actions else None,
                'idempotency_note':'مصرف‌کننده باید partial_event_key را ثبت کند و کلید تکراری را دوباره اجرا نکند.'})
        except ValueError as exc: errors.append({'index':i,'position_id':pid,'reason':str(exc)})
    return {'version':'23.0.68','positions':out,'invalid_positions':errors,'position_count':len(out),
        'read_only':True,'paper_only':True,'recommendations_only':True,'creates_orders':False,
        'execution_authorized':False,'real_orders_enabled':False}
