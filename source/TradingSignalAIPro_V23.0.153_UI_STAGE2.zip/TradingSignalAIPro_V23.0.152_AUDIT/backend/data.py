"""Resilient multi-provider OHLCV downloader for Trading Signal AI Pro.

Providers: Binance, Bybit, OKX, KuCoin, MEXC, Gate.io, Coinbase,
Nobitex, CoinMarketCap (API key required), and Yahoo Finance.
All returned frames use: t (milliseconds), open, high, low, close, volume.
"""
from __future__ import annotations

import math
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd
import requests

TIMEFRAME_SECONDS = {'5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400, '1d': 86400}
COMMODITIES_YAHOO = {'XAUUSD': 'GC=F', 'XAGUSD': 'SI=F', 'GOLD': 'GC=F', 'SILVER': 'SI=F', 'WTI': 'CL=F', 'BRENT': 'BZ=F'}

# Load optional local secrets from project-root .env without an extra dependency.
_ENV_FILE = Path(__file__).resolve().parents[1] / '.env'
if _ENV_FILE.exists():
    for _line in _ENV_FILE.read_text(encoding='utf-8-sig').splitlines():
        _line = _line.strip()
        if _line and not _line.startswith('#') and '=' in _line:
            _key, _value = _line.split('=', 1)
            os.environ.setdefault(_key.strip(), _value.strip().strip('\"').strip("'"))

SESSION = requests.Session()
SESSION.headers.update({'User-Agent': 'TradingSignalAIPro/5.0 (+market-data-client)', 'Accept': 'application/json'})
# V19.3: optional proxy for filtered networks (http://host:port or socks5://host:port).
_PROXY = os.getenv('TS_AI_PROXY', '').strip()
if _PROXY:
    SESSION.proxies.update({'http': _PROXY, 'https': _PROXY})


def _get(url: str, timeout: int = 15, params=None, headers=None):
    """GET JSON. Short connect timeout; a host that does not answer is NOT retried
    (retrying a blocked/dead server only wastes time — the caller moves on)."""
    last_error = None
    for attempt in range(2):
        try:
            response = SESSION.get(url, params=params, headers=headers,
                                   timeout=(min(5, timeout), timeout))
            if response.status_code in (418, 429):
                raise RuntimeError(f'محدودیت درخواست از سرویس ({response.status_code})')
            response.raise_for_status()
            try:
                return response.json()
            except ValueError as exc:
                raise RuntimeError('پاسخ سرویس JSON معتبر نیست') from exc
        except (requests.ConnectTimeout, requests.ConnectionError) as exc:
            last_error = exc
            break                       # unreachable host: skip, do not retry
        except (requests.RequestException, RuntimeError) as exc:
            last_error = exc
            if attempt == 0 and isinstance(exc, requests.RequestException):
                time.sleep(0.35)
    raise RuntimeError(str(last_error or 'خطای ناشناخته شبکه'))


# ---- source health: a source that does not answer is skipped for a while ----
_SOURCE_DOWN: dict = {}          # source -> (retry_after_ts, reason)
NET_COOLDOWN_SEC = 180           # unreachable / blocked / timeout
OTHER_COOLDOWN_SEC = 60          # bad symbol, empty answer, ...


def _mark_failed(src: str, exc: Exception):
    text = str(exc).lower()
    network = any(k in text for k in ('timed out', 'timeout', 'connection', 'name or service',
                                      'max retries', '451', '403', 'ssl', 'proxy', 'refused'))
    _SOURCE_DOWN[src] = (time.time() + (NET_COOLDOWN_SEC if network else OTHER_COOLDOWN_SEC),
                         str(exc)[:160])


def _cooling(src: str) -> bool:
    item = _SOURCE_DOWN.get(src)
    if not item:
        return False
    if time.time() >= item[0]:
        _SOURCE_DOWN.pop(src, None)
        return False
    return True


def reset_source_health():
    """Forget all cool-downs (e.g. after the user turned a VPN on)."""
    _SOURCE_DOWN.clear()


def source_health() -> dict:
    now = time.time()
    return {k: {'retry_in_sec': int(v[0] - now), 'reason': v[1]}
            for k, v in _SOURCE_DOWN.items() if v[0] > now}


def _clean_candles(rows) -> pd.DataFrame:
    """Normalize provider rows while retaining an audit of anything discarded.

    Legacy consumers receive a sorted, normalized frame. V22 callers inspect
    ``frame.attrs['normalization_audit']`` to distinguish harmless exact duplicates
    and reverse ordering from conflicting or malformed source rows.
    """
    df = pd.DataFrame(rows)
    empty_columns = ['t', 'open', 'high', 'low', 'close', 'volume']
    if df.empty:
        out = pd.DataFrame(columns=empty_columns)
        out.attrs['normalization_audit'] = {
            'raw_rows': 0, 'malformed_rows_dropped': 0, 'duplicate_rows_dropped': 0,
            'duplicate_rows_seen': 0, 'duplicate_conflict_groups': 0,
            'out_of_order': False, 'missing_volume_rows': 0, 'volume_available': True,
        }
        return out
    aliases = {'o': 'open', 'h': 'high', 'l': 'low', 'c': 'close', 'v': 'volume'}
    df = df.rename(columns={k: v for k, v in aliases.items() if k in df.columns})
    required = ['t', 'open', 'high', 'low', 'close']
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError('داده ناقص است؛ ستون‌های ناموجود: ' + ', '.join(missing))
    volume_available = 'volume' in df.columns
    if not volume_available:
        df['volume'] = np.nan
    for col in required + ['volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    raw_rows = len(df)
    missing_volume_rows = int(df['volume'].isna().sum())
    duplicate_mask = df['t'].duplicated(keep=False)
    duplicate_rows_seen = int(duplicate_mask.sum())
    duplicate_rows_dropped = int(df['t'].duplicated(keep='first').sum())
    duplicate_conflict_groups = 0
    if duplicate_rows_seen:
        duplicate_values = ['open', 'high', 'low', 'close', 'volume']
        for _, group in df.loc[duplicate_mask].groupby('t', sort=False, dropna=False):
            # Identical repeated rows are safe to collapse. Different OHLCV values
            # at the same timestamp are ambiguous and must remain visible as risk.
            if bool((group[duplicate_values].nunique(dropna=False) > 1).any()):
                duplicate_conflict_groups += 1
    numeric_t = df['t'].to_numpy(dtype=float)
    out_of_order = bool(len(numeric_t) > 1 and np.isfinite(numeric_t).all()
                        and np.any(np.diff(numeric_t) < 0))
    # Provider candle timestamps are integer milliseconds. Do not silently
    # truncate fractional timestamps to int64: that can make a misaligned row
    # appear valid after normalization.
    timestamp_integral = (np.isfinite(numeric_t) &
                          (numeric_t == np.floor(numeric_t)) &
                          (numeric_t < float(2 ** 63)))
    # Count malformed OHLC/t/volume rows before legacy filtering.
    req_values = df[required].to_numpy(dtype=float)
    finite = np.isfinite(req_values).all(axis=1)
    vol = df['volume'].to_numpy(dtype=float)
    volume_valid = np.isnan(vol) | (np.isfinite(vol) & (vol >= 0))
    o, h, l, c = (df[k].to_numpy(dtype=float) for k in ('open', 'high', 'low', 'close'))
    geometry = ((h >= np.maximum.reduce([o, c, l])) &
                (l <= np.minimum.reduce([o, c, h])))
    valid = (finite & timestamp_integral & volume_valid &
             (df['t'].to_numpy(dtype=float) > 0) &
             (req_values[:, 1:] > 0).all(axis=1) & geometry)
    malformed_rows = int((~valid).sum())

    # Keep the historical zero-fill for UI compatibility only. The audit makes
    # missing volume visible; V22 training/signal consumers fail closed on it.
    df['volume'] = df['volume'].replace([float('inf'), float('-inf')], pd.NA).fillna(0.0)
    finite_volume = np.isfinite(df['volume'].to_numpy(dtype=float))
    valid_legacy = (valid & finite_volume & (df['volume'].to_numpy(dtype=float) >= 0))
    df = df.loc[valid_legacy].copy()
    if df.empty:
        out = pd.DataFrame(columns=empty_columns)
    else:
        df['t'] = df['t'].astype('int64')
        df = df.drop_duplicates('t').sort_values('t').reset_index(drop=True)
        out = df[empty_columns].copy()
    out.attrs['normalization_audit'] = {
        'raw_rows': int(raw_rows), 'malformed_rows_dropped': malformed_rows,
        'duplicate_rows_dropped': duplicate_rows_dropped,
        'duplicate_rows_seen': duplicate_rows_seen,
        'duplicate_conflict_groups': duplicate_conflict_groups,
        'out_of_order': out_of_order,
        'missing_volume_rows': missing_volume_rows,
        'volume_available': bool(volume_available and missing_volume_rows == 0),
    }
    return out


def _drop_unclosed(df: pd.DataFrame, tf: str) -> pd.DataFrame:
    if df.empty:
        return df
    step_ms = TIMEFRAME_SECONDS[tf] * 1000
    now_ms = int(time.time() * 1000)
    # Keep only bars whose open time + interval is <= current time.
    return df[df['t'] + step_ms <= now_ms].reset_index(drop=True)


def _rows_from_arrays(data, timestamp_unit='ms'):
    rows = []
    for i, x in enumerate(data.get('t', [])):
        try:
            t = int(float(x) * (1000 if timestamp_unit == 's' else 1))
            volume_values = data.get('v')
            try:
                volume = volume_values[i] if volume_values is not None else None
            except (IndexError, TypeError):
                volume = None
            rows.append({'t': t, 'open': data['o'][i], 'high': data['h'][i],
                         'low': data['l'][i], 'close': data['c'][i],
                         'volume': volume})
        except (IndexError, TypeError, ValueError):
            continue
    return rows


def _aggregate(df: pd.DataFrame, seconds: int, *, source_seconds: int | None = None) -> pd.DataFrame:
    """Aggregate normalized OHLCV candles without inventing partial bars.

    When ``source_seconds`` is supplied, an output candle is emitted only when
    every expected source candle is present exactly once in its UTC-aligned
    bucket. This is required for providers that synthesize 30m/4h bars from
    smaller intervals (Coinbase and Yahoo). The source normalization audit is
    propagated so discarded malformed/conflicting source rows remain visible
    to the Data Contract after aggregation.
    """
    if seconds <= 0:
        raise ValueError('aggregate timeframe must be positive')
    if source_seconds is not None:
        source_seconds = int(source_seconds)
        if source_seconds <= 0 or seconds % source_seconds:
            raise ValueError('source_seconds must be a positive divisor of seconds')

    inherited_attrs = dict(getattr(df, 'attrs', {}) or {})
    if df.empty:
        out = df.copy()
        out.attrs.update(inherited_attrs)
        if source_seconds is not None:
            out.attrs['aggregation_audit'] = {
                'source_seconds': source_seconds,
                'target_seconds': int(seconds),
                'expected_source_bars': int(seconds // source_seconds),
                'incomplete_bucket_count': 0,
                'incomplete_source_rows_dropped': 0,
            }
        return out

    x = df.copy()
    x['t'] = pd.to_numeric(x['t'], errors='coerce')
    x = x.dropna(subset=['t']).sort_values('t').reset_index(drop=True)
    x['t'] = x['t'].astype('int64')
    width_ms = int(seconds) * 1000
    x['bucket'] = (x['t'] // width_ms) * width_ms

    incomplete_bucket_count = 0
    incomplete_source_rows_dropped = 0
    if source_seconds is not None:
        source_ms = source_seconds * 1000
        expected = int(seconds // source_seconds)
        complete_buckets = []
        for bucket, group in x.groupby('bucket', sort=True):
            observed = group['t'].astype('int64').tolist()
            expected_timestamps = [int(bucket) + i * source_ms for i in range(expected)]
            if len(observed) == expected and observed == expected_timestamps:
                complete_buckets.append(int(bucket))
            else:
                incomplete_bucket_count += 1
                incomplete_source_rows_dropped += len(group)
        x = x[x['bucket'].isin(complete_buckets)].copy()

    if x.empty:
        out = pd.DataFrame(columns=['t', 'open', 'high', 'low', 'close', 'volume'])
    else:
        out = x.groupby('bucket', as_index=False, sort=True).agg(
            t=('bucket', 'first'), open=('open', 'first'), high=('high', 'max'),
            low=('low', 'min'), close=('close', 'last'), volume=('volume', 'sum'))
        out = out[['t', 'open', 'high', 'low', 'close', 'volume']]

    out.attrs.update(inherited_attrs)
    if source_seconds is not None:
        out.attrs['aggregation_audit'] = {
            'source_seconds': source_seconds,
            'target_seconds': int(seconds),
            'expected_source_bars': int(seconds // source_seconds),
            'incomplete_bucket_count': int(incomplete_bucket_count),
            'incomplete_source_rows_dropped': int(incomplete_source_rows_dropped),
        }
    return out


def fetch_binance(symbol, tf, limit=5000):
    interval = tf
    step = TIMEFRAME_SECONDS[tf]
    rows, end_ms = [], int(time.time() * 1000)
    for _ in range(math.ceil(limit / 1000)):
        start_ms = end_ms - 1000 * step * 1000
        params = {'symbol': symbol.upper(), 'interval': interval, 'startTime': start_ms,
                  'endTime': end_ms, 'limit': 1000}
        try:
            data = _get('https://data-api.binance.vision/api/v3/klines', 12, params)
        except Exception:
            data = _get('https://api.binance.com/api/v3/klines', 12, params)
        if not isinstance(data, list) or not data:
            break
        rows.extend({'t': int(x[0]), 'open': x[1], 'high': x[2], 'low': x[3], 'close': x[4], 'volume': x[5]} for x in data)
        if len(data) < 1000:
            break
        end_ms = start_ms - 1
    return _clean_candles(rows).tail(limit)


def fetch_bybit(symbol, tf, limit=5000, category='spot'):
    interval = {'5m': '5', '15m': '15', '30m': '30', '1h': '60', '4h': '240', '1d': 'D'}[tf]
    step, rows, end_ms = TIMEFRAME_SECONDS[tf], [], int(time.time() * 1000)
    for _ in range(math.ceil(limit / 1000)):
        start_ms = end_ms - 1000 * step * 1000
        data = _get('https://api.bybit.com/v5/market/kline', 12, {
            'category': category, 'symbol': symbol.upper(), 'interval': interval,
            'start': start_ms, 'end': end_ms, 'limit': 1000})
        if data.get('retCode') != 0:
            raise RuntimeError(f"Bybit: {data.get('retMsg', 'خطای API')}")
        candles = data.get('result', {}).get('list') or []
        if not candles:
            break
        rows.extend({'t': int(x[0]), 'open': x[1], 'high': x[2], 'low': x[3], 'close': x[4], 'volume': x[5]} for x in candles)
        if len(candles) < 1000:
            break
        end_ms = start_ms - 1
    return _clean_candles(rows).tail(limit)


def fetch_okx(symbol, tf, limit=3000, swap=False):
    """OKX: fetch current bars first, then page older history with `after`."""
    inst = symbol.upper().replace('USDT', '-USDT').replace('USDC', '-USDC')
    if swap:
        inst += '-SWAP'
    bar = {'5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '4h': '4H', '1d': '1D'}[tf]
    rows = []
    # /market/candles includes the newest bars; history-candles is for older bars.
    current = _get('https://www.okx.com/api/v5/market/candles', 12,
                   {'instId': inst, 'bar': bar, 'limit': min(300, limit)})
    if current.get('code') != '0':
        raise RuntimeError(f"OKX: {current.get('msg', 'خطای API')}")
    candles = current.get('data') or []
    rows.extend({'t': int(x[0]), 'open': x[1], 'high': x[2], 'low': x[3],
                 'close': x[4], 'volume': x[5]} for x in candles)
    if candles and len(rows) < limit:
        after = candles[-1][0]  # OKX returns newest first; `after` pages older records.
        pages = math.ceil((limit - len(rows)) / 300)
        for _ in range(pages):
            data = _get('https://www.okx.com/api/v5/market/history-candles', 12,
                        {'instId': inst, 'bar': bar, 'limit': 300, 'after': after})
            if data.get('code') != '0':
                raise RuntimeError(f"OKX history: {data.get('msg', 'خطای API')}")
            older = data.get('data') or []
            if not older:
                break
            rows.extend({'t': int(x[0]), 'open': x[1], 'high': x[2], 'low': x[3],
                         'close': x[4], 'volume': x[5]} for x in older)
            after = older[-1][0]
            if len(older) < 300:
                break
    return _clean_candles(rows).tail(limit)


def fetch_kucoin(symbol, tf, limit=5000):
    inst = symbol.upper().replace('USDT', '-USDT').replace('USDC', '-USDC')
    typ = {'5m': '5min', '15m': '15min', '30m': '30min', '1h': '1hour', '4h': '4hour', '1d': '1day'}[tf]
    step, rows, end_at = TIMEFRAME_SECONDS[tf], [], int(time.time())
    for _ in range(math.ceil(limit / 1500)):
        start_at = end_at - 1500 * step
        data = _get('https://api.kucoin.com/api/v1/market/candles', 12,
                    {'symbol': inst, 'type': typ, 'startAt': start_at, 'endAt': end_at})
        if data.get('code') != '200000':
            raise RuntimeError(f"KuCoin: {data.get('msg', 'خطای API')}")
        candles = data.get('data') or []
        if not candles:
            break
        rows.extend({'t': int(float(x[0]) * 1000), 'open': x[1], 'close': x[2], 'high': x[3], 'low': x[4], 'volume': x[5]} for x in candles)
        if len(candles) < 1500:
            break
        end_at = start_at - 1
    return _clean_candles(rows).tail(limit)


def fetch_mexc(symbol, tf, limit=5000):
    interval = {'5m': '5m', '15m': '15m', '30m': '30m', '1h': '60m', '4h': '4h', '1d': '1d'}[tf]
    step, rows, end_ms = TIMEFRAME_SECONDS[tf], [], int(time.time() * 1000)
    for _ in range(math.ceil(limit / 1000)):
        start_ms = end_ms - 1000 * step * 1000
        data = _get('https://api.mexc.com/api/v3/klines', 12, {
            'symbol': symbol.upper(), 'interval': interval, 'startTime': start_ms,
            'endTime': end_ms, 'limit': 1000})
        if not isinstance(data, list) or not data:
            break
        rows.extend({'t': int(x[0]), 'open': x[1], 'high': x[2], 'low': x[3], 'close': x[4], 'volume': x[5]} for x in data)
        if len(data) < 1000:
            break
        end_ms = start_ms - 1
    return _clean_candles(rows).tail(limit)


def fetch_gateio(symbol, tf, limit=5000):
    pair = symbol.upper().replace('USDT', '_USDT').replace('USDC', '_USDC')
    interval = {'5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d'}[tf]
    step, rows = TIMEFRAME_SECONDS[tf], []
    end_ts = int(time.time())
    for _ in range(math.ceil(limit / 1000)):
        start_ts = end_ts - 1000 * step
        data = _get('https://api.gateio.ws/api/v4/spot/candlesticks', 12, {
            'currency_pair': pair, 'interval': interval, 'from': start_ts, 'to': end_ts, 'limit': 1000})
        if not isinstance(data, list) or not data:
            break
        # Gate.io: [timestamp, volume, close, high, low, open, ...]
        rows.extend({'t': int(x[0]) * 1000, 'open': x[5], 'high': x[3], 'low': x[4], 'close': x[2], 'volume': x[1]} for x in data if len(x) >= 6)
        if len(data) < 1000:
            break
        end_ts = start_ts - 1
    return _clean_candles(rows).tail(limit)


def fetch_coinbase(symbol, tf, limit=2000):
    base = symbol.upper().replace('USDT', '').replace('USDC', '')
    product = f'{base}-USD'
    # Coinbase has no 30m candle: build it from 15m bars.
    granularity = {'5m': 300, '15m': 900, '30m': 900, '1h': 3600, '4h': 3600, '1d': 86400}[tf]
    # Coinbase limits each request to 300 candles; paginate by time windows.
    rows, end_ts = [], int(time.time())
    requested_rows = limit * {'4h': 4, '30m': 2}.get(tf, 1)
    for _ in range(math.ceil(requested_rows / 300)):
        start_ts = end_ts - 300 * granularity
        url = f'https://api.exchange.coinbase.com/products/{product}/candles'
        data = _get(url, 12, {'granularity': granularity,
                              'start': datetime.fromtimestamp(start_ts, timezone.utc).isoformat(),
                              'end': datetime.fromtimestamp(end_ts, timezone.utc).isoformat()})
        if not isinstance(data, list) or not data:
            break
        rows.extend({'t': int(x[0]) * 1000, 'low': x[1], 'high': x[2], 'open': x[3], 'close': x[4], 'volume': x[5]} for x in data if len(x) >= 6)
        if len(data) < 300:
            break
        end_ts = start_ts - 1
    frame = _clean_candles(rows).tail(requested_rows)
    if tf == '4h':
        frame = _aggregate(frame, 4 * 3600, source_seconds=3600)
    elif tf == '30m':
        frame = _aggregate(frame, 30 * 60, source_seconds=900)
    return frame.tail(limit)


def fetch_kraken(symbol, tf, limit=700):
    """Kraken public OHLC. No key needed; a useful extra fallback when the
    main exchanges are blocked. Kraken caps each reply at ~720 bars."""
    pair = symbol.upper().replace('BTC', 'XBT')
    interval = {'5m': 5, '15m': 15, '30m': 30, '1h': 60, '4h': 240, '1d': 1440}[tf]
    data = _get('https://api.kraken.com/0/public/OHLC', 12, {'pair': pair, 'interval': interval})
    if data.get('error'):
        raise RuntimeError('Kraken: ' + '; '.join(data['error']))
    result = data.get('result') or {}
    key = next((k for k in result if k != 'last'), None)
    raw = result.get(key) or []
    rows = [{'t': int(x[0]) * 1000, 'open': x[1], 'high': x[2], 'low': x[3],
             'close': x[4], 'volume': x[6]} for x in raw]
    return _clean_candles(rows).tail(limit)


def fetch_bitget(symbol, tf, limit=5000):
    """Bitget public spot candles. No key needed; another independent fallback."""
    granularity = {'5m': '5min', '15m': '15min', '30m': '30min', '1h': '1h', '4h': '4h', '1d': '1day'}[tf]
    step, rows, end_ms = TIMEFRAME_SECONDS[tf] * 1000, [], int(time.time() * 1000)
    for _ in range(math.ceil(limit / 200)):
        start_ms = end_ms - 200 * step
        data = _get('https://api.bitget.com/api/v2/spot/market/candles', 12, {
            'symbol': symbol.upper(), 'granularity': granularity,
            'startTime': start_ms, 'endTime': end_ms, 'limit': 200})
        if data.get('code') not in ('00000', None):
            raise RuntimeError(f"Bitget: {data.get('msg', 'خطای API')}")
        candles = data.get('data') or []
        if not candles:
            break
        rows.extend({'t': int(x[0]), 'open': x[1], 'high': x[2], 'low': x[3],
                     'close': x[4], 'volume': x[5]} for x in candles)
        if len(candles) < 200:
            break
        end_ms = start_ms - 1
    return _clean_candles(rows).tail(limit)


def fetch_lbank(symbol, tf, limit=2000):
    """LBank public spot OHLCV. Public endpoint; no API key or trading permission."""
    interval = {
        '5m': 'minute5', '15m': 'minute15', '30m': 'minute30',
        '1h': 'hour1', '4h': 'hour4', '1d': 'day1',
    }.get(tf)
    if not interval:
        raise ValueError(f'LBank پشتیبانی از تایم‌فریم {tf} را اعلام نکرده است')
    count = max(1, min(int(limit), 2000))
    start_s = max(0, int(time.time()) - count * TIMEFRAME_SECONDS[tf])
    payload = _get('https://api.lbank.info/v2/kline.do', 15, {
        'symbol': symbol.upper().replace('USDT', '_USDT').replace('USDC', '_USDC').lower(),
        'size': count, 'type': interval, 'time': start_s,
    })
    if not isinstance(payload, dict) or str(payload.get('result')).lower() != 'true':
        raise RuntimeError(f"LBank: {(payload or {}).get('msg', 'پاسخ نامعتبر API')}")
    rows = []
    for x in payload.get('data') or []:
        try:
            rows.append({'t': int(float(x[0])) * 1000, 'open': x[1], 'high': x[2],
                         'low': x[3], 'close': x[4], 'volume': x[5]})
        except (IndexError, TypeError, ValueError):
            continue
    return _clean_candles(rows).tail(count)


def fetch_bit24(symbol, tf, limit=2000):
    """Bit24 public Pro-market OHLCV feed (prices in Toman for IRT markets)."""
    resolution = {'15m': '15m', '1h': '1h', '4h': '4h', '1d': '1D'}.get(tf)
    if not resolution:
        raise ValueError(f'Bit24 پشتیبانی از تایم‌فریم {tf} را اعلام نکرده است')
    count = max(1, min(int(limit), 2000))
    end_s = int(time.time())
    start_s = max(0, end_s - count * TIMEFRAME_SECONDS[tf])
    payload = _get('https://pro.bit24.cash/api/v3/markets/ohclv', 15, {
        'from_ts': start_s, 'to_ts': end_s,
        'base_coin_symbol': symbol.upper().replace('USDT', '').replace('IRT', ''),
        'quote_coin_symbol': 'USDT' if symbol.upper().endswith('USDT') else 'IRT',
        'resolution': resolution,
    })
    if not isinstance(payload, dict) or not isinstance(payload.get('data'), dict):
        raise RuntimeError('Bit24: ساختار پاسخ OHLCV معتبر نیست')
    data = payload['data']
    rows = []
    for x in data.get('results') or []:
        try:
            rows.append({'t': int(x['t']) * 1000, 'open': x['o'], 'high': x['h'],
                         'low': x['l'], 'close': x['c'], 'volume': x.get('v')})
        except (KeyError, TypeError, ValueError):
            continue
    return _clean_candles(rows).tail(count)


def fetch_nobitex(symbol, tf, limit=3000):
    """Nobitex public UDF OHLC endpoint; no API token is needed."""
    resolution = {'5m': '5', '15m': '15', '30m': '30', '1h': '60', '4h': '240', '1d': 'D'}[tf]
    market = symbol.upper().replace('/', '')
    step = TIMEFRAME_SECONDS[tf]
    # UDF endpoint has a bounded response window. Fetch sequential 450-bar chunks.
    end_ts = int(time.time())
    start_ts = end_ts - limit * step
    rows = []
    chunk = 450 * step
    cursor = start_ts
    while cursor < end_ts:
        chunk_end = min(cursor + chunk, end_ts)
        payload = _get('https://apiv2.nobitex.ir/market/udf/history', 15, {
            'symbol': market, 'resolution': resolution, 'from': cursor, 'to': chunk_end})
        status = payload.get('s')
        if status == 'no_data':
            cursor = chunk_end + 1
            continue
        if status != 'ok':
            raise RuntimeError(f"Nobitex OHLC: {payload.get('errmsg') or status or 'پاسخ نامعتبر'}")
        rows.extend(_rows_from_arrays(payload, timestamp_unit='s'))
        cursor = chunk_end + 1
        time.sleep(0.08)
    return _clean_candles(rows).tail(limit)


CMC_SLUGS = {
    'BTC': 'bitcoin', 'ETH': 'ethereum', 'BNB': 'bnb', 'SOL': 'solana',
    'XRP': 'xrp', 'DOGE': 'dogecoin', 'ADA': 'cardano', 'LINK': 'chainlink',
    'AVAX': 'avalanche', 'TON': 'toncoin', 'ICP': 'internet-computer',
    'TRX': 'tron', 'POL': 'polygon-ecosystem-token', 'MATIC': 'polygon',
    'DOT': 'polkadot', 'LTC': 'litecoin', 'NEAR': 'near-protocol',
    'APT': 'aptos', 'ARB': 'arbitrum', 'OP': 'optimism', 'INJ': 'injective',
}


def fetch_coinmarketcap(symbol, tf, limit=3000):
    """Fetch CoinMarketCap OHLCV v5 compact rows; tolerate object-shaped payloads too.

    The documented v5 format is [open, high, low, close, volume, market_cap,
    time_open, time_close, time_high, time_low]. Some wrappers/providers may
    expose the v2-style {quotes:[{time_open, quote:{USD:{...}}}]} shape.
    """
    key = os.getenv('CMC_API_KEY', '').strip()
    if not key:
        raise RuntimeError('برای CoinMarketCap ابتدا CMC_API_KEY را در فایل .env یا متغیر محیطی تنظیم کنید')
    if tf not in ('15m', '1h', '4h', '1d'):
        raise RuntimeError('تایم‌فریم درخواستی توسط CoinMarketCap پشتیبانی نمی‌شود')
    limit = max(1, min(int(limit), 10000))
    base = symbol.upper().replace('USDT', '').replace('USDC', '').replace('USD', '')
    slug = CMC_SLUGS.get(base, base.lower())
    now = datetime.now(timezone.utc)
    start = datetime.fromtimestamp(now.timestamp() - limit * TIMEFRAME_SECONDS[tf], timezone.utc).isoformat()
    payload = _get(
        'https://pro-api.coinmarketcap.com/v5/cryptocurrency/ohlcv/historical', 20,
        {'slug': slug, 'interval': tf, 'count': limit, 'time_start': start,
         'time_end': now.isoformat()},
        headers={'X-CMC_PRO_API_KEY': key})
    data = payload.get('data') if isinstance(payload, dict) else None
    if not data:
        status = payload.get('status') if isinstance(payload, dict) else {}
        message = (status or {}).get('error_message') if isinstance(status, dict) else None
        raise RuntimeError(f"CoinMarketCap: {message or 'کندلی برنگرداند'}")

    if isinstance(data, list):
        quotes = data
    elif isinstance(data, dict):
        if isinstance(data.get('quotes'), list):
            quotes = data['quotes']
        else:
            # Object maps may be keyed by symbol/id and contain a quotes list.
            quotes = []
            for value in data.values():
                if isinstance(value, dict) and isinstance(value.get('quotes'), list):
                    quotes.extend(value['quotes'])
                elif isinstance(value, list):
                    quotes.extend(value)
    else:
        quotes = []

    rows = []
    for item in quotes:
        try:
            if isinstance(item, dict):
                qmap = item.get('quote') or {}
                q = qmap.get('USD') if isinstance(qmap, dict) else None
                if q is None and isinstance(qmap, dict) and qmap:
                    q = next(iter(qmap.values()))
                ts_value = item.get('time_open') or item.get('timestamp')
                if not isinstance(q, dict) or ts_value is None:
                    continue
                ts = int(pd.Timestamp(ts_value).timestamp() * 1000)
                row = {'t': ts, 'open': q.get('open'), 'high': q.get('high'),
                       'low': q.get('low'), 'close': q.get('close'),
                       'volume': q.get('volume')}
            elif isinstance(item, (list, tuple)) and len(item) >= 6:
                # Official v5 compact rows place ISO time_open at index 6;
                # accept legacy six-column rows with timestamp at index 5.
                ts_value = item[6] if len(item) > 6 else item[5]
                if ts_value is None:
                    continue
                ts = int(pd.Timestamp(ts_value).timestamp() * 1000)
                row = {'t': ts, 'open': item[0], 'high': item[1], 'low': item[2],
                       'close': item[3], 'volume': item[4]}
            else:
                continue
            rows.append(row)
        except (IndexError, TypeError, ValueError, AttributeError, OverflowError):
            continue

    if not rows:
        raise RuntimeError('CoinMarketCap پاسخ داد، اما هیچ کندل OHLCV قابل‌خواندن نبود')
    return _clean_candles(rows).tail(limit)


def fetch_yahoo(symbol, tf, limit=2000):
    ysym = COMMODITIES_YAHOO.get(symbol, symbol)
    iv = {'5m': '5m', '15m': '15m', '30m': '30m', '1h': '60m', '4h': '1h', '1d': '1d'}[tf]
    rng = {'5m': '60d', '15m': '60d', '30m': '60d', '1h': '1y', '4h': '2y', '1d': '10y'}[tf]
    url = f'https://query1.finance.yahoo.com/v8/finance/chart/{requests.utils.quote(ysym, safe="=^-")}'
    params = {'interval': iv, 'range': rng, 'includePrePost': 'false'}
    errors = []
    payload = None
    for candidate in (url,):
        try:
            payload = _get(candidate, 15, params)
            result = payload.get('chart', {}).get('result')
            if result:
                break
            errors.append(str(payload.get('chart', {}).get('error') or 'بدون داده'))
        except Exception as exc:
            errors.append(str(exc))
    result = (payload or {}).get('chart', {}).get('result') or []
    if not result:
        raise RuntimeError('Yahoo Finance: ' + '; '.join(errors))
    item = result[0]
    ts = item.get('timestamp') or []
    quote = (item.get('indicators', {}).get('quote') or [{}])[0]
    rows = []
    for i, stamp in enumerate(ts):
        try:
            vals = [quote[k][i] for k in ('open', 'high', 'low', 'close')]
            if any(v is None for v in vals):
                continue
            volume_values = quote.get('volume')
            try:
                volume = volume_values[i] if volume_values is not None else None
            except (IndexError, TypeError):
                volume = None
            rows.append({'t': int(stamp) * 1000, 'open': vals[0], 'high': vals[1], 'low': vals[2], 'close': vals[3], 'volume': volume})
        except (IndexError, TypeError):
            continue
    frame = _clean_candles(rows)
    if tf == '4h':
        frame = _aggregate(frame, 4 * 3600, source_seconds=3600)
    return frame.tail(limit)



# Optional unofficial TradingView adapter. This is a community client, not an
# official TradingView API; provider availability and anonymous access vary.
try:
    from tvDatafeed import TvDatafeed, Interval as TvInterval
    HAS_TV = True
except Exception:
    TvDatafeed = None
    TvInterval = None
    HAS_TV = False

def fetch_tradingview(symbol, tf, limit=3000):
    if not HAS_TV:
        raise RuntimeError("کتابخانه اختیاری tvdatafeed نصب نیست؛ pip install tvdatafeed")
    intervals = {'5m': TvInterval.in_5_minute, '15m': TvInterval.in_15_minute, '30m': TvInterval.in_30_minute, '1h': TvInterval.in_1_hour,
                 '4h': TvInterval.in_4_hour, '1d': TvInterval.in_daily}
    sym = str(symbol).upper().strip()
    exchange, tv_symbol = 'BINANCE', sym
    if sym in COMMODITIES_YAHOO:
        exchange = 'OANDA'
        tv_symbol = {'XAUUSD':'XAUUSD', 'XAGUSD':'XAGUSD',
                     'WTI':'WTICOUSD', 'BRENT':'BCOUSD'}.get(sym, sym)
    client = TvDatafeed()
    frame = client.get_hist(symbol=tv_symbol, exchange=exchange,
                            interval=intervals[tf], n_bars=min(int(limit), 5000))
    if frame is None or frame.empty:
        raise RuntimeError(f'TradingView برای {tv_symbol} داده‌ای برنگرداند')
    frame = frame.reset_index()
    if 'datetime' not in frame.columns:
        raise RuntimeError('ساختار پاسخ TradingView نامعتبر است')
    frame['t'] = pd.to_datetime(frame['datetime'], utc=True).dt.as_unit('ms').astype('int64')
    return _clean_candles(frame.to_dict('records')).tail(limit)

def fetch_history_store(symbol, tf, limit=100000):
    from .historical import load_history
    frame = load_history(symbol, tf, limit)
    if frame.empty:
        raise RuntimeError('برای این نماد/تایم‌فریم تاریخچه محلی وجود ندارد؛ ابتدا Backfill را اجرا کن')
    return frame


def fetch_htx(symbol, tf, limit=3000):
    """HTX (Huobi) public klines. No key needed; an independent Asian fallback."""
    period = {'5m': '5min', '15m': '15min', '30m': '30min', '1h': '60min',
              '4h': '4hour', '1d': '1day'}[tf]
    step = TIMEFRAME_SECONDS[tf]
    sym = symbol.upper().replace('USDT', 'USDT').lower()
    rows, end_ts = [], int(time.time())
    for _ in range(math.ceil(limit / 1000)):
        data = _get('https://api.huobi.pro/market/history/kline', 12, {
            'symbol': sym, 'period': period, 'size': 1000, 'end': end_ts})
        if not isinstance(data, dict) or data.get('status') != 'ok':
            raise RuntimeError(f"HTX: {(data or {}).get('err-msg') or 'پاسخ نامعتبر'}")
        candles = data.get('data') or []
        if not candles:
            break
        # rows are newest first: {id(sec), open, high, low, close, amount}
        rows.extend({'t': int(x['id']) * 1000, 'open': x['open'], 'high': x['high'],
                     'low': x['low'], 'close': x['close'],
                     'volume': x.get('amount')} for x in candles)
        if len(candles) < 1000:
            break
        end_ts = int(candles[-1]['id']) - 1
    return _clean_candles(rows).tail(limit)


def fetch_bitfinex(symbol, tf, limit=3000):
    """Bitfinex public v2 candles; USD pairs are used as the near-equivalent."""
    period = {'5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h',
              '4h': '4h', '1d': '1D'}[tf]
    step = TIMEFRAME_SECONDS[tf]
    base = symbol.upper().replace('USDT', '').replace('USDC', '').replace('USD', '')
    pair = f't{base}USD'
    rows, end_ms = [], int(time.time() * 1000)
    for _ in range(math.ceil(limit / 1000)):
        data = _get(f'https://api-pub.bitfinex.com/v2/candles/trade:{period}:{pair}/hist',
                    12, {'limit': 1000, 'end': end_ms, 'sort': -1})
        if not isinstance(data, list) or not data:
            break
        # rows: [MTS, OPEN, CLOSE, HIGH, LOW, VOLUME], newest first
        rows.extend({'t': int(x[0]), 'open': x[1], 'close': x[2], 'high': x[3],
                     'low': x[4], 'volume': x[5]} for x in data if len(x) >= 6)
        if len(data) < 1000:
            break
        end_ms = int(data[-1][0]) - 1
    return _clean_candles(rows).tail(limit)


def fetch_cryptocompare(symbol, tf, limit=3000):
    """CryptoCompare public histodata. Aggregates minute bars for 5m/15m/30m."""
    base = symbol.upper().replace('USDT', '').replace('USDC', '').replace('USD', '')
    spec = {'5m': ('histominute', 5), '15m': ('histominute', 15),
            '30m': ('histominute', 30), '1h': ('histohour', 1),
            '4h': ('histohour', 4), '1d': ('histoday', 1)}[tf]
    endpoint, aggregate = spec
    headers = {}
    key = os.getenv('CRYPTOCOMPARE_API_KEY', '').strip()
    if key:
        headers['authorization'] = f'Apikey {key}'
    rows, to_ts = [], int(time.time())
    for _ in range(math.ceil(limit / 2000)):
        data = _get(f'https://min-api.cryptocompare.com/data/v2/{endpoint}', 15,
                    {'fsym': base, 'tsym': 'USDT', 'limit': 2000,
                     'aggregate': aggregate, 'toTs': to_ts}, headers=headers)
        if not isinstance(data, dict) or data.get('Response') != 'Success':
            msg = (data or {}).get('Message') if isinstance(data, dict) else None
            raise RuntimeError(f"CryptoCompare: {msg or 'پاسخ نامعتبر'}")
        inner = (data.get('Data') or {})
        candles = inner.get('Data') or []
        if not candles:
            break
        rows.extend({'t': int(x['time']) * 1000, 'open': x['open'], 'high': x['high'],
                     'low': x['low'], 'close': x['close'],
                     'volume': x.get('volumefrom')} for x in candles)
        if len(candles) < 2000:
            break
        to_ts = int(candles[0]['time']) - 1
    return _clean_candles(rows).tail(limit)


def fetch_bingx(symbol, tf, limit=3000):
    """BingX public spot klines; another independent fallback."""
    interval = {'5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h',
                '4h': '4h', '1d': '1d'}[tf]
    step = TIMEFRAME_SECONDS[tf]
    inst = symbol.upper().replace('USDT', '-USDT').replace('USDC', '-USDC')
    rows, end_ms = [], int(time.time() * 1000)
    for _ in range(math.ceil(limit / 1000)):
        data = _get('https://open-api.bingx.com/openApi/spot/v1/market/kline', 12, {
            'symbol': inst, 'interval': interval, 'limit': 1000, 'endTime': end_ms})
        if not isinstance(data, dict) or data.get('code') != 0:
            msg = (data or {}).get('msg') if isinstance(data, dict) else None
            raise RuntimeError(f"BingX: {msg or 'پاسخ نامعتبر'}")
        inner = data.get('data')
        # Live API returns data as a list of rows; tolerate the documented
        # {data:{s,list}} wrapper too.
        if isinstance(inner, dict):
            candles = inner.get('list') or []
        elif isinstance(inner, list):
            candles = inner
        else:
            candles = []
        if not candles:
            break
        for x in candles:
            if isinstance(x, dict):
                rows.append({'t': int(x['time']), 'open': x['open'], 'high': x['high'],
                             'low': x['low'], 'close': x['close'],
                             'volume': x.get('volume')})
            elif isinstance(x, (list, tuple)) and len(x) >= 6:
                # live rows: [ts, open, high, low, close, volume, close_time, quote_vol]
                rows.append({'t': int(x[0]), 'open': x[1], 'high': x[2], 'low': x[3],
                             'close': x[4], 'volume': x[5]})
        if len(candles) < 1000:
            break
        oldest = min(int(r['t']) for r in rows)
        end_ms = oldest - 1
    return _clean_candles(rows).tail(limit)


STOOQ_SYMBOLS = {
    'XAUUSD': 'xauusd', 'XAGUSD': 'xagusd', 'GOLD': 'xauusd', 'SILVER': 'xagusd',
    'WTI': 'cl.f', 'BRENT': 'cb.f',
}


def fetch_stooq(symbol, tf, limit=5000):
    """Stooq daily CSV — last-resort fallback for daily commodities/crypto.
    Only supports the 1d timeframe."""
    if tf != '1d':
        raise RuntimeError('Stooq فقط برای تایم‌فریم روزانه (1d) دارد')
    sym = STOOQ_SYMBOLS.get(symbol.upper())
    if not sym:
        base = symbol.upper().replace('USDT', '').replace('USDC', '')
        sym = f'{base.lower()}usd'
    url = f'https://stooq.com/q/d/l/?s={sym}&i=d'
    response = SESSION.get(url, timeout=(5, 20))
    response.raise_for_status()
    text = response.text.strip()
    if not text or text.lower().startswith('no data') or '<html' in text[:200].lower():
        raise RuntimeError('Stooq: داده‌ای برای این نماد نیست')
    rows = []
    for line in text.splitlines()[1:]:
        parts = line.split(',')
        if len(parts) < 6:
            continue
        try:
            ts = int(pd.Timestamp(parts[0]).timestamp() * 1000)
            vol = float(parts[5]) if parts[5] and parts[5] not in ('Volume', 'N/A') else 0.0
            rows.append({'t': ts, 'open': parts[1], 'high': parts[2], 'low': parts[3],
                         'close': parts[4], 'volume': vol})
        except (ValueError, OverflowError):
            continue
    return _clean_candles(rows).tail(limit)



# ======================= V21: USDT-margined perpetual futures =======================
# Internal id = <BASE>USDTPERP (e.g. BTCUSDTPERP). It passes the ordinary [A-Z0-9]
# symbol checks, file names and DB keys; every futures fetcher strips the suffix.
FUTURES_SUFFIX = 'PERP'


def is_futures_symbol(symbol: str) -> bool:
    s = str(symbol).upper().strip()
    return s.endswith('USDT' + FUTURES_SUFFIX) and len(s) > len('USDT' + FUTURES_SUFFIX)


def futures_base_symbol(symbol: str) -> str:
    """BTCUSDTPERP -> BTCUSDT (the exchange's own perpetual contract symbol)."""
    s = str(symbol).upper().strip()
    return s[:-len(FUTURES_SUFFIX)] if is_futures_symbol(s) else s


# Famous USDT-margined perpetuals (plain contract symbols that exist on all five feeds).
FUTURES_FAMOUS_BASES = ['BTC', 'ETH', 'SOL', 'BNB', 'XRP', 'DOGE', 'ADA', 'LINK', 'AVAX',
                        'TON', 'DOT', 'LTC', 'TRX', 'NEAR', 'SUI', 'INJ']
FUTURES_FAMOUS = [b + 'USDT' + FUTURES_SUFFIX for b in FUTURES_FAMOUS_BASES]


def futures_label(symbol: str) -> str:
    return f"{futures_base_symbol(symbol)} · فیوچرز دائمی"


def fetch_binance_fut(symbol, tf, limit=5000):
    sym, step = futures_base_symbol(symbol), TIMEFRAME_SECONDS[tf]
    rows, end_ms = [], int(time.time() * 1000)
    for _ in range(math.ceil(limit / 1500)):
        start_ms = end_ms - 1500 * step * 1000
        data = _get('https://fapi.binance.com/fapi/v1/klines', 12, {
            'symbol': sym, 'interval': tf, 'startTime': start_ms, 'endTime': end_ms, 'limit': 1500})
        if isinstance(data, dict):
            raise RuntimeError(f"Binance Futures: {data.get('msg', 'خطای API')}")
        if not isinstance(data, list) or not data:
            break
        rows.extend({'t': int(x[0]), 'open': x[1], 'high': x[2], 'low': x[3],
                     'close': x[4], 'volume': x[5]} for x in data)
        if len(data) < 1500:
            break
        end_ms = start_ms - 1
    return _clean_candles(rows).tail(limit)


def fetch_bybit_fut(symbol, tf, limit=5000):
    return fetch_bybit(futures_base_symbol(symbol), tf, limit, category='linear')


def fetch_okx_fut(symbol, tf, limit=3000):
    return fetch_okx(futures_base_symbol(symbol), tf, limit, swap=True)


def fetch_gateio_fut(symbol, tf, limit=5000):
    contract = futures_base_symbol(symbol).replace('USDT', '_USDT')
    step, rows, end_ts = TIMEFRAME_SECONDS[tf], [], int(time.time())
    for _ in range(math.ceil(limit / 1000)):
        start_ts = end_ts - 1000 * step
        data = _get('https://api.gateio.ws/api/v4/futures/usdt/candlesticks', 12, {
            'contract': contract, 'interval': tf, 'from': start_ts, 'to': end_ts})
        if isinstance(data, dict):
            raise RuntimeError(f"Gate Futures: {data.get('message', 'خطای API')}")
        if not isinstance(data, list) or not data:
            break
        # Gate futures: [{t (sec), v, c, h, l, o}, ...]
        rows.extend({'t': int(x['t']) * 1000, 'open': x['o'], 'high': x['h'], 'low': x['l'],
                     'close': x['c'], 'volume': x.get('v')} for x in data if isinstance(x, dict) and 't' in x)
        if len(data) < 1000:
            break
        end_ts = start_ts - 1
    return _clean_candles(rows).tail(limit)


def fetch_bitget_fut(symbol, tf, limit=5000):
    granularity = {'5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '4h': '4H', '1d': '1D'}[tf]
    step, rows, end_ms = TIMEFRAME_SECONDS[tf] * 1000, [], int(time.time() * 1000)
    for _ in range(math.ceil(limit / 200)):
        start_ms = end_ms - 200 * step
        data = _get('https://api.bitget.com/api/v2/mix/market/candles', 12, {
            'symbol': futures_base_symbol(symbol), 'productType': 'USDT-FUTURES',
            'granularity': granularity, 'startTime': start_ms, 'endTime': end_ms, 'limit': 200})
        if data.get('code') not in ('00000', None):
            raise RuntimeError(f"Bitget Futures: {data.get('msg', 'خطای API')}")
        candles = data.get('data') or []
        if not candles:
            break
        rows.extend({'t': int(x[0]), 'open': x[1], 'high': x[2], 'low': x[3],
                     'close': x[4], 'volume': x[5]} for x in candles)
        if len(candles) < 200:
            break
        end_ms = start_ms - 1
    return _clean_candles(rows).tail(limit)


# spot source id -> its futures twin (so a chosen "Binance" still works on a PERP symbol)
FUTURES_TWIN = {'binance': 'binance_fut', 'bybit': 'bybit_fut', 'okx': 'okx_fut',
                'gateio': 'gateio_fut', 'bitget': 'bitget_fut'}
FUTURES_AUTO_ORDER = ['binance_fut', 'bybit_fut', 'okx_fut', 'gateio_fut', 'bitget_fut']


SOURCE_FUNCS: dict[str, Callable] = {
    'binance': fetch_binance, 'bybit': fetch_bybit, 'mexc': fetch_mexc,
    'kucoin': fetch_kucoin, 'okx': fetch_okx, 'gateio': fetch_gateio,
    'coinbase': fetch_coinbase, 'nobitex': fetch_nobitex,
    'lbank': fetch_lbank, 'bit24': fetch_bit24,
    'kraken': fetch_kraken, 'bitget': fetch_bitget,
    'bingx': fetch_bingx, 'htx': fetch_htx, 'bitfinex': fetch_bitfinex,
    'cryptocompare': fetch_cryptocompare, 'stooq': fetch_stooq,
    'coinmarketcap': fetch_coinmarketcap, 'yahoo': fetch_yahoo,
    'tradingview': fetch_tradingview, 'history': fetch_history_store,
    'binance_fut': fetch_binance_fut, 'bybit_fut': fetch_bybit_fut, 'okx_fut': fetch_okx_fut,
    'gateio_fut': fetch_gateio_fut, 'bitget_fut': fetch_bitget_fut,
}
SOURCE_LABELS = {
    'auto': 'خودکار (همه منابع)', 'binance': 'Binance', 'bybit': 'Bybit',
    'mexc': 'MEXC', 'kucoin': 'KuCoin', 'okx': 'OKX', 'gateio': 'Gate.io',
    'coinbase': 'Coinbase', 'nobitex': 'Nobitex',
    'lbank': 'LBank', 'bit24': 'Bit24 (بیت ۲۴)',
    'kraken': 'Kraken', 'bitget': 'Bitget', 'bingx': 'BingX',
    'htx': 'HTX (Huobi)', 'bitfinex': 'Bitfinex',
    'cryptocompare': 'CryptoCompare', 'stooq': 'Stooq (فقط روزانه)',
    'coinmarketcap': 'CoinMarketCap (نیازمند API Key)', 'yahoo': 'Yahoo Finance',
    'history': 'آرشیو تاریخی محلی (SQLite)',
    'binance_fut': 'Binance Futures', 'bybit_fut': 'Bybit Futures (linear)', 'okx_fut': 'OKX Swap',
    'gateio_fut': 'Gate.io Futures', 'bitget_fut': 'Bitget Futures',
}
# TradingView is the preferred chart/history provider; exchanges are failover sources.
CRYPTO_AUTO_ORDER = ['tradingview', 'binance', 'bybit', 'okx', 'gateio', 'mexc', 'kucoin', 'coinbase',
                     'bitget', 'bingx', 'htx', 'bitfinex', 'kraken', 'cryptocompare',
                     'nobitex', 'bit24', 'lbank', 'stooq', 'coinmarketcap']


# ---- adaptive ordering: a source that just worked goes to the front ----
_SOURCE_SUCCESS_TS: dict[str, float] = {}


def _adaptive_sort(order: list[str]) -> list[str]:
    """Put the most recently successful sources first. `sorted` is stable, so
    never-successful sources keep their original (preference) order."""
    return sorted(order, key=lambda s: -_SOURCE_SUCCESS_TS.get(s, 0.0))


def _cache_dir() -> Path:
    path = Path.home() / '.trading_ai_models' / 'cache'
    path.mkdir(parents=True, exist_ok=True)
    return path


def _cache_path(symbol, tf):
    safe = ''.join(ch if ch.isalnum() or ch in '-_' else '_' for ch in symbol)
    return _cache_dir() / f'candles_{safe}_{tf}.csv'


def _save_cache(df, symbol, tf):
    try:
        df.tail(10000).to_csv(_cache_path(symbol, tf), index=False)
    except Exception:
        pass


def _load_cache(symbol, tf, limit):
    try:
        path = _cache_path(symbol, tf)
        if not path.exists():
            return None
        frame = _clean_candles(pd.read_csv(path).to_dict('records'))
        if len(frame) < 210:
            return None
        frame.attrs['cache_saved_at'] = datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()
        return frame.tail(limit).reset_index(drop=True)
    except Exception:
        return None


def fetch_candles(symbol: str, tf: str, limit: int = 3000,
                  source: str = 'auto', progress_cb=None,
                  validation_mode: str = 'research',
                  max_age_bars: int | None = None) -> pd.DataFrame:
    """Fetch OHLCV and enforce the V22 Data Contract at the provider boundary.

    Research mode permits WARN batches for display/inspection but never BLOCKED
    batches. Paper/live require PASS, a named non-cache source and freshness.
    """
    symbol = str(symbol).upper().strip()
    if tf not in TIMEFRAME_SECONDS:
        raise ValueError(f'تایم‌فریم نامعتبر است: {tf}')
    max_limit = 100000 if source == 'history' else 10000
    if not 210 <= int(limit) <= max_limit:
        raise ValueError(f'تعداد کندل باید بین ۲۱۰ تا {max_limit:,} باشد')
    if source not in ('auto', *SOURCE_FUNCS.keys()):
        raise ValueError(f'منبع داده ناشناخته است: {source}')
    if validation_mode not in ('research', 'paper', 'live'):
        raise ValueError('حالت اعتبارسنجی داده نامعتبر است')
    if validation_mode in ('paper', 'live') and (max_age_bars is None or int(max_age_bars) < 1):
        raise ValueError('برای Paper/Live باید max_age_bars صریح و مثبت باشد')

    def _contract_frame(frame, src_name):
        # Import locally to avoid data.py <-> data_contract.py import cycle.
        from .data_contract import validate_candles, DataContractError
        audit = dict(getattr(frame, 'attrs', {}).get('normalization_audit') or {})
        result = validate_candles(
            frame, symbol=symbol, timeframe=tf, source=src_name,
            mode=validation_mode, max_age_bars=(int(max_age_bars) if max_age_bars is not None else None),
        )
        report = dict(result.report)
        report['normalization_audit'] = audit
        aggregation_audit = dict(getattr(frame, 'attrs', {}).get('aggregation_audit') or {})
        if aggregation_audit:
            report['aggregation_audit'] = aggregation_audit
        # The provider normalizer can safely sort reverse-ordered exchange pages and
        # remove a small number of malformed/duplicate rows.  Treating every such
        # repair as fatal made otherwise healthy feeds unusable (several exchanges
        # return newest-first candles).  Keep the audit visible, but distinguish a
        # harmless chronological reorder from data loss.
        malformed_dropped = int(audit.get('malformed_rows_dropped', 0) or 0)
        duplicate_dropped = int(audit.get('duplicate_rows_dropped', 0) or 0)
        duplicate_conflicts = int(audit.get('duplicate_conflict_groups', 0) or 0)
        # Exact duplicate candles are harmless after deterministic de-duplication.
        # Conflicting rows at the same timestamp and malformed OHLC rows are not.
        hidden_bad = malformed_dropped + duplicate_conflicts
        raw_rows = int(audit.get('raw_rows', 0) or 0)
        denominator = max(raw_rows, len(frame) + hidden_bad, 1)
        dropped_ratio = hidden_bad / denominator
        report['normalization_summary'] = {
            'raw_rows': raw_rows or denominator,
            'malformed_rows_dropped': malformed_dropped,
            'duplicate_rows_dropped': duplicate_dropped,
            'duplicate_rows_seen': int(audit.get('duplicate_rows_seen', 0) or 0),
            'duplicate_conflict_groups': duplicate_conflicts,
            'dropped_ratio': round(dropped_ratio, 6),
            'reordered': bool(audit.get('out_of_order')),
        }
        report.setdefault('normalization_notes', [])
        report.setdefault('warnings', [])
        report.setdefault('block_reasons', [])

        # Provider pages are frequently newest-first. Sorting them chronologically
        # is safe because timestamps, candle geometry and gaps are rechecked below.
        if audit.get('out_of_order'):
            report['normalization_notes'].append(
                'provider rows were reordered chronologically before validation')
        if duplicate_dropped and not duplicate_conflicts:
            report['normalization_notes'].append(
                f'{duplicate_dropped} exact duplicate candle row(s) were removed')

        if hidden_bad:
            if validation_mode in ('paper', 'live'):
                # Never trade after malformed or conflicting source rows were removed.
                report['status'] = 'BLOCKED'
                report['block_reasons'].append(
                    f'normalizer_removed_ambiguous_rows:{hidden_bad}')
            elif dropped_ratio > 0.05:
                # Research can tolerate minor cleanup, not a materially damaged batch.
                report['status'] = 'BLOCKED'
                report['block_reasons'].append(
                    f'normalizer_removed_too_many_rows:{hidden_bad}/{denominator}')
            else:
                report['warnings'].append(
                    f'normalizer_cleaned_rows:{hidden_bad} (malformed={malformed_dropped}, conflicting_duplicate_groups={duplicate_conflicts})')
                if report['status'] == 'PASS':
                    report['status'] = 'WARN'

        if audit.get('missing_volume_rows'):
            missing_volume_rows = int(audit['missing_volume_rows'])
            report['volume_available'] = False
            report['missing_volume_count'] = max(
                int(report.get('missing_volume_count', 0)), missing_volume_rows)
            report['warnings'].append(
                f'normalizer_missing_volume_rows:{missing_volume_rows}; volume-based features are unavailable')
            if validation_mode in ('paper', 'live'):
                report['status'] = 'BLOCKED'
                report['block_reasons'].append('volume_data_missing_for_trading')
            elif report['status'] == 'PASS':
                report['status'] = 'WARN'

        # De-duplicate report messages while preserving their order.
        report['warnings'] = list(dict.fromkeys(report['warnings']))
        report['block_reasons'] = list(dict.fromkeys(report['block_reasons']))
        report['normalization_notes'] = list(dict.fromkeys(report['normalization_notes']))
        if report['status'] == 'BLOCKED' or (validation_mode in ('paper', 'live') and report['status'] != 'PASS'):
            raise DataContractError('Data Contract rejected provider batch: ' + '; '.join(report.get('block_reasons', []) + report.get('warnings', [])))
        out = result.candles.copy()
        out.attrs.update(getattr(frame, 'attrs', {}))
        out.attrs['source'] = src_name
        out.attrs['data_contract'] = report
        return out

    if symbol in COMMODITIES_YAHOO:
        if source == 'history':
            order = ['history']
        else:
            order = ['tradingview', 'yahoo', 'stooq', 'history'] if source == 'auto' \
                else ([source] if source in ('tradingview', 'yahoo', 'stooq', 'history') else [])
        if source not in ('auto', 'tradingview', 'yahoo', 'stooq', 'history'):
            raise ValueError('برای طلا، نقره و نفت از TradingView، Yahoo Finance، Stooq یا آرشیو تاریخی استفاده کن')
    elif is_futures_symbol(symbol):
        # V21: perpetual futures use their own chain; a spot source id maps to its futures twin.
        if source == 'auto':
            order = FUTURES_AUTO_ORDER.copy()
        elif source in FUTURES_TWIN:
            order = [FUTURES_TWIN[source]]
        elif source in FUTURES_AUTO_ORDER or source == 'history':
            order = [source]
        else:
            raise ValueError('برای فیوچرز از خودکار یا Binance/Bybit/OKX/Gate.io/Bitget استفاده کن')
    elif source == 'auto':
        order = CRYPTO_AUTO_ORDER.copy()
    else:
        order = [source]

    errors = []
    tried_chain = []            # V20: report the fallback chain to the UI
    if source == 'auto' and len(order) > 1:
        live = [x for x in order if not _cooling(x)]
        if live:
            skipped = [x for x in order if x not in live]
            for x in skipped:
                errors.append(f'{SOURCE_LABELS.get(x, x)}: رد شد (اخیراً جواب نداد)')
            order = live
        else:
            reset_source_health()      # everything was down: give all one fresh try
        # Keep TradingView as the strict first choice; adapt only the fallback order.
        if order and order[0] == 'tradingview':
            order = ['tradingview'] + _adaptive_sort(order[1:])
        else:
            order = _adaptive_sort(order)
    # CoinMarketCap needs a key: never waste a request without one
    if 'coinmarketcap' in order and not os.getenv('CMC_API_KEY', '').strip():
        order = [x for x in order if x != 'coinmarketcap']
    # CryptoCompare needs a key (free tier is 401 without one): skip like CMC
    if 'cryptocompare' in order and not os.getenv('CRYPTOCOMPARE_API_KEY', '').strip():
        order = [x for x in order if x != 'cryptocompare']
    # Stooq is daily-only: skip it for intraday timeframes instead of failing.
    if 'stooq' in order and tf != '1d':
        order = [x for x in order if x != 'stooq']
    for src in order:
        try:
            if progress_cb:
                progress_cb(f'در حال دریافت از {SOURCE_LABELS.get(src, src)}...')
            frame = SOURCE_FUNCS[src](symbol, tf, int(limit))
            source_attrs = dict(getattr(frame, 'attrs', {}) or {})
            source_audit = dict(source_attrs.get('normalization_audit') or {})
            source_aggregation_audit = dict(source_attrs.get('aggregation_audit') or {})
            frame = _drop_unclosed(_clean_candles(frame.to_dict('records')), tf)
            # Preserve provider-side audits: a second normalization pass must not
            # erase anomalies found before timeframe aggregation.
            if source_audit:
                frame.attrs['normalization_audit'] = source_audit
            if source_aggregation_audit:
                frame.attrs['aggregation_audit'] = source_aggregation_audit
            if len(frame) < 210:
                raise RuntimeError(f'فقط {len(frame)} کندل معتبر دریافت شد؛ حداقل ۲۱۰ لازم است')
            frame = frame.tail(limit).reset_index(drop=True)
            frame.attrs['normalization_audit'] = source_audit or frame.attrs.get('normalization_audit', {})
            frame = _contract_frame(frame, src)
            frame.attrs['source'] = src
            frame.attrs['source_label'] = SOURCE_LABELS.get(src, src)
            frame.attrs['fallback_chain'] = tried_chain
            _SOURCE_SUCCESS_TS[src] = time.time()
            _save_cache(frame, symbol, tf)
            if progress_cb:
                progress_cb(f'✓ {SOURCE_LABELS.get(src, src)}: {len(frame)} کندل معتبر')
            return frame
        except Exception as exc:
            message = f'{SOURCE_LABELS.get(src, src)}: {exc}'
            errors.append(message)
            tried_chain.append({'source': src, 'label': SOURCE_LABELS.get(src, src),
                                'error': str(exc)[:140]})
            if source == 'auto':
                _mark_failed(src, exc)
            if progress_cb:
                progress_cb(f'✖ {message}')

    cached = _load_cache(symbol, tf, int(limit))
    if cached is not None:
        cached.attrs['source'] = 'cache'
        cached.attrs['source_label'] = 'کش محلی (ممکن است قدیمی باشد)'
        cached.attrs['fallback_chain'] = tried_chain
        cached = _contract_frame(cached, 'cache')
        if progress_cb:
            age = cached.attrs.get('cache_saved_at', 'نامشخص')
            progress_cb(f'⚠ منابع آنلاین ناموفق؛ استفاده از کش محلی، زمان ذخیره: {age}')
        return cached
    raise RuntimeError('هیچ منبعی داده معتبر نداد و کش کافی هم وجود ندارد.\n' + '\n'.join(errors))


def source_catalog():
    key_sources = {'coinmarketcap': 'CMC_API_KEY', 'cryptocompare': 'CRYPTOCOMPARE_API_KEY'}
    return [{'id': key, 'label': label,
             'requires_key': key in key_sources,
             'configured': bool(os.getenv(key_sources.get(key, ''), '').strip()) if key in key_sources else True}
            for key, label in SOURCE_LABELS.items()]


def to_display(df: pd.DataFrame) -> list:
    if df.empty:
        return []
    normalized = _clean_candles(df.to_dict('records'))
    return [{'t': int(r.t), 'o': float(r.open), 'h': float(r.high),
             'l': float(r.low), 'c': float(r.close), 'v': float(r.volume)}
            for r in normalized.itertuples(index=False)]
