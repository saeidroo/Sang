"""Chronological strategy drift diagnostics over reconciled closed paper trades."""
from __future__ import annotations
from collections import defaultdict
import math

from backend.strategy_validation import _context, _metrics


def detect_strategy_drift(events, *, min_baseline=10, min_recent=5,
                          recent_fraction=0.30, win_rate_drop_pp=15.0,
                          expectancy_drop_pct=50.0):
    """Compare an older baseline with the latest cohort segment, without shuffling.

    This is a retrospective warning, not a forecast or entry authorization.
    Contexts are kept exact so regime/timeframe changes are not conflated.
    """
    min_baseline = max(2, min(2000, int(min_baseline)))
    min_recent = max(2, min(1000, int(min_recent)))
    recent_fraction = float(recent_fraction)
    win_rate_drop_pp = float(win_rate_drop_pp)
    expectancy_drop_pct = float(expectancy_drop_pct)
    if not math.isfinite(recent_fraction) or not 0.10 <= recent_fraction <= 0.50:
        raise ValueError('recent_fraction must be between 0.10 and 0.50')
    if not math.isfinite(win_rate_drop_pp) or not 0 <= win_rate_drop_pp <= 100:
        raise ValueError('win_rate_drop_pp must be between 0 and 100')
    if not math.isfinite(expectancy_drop_pct) or not 0 <= expectancy_drop_pct <= 1000:
        raise ValueError('expectancy_drop_pct must be between 0 and 1000')

    groups = defaultdict(list)
    for row in events or []:
        try:
            pnl = float(row.get('net_pnl'))
            closed_at = str(row.get('closed_at') or '').strip()
            if not math.isfinite(pnl) or not closed_at:
                continue
            groups[_context(row)].append((closed_at, str(row.get('trade_id') or ''), pnl))
        except (TypeError, ValueError):
            continue

    reports = []
    for key, values in groups.items():
        values.sort(key=lambda x: (x[0], x[1]))
        n = len(values)
        recent_n = max(min_recent, int(math.ceil(n * recent_fraction)))
        recent_n = min(recent_n, n)
        split = n - recent_n
        enough = split >= min_baseline and recent_n >= min_recent
        if enough:
            baseline_rows = [{'net_pnl': x[2]} for x in values[:split]]
            recent_rows = [{'net_pnl': x[2]} for x in values[split:]]
            baseline = _metrics(baseline_rows)
            recent = _metrics(recent_rows)
            win_drop = round(baseline['win_rate_pct'] - recent['win_rate_pct'], 2)
            exp_drop = None
            if baseline['expectancy_usdt'] > 0:
                exp_drop = round((baseline['expectancy_usdt'] - recent['expectancy_usdt']) /
                                 abs(baseline['expectancy_usdt']) * 100, 2)
            pf_base, pf_recent = baseline['profit_factor'], recent['profit_factor']
            pf_deteriorated = (pf_base is not None and pf_recent is not None and
                               pf_recent < pf_base * 0.60)
            win_deteriorated = win_drop >= win_rate_drop_pp
            expectancy_deteriorated = (exp_drop is not None and
                                       exp_drop >= expectancy_drop_pct)
            recent_negative = recent['expectancy_usdt'] <= 0
            signals = [win_deteriorated, expectancy_deteriorated, pf_deteriorated, recent_negative]
            if recent_negative and sum(signals) >= 2:
                state = 'SEVERE_DRIFT'
            elif sum(signals) >= 2:
                state = 'DRIFT_DETECTED'
            elif sum(signals) == 1:
                state = 'WATCH'
            else:
                state = 'NO_CLEAR_DRIFT'
            report = {
                'strategy': key[0], 'symbol': key[1], 'market': key[2],
                'timeframe': key[3], 'side': key[4], 'market_regime': key[5],
                'volatility_regime': key[6], 'closed_trades': n,
                'baseline': baseline, 'recent': recent,
                'baseline_end': values[split - 1][0], 'recent_start': values[split][0],
                'recent_end': values[-1][0], 'win_rate_drop_pp': win_drop,
                'expectancy_drop_pct': exp_drop,
                'indicators': {'win_rate_deteriorated': win_deteriorated,
                               'expectancy_deteriorated': expectancy_deteriorated,
                               'profit_factor_deteriorated': pf_deteriorated,
                               'recent_expectancy_non_positive': recent_negative},
                'state': state, 'chronological_comparison': True,
                'exact_context_only': True, 'future_data_used_for_past': False,
            }
        else:
            report = {
                'strategy': key[0], 'symbol': key[1], 'market': key[2],
                'timeframe': key[3], 'side': key[4], 'market_regime': key[5],
                'volatility_regime': key[6], 'closed_trades': n,
                'baseline': None, 'recent': None, 'baseline_end': None,
                'recent_start': None, 'recent_end': values[-1][0],
                'win_rate_drop_pp': None, 'expectancy_drop_pct': None,
                'indicators': {}, 'state': 'INSUFFICIENT_DATA',
                'chronological_comparison': True, 'exact_context_only': True,
                'future_data_used_for_past': False,
            }
        reports.append(report)

    order = {'SEVERE_DRIFT': 0, 'DRIFT_DETECTED': 1, 'WATCH': 2,
             'NO_CLEAR_DRIFT': 3, 'INSUFFICIENT_DATA': 4}
    reports.sort(key=lambda x: (order[x['state']], x['strategy'], x['symbol']))
    return {
        'cohorts': reports, 'cohort_count': len(reports),
        'min_baseline': min_baseline, 'min_recent': min_recent,
        'recent_fraction': recent_fraction,
        'thresholds': {'win_rate_drop_pp': win_rate_drop_pp,
                       'expectancy_drop_pct': expectancy_drop_pct,
                       'profit_factor_recent_to_baseline_ratio': 0.60},
        'comparison_method': 'EARLIER_BASELINE_VS_MOST_RECENT_CHRONOLOGICAL_BLOCK',
        'source': 'RECONCILED_CLOSED_PAPER_TRADES_ONLY',
        'interpretation': 'Historical warning only; drift flags are not forecasts or proof of future loss.',
        'paper_only': True, 'authorizes_entries': False,
        'real_orders_enabled': False, 'future_data_used_for_past': False,
    }
