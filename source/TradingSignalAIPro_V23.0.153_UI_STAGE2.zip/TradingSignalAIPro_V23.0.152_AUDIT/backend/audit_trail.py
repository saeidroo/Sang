"""Tamper-evident hash-chain helpers for V22 audit streams."""
from __future__ import annotations
import hashlib, json

GENESIS = "0" * 64

def canonical_hash(value):
    raw=json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=False,default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

def seal_event(event, previous_hash=GENESIS):
    body=dict(event)
    body.pop("event_hash",None)
    body["previous_hash"]=previous_hash
    body["event_hash"]=canonical_hash(body)
    return body

def verify_events(events, *, allow_legacy=True):
    previous=GENESIS; checked=0; legacy=0; errors=[]
    for index,event in enumerate(events):
        if not event.get("event_hash"):
            legacy+=1
            if not allow_legacy: errors.append(f"legacy_unsealed_event:{index}")
            continue
        claimed=event.get("event_hash")
        body=dict(event); body.pop("event_hash",None)
        if body.get("previous_hash") != previous:
            errors.append(f"chain_break:{index}")
        actual=canonical_hash(body)
        if claimed != actual:
            errors.append(f"event_hash_mismatch:{index}")
        previous=claimed; checked+=1
    return {"valid":not errors,"checked_events":checked,"legacy_unsealed_events":legacy,"errors":errors,"head_hash":previous}
