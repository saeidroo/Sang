"""V23.0.72 conservative risk gate for newly listed spot assets (read-only)."""
from __future__ import annotations
import math
from typing import Any

DEFAULTS = {
    'min_quote_volume_usdt': 250_000.0,
    'min_trades_24h': 250,
    'max_abs_change_pct': 35.0,
    'max_spread_bps': 80.0,
    'max_atr_pct': 18.0,
    'min_listing_age_hours': 6.0,
}


def _num(row: dict, key: str):
    value = row.get(key)
    if value is None or isinstance(value, bool):
        return None
    try:
        n = float(value)
        return n if math.isfinite(n) else None
    except (TypeError, ValueError, OverflowError):
        return None


def evaluate_new_listing_risk(candidates: list[dict], settings: dict | None = None) -> dict:
    if not isinstance(candidates, list):
        raise ValueError('candidates must be a list')
    cfg = dict(DEFAULTS)
    if settings is not None:
        if not isinstance(settings, dict):
            raise ValueError('settings must be an object')
        for key, value in settings.items():
            if key not in cfg:
                raise ValueError(f'unknown setting: {key}')
            try: value = float(value)
            except (TypeError, ValueError): raise ValueError(f'invalid setting: {key}')
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f'invalid setting: {key}')
            cfg[key] = value
    results = []
    for raw in candidates[:200]:
        if not isinstance(raw, dict):
            results.append({'decision':'REJECT','reasons':['INVALID_CANDIDATE'],'entry_ready':False})
            continue
        row = dict(raw); reasons=[]; warnings=[]
        symbol = str(row.get('symbol') or '').upper().strip()
        exchange = str(row.get('exchange') or '').strip()
        if not symbol.endswith('USDT') or not exchange:
            reasons.append('PAIR_OR_EXCHANGE_IDENTITY_MISSING')
        age = _num(row, 'age_hours')
        if age is None: age = (_num(row, 'age_days') * 24 if _num(row,'age_days') is not None else None)
        volume = _num(row, 'quote_volume')
        trades = _num(row, 'trades')
        change = _num(row, 'change_pct')
        spread = _num(row, 'spread_bps')
        atr = _num(row, 'atr_pct')
        if age is None or age < 0: reasons.append('LISTING_AGE_UNKNOWN_OR_INVALID')
        elif age < cfg['min_listing_age_hours']: reasons.append('TOO_EARLY_AFTER_LISTING')
        if volume is None or volume < cfg['min_quote_volume_usdt']: reasons.append('INSUFFICIENT_QUOTE_VOLUME')
        if trades is None or trades < cfg['min_trades_24h']: reasons.append('INSUFFICIENT_TRADE_COUNT')
        if change is None: reasons.append('PRICE_CHANGE_EVIDENCE_MISSING')
        elif abs(change) > cfg['max_abs_change_pct']: reasons.append('EXTREME_24H_MOVE_PUMP_DUMP_RISK')
        if spread is None: warnings.append('SPREAD_NOT_VERIFIED')
        elif spread > cfg['max_spread_bps']: reasons.append('SPREAD_TOO_WIDE')
        if atr is None: warnings.append('ATR_NOT_VERIFIED')
        elif atr > cfg['max_atr_pct']: reasons.append('EXTREME_VOLATILITY')
        if row.get('contract_verified') is not True:
            warnings.append('TOKEN_CONTRACT_IDENTITY_UNVERIFIED')
        if row.get('source_reconciled') is not True:
            warnings.append('CROSS_SOURCE_NOT_RECONCILED')
        if abs(change or 0) >= cfg['max_abs_change_pct'] * .75:
            warnings.append('ELEVATED_PUMP_DUMP_ALERT')
        decision = 'REJECT' if reasons else 'WATCH_ONLY'
        results.append({'symbol':symbol,'exchange':exchange,'decision':decision,
            'reasons':reasons,'warnings':warnings,'entry_ready':False,
            'risk':'VERY_HIGH' if reasons or warnings else 'HIGH',
            'metrics':{'age_hours':age,'quote_volume_usdt':volume,'trades_24h':trades,
                       'change_pct':change,'spread_bps':spread,'atr_pct':atr}})
    return {'version':'23.0.72','count':len(results),'results':results,
            'entry_authorized':False,'execution_authorized':False,'creates_orders':False,
            'real_orders_enabled':False,'capital_usdt':1000,
            'disclaimer':'غربالگری محافظه‌کارانه و read-only است؛ WATCH_ONLY مجوز ورود نیست و هیچ سفارش یا معامله‌ای ایجاد نمی‌شود.'}
