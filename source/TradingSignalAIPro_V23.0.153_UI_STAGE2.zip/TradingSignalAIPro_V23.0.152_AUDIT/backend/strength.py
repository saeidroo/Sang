"""Signal strength profiles (V17.2) — user-selectable decisiveness.

The V17 pipeline is deliberately conservative: many confirmed-edge signals
never reach the user because the central brain requires strong consensus on
top of the OOS-verified model. This module makes that trade-off explicit and
controllable instead of hard-coded:

- ``conservative`` — the historical V17.1 behaviour (strictest).
- ``balanced``     — default: a small, bounded relaxation; more confirmed
                     signals pass, safety gates stay on.
- ``assertive``    — for experienced users: lowest consensus thresholds and a
                     displayed-power boost. Still refuses to fabricate evidence:
                     the out-of-sample edge gate, news block and meta-labeler
                     are never bypassed in any profile.

Every threshold is bounded; unknown profile names fall back to ``balanced``.
"""
from __future__ import annotations

import os

PROFILES = {
    'conservative': {
        'label_fa': 'محافظه‌کارانه',
        'entry_net_score': 2.0,          # compute_signal: |bull-bear| needed for BUY/SELL
        'conflict_power_guard': 0.50,    # compute_signal: HOLD when model/trend conflict & power below
        'brain_direction_score': 0.20,   # brain: |score| needed for BUY/SELL direction
        'brain_min_score': 0.22,         # brain: min consensus to keep base BUY/SELL
        'brain_min_support': 2,          # brain: min directional independent sources
        'brain_min_coverage': 0.48,      # brain: min available weight coverage
        'high_vol_min_score': 0.32,      # brain: extra-consensus in high volatility
        'threshold_floor': True,         # use max(user threshold, OOF threshold)
        'power_boost': 0.00,             # displayed power bonus after brain confirmation
    },
    'balanced': {
        'label_fa': 'متعادل (پیشنهادی)',
        'entry_net_score': 1.9,
        'conflict_power_guard': 0.42,
        'brain_direction_score': 0.17,
        'brain_min_score': 0.19,
        'brain_min_support': 2,
        'brain_min_coverage': 0.40,
        'high_vol_min_score': 0.27,
        'threshold_floor': True,
        'power_boost': 0.05,
    },
    'assertive': {
        'label_fa': 'جسورانه',
        'entry_net_score': 1.7,
        'conflict_power_guard': 0.34,
        'brain_direction_score': 0.14,
        'brain_min_score': 0.16,
        'brain_min_support': 1,
        'brain_min_coverage': 0.32,
        'high_vol_min_score': 0.22,
        'threshold_floor': False,        # trust the OOF-selected threshold itself
        'power_boost': 0.10,
    },
}

DEFAULT_PROFILE = (os.getenv('TS_AI_SIGNAL_STRENGTH', 'balanced').strip().lower() or 'balanced')
if DEFAULT_PROFILE not in PROFILES:
    DEFAULT_PROFILE = 'balanced'


def normalize_strength(value, default: str | None = None) -> str:
    """Validate a user-supplied strength; raise ValueError with a Persian message."""
    name = str(value if value is not None else (default or DEFAULT_PROFILE)).strip().lower()
    aliases = {'conservative': 'conservative', 'محافظه_کارانه': 'conservative',
               'balanced': 'balanced', 'متعادل': 'balanced',
               'assertive': 'assertive', 'جسورانه': 'assertive',
               'aggressive': 'assertive'}
    name = aliases.get(name, name)
    if name not in PROFILES:
        raise ValueError('قدرت سیگنال نامعتبر است؛ گزینه‌های مجاز: conservative / balanced / assertive')
    return name


def get_profile(name=None) -> dict:
    return PROFILES[normalize_strength(name)]


def profile_label(name) -> str:
    return PROFILES[normalize_strength(name)]['label_fa']
