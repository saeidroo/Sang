"""V23.0.71 conservative pre-entry quality gate. Advisory only; no market IO/orders."""
from __future__ import annotations
import math


def evaluate_entry_quality(candidates, settings=None):
    if not isinstance(candidates, list):
        raise ValueError('candidates باید فهرست باشد')
    cfg = settings or {}
    if not isinstance(cfg, dict):
        raise ValueError('settings نامعتبر است')
    max_quote_age = float(cfg.get('max_quote_age_seconds', 15))
    max_spread_bps = float(cfg.get('max_spread_bps', 20))
    min_volume_ratio = float(cfg.get('min_volume_ratio', 0.8))
    min_liquidity_usdt = float(cfg.get('min_liquidity_usdt', 10000))
    max_late_entry_atr = float(cfg.get('max_late_entry_atr', 1.5))
    min_score = float(cfg.get('min_quality_score', 60))
    limits = (max_quote_age, max_spread_bps, min_volume_ratio, min_liquidity_usdt, max_late_entry_atr, min_score)
    if any(not math.isfinite(x) or x < 0 for x in limits) or min_score > 100:
        raise ValueError('تنظیمات آستانه نامعتبر است')

    results, seen = [], set()
    for idx, row in enumerate(candidates):
        reasons = []
        if not isinstance(row, dict):
            results.append({'index': idx, 'decision': 'REJECT', 'reasons': ['INVALID_RECORD']}); continue
        symbol = str(row.get('symbol') or '').upper().replace('/', '').strip()
        market = str(row.get('market') or 'perp').lower()
        timeframe = str(row.get('timeframe') or '').strip()
        key = (symbol, market, timeframe)
        if not symbol.endswith('USDT') or market not in {'spot', 'perp'} or not timeframe:
            reasons.append('INVALID_MARKET_IDENTITY')
        if key in seen: reasons.append('DUPLICATE_OR_REPEATED_SIGNAL')
        seen.add(key)
        def number(field):
            try:
                value = float(row[field])
                return value if math.isfinite(value) else None
            except (KeyError, TypeError, ValueError, OverflowError): return None
        age = number('quote_age_seconds')
        spread = number('spread_bps')
        volume = number('volume_ratio')
        liquidity = number('liquidity_usdt')
        late = number('entry_distance_atr')
        score = number('opportunity_quality_index')
        if row.get('quote_fresh') is False or age is None or age > max_quote_age: reasons.append('STALE_OR_MISSING_QUOTE')
        if spread is None or spread < 0 or spread > max_spread_bps: reasons.append('SPREAD_UNSAFE_OR_MISSING')
        if volume is None or volume < min_volume_ratio: reasons.append('VOLUME_TOO_WEAK_OR_MISSING')
        if liquidity is None or liquidity < min_liquidity_usdt: reasons.append('LIQUIDITY_TOO_LOW_OR_MISSING')
        if late is None or late > max_late_entry_atr: reasons.append('LATE_ENTRY_OR_MISSING_DISTANCE')
        if score is None or not 0 <= score <= 100 or score < min_score: reasons.append('QUALITY_SCORE_BELOW_THRESHOLD')
        if row.get('timeframe_conflict') is True: reasons.append('TIMEFRAME_CONFLICT')
        if row.get('expired') is True: reasons.append('SIGNAL_EXPIRED')
        if row.get('blockers'): reasons.append('UPSTREAM_BLOCKER_PRESENT')
        reasons = list(dict.fromkeys(reasons))
        results.append({'index': idx, 'symbol': symbol or None, 'market': market,
            'timeframe': timeframe or None, 'decision': 'REVIEW_PASS' if not reasons else 'REJECT',
            'reasons': reasons, 'quality_score': score, 'entry_authorized': False})
    return {'version': '23.0.71', 'results': results,
        'summary': {'received': len(candidates), 'review_pass': sum(x['decision']=='REVIEW_PASS' for x in results),
                    'rejected': sum(x['decision']=='REJECT' for x in results)},
        'read_only': True, 'paper_only': True, 'recommendations_only': True,
        'entry_authorized': False, 'creates_orders': False,
        'execution_authorized': False, 'real_orders_enabled': False, 'capital_usdt': 1000.0,
        'policy': 'Quality gate only; passing means eligible for further human/strategy review, never permission to enter.'}
