"""
ML model ensemble - combines XGBoost, LightGBM, RandomForest, ExtraTrees,
HistGB and Neural Network with soft-voting + stacking meta-model.

Accuracy upgrades in this version:
  - Seed-ensemble: XGBoost/LightGBM trained with multiple seeds and averaged
    (reduces variance, stabilizes probabilities).
  - Recency weighting: recent candles get exponentially higher sample weight
    (market non-stationarity).
  - Probability calibration: sigmoid/Platt fit on an early OOF block and
    accepted only when a later chronological validation block improves Brier.
    Calibration is then applied to the weighted log-odds inference path.
"""
import os
import numpy as np
import pandas as pd
import joblib
import json
import copy
from pathlib import Path

# CPU-aware parallelism: on multi-core home PCs this cuts training time a lot.
CPU_COUNT = os.cpu_count() or 2
# Respect low-memory machines. Defaults are conservative; users can raise these
# with TS_AI_MODEL_THREADS after confirming available RAM.
try:
    _MODEL_THREADS = max(1, int(os.getenv('TS_AI_MODEL_THREADS', '1')))
except (TypeError, ValueError):
    _MODEL_THREADS = 1
JOBS_FULL = max(1, min(CPU_COUNT, 8, _MODEL_THREADS))
JOBS_LIGHT = max(1, min(2, CPU_COUNT // 2, _MODEL_THREADS))
from sklearn.ensemble import (RandomForestClassifier, GradientBoostingClassifier,
                              ExtraTreesClassifier, HistGradientBoostingClassifier)
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, balanced_accuracy_score
from sklearn.utils.class_weight import compute_sample_weight
from sklearn.linear_model import LogisticRegression

try:
    from xgboost import XGBClassifier
    HAS_XGB = True
except Exception:
    HAS_XGB = False

try:
    from lightgbm import LGBMClassifier
    HAS_LGB = True
except Exception:
    HAS_LGB = False


def _safe_clf_dict():
    """Map model name -> whether it's available."""
    return {
        'xgboost': HAS_XGB,
        'lightgbm': HAS_LGB,
        'random_forest': True,
        'gradient_boosting': True,
        'neural_net': True,
    }


class TradingEnsemble:
    """
    Ensemble of multiple classifiers with soft-voting + stacking meta-model.
    Supports warm-start: pass existing model's estimators to continue training
    instead of starting from scratch.
    """

    def __init__(self, feature_names=None):
        self.feature_names = feature_names or []
        self.models = {}          # name -> fitted estimator
        self.weights = {}         # name -> float (based on val accuracy)
        self.scaler = StandardScaler()
        self.meta_model = None    # GradientBoosting stacking on top
        self.calibrator = None    # IsotonicRegression probability calibrator
        self.n_seeds = 1          # seeds used for XGBoost/LightGBM
        self.meta_labeler = None
        self.meta_threshold = 0.55
        self.is_fitted = False
        self.train_acc = 0.0
        self.val_acc = 0.0
        self.walk_forward_acc = 0.0
        self.balanced_acc = 0.0
        self.high_conf_acc = 0.0
        self.high_conf_cov = 0.0
        self.history = []         # training log
        self.warm_started = False
        self.training_round = 1   # how many times trained (incremental)

    def _log(self, msg):
        self.history.append(msg)

    def _build_base_models(self, params=None, seed=42, jobs=None):
        """Build base estimators. params is dict of dicts.
        jobs: n_jobs for the tree models (None -> JOBS_FULL)."""
        params = params or {}
        if jobs is None:
            jobs = JOBS_FULL
        models = {}

        if HAS_XGB:
            p = params.get('xgboost', {})
            models['xgboost'] = XGBClassifier(
                n_estimators=p.get('n_estimators', 200),
                max_depth=p.get('max_depth', 3),
                learning_rate=p.get('learning_rate', 0.05),
                subsample=p.get('subsample', 0.8),
                colsample_bytree=p.get('colsample_bytree', 0.8),
                min_child_weight=p.get('min_child_weight', 5),
                reg_alpha=p.get('reg_alpha', 0.3),
                reg_lambda=p.get('reg_lambda', 2.0),
                gamma=p.get('gamma', 0.5),
                objective='binary:logistic',
                eval_metric='logloss',
                tree_method='hist',
                early_stopping_rounds=20,
                n_jobs=jobs,
                random_state=seed,
                verbosity=0,
            )

        if HAS_LGB:
            p = params.get('lightgbm', {})
            models['lightgbm'] = LGBMClassifier(
                n_estimators=p.get('n_estimators', 200),
                max_depth=p.get('max_depth', 4),
                learning_rate=p.get('learning_rate', 0.05),
                num_leaves=p.get('num_leaves', 15),
                subsample=p.get('subsample', 0.8),
                colsample_bytree=p.get('colsample_bytree', 0.8),
                min_child_samples=p.get('min_child_samples', 30),
                reg_alpha=p.get('reg_alpha', 0.3),
                reg_lambda=p.get('reg_lambda', 2.0),
                min_split_gain=p.get('min_split_gain', 0.1),
                n_jobs=jobs,
                random_state=seed,
                verbose=-1,
            )

        p = params.get('random_forest', {})
        models['random_forest'] = RandomForestClassifier(
            n_estimators=p.get('n_estimators', 200),
            max_depth=p.get('max_depth', 6),
            min_samples_leaf=p.get('min_samples_leaf', 10),
            min_samples_split=p.get('min_samples_split', 20),
            max_features=p.get('max_features', 'sqrt'),
            bootstrap=True,
            n_jobs=jobs,
            random_state=seed,
        )

        # ExtraTrees: more decorrelated than RandomForest -> diversity boost
        p = params.get('extra_trees', {})
        models['extra_trees'] = ExtraTreesClassifier(
            n_estimators=p.get('n_estimators', 180),
            max_depth=p.get('max_depth', 6),
            min_samples_leaf=p.get('min_samples_leaf', 10),
            max_features=p.get('max_features', 'sqrt'),
            bootstrap=False,
            n_jobs=jobs,
            random_state=seed,
        )

        # Histogram GB: fast, strong on tabular, handles interactions
        p = params.get('hist_gb', {})
        models['hist_gb'] = HistGradientBoostingClassifier(
            max_iter=p.get('max_iter', 160),
            learning_rate=p.get('learning_rate', 0.05),
            max_leaf_nodes=p.get('max_leaf_nodes', 15),
            min_samples_leaf=p.get('min_samples_leaf', 25),
            l2_regularization=p.get('l2', 1.0),
            early_stopping=True,
            validation_fraction=0.15,
            random_state=seed,
        )

        p = params.get('neural_net', {})
        nn_pipe = Pipeline([
            ('scaler', StandardScaler()),
            ('mlp', MLPClassifier(
                hidden_layer_sizes=p.get('hidden', (32, 16)),
                activation='relu',
                alpha=p.get('alpha', 0.01),
                learning_rate_init=p.get('lr', 0.002),
                max_iter=p.get('max_iter', 300),
                early_stopping=True,
                validation_fraction=0.2,
                n_iter_no_change=15,
                random_state=seed,
            ))
        ])
        models['neural_net'] = nn_pipe

        return models

    def fit(self, X_train, y_train, X_val=None, y_val=None, params=None,
            progress_cb=None, warm_start_model=None, n_seeds=1, recency=False,
            use_stacking=False, parallel=False):
        """
        Fit all base models on training data.

        n_seeds: number of seeds for XGBoost/LightGBM (variance reduction).
        recency: if True, sample weights decay exponentially with age
                 (recent candles matter more for the next prediction).
        use_stacking: build the stacking meta-model. DISABLED by default:
                 measured out-of-sample, the GradientBoosting meta-model
                 overfits the recent regime and UNDERPERFORMS the plain
                 weighted log-odds pooling of the base models.
        parallel: when this ensemble is trained inside a parallel worker
                 (trial search / walk-forward), each estimator uses fewer
                 threads to avoid CPU oversubscription.

        warm_start_model: previous TradingEnsemble whose XGBoost booster is
        continued (true incremental learning).
        """
        self.feature_names = list(X_train.columns)
        self.n_seeds = max(1, int(n_seeds))
        jobs = JOBS_LIGHT if parallel else None
        models = {}
        # V19: seed-ensembling now covers every tree family (XGBoost,
        # LightGBM, RandomForest, ExtraTrees, HistGB) — averaging across
        # seeds cuts estimator variance, not just for the boosting models.
        _SEED_FAMILIES = ('xgboost', 'lightgbm', 'random_forest',
                          'extra_trees', 'hist_gb')
        for s in range(self.n_seeds):
            seed = 42 + s * 101
            built = self._build_base_models(params, seed=seed, jobs=jobs)
            for name, est in built.items():
                if s == 0:
                    models[name] = est
                elif name in _SEED_FAMILIES:
                    models[f'{name}_s{s+1}'] = est
        self.models = models
        y_train_arr = np.asarray(y_train).astype(int)

        # Warm-start: TRUE incremental continuation for XGBoost via its
        # booster; other estimators retrain fresh (sklearn has no warm
        # continuation across save/load that is reliable).
        self._warm_xgb_booster = None
        if warm_start_model is not None and warm_start_model.is_fitted:
            same_feats = (list(getattr(warm_start_model, 'feature_names', [])) ==
                          list(X_train.columns))
            if (same_feats and 'xgboost' in warm_start_model.models
                    and 'xgboost' in self.models):
                try:
                    self._warm_xgb_booster = warm_start_model.models['xgboost'].get_booster()
                    self.warm_started = True
                    self.training_round = warm_start_model.training_round + 1
                    self._log(f"Warm-start: continuing XGBoost booster "
                              f"(round {self.training_round})")
                    if progress_cb:
                        progress_cb(f"یادگیری تدریجی (دور {self.training_round}) "
                                    f"— بوستر XGBoost ادامه داده شد")
                except Exception as e:
                    self._log(f"Warm-start unavailable ({e}); fresh training")
            else:
                self._log("Warm-start skipped: feature set or estimator "
                          "mismatch; fresh training")

        # Class-balanced sample weights (+ optional recency decay)
        sw = compute_sample_weight('balanced', y_train_arr)
        if recency and len(sw) > 30:
            idx = np.arange(len(sw), dtype=float)
            decay = np.exp(-2.5 * (len(sw) - 1 - idx) / len(sw))
            sw = sw * decay
            self._log("Recency weighting: ON (recent candles weighted higher)")

        for name, est in self.models.items():
            if progress_cb:
                progress_cb(f"آموزش {name}...")
            self._log(f"Training {name}")

            try:
                if name.startswith('xgboost'):
                    if self._warm_xgb_booster is not None and name == 'xgboost':
                        # Continuation: add fewer trees with lower LR on top
                        est.set_params(
                            n_estimators=max(60, int(est.n_estimators * 0.6)),
                            learning_rate=est.learning_rate * 0.5,
                        )
                    if X_val is not None and y_val is not None:
                        fit_kwargs = dict(
                            sample_weight=sw,
                            eval_set=[(X_val, np.asarray(y_val).astype(int))],
                            verbose=False,
                        )
                        if self._warm_xgb_booster is not None:
                            fit_kwargs['xgb_model'] = self._warm_xgb_booster
                        est.fit(X_train, y_train_arr, **fit_kwargs)
                    else:
                        fit_kwargs = dict(sample_weight=sw, verbose=False)
                        if self._warm_xgb_booster is not None:
                            fit_kwargs['xgb_model'] = self._warm_xgb_booster
                        est.fit(X_train, y_train_arr, **fit_kwargs)
                elif name.startswith('lightgbm'):
                    if X_val is not None and y_val is not None:
                        est.fit(X_train, y_train_arr, sample_weight=sw,
                                eval_set=[(X_val, np.asarray(y_val).astype(int))],
                                callbacks=[])
                    else:
                        est.fit(X_train, y_train_arr, sample_weight=sw)
                elif name == 'neural_net':
                    est.fit(X_train, y_train_arr)
                else:
                    est.fit(X_train, y_train_arr, sample_weight=sw)

                if X_val is not None and y_val is not None:
                    pred = est.predict(X_val)
                    acc = accuracy_score(np.asarray(y_val).astype(int), pred)
                else:
                    pred = est.predict(X_train)
                    acc = accuracy_score(y_train_arr, pred)

                advantage = max(0.0, acc - 0.5)
                w = 0.1 + advantage * 2
                self.weights[name] = w
                self._log(f"  {name} acc={acc:.4f}, weight={w:.3f}")
                if progress_cb:
                    progress_cb(f"{name}: دقت {(acc*100):.1f}%")
            except Exception as e:
                self._log(f"  {name} FAILED: {e}")
                self.weights[name] = 0.0
                if progress_cb:
                    progress_cb(f"✖ {name}: {e}")

        # Normalize weights
        total_w = sum(self.weights.values())
        if total_w > 0:
            self.weights = {k: v / total_w for k, v in self.weights.items()}

        # Train stacking meta-model on base model probabilities.
        # DISABLED by default (use_stacking=False): out-of-sample it
        # overfits the recent regime. The ensemble combines base models
        # with weighted log-odds pooling instead (see predict_proba_array).
        if use_stacking and X_val is not None and y_val is not None and len(X_val) > 50:
            try:
                self._log("Training stacking meta-model (GradientBoosting)")
                if progress_cb:
                    progress_cb("meta-model (stacking)...")
                meta_X = self._base_proba_matrix(X_val)
                meta_y = np.asarray(y_val).astype(int)
                self.meta_model = GradientBoostingClassifier(
                    n_estimators=60, max_depth=2, learning_rate=0.05,
                    subsample=0.8, min_samples_leaf=20,
                    random_state=42
                )
                self.meta_model.fit(meta_X, meta_y)
                self._log(f"  meta-model fit on val ({len(meta_y)} rows)")
                if progress_cb:
                    progress_cb(f"meta-model: built ({len(meta_y)} val rows)")
            except Exception as e:
                self._log(f"  meta-model FAILED: {e}")
                self.meta_model = None

        self.is_fitted = True
        return self

    def fit_calibrator(self, oof_probs: np.ndarray, oof_y: np.ndarray) -> bool:
        """Fit Platt calibration on early OOF data and validate on a later block.

        The previous implementation fitted and scored the calibrator on the
        same OOF rows, which gave an optimistic calibration-quality estimate.
        Here the first 50% is used for fitting, the next 20% for validation,
        and the final 30% remains untouched for threshold selection.
        """
        try:
            p = np.asarray(oof_probs, dtype=float)
            y_raw = np.asarray(oof_y, dtype=float)
            n = min(len(p), len(y_raw))
            p, y_raw = p[:n], y_raw[:n]
            # Split by the original chronological OOF timeline FIRST, then
            # remove neutral/ambiguous labels inside each block. Compressing
            # valid labels before splitting would shift temporal boundaries.
            split = int(n * 0.50)
            validation_end = int(n * 0.70)
            fit_mask = np.isfinite(p[:split]) & np.isfinite(y_raw[:split])
            valid_mask = (np.isfinite(p[split:validation_end]) &
                          np.isfinite(y_raw[split:validation_end]))
            p_fit = np.clip(p[:split][fit_mask], 1e-6, 1 - 1e-6)
            y_fit = y_raw[:split][fit_mask].astype(int)
            p_valid = np.clip(p[split:validation_end][valid_mask], 1e-6, 1 - 1e-6)
            y_valid = y_raw[split:validation_end][valid_mask].astype(int)
            if (len(p_fit) < 250 or len(p_valid) < 100
                    or len(np.unique(y_fit)) < 2 or len(np.unique(y_valid)) < 2):
                self.calibrator = None
                self._log('Calibrator: OFF (not enough chronological calibration/validation samples)')
                return False
            logit_train = np.log(p_fit / (1 - p_fit)).reshape(-1, 1)
            logit_valid = np.log(p_valid / (1 - p_valid)).reshape(-1, 1)
            lr = LogisticRegression(C=1e6, solver='lbfgs', max_iter=300)
            lr.fit(logit_train, y_fit)
            p_before = p_valid
            p_after = lr.predict_proba(logit_valid)[:, 1]
            from sklearn.metrics import brier_score_loss
            b_before = brier_score_loss(y_valid, p_before)
            b_after = brier_score_loss(y_valid, p_after)
            slope = float(lr.coef_[0][0])
            if b_after < b_before * 0.98 and 0.4 <= slope <= 3.0:
                self.calibrator = ('sigmoid', lr)
                self._log(f'Calibrator (sigmoid): ON; chronological holdout Brier {b_before:.4f} -> {b_after:.4f}; slope {slope:.2f}; fit={len(y_fit)}, valid={len(y_valid)}')
                return True
            self.calibrator = None
            self._log(f'Calibrator: OFF (holdout Brier did not improve: {b_before:.4f} -> {b_after:.4f})')
            return False
        except Exception as e:
            self.calibrator = None
            self._log(f'Calibrator failed: {e}')
            return False

    def _apply_calibration(self, p: np.ndarray) -> np.ndarray:
        """Apply sigmoid calibration to raw probabilities (if available)."""
        if self.calibrator is None:
            return p
        try:
            p = np.clip(np.asarray(p, dtype=float), 1e-6, 1 - 1e-6)
            if isinstance(self.calibrator, tuple) and self.calibrator[0] == 'sigmoid':
                lr = self.calibrator[1]
                logit = np.log(p / (1 - p)).reshape(-1, 1)
                return np.clip(lr.predict_proba(logit)[:, 1], 0.0, 1.0)
            return np.clip(self.calibrator.predict(p), 0.0, 1.0)
        except Exception:
            return p

    def predict_agreement(self, X) -> np.ndarray:
        """
        Per-row std of the base models' P(up) — a consensus/quality signal.
        LOW std = all models agree = historically much higher accuracy.
        """
        if not self.is_fitted:
            raise RuntimeError("Model not fitted")
        X = pd.DataFrame(X) if not isinstance(X, pd.DataFrame) else X
        X = X[self.feature_names].copy()
        cols = []
        for name, est in self.models.items():
            if self.weights.get(name, 0) <= 0:
                continue
            try:
                p = est.predict_proba(X)
                cols.append(p[:, 1] if p.shape[1] > 1 else p[:, 0])
            except Exception:
                continue
        if not cols:
            return np.zeros(len(X))
        return np.std(np.column_stack(cols), axis=1)

    def _base_proba_matrix(self, X) -> np.ndarray:
        """Build feature matrix for stacking: each column = base model's P(up)."""
        X = pd.DataFrame(X) if not isinstance(X, pd.DataFrame) else X
        X = X[self.feature_names].copy() if list(X.columns) != self.feature_names else X
        cols = []
        for name in sorted(self.models.keys()):
            if self.weights.get(name, 0) <= 0:
                continue
            try:
                p = self.models[name].predict_proba(X)
                p_up = p[:, 1] if p.shape[1] > 1 else p[:, 0]
                cols.append(p_up)
            except Exception:
                cols.append(np.full(len(X), 0.5))
        if not cols:
            return np.full((len(X), 1), 0.5)
        return np.column_stack(cols)

    def predict_proba(self, X, use_meta=True) -> float:
        """Predict P(up) for a single row. Uses meta-model when available."""
        if not self.is_fitted:
            raise RuntimeError("Model not fitted")
        X = pd.DataFrame(X).iloc[[0]] if not isinstance(X, pd.DataFrame) else X
        X = X[self.feature_names] if list(X.columns) != self.feature_names else X

        # If meta-model exists, use it for final prediction
        if use_meta and self.meta_model is not None:
            try:
                meta_X = self._base_proba_matrix(X)
                p = self.meta_model.predict_proba(meta_X)
                p_up = p[0][1] if p.shape[1] > 1 else p[0][0]
                p_up = self._apply_calibration(np.array([p_up]))[0]
                return float(np.clip(p_up, 0.0, 1.0))
            except Exception:
                pass  # fall through to soft-voting

        # Fallback: weighted log-odds pooling (the main combiner).
        # Log-odds pooling lets unanimous models produce genuinely extreme
        # probabilities (arithmetic averaging compresses them), which is
        # what makes the 70-90% confidence tiers measurable.
        probs = []
        for name, est in self.models.items():
            if self.weights.get(name, 0) <= 0:
                continue
            try:
                p = est.predict_proba(X)
                p_up = np.clip(p[0][1] if p.shape[1] > 1 else p[0][0], 1e-6, 1 - 1e-6)
                probs.append((self.weights[name], p_up))
            except Exception:
                continue

        if not probs:
            return 0.5
        total_w = sum(w for w, _ in probs)
        if total_w == 0:
            return 0.5
        logit = sum(w * np.log(p / (1 - p)) for w, p in probs) / total_w
        raw_probability = float(np.clip(1.0 / (1.0 + np.exp(-logit)), 0.0, 1.0))
        # Calibration must be applied to the normal weighted-log-odds path too;
        # previously only the optional stacking path applied it.
        if use_meta:
            return float(self._apply_calibration(np.array([raw_probability]))[0])
        return raw_probability

    def predict_proba_array(self, X, use_meta=True) -> np.ndarray:
        """Predict for many rows at once. Uses meta-model when available.
        use_meta=False returns the honest soft-vote ensemble probabilities
        (for evaluating data that the meta-model was trained on)."""
        if not self.is_fitted:
            raise RuntimeError("Model not fitted")
        X = pd.DataFrame(X) if not isinstance(X, pd.DataFrame) else X
        X = X[self.feature_names].copy()

        # If meta-model exists, use it
        if use_meta and self.meta_model is not None:
            try:
                meta_X = self._base_proba_matrix(X)
                p = self.meta_model.predict_proba(meta_X)
                p_up = p[:, 1] if p.shape[1] > 1 else p[:, 0]
                p_up = self._apply_calibration(p_up)
                return np.clip(p_up, 0.0, 1.0)
            except Exception:
                pass

        # Weighted log-odds pooling (main combiner)
        n = len(X)
        out = np.zeros(n, dtype=float)
        w_sum = 0.0
        for name, est in self.models.items():
            w = self.weights.get(name, 0)
            if w <= 0:
                continue
            try:
                p = est.predict_proba(X)
                p_up = np.clip(p[:, 1] if p.shape[1] > 1 else p[:, 0], 1e-6, 1 - 1e-6)
                out += w * np.log(p_up / (1 - p_up))
                w_sum += w
            except Exception:
                continue
        if w_sum > 0:
            out = 1.0 / (1.0 + np.exp(-out / w_sum))
        else:
            out[:] = 0.5
        out = np.clip(out, 0.0, 1.0)
        # Keep use_meta=False strictly raw for validation/calibration diagnostics.
        if use_meta:
            out = self._apply_calibration(out)
        return out

    def predict(self, X, use_meta=True) -> np.ndarray:
        """Binary predict."""
        return (self.predict_proba_array(X, use_meta=use_meta) >= 0.5).astype(int)

    def feature_importance(self) -> pd.DataFrame:
        """Return feature importance (averaged across tree models)."""
        frames = []
        for name, est in self.models.items():
            if self.weights.get(name, 0) <= 0:
                continue
            if not hasattr(est, 'feature_importances_'):
                continue  # skip Pipeline (neural_net)
            try:
                imp = est.feature_importances_
                frames.append(
                    pd.DataFrame({'feature': self.feature_names,
                                  'importance': imp * self.weights[name]})
                )
            except Exception:
                continue
        if not frames:
            return pd.DataFrame(columns=['feature', 'importance'])
        df = pd.concat(frames).groupby('feature', as_index=False).sum()
        return df.sort_values('importance', ascending=False).reset_index(drop=True)

    def evaluate(self, X, y, use_meta=True):
        """Compute metrics on given data, including multi-threshold confidence.
        use_meta=False evaluates the raw soft-vote ensemble (use this when the
        meta-model was trained on the same data, e.g. validation metrics)."""
        y_arr = np.asarray(y).astype(int)
        preds = self.predict(X, use_meta=use_meta)
        probs = self.predict_proba_array(X, use_meta=use_meta)

        # Multiple confidence thresholds (both directions: p>=t or p<=1-t)
        conf_metrics = {}
        for thresh in [0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90]:
            mask = (probs >= thresh) | (probs <= 1 - thresh)
            if mask.sum() > 0:
                acc = accuracy_score(y_arr[mask], preds[mask])
                conf_metrics[f'acc_{int(thresh*100)}'] = float(acc)
                conf_metrics[f'cov_{int(thresh*100)}'] = float(mask.mean())
            else:
                conf_metrics[f'acc_{int(thresh*100)}'] = 0.0
                conf_metrics[f'cov_{int(thresh*100)}'] = 0.0

        # Default high-conf = 0.65
        hi_mask = (probs >= 0.65) | (probs <= 0.35)
        if hi_mask.sum() > 0:
            hi_acc = accuracy_score(y_arr[hi_mask], preds[hi_mask])
            hi_cov = float(hi_mask.mean())
        else:
            hi_acc, hi_cov = 0.0, 0.0

        # Very high confidence (0.75)
        vh_mask = (probs >= 0.75) | (probs <= 0.25)
        if vh_mask.sum() > 0:
            vh_acc = accuracy_score(y_arr[vh_mask], preds[vh_mask])
            vh_cov = float(vh_mask.mean())
        else:
            vh_acc, vh_cov = 0.0, 0.0

        # Consensus tier: models nearly unanimous (low prob std).
        try:
            agr = self.predict_agreement(X)
            ag_mask = agr <= 0.06
        except Exception:
            agr = np.zeros(len(y_arr))
            ag_mask = np.zeros(len(y_arr), dtype=bool)
        if ag_mask.sum() > 0:
            ag_acc = accuracy_score(y_arr[ag_mask], preds[ag_mask])
            ag_cov = float(ag_mask.mean())
        else:
            ag_acc, ag_cov = 0.0, 0.0

        # Ultra high confidence (0.85) — the “precision tier”
        uh_mask = (probs >= 0.85) | (probs <= 0.15)
        if uh_mask.sum() > 0:
            uh_acc = accuracy_score(y_arr[uh_mask], preds[uh_mask])
            uh_cov = float(uh_mask.mean())
        else:
            uh_acc, uh_cov = 0.0, 0.0

        # Max confidence (0.90) — only the most certain calls
        mx_mask = (probs >= 0.90) | (probs <= 0.10)
        if mx_mask.sum() > 0:
            mx_acc = accuracy_score(y_arr[mx_mask], preds[mx_mask])
            mx_cov = float(mx_mask.mean())
        else:
            mx_acc, mx_cov = 0.0, 0.0

        return {
            'accuracy': float(accuracy_score(y_arr, preds)),
            'balanced_acc': float(balanced_accuracy_score(y_arr, preds)),
            'high_conf_acc': float(hi_acc),
            'high_conf_cov': float(hi_cov),
            'very_high_conf_acc': float(vh_acc),
            'very_high_conf_cov': float(vh_cov),
            'agree_acc': float(ag_acc),
            'agree_cov': float(ag_cov),
            'mean_agreement_std': float(np.mean(agr)) if len(agr) else 0.0,
            'ultra_high_conf_acc': float(uh_acc),
            'ultra_high_conf_cov': float(uh_cov),
            'max_conf_acc': float(mx_acc),
            'max_conf_cov': float(mx_cov),
            'n_samples': int(len(y_arr)),
            'mean_prob': float(probs.mean()),
            'prob_std': float(probs.std()),
            'conf_metrics': conf_metrics,
        }

    def calibration_report(self, X, y, n_bins: int = 6) -> dict:
        """V20 — honesty report of the predicted probabilities (ECE + Brier).

        Expected Calibration Error: how far the empirical hit rate inside each
        probability bucket is from the bucket's mean predicted probability.
        ECE 0.02 means predictions are essentially honest; ECE 0.10+ means
        "70% confidence" actually wins far less (or more) often than claimed.
        Purely diagnostic — never changes any threshold or weight.
        """
        probs = np.asarray(self.predict_proba_array(X, use_meta=True), dtype=float)
        y_arr = np.asarray(y).astype(int)
        n = min(len(probs), len(y_arr))
        if n == 0:
            return {'ece': 0.0, 'brier': 0.0, 'buckets': [], 'n': 0}
        probs, y_arr = probs[:n], y_arr[:n]
        edges = np.linspace(0.0, 1.0, max(2, int(n_bins)) + 1)
        buckets = []
        ece = 0.0
        for i in range(len(edges) - 1):
            lo, hi = edges[i], edges[i + 1]
            mask = ((probs >= lo) & (probs < hi)) if i < len(edges) - 2 \
                else ((probs >= lo) & (probs <= hi))
            cnt = int(mask.sum())
            if cnt == 0:
                continue
            mean_p = float(probs[mask].mean())
            hit = float(y_arr[mask].mean())
            ece += (cnt / n) * abs(mean_p - hit)
            buckets.append({'range': f'{lo:.2f}-{hi:.2f}', 'n': cnt,
                            'mean_prob': round(mean_p, 4),
                            'hit_rate': round(hit, 4)})
        brier = float(np.mean((probs - y_arr) ** 2))
        return {'ece': round(ece, 4), 'brier': round(brier, 4),
                'buckets': buckets, 'n': int(n)}

    def save(self, path):
        """Save model to disk using joblib."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        bundle = {
            'feature_names': self.feature_names,
            'weights': self.weights,
            'is_fitted': self.is_fitted,
            'train_acc': self.train_acc,
            'val_acc': self.val_acc,
            'walk_forward_acc': self.walk_forward_acc,
            'balanced_acc': self.balanced_acc,
            'high_conf_acc': self.high_conf_acc,
            'high_conf_cov': self.high_conf_cov,
            'history': self.history,
            'warm_started': self.warm_started,
            'training_round': self.training_round,
            'meta_model': self.meta_model,
            'calibrator': self.calibrator,
            'n_seeds': self.n_seeds,
            'meta_labeler': getattr(self, 'meta_labeler', None),
            'meta_threshold': getattr(self, 'meta_threshold', 0.55),
        }
        save_dict = {
            'meta': bundle,
            'models': self.models,
        }
        joblib.dump(save_dict, path, compress=3)
        return path

    @classmethod
    def load(cls, path):
        """Load model from disk."""
        path = Path(path)
        if not path.exists():
            return None
        try:
            data = joblib.load(path)
            obj = cls()
            obj.models = data['models']
            meta = data['meta']
            obj.feature_names = meta['feature_names']
            obj.weights = meta['weights']
            obj.is_fitted = meta['is_fitted']
            obj.train_acc = meta.get('train_acc', 0)
            obj.val_acc = meta.get('val_acc', 0)
            obj.walk_forward_acc = meta.get('walk_forward_acc', 0)
            obj.balanced_acc = meta.get('balanced_acc', 0)
            obj.high_conf_acc = meta.get('high_conf_acc', 0)
            obj.high_conf_cov = meta.get('high_conf_cov', 0)
            obj.history = meta.get('history', [])
            obj.warm_started = meta.get('warm_started', False)
            obj.training_round = meta.get('training_round', 1)
            obj.meta_model = meta.get('meta_model', None)
            obj.calibrator = meta.get('calibrator', None)
            obj.n_seeds = meta.get('n_seeds', 1)
            obj.meta_labeler = meta.get('meta_labeler', None)
            obj.meta_threshold = meta.get('meta_threshold', 0.55)
            return obj
        except Exception:
            return None
