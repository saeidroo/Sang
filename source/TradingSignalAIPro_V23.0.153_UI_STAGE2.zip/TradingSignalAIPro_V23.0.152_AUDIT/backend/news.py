"""Best-effort market news and macro calendar. All external feeds fail open."""
from __future__ import annotations
import time, requests, xml.etree.ElementTree as ET, hashlib
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from threading import Lock
S=requests.Session(); S.headers.update({'User-Agent':'TradingSignalAIPro/6.0'})
_cache={}; _lock=Lock()
def _get_json(url,timeout=8):
 r=S.get(url,timeout=timeout); r.raise_for_status(); return r.json()
def _cached(key,ttl,fn,default):
 now=time.time()
 with _lock:
  old=_cache.get(key)
  if old and now-old[0]<ttl:return old[1]
 try:
  val=fn()
  with _lock:_cache[key]=(now,val)
  return val
 except Exception:
  return old[1] if old else default
def _news():
 def fetch_coindesk():
  r=S.get('https://www.coindesk.com/arc/outboundfeeds/rss/',timeout=8); r.raise_for_status()
  root=ET.fromstring(r.content); items=[]
  for it in root.findall('.//item')[:8]:
   title=it.findtext('title') or ''; link=it.findtext('link') or ''; pub=it.findtext('pubDate') or ''
   items.append({'title':title[:240],'url':link,'published_at':pub,'source':'CoinDesk'})
  return items
 def fetch_cointelegraph():
  r=S.get('https://cointelegraph.com/rss',timeout=8); r.raise_for_status()
  root=ET.fromstring(r.content); items=[]
  for it in root.findall('.//item')[:6]:
   title=it.findtext('title') or ''; link=it.findtext('link') or ''; pub=it.findtext('pubDate') or ''
   items.append({'title':title[:240],'url':link,'published_at':pub,'source':'CoinTelegraph'})
  return items
 def fetch():
  items=[]
  for fn in (fetch_coindesk, fetch_cointelegraph):
   try:
    items.extend(fn())
   except Exception:
    pass
  # de-dupe by title prefix
  seen=set(); out=[]
  for it in items:
   key=(it.get('title') or '')[:48].lower()
   if key in seen: continue
   seen.add(key); out.append(it)
  return out[:10]
 return _cached('news',90,fetch,[])
def _fear_greed():
 def fetch():
  d=_get_json('https://api.alternative.me/fng/?limit=1&format=json'); x=d['data'][0]
  return {'value':int(x['value']),'classification':x['value_classification']}
 return _cached('fg',300,fetch,{'value':50,'classification':'Neutral'})
def _macro():
 def fetch():
  r=S.get('https://nfs.faireconomy.media/ff_calendar_thisweek.json',timeout=8); r.raise_for_status(); data=r.json(); now=datetime.now(timezone.utc); out=[]
  for e in data:
   if str(e.get('impact','')).lower()!='high' or str(e.get('country','')).upper() not in ('USD','US'):continue
   raw=e.get('date') or e.get('datetime')
   try:
    dt=datetime.fromisoformat(str(raw).replace('Z','+00:00'))
    if dt.tzinfo is None:dt=dt.replace(tzinfo=timezone.utc)
   except Exception:continue
   mins=int((dt-now).total_seconds()/60)
   if -1440<=mins<=10080:out.append({'datetime_utc':dt.isoformat(),'minutes_away':mins,'title':str(e.get('title') or e.get('event') or 'USD event'),'currency':'USD','impact':'high'})
  return sorted(out,key=lambda x:x['minutes_away'])
 return _cached('macro',600,fetch,[])
def _translate_fa(text):
 """Best-effort cached headline translation; never presents English as Persian."""
 text=str(text or '').strip()
 if not text:
  return 'عنوانی برای ترجمه موجود نیست'
 digest=hashlib.sha1(text.encode('utf-8')).hexdigest()
 def fetch():
  try:
   response=S.get('https://translate.googleapis.com/translate_a/single',
     params={'client':'gtx','sl':'auto','tl':'fa','dt':'t','q':text[:900]},timeout=4)
   response.raise_for_status(); payload=response.json()
   translated=''.join(part[0] for part in (payload[0] or []) if part and part[0])
   return translated.strip() or 'ترجمهٔ فارسی این خبر موقتاً در دسترس نیست'
  except Exception:
   # Cache failures too, otherwise a disconnected client retries every minute.
   return 'ترجمهٔ فارسی این خبر موقتاً در دسترس نیست'
 translated=_cached('fa:'+digest,21600,fetch,'ترجمهٔ فارسی این خبر موقتاً در دسترس نیست')
 return translated or 'ترجمهٔ فارسی این خبر موقتاً در دسترس نیست'

def _with_persian_titles(items, title_key='title'):
 items=list(items or [])
 if not items:return items
 def translate(item):
  result=dict(item)
  original=str(result.get(title_key,'') or '').strip()
  fa=_translate_fa(original)
  # If translation failed, keep the original headline so the UI is never empty.
  if (not fa) or ('موقتاً در دسترس نیست' in fa) or ('عنوانی برای ترجمه' in fa):
   result['title_fa']=original or 'خبر بدون عنوان'
  else:
   result['title_fa']=fa
  result['title']=original
  return result
 # Small bounded pool: keeps the news endpoint responsive on low-memory PCs.
 with ThreadPoolExecutor(max_workers=min(4,len(items))) as pool:
  return list(pool.map(translate,items))

def build_news_alert(symbol='BTCUSDT'):
 news=_news(); fg=_fear_greed(); macro=_macro(); block=False; reasons=[]
 # RSS headlines are informational only: no unreliable automated sentiment inference.
 news_fa=_with_persian_titles(news[:5])
 macro_fa=_with_persian_titles(macro[:8])
 fg_fa={'Fear and Greed':'شاخص ترس و طمع','Extreme Fear':'ترس شدید','Fear':'ترس','Neutral':'خنثی','Greed':'طمع','Extreme Greed':'طمع شدید'}
 fg=dict(fg); fg['classification_fa']=fg_fa.get(str(fg.get('classification')), 'وضعیت نامشخص')
 upcoming=[e for e in macro_fa if 0<=e['minutes_away']<=30]
 if upcoming:
  block=True; e=upcoming[0]; reasons.append(f"رویداد اقتصادی مهم تا {e['minutes_away']} دقیقه دیگر: {e['title_fa']}")
 return {'block_trading':block,'alert_text':' | '.join(reasons) if reasons else None,
  'sentiment':{'label':'neutral','label_fa':'خنثی','score':0.0,'source':'not_available'},'asset':symbol.replace('USDT',''),
  'breaking':news_fa,'fear_greed':fg,'macro_events':macro_fa,
  'sources_status':{'coindesk_rss':bool(news),'fear_greed':fg.get('value')!=50 or fg.get('classification')!='Neutral','macro_calendar':bool(macro)}}
