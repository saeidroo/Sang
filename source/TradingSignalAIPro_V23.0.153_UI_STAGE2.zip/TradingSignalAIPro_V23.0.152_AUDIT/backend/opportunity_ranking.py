"""Cross-symbol opportunity ranking. Advisory, deterministic, read-only and paper-only."""
from __future__ import annotations


def rank_opportunities(candidates, *, limit=10, max_per_group=1, min_score=45.0):
    if not isinstance(candidates, list):
        raise ValueError('candidates باید فهرست باشد')
    if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 100:
        raise ValueError('limit باید عدد صحیح بین 1 تا 100 باشد')
    if not isinstance(max_per_group, int) or isinstance(max_per_group, bool) or not 1 <= max_per_group <= 20:
        raise ValueError('max_per_group باید بین 1 تا 20 باشد')
    try:
        min_score = float(min_score)
    except (TypeError, ValueError):
        raise ValueError('min_score نامعتبر است')
    if not 0 <= min_score <= 100:
        raise ValueError('min_score باید بین 0 تا 100 باشد')

    clean, rejected = [], []
    seen = set()
    for index, item in enumerate(candidates):
        if not isinstance(item, dict):
            rejected.append({'index': index, 'reason': 'INVALID_RECORD'}); continue
        symbol = str(item.get('symbol', '')).upper().replace('/', '').strip()
        market = str(item.get('market', 'perp')).lower().strip()
        timeframe = str(item.get('timeframe', '1h')).strip()
        key = (symbol, market, timeframe)
        try:
            score = float(item.get('opportunity_quality_index'))
            coverage = float(item.get('evidence_coverage', 0))
        except (TypeError, ValueError):
            rejected.append({'index': index, 'reason': 'MISSING_SCORE_OR_COVERAGE'}); continue
        if (not symbol.endswith('USDT') or market not in {'spot', 'perp'} or not timeframe
                or not 0 <= score <= 100 or not 0 <= coverage <= 1):
            rejected.append({'index': index, 'reason': 'INVALID_FIELDS'}); continue
        if key in seen:
            rejected.append({'index': index, 'reason': 'DUPLICATE_CANDIDATE'}); continue
        seen.add(key)
        classification = str(item.get('classification', ''))
        blockers = item.get('blockers') or []
        if blockers or classification in {'BLOCKED', 'INSUFFICIENT_EVIDENCE', 'POOR_OPPORTUNITY'} or score < min_score:
            rejected.append({'index': index, 'reason': 'BELOW_QUALITY_GATE'}); continue
        # Group may be supplied by a correlation/sector map; default isolates each asset.
        group = str(item.get('correlation_group') or symbol.removesuffix('USDT'))
        clean.append({'symbol': symbol, 'market': market, 'timeframe': timeframe,
                      'score': round(score, 2), 'coverage': round(coverage, 3),
                      'classification': classification, 'correlation_group': group,
                      'source_index': index})

    clean.sort(key=lambda x: (-x['score'], -x['coverage'], x['symbol'], x['market'], x['timeframe']))
    ranked, group_counts = [], {}
    for row in clean:
        group = row['correlation_group']
        if group_counts.get(group, 0) >= max_per_group:
            rejected.append({'index': row['source_index'], 'reason': 'DIVERSIFICATION_LIMIT'}); continue
        if len(ranked) >= limit:
            rejected.append({'index': row['source_index'], 'reason': 'RANK_LIMIT'}); continue
        group_counts[group] = group_counts.get(group, 0) + 1
        ranked.append({**row, 'rank': len(ranked) + 1})
    for row in ranked:
        row.pop('source_index', None)
    return {'ranked_opportunities': ranked, 'rejected_count': len(rejected),
            'rejected': rejected, 'candidate_count': len(candidates),
            'ranked_count': len(ranked), 'diversification_applied': True,
            'ranking_is_advisory': True, 'authorizes_entries': False,
            'read_only': True, 'paper_only': True, 'real_orders_enabled': False,
            'policy': 'Ranks supplied scored candidates only; no market data is fetched and ranking is not a trade instruction.'}
