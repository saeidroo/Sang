"""V22.3v: execute an independent baseline replay and persist its comparison artifact."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
from backend.btc_replay_determinism import compare_prediction_replays, build_training_environment


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False, default=str)


def execute_baseline_replay(dataset, original_predictions, *, original_run_id: str,
                            replay_run_id: str, random_state: int = 42,
                            include_logistic: bool = True, artifact_dir):
    """Retrain on a rebuilt, lineage-verified dataset; never overwrite original run.

    `original_predictions` may contain all models or one model. A distinct replay ID
    and exclusive artifact creation make the replay append-only.
    """
    if not original_run_id or not replay_run_id or original_run_id == replay_run_id:
        raise ValueError('invalid_replay_run_identity')
    lineage = dataset.get('manifest', {}).get('lineage')
    if lineage is None:
        raise ValueError('training_lineage_required_for_replay')
    from backend.btc_training_lineage import require_training_lineage
    require_training_lineage(lineage)
    from backend.btc_baseline import evaluate_btc_4h_baselines
    result = evaluate_btc_4h_baselines(dataset, include_logistic=include_logistic,
        random_state=random_state, require_lineage=True)
    original = original_predictions.to_dict(orient='records') if hasattr(original_predictions, 'to_dict') else list(original_predictions)
    replay_rows = result['oof_predictions'].to_dict(orient='records')
    models = sorted({str(r.get('model')) for r in original} | {str(r.get('model')) for r in replay_rows})
    comparisons = {}
    for model in models:
        left = [r for r in original if str(r.get('model')) == model]
        right = [r for r in replay_rows if str(r.get('model')) == model]
        comparisons[model] = compare_prediction_replays(left, right)
    environment = result['training_environment']
    expected_environment = build_training_environment(random_state=random_state,
        model_config={'include_logistic': bool(include_logistic), 'logistic_max_iter': 1000,
                      'class_weight': 'balanced', 'scaler': 'StandardScaler'})
    if environment['environment_sha256'] != expected_environment['environment_sha256']:
        raise ValueError('replay_environment_fingerprint_mismatch')
    payload = {'schema_version':'btc4h-training-replay-artifact-v1',
        'original_run_id':original_run_id, 'replay_run_id':replay_run_id,
        'dataset_hash':dataset['manifest'].get('dataset_hash'),
        'lineage_sha256':dataset['manifest'].get('lineage_sha256'),
        'training_environment':environment,
        'replay_oof_sha256':result['oof_prediction_sha256'],
        'comparisons':comparisons,
        'all_models_deterministic':all(x['deterministic'] for x in comparisons.values()),
        'replay_metrics':result['aggregate_metrics']}
    payload['artifact_sha256'] = hashlib.sha256(_canonical(payload).encode()).hexdigest()
    outdir = Path(artifact_dir); outdir.mkdir(parents=True, exist_ok=True)
    target = outdir / f'{replay_run_id}.json'
    # O_EXCL: a replay artifact is immutable and a repeated ID is rejected.
    with target.open('x', encoding='utf-8') as handle:
        handle.write(_canonical(payload) + '\n')
    return payload
