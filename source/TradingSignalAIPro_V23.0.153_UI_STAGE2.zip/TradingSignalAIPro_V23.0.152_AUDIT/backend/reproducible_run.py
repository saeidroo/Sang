"""V22.2e reproducible evaluation-run manifests and integrity verification."""
from __future__ import annotations
import hashlib, json, os, platform, sys, uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

RUN_SCHEMA = "repro-run-v1"

def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def sha256_file(path: str | Path) -> str:
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024), b""): h.update(chunk)
    return h.hexdigest()

def create_run_manifest(*, data_hash: str, config: dict, cost_model: dict, test_block_id: str,
                        code_id: str | None = None, seed: int | None = None,
                        trial_count: int | None = None, model_artifacts: dict[str, str] | None = None,
                        run_id: str | None = None) -> dict:
    """Create a deterministic-content manifest; timestamp/run id are audit metadata."""
    if not isinstance(data_hash,str) or len(data_hash)!=64 or any(c not in "0123456789abcdef" for c in data_hash.lower()):
        raise ValueError("data_hash must be a SHA-256 hex digest")
    if not isinstance(config,dict): raise ValueError("config must be an object")
    if not isinstance(cost_model,dict) or not cost_model.get("cost_hash") or not cost_model.get("version"):
        raise ValueError("versioned cost_model with cost_hash is required")
    if not test_block_id or not str(test_block_id).strip(): raise ValueError("test_block_id is required")
    if trial_count is not None and int(trial_count)<1: raise ValueError("trial_count must be >= 1")
    artifacts={}
    for name,path in (model_artifacts or {}).items():
        p=Path(path)
        if not p.is_file(): raise ValueError(f"model artifact not found: {name}")
        artifacts[str(name)]={"sha256":sha256_file(p),"size_bytes":p.stat().st_size,"filename":p.name}
    body={"schema_version":RUN_SCHEMA,"run_id":run_id or str(uuid.uuid4()),
          "created_at":datetime.now(timezone.utc).isoformat(timespec="seconds"),
          "data":{"sha256":data_hash},"config":{"value":config,"sha256":sha256_bytes(_canonical(config))},
          "cost_model":dict(cost_model),"test_block":{"id":str(test_block_id),"untouched_asserted_by_caller":True},
          "code_id":code_id or os.getenv("TS_AI_CODE_ID","working-tree"),"seed":seed,
          "trial_count":int(trial_count) if trial_count is not None else None,
          "runtime":{"python":sys.version.split()[0],"platform":platform.platform()},"model_artifacts":artifacts}
    body["manifest_sha256"]=sha256_bytes(_canonical(body))
    return body

def save_run_manifest(manifest: dict, directory: str | Path) -> Path:
    if manifest.get("schema_version")!=RUN_SCHEMA: raise ValueError("unsupported manifest schema")
    target=Path(directory); target.mkdir(parents=True,exist_ok=True)
    path=target/f"{manifest['run_id']}.json"
    tmp=path.with_suffix(".json.tmp")
    tmp.write_bytes(_canonical(manifest)+b"\n")
    os.replace(tmp,path)
    return path

def verify_run_manifest(manifest_or_path: dict | str | Path, *, verify_artifacts_dir: str | Path | None = None) -> dict:
    if isinstance(manifest_or_path,(str,Path)):
        path=Path(manifest_or_path); m=json.loads(path.read_text(encoding="utf-8"))
        base=Path(verify_artifacts_dir) if verify_artifacts_dir else path.parent
    else: m=dict(manifest_or_path); base=Path(verify_artifacts_dir) if verify_artifacts_dir else None
    supplied=m.pop("manifest_sha256",None)
    actual=sha256_bytes(_canonical(m))
    errors=[]
    if m.get("schema_version")!=RUN_SCHEMA: errors.append("unsupported_schema")
    if not supplied or supplied!=actual: errors.append("manifest_hash_mismatch")
    artifact_checks={}
    for name,meta in (m.get("model_artifacts") or {}).items():
        if base is None: artifact_checks[name]="not_checked_no_directory"; continue
        p=base/meta.get("filename","")
        ok=p.is_file() and sha256_file(p)==meta.get("sha256") and p.stat().st_size==meta.get("size_bytes")
        artifact_checks[name]="ok" if ok else "mismatch_or_missing"
        if not ok: errors.append(f"artifact_invalid:{name}")
    return {"valid":not errors,"errors":errors,"manifest_sha256":supplied,"artifact_checks":artifact_checks}


def link_run_provenance(manifest: dict, *, registry_events: list[dict], paper_events: list[dict],
                        experiment_id: str | None = None) -> dict:
    """Attach registry-derived trial count and Paper Ledger linkage, then reseal hash.

    Trial count is derived from append-only experiment_started events, never caller input.
    Paper events are restricted to the manifest run_id.
    """
    import copy
    out=copy.deepcopy(manifest)
    starts=[e for e in registry_events if e.get('event_type')=='experiment_started']
    if experiment_id:
        matched=[e for e in starts if e.get('experiment_id')==str(experiment_id)]
        if not matched:
            raise ValueError('experiment_id not found in Experiment Registry')
        hypothesis_id=matched[0].get('hypothesis_id')
        relevant=[e for e in starts if e.get('hypothesis_id')==hypothesis_id]
        out['experiment_registry']={'experiment_id':str(experiment_id),'hypothesis_id':hypothesis_id,
            'trial_count':len(relevant),'trial_count_scope':'hypothesis'}
    else:
        out['experiment_registry']={'experiment_id':None,'trial_count':len(starts),
            'trial_count_scope':'global_registry'}
    out['trial_count']=out['experiment_registry']['trial_count']
    run_id=str(out['run_id'])
    linked=[e for e in paper_events if str(e.get('run_id'))==run_id]
    trade_events={'trade_closed','trade_close','position_closed','closed_trade'}
    out['paper_ledger']={'run_id':run_id,'event_count':len(linked),
        'trade_event_count':sum(1 for e in linked if str(e.get('event','')).lower() in trade_events),
        'event_ids':sorted(str(e.get('event_id')) for e in linked if e.get('event_id')),
        'linked':bool(linked)}
    out.pop('manifest_sha256',None)
    out['manifest_sha256']=sha256_bytes(_canonical(out))
    return out
