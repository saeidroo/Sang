"""Read-only mining of completed archived OHLCV for severe pump/dump episodes.

The archive is opened read-only. Labels use future highs/lows while features use
only candles available before the event window, preventing look-ahead leakage.
"""
from __future__ import annotations
import os, sqlite3
from collections import defaultdict
from pathlib import Path

DEFAULT_DB = Path(os.getenv('TRADING_AI_HISTORY_DB', str(Path.home()/'.trading_ai_models'/'history'/'candles.sqlite3'))).expanduser()
SUPPORTED = {'5m','15m','30m','1h','4h','1d'}


def _band(v, cuts, labels):
    for cut, label in zip(cuts, labels):
        if v < cut: return label
    return labels[-1]


def _pre_move_features(rows, i, lookback=24):
    w = rows[max(0, i-lookback):i]
    if len(w) < min(12, lookback): return None
    try:
        closes=[float(x[4]) for x in w]; opens=[float(x[1]) for x in w]
        highs=[float(x[2]) for x in w]; lows=[float(x[3]) for x in w]
        vols=[max(0.0,float(x[5])) for x in w]
        if min(closes)<=0 or min(opens)<=0: return None
        mom4=(closes[-1]/closes[max(0,len(closes)-5)]-1)*100
        mom12=(closes[-1]/closes[max(0,len(closes)-13)]-1)*100
        avg=sum(vols[:-1])/max(1,len(vols)-1)
        vr=vols[-1]/avg if avg>0 else 0.0
        rng=(max(highs)-min(lows))/closes[-1]*100
        body=(closes[-1]/opens[-1]-1)*100
        up=sum(closes[k]>closes[k-1] for k in range(1,len(closes)))/max(1,len(closes)-1)
        return {'momentum_4':round(mom4,3),'momentum_12':round(mom12,3),
                'volume_ratio':round(vr,3),'range_pct':round(rng,3),
                'last_body_pct':round(body,3),'up_close_ratio':round(up,3),
                'momentum_4_band':_band(mom4,[-1,1],['down','flat','up']),
                'momentum_12_band':_band(mom12,[-2.5,2.5],['down','flat','up']),
                'volume_band':_band(vr,[0.65,1.8],['low','normal','high']),
                'volatility_band':_band(rng,[3,8],['tight','normal','wide']),
                'pressure':'sell' if body<=-0.5 else 'buy' if body>=0.5 else 'neutral',
                'trend':'bull' if up>0.62 else 'bear' if up<0.38 else 'mixed'}
    except (ValueError,TypeError,ZeroDivisionError,IndexError): return None


def mine_rows(rows, symbol, timeframe, threshold_pct=10.0, horizon_bars=24, lookback=24, max_events=5000):
    """Mine both directions independently; a whipsaw may produce both labels."""
    threshold=float(threshold_pct); horizon=int(horizon_bars); lookback=int(lookback)
    if not 0.1 <= threshold <= 100 or not 2 <= horizon <= 500 or not 5 <= lookback <= 200:
        raise ValueError('پارامترهای اسکن خارج از محدوده مجاز هستند')
    if timeframe not in SUPPORTED: raise ValueError('تایم‌فریم پشتیبانی نمی‌شود')
    events=[]; counts={'pump':0,'dump':0}; pattern=defaultdict(lambda:{'pump':0,'dump':0})
    clean=[]
    for r in rows:
        try:
            t,o,h,l,c,v=r
            vals=[float(o),float(h),float(l),float(c),float(v)]
            if int(t)>0 and min(vals[:4])>0 and vals[1]>=max(vals[0],vals[3]) and vals[2]<=min(vals[0],vals[3]) and vals[4]>=0:
                clean.append((int(t),*vals))
        except (TypeError,ValueError,IndexError): continue
    clean.sort(key=lambda x:x[0])
    # Non-overlapping event windows reduce duplicate labels from one prolonged move.
    next_allowed=0
    for i in range(lookback, len(clean)-horizon):
        if i < next_allowed: continue
        start=float(clean[i][4])
        future=clean[i+1:i+1+horizon]
        highs=[x[2] for x in future]; lows=[x[3] for x in future]
        pump=(max(highs)/start-1)*100 >= threshold
        dump=(min(lows)/start-1)*100 <= -threshold
        if not (pump or dump): continue
        features=_pre_move_features(clean,i,lookback)
        if not features: continue
        labels=[]
        if pump: labels.append('pump')
        if dump: labels.append('dump')
        for label in labels:
            counts[label]+=1
            key='|'.join([features['momentum_4_band'],features['momentum_12_band'],features['volume_band'],features['volatility_band'],features['pressure'],features['trend']])
            pattern[key][label]+=1
        events.append({'symbol':str(symbol).upper(),'timeframe':timeframe,'event_ts':clean[i][0],
                       'reference_close':round(start,10),'pump':bool(pump),'dump':bool(dump),
                       'max_up_pct':round((max(highs)/start-1)*100,3),
                       'max_down_pct':round((min(lows)/start-1)*100,3),
                       'horizon_bars':horizon,'threshold_pct':threshold,'preconditions':features})
        next_allowed=i+horizon
        if len(events)>=max_events: break
    ranked=sorted([{'signature':k,'pump':v['pump'],'dump':v['dump'],'samples':v['pump']+v['dump']} for k,v in pattern.items()],
                  key=lambda x:(x['samples'],x['pump']+x['dump']),reverse=True)[:30]
    return {'symbol':str(symbol).upper(),'timeframe':timeframe,'candles_scanned':len(clean),
            'threshold_pct':threshold,'horizon_bars':horizon,'pump_events':counts['pump'],
            'dump_events':counts['dump'],'both_direction_events':sum(1 for e in events if e['pump'] and e['dump']),
            'patterns':ranked,'events':events[-100:]}


def scan_archive(symbol=None, timeframe='1h', threshold_pct=10.0, horizon_bars=24,
                 lookback=24, db_path=None, max_candles=250000):
    path=Path(db_path or DEFAULT_DB).expanduser()
    if not path.exists():
        return {'status':'no_history_archive','archive_path':str(path),'markets':[],'total_candles':0}
    uri=f'file:{path.resolve().as_posix()}?mode=ro'
    con=sqlite3.connect(uri,uri=True,timeout=10)
    try:
        q='SELECT symbol,timeframe,t,open,high,low,close,volume FROM candles WHERE timeframe=?'
        args=[timeframe]
        if symbol: q+=' AND UPPER(symbol)=?'; args.append(str(symbol).upper())
        q+=' ORDER BY symbol,t LIMIT ?'; args.append(int(max_candles))
        rows=con.execute(q,args).fetchall()
    finally: con.close()
    grouped=defaultdict(list)
    for sym,tf,t,o,h,l,c,v in rows: grouped[str(sym).upper()].append((t,o,h,l,c,v))
    reports=[mine_rows(data,sym,timeframe,threshold_pct,horizon_bars,lookback) for sym,data in grouped.items()]
    return {'status':'completed' if reports else 'no_matching_candles','archive_path':str(path),
            'total_candles':len(rows),'markets':reports,
            'pump_events':sum(x['pump_events'] for x in reports),
            'dump_events':sum(x['dump_events'] for x in reports)}
