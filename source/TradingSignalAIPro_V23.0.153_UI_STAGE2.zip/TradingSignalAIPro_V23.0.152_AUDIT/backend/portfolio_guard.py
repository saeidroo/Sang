"""V23.0.67 read-only paper portfolio exposure and concurrency guard."""
from __future__ import annotations
import math

DEFAULTS = {'max_positions': 5, 'max_gross_exposure_pct': 80.0,
            'max_portfolio_stop_risk_pct': 2.0, 'max_symbol_exposure_pct': 25.0,
            'max_group_exposure_pct': 35.0, 'drawdown_soft_pct': 5.0,
            'drawdown_hard_pct': 12.0}

def _n(v, name, minimum=0.0):
    try: x = float(v)
    except (TypeError, ValueError, OverflowError): raise ValueError(f'{name} نامعتبر است')
    if not math.isfinite(x) or x < minimum: raise ValueError(f'{name} نامعتبر است')
    return x

def analyze_paper_portfolio(positions, *, equity=1000.0, peak_equity=None, settings=None):
    if not isinstance(positions, list): raise ValueError('positions باید فهرست باشد')
    cfg = dict(DEFAULTS); cfg.update(settings or {})
    equity = _n(equity, 'equity', 0.01)
    peak = _n(equity if peak_equity is None else peak_equity, 'peak_equity', equity)
    dd = max(0.0, (peak-equity)/peak*100.0)
    gross = risk = 0.0; symbols = {}; groups = {}; seen = set(); duplicates = []; invalid = []
    for i, p in enumerate(positions):
        if not isinstance(p, dict): invalid.append({'index': i, 'reason': 'position نامعتبر'}); continue
        symbol = str(p.get('symbol') or '').upper().strip()
        market = str(p.get('market') or 'SPOT').upper().strip()
        side = str(p.get('side') or 'LONG').upper().strip()
        if not symbol: invalid.append({'index': i, 'reason': 'symbol ناموجود'}); continue
        key = (symbol, market, side)
        if key in seen: duplicates.append({'symbol':symbol,'market':market,'side':side,'index':i})
        seen.add(key)
        try:
            notional = _n(p.get('notional_usdt', 0), 'notional_usdt')
            stop_risk = _n(p.get('stop_risk_usdt', 0), 'stop_risk_usdt')
        except ValueError as exc: invalid.append({'index':i,'reason':str(exc)}); continue
        gross += notional; risk += stop_risk
        symbols[symbol] = symbols.get(symbol, 0.0) + notional
        group = str(p.get('correlation_group') or symbol)
        groups[group] = groups.get(group, 0.0) + notional
    gross_pct = gross/equity*100; risk_pct = risk/equity*100
    soft = _n(cfg['drawdown_soft_pct'],'drawdown_soft_pct',0.000001)
    hard = _n(cfg['drawdown_hard_pct'],'drawdown_hard_pct',soft)
    if dd >= hard: factor, dd_state = 0.0, 'HARD_DRAWDOWN_BREACH'
    elif dd >= soft: factor, dd_state = max(0.0, 1-(dd-soft)/(hard-soft)), 'REDUCED_RISK'
    else: factor, dd_state = 1.0, 'NORMAL'
    blockers=[]
    if len(positions) > int(cfg['max_positions']): blockers.append('MAX_OPEN_POSITIONS_EXCEEDED')
    if gross_pct > _n(cfg['max_gross_exposure_pct'],'max_gross_exposure_pct'): blockers.append('GROSS_EXPOSURE_LIMIT_EXCEEDED')
    if risk_pct > _n(cfg['max_portfolio_stop_risk_pct'],'max_portfolio_stop_risk_pct'): blockers.append('PORTFOLIO_STOP_RISK_LIMIT_EXCEEDED')
    if duplicates: blockers.append('DUPLICATE_OPEN_POSITION')
    if invalid: blockers.append('INVALID_POSITION_DATA')
    if dd_state == 'HARD_DRAWDOWN_BREACH': blockers.append('HARD_DRAWDOWN_BREACH')
    sym_cap=_n(cfg['max_symbol_exposure_pct'],'max_symbol_exposure_pct'); grp_cap=_n(cfg['max_group_exposure_pct'],'max_group_exposure_pct')
    concentration = [{'symbol':k,'notional_usdt':round(v,8),'exposure_pct':round(v/equity*100,4),'over_limit':v/equity*100>sym_cap} for k,v in sorted(symbols.items())]
    correlated = [{'group':k,'notional_usdt':round(v,8),'exposure_pct':round(v/equity*100,4),'over_limit':v/equity*100>grp_cap} for k,v in sorted(groups.items())]
    if any(x['over_limit'] for x in concentration): blockers.append('SINGLE_SYMBOL_CONCENTRATION')
    if any(x['over_limit'] for x in correlated): blockers.append('CORRELATED_GROUP_CONCENTRATION')
    return {'version':'23.0.67','equity_usdt':round(equity,8),'peak_equity_usdt':round(peak,8),'drawdown_pct':round(dd,4),'drawdown_state':dd_state,'future_risk_budget_multiplier':round(factor,4),'open_positions':len(positions),'gross_exposure_usdt':round(gross,8),'gross_exposure_pct':round(gross_pct,4),'aggregate_stop_risk_usdt':round(risk,8),'aggregate_stop_risk_pct':round(risk_pct,4),'symbol_concentration':concentration,'correlated_exposure':correlated,'duplicates':duplicates,'invalid_positions':invalid,'blockers':sorted(set(blockers)),'portfolio_status':'BLOCKED' if blockers else ('CAUTION' if dd_state!='NORMAL' else 'WITHIN_CONFIGURED_LIMITS'),'read_only':True,'paper_only':True,'creates_orders':False,'execution_authorized':False,'real_orders_enabled':False}
