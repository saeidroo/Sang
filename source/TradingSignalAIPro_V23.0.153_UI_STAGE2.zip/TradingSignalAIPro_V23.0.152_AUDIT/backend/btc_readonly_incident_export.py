"""Portable incident evidence export and optional external Witness anchoring."""
from __future__ import annotations
import hashlib, json, os, tempfile, urllib.parse, urllib.request, zipfile
from datetime import datetime, timezone
from pathlib import Path
from backend.btc_live_environment_validation import _canonical
from backend.btc_readonly_incidents import verify_incident_log
from backend.witness_server import digest_anchor, verify_anchor_record
from backend.witness_remote import _validate_endpoint

SCHEMA='tekar.btc4h.readonly_incident_export.v1'
MAX_BUNDLE_BYTES=16*1024*1024


def build_incident_export_bundle(*, log_path, output_path):
    log=Path(log_path).expanduser()
    state=verify_incident_log(log)
    raw=log.read_bytes() if log.exists() else b''
    payload={'schema_version':SCHEMA,'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'incident_log_sha256':hashlib.sha256(raw).hexdigest(),'event_count':state['event_count'],
        'head_sha256':state['head_sha256'],'active_incidents':state['active_incidents'],
        'scope':'read_only_btc_4h_incident_audit','training_allowed':False,'live_orders':False}
    manifest={**payload,'manifest_sha256':hashlib.sha256(_canonical(payload)).hexdigest()}
    out=Path(output_path).expanduser(); out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists(): raise FileExistsError('incident_export_destination_exists')
    fd,tmp_name=tempfile.mkstemp(prefix=out.name+'.',suffix='.tmp',dir=str(out.parent)); os.close(fd)
    tmp=Path(tmp_name)
    try:
        with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
            z.writestr('manifest.json',_canonical(manifest)+b'\n')
            z.writestr('incidents.jsonl',raw)
        if tmp.stat().st_size>MAX_BUNDLE_BYTES: raise ValueError('incident_export_bundle_too_large')
        with tmp.open('rb') as f: os.fsync(f.fileno())
        os.link(tmp,out)
    finally:
        try: tmp.unlink()
        except FileNotFoundError: pass
    return {'created':True,'path':str(out),'bytes':out.stat().st_size,
        'bundle_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
        'manifest_sha256':manifest['manifest_sha256'],'event_count':state['event_count'],
        'head_sha256':state['head_sha256']}


def verify_incident_export_bundle(path):
    p=Path(path)
    if p.is_symlink() or not p.is_file() or p.stat().st_size>MAX_BUNDLE_BYTES:
        raise ValueError('incident_export_file_invalid')
    with zipfile.ZipFile(p,'r') as z:
        names=z.namelist()
        if len(names)!=2 or set(names)!={'manifest.json','incidents.jsonl'}: raise ValueError('incident_export_file_set_invalid')
        manifest=json.loads(z.read('manifest.json')); raw=z.read('incidents.jsonl')
    payload=dict(manifest); declared=payload.pop('manifest_sha256',None)
    if not isinstance(declared,str) or hashlib.sha256(_canonical(payload)).hexdigest()!=declared:
        raise ValueError('incident_export_manifest_hash_mismatch')
    if manifest.get('schema_version')!=SCHEMA or manifest.get('training_allowed') is not False or manifest.get('live_orders') is not False:
        raise ValueError('incident_export_schema_or_safety_invalid')
    if hashlib.sha256(raw).hexdigest()!=manifest.get('incident_log_sha256'):
        raise ValueError('incident_export_log_hash_mismatch')
    # Validate the chain without extracting untrusted archive paths.
    from backend.btc_readonly_incidents import verify_incident_log_bytes
    state=verify_incident_log_bytes(raw)
    if state['event_count']!=manifest.get('event_count') or state['head_sha256']!=manifest.get('head_sha256'):
        raise ValueError('incident_export_chain_summary_mismatch')
    return {'valid':True,'manifest':manifest,'event_count':state['event_count'],
        'head_sha256':state['head_sha256'],'bundle_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}


def submit_incident_bundle_to_witness(bundle_path, *, endpoint, bearer_token,
        pinned_public_key_path, timeout=15, post_json=None):
    """Anchor only bundle digests; bearer token is never persisted or returned."""
    if not isinstance(bearer_token,str) or not bearer_token or len(bearer_token)>4096:
        raise ValueError('witness_bearer_token_invalid')
    _validate_endpoint(endpoint)
    verified=verify_incident_export_bundle(bundle_path)
    manifest=verified['manifest']
    anchor={'schema_version':'ts-ai-readonly-incident-anchor-v1',
        'bundle_sha256':verified['bundle_sha256'],'manifest_sha256':manifest['manifest_sha256'],
        'incident_log_sha256':manifest['incident_log_sha256'],'incident_head_sha256':manifest['head_sha256'],
        'event_count':manifest['event_count'],'scope':'read_only_btc_4h_incident_audit',
        'training_allowed':False,'live_orders':False}
    payload={'schema_version':'ts-ai-external-witness-v1','anchor':anchor,'anchor_digest':digest_anchor(anchor)}
    if post_json is None:
        url=endpoint.rstrip('/')+'/v1/anchors'
        req=urllib.request.Request(url,data=json.dumps(payload,separators=(',',':')).encode(),
            headers={'Authorization':'Bearer '+bearer_token,'Accept':'application/json','Content-Type':'application/json'},method='POST')
        with urllib.request.urlopen(req,timeout=timeout) as response:
            if response.status!=200: raise RuntimeError(f'witness_http_status:{response.status}')
            raw=response.read(65537)
            if len(raw)>65536: raise ValueError('witness_receipt_too_large')
            receipt=json.loads(raw.decode('utf-8'))
    else:
        receipt=post_json(endpoint,payload,bearer_token,timeout)
    if receipt.get('anchor_digest')!=payload['anchor_digest']:
        raise ValueError('witness_receipt_anchor_digest_mismatch')
    verify_anchor_record(receipt,pinned_public_key_path)
    return {'anchored':True,'anchor_digest':payload['anchor_digest'],
        'witness_sequence':receipt.get('sequence'),'witness_id':receipt.get('witness_id'),
        'duplicate':bool(receipt.get('duplicate',False)),'signature_verified':True,
        'training_allowed':False,'live_orders':False}
