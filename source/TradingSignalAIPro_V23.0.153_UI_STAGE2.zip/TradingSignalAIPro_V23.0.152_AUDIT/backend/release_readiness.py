"""Read-only release and production-readiness checks for V22.2w.

This is a configuration preflight, not a penetration test or deployment attestation.
It deliberately reports secret presence only; secret values are never returned.
"""
from __future__ import annotations
import importlib.metadata
import importlib.util
import os
import platform
import sys
from pathlib import Path
from typing import Mapping

REQUIRED_MODULES = ("flask", "requests", "numpy", "pandas", "sklearn", "joblib", "cryptography")
OPTIONAL_MODULES = ("xgboost", "lightgbm", "gymnasium", "stable_baselines3", "finrl", "webview")


def _module_inventory(names):
    result = []
    for name in names:
        installed = importlib.util.find_spec(name) is not None
        dist_name = {"sklearn": "scikit-learn", "webview": "pywebview", "stable_baselines3": "stable-baselines3"}.get(name, name)
        try:
            version = importlib.metadata.version(dist_name) if installed else None
        except importlib.metadata.PackageNotFoundError:
            version = "installed-version-unknown" if installed else None
        result.append({"module": name, "installed": installed, "version": version})
    return result


def production_readiness(env: Mapping[str, str] | None = None, *, private_key_path: str | None = None,
                         trusted_source_key_path: str | None = None, db_path: str | None = None,
                         host: str | None = None) -> dict:
    """Return deterministic checks; status is BLOCKED, WARN or READY."""
    e = os.environ if env is None else env
    required = _module_inventory(REQUIRED_MODULES)
    optional = _module_inventory(OPTIONAL_MODULES)
    checks = []

    def add(name, passed, severity="block", detail=""):
        checks.append({"name": name, "passed": bool(passed), "severity": severity,
                       "detail": detail if detail else ("ok" if passed else "not_configured_or_failed")})

    add("python_supported", sys.version_info >= (3, 10), detail=f"python={platform.python_version()}")
    missing = [x["module"] for x in required if not x["installed"]]
    add("required_dependencies", not missing, detail="all_required_modules_installed" if not missing else "missing=" + ",".join(missing))
    add("api_token_present", bool(e.get("TS_WITNESS_API_TOKEN", "").strip() or e.get("TS_WITNESS_API_TOKEN_FILE", "").strip()), detail="secret_value_not_inspected")
    token_file = e.get("TS_WITNESS_API_TOKEN_FILE", "").strip()
    if token_file:
        p = Path(token_file)
        add("api_token_file_readable", p.is_file() and os.access(p, os.R_OK), detail="path_presence_only")
        if p.is_file() and os.name != "nt":
            add("api_token_file_permissions", (p.stat().st_mode & 0o077) == 0, detail="must_not_be_group_or_world_accessible")
    else:
        add("api_token_file_permissions", False, severity="warn", detail="token_file_not_used; protect environment secret externally")

    priv = Path(private_key_path or e.get("TS_WITNESS_PRIVATE_KEY", "witness-keys/witness-private.pem"))
    trust = Path(trusted_source_key_path or e.get("TS_WITNESS_TRUSTED_SOURCE_PUBLIC_KEY", "")) if (trusted_source_key_path or e.get("TS_WITNESS_TRUSTED_SOURCE_PUBLIC_KEY")) else None
    add("signing_private_key_present", priv.is_file(), detail="private_key_path_presence_only")
    if priv.is_file() and os.name != "nt":
        add("signing_private_key_permissions", (priv.stat().st_mode & 0o077) == 0, detail="must_not_be_group_or_world_accessible")
    else:
        add("signing_private_key_permissions", False, severity="warn", detail="cannot_verify_permissions")
    add("trusted_source_key_present", bool(trust and trust.is_file()), detail="required_for_remote_replication")
    endpoint = e.get("TS_WITNESS_REMOTE_ENDPOINT", "").strip()
    add("remote_endpoint_https", not endpoint or endpoint.lower().startswith("https://"), detail="https_required_when_remote_endpoint_is_configured")
    bind = host or e.get("TS_WITNESS_HOST", "127.0.0.1")
    add("service_bind_loopback_or_proxy", bind in ("127.0.0.1", "::1", "localhost"), severity="warn",
        detail="loopback_bind_ok" if bind in ("127.0.0.1", "::1", "localhost") else "non_loopback_bind_requires_verified_tls_proxy_firewall_and_mtls")
    add("debug_disabled_by_launcher", True, severity="warn", detail="launcher_uses_debug_false; verify production process manager")
    add("database_path_configured", bool(db_path or e.get("TS_WITNESS_DB")), severity="warn", detail="persistent_storage_path_should_be_explicit")
    failed_block = [c["name"] for c in checks if not c["passed"] and c["severity"] == "block"]
    failed_warn = [c["name"] for c in checks if not c["passed"] and c["severity"] == "warn"]
    status = "BLOCKED" if failed_block else ("WARN" if failed_warn else "READY")
    return {"schema_version": "v22.2w-readiness-v1", "application_version": "22.2.21",
            "status": status, "checks": checks, "required_dependencies": required,
            "optional_dependencies": optional, "failed_blocking_checks": failed_block,
            "warnings": failed_warn,
            "scope_note": "Read-only preflight only; not a penetration test, TLS handshake test, multi-host validation, or trading approval."}
