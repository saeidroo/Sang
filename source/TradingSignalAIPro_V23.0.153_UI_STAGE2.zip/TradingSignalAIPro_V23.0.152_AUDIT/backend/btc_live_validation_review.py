"""Independent ingestion and operator review of live-environment evidence."""
from __future__ import annotations
import hashlib, json, os, re
from datetime import datetime, timezone
from pathlib import Path
from backend.btc_live_environment_validation import _canonical, verify_live_environment_report

_HEX64 = re.compile(r'^[0-9a-f]{64}$')


def _parse_utc(value):
    if not isinstance(value, str):
        raise ValueError('live_report_timestamp_missing')
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    except ValueError as exc:
        raise ValueError('live_report_timestamp_invalid') from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError('live_report_timestamp_not_timezone_aware')
    return parsed.astimezone(timezone.utc)


def load_live_validation_report(path, *, max_bytes=2 * 1024 * 1024, max_age_hours=24, now_utc=None):
    source = Path(path).expanduser()
    if source.is_symlink() or not source.is_file():
        raise ValueError('live_report_path_not_regular_file')
    raw = source.read_bytes()
    if len(raw) > max_bytes:
        raise ValueError('live_report_too_large')
    try:
        report = json.loads(raw.decode('utf-8'))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError('live_report_json_invalid') from exc
    verify_live_validation_evidence(report, now_utc=now_utc, max_age_hours=max_age_hours)
    return report


def verify_live_validation_evidence(report, *, now_utc=None, max_age_hours=24):
    verify_live_environment_report(report)
    created = _parse_utc(report.get('created_at_utc'))
    now = now_utc or datetime.now(timezone.utc)
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError('review_clock_not_timezone_aware')
    age = (now.astimezone(timezone.utc) - created).total_seconds() / 3600
    if age < -0.05:
        raise ValueError('live_report_timestamp_in_future')
    if age > max_age_hours:
        raise ValueError('live_report_stale')
    env = report.get('environment')
    if not isinstance(env, dict):
        raise ValueError('live_report_environment_missing')
    env_payload = dict(env)
    env_hash = env_payload.pop('sha256', None)
    if not isinstance(env_hash, str) or hashlib.sha256(_canonical(env_payload)).hexdigest() != env_hash:
        raise ValueError('live_report_environment_fingerprint_mismatch')
    if report.get('request', {}).get('symbol') != 'BTCUSDT' or report.get('request', {}).get('timeframe') != '4h':
        raise ValueError('live_report_market_contract_mismatch')
    cross = report.get('cross_source')
    if report.get('status') == 'PASS':
        if not isinstance(cross, dict) or cross.get('status') != 'PASS':
            raise ValueError('live_report_pass_without_cross_source_pass')
        if cross.get('read_only') is not True or cross.get('training_allowed') is not False or cross.get('live_orders') is not False:
            raise ValueError('live_report_cross_source_safety_flags_invalid')
        if cross.get('selected_source') != 'Binance' or cross.get('fallback_used') is not False:
            raise ValueError('live_report_source_selection_invalid')
        reconciliation = cross.get('reconciliation')
        if not isinstance(reconciliation, dict) or reconciliation.get('status') != 'PASS':
            raise ValueError('live_report_reconciliation_not_passed')
        if isinstance(reconciliation.get('compared_candles'), bool) or not isinstance(reconciliation.get('compared_candles'), int) or reconciliation['compared_candles'] < 2:
            raise ValueError('live_report_reconciliation_coverage_invalid')
        for key in ('primary_sha256', 'backup_sha256'):
            if not isinstance(reconciliation.get(key), str) or not _HEX64.fullmatch(reconciliation[key]):
                raise ValueError('live_report_source_digest_invalid')
    elif report.get('status') not in ('DEGRADED', 'BLOCKED'):
        raise ValueError('live_report_status_invalid')
    return {'valid': True, 'status': report['status'], 'age_hours': round(age, 4),
            'report_sha256': report['report_sha256']}


def review_live_validation_reports(paths, *, operator_approved=False, min_pass_runs=3,
                                   max_age_hours=24, now_utc=None):
    if isinstance(min_pass_runs, bool) or not isinstance(min_pass_runs, int) or min_pass_runs < 2:
        raise ValueError('minimum_pass_runs_must_be_at_least_two')
    reports = [load_live_validation_report(p, max_age_hours=max_age_hours, now_utc=now_utc) if not isinstance(p, dict) else p for p in paths]
    if not reports:
        raise ValueError('no_live_validation_reports')
    checks = [verify_live_validation_evidence(r, now_utc=now_utc, max_age_hours=max_age_hours) for r in reports]
    digests = [r['report_sha256'] for r in reports]
    if len(set(digests)) != len(digests):
        raise ValueError('duplicate_live_validation_report')
    times = [_parse_utc(r['created_at_utc']) for r in reports]
    if times != sorted(times) or len(set(times)) != len(times):
        raise ValueError('live_validation_reports_not_strictly_chronological')
    pass_count = sum(1 for r in reports if r.get('status') == 'PASS')
    all_pass = pass_count == len(reports)
    if not all_pass:
        decision = 'BLOCKED'
    elif pass_count < min_pass_runs or not operator_approved:
        decision = 'REVIEW_REQUIRED'
    else:
        decision = 'ACCEPT_READONLY'
    result = {
        'schema': 'tekar.btc4h.live_validation_operator_review.v1',
        'created_at_utc': (now_utc or datetime.now(timezone.utc)).isoformat(),
        'decision': decision,
        'report_count': len(reports),
        'pass_count': pass_count,
        'min_pass_runs': min_pass_runs,
        'operator_approved': operator_approved is True,
        'report_digests': digests,
        'verification': checks,
        'training_allowed': False,
        'paper_execution_allowed': False,
        'live_orders': False,
    }
    result['review_sha256'] = hashlib.sha256(_canonical(result)).hexdigest()
    return result


def verify_live_validation_review(review):
    if not isinstance(review, dict):
        raise ValueError('live_validation_review_invalid')
    payload = dict(review)
    supplied = payload.pop('review_sha256', None)
    actual = hashlib.sha256(_canonical(payload)).hexdigest()
    if supplied != actual:
        raise ValueError('live_validation_review_hash_mismatch')
    if review.get('decision') not in ('ACCEPT_READONLY', 'REVIEW_REQUIRED', 'BLOCKED'):
        raise ValueError('live_validation_review_decision_invalid')
    if review.get('training_allowed') is not False or review.get('live_orders') is not False:
        raise ValueError('live_validation_review_safety_flags_invalid')
    if review['decision'] == 'ACCEPT_READONLY' and not (review.get('operator_approved') is True and review.get('pass_count', 0) >= review.get('min_pass_runs', 3) and review.get('pass_count') == review.get('report_count')):
        raise ValueError('live_validation_acceptance_gate_invalid')
    return {'valid': True, 'decision': review['decision'], 'sha256': actual}


def save_live_validation_review(review, *, output_path):
    verify_live_validation_review(review)
    path = Path(output_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = _canonical(review) + b'\n'
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    return {'saved': True, 'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
            'decision': review['decision'], 'training_allowed': False, 'live_orders': False}
