"""V19 — Market memory: the brain remembers its past analyses per market.

Every /api/analyze stores a compact snapshot (signal, score, levels, regime,
price). Later analyses mature the older snapshots against real closes at the
12-bar horizon (the same honest horizon the training labels use) and expose:

- ``latest``     : the previous snapshot + a "what changed" diff,
- ``stats``      : matured decision outcomes (directional hit-rate, average
                   return) computed only from bars that ACTUALLY matured,
- ``timeline``   : the recent decision history for the analyst report.

No fabrication rule: snapshots whose horizon bar is missing from the supplied
frame stay pending forever instead of being measured at an arbitrary price.
"""
from __future__ import annotations

import json
import math
import os
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

HORIZON_BARS = 12
TF_MS = {'5m': 5 * 60_000, '15m': 15 * 60_000, '30m': 30 * 60_000, '1h': 60 * 60_000,
         '4h': 4 * 60 * 60_000, '1d': 24 * 60 * 60_000}
MAX_TIMELINE = 400


def _db_path() -> Path:
    raw = os.getenv('TS_AI_MEMORY_DB')
    path = Path(raw).expanduser() if raw else (
        Path.home() / '.trading_ai_models' / 'analysis_memory.sqlite3')
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(), timeout=10)
    conn.execute('''CREATE TABLE IF NOT EXISTS analysis_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        symbol TEXT NOT NULL,
        timeframe TEXT NOT NULL,
        bar_ts INTEGER NOT NULL,
        created_at REAL NOT NULL,
        price REAL NOT NULL,
        signal_kind TEXT NOT NULL,
        brain_decision TEXT,
        score REAL,
        power REAL,
        prob REAL,
        tp REAL,
        sl REAL,
        regime TEXT,
        setup TEXT,
        components_json TEXT,
        realized_return REAL,
        UNIQUE(symbol, timeframe, bar_ts)
    )''')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_memory_outcomes '
                 'ON analysis_snapshots(symbol,timeframe,realized_return,bar_ts)')
    return conn


@contextmanager
def _connection():
    conn = _connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _finite(value: Any) -> float | None:
    try:
        x = float(value)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def save_snapshot(symbol: str, timeframe: str, bar_ts: int, price: float,
                  signal: dict, brain: dict | None, regime: dict | None = None,
                  components: dict | None = None) -> bool:
    """Store one analysis snapshot. Idempotent per (symbol, timeframe, bar_ts)."""
    if timeframe not in TF_MS:
        return False
    p = _finite(price)
    if p is None or p <= 0:
        return False
    signal = signal or {}
    kind = str(signal.get('kind', 'HOLD'))
    scores = {str(k): _finite(v) for k, v in (components or {}).items()
              if _finite(v) is not None}
    try:
        with _connection() as conn:
            cur = conn.execute('''INSERT OR IGNORE INTO analysis_snapshots
                (symbol,timeframe,bar_ts,created_at,price,signal_kind,brain_decision,
                 score,power,prob,tp,sl,regime,setup,components_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (str(symbol), str(timeframe), int(bar_ts), time.time(), p, kind,
                 str((brain or {}).get('decision') or signal.get('kind', 'HOLD')),
                 _finite((brain or {}).get('score')),
                 _finite(signal.get('power')),
                 _finite(signal.get('prob')),
                 _finite(signal.get('tp')), _finite(signal.get('sl')),
                 str((regime or {}).get('regime') or ''),
                 str((signal.get('scenario') or {}).get('setup') or ''),
                 json.dumps(scores, separators=(',', ':'), sort_keys=True)))
            return cur.rowcount == 1
    except Exception:
        return False


def mature_snapshots(symbol: str, timeframe: str, market_frame: pd.DataFrame) -> int:
    """Close pending snapshots whose exact horizon close exists in the frame."""
    step = TF_MS.get(timeframe)
    if not step or not isinstance(market_frame, pd.DataFrame) or market_frame.empty:
        return 0
    if not {'t', 'close'}.issubset(market_frame.columns):
        return 0
    frame = market_frame[['t', 'close']].copy()
    frame['t'] = pd.to_numeric(frame['t'], errors='coerce')
    frame['close'] = pd.to_numeric(frame['close'], errors='coerce')
    frame = frame.replace([np.inf, -np.inf], np.nan).dropna().sort_values('t')
    prices = {int(t): float(c) for t, c in zip(frame['t'], frame['close']) if float(c) > 0}
    if not prices:
        return 0
    with _connection() as conn:
        rows = conn.execute('''SELECT id,bar_ts,price FROM analysis_snapshots
            WHERE symbol=? AND timeframe=? AND realized_return IS NULL''',
            (str(symbol), str(timeframe))).fetchall()
        changed = 0
        for row_id, bar_ts, entry in rows:
            target = prices.get(int(bar_ts) + step * HORIZON_BARS)
            if target is None or not entry or entry <= 0:
                continue
            ret = target / float(entry) - 1.0
            conn.execute('UPDATE analysis_snapshots SET realized_return=? '
                         'WHERE id=? AND realized_return IS NULL',
                         (float(ret), int(row_id)))
            changed += 1
    return changed


def _direction_of(kind: str) -> int:
    return 1 if kind == 'BUY' else -1 if kind == 'SELL' else 0


def memory_report(symbol: str, timeframe: str, current_price: float | None = None,
                  timeline_limit: int = 10) -> dict:
    """Everything the UI/report needs: latest snapshot, diff and honest stats."""
    out = {'available': False, 'database': str(_db_path()),
           'horizon_bars': HORIZON_BARS}
    try:
        with _connection() as conn:
            rows = conn.execute('''SELECT bar_ts,created_at,price,signal_kind,brain_decision,
                 score,power,prob,tp,sl,regime,setup,realized_return
                 FROM analysis_snapshots WHERE symbol=? AND timeframe=?
                 ORDER BY bar_ts DESC LIMIT ?''',
                (str(symbol), str(timeframe), MAX_TIMELINE)).fetchall()
    except Exception as exc:
        out['error'] = str(exc)[:160]
        return out
    if not rows:
        out['note'] = 'برای این بازار هنوز تحلیلی در حافظه ثبت نشده است.'
        return out
    out['available'] = True
    (bar_ts, created_at, price, kind, decision, score, power, prob,
     tp, sl, regime, setup, realized) = rows[0]
    latest = {'bar_ts': int(bar_ts), 'created_at': float(created_at),
              'price': _finite(price), 'signal_kind': kind,
              'brain_decision': decision, 'score': _finite(score),
              'power': _finite(power), 'prob': _finite(prob),
              'tp': _finite(tp), 'sl': _finite(sl),
              'regime': regime or '', 'setup': setup or '',
              'realized_return': _finite(realized)}
    diff = {}
    if current_price is not None and _finite(price):
        cur = _finite(current_price)
        if cur and price and price > 0:
            diff['price_change_pct'] = round((cur / float(price) - 1.0) * 100.0, 4)
    # Matured outcome stats — only closed, non-zero outcomes count. Returns are
    # signed by signal direction so SELL rows report the SELL's own PnL.
    matured = [(k, r) for (_, _, _, k, _, _, _, _, _, _, _, _, r) in rows
               if r is not None and _finite(r) is not None and abs(float(r)) > 0.0002]
    trade_rows = [(k, _direction_of(k) * float(r)) for (k, r) in matured
                  if _direction_of(k) != 0]
    n_trades = len(trade_rows)
    wins = sum(1 for _, signed in trade_rows if signed > 0)
    total_ret = sum(signed for _, signed in trade_rows)
    out.update({
        'latest': latest,
        'diff': diff,
        'snapshots': len(rows),
        'stats': {
            'matured_trades': n_trades,
            'directional_wins': wins,
            'directional_hit_rate': round(wins / n_trades, 4) if n_trades else None,
            'sum_return_pct': round(total_ret * 100.0, 4) if n_trades else None,
            'avg_return_pct': round(total_ret / n_trades * 100.0, 4) if n_trades else None,
            'note': ('آمار فقط از تحلیل‌هایی که افق ۱۲ کندلی‌شان با قیمت واقعی بسته شده '
                     'محاسبه می‌شود؛ بدون حدس زدن.' if n_trades
                     else 'هنوز هیچ تحلیل این بازار به افق ۱۲ کندلی نرسیده است.'),
        },
        'timeline': [{'bar_ts': int(r[0]), 'signal_kind': r[3], 'score': _finite(r[5]),
                      'price': _finite(r[2]), 'realized_return': _finite(r[12])}
                     for r in rows[:max(1, min(20, timeline_limit))]],
    })
    return out
