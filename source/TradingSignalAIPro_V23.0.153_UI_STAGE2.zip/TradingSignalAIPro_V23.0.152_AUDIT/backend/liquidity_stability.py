"""In-process rolling liquidity persistence tracker; advisory only."""
from __future__ import annotations
import threading, time
from collections import defaultdict, deque

class LiquidityStabilityTracker:
    def __init__(self, max_samples=12, min_interval_seconds=900, required_samples=3, min_span_seconds=1800):
        self.max_samples = max_samples
        self.min_interval_seconds = min_interval_seconds
        self.required_samples = required_samples
        self.min_span_seconds = min_span_seconds
        self._samples = defaultdict(lambda: deque(maxlen=max_samples))
        self._lock = threading.Lock()

    def record(self, exchange: str, symbol: str, quote_volume: float, timestamp: float | None = None) -> dict:
        now = time.time() if timestamp is None else float(timestamp)
        try: volume = float(quote_volume)
        except (TypeError, ValueError): volume = -1
        if not exchange or not symbol or volume < 0:
            return {'status': 'invalid_snapshot', 'stable': False, 'entry_ready': False}
        key = (str(exchange).lower(), str(symbol).upper())
        with self._lock:
            q = self._samples[key]
            if q and now <= q[-1][0]:
                return {'status': 'out_of_order_snapshot', 'stable': False, 'entry_ready': False,
                        'samples': len(q)}
            if q and now - q[-1][0] < self.min_interval_seconds:
                return {'status': 'sample_too_soon', 'stable': False, 'entry_ready': False,
                        'samples': len(q), 'next_sample_after': q[-1][0] + self.min_interval_seconds}
            q.append((now, volume))
            samples = list(q)
        span = samples[-1][0] - samples[0][0] if len(samples) > 1 else 0
        values = [v for _, v in samples]
        enough = len(samples) >= self.required_samples and span >= self.min_span_seconds
        positive = [v for v in values if v > 0]
        median = sorted(positive)[len(positive)//2] if positive else 0
        floor_ratio = min(values) / median if median > 0 else 0
        stable = bool(enough and median >= 100_000 and floor_ratio >= 0.35)
        status = 'liquidity_stable_observed' if stable else 'insufficient_observations' if not enough else 'liquidity_unstable'
        return {'status': status, 'stable': stable, 'samples': len(samples),
                'observation_span_seconds': int(span), 'median_quote_volume': round(median, 2),
                'minimum_to_median_ratio': round(floor_ratio, 3), 'entry_ready': False,
                'advice': 'پایداری نسبی گردش در چند مشاهده دیده شده؛ این معیار تضمین عمق دفتر سفارش یا امکان اجرای معامله نیست.' if stable else
                          'پایداری نقدشوندگی هنوز تأیید نشده؛ مشاهده‌های بیشتری لازم است.'}


TRACKER = LiquidityStabilityTracker()
