"""V23.0.136 evidence-based pump/dump trap detector (read-only, paper-only)."""
from __future__ import annotations
import math


def _n(v):
    if isinstance(v, bool) or v is None:
        return None
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError, OverflowError):
        return None


def _valid_candles(candles):
    parsed = []
    for candle in candles:
        if not isinstance(candle, dict):
            continue
        row = {k: _n(candle.get(k)) for k in ('open', 'high', 'low', 'close', 'volume')}
        if (all(row[k] is not None for k in ('open', 'high', 'low', 'close'))
                and row['high'] >= max(row['open'], row['close'])
                and row['low'] <= min(row['open'], row['close'])
                and row['high'] >= row['low']):
            parsed.append(row)
    return parsed


def detect_market_traps(candidates):
    if not isinstance(candidates, list):
        raise ValueError('candidates must be a list')
    out = []
    for c in candidates[:100]:
        if not isinstance(c, dict):
            out.append({'decision': 'INSUFFICIENT_DATA', 'score': 0, 'reasons': ['INVALID_CANDIDATE'],
                        'entry_authorized': False, 'execution_authorized': False})
            continue
        symbol = str(c.get('symbol') or '').upper().strip()
        direction = str(c.get('direction') or '').lower()
        if direction not in ('long', 'short'):
            direction = 'unknown'
        reasons, evidence = [], {}
        score = 0
        bull = bear = False
        candles = c.get('candles')
        if not isinstance(candles, list) or not candles or len(candles) > 500:
            candles = []
        parsed = _valid_candles(candles)
        if len(parsed) < 2:
            reasons.append('INSUFFICIENT_VALID_CANDLES')
        else:
            cur, prev = parsed[-1], parsed[-2]
            sh, sl = _n(c.get('swing_high')), _n(c.get('swing_low'))
            # Sweep + close back through the level is a candidate, not proof.
            bull_sweep = sl is not None and sl > 0 and cur['low'] < sl and cur['close'] > sl
            bear_sweep = sh is not None and sh > 0 and cur['high'] > sh and cur['close'] < sh
            if bull_sweep:
                bull = True; score += 30
                evidence['sell_side_liquidity_sweep'] = True
            if bear_sweep:
                bear = True; score += 30
                evidence['buy_side_liquidity_sweep'] = True
            if sh is not None and sh > 0 and cur['close'] > sh:
                evidence['upside_breakout_close'] = True
            if sl is not None and sl > 0 and cur['close'] < sl:
                evidence['downside_breakdown_close'] = True

            # A second candle is required to upgrade a wick/reclaim into a stronger
            # trap confirmation. This avoids treating a single long wick as proof.
            if len(parsed) >= 3:
                before = parsed[-3]
                if (sh is not None and sh > 0 and before['high'] > sh
                        and before['close'] < sh and cur['close'] < before['close']):
                    bear = True; score += 25
                    evidence['bull_trap_follow_through'] = True
                if (sl is not None and sl > 0 and before['low'] < sl
                        and before['close'] > sl and cur['close'] > before['close']):
                    bull = True; score += 25
                    evidence['bear_trap_follow_through'] = True

            volumes = [x['volume'] for x in parsed[:-1] if x['volume'] is not None and x['volume'] > 0]
            if cur['volume'] is not None and volumes:
                baseline = sorted(volumes[-20:])[len(volumes[-20:]) // 2]
                if baseline > 0:
                    vr = cur['volume'] / baseline
                    evidence['volume_ratio_vs_median'] = round(vr, 4)
                    if vr >= 1.5 and (bull or bear):
                        score += 10
                    elif vr < 0.8:
                        reasons.append('LOW_VOLUME_CONFIRMATION')
            if c.get('opposing_choch') is True:
                score += 10; evidence['opposing_choch'] = True
            if c.get('orderflow_divergence') is True:
                score += 10; evidence['orderflow_divergence'] = True
            if c.get('breakout_confirmed') is True:
                evidence['breakout_confirmed'] = True
                # Confirmed continuation conflicts with the corresponding trap thesis.
                if evidence.get('upside_breakout_close') and not bear_sweep:
                    reasons.append('UPSIDE_BREAKOUT_CONTINUATION_RISK')
                if evidence.get('downside_breakdown_close') and not bull_sweep:
                    reasons.append('DOWNSIDE_BREAKDOWN_CONTINUATION_RISK')

        if bull and bear:
            trap, decision = 'CONFLICTING_OR_NONE', 'CONFLICTING_EVIDENCE'
        elif bull:
            trap = 'BEAR_TRAP_CANDIDATE'
            decision = 'WATCH' if score >= 40 else 'LOW_CONFIDENCE'
        elif bear:
            trap = 'BULL_TRAP_CANDIDATE'
            decision = 'WATCH' if score >= 40 else 'LOW_CONFIDENCE'
        else:
            trap = 'NONE'
            decision = 'INSUFFICIENT_DATA' if reasons and 'INSUFFICIENT_VALID_CANDLES' in reasons else 'NO_TRAP_EVIDENCE'
        confirmed = bool(evidence.get('bull_trap_follow_through') or evidence.get('bear_trap_follow_through'))
        out.append({
            'symbol': symbol, 'direction': direction, 'trap_type': trap, 'decision': decision,
            'score': min(score, 100), 'confirmed_by_follow_through': confirmed,
            'evidence': evidence, 'reasons': reasons,
            'entry_authorized': False, 'execution_authorized': False,
        })
    return {
        'version': '23.0.136', 'count': len(out), 'results': out, 'paper_only': True,
        'capital_usdt': 1000, 'entry_authorized': False, 'execution_authorized': False,
        'creates_orders': False, 'real_orders_enabled': False,
        'disclaimer': 'این خروجی فقط نامزد تله را از شواهد کندلی مشخص می‌کند؛ تله یا دستکاری بازار را اثبات نمی‌کند و مجوز معامله نیست.',
    }
