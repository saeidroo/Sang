"""V22.3b: BTC 4h OHLCV integrity and purged walk-forward utilities.

No data is downloaded, repaired, sorted, or imputed here. Callers must supply
chronological candles and explicitly handle WARN/BLOCKED reports.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

VERSION = 'btc-4h-integrity-wf-v1'
FOUR_HOURS_MS = 4 * 60 * 60 * 1000


def validate_btc_4h(candles, *, timestamp='t', outlier_mad_z=12.0,
                    max_gap_bars=0, require_volume=True):
    df = pd.DataFrame(candles).copy()
    required = [timestamp, 'open', 'high', 'low', 'close']
    missing = [c for c in required if c not in df]
    if missing:
        return {'version': VERSION, 'status': 'BLOCKED', 'reasons': ['missing_columns:'+','.join(missing)],
                'row_count': len(df), 'missing_columns': missing}
    for c in required + (['volume'] if 'volume' in df else []):
        df[c] = pd.to_numeric(df[c], errors='coerce')
    reasons, warnings = [], []
    if len(df) < 3:
        reasons.append('insufficient_rows')
    ts = df[timestamp].to_numpy(dtype=float)
    if not np.isfinite(ts).all(): reasons.append('invalid_timestamps')
    elif len(ts) and (np.diff(ts) <= 0).any(): reasons.append('timestamps_not_strictly_increasing_or_duplicate')
    elif len(ts) and (ts.astype(np.int64) % FOUR_HOURS_MS != 0).any(): reasons.append('timestamp_not_aligned_to_4h')
    prices = df[['open','high','low','close']].to_numpy(dtype=float)
    if not np.isfinite(prices).all() or (prices <= 0).any(): reasons.append('invalid_or_nonpositive_prices')
    elif len(prices):
        o,h,l,c = prices.T
        if ((h < np.maximum.reduce([o,c,l])) | (l > np.minimum.reduce([o,c,h]))).any():
            reasons.append('invalid_ohlc_geometry')
    if 'volume' not in df:
        if require_volume: reasons.append('volume_column_missing')
        else: warnings.append('volume_column_missing')
    else:
        v = df['volume'].to_numpy(dtype=float)
        if not np.isfinite(v).all() or (v < 0).any(): reasons.append('invalid_volume')
    gap_count = max_gap = 0
    if len(ts) > 1 and np.isfinite(ts).all():
        steps = np.diff(ts.astype(np.int64)) // FOUR_HOURS_MS - 1
        gaps = steps[steps > 0]
        gap_count, max_gap = int(len(gaps)), int(gaps.max()) if len(gaps) else 0
        if max_gap > int(max_gap_bars): reasons.append(f'gaps_exceed_policy:{max_gap}>{int(max_gap_bars)}')
    outlier_indices = []
    close = df['close'].to_numpy(dtype=float)
    if len(close) > 2 and np.isfinite(close).all() and (close > 0).all():
        logret = np.diff(np.log(close)); med = float(np.median(logret))
        mad = float(np.median(np.abs(logret-med)))
        if mad > 0:
            robust_z = 0.67448975 * np.abs(logret-med) / mad
            outlier_indices = (np.flatnonzero(robust_z > float(outlier_mad_z)) + 1).tolist()
        elif np.any(np.abs(logret-med) > 0):
            outlier_indices = (np.flatnonzero(np.abs(logret-med) > 0) + 1).tolist()
        if outlier_indices: warnings.append('return_outliers_review_required')
    status = 'BLOCKED' if reasons else ('WARN' if warnings else 'PASS')
    return {'version': VERSION, 'symbol': 'BTC', 'timeframe': '4h', 'status': status,
            'row_count': len(df), 'gap_count': gap_count, 'max_gap_bars': max_gap,
            'outlier_indices': outlier_indices, 'warnings': warnings, 'reasons': reasons,
            'policy': {'max_gap_bars': int(max_gap_bars), 'outlier_mad_z': float(outlier_mad_z),
                       'outliers_are_review_flags_not_auto_deletions': True}}


def purged_walk_forward(n_rows, *, n_splits=5, min_train_size=None,
                        validation_size=None, label_horizon_bars=1, embargo_bars=0):
    """Expanding-window folds. Purge train rows whose label horizon touches validation."""
    n = int(n_rows); k = int(n_splits); h = int(label_horizon_bars); e = int(embargo_bars)
    if n < 30 or k < 1 or h < 1 or e < 0: raise ValueError('invalid walk-forward dimensions')
    val = int(validation_size or max(1, n // (k + 2)))
    start0 = int(min_train_size or (n - k * val))
    if start0 < 10 or start0 + k * val > n: raise ValueError('fold sizes do not fit data')
    folds=[]
    for i in range(k):
        vstart = start0 + i*val; vend = min(n, vstart+val)
        train_end = vstart - e - h
        if train_end < 2: raise ValueError('purge/embargo leaves insufficient training rows')
        train_idx = np.arange(0, train_end, dtype=int)
        valid_idx = np.arange(vstart, vend, dtype=int)
        # Each training label ends at position train position + horizon.
        if len(train_idx) and int(train_idx[-1] + h + e) >= vstart:
            raise AssertionError('internal purge invariant failed')
        folds.append({'fold': i+1, 'train_indices': train_idx.tolist(),
                      'validation_indices': valid_idx.tolist(), 'train_count': len(train_idx),
                      'validation_count': len(valid_idx), 'purged_embargoed_count': int(vstart-len(train_idx)),
                      'train_label_end_max': int(train_idx[-1]+h) if len(train_idx) else None,
                      'validation_start': vstart, 'validation_end_exclusive': vend})
    return {'version': VERSION, 'method': 'expanding_window_purged', 'n_rows': n,
            'n_splits': k, 'label_horizon_bars': h, 'embargo_bars': e, 'folds': folds,
            'test_policy': 'Each validation fold is evaluated once; never shuffle or tune on its labels.'}


def assert_4h_contiguous(candles, *, timestamp='t'):
    """Raise unless all timestamps form a strictly increasing contiguous 4h series."""
    df = pd.DataFrame(candles)
    if timestamp not in df: raise ValueError('timestamp column missing')
    ts = pd.to_numeric(df[timestamp], errors='coerce').to_numpy(dtype=float)
    if len(ts) < 2 or not np.isfinite(ts).all(): raise ValueError('timestamps invalid or insufficient')
    if (np.diff(ts) != FOUR_HOURS_MS).any(): raise ValueError('4h series contains duplicate, out-of-order, or missing candles')
    return True


def purged_walk_forward_with_labels(label_end_positions, *, n_splits=5,
                                    min_train_size=None, validation_size=None,
                                    embargo_bars=0):
    """Build expanding folds and purge using each sample's actual label end position."""
    from backend.btc_features import purge_training_indices
    ends = np.asarray(label_end_positions, dtype=int)
    n = len(ends); k = int(n_splits); e = int(embargo_bars)
    if ends.ndim != 1 or n < 30 or k < 1 or e < 0:
        raise ValueError('invalid label-end vector or walk-forward dimensions')
    if np.any((ends < -1) | (ends >= n)):
        raise ValueError('label end positions must be -1 or valid row positions')
    val = int(validation_size or max(1, n // (k + 2)))
    start0 = int(min_train_size or (n-k*val))
    if start0 < 10 or start0 + k*val > n:
        raise ValueError('fold sizes do not fit data')
    folds=[]
    for i in range(k):
        vstart = start0 + i*val; vend = min(n, vstart+val)
        raw_train = np.arange(0, vstart, dtype=int)
        purged = purge_training_indices(raw_train, ends, validation_start=vstart,
                                        embargo_bars=e)
        if len(purged['train_indices']) < 2:
            raise ValueError('actual label-end purge leaves insufficient training rows')
        folds.append({'fold':i+1, 'train_indices':purged['train_indices'],
                      'validation_indices':list(range(vstart,vend)),
                      'train_count':len(purged['train_indices']),
                      'validation_count':vend-vstart,
                      'purged_indices':purged['purged_indices'],
                      'purged_count':purged['purged_count'],
                      'train_label_end_max':purged['max_kept_label_end_pos'],
                      'validation_start':vstart,'validation_end_exclusive':vend})
    return {'version':VERSION,'method':'expanding_window_actual_label_end_purged',
            'n_rows':n,'n_splits':k,'embargo_bars':e,'folds':folds,
            'test_policy':'Validation labels are not included in training indices.'}
