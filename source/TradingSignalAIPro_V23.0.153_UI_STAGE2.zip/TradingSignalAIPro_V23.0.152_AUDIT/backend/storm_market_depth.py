"""V22.6c persistent liquidity observations and public spot order-book diagnostics.
Read-only market data; depth metrics are snapshots, not execution guarantees.
"""
from __future__ import annotations
import os, sqlite3, time
from pathlib import Path
from statistics import median
import requests

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.getenv('TEKAR_STORM_DB', str(ROOT / 'data' / 'storm_liquidity.sqlite3')))
TIMEOUT = (3, 6)


def _connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_PATH), timeout=5)
    con.execute('''CREATE TABLE IF NOT EXISTS liquidity_observations (
        id INTEGER PRIMARY KEY AUTOINCREMENT, exchange TEXT NOT NULL,
        symbol TEXT NOT NULL, ts REAL NOT NULL, quote_volume REAL NOT NULL,
        bid_depth REAL, ask_depth REAL, spread_bps REAL)''')
    con.execute('CREATE INDEX IF NOT EXISTS idx_liq_key_ts ON liquidity_observations(exchange,symbol,ts)')
    return con


def record_observation(exchange: str, symbol: str, quote_volume: float,
                       bid_depth: float | None = None, ask_depth: float | None = None,
                       spread_bps: float | None = None, timestamp: float | None = None) -> dict:
    ex, sym = str(exchange or '').strip().lower(), str(symbol or '').strip().upper()
    try: vol = float(quote_volume)
    except (TypeError, ValueError): vol = -1
    vals = [bid_depth, ask_depth, spread_bps]
    try: vals = [None if v is None else float(v) for v in vals]
    except (TypeError, ValueError): return {'status':'invalid_snapshot','entry_ready':False}
    if not ex or not sym or vol < 0 or any(v is not None and v < 0 for v in vals):
        return {'status':'invalid_snapshot','entry_ready':False}
    ts = float(timestamp if timestamp is not None else time.time())
    with _connect() as con:
        last = con.execute('SELECT ts FROM liquidity_observations WHERE exchange=? AND symbol=? ORDER BY ts DESC LIMIT 1',(ex,sym)).fetchone()
        if last and ts <= last[0]: return {'status':'out_of_order_snapshot','entry_ready':False}
        if last and ts-last[0] < 600: return {'status':'sample_too_soon','entry_ready':False,'next_sample_after':last[0]+600}
        con.execute('INSERT INTO liquidity_observations(exchange,symbol,ts,quote_volume,bid_depth,ask_depth,spread_bps) VALUES(?,?,?,?,?,?,?)',(ex,sym,ts,vol,*vals))
        rows=con.execute('SELECT ts,quote_volume,bid_depth,ask_depth,spread_bps FROM liquidity_observations WHERE exchange=? AND symbol=? ORDER BY ts DESC LIMIT 12',(ex,sym)).fetchall()
    rows=list(reversed(rows)); volumes=[r[1] for r in rows]; span=rows[-1][0]-rows[0][0]
    enough=len(rows)>=3 and span>=1200
    med=median(volumes) if volumes else 0
    stable=bool(enough and med>=100000 and min(volumes)/med>=.35)
    return {'status':'liquidity_stable_observed' if stable else 'insufficient_observations' if not enough else 'liquidity_unstable',
            'stable':stable,'samples':len(rows),'observation_span_seconds':int(span),
            'median_quote_volume':round(med,2),'minimum_to_median_ratio':round(min(volumes)/med,3) if med else 0,
            'latest_bid_depth_quote':vals[0],'latest_ask_depth_quote':vals[1], 'latest_spread_bps':vals[2], 'entry_ready':False}


def history(exchange: str, symbol: str, limit: int=12) -> dict:
    with _connect() as con:
        rows=con.execute('SELECT ts,quote_volume,bid_depth,ask_depth,spread_bps FROM liquidity_observations WHERE exchange=? AND symbol=? ORDER BY ts DESC LIMIT ?',
                         (str(exchange).lower(),str(symbol).upper(),max(1,min(int(limit),100)))).fetchall()
    return {'exchange':exchange,'symbol':symbol,'count':len(rows),'observations':[{'timestamp':r[0],'quote_volume':r[1],'bid_depth_quote':r[2],'ask_depth_quote':r[3],'spread_bps':r[4]} for r in reversed(rows)],'entry_ready':False}


def _fetch(url, params):
    r=requests.get(url,params=params,timeout=TIMEOUT,headers={'User-Agent':'TradingSignalAIPro/22.6.3'})
    r.raise_for_status(); return r.json()


def fetch_orderbook(exchange: str, symbol: str, levels: int=20, fetch_json=_fetch) -> dict:
    ex=str(exchange).strip().lower(); sym=str(symbol).strip().upper()
    if not sym or not sym.endswith('USDT'):
        return {'status':'unsupported_pair','entry_ready':False}
    try:
        if ex=='binance': raw=fetch_json('https://api.binance.com/api/v3/depth',{'symbol':sym,'limit':min(100,int(levels))}); bids,asks=raw['bids'],raw['asks']
        elif ex=='mexc': raw=fetch_json('https://api.mexc.com/api/v3/depth',{'symbol':sym,'limit':min(100,int(levels))}); bids,asks=raw['bids'],raw['asks']
        elif ex=='bybit':
            raw=fetch_json('https://api.bybit.com/v5/market/orderbook',{'category':'spot','symbol':sym,'limit':min(200,int(levels))})['result']; bids,asks=raw['b'],raw['a']
        else: return {'status':'unsupported_exchange','entry_ready':False}
        bids=[(float(p),float(q)) for p,q in bids[:levels] if float(p)>0 and float(q)>0]
        asks=[(float(p),float(q)) for p,q in asks[:levels] if float(p)>0 and float(q)>0]
        if not bids or not asks: return {'status':'empty_orderbook','entry_ready':False}
        best_bid=max(p for p,q in bids); best_ask=min(p for p,q in asks)
        if best_ask<=best_bid: return {'status':'crossed_or_invalid_book','entry_ready':False}
        mid=(best_bid+best_ask)/2
        bid_depth=sum(p*q for p,q in bids); ask_depth=sum(p*q for p,q in asks)
        spread=(best_ask-best_bid)/mid*10000
        imbalance=(bid_depth-ask_depth)/(bid_depth+ask_depth) if bid_depth+ask_depth else 0
        return {'status':'depth_snapshot_ok','exchange':ex,'symbol':sym,'levels_used':min(len(bids),len(asks)),
                'best_bid':best_bid,'best_ask':best_ask,'mid_price':mid,'spread_bps':round(spread,2),
                'bid_depth_quote':round(bid_depth,2),'ask_depth_quote':round(ask_depth,2),
                'depth_imbalance':round(imbalance,4),
                'bid_levels':[{'price':p,'quantity':q} for p,q in bids],
                'ask_levels':[{'price':p,'quantity':q} for p,q in asks], 'entry_ready':False,
                'warning':'این تصویر لحظه‌ای دفتر سفارش است؛ دیوارها قابل لغو/جعل‌اند و عمق نمایش‌داده‌شده تضمین اجرای سفارش نیست.'}
    except Exception as exc:
        return {'status':'depth_unavailable','error':str(exc)[:140],'entry_ready':False}
