"""Offline monitoring, periodic summaries, hash-chained audit events and ledger recovery."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

VERSION = 'btc-4h-paper-monitor-v1'
GENESIS = '0' * 64


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def build_hash_chain(events: list[dict]) -> list[dict]:
    """Return a deterministic SHA-256 chain; each event commits to its predecessor."""
    chain, previous = [], GENESIS
    for index, event in enumerate(events):
        payload = dict(event)
        payload.pop('chain_hash', None)
        payload.pop('previous_hash', None)
        digest = hashlib.sha256((previous + _canonical(payload)).encode('utf-8')).hexdigest()
        chain.append({**payload, 'sequence': index, 'previous_hash': previous, 'chain_hash': digest})
        previous = digest
    return chain


def verify_hash_chain(chain: list[dict]) -> dict:
    previous = GENESIS
    for index, item in enumerate(chain):
        if item.get('sequence') != index or item.get('previous_hash') != previous:
            return {'valid': False, 'verified_events': index, 'error': 'sequence_or_previous_hash_mismatch'}
        payload = {k: v for k, v in item.items() if k not in ('chain_hash', 'previous_hash', 'sequence')}
        expected = hashlib.sha256((previous + _canonical(payload)).encode('utf-8')).hexdigest()
        if item.get('chain_hash') != expected:
            return {'valid': False, 'verified_events': index, 'error': 'event_hash_mismatch'}
        previous = expected
    return {'valid': True, 'verified_events': len(chain), 'head_hash': previous}


def _period_key(trade: dict, period: str, bars_per_day: int) -> str:
    stamp = trade.get('exit_timestamp') or trade.get('entry_timestamp')
    if stamp:
        import pandas as pd
        ts = pd.Timestamp(stamp)
        return str(ts.date() if period == 'daily' else ts.to_period('W').start_time.date())
    pos = int(trade.get('exit_pos', trade.get('entry_pos', 0)))
    day = pos // bars_per_day
    return f'day:{day}' if period == 'daily' else f'week:{day // 7}'


def _period_summary(trades: list[dict], period: str, bars_per_day: int) -> list[dict]:
    groups: dict[str, list[dict]] = {}
    for trade in trades:
        groups.setdefault(_period_key(trade, period, bars_per_day), []).append(trade)
    output = []
    for key, rows in sorted(groups.items()):
        pnls = [float(x.get('net_pnl', 0.0)) for x in rows]
        wins = sum(x > 0 for x in pnls)
        losses = sum(x < 0 for x in pnls)
        output.append({'period': key, 'trade_count': len(rows), 'net_pnl': sum(pnls),
                       'win_rate': wins / len(rows) if rows else None,
                       'gross_profit': sum(x for x in pnls if x > 0),
                       'gross_loss': sum(x for x in pnls if x < 0),
                       'wins': wins, 'losses': losses})
    return output


def build_monitoring_report(ledger: dict, *, bars_per_day: int = 6) -> dict:
    if not isinstance(ledger, dict) or ledger.get('mode') != 'PAPER_ONLY_OFFLINE':
        raise ValueError('a PAPER_ONLY_OFFLINE ledger is required')
    if ledger.get('live_orders_sent') is not False:
        raise ValueError('ledger live-order safety flag is invalid')
    if bars_per_day < 1:
        raise ValueError('bars_per_day must be >= 1')
    trades = ledger.get('trades', [])
    events = ledger.get('events', [])
    if not isinstance(trades, list) or not isinstance(events, list):
        raise ValueError('ledger trades/events must be lists')
    chain = build_hash_chain(events)
    verification = verify_hash_chain(chain)
    equity = ledger.get('equity_curve', [])
    values = [float(x['equity']) for x in equity]
    if not all(__import__('math').isfinite(x) for x in values):
        raise ValueError('equity curve contains non-finite values')
    peak, max_dd = None, 0.0
    for value in values:
        peak = value if peak is None else max(peak, value)
        if peak:
            max_dd = min(max_dd, value / peak - 1.0)
    report = {
        'version': VERSION, 'mode': 'PAPER_ONLY_OFFLINE',
        'source_ledger_hash': ledger.get('ledger_hash'),
        'monitoring': {'trade_count': len(trades), 'event_count': len(events),
            'equity_points': len(equity), 'final_equity': float(ledger.get('final_equity', 0.0)),
            'net_return': float(ledger.get('net_return', 0.0)), 'max_drawdown_recomputed': max_dd,
            'win_rate': ledger.get('win_rate'), 'profit_factor': ledger.get('profit_factor'),
            'skipped': dict(ledger.get('skipped', {})),
            'global_halt': bool(ledger.get('risk_controls', {}).get('global_halt', False)),
            'halted_days': list(ledger.get('risk_controls', {}).get('halted_days', []))},
        'daily': _period_summary(trades, 'daily', bars_per_day),
        'weekly': _period_summary(trades, 'weekly', bars_per_day),
        'event_chain': chain, 'event_chain_verification': verification,
        'safety': {'paper_only': True, 'network_access': False, 'exchange_order_submission': False}}
    report['monitoring_hash'] = hashlib.sha256(_canonical(report).encode('utf-8')).hexdigest()
    return report


def save_monitoring_report(report: dict, path: str | Path) -> str:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    tmp.replace(path)
    return str(path)


def recover_paper_ledger(path: str | Path) -> dict:
    """Load and validate a saved paper ledger; never silently repair corrupted data."""
    path = Path(path)
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f'ledger cannot be read: {exc}') from exc
    if not isinstance(data, dict) or data.get('mode') != 'PAPER_ONLY_OFFLINE':
        raise ValueError('not a paper-only ledger')
    if data.get('live_orders_sent') is not False:
        raise ValueError('ledger safety flag missing or invalid')
    supplied = data.get('ledger_hash')
    payload = dict(data)
    payload.pop('ledger_hash', None)
    expected = hashlib.sha256(_canonical(payload).encode('utf-8')).hexdigest()
    if not supplied or supplied != expected:
        raise ValueError('ledger hash mismatch; recovery refused')
    if not isinstance(data.get('trades'), list) or not isinstance(data.get('events'), list):
        raise ValueError('ledger structure is incomplete')
    return {'recovered': True, 'mode': 'PAPER_ONLY_OFFLINE', 'ledger': data,
            'trade_count': len(data['trades']), 'event_count': len(data['events']),
            'ledger_hash': supplied}
