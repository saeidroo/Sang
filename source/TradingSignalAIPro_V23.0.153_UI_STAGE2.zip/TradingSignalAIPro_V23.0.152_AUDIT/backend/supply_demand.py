"""V23.0.51 causal supply/demand zone analysis for paper-trading decisions.

Zones are inferred from confirmed swing pivots and subsequent departures using
closed OHLCV candles only. They are heuristic price areas, not order-book data.
"""
from __future__ import annotations
import math
from typing import Any
import pandas as pd


def analyze_supply_demand(candles: Any, *, side: str, atr_value: float | None = None,
                          lookback: int = 160, pivot_width: int = 3,
                          proximity_atr: float = 0.65) -> dict:
    direction = str(side).upper()
    if direction not in ("LONG", "SHORT"):
        raise ValueError("side must be LONG or SHORT")
    if not isinstance(candles, pd.DataFrame):
        candles = pd.DataFrame(candles)
    required = {"open", "high", "low", "close"}
    if not required.issubset(candles.columns):
        return {"state":"UNAVAILABLE", "blocking":False, "zones":[], "reason":"OHLC columns unavailable"}
    d = candles.tail(max(lookback, pivot_width*2+5)).copy()
    for col in required:
        d[col] = pd.to_numeric(d[col], errors="coerce")
    d = d.replace([float("inf"), float("-inf")], float("nan")).dropna(subset=list(required)).reset_index(drop=True)
    if len(d) < pivot_width*2+8:
        return {"state":"UNAVAILABLE", "blocking":False, "zones":[], "reason":"insufficient closed candles"}
    if atr_value is None:
        tr = pd.concat([d.high-d.low, (d.high-d.close.shift()).abs(), (d.low-d.close.shift()).abs()], axis=1).max(axis=1)
        atr_value = float(tr.tail(14).mean())
    atr = float(atr_value)
    if not math.isfinite(atr) or atr <= 0:
        return {"state":"INVALID", "blocking":False, "zones":[], "reason":"invalid ATR"}
    for _, r in d.iterrows():
        o,h,l,c = (float(r[k]) for k in ("open","high","low","close"))
        if min(o,h,l,c) <= 0 or h < max(o,c) or l > min(o,c) or h < l:
            return {"state":"INVALID", "blocking":False, "zones":[], "reason":"invalid OHLC geometry"}
    close = float(d.close.iloc[-1]); candidates=[]
    # A pivot is usable only after pivot_width candles have closed to its right.
    for i in range(pivot_width, len(d)-pivot_width):
        row=d.iloc[i]
        is_high=float(row.high) >= float(d.high.iloc[i-pivot_width:i+pivot_width+1].max())
        is_low=float(row.low) <= float(d.low.iloc[i-pivot_width:i+pivot_width+1].min())
        # Departure is measured only in bars after the pivot confirmation window.
        departure_idx=min(len(d)-1, i+pivot_width+3)
        if is_high:
            top=float(row.high); base=max(float(row.open),float(row.close))
            departure=top-float(d.close.iloc[departure_idx])
            if departure >= 0.8*atr:
                candidates.append({"type":"SUPPLY","low":base,"high":top,"pivot_index":i,"departure_atr":departure/atr})
        if is_low:
            bottom=float(row.low); base=min(float(row.open),float(row.close))
            departure=float(d.close.iloc[departure_idx])-bottom
            if departure >= 0.8*atr:
                candidates.append({"type":"DEMAND","low":bottom,"high":base,"pivot_index":i,"departure_atr":departure/atr})
    zones=[]
    for z in candidates:
        touches=0
        for j in range(z["pivot_index"]+pivot_width+1, len(d)-1):
            if float(d.high.iloc[j]) >= z["low"] and float(d.low.iloc[j]) <= z["high"]:
                touches += 1
        age=len(d)-1-z["pivot_index"]
        strength=max(0.0, min(100.0, 35 + min(z["departure_atr"],3)*15 - touches*10 - age/len(d)*15))
        z.update({"touches":touches,"age_bars":age,"strength":round(strength,2)})
        z["distance_atr"] = round((z["low"]-close)/atr if z["type"]=="SUPPLY" else (close-z["high"])/atr,4)
        zones.append(z)
    relevant_type="SUPPLY" if direction=="LONG" else "DEMAND"
    relevant=[z for z in zones if z["type"]==relevant_type and ((z["low"]>=close if direction=="LONG" else z["high"]<=close))]
    relevant.sort(key=lambda z: abs(z["distance_atr"]))
    nearest=relevant[0] if relevant else None
    blocking=bool(nearest and 0 <= nearest["distance_atr"] <= proximity_atr and nearest["strength"] >= 35)
    state="OPPOSING_ZONE_NEAR" if blocking else "CLEAR" if nearest is None else "ZONE_AHEAD"
    return {"state":state,"side":direction,"blocking":blocking,"reference_close":close,
            "atr":atr,"proximity_atr":proximity_atr,"nearest_opposing_zone":nearest,
            "zones":sorted(zones,key=lambda z:(z["type"],z["pivot_index"])),
            "evaluated_data":"closed candles only","warning":"مناطق عرضه/تقاضا تخمین ساختاری هستند و دفتر سفارش واقعی را نشان نمی‌دهند."}
