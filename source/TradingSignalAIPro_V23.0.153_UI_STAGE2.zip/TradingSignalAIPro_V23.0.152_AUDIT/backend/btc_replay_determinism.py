"""Determinism fingerprints and prediction-level comparison for BTC 4h OOF replays."""
from __future__ import annotations
import hashlib, json, platform


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False, default=str)


def _sha(value):
    return hashlib.sha256(_canonical(value).encode('utf-8')).hexdigest()


def build_training_environment(*, random_state, model_config=None):
    """Capture the reproducibility-relevant runtime and explicit model settings."""
    versions = {}
    for name in ('numpy', 'pandas', 'scikit-learn', 'scipy'):
        try:
            from importlib.metadata import version
            versions[name] = version(name)
        except Exception:
            versions[name] = None
    payload = {'schema_version': 'btc4h-training-environment-v1',
               'random_state': int(random_state), 'model_config': model_config or {},
               'python': platform.python_version(), 'implementation': platform.python_implementation(),
               'platform': platform.platform(), 'dependencies': versions}
    payload['environment_sha256'] = _sha(payload)
    return payload


def _records(predictions):
    if hasattr(predictions, 'to_dict'):
        rows = predictions.to_dict(orient='records')
    else:
        rows = list(predictions)
    # Canonical key order and stable row order; OOF identity is the sort key.
    rows = [dict(r) for r in rows]
    rows.sort(key=lambda r: (str(r.get('model')), int(r.get('fold', -1)),
                             str(r.get('sample_id', r.get('sample_index', '')))))
    return rows


def prediction_digest(predictions):
    return _sha(_records(predictions))


def compare_prediction_replays(first, second):
    """Compare two OOF outputs and classify whether prediction rows changed."""
    a, b = _records(first), _records(second)
    def key(row):
        return (str(row.get('model')), int(row.get('fold', -1)),
                str(row.get('sample_id', row.get('sample_index', ''))))
    left, right = {key(r): r for r in a}, {key(r): r for r in b}
    added = sorted(set(right) - set(left)); removed = sorted(set(left) - set(right))
    changed = sorted(k for k in set(left) & set(right) if _canonical(left[k]) != _canonical(right[k]))
    result = {'schema_version': 'btc4h-oof-replay-comparison-v1',
              'first_sha256': _sha(a), 'second_sha256': _sha(b),
              'first_rows': len(a), 'second_rows': len(b),
              'added_keys': [list(k) for k in added], 'removed_keys': [list(k) for k in removed],
              'changed_keys': [list(k) for k in changed],
              'deterministic': not (added or removed or changed)}
    result['comparison_sha256'] = _sha(result)
    return result


def require_deterministic_replay(first, second):
    report = compare_prediction_replays(first, second)
    if not report['deterministic']:
        raise ValueError('btc4h_oof_replay_nondeterministic')
    return report
