"""V23.0.69 read-only exit-risk intelligence for PAPER positions."""
from __future__ import annotations
import math


def _finite(value, name, minimum=None):
    try: number = float(value)
    except (TypeError, ValueError, OverflowError): raise ValueError(f'{name} نامعتبر است')
    if not math.isfinite(number) or (minimum is not None and number < minimum):
        raise ValueError(f'{name} نامعتبر است')
    return number


def evaluate_exit_intelligence(positions, settings=None):
    if not isinstance(positions, list):
        raise ValueError('positions باید فهرست باشد')
    cfg = {'max_adverse_move_pct': 2.0, 'emergency_atr_multiple': 3.0,
           'stale_after_seconds': 120.0}
    if settings is not None:
        if not isinstance(settings, dict): raise ValueError('settings نامعتبر است')
        cfg.update(settings)
    adverse_limit = _finite(cfg['max_adverse_move_pct'], 'max_adverse_move_pct', 0.01)
    emergency_atr = _finite(cfg['emergency_atr_multiple'], 'emergency_atr_multiple', 0.1)
    stale_after = _finite(cfg['stale_after_seconds'], 'stale_after_seconds', 0.0)
    out, invalid, seen = [], [], set()
    for index, p in enumerate(positions):
        if not isinstance(p, dict):
            invalid.append({'index': index, 'reason': 'position نامعتبر'}); continue
        pid = str(p.get('position_id') or '').strip()
        if not pid or pid in seen:
            invalid.append({'index': index, 'position_id': pid or None, 'reason': 'شناسه خالی یا تکراری'}); continue
        seen.add(pid)
        status = str(p.get('status') or 'OPEN').upper()
        if status not in ('OPEN', 'RECONCILED_OPEN') or p.get('paper_only') is False:
            out.append({'position_id': pid, 'decision': 'IGNORE', 'reason': 'CLOSED_OR_NON_PAPER_POSITION', 'event_key': None}); continue
        side = str(p.get('side') or '').upper()
        if side not in ('LONG', 'SHORT'):
            invalid.append({'index': index, 'position_id': pid, 'reason': 'side نامعتبر'}); continue
        try:
            entry = _finite(p.get('entry_price'), 'entry_price', 1e-12)
            price = _finite(p.get('current_price'), 'current_price', 1e-12)
            stop = _finite(p.get('stop_price'), 'stop_price', 1e-12)
            atr = _finite(p.get('atr'), 'atr', 1e-12)
            qty = _finite(p.get('quantity'), 'quantity', 1e-12)
            age = _finite(p.get('quote_age_seconds', 0), 'quote_age_seconds', 0)
            if (side == 'LONG' and stop >= entry) or (side == 'SHORT' and stop <= entry):
                raise ValueError('حد ضرر با جهت موقعیت سازگار نیست')
            if age > stale_after:
                out.append({'position_id': pid, 'decision': 'HOLD_NO_ACTION', 'reason': 'STALE_PRICE_DATA', 'event_key': None}); continue
            adverse_pct = ((entry-price)/entry*100) if side == 'LONG' else ((price-entry)/entry*100)
            adverse_distance = (entry-price) if side == 'LONG' else (price-entry)
            stop_breached = price <= stop if side == 'LONG' else price >= stop
            structure_break = bool(p.get('structure_break_against_position', False))
            reversal = bool(p.get('reversal_confirmed', False))
            volatility_shock = adverse_distance >= atr * emergency_atr
            reasons = []
            if stop_breached: reasons.append('STOP_LEVEL_BREACHED')
            if structure_break: reasons.append('STRUCTURE_BREAK_AGAINST_POSITION')
            if reversal: reasons.append('REVERSAL_CONFIRMED')
            if adverse_pct >= adverse_limit: reasons.append('ADVERSE_MOVE_THRESHOLD')
            if volatility_shock: reasons.append('EMERGENCY_ATR_SHOCK')
            decision = 'EXIT_REVIEW_REQUIRED' if reasons else 'HOLD_AND_MONITOR'
            trigger = '|'.join(reasons) if reasons else 'MONITOR'
            event_key = f'{pid}:EXIT_REVIEW:{trigger}' if reasons else None
            gross = ((price-entry) if side == 'LONG' else (entry-price))*qty
            out.append({'position_id': pid, 'symbol': str(p.get('symbol') or '').upper(),
                'side': side, 'decision': decision, 'reasons': reasons,
                'adverse_move_pct': round(adverse_pct, 6), 'estimated_gross_pnl_usdt': round(gross, 8),
                'event_key': event_key, 'idempotency_policy': 'مصرف‌کننده باید event_key را به‌صورت یکتا ثبت کند.',
                'requires_human_or_paper_engine_confirmation': True})
        except ValueError as exc:
            invalid.append({'index': index, 'position_id': pid, 'reason': str(exc)})
    return {'version': '23.0.69', 'positions': out, 'invalid_positions': invalid,
        'position_count': len(out), 'read_only': True, 'paper_only': True,
        'recommendations_only': True, 'creates_orders': False,
        'execution_authorized': False, 'real_orders_enabled': False}
