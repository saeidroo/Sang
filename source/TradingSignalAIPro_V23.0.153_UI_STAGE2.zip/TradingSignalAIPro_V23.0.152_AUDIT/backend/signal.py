"""
Signal engine - combines model probability with technical confirmation
and ATR-based TP/SL levels to produce BUY/SELL/HOLD signals.
Also includes visual backtest over historical bars and an honest
trade simulator. TP/SL geometry is ALIGNED with the training labels
(Triple-Barrier ±1.5×ATR within 12 bars) so the model's probability
directly estimates the win probability of the recommended trade.
"""
import numpy as np
import pandas as pd
from .indicators import ema, rsi, atr, all_indicators
from .trade_contract import (ATR_TP_MULT, ATR_SL_MULT, TRADE_HORIZON_BARS,
                             TRAIL_TRIGGER_PCT, TRAIL_DISTANCE_PCT, trailing_stop_price)
from .execution_model import (execution_costs, net_return_fraction, round_trip_cost_pct,
                              funding_cashflow_for_bars)

# Backtest costs use the same deterministic fee/spread/slippage/impact model
# as paper execution. A representative 1,000 USDT notional is used because
# historical signal simulation has no position-size input.
try:
    BACKTEST_COST_NOTIONAL_USDT = float(__import__('os').getenv(
        'TS_AI_BACKTEST_NOTIONAL_USDT', '1000'))
    if not np.isfinite(BACKTEST_COST_NOTIONAL_USDT) or BACKTEST_COST_NOTIONAL_USDT <= 0:
        BACKTEST_COST_NOTIONAL_USDT = 1000.0
except (TypeError, ValueError):
    BACKTEST_COST_NOTIONAL_USDT = 1000.0
BACKTEST_EXECUTION_COSTS = execution_costs(BACKTEST_COST_NOTIONAL_USDT)
ROUND_TRIP_COST_PCT = round_trip_cost_pct(BACKTEST_COST_NOTIONAL_USDT)
BACKTEST_HORIZON = TRADE_HORIZON_BARS
BACKTEST_SIGNALS = 12
SIM_HORIZON = TRADE_HORIZON_BARS


def _funding_events_between(ind_rows: pd.DataFrame, entry_idx: int, exit_idx: int):
    """Return exact realized settlements in (entry candle open, exit candle open].

    New trainer output stores zero or more event dictionaries per candle in
    ``funding_events``. Legacy scalar columns remain supported. Event timestamps
    must be unique and chronological; no rate/mark is inferred from OHLC.
    """
    required = {"t"}
    if not required.issubset(ind_rows.columns):
        raise ValueError("perpetual backtest requires candle timestamps")
    if entry_idx < 0 or exit_idx < entry_idx or exit_idx >= len(ind_rows):
        raise ValueError("funding interval indices are invalid")
    entry_ts = float(ind_rows["t"].iloc[entry_idx])
    exit_ts = float(ind_rows["t"].iloc[exit_idx])
    if not (np.isfinite(entry_ts) and np.isfinite(exit_ts) and exit_ts >= entry_ts):
        raise ValueError("perpetual backtest candle timestamps are invalid")

    events = []
    window = ind_rows.iloc[entry_idx:exit_idx + 1]
    if "funding_events" in ind_rows.columns:
        for cell in window["funding_events"].tolist():
            if cell is None or (isinstance(cell, float) and np.isnan(cell)):
                continue
            if not isinstance(cell, (list, tuple)):
                raise ValueError("funding event-list cell has invalid structure")
            for event in cell:
                if not isinstance(event, dict):
                    raise ValueError("funding event record has invalid structure")
                try:
                    events.append((float(event["settlement_ts"]),
                                   float(event["funding_rate"]),
                                   float(event["mark_price"])))
                except (KeyError, TypeError, ValueError, OverflowError):
                    raise ValueError("funding event is missing rate, timestamp or mark")
    else:
        legacy = {"funding_rate", "funding_mark_price", "funding_settlement_ts"}
        if not legacy.issubset(ind_rows.columns):
            raise ValueError("perpetual backtest requires complete realized funding columns")
        ts = window["funding_settlement_ts"].to_numpy(dtype=float)
        rates = window["funding_rate"].to_numpy(dtype=float)
        marks = window["funding_mark_price"].to_numpy(dtype=float)
        present = np.isfinite(rates)
        if np.any(present != np.isfinite(ts)) or np.any(present != np.isfinite(marks)):
            raise ValueError("perpetual funding history contains incomplete settlement records")
        legacy_ts = ts[present]
        if len(legacy_ts) > 1 and np.any(np.diff(legacy_ts) <= 0):
            raise ValueError("perpetual funding settlements must be unique and chronological")
        events.extend((float(t), float(r), float(m)) for t, r, m in zip(legacy_ts, rates[present], marks[present]))

    events.sort(key=lambda x: x[0])
    timestamps = [event[0] for event in events]
    if len(timestamps) != len(set(timestamps)):
        raise ValueError("perpetual funding settlements contain duplicate timestamps")
    for ts, rate, mark in events:
        if not (np.isfinite(ts) and np.isfinite(rate) and np.isfinite(mark)):
            raise ValueError("perpetual funding history contains non-finite values")
        if abs(rate) > 0.10 or mark <= 0:
            raise ValueError("perpetual funding history contains invalid rate or mark price")
    selected = [(rate, mark) for ts, rate, mark in events if entry_ts < ts <= exit_ts]
    return (np.asarray([x[0] for x in selected], dtype=float),
            np.asarray([x[1] for x in selected], dtype=float))


def simulate_trades(probs: np.ndarray, ind_rows: pd.DataFrame,
                    thr: float = 0.6, tp_mult: float = ATR_TP_MULT,
                    sl_mult: float = ATR_SL_MULT,
                    horizon: int = SIM_HORIZON, market: str = "spot") -> dict:
    """Simulate one position at a time with conservative, executable exits.

    A trade that reaches neither barrier is closed at the last close of the
    full horizon instead of silently disappearing from the win-rate sample.
    A trade without a full future horizon is reported as open and excluded.
    Same-candle TP/SL touches remain ambiguous and are excluded from win/loss.
    Round-trip fees + slippage are deducted before classifying net wins/losses;
    gross wins are also retained as a separate diagnostic.
    """
    if not isinstance(ind_rows, pd.DataFrame) or not {'high', 'low', 'close', 'atr_14'}.issubset(ind_rows.columns):
        raise ValueError('ستون‌های OHLC و ATR برای شبیه‌سازی معامله لازم‌اند')
    if (not isinstance(horizon, (int, np.integer)) or horizon < 1
            or not np.isfinite(float(thr)) or not 0.5 <= float(thr) <= 0.99
            or not np.isfinite(float(tp_mult)) or not np.isfinite(float(sl_mult))
            or float(tp_mult) <= 0 or float(sl_mult) <= 0):
        raise ValueError('آستانه، افق یا ضرایب حد سود/ضرر شبیه‌سازی نامعتبرند')

    market = str(market or "spot").lower()
    if market not in ("spot", "perp"):
        raise ValueError("market must be spot or perp")
    if market == "perp" and not ({"t", "funding_events"}.issubset(ind_rows.columns) or
                                  {"t", "funding_rate", "funding_mark_price", "funding_settlement_ts"}.issubset(ind_rows.columns)):
        raise ValueError("perpetual backtest requires realized funding event records")

    H = ind_rows['high'].to_numpy(dtype=float)
    L = ind_rows['low'].to_numpy(dtype=float)
    C = ind_rows['close'].to_numpy(dtype=float)
    A = ind_rows['atr_14'].to_numpy(dtype=float)
    n = min(len(probs), len(ind_rows))
    wins = losses = gross_wins = ambiguous = opens = timeouts = breakeven = 0
    win_rets, loss_rets, closed_rets = [], [], []
    trade_details = []
    busy_until = -1
    i = 0
    while i < n - 1:
        if i <= busy_until:
            i += 1
            continue
        p = float(probs[i])
        if not np.isfinite(p) or abs(p - 0.5) < (thr - 0.5):
            i += 1
            continue
        if not np.isfinite(C[i]) or C[i] <= 0:
            i += 1
            continue
        atr_i = A[i] if np.isfinite(A[i]) and A[i] > 0 else C[i] * 0.01
        side = 1 if p >= 0.5 else -1
        side_name = "LONG" if side == 1 else "SHORT"
        entry_reference = C[i]
        entry_fill = entry_reference * (1.0 + side * BACKTEST_EXECUTION_COSTS["total_adverse_price_bps_per_side"] / 10000.0)
        tp = entry_fill + side * tp_mult * atr_i
        sl = entry_fill - side * sl_mult * atr_i
        initial_sl = sl
        trail_active = False
        favourable_peak = entry_fill
        end = min(n, i + 1 + horizon)
        result = 'open'
        ret = 0.0
        exit_idx = end - 1
        for j in range(i + 1, end):
            if not (np.isfinite(H[j]) and np.isfinite(L[j]) and np.isfinite(C[j])):
                continue
            if side == 1:
                hit_tp, hit_sl = H[j] >= tp, L[j] <= sl
            else:
                hit_tp, hit_sl = L[j] <= tp, H[j] >= sl
            if hit_tp and hit_sl:
                result = 'ambiguous'
                exit_idx = j
                break
            if hit_tp:
                ret = side * (tp - entry_fill) / entry_fill
                result = 'win'
                exit_idx = j
                break
            if hit_sl:
                ret = side * (sl - entry_fill) / entry_fill
                result = 'loss'
                exit_idx = j
                break
            # Update trailing stop only after checking this candle against the
            # stop known at its open; the tightened stop becomes active next bar.
            favourable = H[j] if side == 1 else L[j]
            favourable_peak = max(favourable_peak, favourable) if side == 1 else min(favourable_peak, favourable)
            progress_pct = side * (favourable_peak / entry_fill - 1.0) * 100.0
            if progress_pct >= TRAIL_TRIGGER_PCT:
                trail_active = True
                candidate = trailing_stop_price(
                    side="LONG" if side == 1 else "SHORT",
                    peak_price=favourable_peak, distance_pct=TRAIL_DISTANCE_PCT)
                sl = max(sl, candidate) if side == 1 else min(sl, candidate)

        if result == 'open':
            # Only a fully observed horizon can be closed at its final close.
            if end - i - 1 >= horizon and np.isfinite(C[exit_idx]) and C[exit_idx] > 0:
                ret = side * (C[exit_idx] - entry_fill) / entry_fill
                timeouts += 1
                net_ret = net_return_fraction(entry_reference=entry_reference,
                    exit_reference=C[exit_idx], side=side_name,
                    notional=BACKTEST_COST_NOTIONAL_USDT, costs=BACKTEST_EXECUTION_COSTS)
                if market == "perp":
                    rates, marks = _funding_events_between(ind_rows, i, exit_idx)
                    quantity = BACKTEST_COST_NOTIONAL_USDT / entry_fill
                    net_ret += funding_cashflow_for_bars(side=side_name, quantity=quantity,
                                                         funding_rates=rates, mark_prices=marks) / BACKTEST_COST_NOTIONAL_USDT
                if abs(ret) < 1e-12:
                    breakeven += 1
                if ret > 0:
                    gross_wins += 1
                if net_ret > 0:
                    result = 'win'
                    wins += 1
                    win_rets.append(net_ret)
                else:
                    result = 'loss'  # win-rate/Wilson evidence is net of trading costs
                    losses += 1
                    loss_rets.append(net_ret)
                closed_rets.append(net_ret)
                trade_details.append({'idx': int(i), 'exit_idx': int(exit_idx),
                    'side': side_name, 'is_win': bool(net_ret > 0),
                    'net_return_pct': float(net_ret * 100.0),
                    'exit_reason': 'TIME_EXIT'})
            else:
                opens += 1
        elif result == 'ambiguous':
            ambiguous += 1
        else:
            exit_reference = tp if result == 'win' else sl
            net_ret = net_return_fraction(entry_reference=entry_reference,
                exit_reference=exit_reference, side=side_name,
                notional=BACKTEST_COST_NOTIONAL_USDT, costs=BACKTEST_EXECUTION_COSTS)
            if market == "perp":
                rates, marks = _funding_events_between(ind_rows, i, exit_idx)
                quantity = BACKTEST_COST_NOTIONAL_USDT / entry_fill
                net_ret += funding_cashflow_for_bars(side=side_name, quantity=quantity,
                                                     funding_rates=rates, mark_prices=marks) / BACKTEST_COST_NOTIONAL_USDT
            closed_rets.append(net_ret)
            trade_details.append({'idx': int(i), 'exit_idx': int(exit_idx),
                'side': side_name, 'is_win': bool(net_ret > 0),
                'net_return_pct': float(net_ret * 100.0),
                'exit_reason': 'TAKE_PROFIT' if result == 'win' else 'STOP_LOSS'})
            if result == 'win':
                gross_wins += 1
            if result == 'win' and net_ret > 0:
                wins += 1
                win_rets.append(net_ret)
            else:
                losses += 1
                loss_rets.append(net_ret)

        busy_until = exit_idx
        i = exit_idx + 1

    n_trades = wins + losses
    win_rate = wins / n_trades if n_trades else 0.0
    avg_win = float(np.mean(win_rets)) * 100 if win_rets else 0.0
    avg_loss = float(np.mean(loss_rets)) * 100 if loss_rets else 0.0
    expectancy = float(np.mean(closed_rets)) * 100 if closed_rets else 0.0
    net_expectancy = expectancy if n_trades else 0.0
    return {
        'net_expectancy_pct': float(net_expectancy), 'cost_pct': ROUND_TRIP_COST_PCT,
        'cost_assumption': 'exact paper fill-price plus two-sided fees; deterministic assumptions, not order-book measured',
        'n_trades': int(n_trades), 'closed_trades': int(n_trades),
        'wins': int(wins), 'losses': int(losses), 'gross_wins': int(gross_wins),
        'gross_win_rate': float(gross_wins / n_trades) if n_trades else 0.0,
        'breakeven': int(breakeven),
        'timeouts': int(timeouts), 'ambiguous': int(ambiguous), 'open_trades': int(opens),
        'win_rate': float(win_rate), 'avg_win_pct': float(avg_win),
        'avg_loss_pct': float(avg_loss), 'expectancy_pct': float(expectancy),
        'non_overlapping': True,
        'trade_details': trade_details,
    }


def simulate_trades_per_trade(probs, ind_rows, thr=0.60, tp_mult=ATR_TP_MULT,
                              sl_mult=ATR_SL_MULT, horizon=SIM_HORIZON,
                              market='spot'):
    """Return outcomes from the canonical simulator, not a divergent legacy loop.

    This preserves the same non-overlap policy, ATR barriers, trailing/time exits,
    fill costs and (for market='perp') realized funding accounting. Ambiguous and
    still-open trades are excluded exactly as in the aggregate closed-trade stats.
    """
    result = simulate_trades(probs, ind_rows, thr=thr, tp_mult=tp_mult,
                             sl_mult=sl_mult, horizon=horizon, market=market)
    return list(result.get('trade_details', []))


def compute_signal(ind_df: pd.DataFrame, model_prob: float,
                   threshold: float = 0.6, atr_mult_tp: float = ATR_TP_MULT,
                   atr_mult_sl: float = ATR_SL_MULT, news_alert: dict | None = None,
                   meta_probability: float | None = None, meta_threshold: float = 0.55,
                   strength: str | None = None,
                   data_contract_report: dict | None = None) -> dict:
    """
    Build signal from indicator dataframe + model probability.
    ind_df should be the result of all_indicators() — last row is "now".

    ``strength`` (V17.2) picks the decisiveness profile: it lowers the
    net-score entry bar and the conflict guard for stronger profiles. The
    news block and the meta-labeler filter are never bypassed.
    """
    # Signal generation is fail-closed when a caller supplies a Data Contract
    # report. WARN is not enough for a tradable signal; only exact PASS proceeds.
    if data_contract_report is not None and data_contract_report.get('status') != 'PASS':
        status = str(data_contract_report.get('status', 'UNKNOWN'))
        reasons = list(data_contract_report.get('block_reasons') or [])
        reasons += list(data_contract_report.get('warnings') or [])
        detail = '; '.join(reasons) or f'Data Contract status={status}'
        return {
            'kind': 'HOLD', 'reason': f'عدم معامله: اعتبار داده تأیید نشد ({detail})',
            'power': 0.0, 'net_score': 0.0, 'bull_score': 0.0, 'bear_score': 0.0,
            'strength_profile': 'data_blocked', 'entry': None, 'tp': None, 'sl': None,
            'levels_side': None, 'levels_provisional': True, 'atr': None, 'price': None,
            'prob': float(model_prob) if np.isfinite(model_prob) else None,
            'model_conf': None, 'news_alert': news_alert, 'news_blocked': False,
            'meta_probability': meta_probability, 'meta_blocked': False,
            'trend_up': False, 'trend_down': False, 'rsi_val': None, 'vol_ratio': None,
            'reasons': [('neg', f'Data Contract: {status} — {detail}')],
            'data_blocked': True, 'data_contract': data_contract_report,
            'ts': 0,
        }

    from .strength import normalize_strength, get_profile
    profile = get_profile(strength)
    _strength_name = normalize_strength(strength)
    last = ind_df.iloc[-1]
    price = float(last['close'])
    atr_val = float(last['atr_14']) if not np.isnan(last['atr_14']) else price * 0.01
    e20 = float(last['ema_20'])
    e50 = float(last['ema_50'])
    rsi_val = float(last['rsi_14'])

    # Trend regime
    trend_up = (price > e20) and (e20 > e50)
    trend_down = (price > 0) and (price < e20) and (e20 < e50)

    # RSI conditions
    rsi_overbought = rsi_val >= 72
    rsi_oversold = rsi_val <= 28

    # Volume confirmation
    v_now = float(last['volume'])
    v_mean_20 = float(ind_df['volume'].iloc[-20:].mean()) if len(ind_df) >= 20 else v_now
    vol_ratio = v_now / (v_mean_20 + 1e-9) if v_mean_20 > 0 else 1.0

    # Model direction & confidence
    model_up = model_prob >= 0.5
    model_conf = abs(model_prob - 0.5) * 2  # 0..1
    model_conf_threshold = (threshold - 0.5) * 2  # required min confidence

    # Scoring
    bull_score = 0.0
    bear_score = 0.0
    reasons = []

    # 1. Model (heavy weight)
    if model_up:
        bull_score += model_conf * 3
        reasons.append(('pos', f'مدل: تمایل صعودی با اطمینان {(model_conf*100):.0f}% '
                               f'(P={model_prob:.3f})'))
    else:
        bear_score += model_conf * 3
        reasons.append(('neg', f'مدل: تمایل نزولی با اطمینان {(model_conf*100):.0f}% '
                               f'(P={model_prob:.3f})'))

    # 2. Trend
    if trend_up:
        bull_score += 1.5
        reasons.append(('pos', 'روند صعودی (EMA20 > EMA50 و قیمت بالای EMA20)'))
    elif trend_down:
        bear_score += 1.5
        reasons.append(('neg', 'روند نزولی (EMA20 < EMA50 و قیمت زیر EMA20)'))
    else:
        reasons.append(('neu', 'روند خنثی'))

    # 3. RSI
    if rsi_oversold:
        bull_score += 1.0
        reasons.append(('pos', f'RSI اشباع فروش ({rsi_val:.1f}) — احتمال بازگشت'))
    elif rsi_overbought:
        bear_score += 1.0
        reasons.append(('neg', f'RSI اشباع خرید ({rsi_val:.1f}) — احتمال اصلاح'))
    else:
        reasons.append(('neu', f'RSI در محدوده سالم ({rsi_val:.1f})'))

    # 4. Volume confirmation
    if vol_ratio >= 1.0:
        if model_up:
            bull_score += 0.5
        else:
            bear_score += 0.5
        reasons.append(('pos', f'حجم بالاتر از میانگین ({vol_ratio:.2f}×) — تأیید حرکت'))
    else:
        reasons.append(('neu', f'حجم کمتر از میانگین ({vol_ratio:.2f}×)'))

    # 5. MACD confirmation
    if not np.isnan(last['macd_hist']):
        if last['macd_hist'] > 0:
            bull_score += 0.5
            reasons.append(('pos', 'هیستوگرام MACD مثبت'))
        else:
            bear_score += 0.5
            reasons.append(('neg', 'هیستوگرام MACD منفی'))

    # 6. Bollinger position
    if not np.isnan(last['bb_pct']):
        if last['bb_pct'] < 0.2:
            bull_score += 0.5
            reasons.append(('pos', 'قیمت نزدیک باند پایین بولینگر — احتمال برگشت'))
        elif last['bb_pct'] > 0.8:
            bear_score += 0.5
            reasons.append(('neg', 'قیمت نزدیک باند بالای بولینگر — احتمال اصلاح'))

    net_score = bull_score - bear_score
    max_score = 3 + 1.5 + 1 + 0.5 + 0.5 + 0.5  # 7.0
    power = min(1.0, abs(net_score) / max_score)

    # Conflict check
    conflicting = (model_up and trend_down) or (not model_up and trend_up)

    # Decision
    kind = 'HOLD'
    reason = ''

    news_block = bool(news_alert and news_alert.get('block_trading'))
    meta_block = (meta_probability is not None and meta_probability < meta_threshold)

    if news_block:
        kind = 'HOLD'
        reason = f"هشدار خبری/اقتصادی: {news_alert.get('alert_text') or 'ریسک رویداد بالا'} — فعلاً ورود نکن."
    elif meta_block:
        kind = 'HOLD'
        reason = f'Meta-Labeler کیفیت این معامله را پایین ارزیابی کرد ({meta_probability:.0%}).'
    elif model_conf < model_conf_threshold:
        kind = 'HOLD'
        reason = f'اطمینان مدل ({(model_conf*100):.0f}%) پایین‌تر از حد آستانه — ورود نکن.'
    elif conflicting and power < profile['conflict_power_guard']:
        kind = 'HOLD'
        reason = 'مدل و روند هم‌جهت نیستند — ریسک بالا.'
    elif (net_score >= profile['entry_net_score'] and model_up and not rsi_overbought):
        kind = 'BUY'
        reason = 'هم‌جهتی مدل، روند و اندیکاتورها به نفع صعود.'
    elif (net_score <= -profile['entry_net_score'] and not model_up and not rsi_oversold):
        kind = 'SELL'
        reason = 'هم‌جهتی مدل، روند و اندیکاتورها به نفع نزول.'
    else:
        kind = 'HOLD'
        reason = 'شرایط کافی برای ورود مطمئن فراهم نیست.'

    # Levels. For HOLD, show a clearly labelled *reference scenario* in the
    # model's directional-bias direction; it is not an entry recommendation.
    entry = price
    level_side = 1 if (kind == 'BUY' or (kind == 'HOLD' and model_prob >= 0.5)) else -1
    tp = price + level_side * atr_val * atr_mult_tp
    sl = price - level_side * atr_val * atr_mult_sl
    levels_provisional = (kind == 'HOLD')

    return {
        'kind': kind,
        'reason': reason,
        'power': float(power),
        'net_score': float(net_score),
        'bull_score': float(bull_score),
        'bear_score': float(bear_score),
        'strength_profile': _strength_name,
        'entry': float(entry),
        'tp': float(tp),
        'sl': float(sl),
        'levels_side': 'LONG' if level_side > 0 else 'SHORT',
        'levels_provisional': bool(levels_provisional),
        'atr': float(atr_val),
        'price': float(price),
        'prob': float(model_prob),
        'model_conf': float(model_conf),
        'news_alert': news_alert,
        'news_blocked': bool(news_block),
        'meta_probability': (float(meta_probability) if meta_probability is not None else None),
        'meta_blocked': bool(meta_block),
        'trend_up': bool(trend_up),
        'trend_down': bool(trend_down),
        'rsi_val': float(rsi_val),
        'vol_ratio': float(vol_ratio),
        'reasons': reasons,
        'ts': int(ind_df['t'].iloc[-1]) if 't' in ind_df.columns else 0,
    }



def apply_oos_edge_gate(signal: dict, model_meta: dict, requested_threshold: float,
                        strength: str | None = None):
    """Require a conservative, out-of-fold edge before allowing trade signals.

    A model with no threshold whose OOF Wilson lower bound beats the random
    TP/SL baseline is informational only: force HOLD and suppress backtests.

    ``strength`` only decides which threshold governs the live signal once the
    edge IS confirmed: conservative/balanced use max(user, OOF-selected) so the
    user can only make it stricter; assertive trusts the OOF-selected threshold
    itself. The edge requirement itself is never bypassed.
    """
    from .strength import get_profile
    profile = get_profile(strength)
    edge_confirmed = bool((model_meta or {}).get('edge_confirmed', False))
    if not edge_confirmed:
        signal = dict(signal)
        signal['kind'] = 'HOLD'
        signal['levels_provisional'] = True
        signal['reason'] = ('در آزمون خارج‌ازنمونه، برتری پایدار نسبت به خط پایه تصادفی تأیید نشد؛ '
                            'برای جلوگیری از سیگنال شانسی فعلاً فقط نظاره کن. سطوح قیمت صرفاً سناریوی مرجع‌اند.')
        return signal, float(requested_threshold), False
    try:
        calibrated_threshold = float((model_meta or {}).get('best_threshold') or requested_threshold)
    except (TypeError, ValueError):
        calibrated_threshold = float(requested_threshold)
    if profile['threshold_floor']:
        effective = max(float(requested_threshold), calibrated_threshold)
    else:
        effective = calibrated_threshold
    return signal, effective, True


def backtest_signals(ind_df: pd.DataFrame, features_df: pd.DataFrame,
                     model, threshold: float = 0.6,
                     count: int = BACKTEST_SIGNALS,
                     min_ts: int = None) -> list:
    """
    Walk through history, generate signals on each bar, keep BUY/SELL.
    Test if TP or SL hit first within BACKTEST_HORIZON bars.

    HONESTY RULES:
    - min_ts: only bars with timestamp >= min_ts are shown. Pass the
      training TEST-window start timestamp so the displayed win rate only
      covers data the model never trained on (out-of-sample history).
    - Ambiguous candles (both TP and SL touched inside the same bar) are
      marked result='ambiguous' — NOT counted as wins.
    """
    if model is None or not model.is_fitted:
        return []

    # Predict probabilities for every feature row
    probs = model.predict_proba_array(features_df)

    # Align: features_df rows correspond to ind_df rows from warmup onwards
    # We assume features_df and ind_df are already aligned (same length, same indices)
    n = len(features_df)
    if n != len(ind_df):
        # Try to align by taking the last n rows of ind_df
        ind_aligned = ind_df.iloc[-n:].reset_index(drop=True)
    else:
        ind_aligned = ind_df.reset_index(drop=True)

    out = []
    for i in range(n):
        # Out-of-sample filter: skip bars the model was trained on
        if min_ts is not None and 't' in ind_aligned.columns:
            if int(ind_aligned['t'].iloc[i]) < int(min_ts):
                continue

        prob = float(probs[i])
        model_up = prob >= 0.5
        model_conf = abs(prob - 0.5) * 2
        if model_conf < (threshold - 0.5) * 2:
            continue

        row = ind_aligned.iloc[i]
        price = float(row['close'])
        atr_val = float(row['atr_14']) if not np.isnan(row['atr_14']) else price * 0.01
        e20 = float(row['ema_20'])
        e50 = float(row['ema_50'])
        rsi_val = float(row['rsi_14'])

        trend_up = (price > e20) and (e20 > e50)
        trend_down = (price < e20) and (e20 < e50)
        rsi_overbought = rsi_val >= 72
        rsi_oversold = rsi_val <= 28

        v_now = float(row['volume'])
        v_mean = float(ind_aligned['volume'].iloc[max(0, i-20):i+1].mean())
        vol_ok = (v_now / (v_mean + 1e-9)) >= 1.0 if v_mean > 0 else False

        bull = 0.0
        bear = 0.0
        bull += model_conf * 3 if model_up else 0
        bear += model_conf * 3 if not model_up else 0
        if trend_up:
            bull += 1.5
        elif trend_down:
            bear += 1.5
        if rsi_oversold:
            bull += 1.0
        elif rsi_overbought:
            bear += 1.0
        if vol_ok:
            if model_up:
                bull += 0.5
            else:
                bear += 0.5
        if not np.isnan(row['macd_hist']):
            if row['macd_hist'] > 0:
                bull += 0.5
            else:
                bear += 0.5

        net = bull - bear
        conflicting = (model_up and trend_down) or (not model_up and trend_up)

        kind = 'HOLD'
        if conflicting and abs(net) / 7 < 0.5:
            kind = 'HOLD'
        elif net >= 2.0 and model_up and not rsi_overbought:
            kind = 'BUY'
        elif net <= -2.0 and not model_up and not rsi_oversold:
            kind = 'SELL'

        if kind == 'HOLD':
            continue

        tp_price = price + atr_val * ATR_TP_MULT if kind == 'BUY' else price - atr_val * ATR_TP_MULT
        sl_price = price - atr_val * ATR_SL_MULT if kind == 'BUY' else price + atr_val * ATR_SL_MULT

        # Forward test: did we hit TP or SL first within BACKTEST_HORIZON bars?
        result = 'open'
        ret_pct = 0.0
        forward_end = min(n, i + 1 + BACKTEST_HORIZON)
        for j in range(i + 1, forward_end):
            r = ind_aligned.iloc[j]
            if kind == 'BUY':
                hit_tp = r['high'] >= tp_price
                hit_sl = r['low'] <= sl_price
                if hit_tp and hit_sl:
                    # Both barriers in one candle: order unknowable from OHLC
                    result = 'ambiguous'
                    ret_pct = 0.0
                    break
                if hit_tp:
                    result = 'win'
                    ret_pct = (tp_price - price) / price * 100
                    break
                if hit_sl:
                    result = 'loss'
                    ret_pct = (sl_price - price) / price * 100
                    break
            else:
                hit_tp = r['low'] <= tp_price
                hit_sl = r['high'] >= sl_price
                if hit_tp and hit_sl:
                    result = 'ambiguous'
                    ret_pct = 0.0
                    break
                if hit_tp:
                    result = 'win'
                    ret_pct = (price - tp_price) / price * 100
                    break
                if hit_sl:
                    result = 'loss'
                    ret_pct = (price - sl_price) / price * 100
                    break

        # If neither barrier is hit after a complete 12-bar horizon, close at
        # the final observed close and count the realized timeout PnL.
        full_horizon = (forward_end - i - 1) >= BACKTEST_HORIZON
        if result == 'open' and full_horizon and forward_end > i + 1:
            exit_price = float(ind_aligned['close'].iloc[forward_end - 1])
            ret_pct = ((exit_price - price) / price * 100 if kind == 'BUY'
                       else (price - exit_price) / price * 100)
            result = 'win' if ret_pct > 0 else 'loss'

        gross_result = result
        net_ret_pct = (ret_pct - ROUND_TRIP_COST_PCT if result in ('win', 'loss') else None)
        if result == 'win' and net_ret_pct is not None and net_ret_pct <= 0:
            result = 'loss'  # a gross TP that cannot cover costs is not a net win

        out.append({
            'idx': int(i),
            'ts': int(row['t']) if 't' in ind_aligned.columns else 0,
            'kind': kind,
            'entry': price,
            'tp': tp_price,
            'sl': sl_price,
            'result': result,
            'gross_result': gross_result,
            'ret_pct': float(ret_pct),
            'net_ret_pct': (float(net_ret_pct) if net_ret_pct is not None else None),
        })

    return out[-count:][::-1]
