"""V23.0.85 — Storm learning data-quality audit and evidence-based learning for Storm Scout.

This module records only observed scout prices. It never fabricates forecasts or
turns a star into an order instruction. Outcomes are resolved from later real
snapshots at 1h/4h/24h horizons; missing observations remain pending.
"""
from __future__ import annotations
import os, sqlite3, time, math
from contextlib import contextmanager
from pathlib import Path
from statistics import mean
from collections import defaultdict

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.getenv('TEKAR_STORM_LEARNING_DB', str(ROOT / 'data' / 'storm_learning.sqlite3')))
HORIZONS = {'1h': 3600, '4h': 14400, '24h': 86400, '3d': 259200, '7d': 604800}
SUCCESS_RETURN_PCT = {'1h': 1.0, '4h': 2.5, '24h': 5.0, '3d': 10.0, '7d': 15.0}
FAIL_RETURN_PCT = -2.0
STAR_MIN_SAMPLES = 10
STAR_MIN_WIN_RATE = 0.65


@contextmanager
def _db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_PATH), timeout=15)
    con.row_factory = sqlite3.Row
    con.execute('''CREATE TABLE IF NOT EXISTS scout_sightings (
        id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, ts REAL NOT NULL,
        price REAL NOT NULL, score REAL NOT NULL, phase TEXT NOT NULL,
        direction TEXT NOT NULL, verified INTEGER NOT NULL, pattern TEXT NOT NULL,
        market_regime TEXT NOT NULL DEFAULT 'UNKNOWN', UNIQUE(symbol, ts))''')
    sighting_columns = {row[1] for row in con.execute('PRAGMA table_info(scout_sightings)')}
    if 'market_regime' not in sighting_columns:
        con.execute("ALTER TABLE scout_sightings ADD COLUMN market_regime TEXT NOT NULL DEFAULT 'UNKNOWN'")
    con.execute('CREATE INDEX IF NOT EXISTS idx_scout_sightings_symbol_ts ON scout_sightings(symbol,ts)')
    con.execute('''CREATE TABLE IF NOT EXISTS scout_price_observations (
        id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, ts REAL NOT NULL,
        price REAL NOT NULL, UNIQUE(symbol,ts))''')
    con.execute('CREATE INDEX IF NOT EXISTS idx_scout_price_symbol_ts ON scout_price_observations(symbol,ts)')
    con.execute('''CREATE TABLE IF NOT EXISTS scout_outcomes (
        id INTEGER PRIMARY KEY AUTOINCREMENT, sighting_id INTEGER NOT NULL,
        horizon TEXT NOT NULL, due_ts REAL NOT NULL, resolved_ts REAL,
        return_pct REAL, result TEXT, UNIQUE(sighting_id,horizon),
        FOREIGN KEY(sighting_id) REFERENCES scout_sightings(id))''')
    con.execute('CREATE INDEX IF NOT EXISTS idx_scout_outcomes_horizon_result ON scout_outcomes(horizon,result)')
    # V23.0.109: independently track distinct pre-pump signal episodes.
    # A 24-hour per-symbol cooldown prevents every repeated scan from being
    # counted as a new, statistically independent recommendation.
    con.execute('''CREATE TABLE IF NOT EXISTS scout_pre_pump_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, spotted_ts REAL NOT NULL,
        price REAL NOT NULL, scout_score REAL NOT NULL, pre_pump_score REAL NOT NULL,
        flow_grade TEXT NOT NULL, volume_acceleration_ratio REAL,
        recent_volume_ratio REAL, buy_pressure_ratio REAL, buy_pressure_change REAL,
        flow_persistence REAL, price_change_1h_pct REAL, market_regime TEXT NOT NULL DEFAULT 'UNKNOWN',
        relative_strength_score REAL, UNIQUE(symbol, spotted_ts))''')
    pre_pump_columns = {row[1] for row in con.execute('PRAGMA table_info(scout_pre_pump_events)')}
    if 'relative_strength_score' not in pre_pump_columns:
        con.execute('ALTER TABLE scout_pre_pump_events ADD COLUMN relative_strength_score REAL')
    con.execute('CREATE INDEX IF NOT EXISTS idx_pre_pump_symbol_ts ON scout_pre_pump_events(symbol,spotted_ts)')
    con.execute('''CREATE TABLE IF NOT EXISTS scout_pre_pump_outcomes (
        id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER NOT NULL,
        horizon TEXT NOT NULL, due_ts REAL NOT NULL, resolved_ts REAL,
        return_pct REAL, result TEXT, UNIQUE(event_id,horizon),
        FOREIGN KEY(event_id) REFERENCES scout_pre_pump_events(id))''')
    con.execute('CREATE INDEX IF NOT EXISTS idx_pre_pump_outcomes_horizon_result ON scout_pre_pump_outcomes(horizon,result)')

    # V23.0.125: direction-aware result migration. Raw prices, timestamps and
    # returns are preserved; only the derived outcome labels are reclassified.
    pre_cols = {row[1] for row in con.execute('PRAGMA table_info(scout_pre_pump_events)')}
    migrations = {
        'event_type': "TEXT NOT NULL DEFAULT 'pump'",
        'signal_direction': "TEXT NOT NULL DEFAULT 'up'",
        'pre_dump_score': 'REAL',
        'sell_pressure_ratio': 'REAL',
        'sell_pressure_change': 'REAL',
    }
    for name, decl in migrations.items():
        if name not in pre_cols:
            con.execute(f'ALTER TABLE scout_pre_pump_events ADD COLUMN {name} {decl}')
    con.execute("UPDATE scout_pre_pump_events SET event_type='pump', signal_direction='up' WHERE event_type IS NULL OR event_type=''")
    con.execute('CREATE INDEX IF NOT EXISTS idx_pre_move_type_ts ON scout_pre_pump_events(event_type,spotted_ts)')

    con.execute('CREATE TABLE IF NOT EXISTS scout_learning_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
    migration = con.execute("SELECT value FROM scout_learning_meta WHERE key='directional_outcomes_v1'").fetchone()
    if not migration:
        old_rows = con.execute("""SELECT o.id,o.horizon,o.return_pct,s.direction FROM scout_outcomes o
                                  JOIN scout_sightings s ON s.id=o.sighting_id
                                  WHERE o.return_pct IS NOT NULL AND o.result IN ('success','fake','neutral')""").fetchall()
        for row in old_rows:
            label = _directional_outcome(row['direction'], float(row['return_pct']), row['horizon'])
            con.execute('UPDATE scout_outcomes SET result=? WHERE id=?', (label, row['id']))
        old_pre_rows = con.execute("""SELECT o.id,o.horizon,o.return_pct,e.event_type,e.signal_direction
                                  FROM scout_pre_pump_outcomes o JOIN scout_pre_pump_events e ON e.id=o.event_id
                                  WHERE o.return_pct IS NOT NULL AND o.result IN ('success','fake','neutral')""").fetchall()
        for row in old_pre_rows:
            direction = 'down' if str(row['event_type']).lower() == 'dump' else row['signal_direction']
            label = _directional_outcome(direction, float(row['return_pct']), row['horizon'])
            con.execute('UPDATE scout_pre_pump_outcomes SET result=? WHERE id=?', (label, row['id']))
        con.execute("INSERT OR REPLACE INTO scout_learning_meta(key,value) VALUES('directional_outcomes_v1','complete')")
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def _finite_positive(value) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if math.isfinite(number) and number > 0 else None


def _finite_number(value) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if math.isfinite(number) else None


def _symbol(value) -> str:
    raw = str(value or '').upper().strip().replace(' ', '')
    raw = raw.replace('/', '').replace('-', '').replace('_', '')
    if raw.endswith('USDT') and len(raw) > 4:
        return raw
    if raw and raw.isalnum():
        return raw + 'USDT'
    return ''


def _market_regime(item: dict) -> str:
    """Return only the explicitly observed BTC 4h regime; unknown stays unknown."""
    features = item.get('features') or {}
    candidates = [item.get('btc_regime_4h')]
    if isinstance(features, dict):
        candidates.append(features.get('btc_regime_4h'))
    for value in candidates:
        if isinstance(value, dict):
            value = value.get('state')
        state = str(value or '').strip().lower()
        if state in ('up', 'down', 'neutral'):
            return state.upper()
    return 'UNKNOWN'


def _normalize_direction(direction: str | None) -> str:
    value = str(direction or '').strip().lower()
    if value in ('down', 'bear', 'bearish', 'sell', 'short'):
        return 'down'
    if value in ('up', 'bull', 'bullish', 'buy', 'long'):
        return 'up'
    return 'unknown'


def _directional_outcome(direction: str, return_pct: float, horizon: str) -> str:
    """Classify by predicted side; unknown direction is never assumed bullish."""
    side = _normalize_direction(direction)
    if side == 'unknown':
        return 'neutral'
    aligned_return = -float(return_pct) if side == 'down' else float(return_pct)
    target = float(SUCCESS_RETURN_PCT[horizon])
    adverse = abs(float(FAIL_RETURN_PCT))
    return 'success' if aligned_return >= target else 'fake' if aligned_return <= -adverse else 'neutral'


def record_scan(items: list[dict], timestamp: float | None = None, snapshots: dict | None = None) -> dict:
    ts = _finite_positive(timestamp if timestamp is not None else time.time())
    if ts is None:
        raise ValueError('timestamp باید عدد مثبت و متناهی باشد')
    inserted = 0
    rejected = 0
    pre_pump_recorded = 0
    with _db() as con:
        # Record broad market prices too, so a tracked candidate can be evaluated
        # even after it drops out of the visible top-candidate list.
        for base, quote in (snapshots or {}).items():
            try:
                symbol = _symbol(base)
                price = _finite_positive(quote.get('price'))
                if symbol and price is not None:
                    con.execute('INSERT OR IGNORE INTO scout_price_observations(symbol,ts,price) VALUES(?,?,?)',
                                (symbol, ts, price))
            except (AttributeError, TypeError, ValueError):
                continue
        for item in items:
            symbol = _symbol(item.get('symbol'))
            price = _finite_positive(item.get('price'))
            try:
                score = float(item.get('score'))
            except (TypeError, ValueError, OverflowError):
                score = float('nan')
            if not symbol or price is None or not math.isfinite(score) or not (0 <= score <= 100):
                rejected += 1
                continue
            feats = item.get('features') or {}
            mtf = (feats.get('mtf') or {}) if isinstance(feats, dict) else {}
            pattern = '|'.join((str(item.get('phase') or 'unknown'), str(item.get('direction') or 'unknown'),
                                str(mtf.get('status') or 'na'), 'fresh' if item.get('fresh') else 'not_fresh'))
            cur = con.execute('''INSERT OR IGNORE INTO scout_sightings
                (symbol,ts,price,score,phase,direction,verified,pattern,market_regime) VALUES(?,?,?,?,?,?,?,?,?)''',
                (symbol, ts, price, score, str(item.get('phase') or 'unknown'),
                 str(item.get('direction') or 'unknown'), int(bool(item.get('verified'))), pattern,
                 _market_regime(item)))
            inserted += max(cur.rowcount, 0)
            con.execute('INSERT OR IGNORE INTO scout_price_observations(symbol,ts,price) VALUES(?,?,?)',
                        (symbol, ts, price))
            # SQLite may retain a previous lastrowid after INSERT OR IGNORE.
            # Create outcomes only when this exact sighting was inserted.
            if cur.rowcount == 1:
                sighting_id = cur.lastrowid
                for horizon, seconds in HORIZONS.items():
                    con.execute('INSERT OR IGNORE INTO scout_outcomes(sighting_id,horizon,due_ts) VALUES(?,?,?)',
                                (sighting_id, horizon, ts + seconds))
            # Record either side of the early-move detector. Opposite directions
            # are separate event types so a bearish setup is never scored as a failed pump.
            # The early volume-flow detector has its own direction. It must not
            # inherit / be vetoed by the separate general-purpose trend label.
            pump_candidate = bool(item.get('pre_pump_candidate'))
            dump_candidate = bool(item.get('pre_dump_candidate'))
            if pump_candidate or dump_candidate:
                event_type = 'dump' if dump_candidate and (not pump_candidate or float(item.get('pre_dump_score') or 0) >= float(item.get('pre_pump_score') or 0)) else 'pump'
                direction = 'down' if event_type == 'dump' else 'up'
                last_event = con.execute("""SELECT id FROM scout_pre_pump_events
                    WHERE symbol=? AND event_type=? AND spotted_ts>? ORDER BY spotted_ts DESC LIMIT 1""",
                    (symbol, event_type, ts - 86400.0)).fetchone()
                if last_event is None:
                    grade_key = 'pre_dump_grade' if event_type == 'dump' else 'pre_pump_grade'
                    score_key = 'pre_dump_score' if event_type == 'dump' else 'pre_pump_score'
                    move_key = 'pre_dump_price_change_1h_pct' if event_type == 'dump' else 'pre_pump_price_change_1h_pct'
                    grade = str(item.get(grade_key) or 'unknown')
                    if grade not in ('exchange_taker', 'candle_proxy'):
                        grade = 'unknown'
                    pre_score = _finite_number(item.get(score_key)) or 0.0
                    # Legacy columns keep the signal-aligned pressure for
                    # downstream compatibility; explicit sell columns retain
                    # the raw bearish evidence as well.
                    aligned_pressure = item.get('sell_pressure_ratio') if event_type == 'dump' else item.get('buy_pressure_ratio')
                    aligned_pressure_change = item.get('sell_pressure_change') if event_type == 'dump' else item.get('buy_pressure_change')
                    metrics = [
                        _finite_number(item.get('volume_acceleration_ratio')),
                        _finite_number(item.get('recent_volume_ratio')),
                        _finite_number(aligned_pressure),
                        _finite_number(aligned_pressure_change),
                        _finite_number(item.get('flow_persistence')),
                        _finite_number(item.get(move_key)),
                    ]
                    relative_strength = _finite_number(item.get('relative_strength_score'))
                    if relative_strength is not None and not 0.0 <= relative_strength <= 100.0:
                        relative_strength = None
                    event_cur = con.execute("""INSERT OR IGNORE INTO scout_pre_pump_events
                        (symbol,spotted_ts,price,scout_score,pre_pump_score,flow_grade,
                         volume_acceleration_ratio,recent_volume_ratio,buy_pressure_ratio,
                         buy_pressure_change,flow_persistence,price_change_1h_pct,market_regime,
                         relative_strength_score,event_type,signal_direction,pre_dump_score,
                         sell_pressure_ratio,sell_pressure_change)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (symbol, ts, price, score, pre_score, grade, *metrics, _market_regime(item),
                         relative_strength, event_type, direction,
                         _finite_number(item.get('pre_dump_score')) if event_type == 'dump' else None,
                         _finite_number(item.get('sell_pressure_ratio')),
                         _finite_number(item.get('sell_pressure_change'))))
                    if event_cur.rowcount == 1:
                        pre_pump_recorded += 1
                        for horizon, seconds in HORIZONS.items():
                            con.execute("""INSERT OR IGNORE INTO scout_pre_pump_outcomes
                                (event_id,horizon,due_ts) VALUES(?,?,?)""",
                                (event_cur.lastrowid, horizon, ts + seconds))
        # Resolve each due event against the first later real observation, with a bounded delay.
        pending = con.execute('''SELECT o.id,o.horizon,o.due_ts,s.symbol,s.ts,s.price,s.id AS sid,s.direction
            FROM scout_outcomes o JOIN scout_sightings s ON s.id=o.sighting_id
            WHERE o.resolved_ts IS NULL AND o.due_ts <= ? ORDER BY o.due_ts LIMIT 5000''', (ts,)).fetchall()
        resolved = 0
        for row in pending:
            horizon = row['horizon']; seconds = HORIZONS[horizon]
            max_lag = max(7200, seconds * 0.30)
            if ts > row['due_ts'] + max_lag:
                # Do not label an old candidate using a very late, unrelated price.
                con.execute("UPDATE scout_outcomes SET result='missing_observation' WHERE id=?", (row['id'],))
                continue
            obs = con.execute('''SELECT price,ts FROM scout_price_observations WHERE symbol=? AND ts>=? AND ts<=?
                ORDER BY ts LIMIT 1''', (row['symbol'], row['due_ts'], ts)).fetchone()
            if not obs:
                continue
            ret = (float(obs['price']) / float(row['price']) - 1.0) * 100.0
            result = _directional_outcome(row['direction'], ret, horizon)
            con.execute('UPDATE scout_outcomes SET resolved_ts=?,return_pct=?,result=? WHERE id=?',
                        (float(obs['ts']), ret, result, row['id']))
            resolved += 1
        # Resolve the independent pre-pump episode ledger from the same real
        # timestamped price observations; never infer an unobserved intrabar path.
        pre_pump_pending = con.execute('''SELECT o.id,o.horizon,o.due_ts,e.symbol,e.price,e.event_type,e.signal_direction
            FROM scout_pre_pump_outcomes o JOIN scout_pre_pump_events e ON e.id=o.event_id
            WHERE o.resolved_ts IS NULL AND o.result IS NULL AND o.due_ts<=?
            ORDER BY o.due_ts LIMIT 5000''', (ts,)).fetchall()
        pre_pump_resolved = 0
        for row in pre_pump_pending:
            seconds = HORIZONS[row['horizon']]
            max_lag = max(7200, seconds * 0.30)
            if ts > row['due_ts'] + max_lag:
                con.execute("UPDATE scout_pre_pump_outcomes SET result='missing_observation' WHERE id=?",
                            (row['id'],))
                continue
            obs = con.execute('''SELECT price,ts FROM scout_price_observations
                WHERE symbol=? AND ts>=? AND ts<=? ORDER BY ts LIMIT 1''',
                (row['symbol'], row['due_ts'], ts)).fetchone()
            if obs is None:
                continue
            ret = (float(obs['price']) / float(row['price']) - 1.0) * 100.0
            direction = 'down' if row['event_type'] == 'dump' else row['signal_direction']
            result = _directional_outcome(direction, ret, row['horizon'])
            con.execute('''UPDATE scout_pre_pump_outcomes SET resolved_ts=?,return_pct=?,result=? WHERE id=?''',
                        (float(obs['ts']), ret, result, row['id']))
            pre_pump_resolved += 1
        return {'recorded': inserted, 'resolved': resolved, 'rejected': rejected,
                'pre_pump_events_recorded': pre_pump_recorded,
                'pre_pump_outcomes_resolved': pre_pump_resolved}


def _stats(con, symbol: str | None = None, direction: str | None = None) -> dict:
    clauses, args = [], []
    if symbol is not None:
        clauses.append('s.symbol=?'); args.append(symbol)
    normalized_direction = _normalize_direction(direction) if direction is not None else None
    if normalized_direction == 'unknown':
        return {h: {'samples': 0, 'successes': 0, 'fake_moves': 0, 'win_rate': None,
                    'avg_return_pct': None, 'avg_directional_return_pct': None,
                    'avg_market_return_pct': None, 'up_samples': 0, 'down_samples': 0}
                for h in HORIZONS}
    where = (' WHERE ' + ' AND '.join(clauses)) if clauses else ''
    rows = con.execute('''SELECT o.horizon,o.result,o.return_pct,s.direction FROM scout_outcomes o
        JOIN scout_sightings s ON s.id=o.sighting_id''' + where, args).fetchall()
    if normalized_direction is not None:
        rows = [r for r in rows if _normalize_direction(r['direction']) == normalized_direction]
    out = {}
    for horizon in HORIZONS:
        vals = [r for r in rows if r['horizon'] == horizon and r['result'] in ('success','fake','neutral')
                and _normalize_direction(r['direction']) != 'unknown']
        wins = sum(r['result'] == 'success' for r in vals)
        raw_returns = [float(r['return_pct']) for r in vals if r['return_pct'] is not None]
        aligned_returns = [(-float(r['return_pct']) if _normalize_direction(r['direction']) == 'down' else float(r['return_pct']))
                           for r in vals if r['return_pct'] is not None and _normalize_direction(r['direction']) != 'unknown']
        out[horizon] = {'samples': len(vals), 'successes': wins,
                        'fake_moves': sum(r['result'] == 'fake' for r in vals),
                        'win_rate': round(wins / len(vals), 3) if vals else None,
                        # avg_return_pct is direction-adjusted for legacy consumers;
                        # raw_market_return_pct remains available for transparency.
                        'avg_return_pct': round(mean(aligned_returns), 3) if aligned_returns else None,
                        'avg_directional_return_pct': round(mean(aligned_returns), 3) if aligned_returns else None,
                        'avg_market_return_pct': round(mean(raw_returns), 3) if raw_returns else None,
                        'up_samples': sum(_normalize_direction(r['direction']) == 'up' for r in vals),
                        'down_samples': sum(_normalize_direction(r['direction']) == 'down' for r in vals)}
    return out


def annotate(items: list[dict]) -> list[dict]:
    with _db() as con:
        for item in items:
            symbol = _symbol(item.get('symbol'))
            stats = _stats(con, symbol)
            signal_direction = _normalize_direction(item.get('direction'))
            directional_stats = _stats(con, symbol, signal_direction)
            four = directional_stats['4h']
            star = bool(signal_direction in ('up', 'down') and
                        four['samples'] >= STAR_MIN_SAMPLES and four['win_rate'] is not None
                        and four['win_rate'] >= STAR_MIN_WIN_RATE and
                        (four.get('avg_directional_return_pct') or 0) > 0)
            item['learning'] = {'horizons': stats, 'directional_horizons': directional_stats,
                                'signal_direction': signal_direction, 'star': star,
                                'star_reason': ('یک ستاره طلایی فقط برای همین جهت: حداقل ۱۰ نمونه ۴ساعته، موفقیت ≥۶۵٪ و میانگین بازده هم‌جهت مثبت' if star else
                                                'بدون ستاره؛ عملکرد جهت مخالف به این سیگنال منتقل نمی‌شود و شواهد همین جهت هنوز کافی نیست')}
            direction = 'صعودی' if item.get('direction') == 'up' else 'نزولی'
            feats = item.get('features') or {}
            continuation = ('حفظ شکست و تداوم حجم بالاتر از میانگین' if item.get('direction') == 'up'
                            else 'حفظ شکست نزولی و تداوم فشار فروش')
            invalidation = ('بازگشت قیمت زیر ناحیه شکست یا افت محسوس حجم' if item.get('direction') == 'up'
                            else 'بازگشت قیمت بالای ناحیه شکست یا برگشت فشار خرید')
            if not item.get('verified'):
                scenario = 'داده کندلی کافی نیست؛ سناریوی فردا قابل اتکا نیست'
            elif item.get('phase') in ('late', 'exhausted'):
                scenario = f'ریسک فرسودگی حرکت {direction} بالاست؛ دنبال‌کردن قیمت می‌تواند دیرهنگام باشد'
            else:
                scenario = f'سناریوی ۲۴ساعته {direction} مشروط به {continuation}؛ ابطال با {invalidation}'
            item['outlook'] = {'direction': direction, 'summary': scenario,
                'status': 'سناریو، نه پیش‌بینی قطعی' if item.get('verified') else 'تأییدنشده؛ بدون برآورد قابل اتکا',
                'horizons': {'1h': 'در انتظار مشاهده قیمت واقعی', '4h': 'در انتظار مشاهده قیمت واقعی',
                             '24h': 'سناریوی مشروط؛ نتیجه پس از مشاهده ثبت می‌شود'}}
    return items


def directional_performance_report() -> dict:
    """Observed recommendation performance split by side and fixed horizons.

    Only resolved outcomes backed by a later price observation enter the
    success-rate denominator. Pending and missing observations stay separate.
    This report is descriptive and never tunes weights or issues trade signals.
    """
    with _db() as con:
        rows = con.execute("""SELECT s.direction,o.horizon,o.result,o.return_pct
            FROM scout_outcomes o JOIN scout_sightings s ON s.id=o.sighting_id""").fetchall()
    report = {}
    for direction in ('up', 'down'):
        report[direction] = {}
        for horizon in HORIZONS:
            subset = [r for r in rows if r['horizon'] == horizon
                      and _normalize_direction(r['direction']) == direction]
            valid = [r for r in subset if r['result'] in ('success', 'fake', 'neutral')]
            wins = sum(r['result'] == 'success' for r in valid)
            directional_returns = [(-float(r['return_pct']) if direction == 'down' else float(r['return_pct']))
                                   for r in valid if r['return_pct'] is not None]
            low, high = _wilson_interval(wins, len(valid))
            n = len(valid)
            report[direction][horizon] = {
                'samples': n, 'successes': wins,
                'failures': sum(r['result'] == 'fake' for r in valid),
                'neutral': sum(r['result'] == 'neutral' for r in valid),
                'pending': sum(r['result'] is None for r in subset),
                'missing_observations': sum(r['result'] == 'missing_observation' for r in subset),
                'success_rate': round(wins / n, 4) if n else None,
                'success_rate_ci95': [round(low, 4), round(high, 4)] if low is not None else None,
                'avg_directional_return_pct': round(mean(directional_returns), 4) if directional_returns else None,
                'evidence_level': 'insufficient' if n < 10 else 'preliminary' if n < 30 else 'reviewable',
            }
    return {
        'horizons_seconds': HORIZONS.copy(),
        'directions': report,
        'sample_policy': 'فقط نتایج واقعی resolve شده وارد نرخ موفقیت می‌شوند؛ pending و missing جدا هستند.',
        'threshold_policy': 'fixed_no_auto_adjustment',
        'paper_only': True,
        'note': 'بازده هم‌جهت برای نزولی برابر منفی بازده خام بازار است. گزارش توصیفی است و به‌تنهایی سیگنال یا سفارش ایجاد نمی‌کند.',
    }



def failure_pattern_audit(min_samples: int = 5, limit: int = 20) -> dict:
    """Describe recurring failure contexts from resolved, observed Scout outcomes.

    This is an audit only: it never changes scores, thresholds, or trade state.
    Groups are split by direction, horizon, phase, market regime and score band.
    """
    try:
        min_samples, limit = int(min_samples), int(limit)
    except (TypeError, ValueError):
        raise ValueError('min_samples و limit باید عدد صحیح باشند')
    if not 2 <= min_samples <= 1000 or not 1 <= limit <= 100:
        raise ValueError('محدوده min_samples یا limit نامعتبر است')
    with _db() as con:
        rows = con.execute("""SELECT s.direction,s.phase,s.market_regime,s.score,
                o.horizon,o.result FROM scout_outcomes o
            JOIN scout_sightings s ON s.id=o.sighting_id
            WHERE o.result IN ('success','fake','neutral')
            ORDER BY o.resolved_ts DESC""").fetchall()
    groups = defaultdict(list)
    baselines = defaultdict(list)
    for row in rows:
        direction = _normalize_direction(row['direction'])
        if direction == 'unknown':
            continue
        score = float(row['score'])
        score_band = 'low' if score < 40 else 'medium' if score < 70 else 'high'
        horizon = str(row['horizon'])
        outcome = str(row['result'])
        baselines[(direction, horizon)].append(outcome)
        key = (direction, horizon, str(row['phase'] or 'unknown'),
               str(row['market_regime'] or 'UNKNOWN'), score_band)
        groups[key].append(outcome)
    baseline_report = []
    for (direction, horizon), outcomes in sorted(baselines.items()):
        wins, failures, neutral = outcomes.count('success'), outcomes.count('fake'), outcomes.count('neutral')
        decisive = wins + failures
        baseline_report.append({'direction': direction, 'horizon': horizon,
            'samples': len(outcomes), 'decisive_samples': decisive,
            'successes': wins, 'failures': failures, 'neutral': neutral,
            'failure_rate': round(failures / decisive, 4) if decisive else None})
    patterns = []
    for (direction, horizon, phase, regime, score_band), outcomes in groups.items():
        n = len(outcomes)
        if n < min_samples:
            continue
        wins, failures, neutral = outcomes.count('success'), outcomes.count('fake'), outcomes.count('neutral')
        decisive = wins + failures
        patterns.append({
            'direction': direction, 'horizon': horizon, 'phase': phase,
            'market_regime': regime, 'score_band': score_band,
            'samples': n, 'successes': wins, 'failures': failures, 'neutral': neutral,
            'failure_rate': round(failures / decisive, 4) if decisive else None,
            'success_rate': round(wins / decisive, 4) if decisive else None,
            'evidence_level': 'preliminary' if n < 10 else 'reviewable',
            'diagnosis': 'recurring_failure_context' if decisive and failures / decisive >= 0.5 else 'mixed_or_non_failure',
        })
    patterns.sort(key=lambda x: (x['failures'], x['samples'], x['failure_rate'] or 0), reverse=True)
    return {'status': 'completed', 'patterns': patterns[:limit], 'baseline': baseline_report,
            'groups_examined': len(groups), 'groups_meeting_min_samples': len(patterns),
            'min_samples': min_samples, 'limit': limit,
            'policy': 'descriptive_only_no_auto_weight_or_threshold_changes',
            'paper_only': True,
            'note': 'الگوهای شکست از نتایج واقعی ثبت‌شده استخراج می‌شوند؛ همبستگی به‌تنهایی علت شکست را اثبات نمی‌کند.'}


def summary() -> dict:
    with _db() as con:
        all_stats = _stats(con)
        counts = con.execute("SELECT result,COUNT(*) AS n FROM scout_outcomes GROUP BY result").fetchall()
        direction_counts = con.execute("""SELECT s.direction,o.result,COUNT(*) AS n FROM scout_outcomes o
            JOIN scout_sightings s ON s.id=o.sighting_id GROUP BY s.direction,o.result""").fetchall()
        sightings = con.execute('SELECT COUNT(*) FROM scout_sightings').fetchone()[0]
    with _db() as con:
        pending = con.execute("SELECT COUNT(*) FROM scout_outcomes WHERE resolved_ts IS NULL AND result IS NULL").fetchone()[0]
        missing = con.execute("SELECT COUNT(*) FROM scout_outcomes WHERE result='missing_observation'").fetchone()[0]
        observation_count = con.execute('SELECT COUNT(*) FROM scout_price_observations').fetchone()[0]
    early_report = pre_pump_performance_report()
    return {'sightings': sightings, 'price_observations': observation_count,
            'pending_outcomes': pending, 'missing_observations': missing,
            'outcomes': {r['result']: r['n'] for r in counts},
            'directional_outcomes': {f"{str(r['direction']).lower()}:{r['result']}": int(r['n']) for r in direction_counts},
            'horizons': all_stats, 'directional_performance': directional_performance_report(), 'star_min_samples': STAR_MIN_SAMPLES,
            'star_min_win_rate': STAR_MIN_WIN_RATE,
            'pre_pump': early_report, 'early_moves': early_report,
            'note': 'موفقیت بر اساس جهت سیگنال محاسبه می‌شود: رشد برای سیگنال صعودی و افت برای سیگنال نزولی. داده کم یا گمشده موفقیت شمرده نمی‌شود.'}


def pre_pump_performance_report() -> dict:
    """Evaluate unique pre-pump episodes against later observed prices only."""
    with _db() as con:
        total_events = int(con.execute('SELECT COUNT(*) FROM scout_pre_pump_events').fetchone()[0])
        unique_symbols = int(con.execute('SELECT COUNT(DISTINCT symbol) FROM scout_pre_pump_events').fetchone()[0])
        recent_rows = con.execute('''SELECT e.id,e.symbol,e.spotted_ts,e.price,e.pre_pump_score,
            e.flow_grade,e.market_regime,e.event_type,e.signal_direction,e.pre_dump_score,
            o.horizon,o.result,o.return_pct,o.resolved_ts
            FROM scout_pre_pump_events e LEFT JOIN scout_pre_pump_outcomes o ON o.event_id=e.id
            ORDER BY e.spotted_ts DESC,e.id DESC LIMIT 120''').fetchall()
        event_metrics = con.execute('''SELECT event_type,flow_grade,COUNT(*) AS n,AVG(pre_pump_score) AS avg_score
            FROM scout_pre_pump_events GROUP BY event_type,flow_grade''').fetchall()
        horizon_rows = con.execute('''SELECT o.horizon,o.result,o.return_pct,e.flow_grade,e.pre_pump_score,
            e.volume_acceleration_ratio,e.buy_pressure_ratio,e.buy_pressure_change,
            e.relative_strength_score,e.market_regime,e.event_type,e.signal_direction,
            e.pre_dump_score,e.sell_pressure_ratio,e.sell_pressure_change
            FROM scout_pre_pump_outcomes o JOIN scout_pre_pump_events e ON e.id=o.event_id''').fetchall()
    horizons = {}
    for horizon in HORIZONS:
        values = [r for r in horizon_rows if r['horizon'] == horizon]
        valid = [r for r in values if r['result'] in ('success', 'fake', 'neutral')
                 and _normalize_direction(r['signal_direction']) != 'unknown']
        wins = sum(r['result'] == 'success' for r in valid)
        raw_returns = [float(r['return_pct']) for r in valid if r['return_pct'] is not None]
        directional_returns = [(-float(r['return_pct']) if _normalize_direction(r['signal_direction']) == 'down' else float(r['return_pct']))
                                for r in valid if r['return_pct'] is not None and _normalize_direction(r['signal_direction']) != 'unknown']
        n = len(valid)
        lower, upper = _wilson_interval(wins, n)
        horizons[horizon] = {
            'samples': n, 'successes': wins,
            'fake_moves': sum(r['result'] == 'fake' for r in valid),
            'neutral': sum(r['result'] == 'neutral' for r in valid),
            'pending': sum(r['result'] is None for r in values),
            'missing_observations': sum(r['result'] == 'missing_observation' for r in values),
            'success_rate': round(wins / n, 3) if n else None,
            'success_rate_ci95': [round(lower, 3), round(upper, 3)] if lower is not None else None,
            'avg_return_pct': round(mean(directional_returns), 3) if directional_returns else None,
            'avg_directional_return_pct': round(mean(directional_returns), 3) if directional_returns else None,
            'avg_market_return_pct': round(mean(raw_returns), 3) if raw_returns else None,
            'evidence_level': 'insufficient' if n < 10 else 'preliminary' if n < 30 else 'reviewable'
        }
    flow_grades = {grade: {'events': 0, 'avg_pre_pump_score': None}
                   for grade in ('exchange_taker', 'candle_proxy', 'unknown')}
    event_types = {'pump': {'events': 0, 'avg_score': None}, 'dump': {'events': 0, 'avg_score': None}}
    for row in event_metrics:
        grade = str(row['flow_grade'])
        flow_grades.setdefault(grade, {'events': 0, 'avg_pre_pump_score': None})
        flow_grades[grade]['events'] += int(row['n'])
        event_types.setdefault(str(row['event_type']), {'events': 0, 'avg_score': None})
        event_types[str(row['event_type'])]['events'] += int(row['n'])
        if row['avg_score'] is not None:
            event_types[str(row['event_type'])]['avg_score'] = round(float(row['avg_score']), 2)
    for grade in flow_grades:
        matching = [r for r in event_metrics if str(r['flow_grade']) == grade]
        total = sum(int(r['n']) for r in matching)
        avg = (sum(float(r['avg_score']) * int(r['n']) for r in matching if r['avg_score'] is not None) /
               max(1, sum(int(r['n']) for r in matching if r['avg_score'] is not None)))
        flow_grades[grade] = {'events': total, 'avg_pre_pump_score': round(avg, 2) if matching else None}
    directional_horizons = {}
    for direction in ('up', 'down'):
        directional_horizons[direction] = {}
        for horizon in HORIZONS:
            subset = [r for r in horizon_rows
                      if r['horizon'] == horizon and (str(r['signal_direction']).lower() == direction)]
            valid = [r for r in subset if r['result'] in ('success', 'fake', 'neutral')]
            wins = sum(r['result'] == 'success' for r in valid)
            directional_horizons[direction][horizon] = {
                'samples': len(valid), 'successes': wins,
                'failures': sum(r['result'] == 'fake' for r in valid),
                'neutral': sum(r['result'] == 'neutral' for r in valid),
                'pending': sum(r['result'] is None for r in subset),
                'success_rate': round(wins / len(valid), 3) if valid else None,
                'avg_directional_return_pct': round(mean([
                    (-float(r['return_pct']) if direction == 'down' else float(r['return_pct']))
                    for r in valid if r['return_pct'] is not None]), 3)
                    if any(r['return_pct'] is not None for r in valid) else None,
            }

    # Descriptive cohorts help compare real taker evidence with candle proxies
    # and identify score bands; no cohort is allowed to tune thresholds here.
    flow_grade_horizons = {}
    score_band_horizons = {}
    for grade in flow_grades:
        flow_grade_horizons[grade] = {}
        for horizon in HORIZONS:
            rows = [r for r in horizon_rows if r['flow_grade'] == grade and r['horizon'] == horizon]
            valid = [r for r in rows if r['result'] in ('success', 'fake', 'neutral')]
            wins = sum(r['result'] == 'success' for r in valid)
            raw_returns = [float(r['return_pct']) for r in valid if r['return_pct'] is not None]
            returns = [(-float(r['return_pct']) if _normalize_direction(r['signal_direction']) == 'down' else float(r['return_pct']))
                       for r in valid if r['return_pct'] is not None and _normalize_direction(r['signal_direction']) != 'unknown']
            n = len(valid)
            flow_grade_horizons[grade][horizon] = {
                'samples': n, 'successes': wins,
                'success_rate': round(wins / n, 3) if n else None,
                'avg_return_pct': round(mean(returns), 3) if returns else None,
                'avg_directional_return_pct': round(mean(returns), 3) if returns else None,
                'avg_market_return_pct': round(mean(raw_returns), 3) if raw_returns else None,
                'pending': sum(r['result'] is None for r in rows),
                'missing_observations': sum(r['result'] == 'missing_observation' for r in rows),
                'evidence_level': 'insufficient' if n < 10 else 'preliminary' if n < 30 else 'reviewable'}
    score_band_keys = ('60-69', '70-79', '80+')
    for band in score_band_keys:
        score_band_horizons[band] = {}
        for horizon in HORIZONS:
            rows = []
            for r in horizon_rows:
                try:
                    score = float(r['pre_pump_score'])
                except (TypeError, ValueError, OverflowError):
                    continue
                row_band = '60-69' if score < 70 else '70-79' if score < 80 else '80+'
                if row_band == band and r['horizon'] == horizon:
                    rows.append(r)
            valid = [r for r in rows if r['result'] in ('success', 'fake', 'neutral')]
            wins = sum(r['result'] == 'success' for r in valid)
            n = len(valid)
            score_band_horizons[band][horizon] = {
                'samples': n, 'successes': wins,
                'success_rate': round(wins / n, 3) if n else None,
                'evidence_level': 'insufficient' if n < 10 else 'preliminary' if n < 30 else 'reviewable'}
    directional_score_band_horizons = {}
    for direction in ('up', 'down'):
        directional_score_band_horizons[direction] = {}
        for band in score_band_keys:
            directional_score_band_horizons[direction][band] = {}
            for horizon in HORIZONS:
                rows = []
                for r in horizon_rows:
                    row_direction = str(r['signal_direction'] or 'up').lower()
                    if row_direction != direction or r['horizon'] != horizon:
                        continue
                    try:
                        score = float(r['pre_pump_score'])
                    except (TypeError, ValueError, OverflowError):
                        continue
                    row_band = '60-69' if score < 70 else '70-79' if score < 80 else '80+'
                    if row_band == band:
                        rows.append(r)
                valid = [r for r in rows if r['result'] in ('success','fake','neutral')]
                wins = sum(r['result'] == 'success' for r in valid)
                directional_score_band_horizons[direction][band][horizon] = {
                    'samples': len(valid), 'successes': wins,
                    'success_rate': round(wins / len(valid), 3) if valid else None,
                    'pending': sum(r['result'] is None for r in rows),
                    'evidence_level': 'insufficient' if len(valid) < 10 else 'preliminary' if len(valid) < 30 else 'reviewable'}
    feature_combo_learning = _pre_pump_feature_combo_report(horizon_rows)
    recent = {}
    for row in recent_rows:
        event = recent.setdefault(int(row['id']), {
            'id': int(row['id']), 'symbol': row['symbol'], 'spotted_at': float(row['spotted_ts']),
            'spotted_price': float(row['price']), 'pre_pump_score': float(row['pre_pump_score']),
            'pre_dump_score': float(row['pre_dump_score']) if row['pre_dump_score'] is not None else None,
            'event_type': row['event_type'], 'direction': row['signal_direction'],
            'flow_grade': row['flow_grade'], 'market_regime': row['market_regime'], 'outcomes': {}})
        if row['horizon']:
            raw_return = float(row['return_pct']) if row['return_pct'] is not None else None
            direction = 'down' if str(row['signal_direction']).lower() == 'down' else 'up'
            event['outcomes'][row['horizon']] = {
                'result': row['result'],
                'return_pct': round(raw_return, 3) if raw_return is not None else None,
                'directional_return_pct': round(-raw_return if direction == 'down' else raw_return, 3) if raw_return is not None else None,
                'resolved_at': float(row['resolved_ts']) if row['resolved_ts'] is not None else None}
    return {
        'total_events': total_events, 'unique_symbols': unique_symbols,
        'event_types': event_types, 'directional_horizons': directional_horizons,
        'horizons': horizons, 'flow_grades': flow_grades,
        'flow_grade_horizons': flow_grade_horizons,
        'score_band_horizons': score_band_horizons,
        'directional_score_band_horizons': directional_score_band_horizons,
        'feature_combo_learning': feature_combo_learning,
        'recent_events': list(recent.values())[:12],
        'minimum_samples_for_review': 30,
        'threshold_policy': 'fixed_no_auto_adjustment',
        'threshold_policy_note': 'آستانه پیش‌نشانگر خودکار تغییر نمی‌کند؛ بازبینی فقط پس از حداقل ۳۰ نتیجه معتبر در هر افق و بررسی خارج از نمونه مجاز است.',
        'deduplication_window_hours': 24,
        'early_move_types': ['pump', 'dump'],
        'note': 'این گزارش هر دو جهت را مستقل ارزیابی می‌کند: پامپ با رشد هم‌جهت و دامپ با افت هم‌جهت؛ avg_return_pct هم‌جهت است و avg_market_return_pct بازده خام بازار را نشان می‌دهد. داده مفقود موفقیت نیست.'
    }



def _pre_pump_feature_bands(row) -> tuple[str, str, str]:
    """Convert stored early-pump OR early-dump evidence into coarse buckets."""
    volume = _finite_number(row['volume_acceleration_ratio'])
    if volume is None or volume <= 0:
        volume_band = 'unknown'
    elif volume >= 1.50:
        volume_band = 'strong'
    elif volume >= 1.15:
        volume_band = 'rising'
    else:
        volume_band = 'low'

    direction = str(row['signal_direction'] or 'up').lower() if 'signal_direction' in row.keys() else 'up'
    if direction == 'down' and 'sell_pressure_ratio' in row.keys():
        pressure = _finite_number(row['sell_pressure_ratio'])
        pressure_change = _finite_number(row['sell_pressure_change'])
    else:
        pressure = _finite_number(row['buy_pressure_ratio'])
        pressure_change = _finite_number(row['buy_pressure_change'])
    if pressure is None or pressure_change is None:
        pressure_band = 'unknown'
    elif pressure >= 0.65 and pressure_change >= 0.05:
        pressure_band = 'strong'
    elif pressure >= 0.57 and pressure_change >= 0.02:
        pressure_band = 'rising'
    else:
        pressure_band = 'weak'

    strength = _finite_number(row['relative_strength_score'])
    if strength is None or not 0.0 <= strength <= 100.0:
        strength_band = 'unknown'
    elif strength >= 70.0:
        strength_band = 'leader'
    elif strength >= 40.0:
        strength_band = 'middle'
    else:
        strength_band = 'lagging'
    return volume_band, pressure_band, strength_band


def _pre_pump_feature_combo_report(horizon_rows) -> dict:
    """Describe outcomes by combined volume, buy-pressure and peer-strength bands.

    This is observational learning only. It intentionally never writes learned
    weights or changes the detector thresholds / trading eligibility.
    """
    labels = {
        'strong': 'شتاب حجم قوی', 'rising': 'شتاب حجم رو به افزایش',
        'low': 'شتاب حجم پایین', 'unknown': 'شتاب حجم نامشخص',
    }
    buy_labels = {
        'strong': 'فشار خرید قوی', 'rising': 'فشار خرید رو به افزایش',
        'weak': 'فشار خرید ضعیف', 'unknown': 'فشار خرید نامشخص',
    }
    strength_labels = {
        'leader': 'قدرت نسبی بالا', 'middle': 'قدرت نسبی متوسط',
        'lagging': 'قدرت نسبی پایین', 'unknown': 'قدرت نسبی ثبت‌نشده',
    }
    regime_labels = {
        'UP': 'بازار صعودی', 'DOWN': 'بازار نزولی',
        'NEUTRAL': 'بازار خنثی', 'UNKNOWN': 'وضعیت بازار نامشخص',
    }
    grouped = defaultdict(list)
    for row in horizon_rows:
        volume_band, buy_band, strength_band = _pre_pump_feature_bands(row)
        grade = str(row['flow_grade'] or 'unknown')
        regime = str(row['market_regime'] or 'UNKNOWN').strip().upper()
        if regime not in regime_labels:
            regime = 'UNKNOWN'
        # Keep unknown regimes separate: never blend them into a known BTC regime.
        direction = str(row['signal_direction'] or 'up').lower()
        key = (direction, regime, grade, volume_band, buy_band, strength_band)
        grouped[key].append(row)

    cohorts = []
    for (direction, regime, grade, volume_band, buy_band, strength_band), rows in grouped.items():
        by_horizon = {}
        for horizon in HORIZONS:
            matching = [r for r in rows if r['horizon'] == horizon]
            valid = [r for r in matching if r['result'] in ('success', 'fake', 'neutral')]
            wins = sum(r['result'] == 'success' for r in valid)
            failures = sum(r['result'] == 'fake' for r in valid)
            raw_returns = [float(r['return_pct']) for r in valid if r['return_pct'] is not None]
            returns = [(-float(r['return_pct']) if direction == 'down' else float(r['return_pct']))
                       for r in valid if r['return_pct'] is not None]
            n = len(valid)
            lower, upper = _wilson_interval(wins, n)
            by_horizon[horizon] = {
                'samples': n, 'successes': wins, 'failures': failures,
                'neutral': sum(r['result'] == 'neutral' for r in valid),
                'pending': sum(r['result'] is None for r in matching),
                'success_rate': round(wins / n, 3) if n else None,
                'success_rate_ci95': [round(lower, 3), round(upper, 3)] if lower is not None else None,
                'avg_return_pct': round(mean(returns), 3) if returns else None,
                'avg_directional_return_pct': round(mean(returns), 3) if returns else None,
                'avg_market_return_pct': round(mean(raw_returns), 3) if raw_returns else None,
                'evidence_level': 'insufficient' if n < 10 else 'preliminary' if n < 30 else 'reviewable',
            }
        resolved_total = sum(by_horizon[h]['samples'] for h in HORIZONS)
        cohorts.append({
            'key': '|'.join((direction, regime, grade, volume_band, buy_band, strength_band)),
            'market_regime': regime,
            'market_regime_label_fa': regime_labels[regime],
            'flow_grade': grade,
            'volume_band': volume_band,
            'direction': direction,
            'event_type': 'dump' if direction == 'down' else 'pump',
            'pressure_side': 'sell' if direction == 'down' else 'buy',
            'buy_pressure_band': buy_band,
            'pressure_band': buy_band,
            'relative_strength_band': strength_band,
            'label_fa': ' + '.join((labels[volume_band],
                ('فشار فروش ' if direction == 'down' else 'فشار خرید ') + {'strong':'قوی','rising':'رو به افزایش','weak':'ضعیف','unknown':'نامشخص'}[buy_band],
                strength_labels[strength_band])),
            'flow_label_fa': 'تیکر واقعی' if grade == 'exchange_taker' else 'پروکسی کندلی' if grade == 'candle_proxy' else 'منبع نامشخص',
            'horizons': by_horizon,
            'resolved_outcomes_across_horizons': resolved_total,
        })
    cohorts.sort(key=lambda c: (c['resolved_outcomes_across_horizons'],
                                c['horizons']['24h']['samples'],
                                c['horizons']['24h']['success_rate'] or -1), reverse=True)
    regime_counts = {}
    for cohort in cohorts:
        regime = cohort['market_regime']
        regime_counts[regime] = regime_counts.get(regime, 0) + 1
    return {
        'cohorts': cohorts[:60],
        'cohort_count': len(cohorts),
        'regime_cohort_counts': regime_counts,
        'regime_labels_fa': regime_labels,
        'minimum_samples_for_review': 30,
        'evidence_levels': {'insufficient': '<10 نتیجه معتبر', 'preliminary': '۱۰ تا ۲۹ نتیجه معتبر',
                            'reviewable': 'حداقل ۳۰ نتیجه معتبر'},
        'threshold_policy': 'descriptive_only_no_auto_tuning',
        'note': 'ترکیب شتاب حجم، فشار خرید برای پامپ و فشار فروش برای دامپ، همراه قدرت نسبی فقط از داده‌های زمان شناسایی گروه‌بندی می‌شود؛ جهت‌ها جدا هستند و هر افق جدا ارزیابی می‌شود. وضعیت بازار نامشخص با رژیم‌های شناخته‌شده ادغام نمی‌شود.',
    }

def _wilson_interval(wins: int, samples: int, z: float = 1.96) -> tuple[float, float] | tuple[None, None]:
    """Two-sided Wilson score interval for a binomial success rate."""
    if samples <= 0:
        return None, None
    p = max(0.0, min(float(wins), float(samples))) / float(samples)
    z2 = z * z
    denom = 1.0 + z2 / samples
    center = (p + z2 / (2.0 * samples)) / denom
    margin = (z * math.sqrt((p * (1.0 - p) / samples) + z2 / (4.0 * samples * samples))) / denom
    return max(0.0, center - margin), min(1.0, center + margin)


def followups(limit: int = 40) -> dict:
    """Direction-aware outcomes for bullish and bearish Scout recommendations."""
    try:
        limit = max(1, min(100, int(limit)))
    except (TypeError, ValueError):
        limit = 40
    with _db() as con:
        rows = con.execute('''SELECT s.id AS sighting_id,s.symbol,s.ts AS spotted_ts,s.price AS spotted_price,
            s.score,s.phase,s.direction,s.market_regime,o.horizon,o.resolved_ts,o.return_pct,o.result
            FROM scout_outcomes o JOIN scout_sightings s ON s.id=o.sighting_id
            WHERE o.resolved_ts IS NOT NULL AND o.result IN ('success','fake','neutral')
            ORDER BY o.resolved_ts DESC LIMIT ?''', (limit,)).fetchall()
    events = []
    recoveries = []
    delayed_pumps, delayed_dumps = [], []
    for r in rows:
        ret = float(r['return_pct']) if r['return_pct'] is not None else None
        direction = _normalize_direction(r['direction'])
        directional_return = (-ret if direction == 'down' else ret) if ret is not None else None
        delayed = r['horizon'] in ('3d', '7d') and r['result'] == 'success'
        adverse_excursion = None
        if r['horizon'] in ('3d', '7d'):
            with _db() as con:
                if direction == 'down':
                    extreme = con.execute('''SELECT MAX(price) FROM scout_price_observations
                        WHERE symbol=? AND ts>? AND ts<=?''',
                        (r['symbol'], float(r['spotted_ts']), float(r['resolved_ts']))).fetchone()[0]
                    adverse_excursion = ((float(extreme) / float(r['spotted_price']) - 1.0) * 100.0
                                         if extreme is not None else None)
                else:
                    extreme = con.execute('''SELECT MIN(price) FROM scout_price_observations
                        WHERE symbol=? AND ts>? AND ts<=?''',
                        (r['symbol'], float(r['spotted_ts']), float(r['resolved_ts']))).fetchone()[0]
                    adverse_excursion = ((float(extreme) / float(r['spotted_price']) - 1.0) * 100.0
                                         if extreme is not None else None)
        recovered_after_dip = bool(delayed and direction == 'up' and adverse_excursion is not None
                                   and adverse_excursion <= FAIL_RETURN_PCT)
        recovered_after_rally = bool(delayed and direction == 'down' and adverse_excursion is not None
                                     and adverse_excursion >= abs(FAIL_RETURN_PCT))
        event = {'id': f"{r['sighting_id']}:{r['horizon']}", 'symbol': r['symbol'],
            'spotted_at': float(r['spotted_ts']), 'resolved_at': float(r['resolved_ts']),
            'spotted_price': float(r['spotted_price']), 'score': float(r['score']),
            'phase': r['phase'], 'direction': direction, 'market_regime': r['market_regime'],
            'horizon': r['horizon'], 'return_pct': round(ret, 3) if ret is not None else None,
            'directional_return_pct': round(directional_return, 3) if directional_return is not None else None,
            'result': r['result'], 'delayed_pump': bool(delayed and direction == 'up'),
            'delayed_dump': bool(delayed and direction == 'down'),
            'recovered_after_dip': recovered_after_dip,
            'recovered_after_rally': recovered_after_rally,
            'adverse_excursion_pct': round(adverse_excursion, 3) if adverse_excursion is not None else None,
            # Stable directional aliases retained for API consumers: an UP
            # signal's adverse excursion is a drawdown; a DOWN signal's is an
            # adverse rally. Keep the neutral generic field as well.
            'observed_max_drawdown_pct': (round(adverse_excursion, 3)
                if direction != 'down' and adverse_excursion is not None else None),
            'observed_max_adverse_rally_pct': (round(adverse_excursion, 3)
                if direction == 'down' and adverse_excursion is not None else None)}
        events.append(event)
        if event['delayed_pump']:
            delayed_pumps.append(event)
        if event['delayed_dump']:
            delayed_dumps.append(event)
        if recovered_after_dip or recovered_after_rally:
            recoveries.append(event)

    # Learn descriptive cohorts separately for UP and DOWN so their raw returns
    # cannot cancel each other or make a correct short look like a losing setup.
    with _db() as con:
        cohort_rows = con.execute('''SELECT s.phase,s.score,s.market_regime,s.direction,o.horizon,o.result,o.return_pct
            FROM scout_outcomes o JOIN scout_sightings s ON s.id=o.sighting_id
            WHERE o.resolved_ts IS NOT NULL AND o.result IN ('success','fake','neutral')''').fetchall()
    cohorts = {}
    for row in cohort_rows:
        score = float(row['score'])
        band = ('<50' if score < 50 else '50-59' if score < 60 else
                '60-69' if score < 70 else '70-79' if score < 80 else '80+')
        direction = _normalize_direction(row['direction'])
        key = (direction, str(row['horizon']), str(row['phase']), band, str(row['market_regime'] or 'UNKNOWN'))
        item = cohorts.setdefault(key, {'samples': 0, 'wins': 0, 'returns': []})
        item['samples'] += 1
        item['wins'] += int(row['result'] == 'success')
        if row['return_pct'] is not None:
            raw = float(row['return_pct'])
            item['returns'].append(-raw if direction == 'down' else raw)
    insights = []
    for (direction, horizon, phase, band, regime), item in cohorts.items():
        if item['samples'] < 5:
            continue
        avg = mean(item['returns']) if item['returns'] else None
        lower, upper = _wilson_interval(item['wins'], item['samples'])
        n = item['samples']
        evidence = 'کم' if n < 10 else 'مقدماتی' if n < 30 else 'بیشتر، اما همچنان نیازمند بررسی'
        insights.append({'direction': direction, 'horizon': horizon, 'phase': phase, 'score_band': band,
            'market_regime': regime, 'samples': n, 'wins': item['wins'],
            'success_rate': round(item['wins'] / n, 3),
            'success_rate_ci95': [round(lower, 3), round(upper, 3)],
            'evidence_level': evidence,
            'avg_return_pct': round(avg, 3) if avg is not None else None})
    insights.sort(key=lambda x: (x['success_rate_ci95'][0], x['samples'],
                                 x['avg_return_pct'] if x['avg_return_pct'] is not None else -999), reverse=True)

    with _db() as con:
        recommendation_rows = con.execute('''SELECT s.id AS sighting_id,s.symbol,s.ts AS spotted_ts,
            s.price AS spotted_price,s.score,s.phase,s.direction,o.horizon,o.resolved_ts,
            o.return_pct,o.result FROM scout_sightings s
            LEFT JOIN scout_outcomes o ON o.sighting_id=s.id
            ORDER BY s.ts DESC,s.id DESC''').fetchall()
    grouped = {}
    horizon_order = ('1h', '4h', '24h', '3d', '7d')
    for row in recommendation_rows:
        item = grouped.setdefault(row['sighting_id'], {
            'id': int(row['sighting_id']), 'symbol': row['symbol'],
            'spotted_at': float(row['spotted_ts']), 'spotted_price': float(row['spotted_price']),
            'score': float(row['score']), 'phase': row['phase'],
            'direction': _normalize_direction(row['direction']), 'outcomes': {}})
        if row['horizon']:
            item['outcomes'][row['horizon']] = {
                'result': row['result'],
                'return_pct': round(float(row['return_pct']), 3) if row['return_pct'] is not None else None,
                'resolved_at': float(row['resolved_ts']) if row['resolved_ts'] is not None else None}

    category_rows = {key: [] for key in (
        'immediate_pump','immediate_dump','next_day_pump','next_day_dump','delayed_pump','delayed_dump',
        'recovered_after_dip','recovered_after_rally','never_reached_target','pending','insufficient_observations')}
    for item in grouped.values():
        outcomes = item['outcomes']
        successful = [h for h in horizon_order if outcomes.get(h, {}).get('result') == 'success']
        resolved_valid = [h for h in horizon_order if outcomes.get(h, {}).get('result') in ('success','fake','neutral')]
        unresolved = [h for h in horizon_order if h not in outcomes or outcomes[h].get('result') is None]
        missing = [h for h in horizon_order if outcomes.get(h, {}).get('result') == 'missing_observation']
        first_success = successful[0] if successful else None
        side = item['direction']
        suffix = 'dump' if side == 'down' else 'pump'
        if first_success in ('1h', '4h'):
            category = f'immediate_{suffix}'
        elif first_success == '24h':
            category = f'next_day_{suffix}'
        elif first_success in ('3d', '7d'):
            category = f'delayed_{suffix}'
        elif unresolved:
            category = 'pending'
        elif missing:
            category = 'insufficient_observations'
        else:
            category = 'never_reached_target'
        item['category'] = category
        item['first_success_horizon'] = first_success
        item['outcomes'] = {h: outcomes[h] for h in horizon_order if h in outcomes}
        item['completed_valid_horizons'] = len(resolved_valid)
        if first_success in ('3d', '7d'):
            success = outcomes[first_success]
            with _db() as con:
                if side == 'down':
                    extreme = con.execute('''SELECT MAX(price) FROM scout_price_observations
                        WHERE symbol=? AND ts>? AND ts<=?''',
                        (item['symbol'], item['spotted_at'], success['resolved_at'])).fetchone()[0]
                    excursion = ((float(extreme) / item['spotted_price'] - 1.0) * 100.0) if extreme is not None else None
                    item['observed_max_adverse_rally_pct'] = round(excursion, 3) if excursion is not None else None
                    if excursion is not None and excursion >= abs(FAIL_RETURN_PCT):
                        item['category'] = 'recovered_after_rally'
                else:
                    extreme = con.execute('''SELECT MIN(price) FROM scout_price_observations
                        WHERE symbol=? AND ts>? AND ts<=?''',
                        (item['symbol'], item['spotted_at'], success['resolved_at'])).fetchone()[0]
                    excursion = ((float(extreme) / item['spotted_price'] - 1.0) * 100.0) if extreme is not None else None
                    item['observed_max_drawdown_pct'] = round(excursion, 3) if excursion is not None else None
                    if excursion is not None and excursion <= FAIL_RETURN_PCT:
                        item['category'] = 'recovered_after_dip'
        category_rows[item['category']].append(item)

    early_move_report = pre_pump_performance_report()
    performance_report = {
        'total_recommendations': len(grouped),
        'counts': {key: len(values) for key, values in category_rows.items()},
        'categories': category_rows,
        'classification': {
            'immediate_pump': 'رسیدن به هدف صعودی در ۱ یا ۴ ساعت',
            'immediate_dump': 'رسیدن به هدف نزولی در ۱ یا ۴ ساعت',
            'next_day_pump': 'رسیدن به هدف صعودی در ۲۴ ساعت',
            'next_day_dump': 'رسیدن به هدف نزولی در ۲۴ ساعت',
            'delayed_pump': 'اولین رسیدن به هدف صعودی در ۳ یا ۷ روز',
            'delayed_dump': 'اولین رسیدن به هدف نزولی در ۳ یا ۷ روز',
            'recovered_after_dip': 'هدف صعودی پس از افت نامساعد میانی',
            'recovered_after_rally': 'هدف نزولی پس از جهش نامساعد میانی',
            'never_reached_target': 'همه افق‌ها مشاهده معتبر دارند اما هدف هم‌جهت محقق نشده',
            'pending': 'حداقل یک افق هنوز ارزیابی نشده است',
            'insufficient_observations': 'برخی قیمت‌های لازم مشاهده نشده‌اند'},
        'note': 'موفقیت نزولی با افت قیمت سنجیده می‌شود و موفقیت صعودی با رشد قیمت؛ بازده خام نیز جداگانه نگهداری می‌شود.'}
    return {'events': events, 'delayed_pumps': delayed_pumps, 'delayed_dumps': delayed_dumps,
            'delayed_moves': delayed_pumps + delayed_dumps,
            'recovered_after_dip': [e for e in recoveries if e['direction'] == 'up'],
            'recovered_after_rally': [e for e in recoveries if e['direction'] == 'down'],
            'performance_report': performance_report,
            'horizon_thresholds_pct': dict(SUCCESS_RETURN_PCT),
            'historical_insights': insights[:16], 'insight_min_samples': 5,
            'pre_pump_report': early_move_report,
            'early_move_report': early_move_report,
            'regime_learning_note': 'یادگیری رژیم فقط از برچسب صریح BTC چهار‌ساعته هنگام معرفی استفاده می‌کند؛ داده‌های فاقد برچسب UNKNOWN می‌مانند.',
            'note': 'سیگنال صعودی با رشد و سیگنال نزولی با افت قیمت ارزیابی می‌شود؛ نبود مشاهده هرگز موفقیت یا شکست تلقی نمی‌شود.'}
