"""Operational trust-store health and rotation-policy reporting for BTC replay anchors."""
from __future__ import annotations
import hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path
from backend.btc_replay_trust_backup import audit_replay_trust_store

ZERO='0'*64


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()


def _sha(value): return hashlib.sha256(_canonical(value)).hexdigest()


def evaluate_replay_trust_policy(*, trust_dir=None, max_key_age_days=365,
                                 rotation_warning_days=30, max_signing_sequence=100000,
                                 sequence_warning_margin=1000, now=None):
    from backend import signed_anchor
    root=Path(trust_dir).expanduser() if trust_dir is not None else signed_anchor._key_dir()
    now=now or datetime.now(timezone.utc)
    if now.tzinfo is None: raise ValueError('trust_monitor_now_must_be_timezone_aware')
    health=audit_replay_trust_store(trust_dir=root)
    warnings=[]; errors=list(health.get('errors',[]))
    active={}
    try:
        active=json.loads((root/'active_key.json').read_text(encoding='utf-8'))
        created=active.get('created_at')
        if created:
            created_dt=datetime.fromisoformat(str(created).replace('Z','+00:00'))
            if created_dt.tzinfo is None: raise ValueError('active_key_creation_timezone_missing')
            age=max(0.0,(now-created_dt).total_seconds()/86400)
        else:
            age=None; warnings.append('active_key_creation_time_unavailable')
    except Exception as exc:
        age=None; errors.append(f'active_key_metadata_invalid:{exc}')
    sequence=health.get('highest_signing_sequence',0)
    if age is not None:
        if age >= max_key_age_days: warnings.append('active_key_rotation_overdue')
        elif age >= max(0,max_key_age_days-rotation_warning_days): warnings.append('active_key_rotation_approaching')
    if sequence >= max_signing_sequence: warnings.append('signing_sequence_limit_reached')
    elif sequence >= max(0,max_signing_sequence-sequence_warning_margin): warnings.append('signing_sequence_limit_approaching')
    if not health.get('healthy'): errors.append('trust_store_unhealthy')
    status='CRITICAL' if errors else ('WARNING' if warnings else 'HEALTHY')
    return {'schema_version':'btc-replay-trust-health-v1','status':status,
            'checked_at_utc':now.astimezone(timezone.utc).isoformat(),
            'active_key_id':health.get('active_key_id'),
            'active_key_age_days':round(age,3) if age is not None else None,
            'trusted_key_count':health.get('trusted_key_count',0),
            'revoked_key_count':health.get('revoked_key_count',0),
            'highest_signing_sequence':sequence,'max_signing_sequence':max_signing_sequence,
            'warnings':sorted(set(warnings)),'errors':sorted(set(errors))}


def append_replay_trust_health_report(report: dict, *, report_path):
    if not isinstance(report,dict) or report.get('schema_version')!='btc-replay-trust-health-v1':
        raise ValueError('trust_health_report_invalid')
    path=Path(report_path).expanduser(); path.parent.mkdir(parents=True,exist_ok=True)
    rows=[]
    if path.exists():
        for number,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
            try: rows.append(json.loads(line))
            except ValueError as exc: raise ValueError(f'trust_health_log_corrupt_line:{number}') from exc
    audit_trust_health_reports(rows)
    body={'sequence':len(rows)+1,'previous_report_sha256':rows[-1]['report_sha256'] if rows else ZERO,
          'report':report}
    body['report_sha256']=_sha(body)
    payload=_canonical(body)+b'\n'
    fd=os.open(str(path),os.O_CREAT|os.O_APPEND|os.O_WRONLY,0o600)
    try:
        written=os.write(fd,payload)
        if written!=len(payload): raise OSError('trust_health_log_short_append')
        os.fsync(fd)
    finally: os.close(fd)
    return {'sequence':body['sequence'],'report_sha256':body['report_sha256'],'path':str(path)}


def audit_trust_health_reports(rows_or_path):
    if isinstance(rows_or_path,(str,Path)):
        path=Path(rows_or_path); rows=[]
        if path.exists():
            for number,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
                try: rows.append(json.loads(line))
                except ValueError as exc: raise ValueError(f'trust_health_log_corrupt_line:{number}') from exc
    else: rows=list(rows_or_path)
    previous=ZERO
    for sequence,row in enumerate(rows,1):
        body=dict(row); digest=body.pop('report_sha256',None)
        if row.get('sequence')!=sequence or row.get('previous_report_sha256')!=previous:
            raise ValueError('trust_health_log_sequence_or_link_mismatch')
        if not digest or _sha(body)!=digest:
            raise ValueError('trust_health_log_hash_mismatch')
        previous=digest
    return {'status':'PASS','report_count':len(rows),'head_sha256':previous,
            'latest_status':rows[-1]['report']['status'] if rows else None}
