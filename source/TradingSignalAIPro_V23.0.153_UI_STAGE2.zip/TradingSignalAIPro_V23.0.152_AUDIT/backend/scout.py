"""V19.3 — Storm Scout ("دیده‌بان طوفان"): a second brain that hunts for coins
that are showing EARLY signs of an explosive move.

Pipeline (all best-effort, nothing is ever fabricated):
 1. Collect market snapshots in parallel from many independent sources
    (exchanges + aggregators incl. CoinMarketCap / CoinGecko / CoinPaprika /
    CryptoCompare). Each source has mirrors, a short timeout and a cooldown, so a
    filtered/blocked site is skipped in seconds instead of freezing the scan.
 2. Merge by coin, pre-score on cross-source evidence (move, turnover, trending).
 3. Verify the best candidates on real 15m candles: volume surge, range
    breakout, volatility expansion after compression, momentum in ATR units.
 4. Publish alerts (score >= STORM) and a watch list. A coin whose candles
    could not be verified is capped below the alert level.

It detects conditions that often precede large moves; it does not predict them.
"""
from __future__ import annotations

import math
import os
import re
import statistics
import threading
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutTimeout, as_completed
from typing import Any, Callable

import numpy as np
import pandas as pd
import requests

STORM_LEVEL = 70
WATCH_LEVEL = 50
EARLY_LEVEL = 45              # V20: threshold for the "early hunt" list (شکار اول حرکت)
UNVERIFIED_CAP = 55           # no candle/identity confirmation -> never reaches "storm"
MAX_PRICE_DISPERSION_PCT = 5.0  # quote disagreement -> quarantine candidate
MTF_UNALIGNED_CAP = 64.0       # multi-timeframe disagreement stays below Storm
SOURCE_TIMEOUT = (4, 9)       # connect, read seconds
COOLDOWN_SEC = 600
_STABLES = {'USDT', 'USDC', 'FDUSD', 'TUSD', 'USDP', 'DAI', 'BUSD', 'USDE', 'EUR', 'EURI', 'AEUR',
            'USD1', 'XUSD', 'PYUSD', 'UST', 'USDS', 'USDD', 'GUSD', 'LUSD', 'FRAX', 'WBTC', 'WETH',
            'STETH', 'WSTETH', 'WBETH', 'CBBTC'}
_LEVERAGED = re.compile(r'(\d+[LS]|UP|DOWN|BULL|BEAR)$')

_SESSION = requests.Session()
_SESSION.headers.update({'User-Agent': 'Mozilla/5.0 TradingSignalAIPro/19.3', 'Accept': 'application/json'})
_HEALTH: dict[str, dict] = {}
_LOCK = threading.Lock()
_STATE: dict[str, Any] = {'result': None, 'running': False, 'last_start': 0.0, 'thread': None,
                          'stop': False, 'fail_streak': 0}


# ------------------------------------------------------------------ http
def _apply_proxy() -> None:
    proxy = (os.getenv('TS_AI_PROXY') or os.getenv('SCOUT_PROXY') or '').strip()
    _SESSION.proxies.clear()
    if proxy:
        _SESSION.proxies.update({'http': proxy, 'https': proxy})


def _get_json(urls: list[str] | str, params=None, headers=None):
    """Try each mirror once, fast. Raises the last error if all fail."""
    if isinstance(urls, str):
        urls = [urls]
    last: Exception | None = None
    for url in urls:
        try:
            r = _SESSION.get(url, params=params, headers=headers, timeout=SOURCE_TIMEOUT)
            if r.status_code in (418, 429, 451, 403):
                raise RuntimeError(f'HTTP {r.status_code} (محدود/مسدود)')
            r.raise_for_status()
            return r.json()
        except Exception as exc:
            last = exc
    raise RuntimeError(str(last)[:140] if last else 'خطای ناشناخته')


def _apply_brain_priority(items: list[dict]) -> list[dict]:
    """Reorder an already-qualified scout list using validated pattern feedback.

    This is a bounded display-order adjustment only: it never changes the
    scout score, eligibility thresholds, alert membership, or execution.
    Pattern weights are supplied by market_brain only after its 20-sample gate.
    """
    for item in items:
        prediction = item.get('brain_prediction') or {}
        learning = prediction.get('pattern_learning') or {}
        try:
            weight = float(learning.get('weight', 1.0))
            calls = int(learning.get('directional_calls') or 0)
            base_score = float(item.get('score') or 0.0)
            if not math.isfinite(weight) or not math.isfinite(base_score):
                raise ValueError('non-finite priority input')
        except (TypeError, ValueError, OverflowError):
            weight, calls, base_score = 1.0, 0, float(item.get('score') or 0.0)
        # Ignore any malformed/unvalidated external weight and cap influence.
        if calls < 20:
            weight = 1.0
        weight = min(1.15, max(0.75, weight))
        item['brain_priority_weight'] = round(weight, 3)
        item['brain_priority_score'] = round(base_score * weight, 3)
        item['brain_priority_reliability'] = learning.get('reliability', 'insufficient_samples')
    return sorted(items, key=lambda x: (x.get('brain_priority_score', x.get('score', 0)),
                                        x.get('relative_strength_score') if x.get('relative_strength_score') is not None else -1,
                                        x.get('score', 0)), reverse=True)


def _annotate_relative_strength(items: list[dict]) -> list[dict]:
    """Add a cross-sectional momentum/participation rank for this scan only.

    Percentile ranks are computed only from finite, observed fields. Missing
    fields are omitted and remaining weights are renormalized. This is a
    descriptive display metric; it does not alter eligibility or raw scores.
    """
    metrics = (("change_1h", 0.50), ("change_24h", 0.30), ("volume_usd", 0.20))
    ranks: dict[int, list[tuple[float, float]]] = {id(item): [] for item in items}
    for field, weight in metrics:
        observed = []
        for item in items:
            value = _f(item.get(field))
            if value is not None and (field != "volume_usd" or value > 0):
                # Rank relative strength in the candidate's predicted direction.
                if field in ("change_1h", "change_24h") and item.get("direction") == "down":
                    value = -value
                observed.append((item, value))
        if len(observed) < 2:
            continue
        ordered = sorted(value for _, value in observed)
        n = len(ordered)
        for item, value in observed:
            # Mid-rank percentile; equal values receive the same rank.
            below = sum(v < value for v in ordered)
            equal = sum(v == value for v in ordered)
            percentile = 100.0 * (below + (equal - 1) / 2) / max(1, n - 1)
            ranks[id(item)].append((percentile, weight))
    for item in items:
        parts = ranks[id(item)]
        if parts:
            denom = sum(weight for _, weight in parts)
            item["relative_strength_score"] = round(sum(rank * weight for rank, weight in parts) / denom, 2)
            item["relative_strength_coverage"] = len(parts)
            item["relative_strength_basis"] = "same_scan_direction_adjusted_percentile"
        else:
            item["relative_strength_score"] = None
            item["relative_strength_coverage"] = 0
            item["relative_strength_basis"] = "insufficient_peer_data"
    return items


def _f(x) -> float | None:
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def _row(base, price, c24, vol, source, c1h=None, c7d=None, mcap=None, rank=None, trending=False):
    base = str(base or '').upper().strip()
    if not re.fullmatch(r'[A-Z0-9]{2,15}', base) or base in _STABLES or _LEVERAGED.search(base):
        return None
    price, c24, vol = _f(price), _f(c24), _f(vol)
    if price is None or price <= 0 or c24 is None or vol is None or vol <= 0:
        return None
    return {'base': base, 'price': price, 'c24': c24, 'c1h': _f(c1h), 'c7d': _f(c7d), 'vol': vol,
            'mcap': _f(mcap), 'rank': rank, 'trending': bool(trending), 'source': source}


# ------------------------------------------------------------- collectors
def _binance_like(urls, name):
    def run():
        out = []
        for t in _get_json(urls):
            s = str(t.get('symbol', ''))
            if s.endswith('USDT'):
                out.append(_row(s[:-4], t.get('lastPrice'), t.get('priceChangePercent'),
                                t.get('quoteVolume'), name))
        return out
    return run


def _bybit():
    d = _get_json(['https://api.bybit.com/v5/market/tickers', 'https://api.bytick.com/v5/market/tickers'],
                  params={'category': 'spot'})
    return [_row(t['symbol'][:-4], t.get('lastPrice'), (_f(t.get('price24hPcnt')) or 0) * 100,
                 t.get('turnover24h'), 'bybit')
            for t in (d.get('result') or {}).get('list', []) if str(t.get('symbol', '')).endswith('USDT')]


def _okx():
    d = _get_json(['https://www.okx.com/api/v5/market/tickers', 'https://aws.okx.com/api/v5/market/tickers'],
                  params={'instType': 'SPOT'})
    out = []
    for t in d.get('data', []):
        if not str(t.get('instId', '')).endswith('-USDT'):
            continue
        last, op = _f(t.get('last')), _f(t.get('open24h'))
        if last and op:
            out.append(_row(t['instId'].split('-')[0], last, (last / op - 1) * 100, t.get('volCcy24h'), 'okx'))
    return out


def _kucoin():
    d = _get_json(['https://api.kucoin.com/api/v1/market/allTickers'])
    return [_row(t['symbol'].split('-')[0], t.get('last'), (_f(t.get('changeRate')) or 0) * 100,
                 t.get('volValue'), 'kucoin')
            for t in (d.get('data') or {}).get('ticker', []) if str(t.get('symbol', '')).endswith('-USDT')]


def _gate():
    d = _get_json(['https://api.gateio.ws/api/v4/spot/tickers'])
    return [_row(t['currency_pair'].split('_')[0], t.get('last'), t.get('change_percentage'),
                 t.get('quote_volume'), 'gate')
            for t in d if str(t.get('currency_pair', '')).endswith('_USDT')]


def _coingecko_markets():
    h = {'x-cg-demo-api-key': os.getenv('COINGECKO_API_KEY')} if os.getenv('COINGECKO_API_KEY') else None
    d = _get_json(['https://api.coingecko.com/api/v3/coins/markets'], headers=h, params={
        'vs_currency': 'usd', 'order': 'volume_desc', 'per_page': 250, 'page': 1,
        'price_change_percentage': '1h,24h,7d'})
    return [_row(c.get('symbol'), c.get('current_price'), c.get('price_change_percentage_24h_in_currency'),
                 c.get('total_volume'), 'coingecko', c.get('price_change_percentage_1h_in_currency'),
                 c.get('price_change_percentage_7d_in_currency'), c.get('market_cap'),
                 c.get('market_cap_rank')) for c in d]


def _coingecko_trending():
    h = {'x-cg-demo-api-key': os.getenv('COINGECKO_API_KEY')} if os.getenv('COINGECKO_API_KEY') else None
    d = _get_json(['https://api.coingecko.com/api/v3/search/trending'], headers=h)
    # trending carries no price: represent as a flag-only row
    return [{'flag_only': True, 'base': str((c.get('item') or {}).get('symbol', '')).upper(),
             'source': 'coingecko_trending'} for c in d.get('coins', [])]


def _coinpaprika():
    d = _get_json(['https://api.coinpaprika.com/v1/tickers'], params={'quotes': 'USD'})
    out = []
    for c in d:
        rank = c.get('rank') or 99999
        if rank > 600:
            continue
        q = (c.get('quotes') or {}).get('USD') or {}
        out.append(_row(c.get('symbol'), q.get('price'), q.get('percent_change_24h'), q.get('volume_24h'),
                        'coinpaprika', q.get('percent_change_1h'), q.get('percent_change_7d'),
                        q.get('market_cap'), rank))
    return out


def _cryptocompare():
    d = _get_json(['https://min-api.cryptocompare.com/data/top/totalvolfull'],
                  params={'limit': 100, 'tsym': 'USD'})
    out = []
    for c in d.get('Data', []):
        raw = (c.get('RAW') or {}).get('USD') or {}
        out.append(_row((c.get('CoinInfo') or {}).get('Name'), raw.get('PRICE'), raw.get('CHANGEPCT24HOUR'),
                        raw.get('TOTALVOLUME24HTO'), 'cryptocompare', None, None, raw.get('MKTCAP')))
    return out


def _cmc_pro():
    key = os.getenv('CMC_API_KEY', '').strip()
    if not key:
        raise RuntimeError('CMC_API_KEY تنظیم نشده (اختیاری)')
    d = _get_json(['https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest'],
                  headers={'X-CMC_PRO_API_KEY': key},
                  params={'limit': 300, 'convert': 'USD', 'sort': 'volume_24h'})
    out = []
    for c in d.get('data', []):
        q = (c.get('quote') or {}).get('USD') or {}
        out.append(_row(c.get('symbol'), q.get('price'), q.get('percent_change_24h'), q.get('volume_24h'),
                        'coinmarketcap', q.get('percent_change_1h'), q.get('percent_change_7d'),
                        q.get('market_cap'), c.get('cmc_rank')))
    return out


def _cmc_public():
    """Unofficial public listing endpoint of coinmarketcap.com (no key). Best effort."""
    d = _get_json(['https://api.coinmarketcap.com/data-api/v3/cryptocurrency/listing'],
                  params={'start': 1, 'limit': 200, 'sortBy': 'volume_24h', 'sortType': 'desc',
                          'convert': 'USD', 'cryptoType': 'all', 'tagType': 'all'})
    out = []
    for c in (d.get('data') or {}).get('cryptoCurrencyList', []):
        q = next((x for x in c.get('quotes', []) if x.get('name') == 'USD'), {})
        out.append(_row(c.get('symbol'), q.get('price'), q.get('percentChange24h'), q.get('volume24h'),
                        'coinmarketcap_web', q.get('percentChange1h'), q.get('percentChange7d'),
                        q.get('marketCap'), c.get('cmcRank')))
    return out


SOURCES: dict[str, tuple[str, Callable[[], list]]] = {
    'binance': ('Binance', _binance_like(
        ['https://data-api.binance.vision/api/v3/ticker/24hr', 'https://api.binance.com/api/v3/ticker/24hr',
         'https://api1.binance.com/api/v3/ticker/24hr', 'https://api2.binance.com/api/v3/ticker/24hr',
         'https://api3.binance.com/api/v3/ticker/24hr', 'https://api-gcp.binance.com/api/v3/ticker/24hr'],
        'binance')),
    'mexc': ('MEXC', _binance_like(['https://api.mexc.com/api/v3/ticker/24hr'], 'mexc')),
    'bybit': ('Bybit', _bybit), 'okx': ('OKX', _okx), 'kucoin': ('KuCoin', _kucoin), 'gate': ('Gate.io', _gate),
    'coingecko': ('CoinGecko', _coingecko_markets),
    'coingecko_trending': ('CoinGecko Trending', _coingecko_trending),
    'coinpaprika': ('CoinPaprika', _coinpaprika),
    'cryptocompare': ('CryptoCompare', _cryptocompare),
    'coinmarketcap': ('CoinMarketCap (API)', _cmc_pro),
    'coinmarketcap_web': ('CoinMarketCap (وب)', _cmc_public),
}


def _cooling(key: str) -> bool:
    h = _HEALTH.get(key)
    return bool(h and h.get('until', 0) > time.time())


def _collect(deadline: float = 22.0) -> tuple[list[dict], list[dict]]:
    """Run every non-cooling source in parallel; never wait longer than `deadline`."""
    rows: list[dict] = []
    report: list[dict] = []
    started = time.time()
    pool = ThreadPoolExecutor(max_workers=len(SOURCES))
    futs = {}
    for key, (label, fn) in SOURCES.items():
        if _cooling(key):
            report.append({'id': key, 'label': label, 'ok': False, 'skipped': True,
                           'error': 'موقتاً رد شد (اخیراً جواب نداد)'})
            continue
        futs[pool.submit(fn)] = (key, label, time.time())
    pending = set(futs)
    try:
        for fut in as_completed(futs, timeout=deadline):
            pending.discard(fut)
            key, label, t0 = futs[fut]
            try:
                got = [r for r in fut.result() if r]
                if not got:
                    raise RuntimeError('پاسخ خالی')
                rows.extend(got)
                _HEALTH[key] = {'fails': 0, 'until': 0}
                report.append({'id': key, 'label': label, 'ok': True, 'count': len(got),
                               'ms': int((time.time() - t0) * 1000)})
            except Exception as exc:
                _mark_failed(key)
                report.append({'id': key, 'label': label, 'ok': False, 'error': str(exc)[:120]})
    except FutTimeout:
        pass
    for fut in pending:                      # too slow: give up on them, do not block the scan
        key, label, _ = futs[fut]
        _mark_failed(key)
        report.append({'id': key, 'label': label, 'ok': False, 'error': f'کند بود (> {deadline:.0f}s)'})
        fut.cancel()
    pool.shutdown(wait=False, cancel_futures=True)
    return rows, report


def _mark_failed(key: str) -> None:
    h = _HEALTH.setdefault(key, {'fails': 0, 'until': 0})
    h['fails'] += 1
    if h['fails'] >= 2:                      # two strikes -> sit out for a while
        h['until'] = time.time() + COOLDOWN_SEC


# -------------------------------------------------------------- scoring
def merge(rows: list[dict]) -> dict[str, dict]:
    """Merge market observations conservatively without counting trend flags as quotes.

    V22.5a: source breadth is based only on priced observations. A trending-only
    result is metadata, not an independent market-price confirmation. Prices,
    volume and market cap use medians; large cross-source price disagreement is
    retained as an explicit identity/quality conflict for fail-closed scoring.
    """
    coins: dict[str, dict] = {}
    for r in rows:
        base = str(r.get('base') or '').upper().strip()
        if not base:
            continue
        c = coins.setdefault(base, {'base': base, 'sources': set(), 'trend_sources': set(),
                                    'c24': [], 'c1h': [], 'c7d': [], 'prices': [],
                                    'volumes': [], 'mcaps': [], 'ranks': [],
                                    'vol': 0.0, 'mcap': None, 'rank': None, 'price': None,
                                    'trending': False, 'exch': set()})
        if r.get('flag_only'):
            c['trending'] = True
            if r.get('source'):
                c['trend_sources'].add(r['source'])
            continue
        if r.get('price') is None or r.get('c24') is None or r.get('vol') is None:
            continue
        source = r.get('source')
        if source:
            c['sources'].add(source)
        c['c24'].append(r['c24'])
        c['prices'].append(float(r['price']))
        c['volumes'].append(float(r['vol']))
        for k in ('c1h', 'c7d'):
            if r.get(k) is not None:
                c[k].append(r[k])
        if r.get('mcap') and r['mcap'] > 0:
            c['mcaps'].append(float(r['mcap']))
        if r.get('rank'):
            c['ranks'].append(int(r['rank']))
        if source in ('binance', 'mexc', 'bybit', 'okx', 'kucoin', 'gate'):
            c['exch'].add(source)

    out = {}
    for b, c in coins.items():
        if not c['c24'] or not c['prices']:
            continue
        med = lambda xs: statistics.median(xs) if xs else None
        c['c24'], c['c1h'], c['c7d'] = med(c['c24']), med(c['c1h']), med(c['c7d'])
        c['price'] = med(c['prices'])
        c['vol'] = med(c['volumes'])
        c['mcap'] = med(c['mcaps'])
        c['rank'] = min(c['ranks']) if c['ranks'] else None
        pmed = c['price']
        c['price_dispersion_pct'] = round(
            100.0 * (max(c['prices']) - min(c['prices'])) / pmed, 3
        ) if pmed and len(c['prices']) > 1 else 0.0
        c['identity_conflict'] = c['price_dispersion_pct'] > MAX_PRICE_DISPERSION_PCT
        c['price_source_count'] = len(c['sources'])
        c['exchange_source_count'] = len(c['exch'])
        # Internal raw arrays are not needed by scoring/API consumers.
        for key in ('prices', 'volumes', 'mcaps', 'ranks'):
            c.pop(key, None)
        out[b] = c
    return out


def prescore(c: dict, min_volume: float) -> float:
    """0..100 from cross-source data only (no candles). Used to pick candidates.

    V20 — tuned to catch moves EARLY: the raw 24h move matters less; what matters
    is whether the move is FRESH (concentrated in the last hour), whether the
    coin turns over a lot relative to its size, and whether it is small enough
    that a storm can actually lift it fast.
    """
    if c['vol'] < min_volume:
        return 0.0
    move = min(abs(c['c24']), 30.0) / 30.0
    hour = min(abs(c['c1h'] or 0.0), 8.0) / 8.0
    # freshness: how much of the 24h move happened in the last hour (1h starts first)
    fresh_share = min(abs(c['c1h'] or 0.0) / max(abs(c['c24']), 0.5), 1.0) if c['c24'] else 0.0
    turnover = 0.0
    if c.get('mcap') and c['mcap'] > 0:
        turnover = min(c['vol'] / c['mcap'], 1.5) / 1.5        # volume / market-cap
    breadth = min(len(c['sources']), 5) / 5.0
    # small caps move first and fastest — mild boost for the chase
    cap_b = 0.0
    if c.get('mcap') and c['mcap'] > 0:
        cap_b = 0.30 if c['mcap'] < 50e6 else 0.20 if c['mcap'] < 150e6 else 0.10 if c['mcap'] < 500e6 else 0.0
    return round(100 * (0.22 * move + 0.16 * hour + 0.15 * fresh_share + 0.22 * turnover
                        + 0.15 * breadth + 0.10 * (1.0 if c['trending'] else 0.0))
                 + cap_b * 100, 1)


def compression_features(df: pd.DataFrame) -> dict:
    """Causal squeeze detector. Uses only bars present in df; final four bars form release window."""
    empty = {'compression_ratio': None, 'compression_duration_bars': 0,
             'compression_quality': 0.0, 'release_confirmed': False,
             'release_volume_ratio': 0.0, 'breakout_distance_atr': 0.0,
             'fakeout_risk': 1.0, 'squeeze_release': False}
    try:
        d = df[['high', 'low', 'close', 'volume']].astype(float).replace([np.inf, -np.inf], np.nan).dropna()
        if len(d) < 150:
            return empty
        h, l, c, v = (d[k].to_numpy() for k in ('high', 'low', 'close', 'volume'))
        if np.any(h <= 0) or np.any(l <= 0) or np.any(c <= 0) or np.any(v < 0) or np.any(h < l):
            return empty
        pc = np.r_[c[0], c[:-1]]
        tr = np.maximum(h-l, np.maximum(np.abs(h-pc), np.abs(l-pc)))
        baseline = float(np.median(tr[-140:-20]))
        comp = tr[-20:-4]
        comp_atr = float(np.median(comp))
        if baseline <= 1e-12 or comp_atr <= 1e-12:
            return empty
        ratio = comp_atr / baseline
        # Count the contiguous low-range bars immediately preceding the release window.
        threshold = baseline * 0.78
        duration = 0
        for x in tr[-20:-4][::-1]:
            if x <= threshold:
                duration += 1
            else:
                break
        comp_range = (float(np.max(h[-20:-4])) - float(np.min(l[-20:-4]))) / max(float(np.median(c[-20:-4])), 1e-12)
        base_range = (float(np.median([np.max(h[i-16:i])-np.min(l[i-16:i]) for i in range(40, 120, 8)])) /
                      max(float(np.median(c[-140:-20])), 1e-12))
        range_ratio = comp_range / max(base_range, 1e-12)
        vol_base = float(np.median(v[-100:-20]))
        comp_vol = float(np.median(v[-20:-4]))
        vol_stability = min(comp_vol / max(vol_base, 1e-12), 1.0) if vol_base > 0 else 0.0
        # A squeeze is valid only if it is compact, persistent and not a dead/zero-volume market.
        quality = float(np.clip((0.72-ratio)/0.42, 0, 1) * np.clip((1.15-range_ratio)/0.75, 0, 1)
                        * np.clip(duration/8, 0, 1) * np.clip(vol_stability/0.35, 0, 1))
        release_tr = float(np.mean(tr[-4:]))
        expansion = release_tr / comp_atr
        recent_vol = float(np.mean(v[-4:]))
        release_vol = recent_vol / max(vol_base, 1e-12)
        prior_high, prior_low = float(np.max(h[-20:-4])), float(np.min(l[-20:-4]))
        last = float(c[-1])
        up = last > prior_high
        down = last < prior_low
        direction = 'up' if up else 'down' if down else None
        level = prior_high if up else prior_low if down else last
        distance = ((last-level)/max(comp_atr, 1e-12)) if up else ((level-last)/max(comp_atr, 1e-12)) if down else 0.0
        candle_range = max(float(h[-1]-l[-1]), 1e-12)
        body_ratio = abs(float(c[-1]-float(d['open'].iloc[-1]))) / candle_range if 'open' in d.columns else abs(float(c[-1]-float(c[-2]))) / candle_range
        # Close must hold beyond the boundary; large rejection wick increases fakeout risk.
        rejection = ((float(h[-1])-last)/candle_range) if up else ((last-float(l[-1]))/candle_range) if down else 1.0
        fakeout = float(np.clip(0.30*(1-min(distance/0.5, 1)) + 0.70*rejection, 0, 1)) if direction else 1.0
        confirmed = bool(quality >= 0.35 and duration >= 6 and expansion >= 1.35 and
                         release_vol >= 1.8 and direction and distance >= 0.08 and
                         body_ratio >= 0.45 and fakeout <= 0.62)
        return {'compression_ratio': round(ratio, 3), 'compression_duration_bars': int(duration),
                'compression_quality': round(quality, 3), 'release_confirmed': confirmed,
                'release_volume_ratio': round(release_vol, 2), 'breakout_distance_atr': round(distance, 2),
                'fakeout_risk': round(fakeout, 3), 'squeeze_release': confirmed}
    except Exception:
        return empty


def volume_flow_features(df: pd.DataFrame) -> dict:
    """Estimate directional volume flow without claiming order-book/smart-money access.

    Uses exchange taker-buy volume only when a trustworthy column is explicitly
    present. Otherwise uses candle close-location signed-volume as a weak proxy.
    A single oversized bar cannot qualify as persistent accumulation/distribution.
    """
    empty = {'flow_mode': 'unavailable', 'flow_delta_ratio': 0.0,
             'buy_pressure_ratio': 0.0, 'sell_pressure_ratio': 0.0,
             'flow_persistence': 0.0, 'buy_flow_persistence': 0.0,
             'sell_flow_persistence': 0.0, 'volume_spike_ratio': 0.0,
             'volume_acceleration_ratio': None, 'recent_volume_ratio': None,
             'pre_pump_score': None, 'pre_pump_candidate': False,
             'pre_pump_grade': 'insufficient', 'pre_pump_price_change_1h_pct': None,
             'pre_dump_score': None, 'pre_dump_candidate': False,
             'pre_dump_grade': 'insufficient', 'pre_dump_price_change_1h_pct': None,
             'prior_buy_pressure_ratio': None, 'buy_pressure_change': None,
             'sell_pressure_change': None,
             'accumulation_proxy': False, 'distribution_proxy': False,
             'flow_data_quality': 'insufficient'}
    try:
        cols = ['high', 'low', 'close', 'volume']
        d = df[cols + (['taker_buy_base_volume'] if 'taker_buy_base_volume' in df.columns else [])].copy()
        for k in cols + (['taker_buy_base_volume'] if 'taker_buy_base_volume' in d.columns else []):
            d[k] = pd.to_numeric(d[k], errors='coerce')
        d = d.replace([np.inf, -np.inf], np.nan).dropna(subset=cols)
        if len(d) < 120:
            return empty
        h, l, c, v = (d[k].to_numpy(dtype=float) for k in ('high', 'low', 'close', 'volume'))
        if np.any(v < 0) or np.any(h < l) or np.any(c <= 0):
            return empty
        base = float(np.median(v[-104:-8]))
        recent = v[-8:]
        if base <= 0 or float(np.sum(recent)) <= 0:
            return empty
        spike = float(np.mean(recent) / base)
        prior4_mean = float(np.mean(recent[:4]))
        latest4_mean = float(np.mean(recent[4:]))
        recent_volume_ratio = latest4_mean / base
        volume_acceleration = latest4_mean / max(prior4_mean, 1e-12)
        price_change_1h = float((c[-1] / c[-5] - 1.0) * 100.0)
        actual = 'taker_buy_base_volume' in d.columns
        if actual:
            tb_all = d['taker_buy_base_volume'].to_numpy(dtype=float)
            tb = tb_all[-8:]
            prior_tb = tb_all[-16:-8]
            if (np.any(~np.isfinite(tb_all[-16:])) or np.any(tb_all[-16:] < 0) or
                    np.any(tb_all[-16:] > v[-16:] * 1.001)):
                return empty
            signed = (2.0 * tb - recent)
            prior_signed = 2.0 * prior_tb - v[-16:-8]
            mode = 'taker_buy_volume'
            quality = 'exchange_taker_field'
        else:
            # Close-location value: +1 near high, -1 near low. This is not trade-side data.
            span = np.maximum(h[-8:] - l[-8:], np.maximum(np.abs(c[-8:]) * 1e-9, 1e-12))
            clv = np.clip((2.0 * c[-8:] - h[-8:] - l[-8:]) / span, -1.0, 1.0)
            signed = clv * recent
            prior_span = np.maximum(h[-16:-8] - l[-16:-8], np.maximum(np.abs(c[-16:-8]) * 1e-9, 1e-12))
            prior_clv = np.clip((2.0 * c[-16:-8] - h[-16:-8] - l[-16:-8]) / prior_span, -1.0, 1.0)
            prior_signed = prior_clv * v[-16:-8]
            mode = 'candle_signed_volume_proxy'
            quality = 'proxy_only'
        total = float(np.sum(recent))
        delta = float(np.sum(signed) / total)
        buy_ratio = float(np.clip((1.0 + delta) / 2.0, 0.0, 1.0))
        sell_ratio = float(np.clip((1.0 - delta) / 2.0, 0.0, 1.0))
        prior_total = float(np.sum(v[-16:-8]))
        prior_delta = float(np.sum(prior_signed) / prior_total) if prior_total > 0 else 0.0
        prior_buy_ratio = float(np.clip((1.0 + prior_delta) / 2.0, 0.0, 1.0))
        buy_pressure_change = buy_ratio - prior_buy_ratio
        signs = np.sign(signed[np.abs(signed) > total * 1e-5])
        if len(signs) < 4:
            buy_persistence = sell_persistence = persistence = 0.0
        else:
            # Keep directional persistence separate. The old max(up, down)
            # value could let a bearish setup pass because positive bars were
            # more numerous, even when a few large negative bars dominated volume.
            buy_persistence = float(np.mean(signs > 0))
            sell_persistence = float(np.mean(signs < 0))
            persistence = max(buy_persistence, sell_persistence)
        # Reject apparent flow driven by one candle (>65% of the entire 8-bar volume).
        concentration = float(np.max(recent) / total)
        stable = concentration <= 0.65 and spike >= 1.2
        accumulation = bool(stable and buy_persistence >= 0.65 and delta >= 0.18 and buy_ratio >= 0.58)
        distribution = bool(stable and sell_persistence >= 0.65 and delta <= -0.18 and sell_ratio >= 0.58)

        # V23.0.129: direction-specific persistence prevents opposite-side bar counts from qualifying a setup.
        # V23.0.108: early build-up detector. This is deliberately separate
        # from the main scout score and only describes volume/price evidence.
        volume_component = float(np.clip((recent_volume_ratio - 1.0) / 1.5, 0.0, 1.0))
        acceleration_component = float(np.clip((volume_acceleration - 1.0) / 1.25, 0.0, 1.0))
        buy_level_component = float(np.clip((buy_ratio - 0.50) / 0.25, 0.0, 1.0))
        buy_rise_component = float(np.clip((buy_pressure_change + 0.02) / 0.15, 0.0, 1.0))
        buy_component = 0.60 * buy_level_component + 0.40 * buy_rise_component
        buy_persistence_component = float(np.clip((buy_persistence - 0.50) / 0.50, 0.0, 1.0))
        pre_pump_score = 100.0 * (
            0.35 * volume_component + 0.25 * acceleration_component +
            0.25 * buy_component + 0.15 * buy_persistence_component
        )
        pre_pump_candidate = bool(
            stable and pre_pump_score >= 60.0 and recent_volume_ratio >= 1.35 and
            volume_acceleration >= 1.12 and buy_persistence >= 0.65 and buy_ratio >= 0.57 and
            buy_pressure_change >= 0.04 and delta >= 0.14 and
            -1.5 <= price_change_1h <= 2.5
        )
        # Mirror the pump detector for distribution / pre-dump conditions.
        sell_pressure_change = -buy_pressure_change
        sell_level_component = float(np.clip((sell_ratio - 0.50) / 0.25, 0.0, 1.0))
        sell_rise_component = float(np.clip((sell_pressure_change + 0.02) / 0.15, 0.0, 1.0))
        sell_component = 0.60 * sell_level_component + 0.40 * sell_rise_component
        sell_persistence_component = float(np.clip((sell_persistence - 0.50) / 0.50, 0.0, 1.0))
        pre_dump_score = 100.0 * (
            0.35 * volume_component + 0.25 * acceleration_component +
            0.25 * sell_component + 0.15 * sell_persistence_component
        )
        pre_dump_candidate = bool(
            stable and pre_dump_score >= 60.0 and recent_volume_ratio >= 1.35 and
            volume_acceleration >= 1.12 and sell_persistence >= 0.65 and sell_ratio >= 0.57 and
            sell_pressure_change >= 0.04 and delta <= -0.14 and
            -2.5 <= price_change_1h <= 1.5
        )
        return {'flow_mode': mode, 'flow_delta_ratio': round(delta, 3),
                'buy_pressure_ratio': round(buy_ratio, 3), 'sell_pressure_ratio': round(sell_ratio, 3),
                'flow_persistence': round(persistence, 3),
                'buy_flow_persistence': round(buy_persistence, 3),
                'sell_flow_persistence': round(sell_persistence, 3),
                'volume_spike_ratio': round(spike, 2),
                'volume_acceleration_ratio': round(volume_acceleration, 2),
                'recent_volume_ratio': round(recent_volume_ratio, 2),
                'pre_pump_score': round(pre_pump_score, 1),
                'pre_pump_candidate': pre_pump_candidate,
                'pre_pump_grade': 'exchange_taker' if actual else 'candle_proxy',
                'pre_pump_price_change_1h_pct': round(price_change_1h, 3),
                'pre_dump_score': round(pre_dump_score, 1),
                'pre_dump_candidate': pre_dump_candidate,
                'pre_dump_grade': 'exchange_taker' if actual else 'candle_proxy',
                'pre_dump_price_change_1h_pct': round(price_change_1h, 3),
                'prior_buy_pressure_ratio': round(prior_buy_ratio, 3),
                'buy_pressure_change': round(buy_pressure_change, 3),
                'sell_pressure_change': round(sell_pressure_change, 3),
                'accumulation_proxy': accumulation, 'distribution_proxy': distribution,
                'flow_data_quality': quality}
    except Exception:
        return empty


def candle_features(df: pd.DataFrame) -> dict | None:
    """Early-explosion evidence from 15m candles (needs >= 150 closed bars)."""
    try:
        d = df[['high', 'low', 'close', 'volume']].astype(float).replace([np.inf, -np.inf], np.nan).dropna()
    except Exception:
        return None
    if len(d) < 150:
        return None
    h, l, c, v = (d[k].to_numpy() for k in ('high', 'low', 'close', 'volume'))
    prev_c = np.r_[c[0], c[:-1]]
    tr = np.maximum(h - l, np.maximum(abs(h - prev_c), abs(l - prev_c)))
    base_vol = float(np.median(v[-100:-4]))
    if base_vol <= 0 or c[-1] <= 0:
        return None
    vol_ratio = float(np.mean(v[-4:]) / base_vol)
    hh, ll = float(np.max(h[-97:-1])), float(np.min(l[-97:-1]))
    up_break, dn_break = c[-1] > hh, c[-1] < ll
    atr_now = float(np.mean(tr[-8:]))
    atr_before = float(np.mean(tr[-104:-8])) or 1e-12
    atr_ratio = atr_now / atr_before
    coil = float(np.mean(tr[-40:-8])) / (float(np.mean(tr[-140:-40])) or 1e-12)
    atr14 = float(np.mean(tr[-22:-8])) or 1e-12
    mom_z = float((c[-1] - c[-5]) / atr14)
    direction = 'up' if (up_break or (not dn_break and mom_z > 0)) else 'down'
    near = (hh - c[-1]) / hh if direction == 'up' else (c[-1] - ll) / ll
    vol_s = float(np.clip((vol_ratio - 1.5) / 2.5, 0, 1))
    brk_s = 1.0 if (up_break and direction == 'up') or (dn_break and direction == 'down') else float(np.clip(0.5 - near / 0.02, 0, 0.5))
    exp_s = float(np.clip(atr_ratio - 1.0, 0, 1))
    mom_s = float(np.clip(abs(mom_z) / 4.0, 0, 1))
    score = 100 * (0.30 * vol_s + 0.20 * brk_s + 0.15 * exp_s + 0.15 * mom_s)
    hh_before = float(np.max(h[-101:-5])) if len(h) >= 101 else hh
    ll_before = float(np.min(l[-101:-5])) if len(l) >= 101 else ll
    fresh_breakout = bool((up_break and c[-5] <= hh_before) or (dn_break and c[-5] >= ll_before))
    comp = compression_features(df)
    recent = c[-5:]
    micro_trend = bool(direction == 'up' and np.sum(np.diff(recent) > 0) >= 4)
    if direction == 'down':
        micro_trend = bool(np.sum(np.diff(recent) < 0) >= 4)
    win = c[-12:]
    bars_since = int(len(win) - 1 - int(np.argmin(win))) if direction == 'up' else int(len(win) - 1 - int(np.argmax(win)))
    fresh_move = bool(bars_since <= 5)
    return {'candle_score': round(score, 1), 'vol_ratio': round(vol_ratio, 2), 'breakout': bool(up_break or dn_break),
            'atr_ratio': round(atr_ratio, 2), 'coiled': bool(coil < 0.8), 'momentum_atr': round(mom_z, 2),
            'direction': direction, 'fresh_breakout': fresh_breakout, **comp, **volume_flow_features(df),
            'micro_trend': micro_trend, 'fresh_move': fresh_move, 'bars_since_start': bars_since}


def final_score(c: dict, feats: dict | None) -> tuple[float, str, bool]:
    """Returns (score, phase, verified). Unverified coins are capped below the storm level.

    V20 phases (user request: catch the move at its START, not after 20-30%):
      early     move < 8%    -> "اول حرکت" (bonus for fresh evidence)
      running   move < 20%   -> "در حال حرکت"
      late      move < 40%   -> "دیر" (small penalty — chasing here is risky)
      exhausted move >= 40%  -> "احتمالاً دیرشده" (strong penalty)
    """
    cross = 10.0 * min(len(c['sources']), 5) / 5.0
    trend = 10.0 if c['trending'] else 0.0
    move = abs(c['c24'])
    phase = 'early' if move < 8 else 'running' if move < 20 else 'late' if move < 40 else 'exhausted'
    if c.get('identity_conflict'):
        # Divergent quotes can indicate ticker collision, stale venue data, or
        # a broken market mapping. Never promote such an instrument to a storm.
        raw = 0.55 * prescore(c, 0) + cross + trend
        return round(min(UNVERIFIED_CAP, raw), 1), phase, False
    if feats is None:
        return round(min(UNVERIFIED_CAP, 0.55 * prescore(c, 0) + cross + trend), 1), phase, False
    mtf = feats.get('mtf') if feats.get('mtf_checked') else None
    if mtf and not mtf.get('aligned'):
        # Strong countertrend evidence remains visible as a watch candidate only;
        # missing/conflicting higher-timeframe context cannot trigger a Storm.
        raw = feats['candle_score'] + cross + trend
        return round(min(MTF_UNALIGNED_CAP, raw), 1), phase, False
    score = feats['candle_score'] + cross + trend
    # freshness evidence only exists when candle features are available
    fresh = bool(feats.get('fresh_breakout') or feats.get('squeeze_release') or feats.get('fresh_move'))
    if phase == 'early':
        if fresh:
            score += 6                                       # caught at the start — exactly what we hunt
        # most of the 24h move just happened in the last hour -> the leg is young
        if abs(c.get('c1h') or 0.0) >= 0.5 * max(move, 0.5):
            score += 5
    elif phase == 'running':
        if fresh:
            score += 3
    elif phase == 'late':
        score -= 8                                           # already chewed 20-40%
    elif phase == 'exhausted':
        score -= 15                                          # the storm is mostly already over
    return round(max(0.0, min(100.0, score)), 1), phase, True


def merge_unique_candidates(*groups: list[dict]) -> list[dict]:
    """Merge candidate groups by symbol so learning/feedback runs once per asset."""
    merged, seen = [], set()
    for group in groups:
        for item in group or []:
            key = str(item.get('symbol') or item.get('base') or '').upper().strip()
            if not key:
                key = f'object:{id(item)}'
            if key in seen:
                continue
            seen.add(key)
            merged.append(item)
    return merged


def pre_dump_rejection_diagnostics(items: list[dict], selected: list[dict] | None = None) -> dict:
    """Explain why bearish flow candidates did not reach the pre-dump list.

    Counts are overlapping rejection reasons, not mutually exclusive totals.
    This is observability only: it does not change candidate eligibility.
    """
    selected_symbols = {str(x.get('symbol') or '').upper() for x in (selected or [])}
    counts = {key: 0 for key in (
        'unverified', 'not_early_phase', 'flow_not_qualified', 'score_below_60',
        '24h_move_out_of_range', '1h_move_out_of_range', 'selected'
    )}
    near_misses = []
    for item in items or []:
        try:
            score = float(item.get('pre_dump_score'))
            move24 = float(item.get('change_24h'))
            move1h = float(item.get('pre_dump_price_change_1h_pct'))
        except (TypeError, ValueError, OverflowError):
            continue
        reasons = []
        if item.get('verified') is not True:
            counts['unverified'] += 1; reasons.append('unverified')
        if item.get('phase') != 'early':
            counts['not_early_phase'] += 1; reasons.append('not_early_phase')
        if not item.get('pre_dump_candidate'):
            counts['flow_not_qualified'] += 1; reasons.append('flow_not_qualified')
        if score < 60.0:
            counts['score_below_60'] += 1; reasons.append('score_below_60')
        if not (-5.0 <= move24 <= 3.0):
            counts['24h_move_out_of_range'] += 1; reasons.append('24h_move_out_of_range')
        if not (-2.5 <= move1h <= 1.5):
            counts['1h_move_out_of_range'] += 1; reasons.append('1h_move_out_of_range')
        symbol = str(item.get('symbol') or '').upper()
        if symbol in selected_symbols:
            counts['selected'] += 1
        elif item.get('pre_dump_candidate') and reasons:
            near_misses.append({
                'symbol': symbol, 'pre_dump_score': round(score, 1),
                'change_24h': round(move24, 2), 'change_1h': round(move1h, 2),
                'phase': item.get('phase'), 'rejected_by': reasons
            })
    near_misses.sort(key=lambda x: x['pre_dump_score'], reverse=True)
    return {'scanned': len(items or []), 'selected': counts['selected'],
            'rejection_counts': counts, 'near_misses': near_misses[:10],
            'note': 'علت‌ها هم‌پوشانی دارند؛ این گزارش فقط تشخیصی است و فیلترها را تغییر نمی‌دهد.'}


def select_early_directional_candidates(items: list[dict], direction: str, limit: int = 8) -> list[dict]:
    """Select early pump OR dump setups with mirrored, direction-specific evidence."""
    direction = str(direction or '').lower()
    if direction not in ('up', 'down'):
        raise ValueError('direction must be up or down')
    selected = []
    score_key = 'pre_pump_score' if direction == 'up' else 'pre_dump_score'
    candidate_key = 'pre_pump_candidate' if direction == 'up' else 'pre_dump_candidate'
    move_key = 'pre_pump_price_change_1h_pct' if direction == 'up' else 'pre_dump_price_change_1h_pct'
    # Recalculate peer-relative strength in the candidate's own direction.
    # This avoids bullish percentiles leaking into bearish priority ranking.
    directional_items = [dict(item, direction=direction) for item in items]
    _annotate_relative_strength(directional_items)
    for item in directional_items:
        try:
            move24 = float(item.get('change_24h'))
            price1h = float(item.get(move_key))
            score = float(item.get(score_key))
            if not all(math.isfinite(x) for x in (move24, price1h, score)):
                continue
        except (TypeError, ValueError, OverflowError):
            continue
        move_ok = (-3.0 <= move24 <= 5.0) if direction == 'up' else (-5.0 <= move24 <= 3.0)
        intrahour_ok = (-1.5 <= price1h <= 2.5) if direction == 'up' else (-2.5 <= price1h <= 1.5)
        if (item.get('verified') is not True or item.get('phase') != 'early' or
                not item.get(candidate_key) or not move_ok or not intrahour_ok or score < 60.0):
            continue
        # The volume-flow detector is an independent directional observation.
        # Do not discard a valid bearish setup merely because the generic Scout
        # trend classifier currently labels the asset bullish (or vice versa).
        directional_item = dict(item)
        directional_item['direction'] = direction
        directional_item['signal_direction'] = direction
        directional_item['priority_signal_type'] = 'pre_dump' if direction == 'down' else 'pre_pump'
        selected.append(directional_item)
    selected.sort(key=lambda x: (
        float(x.get(score_key) or 0.0),
        float(x.get('relative_strength_score') if x.get('relative_strength_score') is not None else -1.0),
        float(x.get('score') or 0.0)), reverse=True)
    return selected[:max(0, int(limit))]


def _apply_directional_brain_priority(items: list[dict], direction: str) -> list[dict]:
    """Rank pre-pump and pre-dump candidates independently.

    The directional detector score is primary. Historical brain feedback is a
    small, bounded modifier only after its sample gate; generic trend direction
    and the opposite side's score are never used to rank this list.
    """
    if direction not in ("up", "down"):
        raise ValueError("direction must be up or down")
    score_key = "pre_pump_score" if direction == "up" else "pre_dump_score"
    for item in items:
        prediction = item.get("brain_prediction") or {}
        learning = prediction.get("pattern_learning") or {}
        try:
            raw = float(item.get(score_key) or 0.0)
            weight = float(learning.get("weight", 1.0))
            calls = int(learning.get("directional_calls") or 0)
            relative = float(item.get("relative_strength_score")) if item.get("relative_strength_score") is not None else 0.0
            if not all(math.isfinite(v) for v in (raw, weight, relative)):
                raise ValueError("non-finite directional priority")
        except (TypeError, ValueError, OverflowError):
            raw, weight, relative, calls = 0.0, 1.0, 0.0, 0
        if calls < 20:
            weight = 1.0
        weight = min(1.15, max(0.75, weight))
        # Relative strength is a tie-break influence, not a replacement for
        # direction-specific pre-move evidence.
        item["directional_brain_weight"] = round(weight, 3)
        item["directional_priority_score"] = round(raw * weight + max(0.0, min(100.0, relative)) * 0.05, 3)
        item["directional_priority_direction"] = direction
        item["directional_priority_reliability"] = learning.get("reliability", "insufficient_samples")
    return sorted(items, key=lambda x: (
        float(x.get("directional_priority_score") or 0.0),
        float(x.get(score_key) or 0.0),
        float(x.get("score") or 0.0)), reverse=True)


def _apply_historical_pattern_priority(items: list[dict], direction: str, matcher=None) -> list[dict]:
    """Use mined pump/dump history as a small, sample-gated ranking modifier.

    This only reorders already-qualified directional watchlist entries. Missing,
    stale/unavailable, mixed, or under-sampled history contributes zero points.
    It cannot create a signal, change eligibility, or authorize execution.
    """
    if direction not in ("up", "down"):
        raise ValueError("direction must be up or down")
    if matcher is None:
        from backend.historical_pattern_matcher import match_current_to_history
        matcher = match_current_to_history
    for item in items:
        symbol = str(item.get("symbol") or item.get("base") or "").upper()
        evidence = {"status": "unavailable", "historical_bias": "insufficient_samples",
                    "historical_samples": 0, "priority_adjustment": 0.0}
        try:
            report = matcher(symbol=symbol, timeframe="1h", min_samples=5)
            matches = report.get("matches") or []
            match = next((m for m in matches if str(m.get("symbol", "")).upper() == symbol), None)
            if match:
                samples = int(match.get("historical_samples") or 0)
                bias = match.get("historical_bias")
                share_key = "pump_share_pct" if direction == "up" else "dump_share_pct"
                share = match.get(share_key)
                if samples >= 5 and bias in ("pump_favored", "dump_favored") and share is not None:
                    # Maximum +/- 2.5 ranking points; never a direct signal score.
                    adjustment = max(-2.5, min(2.5, (float(share) - 50.0) / 20.0))
                    if (direction == "up" and bias == "dump_favored") or (direction == "down" and bias == "pump_favored"):
                        adjustment = -abs(adjustment)
                    elif (direction == "up" and bias == "pump_favored") or (direction == "down" and bias == "dump_favored"):
                        adjustment = abs(adjustment)
                    else:
                        adjustment = 0.0
                    evidence = {"status": report.get("status", "completed"),
                                "historical_bias": bias, "historical_samples": samples,
                                "pump_share_pct": match.get("pump_share_pct"),
                                "dump_share_pct": match.get("dump_share_pct"),
                                "evidence_reliability": match.get("evidence_reliability", "low"),
                                "priority_adjustment": round(adjustment, 3),
                                "is_forecast": False}
                else:
                    evidence.update({"status": report.get("status", "completed"),
                                     "historical_bias": bias or "insufficient_samples",
                                     "historical_samples": samples,
                                     "is_forecast": False})
            else:
                evidence["status"] = report.get("status", "no_matching_candles")
        except Exception as exc:
            evidence["status"] = "unavailable"
            evidence["error"] = str(exc)[:120]
        item["historical_pattern_evidence"] = evidence
        base = float(item.get("directional_priority_score") or item.get("pre_pump_score" if direction == "up" else "pre_dump_score") or 0.0)
        item["historical_pattern_priority_score"] = round(base + evidence["priority_adjustment"], 3)
        item["historical_pattern_direction"] = direction
    return sorted(items, key=lambda x: (float(x.get("historical_pattern_priority_score") or 0.0),
                                        float(x.get("directional_priority_score") or 0.0),
                                        float(x.get("score") or 0.0)), reverse=True)


def _failure_pattern_bucket(feature: str, value):
    """Mirror the signal-time buckets used by market_brain.directional_failure_patterns."""
    if value is None or value == '':
        return None
    if feature in ('market_regime', 'phase'):
        return str(value).strip().lower()[:40]
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    if feature == 'sell_ratio':
        return '<0.45' if number < .45 else '0.45-0.55' if number < .55 else '0.55-0.65' if number < .65 else '>=0.65'
    if feature == 'volume_ratio':
        return '<1.0' if number < 1 else '1.0-1.2' if number < 1.2 else '1.2-1.5' if number < 1.5 else '>=1.5'
    if feature in ('score', 'pre_pump_score', 'pre_dump_score', 'active_dump_score'):
        return '<60' if number < 60 else '60-69' if number < 70 else '70-79' if number < 80 else '>=80'
    return None


def _apply_learned_failure_pattern_adjustment(items: list[dict], signal_type: str, report: dict) -> list[dict]:
    """Apply a tiny, evidence-gated display-rank adjustment; never changes eligibility."""
    baseline = next((b for b in report.get('baseline', [])
                     if b.get('signal_type') == signal_type and b.get('horizon') == '24h'), None)
    # Require a meaningful overall baseline and robust per-condition evidence.
    if not baseline or int(baseline.get('resolved') or 0) < 50:
        for item in items:
            item['failure_pattern_weight'] = 1.0
            item['failure_pattern_reliability'] = 'insufficient_samples'
        return items

    patterns = [p for p in report.get('patterns', [])
                if p.get('signal_type') == signal_type and p.get('horizon') == '24h'
                and int(p.get('samples') or 0) >= 30]
    for item in items:
        matched_lifts = []
        for pattern in patterns:
            feature = pattern.get('feature')
            bucket = _failure_pattern_bucket(feature, item.get(feature))
            if bucket is not None and bucket == pattern.get('value'):
                n = int(pattern.get('samples') or 0)
                # Shrink small-but-qualified groups toward the baseline to limit overfit.
                confidence = n / (n + 50.0)
                matched_lifts.append(float(pattern.get('failure_lift_pp') or 0.0) * confidence)
        if matched_lifts:
            avg_lift = sum(matched_lifts) / len(matched_lifts)
            weight = 1.0 - (avg_lift / 100.0) * 0.15
            weight = min(1.05, max(0.95, weight))
            item['failure_pattern_weight'] = round(weight, 4)
            item['failure_pattern_reliability'] = 'evidence_gated_24h'
            item['failure_pattern_matches'] = len(matched_lifts)
        else:
            item['failure_pattern_weight'] = 1.0
            item['failure_pattern_reliability'] = 'no_matching_pattern'
            item['failure_pattern_matches'] = 0
        item['directional_priority_score'] = round(
            float(item.get('directional_priority_score') or 0.0) * item['failure_pattern_weight'], 3)
    return sorted(items, key=lambda x: (
        float(x.get('directional_priority_score') or 0.0),
        float(x.get('pre_pump_score') if signal_type == 'pre_pump' else x.get('pre_dump_score') or 0.0),
        float(x.get('score') or 0.0)), reverse=True)


def _apply_failure_audit_priority(items: list[dict], direction: str, report: dict) -> list[dict]:
    """Apply a very small, sample-gated rank penalty from resolved failure audits.

    Only a repeated 24h context with at least 30 decisive observations and a
    direction-wide baseline of at least 50 decisive observations can contribute.
    It never changes candidate eligibility, raw scores, or execution state.
    """
    side = 'down' if direction == 'down' else 'up'
    baseline = next((b for b in report.get('baseline', [])
                     if b.get('direction') == side and b.get('horizon') == '24h'), None)
    if not baseline or int(baseline.get('decisive_samples') or 0) < 50 or baseline.get('failure_rate') is None:
        for item in items:
            item['failure_audit_adjustment'] = 0.0
            item['failure_audit_reliability'] = 'insufficient_baseline'
        return items

    def score_band(value):
        try:
            score = float(value)
        except (TypeError, ValueError, OverflowError):
            return None
        return 'low' if score < 40 else 'medium' if score < 70 else 'high'

    base_rate = float(baseline['failure_rate'])
    patterns = [p for p in report.get('patterns', [])
                if p.get('direction') == side and p.get('horizon') == '24h'
                and int(p.get('samples') or 0) >= 30
                and int(p.get('successes') or 0) + int(p.get('failures') or 0) >= 30
                and p.get('failure_rate') is not None]
    for item in items:
        matches = []
        for pattern in patterns:
            if (str(item.get('phase') or 'unknown') == str(pattern.get('phase') or 'unknown')
                and str(item.get('market_regime') or 'UNKNOWN') == str(pattern.get('market_regime') or 'UNKNOWN')
                and score_band(item.get('score')) == pattern.get('score_band')):
                matches.append(pattern)
        if not matches:
            item['failure_audit_adjustment'] = 0.0
            item['failure_audit_reliability'] = 'no_matching_pattern'
            item['failure_audit_matches'] = 0
            continue
        # Most specific match is unique by grouping; conservative shrinkage
        # prevents small samples from dominating the rank.
        pattern = max(matches, key=lambda p: int(p.get('samples') or 0))
        n = int(pattern.get('successes') or 0) + int(pattern.get('failures') or 0)
        posterior = (float(pattern['failure_rate']) * n + base_rate * 30.0) / (n + 30.0)
        excess = max(0.0, posterior - base_rate)
        penalty = min(2.0, excess * 4.0)  # maximum 2 ranking points
        item['failure_audit_adjustment'] = round(-penalty, 3)
        item['failure_audit_reliability'] = 'evidence_gated_24h'
        item['failure_audit_matches'] = 1
        item['directional_priority_score'] = round(
            float(item.get('directional_priority_score') or 0.0) - penalty, 3)
    return sorted(items, key=lambda x: (
        float(x.get('directional_priority_score') or 0.0),
        float(x.get('score') or 0.0)), reverse=True)


def _apply_contrastive_outcome_priority(items: list[dict], direction: str, report: dict) -> list[dict]:
    """Compare successful and failed outcomes in the same directional context.

    The direction-wide 24h success rate is the reference. A context-specific
    rate is shrunk toward that baseline before applying a small rank-only
    adjustment. Neutral, pending and missing observations are excluded by the
    audit producer. No candidate eligibility or execution state is changed.
    """
    side = 'down' if direction == 'down' else 'up'
    baseline = next((b for b in report.get('baseline', [])
                     if b.get('direction') == side and b.get('horizon') == '24h'), None)
    if not baseline:
        baseline_n, base_success = 0, None
    else:
        baseline_n = int(baseline.get('decisive_samples') or 0)
        failure_rate = baseline.get('failure_rate')
        base_success = (1.0 - float(failure_rate)) if failure_rate is not None else None
    eligible = (baseline_n >= 50 and base_success is not None)
    if not eligible:
        for item in items:
            item['contrastive_outcome_adjustment'] = 0.0
            item['contrastive_outcome_reliability'] = 'insufficient_directional_baseline'
            item['contrastive_outcome_matches'] = 0
        return items

    def score_band(value):
        try:
            score = float(value)
        except (TypeError, ValueError, OverflowError):
            return None
        return 'low' if score < 40 else 'medium' if score < 70 else 'high'

    patterns = [p for p in report.get('patterns', [])
                if p.get('direction') == side and p.get('horizon') == '24h'
                and int(p.get('successes') or 0) + int(p.get('failures') or 0) >= 30]
    for item in items:
        matches = [p for p in patterns
                   if str(item.get('phase') or 'unknown') == str(p.get('phase') or 'unknown')
                   and str(item.get('market_regime') or 'UNKNOWN') == str(p.get('market_regime') or 'UNKNOWN')
                   and score_band(item.get('score')) == p.get('score_band')]
        if not matches:
            item['contrastive_outcome_adjustment'] = 0.0
            item['contrastive_outcome_reliability'] = 'no_matching_context'
            item['contrastive_outcome_matches'] = 0
            continue
        pattern = max(matches, key=lambda p: int(p.get('successes') or 0) + int(p.get('failures') or 0))
        wins, losses = int(pattern.get('successes') or 0), int(pattern.get('failures') or 0)
        n = wins + losses
        if n < 30:
            adjustment = 0.0
        else:
            # Empirical-Bayes style shrinkage: 30 baseline-equivalent prior samples.
            posterior_success = (wins + base_success * 30.0) / (n + 30.0)
            lift = posterior_success - base_success
            adjustment = max(-1.5, min(1.5, lift * 3.0))
        item['contrastive_outcome_adjustment'] = round(adjustment, 3)
        item['contrastive_outcome_reliability'] = 'sample_gated_24h'
        item['contrastive_outcome_matches'] = 1
        item['contrastive_outcome_success_lift_pp'] = round((wins / n - base_success) * 100.0, 2) if n else None
        item['directional_priority_score'] = round(
            float(item.get('directional_priority_score') or 0.0) + adjustment, 3)
    return sorted(items, key=lambda x: (
        float(x.get('directional_priority_score') or 0.0),
        float(x.get('score') or 0.0)), reverse=True)


def _apply_feature_combo_priority(items: list[dict], direction: str, report: dict) -> list[dict]:
    """Rank only already-qualified candidates using joint historical feature cohorts.

    Cohorts combine volume acceleration, directional pressure, peer-relative
    strength, flow source grade and BTC regime. Pump and dump evidence never
    crosses directions. Missing or under-sampled cohorts are neutral.
    """
    if direction not in ("up", "down"):
        raise ValueError("direction must be up or down")
    learning = report.get("feature_combo_learning") or {}
    cohorts = learning.get("cohorts") or []

    def number(value):
        try:
            value = float(value)
            return value if math.isfinite(value) else None
        except (TypeError, ValueError, OverflowError):
            return None

    def bands(item):
        volume = number(item.get("volume_acceleration_ratio"))
        volume_band = ('unknown' if volume is None or volume <= 0 else
                       'strong' if volume >= 1.50 else 'rising' if volume >= 1.15 else 'low')
        pressure = number(item.get('sell_pressure_ratio' if direction == 'down' else 'buy_pressure_ratio'))
        change = number(item.get('sell_pressure_change' if direction == 'down' else 'buy_pressure_change'))
        if pressure is None or change is None:
            pressure_band = 'unknown'
        elif pressure >= .65 and change >= .05:
            pressure_band = 'strong'
        elif pressure >= .57 and change >= .02:
            pressure_band = 'rising'
        else:
            pressure_band = 'weak'
        strength = number(item.get('relative_strength_score'))
        strength_band = ('unknown' if strength is None or not 0 <= strength <= 100 else
                         'leader' if strength >= 70 else 'middle' if strength >= 40 else 'lagging')
        return volume_band, pressure_band, strength_band

    for item in items:
        volume_band, pressure_band, strength_band = bands(item)
        regime = str(item.get('market_regime') or item.get('btc_regime_4h') or 'UNKNOWN').strip().upper()
        if regime not in ('UP', 'DOWN', 'NEUTRAL'):
            regime = 'UNKNOWN'
        grade = str(item.get('flow_grade') or item.get('pre_pump_grade') or 'unknown')
        matching = [c for c in cohorts
                    if str(c.get('direction') or 'up').lower() == direction
                    and str(c.get('market_regime') or 'UNKNOWN').upper() == regime
                    and str(c.get('flow_grade') or 'unknown') == grade
                    and c.get('volume_band') == volume_band
                    and c.get('buy_pressure_band', c.get('pressure_band')) == pressure_band
                    and c.get('relative_strength_band') == strength_band]
        cohort = next((c for c in matching if (c.get('horizons') or {}).get('24h', {}).get('samples', 0) >= 30), None)
        if not cohort:
            item['feature_combo_adjustment'] = 0.0
            item['feature_combo_reliability'] = 'insufficient_or_no_matching_cohort'
            item['feature_combo_samples'] = 0
            continue
        stats = cohort['horizons']['24h']
        n = int(stats.get('samples') or 0)
        rate = number(stats.get('success_rate'))
        if n < 30 or rate is None:
            adjustment = 0.0
        else:
            # Conservative shrinkage to neutral 50%; max +/-1.0 rank point.
            posterior = (rate * n + .5 * 30.0) / (n + 30.0)
            adjustment = max(-1.0, min(1.0, (posterior - .5) * 4.0))
        item['feature_combo_adjustment'] = round(adjustment, 3)
        item['feature_combo_reliability'] = 'joint_24h_cohort_sample_gated'
        item['feature_combo_samples'] = n
        item['feature_combo_key'] = cohort.get('key')
        item['directional_priority_score'] = round(
            float(item.get('directional_priority_score') or 0.0) + adjustment, 3)
    return sorted(items, key=lambda x: (
        float(x.get('directional_priority_score') or 0.0),
        float(x.get('score') or 0.0)), reverse=True)


def select_pre_pump_candidates(items: list[dict], limit: int = 8) -> list[dict]:
    """Backward-compatible bullish early-move selector."""
    return select_early_directional_candidates(items, 'up', limit)


def select_active_dump_candidates(items: list[dict], limit: int = 8) -> list[dict]:
    """Identify already-active selloffs separately from early pre-dump setups.

    This list is intentionally not a pre-dump signal: it requires downside
    momentum plus independent sell-flow evidence and never changes classic tiers.
    """
    selected = []
    for source in items or []:
        if source.get('verified') is not True:
            continue
        try:
            move1h = float(source.get('change_1h'))
            move24 = float(source.get('change_24h'))
            sell_ratio = float(source.get('sell_pressure_ratio'))
            persistence = float(source.get('sell_flow_persistence'))
            volume_ratio = float(source.get('recent_volume_ratio'))
        except (TypeError, ValueError, OverflowError):
            continue
        if not all(math.isfinite(x) for x in (move1h, move24, sell_ratio, persistence, volume_ratio)):
            continue
        momentum = move1h <= -2.5 or move24 <= -6.0
        sell_flow = sell_ratio >= 0.55 and persistence >= 0.50
        volume_confirmed = volume_ratio >= 1.20
        if not (momentum and sell_flow and volume_confirmed):
            continue
        momentum_strength = max(
            float(np.clip((-move1h - 2.5) / 7.5, 0.0, 1.0)),
            float(np.clip((-move24 - 6.0) / 18.0, 0.0, 1.0)),
        )
        score = 100.0 * (
            0.35 * float(np.clip((sell_ratio - 0.50) / 0.35, 0.0, 1.0)) +
            0.25 * float(np.clip((persistence - 0.50) / 0.50, 0.0, 1.0)) +
            0.20 * float(np.clip((volume_ratio - 1.0) / 2.0, 0.0, 1.0)) +
            0.20 * momentum_strength
        )
        item = dict(source)
        item.update({
            'direction': 'down', 'signal_direction': 'down',
            'priority_signal_type': 'active_dump',
            'active_dump_score': round(score, 1),
            'active_dump_1h_change': round(move1h, 2),
            'active_dump_24h_change': round(move24, 2),
        })
        selected.append(item)
    selected.sort(key=lambda x: (float(x.get('active_dump_score') or 0.0),
                                 float(x.get('sell_pressure_ratio') or 0.0)), reverse=True)
    return selected[:max(0, int(limit))]


def select_pre_dump_candidates(items: list[dict], limit: int = 8) -> list[dict]:
    """Bearish mirror of the pre-pump selector."""
    return select_early_directional_candidates(items, 'down', limit)


# ---------------------------------------------------------------- scan
def trend_context_features(df: pd.DataFrame) -> dict | None:
    """Compact directional context for 1h structure / 4h BTC regime.

    Uses only closed OHLC candles. A directional state requires price/EMA
    ordering and a six-bar return in the same direction; otherwise it is neutral.
    """
    try:
        close = pd.to_numeric(df['close'], errors='coerce').replace([np.inf, -np.inf], np.nan).dropna()
        if len(close) < 60 or (close <= 0).any():
            return None
        ema20 = float(close.ewm(span=20, adjust=False).mean().iloc[-1])
        ema50 = float(close.ewm(span=50, adjust=False).mean().iloc[-1])
        last = float(close.iloc[-1])
        roc6 = float((last / float(close.iloc[-7]) - 1.0) * 100.0)
        if last > ema20 > ema50 and roc6 > 0.10:
            state = 'up'
        elif last < ema20 < ema50 and roc6 < -0.10:
            state = 'down'
        else:
            state = 'neutral'
        return {'state': state, 'close': last, 'ema20': ema20, 'ema50': ema50,
                'roc6_pct': round(roc6, 3)}
    except Exception:
        return None


def evaluate_mtf_alignment(trigger: dict | None, structure: dict | None,
                           btc_regime: dict | None) -> dict:
    """Fail-closed 15m trigger + 1h structure + BTC 4h regime decision."""
    direction = (trigger or {}).get('direction')
    structure_state = (structure or {}).get('state')
    btc_state = (btc_regime or {}).get('state')
    if direction not in ('up', 'down') or structure_state not in ('up', 'down', 'neutral') \
            or btc_state not in ('up', 'down', 'neutral'):
        return {'checked': True, 'aligned': False, 'status': 'incomplete',
                'direction': direction, 'structure_1h': structure_state, 'btc_regime_4h': btc_state}
    structure_ok = structure_state == direction
    btc_ok = btc_state in ('neutral', direction)
    aligned = bool(structure_ok and btc_ok)
    countertrend_strong = bool(
        not aligned and trigger.get('breakout') and
        float(trigger.get('vol_ratio') or 0) >= 3.0 and
        float(trigger.get('candle_score') or 0) >= 85.0
    )
    status = 'aligned' if aligned else 'strong_countertrend_watch' if countertrend_strong else 'conflict'
    return {'checked': True, 'aligned': aligned, 'status': status,
            'direction': direction, 'structure_1h': structure_state,
            'btc_regime_4h': btc_state, 'countertrend_evidence': countertrend_strong}


def _verified_frame(fetcher, symbol: str, timeframe: str, limit: int,
                    max_age_bars: int, now_ms: float) -> pd.DataFrame | None:
    df = fetcher(symbol, timeframe, limit=limit, source='auto')
    if df is None or len(df) < 60 or df.attrs.get('source') == 'cache':
        return None
    try:
        last_t = float(df['t'].iloc[-1])
    except Exception:
        return None
    interval_ms = {'15m': 15, '1h': 60, '4h': 240}[timeframe] * 60_000
    age_ms = now_ms - last_t
    if not math.isfinite(last_t) or age_ms > max_age_bars * interval_ms or age_ms < -interval_ms:
        return None
    return df


def verify_multi_timeframe(base: str, fetcher=None, now_ms: float | None = None) -> dict | None:
    """Verify 15m trigger, 1h coin structure and 4h BTC market regime.

    Any missing, cached or stale timeframe fails closed. The optional fetcher
    exists for deterministic tests; production uses backend.data.fetch_candles.
    """
    if fetcher is None:
        from backend.data import fetch_candles
        fetcher = fetch_candles
    now_ms = float(now_ms if now_ms is not None else time.time() * 1000)
    try:
        trigger_df = _verified_frame(fetcher, f'{base}USDT', '15m', 300, 4, now_ms)
        structure_df = _verified_frame(fetcher, f'{base}USDT', '1h', 240, 2, now_ms)
        btc_df = _verified_frame(fetcher, 'BTCUSDT', '4h', 240, 2, now_ms)
        if trigger_df is None or structure_df is None or btc_df is None:
            return None
        trigger = candle_features(trigger_df)
        structure = trend_context_features(structure_df)
        btc_regime = trend_context_features(btc_df)
        if trigger is None or structure is None or btc_regime is None:
            return None
        mtf = evaluate_mtf_alignment(trigger, structure, btc_regime)
        return {**trigger, 'mtf': mtf, 'structure_1h': structure,
                'btc_regime_4h': btc_regime, 'mtf_checked': True}
    except Exception:
        return None


def _verify(base: str) -> dict | None:
    return verify_multi_timeframe(base)


def scan_once(max_candidates: int = 14, verify: Callable[[str], dict | None] | None = None) -> dict:
    _apply_proxy()
    min_vol = float(os.getenv('SCOUT_MIN_VOLUME', '2000000'))
    rows, report = _collect()
    ok_sources = [r for r in report if r.get('ok')]
    result: dict[str, Any] = {'generated_at': int(time.time()), 'sources': report,
                              'sources_ok': len(ok_sources), 'sources_total': len(SOURCES),
                              'online': bool(ok_sources), 'alerts': [], 'watch': [], 'early': [],
                              'pre_pump': [], 'pre_dump': [], 'active_dump': [], 'pre_dump_diagnostics': {}, 'stale': False}
    if not ok_sources:
        result['error'] = 'هیچ منبعی پاسخ نداد (اینترنت/فیلتر). دوباره خودکار تلاش می‌شود.'
        return result
    coins = merge(rows)
    ranked = sorted(((prescore(c, min_vol), b) for b, c in coins.items()), reverse=True)
    cands = [b for s, b in ranked if s > 0][:max_candidates]
    verify = verify or _verify
    feats: dict[str, dict | None] = {}
    pool = ThreadPoolExecutor(max_workers=4)
    futs = {pool.submit(verify, b): b for b in cands}
    try:
        for fut in as_completed(futs, timeout=60):
            try:
                feats[futs[fut]] = fut.result()
            except Exception:
                feats[futs[fut]] = None
    except FutTimeout:
        pass
    pool.shutdown(wait=False, cancel_futures=True)
    items = []
    for b in cands:
        c, f = coins[b], feats.get(b)
        score, phase, verified = final_score(c, f)
        direction = (f or {}).get('direction') or ('up' if c['c24'] >= 0 else 'down')
        # ---- V20: compact reasons (UI shows them in a tooltip, keep them short) ----
        reasons = []
        if c.get('identity_conflict'):
            reasons.append(f'اختلاف قیمت منابع {c["price_dispersion_pct"]:.1f}٪')
        if f:
            if f.get('pre_pump_candidate'):
                flow_label = 'فشار خرید تیکر' if f.get('pre_pump_grade') == 'exchange_taker' else 'پروکسی فشار خرید کندلی'
                reasons.append(
                    f'پیش‌نشانگر: حجم {f.get("recent_volume_ratio", 0):.1f}×، '
                    f'شتاب {f.get("volume_acceleration_ratio", 0):.1f}×، {flow_label}'
                )
            mtf = f.get('mtf') or {}
            if mtf.get('status') == 'aligned':
                reasons.append('هم‌جهتی ۱۵دقیقه/۱ساعت با رژیم BTC چهار‌ساعته')
            elif mtf.get('checked'):
                reasons.append('ناهم‌جهتی تایم‌فریم‌ها؛ فقط واچ، بدون هشدار طوفان')
            if f.get('fresh_breakout'):
                reasons.append('شکست تازه')
            elif f.get('breakout'):
                reasons.append('شکست سقف ۲۴س')
            if f['vol_ratio'] >= 2:
                reasons.append(f'حجم {f["vol_ratio"]:.1f}×')
            if f.get('squeeze_release'):
                reasons.append('فشردگی → انبساط')
            if f.get('accumulation_proxy'):
                reasons.append('فشار خرید پایدار (پروکسی حجم)')
            elif f.get('distribution_proxy'):
                reasons.append('فشار فروش پایدار (پروکسی حجم)')
            if f.get('pre_dump_candidate'):
                flow_label = 'تیکر فروش واقعی' if f.get('pre_dump_grade') == 'exchange_taker' else 'پروکسی فشار فروش کندلی'
                reasons.append(f'پیش‌نشانگر دامپ: حجم {f.get("recent_volume_ratio", 0):.1f}×، شتاب {f.get("volume_acceleration_ratio", 0):.1f}×، {flow_label}')
            if f.get('micro_trend'):
                reasons.append('میکروترند پله‌ای')
            if abs(f.get('momentum_atr', 0)) >= 2:
                reasons.append(f'شتاب {f["momentum_atr"]:+.1f} ATR/۱س')
        if c.get('c1h') is not None and abs(c['c1h']) >= 0.5 * max(abs(c['c24']), 0.5) and abs(c['c1h']) >= 1.5:
            reasons.append('حرکت تازه (۱ساعته)')
        if c['trending']:
            reasons.append('ترند CMC/CoinGecko')
        if c.get('mcap') and c['mcap'] < 150e6:
            reasons.append('کپ کوچک')
        reasons.append(f'{len(c["sources"])} منبع تأیید')
        if not verified:
            reasons.append('تأیید بازار/کندل ناقص')
        fresh = bool(f and (f.get('fresh_breakout') or f.get('squeeze_release') or f.get('fresh_move')))
        items.append({'symbol': f'{b}USDT', 'base': b, 'score': score, 'direction': direction, 'phase': phase,
                      'verified': verified, 'fresh': fresh,
                      'identity_conflict': bool(c.get('identity_conflict')),
                      'price_dispersion_pct': c.get('price_dispersion_pct', 0.0),
                      'price_source_count': c.get('price_source_count', len(c['sources'])),
                      'exchange_source_count': c.get('exchange_source_count', len(c['exch'])),
                      'bars_since_start': (f or {}).get('bars_since_start'),
                      'mtf': (f or {}).get('mtf'),
                      'structure_1h': (f or {}).get('structure_1h'),
                      'btc_regime_4h': (f or {}).get('btc_regime_4h'),
                      'price': c['price'], 'change_24h': round(c['c24'], 2),
                      'change_1h': None if c['c1h'] is None else round(c['c1h'], 2),
                      'pre_pump_candidate': bool((f or {}).get('pre_pump_candidate')),
                      'pre_pump_score': (f or {}).get('pre_pump_score'),
                      'pre_pump_grade': (f or {}).get('pre_pump_grade', 'insufficient'),
                      'pre_pump_price_change_1h_pct': (f or {}).get('pre_pump_price_change_1h_pct'),
                      'pre_dump_candidate': bool((f or {}).get('pre_dump_candidate')),
                      'pre_dump_score': (f or {}).get('pre_dump_score'),
                      'pre_dump_grade': (f or {}).get('pre_dump_grade', 'insufficient'),
                      'pre_dump_price_change_1h_pct': (f or {}).get('pre_dump_price_change_1h_pct'),
                      'sell_pressure_ratio': (f or {}).get('sell_pressure_ratio'),
                      'sell_pressure_change': (f or {}).get('sell_pressure_change'),
                      'flow_grade': (f or {}).get('pre_pump_grade', 'unknown'),
                      'market_regime': ((f or {}).get('btc_regime_4h') or {}).get('state', 'UNKNOWN') if isinstance((f or {}).get('btc_regime_4h'), dict) else ((f or {}).get('btc_regime_4h') or 'UNKNOWN'),
                      'volume_acceleration_ratio': (f or {}).get('volume_acceleration_ratio'),
                      'recent_volume_ratio': (f or {}).get('recent_volume_ratio'),
                      'buy_pressure_ratio': (f or {}).get('buy_pressure_ratio'),
                      'buy_pressure_change': (f or {}).get('buy_pressure_change'),
                      'flow_persistence': (f or {}).get('flow_persistence'),
                      'sell_flow_persistence': (f or {}).get('sell_flow_persistence'),
                      'volume_usd': round(c['vol']), 'rank': c['rank'], 'sources': sorted(c['sources']),
                      'reasons': reasons[:4], 'features': f})
    items.sort(key=lambda x: x['score'], reverse=True)
    # V23.0.107: compare candidates against peers in this same scan.
    # V23.0.108: expose a distinct pre-pump build-up list before the classic tiers.
    _annotate_relative_strength(items)
    # V23.0.108: a separate pre-pump watchlist; it never changes the classic tiers.
    result['pre_pump'] = select_pre_pump_candidates(items, limit=8)
    result['pre_dump'] = select_pre_dump_candidates(items, limit=8)
    result['active_dump'] = select_active_dump_candidates(items, limit=8)
    result['pre_dump_diagnostics'] = pre_dump_rejection_diagnostics(items, result['pre_dump'])
    # V20: three tiers —
    #  early  : verified young legs (phase=early) with real evidence -> hunt FIRST
    #  alerts : full storms (exhausted coins are demoted to watch)
    #  watch  : forming storms
    early_pool = [i for i in items if i['verified'] and i['phase'] == 'early' and i['score'] >= EARLY_LEVEL]
    early_pool.sort(key=lambda x: (x['fresh'], x['score']), reverse=True)
    result['early'] = early_pool[:8]
    result['alerts'] = [i for i in items if i['score'] >= STORM_LEVEL and i['phase'] != 'exhausted'][:8]
    result['watch'] = [i for i in items if WATCH_LEVEL <= i['score'] < STORM_LEVEL][:8]
    result['candidates_checked'] = len(cands)
    # V23.0.84: persist real sightings and attach evidence-based outcomes.
    try:
        from backend import storm_learning
        # Persist directional early-move candidates first. Their explicit
        # pre-pump/pre-dump direction must take precedence over a conflicting
        # generic trend label for the same symbol and timestamp.
        learning_items = merge_unique_candidates(
            result['pre_pump'], result['pre_dump'], result['early'], result['alerts'], result['watch'])
        storm_learning.record_scan(learning_items, timestamp=float(result['generated_at']), snapshots=coins)
        storm_learning.annotate(learning_items)
        # Small independent historical brain: compares current 1h market state
        # with archived completed-candle patterns. No order/execution side effects.
        from backend import market_brain
        brain_items = learning_items
        result['market_brain'] = market_brain.predict(brain_items, now=float(result['generated_at']))
        # V23.0.127: independently rank the two early-directional watchlists.
        # This affects display priority only; eligibility and trading are untouched.
        result['pre_pump'] = _apply_directional_brain_priority(result.get('pre_pump', []), 'up')
        result['pre_dump'] = _apply_directional_brain_priority(result.get('pre_dump', []), 'down')
        # V23.0.134: cautiously use repeated 24h failure patterns for display ranking only.
        # A baseline needs 50 resolved samples and a matching condition needs 30 samples.
        result['directional_failure_patterns'] = market_brain.directional_failure_patterns(min_samples=30)
        result['pre_pump'] = _apply_learned_failure_pattern_adjustment(
            result.get('pre_pump', []), 'pre_pump', result['directional_failure_patterns'])
        result['pre_dump'] = _apply_learned_failure_pattern_adjustment(
            result.get('pre_dump', []), 'pre_dump', result['directional_failure_patterns'])
        # V23.0.145: mined historical pump AND dump patterns contribute a tiny,
        # sample-gated ranking adjustment to the corresponding directional list.
        result['pre_pump'] = _apply_historical_pattern_priority(result.get('pre_pump', []), 'up')
        result['pre_dump'] = _apply_historical_pattern_priority(result.get('pre_dump', []), 'down')
        # Persist forecasts and score due ones against later observed prices.
        result['market_brain_feedback'] = market_brain.record_feedback(
            brain_items, snapshots=coins, now=float(result['generated_at']))
        result['market_brain_feedback_summary'] = market_brain.feedback_summary()
        # V23.0.132: retain signal-time context and diagnose actual pre-pump, pre-dump and active-dump sightings.
        result['directional_signal_feedback'] = market_brain.record_directional_signal_feedback({
            'pre_pump': result.get('pre_pump', []),
            'pre_dump': result.get('pre_dump', []),
            'active_dump': result.get('active_dump', []),
        }, snapshots=coins, now=float(result['generated_at']))
        result['directional_signal_feedback_summary'] = market_brain.directional_signal_feedback_summary()
        # V23.0.132: explain resolved misses using the features captured at signal time.
        # Diagnostic only; no automatic threshold or model-weight changes.
        result['directional_failure_analysis'] = market_brain.directional_failure_analysis()
        # V23.0.133: summarize recurring failure-associated conditions; diagnostic only.
        result['directional_failure_patterns_diagnostic'] = market_brain.directional_failure_patterns(min_samples=5)
        # V23.0.148: cautious rank-only penalty from resolved Scout failure contexts.
        # Uses 24h outcomes, direction-specific baselines and a strict evidence gate.
        result['failure_pattern_priority_audit'] = storm_learning.failure_pattern_audit(min_samples=30, limit=100)
        result['pre_pump'] = _apply_failure_audit_priority(
            result.get('pre_pump', []), 'up', result['failure_pattern_priority_audit'])
        result['pre_dump'] = _apply_failure_audit_priority(
            result.get('pre_dump', []), 'down', result['failure_pattern_priority_audit'])
        # V23.0.149: compare successful AND failed outcomes against the same
        # direction-specific baseline; only a bounded rank-only adjustment.
        result['pre_pump'] = _apply_contrastive_outcome_priority(
            result.get('pre_pump', []), 'up', result['failure_pattern_priority_audit'])
        result['pre_dump'] = _apply_contrastive_outcome_priority(
            result.get('pre_dump', []), 'down', result['failure_pattern_priority_audit'])
        result['contrastive_outcome_priority_policy'] = {
            'horizon': '24h', 'direction_specific': True, 'baseline_min_samples': 50,
            'context_min_decisive_samples': 30, 'max_adjustment_points': 1.5,
            'rank_only': True, 'paper_only': True}
        # V23.0.96: validated pattern history affects display priority only.
        # Re-rank within existing qualified lists; do not promote new candidates
        # or alter score/thresholds/order execution.
        result['early'] = _apply_brain_priority(result.get('early', []))
        result['alerts'] = _apply_brain_priority(result.get('alerts', []))
        result['watch'] = _apply_brain_priority(result.get('watch', []))
        result['learning_summary'] = storm_learning.summary()
        # V23.0.150: use joint historical feature combinations (volume +
        # directional pressure + peer strength + flow grade + BTC regime).
        combo_report = (result['learning_summary'].get('pre_pump') or {}).get('feature_combo_learning') or {}
        result['pre_pump'] = _apply_feature_combo_priority(result.get('pre_pump', []), 'up',
                                                             {'feature_combo_learning': combo_report})
        result['pre_dump'] = _apply_feature_combo_priority(result.get('pre_dump', []), 'down',
                                                             {'feature_combo_learning': combo_report})
        result['feature_combo_priority_policy'] = {
            'horizon': '24h', 'directions_separate': True, 'minimum_cohort_samples': 30,
            'prior_samples': 30, 'max_adjustment_points': 1.0,
            'features': ['volume_acceleration', 'directional_pressure', 'relative_strength', 'flow_grade', 'btc_regime'],
            'rank_only': True, 'paper_only': True}
    except Exception as exc:
        # Learning is best-effort; a storage issue must not take down the market scan.
        result['learning_status'] = 'unavailable'
        result['learning_error'] = str(exc)[:160]
    result['disclaimer'] = ('پیش‌نشانگرهای پیش از پامپ و پیش از دامپ، به‌ترتیب شتاب حجم همراه فشار خرید یا فروش را بررسی می‌کنند؛ '
                            'پروکسی کندلی با داده واقعی تیکر یکسان نیست. چشم‌اندازها سناریویی‌اند؛ '
                            'نتیجه‌های ۱/۴/۲۴س فقط با مشاهده قیمت بعدی ثبت می‌شوند. هیچ‌کدام توصیه خرید یا تضمین سود نیست.')
    return result


# ------------------------------------------------------- background loop
def get_state() -> dict:
    with _LOCK:
        res = _STATE['result']
        out = dict(res) if res else {'generated_at': None, 'alerts': [], 'watch': [], 'sources': [],
                                     'online': False, 'note': 'هنوز اسکنی انجام نشده است.'}
        out['running'] = bool(_STATE['running'])
        out['fail_streak'] = _STATE['fail_streak']
        out['interval_sec'] = interval()
        return out


def interval() -> int:
    try:
        return max(60, int(os.getenv('SCOUT_INTERVAL_SEC', '300')))
    except ValueError:
        return 300


def run_scan() -> dict:
    """One guarded scan; keeps the last good result (marked stale) if the network is down."""
    with _LOCK:
        if _STATE['running']:
            return get_state()
        _STATE['running'] = True
    try:
        res = scan_once()
    except Exception as exc:
        res = {'generated_at': int(time.time()), 'online': False, 'alerts': [], 'watch': [],
               'sources': [], 'error': str(exc)[:160]}
    finally:
        with _LOCK:
            _STATE['running'] = False
    with _LOCK:
        prev = _STATE['result']
        if res.get('online'):
            _STATE['fail_streak'] = 0
            _STATE['result'] = res
        else:
            _STATE['fail_streak'] += 1
            if prev and prev.get('online'):
                keep = dict(prev)
                keep['stale'] = True
                keep['error'] = res.get('error')
                keep['sources'] = res.get('sources') or prev.get('sources')
                _STATE['result'] = keep
            else:
                _STATE['result'] = res
    return get_state()


def _loop() -> None:
    while not _STATE['stop']:
        run_scan()
        # offline -> retry sooner (30s, 60s, ... capped at the normal interval) so it
        # picks the internet up as soon as it returns
        streak = _STATE['fail_streak']
        wait = interval() if streak == 0 else min(interval(), 30 * (2 ** min(streak - 1, 4)))
        for _ in range(int(wait)):
            if _STATE['stop']:
                return
            time.sleep(1)


def start_background() -> bool:
    # The historical market brain is an independent startup task. It must
    # still learn from the local candle archive when live Storm Scout polling
    # is disabled by configuration.
    try:
        from backend import market_brain
        learning_started = market_brain.start_startup_learning()
        if learning_started:
            print('[market-brain] یادگیری آرشیو تاریخی به‌صورت خودکار در پس‌زمینه شروع شد.')
        else:
            state = market_brain.historical_learning_status().get('status', 'unknown')
            print(f'[market-brain] یادگیری تاریخی قبلاً شروع شده یا در وضعیت {state} است؛ شروع تکراری انجام نشد.')
    except Exception as exc:
        print(f'[market-brain] شروع یادگیری تاریخی ناموفق بود: {str(exc)[:180]}')
    if os.getenv('SCOUT_ENABLED', '1').strip() == '0':
        return False
    with _LOCK:
        t = _STATE.get('thread')
        if t and t.is_alive():
            return False
        _STATE['stop'] = False
        t = threading.Thread(target=_loop, name='storm-scout', daemon=True)
        _STATE['thread'] = t
    # The first live market scan begins in parallel with historical learning.
    t.start()
    return True



def stop_background(timeout: float = 3.0) -> bool:
    """Signal the background scout loop to stop and wait briefly for exit."""
    with _LOCK:
        _STATE['stop'] = True
        worker = _STATE.get('thread')
    if worker and worker.is_alive() and worker is not threading.current_thread():
        worker.join(timeout=max(0.0, min(float(timeout), 10.0)))
    return not bool(worker and worker.is_alive())


def trigger_refresh() -> bool:
    """Non-blocking manual refresh. Returns False if a scan is already running."""
    if _STATE['running']:
        return False
    threading.Thread(target=run_scan, name='storm-scout-manual', daemon=True).start()
    return True
