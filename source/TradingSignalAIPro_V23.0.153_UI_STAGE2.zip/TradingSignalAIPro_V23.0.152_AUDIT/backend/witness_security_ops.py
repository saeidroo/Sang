"""Security audit telemetry and offline key/token operations for Witness (V22.2v)."""
from __future__ import annotations
import base64, hashlib, json, os, secrets, sqlite3
from datetime import datetime, timezone
from pathlib import Path
from cryptography.hazmat.primitives import serialization


def _canonical(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def init_security_schema(db_path: str | Path) -> None:
    with sqlite3.connect(db_path) as db:
        db.execute('''CREATE TABLE IF NOT EXISTS security_events (
            event_id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT NOT NULL,
            category TEXT NOT NULL, method TEXT NOT NULL, route TEXT NOT NULL,
            status_code INTEGER NOT NULL, client_fingerprint TEXT NOT NULL,
            previous_hash TEXT NOT NULL, event_hash TEXT NOT NULL UNIQUE)''')
        db.executescript('''
        CREATE TRIGGER IF NOT EXISTS security_events_no_update BEFORE UPDATE ON security_events BEGIN SELECT RAISE(ABORT, 'append_only'); END;
        CREATE TRIGGER IF NOT EXISTS security_events_no_delete BEFORE DELETE ON security_events BEGIN SELECT RAISE(ABORT, 'append_only'); END;
        ''')


def record_security_event(db_path: str | Path, *, category: str, method: str,
                          route: str, status_code: int, client_identity: str = 'unknown') -> dict:
    """Append one sanitized event; raw IPs, tokens, bodies and query strings are never stored."""
    init_security_schema(db_path)
    client_fp = hashlib.sha256(client_identity.encode('utf-8', 'replace')).hexdigest()[:20]
    timestamp = datetime.now(timezone.utc).isoformat()
    db = sqlite3.connect(db_path, timeout=10, isolation_level=None)
    try:
        db.execute('PRAGMA busy_timeout=10000')
        db.execute('BEGIN IMMEDIATE')
        previous = db.execute('SELECT event_hash FROM security_events ORDER BY event_id DESC LIMIT 1').fetchone()
        prev_hash = previous[0] if previous else '0' * 64
        payload = {'timestamp': timestamp, 'category': str(category)[:48], 'method': str(method)[:12],
                   'route': str(route)[:160], 'status_code': int(status_code),
                   'client_fingerprint': client_fp, 'previous_hash': prev_hash}
        event_hash = hashlib.sha256(_canonical(payload)).hexdigest()
        cur = db.execute('''INSERT INTO security_events(timestamp,category,method,route,status_code,
                     client_fingerprint,previous_hash,event_hash) VALUES(?,?,?,?,?,?,?,?)''',
                     (timestamp, payload['category'], payload['method'], payload['route'],
                      payload['status_code'], client_fp, prev_hash, event_hash))
        db.execute('COMMIT')
        return {'event_id': cur.lastrowid, 'event_hash': event_hash}
    except Exception:
        if db.in_transaction: db.execute('ROLLBACK')
        raise
    finally:
        db.close()


def security_status(db_path: str | Path, *, limit: int = 100) -> dict:
    init_security_schema(db_path)
    limit = max(1, min(int(limit), 500))
    with sqlite3.connect(db_path) as db:
        total = db.execute('SELECT COUNT(*) FROM security_events').fetchone()[0]
        counts = {str(k): int(v) for k, v in db.execute(
            'SELECT category, COUNT(*) FROM security_events GROUP BY category').fetchall()}
        rows = db.execute('''SELECT event_id,timestamp,category,method,route,status_code,
            client_fingerprint,previous_hash,event_hash FROM security_events ORDER BY event_id DESC LIMIT ?''',
            (limit,)).fetchall()
    events = [dict(zip(('event_id','timestamp','category','method','route','status_code',
                        'client_fingerprint','previous_hash','event_hash'), row)) for row in rows]
    return {'total_events': total, 'counts_by_category': counts, 'recent_events': events}


def verify_security_chain(db_path: str | Path) -> dict:
    init_security_schema(db_path)
    expected_prev = '0' * 64
    checked = 0
    with sqlite3.connect(db_path) as db:
        rows = db.execute('''SELECT timestamp,category,method,route,status_code,client_fingerprint,
            previous_hash,event_hash FROM security_events ORDER BY event_id''').fetchall()
    for row in rows:
        timestamp, category, method, route, status, client_fp, previous, event_hash = row
        payload = {'timestamp': timestamp, 'category': category, 'method': method, 'route': route,
                   'status_code': status, 'client_fingerprint': client_fp, 'previous_hash': previous}
        calculated = hashlib.sha256(_canonical(payload)).hexdigest()
        if previous != expected_prev or calculated != event_hash:
            return {'valid': False, 'checked': checked, 'failed_at': checked + 1}
        expected_prev = event_hash
        checked += 1
    return {'valid': True, 'checked': checked, 'head_hash': expected_prev}


def key_fingerprint(path: str | Path) -> str:
    key = serialization.load_pem_public_key(Path(path).read_bytes())
    raw = key.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    return hashlib.sha256(raw).hexdigest()


def inspect_key_pair(private_path: str | Path, public_path: str | Path) -> dict:
    private = serialization.load_pem_private_key(Path(private_path).read_bytes(), password=None)
    public = serialization.load_pem_public_key(Path(public_path).read_bytes())
    derived = private.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    supplied = public.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    return {'matches': secrets.compare_digest(derived, supplied),
            'public_key_fingerprint_sha256': hashlib.sha256(supplied).hexdigest()}


def create_token_rotation_candidate(path: str | Path) -> dict:
    """Create a new 0600 token file; never overwrites. Activate only after controlled deployment."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    token = secrets.token_urlsafe(48)
    fd = os.open(str(target), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as stream:
        stream.write(token + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    return {'path': str(target), 'token': token,
            'token_fingerprint_sha256': hashlib.sha256(token.encode()).hexdigest(),
            'permissions_octal': oct(target.stat().st_mode & 0o777)}
