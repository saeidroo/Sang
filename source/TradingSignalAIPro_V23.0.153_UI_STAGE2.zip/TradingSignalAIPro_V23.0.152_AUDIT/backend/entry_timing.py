"""Read-only 15m entry-quality diagnostics for paper opportunity ranking."""
from __future__ import annotations
import math
import pandas as pd


def evaluate_entry_timing(candles, side: str) -> dict:
    """Classify pullback/breakout/late-entry evidence; never creates a trade signal."""
    side = str(side or '').upper()
    if side not in {'LONG', 'SHORT'}:
        return _unavailable('جهت معامله نامعتبر است')
    try:
        f = pd.DataFrame(candles).copy()
        needed = ['open', 'high', 'low', 'close']
        if any(c not in f for c in needed) or len(f) < 30:
            return _unavailable('حداقل ۳۰ کندل معتبر لازم است')
        for c in needed + (['volume'] if 'volume' in f else []):
            f[c] = pd.to_numeric(f[c], errors='coerce')
        f = f.replace([float('inf'), float('-inf')], float('nan')).dropna(subset=needed)
        if len(f) < 30 or (f[needed] <= 0).any().any():
            return _unavailable('داده OHLC کافی یا معتبر نیست')
        c, h, l = f.close.astype(float), f.high.astype(float), f.low.astype(float)
        ema20 = c.ewm(span=20, adjust=False).mean()
        tr = pd.concat([h-l, (h-c.shift()).abs(), (l-c.shift()).abs()], axis=1).max(axis=1)
        atr = float(tr.rolling(14).mean().iloc[-1])
        price, basis = float(c.iloc[-1]), float(ema20.iloc[-1])
        if not math.isfinite(atr) or atr <= 0 or price <= 0:
            return _unavailable('ATR معتبر محاسبه نشد')
        signed_extension = (price-basis)/atr * (1 if side == 'LONG' else -1)
        late = signed_extension >= 2.0
        near_ema = abs(signed_extension) <= 0.55
        prior_high, prior_low = float(h.iloc[-21:-1].max()), float(l.iloc[-21:-1].min())
        breakout = price > prior_high if side == 'LONG' else price < prior_low
        volume_ok = None
        if 'volume' in f:
            v = f.volume.dropna()
            if len(v) >= 21 and float(v.iloc[-21:-1].mean()) > 0:
                volume_ok = float(v.iloc[-1]) >= 1.5 * float(v.iloc[-21:-1].mean())
        if late:
            setup, mult, reason = 'LATE_ENTRY', 0.90, 'قیمت بیش از ۲ ATR از EMA20 در جهت معامله فاصله گرفته است'
        elif breakout and volume_ok is True:
            setup, mult, reason = 'VOLUME_CONFIRMED_BREAKOUT', 1.02, 'شکست محدوده ۲۰ کندل با حجم حداقل ۱٫۵ برابر میانگین'
        elif breakout and volume_ok is False:
            setup, mult, reason = 'WEAK_BREAKOUT', 0.94, 'شکست بدون تأیید حجم'
        elif near_ema:
            setup, mult, reason = 'PULLBACK_ZONE', 1.01, 'قیمت نزدیک EMA20؛ ناحیه احتمالی پولبک، نه تأیید برگشت'
        else:
            setup, mult, reason = 'NEUTRAL', 1.0, 'الگوی ورود مشخصی تأیید نشد'
        return {'available': True, 'setup': setup, 'ranking_multiplier': mult,
                'signed_extension_atr': round(signed_extension, 3), 'breakout': breakout,
                'volume_confirmation': volume_ok, 'atr': round(atr, 8), 'reason_fa': reason,
                'timeframe': '15m', 'read_only': True, 'real_orders_enabled': False,
                'warning': 'این خروجی صرفاً تعدیل رتبه‌بندی است؛ حدضرر/حدسود واقعی را جایگزین نمی‌کند.'}
    except Exception as exc:
        return _unavailable(f'تحلیل انجام نشد: {exc}')


def _unavailable(reason):
    return {'available': False, 'setup': 'UNAVAILABLE', 'ranking_multiplier': 1.0,
            'reason_fa': reason, 'timeframe': '15m', 'read_only': True,
            'real_orders_enabled': False}
