"""Causal BOS/CHOCH analysis using confirmed swing pivots and closed candles."""
from __future__ import annotations
import math
from typing import Any
import pandas as pd


def analyze_bos_choch(candles: Any, *, side: str, lookback: int = 180,
                      pivot_width: int = 3) -> dict:
    direction = str(side).upper()
    if direction not in ("LONG", "SHORT"):
        raise ValueError("side must be LONG or SHORT")
    if not isinstance(candles, pd.DataFrame):
        candles = pd.DataFrame(candles)
    cols = ("open", "high", "low", "close")
    if not set(cols).issubset(candles.columns):
        return {"state":"UNAVAILABLE", "blocking":False, "trend":"NEUTRAL", "events":[]}
    d = candles.tail(max(int(lookback), pivot_width * 2 + 8)).copy()
    for col in cols:
        d[col] = pd.to_numeric(d[col], errors="coerce")
    d = d.replace([float("inf"), float("-inf")], float("nan")).dropna(subset=list(cols)).reset_index(drop=True)
    if pivot_width < 1 or len(d) < pivot_width * 2 + 8:
        return {"state":"UNAVAILABLE", "blocking":False, "trend":"NEUTRAL", "events":[]}
    vals = d[list(cols)].to_numpy(dtype=float)
    if not all(math.isfinite(float(x)) and x > 0 for x in vals.flat):
        return {"state":"INVALID", "blocking":False, "trend":"NEUTRAL", "events":[]}
    if any(h < max(o,c) or l > min(o,c) or h < l for o,h,l,c in vals):
        return {"state":"INVALID", "blocking":False, "trend":"NEUTRAL", "events":[]}
    highs, lows = [], []
    # Only pivots whose full right-hand confirmation window has closed are eligible.
    for i in range(pivot_width, len(d)-pivot_width):
        w = vals[i-pivot_width:i+pivot_width+1]
        if vals[i,1] == max(w[:,1]) and sum(w[:,1] == vals[i,1]) == 1:
            highs.append((i, float(vals[i,1])))
        if vals[i,2] == min(w[:,2]) and sum(w[:,2] == vals[i,2]) == 1:
            lows.append((i, float(vals[i,2])))
    if len(highs) < 2 or len(lows) < 2:
        return {"state":"INSUFFICIENT_SWINGS", "blocking":False, "trend":"NEUTRAL", "events":[],
                "swing_high":highs[-1][1] if highs else None, "swing_low":lows[-1][1] if lows else None}
    hh = highs[-1][1] > highs[-2][1]
    hl = lows[-1][1] > lows[-2][1]
    lh = highs[-1][1] < highs[-2][1]
    ll = lows[-1][1] < lows[-2][1]
    trend = "BULLISH" if hh and hl else "BEARISH" if lh and ll else "NEUTRAL"
    prev_close, close = float(vals[-2,3]), float(vals[-1,3])
    last_high, last_low = highs[-1][1], lows[-1][1]
    events = []
    if prev_close <= last_high < close:
        events.append({"type":"BOS" if trend != "BEARISH" else "CHOCH", "direction":"BULLISH", "level":last_high})
    if prev_close >= last_low > close:
        events.append({"type":"BOS" if trend != "BULLISH" else "CHOCH", "direction":"BEARISH", "level":last_low})
    opposing = "BEARISH" if direction == "LONG" else "BULLISH"
    opposing_choch = any(e["type"] == "CHOCH" and e["direction"] == opposing for e in events)
    opposing_bos = any(e["type"] == "BOS" and e["direction"] == opposing for e in events)
    return {"state": events[-1]["type"] if events else "NO_BREAK", "trend":trend,
            "blocking":bool(opposing_choch), "opposing_choch":bool(opposing_choch),
            "opposing_bos":bool(opposing_bos), "events":events,
            "swing_high":last_high, "swing_low":last_low,
            "last_close":close, "previous_close":prev_close,
            "note":"Pivot-confirmation is causal; BOS/CHOCH uses the latest closed candle."}
