"""Read-only batch validation immediately before local paper execution."""
from __future__ import annotations
import math
import re

VERSION = "23.0.81"
KEY_RE = re.compile(r"^[A-Za-z0-9:_|.\\-]{8,180}$")
SYMBOL_RE = re.compile(r"^[A-Z0-9]{3,24}$")
DECISIONS = {"PAPER_BUY_CANDIDATE", "PAPER_SELL_CANDIDATE"}


def _finite(value):
    if isinstance(value, bool) or value is None:
        return False
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError, OverflowError):
        return False


def preflight_paper_candidates(candidates):
    """Return a deterministic validation report; never opens positions/orders."""
    if not isinstance(candidates, list):
        raise ValueError("candidates must be a list")
    if len(candidates) > 20:
        raise ValueError("حداکثر ۲۰ نامزد در هر درخواست مجاز است")
    seen_keys, seen_symbols = set(), set()
    results = []
    for index, raw in enumerate(candidates):
        reason = None
        if not isinstance(raw, dict):
            reason = "INVALID_CANDIDATE"
            symbol, key = None, None
        else:
            symbol = str(raw.get("symbol") or "").upper().replace("/", "").strip()
            decision = str(raw.get("decision") or "").upper().strip()
            key = str(raw.get("idempotency_key") or "").strip()
            blockers = raw.get("risk_blockers", [])
            if not SYMBOL_RE.fullmatch(symbol):
                reason = "INVALID_SYMBOL"
            elif decision not in DECISIONS:
                reason = "DECISION_NOT_EXECUTABLE"
            elif not all(_finite(raw.get(k)) for k in ("score", "coverage_pct", "conflict_ratio")):
                reason = "MISSING_OR_INVALID_DECISION_EVIDENCE"
            elif not (75 <= float(raw["score"]) <= 100 and 65 <= float(raw["coverage_pct"]) <= 100
                      and 0 <= float(raw["conflict_ratio"]) <= 0.2):
                reason = "DECISION_THRESHOLDS_NOT_MET"
            elif not isinstance(blockers, list) or blockers:
                reason = "RISK_BLOCKERS_PRESENT_OR_INVALID"
            elif not KEY_RE.fullmatch(key):
                reason = "VALID_IDEMPOTENCY_KEY_REQUIRED"
            elif key in seen_keys:
                reason = "DUPLICATE_IDEMPOTENCY_KEY_IN_BATCH"
            elif symbol in seen_symbols:
                reason = "DUPLICATE_SYMBOL_IN_BATCH"
        if reason is None:
            seen_keys.add(key)
            seen_symbols.add(symbol)
        results.append({"index": index, "symbol": symbol, "status": "READY" if reason is None else "BLOCKED",
                        "reason": None if reason is None else reason,
                        "creates_position": False, "creates_orders": False})
    ready = sum(x["status"] == "READY" for x in results)
    return {"version": VERSION, "status": "PREFLIGHT_PASSED" if ready == len(results) else "PREFLIGHT_BLOCKED",
            "count": len(results), "ready": ready, "blocked": len(results) - ready,
            "results": results, "paper_only": True, "capital_usdt": 1000.0,
            "read_only": True, "creates_positions": False, "creates_orders": False,
            "execution_authorized": False, "real_orders_enabled": False}
