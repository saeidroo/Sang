"""Append-only, hash-linked incident log for read-only BTC 4h SLO decisions."""
from __future__ import annotations
import hashlib, json, os, time
from pathlib import Path
from backend.btc_live_environment_validation import _canonical
from backend.btc_readonly_rolling_slo import verify_readonly_rolling_slo

_ZERO='0'*64


def verify_incident_log_bytes(raw):
    previous=_ZERO; active={}; count=0
    for line_no,line in enumerate(raw.splitlines(),1):
        try: event=json.loads(line.decode('utf-8'))
        except Exception as exc: raise ValueError(f'incident_log_json_invalid:{line_no}') from exc
        supplied=event.get('event_sha256'); payload=dict(event); payload.pop('event_sha256',None)
        actual=hashlib.sha256(_canonical(payload)).hexdigest()
        if supplied!=actual: raise ValueError(f'incident_log_hash_mismatch:{line_no}')
        if event.get('sequence')!=count+1 or event.get('previous_sha256')!=previous:
            raise ValueError(f'incident_log_chain_mismatch:{line_no}')
        if event.get('training_allowed') is not False or event.get('live_orders') is not False:
            raise ValueError(f'incident_log_safety_flags_invalid:{line_no}')
        kind=event.get('event_type')
        if kind=='OPEN':
            if event.get('incident_key') in active: raise ValueError(f'incident_log_duplicate_open:{line_no}')
            active[event['incident_key']]=event
        elif kind=='RECOVERY':
            key=event.get('incident_key'); target=active.get(key)
            if target is None or target.get('event_sha256')!=event.get('closes_event_sha256'):
                raise ValueError(f'incident_log_recovery_target_invalid:{line_no}')
            del active[key]
        elif kind=='SUPPRESSED':
            target=active.get(event.get('incident_key'))
            if target is None or target.get('event_sha256')!=event.get('suppresses_event_sha256'):
                raise ValueError(f'incident_log_suppression_target_invalid:{line_no}')
        else: raise ValueError(f'incident_log_event_type_invalid:{line_no}')
        previous=supplied; count+=1
    return {'valid':True,'event_count':count,'head_sha256':previous,
            'active_incidents':[{'incident_key':k,'event_sha256':v['event_sha256'],'severity':v['severity']} for k,v in active.items()]}


def verify_incident_log(path):
    p=Path(path)
    if not p.exists(): return {'valid':True,'event_count':0,'head_sha256':_ZERO,'active_incidents':[]}
    if p.is_symlink() or not p.is_file(): raise ValueError('incident_log_not_regular_file')
    return verify_incident_log_bytes(p.read_bytes())


def _acquire_lock(lock_path, timeout):
    deadline=time.monotonic()+timeout
    while True:
        try: return os.open(str(lock_path),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        except FileExistsError:
            if time.monotonic()>=deadline: raise TimeoutError('incident_log_lock_timeout')
            time.sleep(0.05)


def _append(path, event, previous, sequence):
    event.update({'sequence':sequence,'previous_sha256':previous})
    event['event_sha256']=hashlib.sha256(_canonical(event)).hexdigest()
    raw=_canonical(event)+b'\n'
    fd=os.open(str(path),os.O_CREAT|os.O_APPEND|os.O_WRONLY,0o600)
    try: os.write(fd,raw); os.fsync(fd)
    finally: os.close(fd)
    return event


def record_readonly_slo_incidents(slo_result, *, log_path, lock_timeout=5.0, now_utc=None):
    verify_readonly_rolling_slo(slo_result)
    path=Path(log_path).expanduser(); path.parent.mkdir(parents=True,exist_ok=True)
    if path.is_symlink(): raise ValueError('incident_log_symlink_rejected')
    lock=path.with_name(path.name+'.lock'); lock_fd=_acquire_lock(lock,lock_timeout)
    try:
        os.close(lock_fd)
        state=verify_incident_log(path)
        previous=state['head_sha256']; sequence=state['event_count']+1
        active={x['incident_key']:x for x in state['active_incidents']}
        decision=slo_result['decision']; now=(now_utc or __import__('datetime').datetime.now(__import__('datetime').timezone.utc)).isoformat()
        appended=[]; suppressed=False
        if decision in ('STOP','REVIEW_REQUIRED'):
            reasons=sorted(slo_result.get('threshold_breaches') or [])
            if decision=='REVIEW_REQUIRED' and not reasons:
                reasons=['insufficient_or_incomplete_window']
            key=hashlib.sha256(_canonical({'decision':decision,'reasons':reasons})).hexdigest()
            if key in active:
                target=active[key]
                event={'event_type':'SUPPRESSED','severity':'INFO','incident_key':key,
                    'incident_fingerprint':key,'slo_sha256':slo_result['slo_sha256'],
                    'suppresses_event_sha256':target['event_sha256'],'created_at_utc':now,
                    'training_allowed':False,'live_orders':False}
                e=_append(path,event,previous,sequence); appended.append(e); previous=e['event_sha256']; sequence+=1; suppressed=True
            else:
                event={'event_type':'OPEN','severity':'CRITICAL' if decision=='STOP' else 'WARNING',
                    'incident_key':key,'incident_fingerprint':key,'reasons':reasons,
                    'slo_sha256':slo_result['slo_sha256'],'created_at_utc':now,
                    'training_allowed':False,'live_orders':False}
                e=_append(path,event,previous,sequence); appended.append(e)
        elif decision=='CONTINUE_READONLY':
            for key,target in active.items():
                event={'event_type':'RECOVERY','severity':'INFO','incident_key':key,
                    'closes_event_sha256':target['event_sha256'],'slo_sha256':slo_result['slo_sha256'],
                    'created_at_utc':now,'training_allowed':False,'live_orders':False}
                e=_append(path,event,previous,sequence); appended.append(e); previous=e['event_sha256']; sequence+=1
        final=verify_incident_log(path)
        return {'appended_count':len(appended),'suppressed':suppressed,'events':appended,
            'log_state':final,'training_allowed':False,'live_orders':False}
    finally:
        try: lock.unlink()
        except FileNotFoundError: pass
