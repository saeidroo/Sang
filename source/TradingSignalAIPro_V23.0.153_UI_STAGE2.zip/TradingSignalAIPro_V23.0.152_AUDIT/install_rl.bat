@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo First run install.bat to create the project virtual environment.
  pause
  exit /b 1
)
echo Installing FinRL 0.3.8 and Stable-Baselines3 DRL dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements-rl.txt
if errorlevel 1 (
  echo Installation failed. Check internet/VPN/proxy and retry.
  pause
  exit /b 1
)
echo DRL dependencies installed successfully.
pause
