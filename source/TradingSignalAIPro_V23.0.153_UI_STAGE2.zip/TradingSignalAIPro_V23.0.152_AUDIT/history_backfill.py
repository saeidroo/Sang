"""Command-line historical candle downloader. Example:
python history_backfill.py --symbols BTCUSDT,ETHUSDT --timeframes 15m,1h,4h,1d
"""
import argparse
from backend.historical import backfill_symbol, expand_market_symbols

def main():
    p=argparse.ArgumentParser(description='Build local OHLCV history for all Binance USDT spot markets and gold/silver proxies')
    p.add_argument('--symbols',default='ALL_USDT,GOLD,SILVER')
    p.add_argument('--timeframes',default='1h,4h,1d')
    p.add_argument('--start',default='2017-01-01T00:00:00+00:00')
    a=p.parse_args()
    symbols=expand_market_symbols([x.strip().upper() for x in a.symbols.split(',') if x.strip()])
    print(f'Discovered {len(symbols)} markets', flush=True)
    for symbol in symbols:
        for tf in [x.strip() for x in a.timeframes.split(',') if x.strip()]:
            print(f'\n=== {symbol} {tf} ===',flush=True)
            def progress(s,t,n,total,pages,cursor):
                print(f'page={pages} fetched={n} newly_saved={total:,}',flush=True)
            result=backfill_symbol(symbol,tf,a.start,progress)
            print(result,flush=True)
if __name__=='__main__': main()
