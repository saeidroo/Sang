@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================================
echo   Trading Signal AI Pro - Windows Installer V23.0.152
echo ============================================================
echo Supported runtime: Python 3.10-3.12, 64-bit. Python 3.11 recommended.
echo.
set "PY="
where py >nul 2>&1
if not errorlevel 1 (
  for %%V in (3.11 3.12 3.10) do (
    if not defined PY (
      py -%%V --version >nul 2>&1
      if not errorlevel 1 set "PY=py -%%V"
    )
  )
)
if not defined PY (
  where python >nul 2>&1
  if not errorlevel 1 set "PY=python"
)
if not defined PY goto :no_python
%PY% windows_preflight.py
if errorlevel 1 goto :bad_runtime
if not exist ".venv\Scripts\python.exe" (
  echo [1/5] Creating isolated virtual environment...
  %PY% -m venv .venv
  if errorlevel 1 goto :failed
) else (
  echo [1/5] Existing virtual environment found.
)
set "VPY=%CD%\.venv\Scripts\python.exe"
"%VPY%" windows_preflight.py
if errorlevel 1 goto :bad_runtime
 echo.
echo [2/5] Upgrading pip...
"%VPY%" -m pip install --upgrade pip --retries 2 --timeout 30
if errorlevel 1 goto :failed
 echo.
echo [3/5] Installing core dependencies.
echo If pip cannot connect, enter your local HTTP proxy port.
set /p PORT="Local HTTP proxy port (blank = direct): "
if not "%PORT%"=="" (
  "%VPY%" -m pip install --proxy "http://127.0.0.1:%PORT%" --retries 2 --timeout 45 -r requirements.txt
) else (
  "%VPY%" -m pip install --retries 2 --timeout 45 -r requirements.txt
)
if errorlevel 1 goto :failed
 echo.
echo [4/5] Checking dependency consistency...
"%VPY%" -m pip check
if errorlevel 1 goto :failed
"%VPY%" dependency_audit.py
if errorlevel 1 goto :failed
"%VPY%" smoke_check.py
if errorlevel 1 goto :failed
 echo.
set /p DESKTOP="Install optional desktop window support? (Y/N, default N): "
if /I "%DESKTOP%"=="Y" (
  if not "%PORT%"=="" (
    "%VPY%" -m pip install --proxy "http://127.0.0.1:%PORT%" --retries 2 --timeout 45 -r requirements-desktop.txt
  ) else (
    "%VPY%" -m pip install --retries 2 --timeout 45 -r requirements-desktop.txt
  )
  if errorlevel 1 goto :failed
  "%VPY%" -m pip check
  if errorlevel 1 goto :failed
)
echo.
echo Installation completed. Start with run.bat.
pause
exit /b 0
:no_python
echo [ERROR] Python was not found. Install Python 3.11 64-bit and enable PATH.
pause
exit /b 1
:bad_runtime
echo [ERROR] Unsupported Python runtime. Install Python 3.10, 3.11 or 3.12 64-bit.
pause
exit /b 2
:failed
echo [ERROR] Installation or smoke test failed. See the error above.
echo No application data was deleted. Fix the network/proxy or dependency issue and retry.
pause
exit /b 1
