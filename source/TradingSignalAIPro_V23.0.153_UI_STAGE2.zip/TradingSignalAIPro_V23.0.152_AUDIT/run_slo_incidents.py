"""Append a verified rolling-SLO incident event to the local audit chain."""
import argparse,json
from pathlib import Path
from backend.btc_readonly_rolling_slo import verify_readonly_rolling_slo
from backend.btc_readonly_incidents import record_readonly_slo_incidents

def main():
 p=argparse.ArgumentParser(description='Append-only incident audit for BTC 4h read-only SLO')
 p.add_argument('--slo',required=True); p.add_argument('--log',default='live-validation/incidents.jsonl')
 a=p.parse_args(); slo=json.loads(Path(a.slo).read_text(encoding='utf-8')); verify_readonly_rolling_slo(slo)
 print(json.dumps(record_readonly_slo_incidents(slo,log_path=a.log),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
