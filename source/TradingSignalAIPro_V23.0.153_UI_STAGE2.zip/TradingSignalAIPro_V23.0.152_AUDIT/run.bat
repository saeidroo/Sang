@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Virtual environment not found. Run install.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" windows_preflight.py
if errorlevel 1 (
  echo [ERROR] The virtual environment uses an unsupported Python runtime.
  pause
  exit /b 2
)
".venv\Scripts\python.exe" -u main.py --browser
set "APP_EXIT=%ERRORLEVEL%"
if not "%APP_EXIT%"=="0" echo [ERROR] Application exited with code %APP_EXIT%.
pause
exit /b %APP_EXIT%
