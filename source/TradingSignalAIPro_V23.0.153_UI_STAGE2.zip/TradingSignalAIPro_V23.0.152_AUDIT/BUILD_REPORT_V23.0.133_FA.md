# گزارش ساخت V23.0.133

- مبنا: V23.0.132_DIRECTIONAL_FAILURE_ANALYSIS
- قابلیت: گزارش الگوهای مشترک مرتبط با شکست سیگنال‌ها
- فایل‌های تغییرکرده: `backend/market_brain.py`، `backend/scout.py`
- تست جدید: `tests/test_v23_0_133_failure_patterns.py`
- تغییر خودکار وزن یا آستانه: انجام نشد
- اتصال داده زنده یا دیتابیس محلی کاربر: انجام نشده است
- حالت اجرا: PAPER ONLY
