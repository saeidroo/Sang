# راهنمای اجرای آزمون‌های پروژه

## محیط موردنیاز

- Python نسخهٔ 3.10، 3.11 یا 3.12 با معماری 64-bit
- وابستگی‌های اصلی فایل `requirements.txt` از جمله Flask

## نصب در محیط مجازی

### Windows PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip check
python dependency_audit.py
python smoke_check.py
```

### Linux / macOS

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip check
python dependency_audit.py
python smoke_check.py
```

## اجرای تست‌ها

از پوشهٔ اصلی پروژه اجرا کنید:

```bash
pytest -q
```

یا:

```bash
python -m pytest -q
```

`pytest.ini` مسیر ریشهٔ پروژه را برای هر دو روش تنظیم می‌کند.

## نکته

اگر Flask یا وابستگی اصلی دیگری نصب نباشد، تست‌های API هنگام collection یا import شکست می‌خورند. این خطا را نباید با حذف تست‌ها یا ساخت mock برای Flask پنهان کرد؛ ابتدا باید وابستگی واقعی نصب و سپس تست API اجرا شود.
