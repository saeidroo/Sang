"""Review imported live validation reports; never enables training or orders."""
import argparse, json
from backend.btc_live_validation_review import review_live_validation_reports, save_live_validation_review


def main():
    p = argparse.ArgumentParser(description='Review repeated BTCUSDT 4h read-only live validation evidence')
    p.add_argument('--reports', nargs='+', required=True)
    p.add_argument('--min-pass-runs', type=int, default=3)
    p.add_argument('--max-age-hours', type=float, default=24)
    p.add_argument('--operator-approved', action='store_true', help='Record local manual approval; not cryptographic identity proof')
    p.add_argument('--output', default='live-validation/operator-review.json')
    a = p.parse_args()
    result = review_live_validation_reports(a.reports, operator_approved=a.operator_approved,
        min_pass_runs=a.min_pass_runs, max_age_hours=a.max_age_hours)
    try:
        saved = save_live_validation_review(result, output_path=a.output)
    except FileExistsError:
        p.error('output already exists; choose a new --output path')
    print(json.dumps({'review': result, 'saved': saved}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result['decision'] == 'ACCEPT_READONLY' else 2)

if __name__ == '__main__': main()
