"""Export incident evidence and optionally anchor its digest at an external Witness."""
import argparse,json,os
from backend.btc_readonly_incident_export import build_incident_export_bundle,verify_incident_export_bundle,submit_incident_bundle_to_witness

def main():
 p=argparse.ArgumentParser(description='Export read-only BTC incident log; optional external Witness anchor')
 p.add_argument('--log',default='live-validation/incidents.jsonl'); p.add_argument('--output',required=True)
 p.add_argument('--witness-endpoint',default=os.getenv('TS_WITNESS_REMOTE_ENDPOINT'))
 p.add_argument('--witness-token-env',default='TS_WITNESS_API_TOKEN')
 p.add_argument('--witness-public-key',default=os.getenv('TS_WITNESS_PUBLIC_KEY'))
 a=p.parse_args(); built=build_incident_export_bundle(log_path=a.log,output_path=a.output)
 result={'export':built,'verification':verify_incident_export_bundle(a.output)}
 if a.witness_endpoint:
  token=os.getenv(a.witness_token_env,'')
  if not (token and a.witness_public_key): p.error('Witness anchoring requires token env var and pinned --witness-public-key')
  result['witness']=submit_incident_bundle_to_witness(a.output,endpoint=a.witness_endpoint,
    bearer_token=token,pinned_public_key_path=a.witness_public_key)
 print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
