#!/usr/bin/env bash
# Quick launcher for Linux/macOS
set -e
cd "$(dirname "$0")"

PY=""
if [ -x "venv/bin/python" ]; then
    PY="venv/bin/python"
elif [ -x ".venv/bin/python" ]; then
    PY=".venv/bin/python"
else
    # Match install.sh: do not accidentally launch an unsupported `python`.
    for c in python3.12 python3.11 python3.10 python3 python; do
        if command -v "$c" >/dev/null 2>&1 && \
           "$c" -c 'import struct,sys; raise SystemExit(0 if sys.version_info[:2] in ((3,10),(3,11),(3,12)) and struct.calcsize("P") == 8 else 1)' >/dev/null 2>&1; then
            PY="$c"
            break
        fi
    done
fi

if [ -z "$PY" ]; then
    echo "اجرای برنامه به Python 3.10، 3.11 یا 3.12 با معماری ۶۴بیتی نیاز دارد." >&2
    exit 2
fi

if ! "$PY" windows_preflight.py; then
    echo "محیط Python با نسخه پشتیبانی‌شده پروژه سازگار نیست." >&2
    exit 2
fi
exec "$PY" main.py "$@"
