"""Windows runtime preflight for TradingSignalAIPro installers and launchers."""
from __future__ import annotations
import argparse
import struct
import sys
from pathlib import Path

SUPPORTED = {(3, 10), (3, 11), (3, 12)}


def inspect_runtime() -> dict:
    version = sys.version_info[:2]
    bits = struct.calcsize("P") * 8
    return {
        "python": sys.executable,
        "version": f"{version[0]}.{version[1]}.{sys.version_info[2]}",
        "supported_version": version in SUPPORTED,
        "bits": bits,
        "supported_architecture": bits == 64,
        "project_root": str(Path(__file__).resolve().parent),
    }


def validate_runtime() -> tuple[bool, list[str]]:
    info = inspect_runtime()
    errors = []
    if not info["supported_version"]:
        errors.append("Python 3.10, 3.11 or 3.12 is required; detected " + info["version"])
    if not info["supported_architecture"]:
        errors.append("64-bit Python is required; detected " + str(info["bits"]) + "-bit")
    return not errors, errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    info = inspect_runtime()
    ok, errors = validate_runtime()
    if args.json:
        import json
        print(json.dumps({**info, "valid": ok, "errors": errors}, ensure_ascii=False))
    else:
        print(f"Python: {info['version']} ({info['bits']}-bit)")
        print(f"Executable: {info['python']}")
        for error in errors:
            print("[ERROR] " + error)
        if ok:
            print("[OK] Windows runtime is supported.")
    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
