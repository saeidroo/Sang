@echo off
REM ============================================================
REM  clear_proxy.bat - Remove proxy settings from pip + env
REM  Run this if your previous proxy is causing install errors
REM ============================================================

echo.
echo ============================================================
echo  Cleaning up old proxy settings ...
echo ============================================================
echo.

REM ---- 1. pip config ----
echo [1/3] Unsetting pip config proxy ...
pip config unset global.proxy 2>nul
pip config unset global.index-url 2>nul
pip config unset global.trusted-host 2>nul
pip config unset global.timeout 2>nul
echo   Done.
echo.

REM ---- 2. Show pip config for verification ----
echo [2/3] Current pip config:
pip config list 2>nul
echo   (if empty above, pip has no proxy configured)
echo.

REM ---- 3. Clear user environment variables ----
echo [3/3] Clearing user proxy env vars ...
setx HTTP_PROXY "" 2>nul
setx HTTPS_PROXY "" 2>nul
setx ALL_PROXY "" 2>nul
setx http_proxy "" 2>nul
setx https_proxy "" 2>nul
echo   Done.
echo.

echo ============================================================
echo  Cleanup complete!
echo ============================================================
echo.
echo IMPORTANT:
echo   - Close ALL cmd windows and reopen before running install.bat
echo   - Then run install.bat and choose option [1] or [2]
echo.
pause
