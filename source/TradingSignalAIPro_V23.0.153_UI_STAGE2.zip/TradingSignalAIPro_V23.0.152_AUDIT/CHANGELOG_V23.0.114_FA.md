# تغییرات V23.0.114 — پایداری نمودار

- وابستگی نمودار به CDN خارجی Lightweight Charts حذف شد؛ رندرر داخلی `frontend/chart-fallback.js` اکنون renderer اصلی است تا قطع CDN باعث خالی ماندن نمودار نشود.
- زنجیره خودکار دریافت کندل رمزارزها دیگر TradingView را فراخوانی نمی‌کند و از منابع مستقل صرافی/داده استفاده می‌کند؛ زنجیره شامل Binance، Bybit، OKX، Gate.io، MEXC، KuCoin، Coinbase، Bitget، BingX، HTX، Bitfinex، Kraken و سایر منابع پیکربندی‌شده است.
- زنجیره خودکار طلا/نفت به Yahoo Finance، سپس Stooq و در نهایت آرشیو محلی محدود شد؛ TradingView حذف شد.
- گزینه TradingView از انتخاب منبع داده حذف شد و نسخه به 23.0.114 ارتقا یافت.
- منطق معاملات و ارسال سفارش تغییر نکرد؛ معاملات واقعی همچنان غیرفعال است.

## آزمون‌ها

- `python -m compileall -q backend`: موفق
- `node --check frontend/app.js`: موفق
- `node --check frontend/chart-fallback.js`: موفق
- آزمون‌های متمرکز منبع داده: 25 موفق
- دریافت زنده از شبکه و رندر در مرورگر واقعی در این محیط انجام نشده است.
