"""Compute rolling read-only reliability SLO from imported report JSON files."""
import argparse,json
from pathlib import Path
from backend.btc_live_validation_review import load_live_validation_report
from backend.btc_readonly_rolling_slo import build_readonly_rolling_slo,verify_readonly_rolling_slo
from backend.btc_live_environment_validation import _canonical
import hashlib,os

def main():
 p=argparse.ArgumentParser(description='Rolling BTCUSDT 4h read-only SLO; no training or orders')
 p.add_argument('--reports',nargs='+',required=True); p.add_argument('--min-reports',type=int,default=10)
 p.add_argument('--operator-approved',action='store_true'); p.add_argument('--output',default='live-validation/rolling-slo.json')
 a=p.parse_args(); reports=[load_live_validation_report(x) for x in a.reports]
 result=build_readonly_rolling_slo(reports,min_reports=a.min_reports,operator_approved=a.operator_approved)
 verify_readonly_rolling_slo(result); path=Path(a.output); path.parent.mkdir(parents=True,exist_ok=True)
 raw=_canonical(result)+b'\n'; fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f: f.write(raw); f.flush(); os.fsync(f.fileno())
 print(json.dumps({'result':result,'saved_sha256':hashlib.sha256(raw).hexdigest()},ensure_ascii=False,indent=2))
 raise SystemExit(0 if result['decision']=='CONTINUE_READONLY' else 2)
if __name__=='__main__': main()
