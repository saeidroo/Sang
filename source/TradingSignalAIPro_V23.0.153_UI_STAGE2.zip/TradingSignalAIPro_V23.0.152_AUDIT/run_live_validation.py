"""Run BTCUSDT 4h public live-environment validation (read-only)."""
import argparse, json
from backend.btc_live_environment_validation import validate_live_environment, save_live_environment_report


def main():
    p = argparse.ArgumentParser(description='BTCUSDT 4h live environment validation; public GET only')
    p.add_argument('--limit', type=int, default=120)
    p.add_argument('--timeout', type=float, default=12.0)
    p.add_argument('--max-age-hours', type=float, default=8.0)
    p.add_argument('--output', default='live-validation/live_environment_report.json')
    a = p.parse_args()
    report = validate_live_environment(limit=a.limit, timeout=a.timeout, max_age_hours=a.max_age_hours)
    try:
        saved = save_live_environment_report(report, output_path=a.output)
    except FileExistsError:
        p.error('output already exists; choose a new --output path (reports are immutable)')
    print(json.dumps({'report': report, 'saved': saved}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report['status'] == 'PASS' else 2)

if __name__ == '__main__': main()
