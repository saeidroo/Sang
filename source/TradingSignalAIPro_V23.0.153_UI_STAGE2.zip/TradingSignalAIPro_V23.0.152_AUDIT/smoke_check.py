"""Offline installation and import smoke checks."""
import importlib
import sys

REQUIRED = ["flask", "requests", "numpy", "pandas", "sklearn", "joblib", "cryptography"]
OPTIONAL = ["xgboost", "lightgbm", "webview", "gymnasium", "stable_baselines3", "finrl"]

def main():
    print(f"Python: {sys.version.split()[0]} ({'64-bit' if sys.maxsize > 2**32 else '32-bit'})")
    if not ((3, 10) <= sys.version_info[:2] < (3, 13)):
        print("[WARN] Tested support target is Python 3.10-3.12; use Python 3.11 64-bit for the recommended install.")
    failed = []
    for name in REQUIRED:
        try:
            mod = importlib.import_module(name)
            print(f"[OK] {name} {getattr(mod, '__version__', '')}")
        except Exception as exc:
            failed.append(name)
            print(f"[FAIL] {name}: {exc}")
    for name in OPTIONAL:
        try:
            mod = importlib.import_module(name)
            print(f"[OK] optional {name} {getattr(mod, '__version__', '')}")
        except Exception as exc:
            print(f"[WARN] optional {name}: {exc}")
    if failed:
        print("Missing required packages: " + ", ".join(failed))
        return 1
    try:
        from dependency_audit import audit
        dep_report = audit()
        if dep_report["missing_core"]:
            raise RuntimeError("missing core dependencies: " + ", ".join(dep_report["missing_core"]))
        print("[OK] core dependency audit")
        from backend.brain import BASE_WEIGHTS
        if abs(sum(BASE_WEIGHTS.values()) - 1.0) > 1e-8:
            raise RuntimeError("central brain weights do not sum to 1")
        print("[OK] V17 central brain module")
        from backend.api import app
        client = app.test_client()
        response = client.get('/api/health')
        if response.status_code != 200 or response.get_json().get('status') != 'ok':
            raise RuntimeError(f"health endpoint returned {response.status_code}")
        print("[OK] Flask API health endpoint")
        response = client.get('/api/symbols')
        if response.status_code != 200:
            raise RuntimeError("symbols endpoint failed")
        print("[OK] symbols endpoint")
        response = client.get('/api/brain/reliability')
        if response.status_code != 200:
            raise RuntimeError("central brain reliability endpoint failed")
        print("[OK] central brain reliability endpoint")
    except Exception as exc:
        print(f"[FAIL] application smoke test: {exc}")
        return 1
    print("All required installation checks passed.")
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
