#!/usr/bin/env python3
"""Operational CLI for BTC 4h replay trust, anchors and recovery."""
from __future__ import annotations
import argparse, json, os, sys
from getpass import getpass
from pathlib import Path


def _password():
    value=os.getenv('TS_AI_TRUST_BACKUP_PASSWORD')
    if value: return value
    return getpass('Trust-store backup password (12+ characters): ')


def main(argv=None):
    parser=argparse.ArgumentParser(description='BTC 4h replay trust operations (never prints private keys or tokens)')
    sub=parser.add_subparsers(dest='command',required=True)
    h=sub.add_parser('health'); h.add_argument('--trust-dir')
    d=sub.add_parser('deployment-check'); d.add_argument('--trust-dir'); d.add_argument('--registry-dir'); d.add_argument('--anchor-path'); d.add_argument('--high-water-path')
    c=sub.add_parser('checkpoint'); c.add_argument('--registry-dir',required=True); c.add_argument('--anchor-path',required=True)
    a=sub.add_parser('audit-chain'); a.add_argument('--registry-dir',required=True); a.add_argument('--anchor-path',required=True)
    s=sub.add_parser('sign'); s.add_argument('--checkpoint-file',required=True); s.add_argument('--output',required=True)
    v=sub.add_parser('verify-signed'); v.add_argument('--anchor-file',required=True); v.add_argument('--public-key')
    p=sub.add_parser('publish'); p.add_argument('--anchor-file',required=True); p.add_argument('--receipt-output')
    b=sub.add_parser('backup'); b.add_argument('--output',required=True); b.add_argument('--trust-dir')
    r=sub.add_parser('restore'); r.add_argument('--backup',required=True); r.add_argument('--destination',required=True)
    rot=sub.add_parser('rotate-ceremony'); rot.add_argument('--output',required=True)
    rv=sub.add_parser('verify-rotation'); rv.add_argument('--ceremony',required=True); rv.add_argument('--trusted-old-key',required=True)
    imp=sub.add_parser('import-rotation'); imp.add_argument('--ceremony',required=True); imp.add_argument('--trusted-old-key',required=True)
    hl=sub.add_parser('audit-health-log'); hl.add_argument('--path',required=True)
    ev=sub.add_parser('evidence'); ev.add_argument('--project-root',required=True); ev.add_argument('--test-summary',required=True); ev.add_argument('--gate-report',required=True); ev.add_argument('--version',required=True); ev.add_argument('--output',required=True)
    ve=sub.add_parser('verify-evidence'); ve.add_argument('--path',required=True)
    live=sub.add_parser('fetch-live-readonly'); live.add_argument('--limit',type=int,default=200); live.add_argument('--max-age-hours',type=float,default=8); live.add_argument('--output',required=True)
    ingest=sub.add_parser('ingest-live-report'); ingest.add_argument('--report',required=True); ingest.add_argument('--store-dir',required=True)
    drift=sub.add_parser('live-drift-check'); drift.add_argument('--live-report'); drift.add_argument('--reconciliation-report'); drift.add_argument('--alerts-path',required=True)
    pilot=sub.add_parser('readonly-pilot-gate'); pilot.add_argument('--live-report',required=True); pilot.add_argument('--ingestion-report',required=True); pilot.add_argument('--drift-alert',required=True); pilot.add_argument('--evidence-log',required=True); pilot.add_argument('--operator-approved',action='store_true')
    obs=sub.add_parser('live-source-observability'); obs.add_argument('--live-reports'); obs.add_argument('--reconciliation-reports'); obs.add_argument('--drift-alerts'); obs.add_argument('--output',required=True); obs.add_argument('--stale-threshold-hours',type=float,default=8); obs.add_argument('--max-revision-rate',type=float,default=0.0)
    cross=sub.add_parser('fetch-cross-source-readonly'); cross.add_argument('--limit',type=int,default=200); cross.add_argument('--max-age-hours',type=float,default=8); cross.add_argument('--output',required=True)
    fail=sub.add_parser('source-failover-drill'); fail.add_argument('--scenarios',required=True); fail.add_argument('--evidence-log',required=True); fail.add_argument('--operator-approved',action='store_true')
    exitp=sub.add_parser('pilot-exit-review'); exitp.add_argument('--observability-report',required=True); exitp.add_argument('--failover-drill',required=True); exitp.add_argument('--pilot-gate',required=True); exitp.add_argument('--cross-source-reports',required=True); exitp.add_argument('--handoff-log',required=True); exitp.add_argument('--decision',choices=['CONTINUE_READONLY','STOP'])
    bundle=sub.add_parser('pilot-review-bundle'); bundle.add_argument('--artifact',action='append',required=True); bundle.add_argument('--output',required=True); bundle.add_argument('--version',required=True)
    vb=sub.add_parser('verify-pilot-review-bundle'); vb.add_argument('--path',required=True)
    sec=sub.add_parser('readonly-security-review'); sec.add_argument('--project-root',required=True); sec.add_argument('--decision',choices=['ACCEPT_READONLY','REJECT']); sec.add_argument('--acceptance-output')
    args=parser.parse_args(argv)
    try:
        if args.command=='health':
            from backend.btc_replay_trust_monitor import evaluate_replay_trust_policy
            result=evaluate_replay_trust_policy(trust_dir=args.trust_dir)
        elif args.command=='deployment-check':
            from backend.btc_replay_trust_backup import audit_replay_trust_store
            from backend.external_anchor import config_status
            from backend.btc_replay_trust_monitor import evaluate_replay_trust_policy
            result={'trust_store':audit_replay_trust_store(trust_dir=args.trust_dir),
                    'rotation_policy':evaluate_replay_trust_policy(trust_dir=args.trust_dir),
                    'witness':config_status(),
                    'external_anchor_path_configured':bool(args.anchor_path),
                    'high_water_path_configured':bool(args.high_water_path),
                    'registry_dir_configured':bool(args.registry_dir)}
            result['ready_for_external_witness']=bool(result['trust_store']['healthy'] and config_status()['configured'] and args.anchor_path and args.high_water_path and args.registry_dir)
        elif args.command=='checkpoint':
            from backend.btc_training_registry import checkpoint_replay_registry
            result=checkpoint_replay_registry(registry_dir=args.registry_dir,anchor_path=args.anchor_path)
        elif args.command=='audit-chain':
            from backend.btc_training_registry import audit_replay_registry_anchor
            result=audit_replay_registry_anchor(registry_dir=args.registry_dir,anchor_path=args.anchor_path)
        elif args.command=='sign':
            from backend.btc_replay_anchor import sign_replay_head_anchor
            result=sign_replay_head_anchor(json.loads(Path(args.checkpoint_file).read_text(encoding='utf-8')),output_path=args.output)
            result={'signed':True,'key_id':result['key_id'],'signing_sequence':result['signing_sequence'],'output':args.output}
        elif args.command=='verify-signed':
            from backend.btc_replay_anchor import verify_signed_replay_head_anchor
            result=verify_signed_replay_head_anchor(json.loads(Path(args.anchor_file).read_text(encoding='utf-8')),public_key_path=args.public_key)
        elif args.command=='publish':
            from backend.btc_replay_anchor import publish_signed_replay_head_anchor
            result=publish_signed_replay_head_anchor(json.loads(Path(args.anchor_file).read_text(encoding='utf-8')),receipt_path=args.receipt_output)
        elif args.command=='backup':
            from backend.btc_replay_trust_backup import export_replay_trust_store_backup
            result=export_replay_trust_store_backup(args.output,password=_password())
        elif args.command=='restore':
            from backend.btc_replay_trust_backup import restore_replay_trust_store_backup
            result=restore_replay_trust_store_backup(args.backup,args.destination,password=_password())
        elif args.command=='rotate-ceremony':
            from backend.btc_replay_anchor import create_replay_key_rotation_ceremony
            item=create_replay_key_rotation_ceremony(output_path=args.output)
            result={k:item[k] for k in ('old_key_id','new_key_id','new_fingerprint_sha256','path')}
        elif args.command=='verify-rotation':
            from backend.btc_replay_anchor import verify_replay_key_rotation_ceremony
            result=verify_replay_key_rotation_ceremony(json.loads(Path(args.ceremony).read_text(encoding='utf-8')),trusted_old_public_key_path=args.trusted_old_key)
        elif args.command=='import-rotation':
            from backend.btc_replay_anchor import import_rotated_replay_trust
            result=import_rotated_replay_trust(json.loads(Path(args.ceremony).read_text(encoding='utf-8')),trusted_old_public_key_path=args.trusted_old_key)
        elif args.command=='audit-health-log':
            from backend.btc_replay_trust_monitor import audit_trust_health_reports
            result=audit_trust_health_reports(args.path)
        elif args.command=='evidence':
            from backend.replay_release_evidence import build_replay_release_evidence_pack
            result=build_replay_release_evidence_pack(project_root=args.project_root,output_path=args.output,
                test_summary=json.loads(Path(args.test_summary).read_text(encoding='utf-8')),
                gate_report=json.loads(Path(args.gate_report).read_text(encoding='utf-8')),release_version=args.version)
        elif args.command=='verify-evidence':
            from backend.replay_release_evidence import verify_replay_release_evidence_pack
            result=verify_replay_release_evidence_pack(args.path)
        elif args.command=='fetch-live-readonly':
            from backend.btc_live_readonly import fetch_binance_btc_4h_readonly, save_readonly_live_report
            report=fetch_binance_btc_4h_readonly(limit=args.limit,max_age_hours=args.max_age_hours)
            result=save_readonly_live_report(report,output_path=args.output)
        elif args.command=='ingest-live-report':
            from backend.btc_live_snapshot import ingest_readonly_live_snapshot
            result=ingest_readonly_live_snapshot(json.loads(Path(args.report).read_text(encoding='utf-8')),store_root=args.store_dir)
        elif args.command=='live-drift-check':
            from backend.btc_live_drift_monitor import evaluate_live_drift, append_live_drift_alert
            live_report=json.loads(Path(args.live_report).read_text(encoding='utf-8')) if args.live_report else None
            reconciliation=json.loads(Path(args.reconciliation_report).read_text(encoding='utf-8')) if args.reconciliation_report else None
            alert=evaluate_live_drift(live_report=live_report,reconciliation_report=reconciliation)
            result={'alert':alert,'persistence':append_live_drift_alert(alert,alerts_path=args.alerts_path)}
        elif args.command=='readonly-pilot-gate':
            from backend.btc_readonly_pilot_gate import evaluate_readonly_pilot_gate, append_readonly_pilot_evidence
            live=json.loads(Path(args.live_report).read_text(encoding='utf-8'))
            ingestion=json.loads(Path(args.ingestion_report).read_text(encoding='utf-8'))
            drift_alert=json.loads(Path(args.drift_alert).read_text(encoding='utf-8'))
            gate=evaluate_readonly_pilot_gate(live_report=live,ingestion_result=ingestion,drift_alert=drift_alert,operator_approved=args.operator_approved)
            result={'gate':gate,'persistence':append_readonly_pilot_evidence(gate,log_path=args.evidence_log)}
        elif args.command=='live-source-observability':
            from backend.btc_live_observability import build_observability_from_jsonl, save_live_source_observability
            report=build_observability_from_jsonl(live_reports_path=args.live_reports,reconciliation_reports_path=args.reconciliation_reports,drift_alerts_path=args.drift_alerts,stale_threshold_hours=args.stale_threshold_hours,max_revision_rate=args.max_revision_rate)
            result={'report':report,'persistence':save_live_source_observability(report,output_path=args.output)}
        elif args.command=='fetch-cross-source-readonly':
            from backend.btc_cross_source_readonly import fetch_cross_source_btc_4h_readonly
            result=fetch_cross_source_btc_4h_readonly(limit=args.limit,max_age_hours=args.max_age_hours)
            raw=json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2).encode()+b'\n'
            target=Path(args.output); target.parent.mkdir(parents=True,exist_ok=True)
            fd=os.open(str(target),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,'wb') as stream: stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        elif args.command=='source-failover-drill':
            from backend.btc_source_failover_gate import evaluate_source_failover_drill, append_source_failover_evidence
            evidence=evaluate_source_failover_drill(scenarios=json.loads(Path(args.scenarios).read_text(encoding='utf-8')),operator_approved=args.operator_approved)
            result={'evidence':evidence,'persistence':append_source_failover_evidence(evidence,log_path=args.evidence_log)}
        elif args.command=='pilot-exit-review':
            from backend.btc_readonly_pilot_exit import evaluate_readonly_pilot_exit, append_readonly_pilot_handoff
            evidence=evaluate_readonly_pilot_exit(observability_report=json.loads(Path(args.observability_report).read_text(encoding='utf-8')),failover_drill=json.loads(Path(args.failover_drill).read_text(encoding='utf-8')),pilot_gate_evidence=json.loads(Path(args.pilot_gate).read_text(encoding='utf-8')),cross_source_reports=json.loads(Path(args.cross_source_reports).read_text(encoding='utf-8')),operator_decision=args.decision)
            result={'evidence':evidence,'handoff':append_readonly_pilot_handoff(evidence,handoff_path=args.handoff_log)}
        elif args.command=='pilot-review-bundle':
            from backend.btc_readonly_review_bundle import build_readonly_external_review_bundle
            result=build_readonly_external_review_bundle(artifact_paths=args.artifact,output_path=args.output,release_version=args.version)
        elif args.command=='verify-pilot-review-bundle':
            from backend.btc_readonly_review_bundle import verify_readonly_external_review_bundle
            result=verify_readonly_external_review_bundle(args.path)
        elif args.command=='readonly-security-review':
            from backend.btc_readonly_security_review import evaluate_readonly_security_review, record_readonly_operator_acceptance
            report=evaluate_readonly_security_review(project_root=args.project_root)
            result={'review':report}
            if args.decision:
                if not args.acceptance_output: raise ValueError('--acceptance-output_required_with_decision')
                result['acceptance']=record_readonly_operator_acceptance(report,decision=args.decision,output_path=args.acceptance_output)
        else:
            raise ValueError('unsupported_command')
        print(json.dumps(result,ensure_ascii=False,sort_keys=True,default=str))
        ok = (not isinstance(result,dict) or (result.get('valid',True) and result.get('healthy',True)
              and result.get('status') not in ('CRITICAL','UNANCHORED','DEGRADED','BLOCKED')
              and result.get('ready_for_external_witness',True)))
        return 0 if ok else 2
    except Exception as exc:
        print(json.dumps({'ok':False,'error':f'{type(exc).__name__}:{exc}'}),file=sys.stderr)
        return 2


if __name__=='__main__':
    raise SystemExit(main())
