"""Verify a pinned external Witness receipt and recover an incident export copy."""
import argparse,json
from pathlib import Path
from backend.btc_readonly_incident_recovery import run_incident_recovery_drill

def main():
 p=argparse.ArgumentParser(description='Verify incident bundle/Witness receipt and run non-destructive recovery drill')
 p.add_argument('--bundle',required=True); p.add_argument('--receipt',required=True)
 p.add_argument('--witness-public-key',required=True); p.add_argument('--highwater',default='live-validation/witness-highwater.json')
 p.add_argument('--recovery-dir',required=True); a=p.parse_args()
 receipt=json.loads(Path(a.receipt).read_text(encoding='utf-8'))
 report=run_incident_recovery_drill(a.bundle,receipt,pinned_public_key_path=a.witness_public_key,
   highwater_path=a.highwater,recovery_dir=a.recovery_dir)
 print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
