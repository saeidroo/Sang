@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Please run install.bat first.
  pause
  exit /b 1
)
REM Low-memory defaults for 6 GB RAM systems.
set TS_AI_MAX_WORKERS=1
set TS_AI_MODEL_THREADS=1
set OMP_NUM_THREADS=1
set OPENBLAS_NUM_THREADS=1
set MKL_NUM_THREADS=1
set NUMEXPR_NUM_THREADS=1
set PYTHONUNBUFFERED=1
REM Same engine as the "Auto multi-hour training" button in the web page.
REM Edit these values to change the run. No API key and no AI service is needed.
REM V17.2: if the app closes/crashes, run this again — AUTO_RETRAIN_RESUME=1
REM continues the previous run (finished rounds and remaining time are kept).
set AUTO_RETRAIN=1
set AUTO_RETRAIN_RESUME=1
set AUTO_RETRAIN_PRESET=top12
set AUTO_RETRAIN_TFS=1h,4h
set AUTO_RETRAIN_LIMIT=5000
set AUTO_RETRAIN_TRIALS=24
set AUTO_RETRAIN_DURATION_HOURS=8
echo Starting unattended training for %AUTO_RETRAIN_DURATION_HOURS% hours...
echo Data sources that do not answer are skipped automatically and retried later.
echo If interrupted, run this file again and it continues where it stopped.
echo Keep this window open. Close it or press Ctrl+C to stop.
echo.
"%CD%\.venv\Scripts\python.exe" -u main.py --browser
pause
