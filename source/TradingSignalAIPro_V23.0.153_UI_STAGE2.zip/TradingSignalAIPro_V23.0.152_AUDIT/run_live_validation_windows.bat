@echo off
setlocal
cd /d "%~dp0"
title TradingSignalAIPro - BTC 4H Read-Only Live Validation

echo ============================================================
echo TradingSignalAIPro - BTCUSDT 4H READ-ONLY LIVE VALIDATION
echo No API key, no training, no paper trading, no live orders.
echo ============================================================

where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python was not found in PATH.
  echo Install Python 3.10 or newer, then reopen this window.
  pause
  exit /b 10
)

python --version
if errorlevel 1 (
  echo [ERROR] Python could not start.
  pause
  exit /b 11
)

if not exist "live-validation" mkdir "live-validation"
set RUN_ID=%RANDOM%_%RANDOM%
set OUTPUT=live-validation\run_%RUN_ID%.json

echo.
echo Running public read-only requests to Binance and OKX...
echo Output: %OUTPUT%
python run_live_validation.py --limit 120 --timeout 12 --max-age-hours 8 --output "%OUTPUT%"
set RESULT=%ERRORLEVEL%

echo.
if "%RESULT%"=="0" (
  echo [PASS] Both public sources passed reconciliation.
) else if "%RESULT%"=="2" (
  echo [BLOCKED/DEGRADED] Network or source validation did not pass.
  echo Do not use this report as approval for training or trading.
) else (
  echo [ERROR] Validation command failed. Exit code: %RESULT%
)

echo Report saved, if created, at: %OUTPUT%
echo You may share this JSON report for review. Do NOT share private keys or tokens.
echo ============================================================
pause
exit /b %RESULT%
