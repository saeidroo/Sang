"""Standalone Witness service launcher. Deploy on a separate host."""
import argparse, os
from backend.witness_server import bootstrap_keys, create_app, init_db
from backend.witness_ops import export_receipts, verify_receipt_export, create_checkpoint, verify_checkpoint, restore_database, health_diagnostics
from backend.witness_replication import replicate_to_secondary, compare_witnesses
from backend.witness_remote import sync_replication_http, build_mtls_context
from backend.witness_scheduler import run_sync_once, run_scheduler, scheduler_status
from backend.witness_alerting import scheduler_metrics, prometheus_metrics, prune_scheduler_history
from backend.witness_security_ops import security_status, verify_security_chain, inspect_key_pair, create_token_rotation_candidate
from backend.release_readiness import production_readiness

def main():
    p=argparse.ArgumentParser(description='TradingSignalAIPro independent Witness')
    p.add_argument('--init-db', action='store_true')
    p.add_argument('--bootstrap-keys', action='store_true')
    p.add_argument('--private-key', default=os.getenv('TS_WITNESS_PRIVATE_KEY','witness-keys/witness-private.pem'))
    p.add_argument('--public-key', default=os.getenv('TS_WITNESS_PUBLIC_KEY','witness-keys/witness-public.pem'))
    p.add_argument('--db', default=os.getenv('TS_WITNESS_DB','witness-data/witness.sqlite3'))
    p.add_argument('--host', default='127.0.0.1'); p.add_argument('--port', type=int, default=8787)
    p.add_argument('--export-receipts'); p.add_argument('--verify-export')
    p.add_argument('--checkpoint'); p.add_argument('--checkpoint-export'); p.add_argument('--verify-checkpoint')
    p.add_argument('--restore-backup'); p.add_argument('--restore-to')
    p.add_argument('--health-diagnostics', action='store_true')
    p.add_argument('--replicate-to-db'); p.add_argument('--replica-private-key'); p.add_argument('--replica-public-key')
    p.add_argument('--compare-replica-db')
    p.add_argument('--remote-sync', action='store_true', help='Resume chunked HTTPS replication to remote Witness')
    p.add_argument('--remote-endpoint', default=os.getenv('TS_WITNESS_REMOTE_ENDPOINT'))
    p.add_argument('--remote-token', default=os.getenv('TS_WITNESS_API_TOKEN'))
    p.add_argument('--source-public-key', default=os.getenv('TS_WITNESS_PUBLIC_KEY'))
    p.add_argument('--chunk-size', type=int, default=500)
    p.add_argument('--mtls-ca'); p.add_argument('--mtls-cert'); p.add_argument('--mtls-key')
    p.add_argument('--remote-scheduler', action='store_true', help='Run durable periodic remote replication')
    p.add_argument('--remote-sync-once', action='store_true', help='Run one monitored replication cycle')
    p.add_argument('--scheduler-status', action='store_true', help='Show durable replication health and lag')
    p.add_argument('--scheduler-state-db', default=os.getenv('TS_WITNESS_SCHEDULER_DB','witness-data/replication-state.sqlite3'))
    p.add_argument('--interval-seconds', type=int, default=300)
    p.add_argument('--max-lag', type=int, default=0)
    p.add_argument('--stale-after-seconds', type=int, default=900)
    p.add_argument('--timeout', type=int, default=15)
    p.add_argument('--webhook-url', default=os.getenv('TS_WITNESS_ALERT_WEBHOOK'))
    p.add_argument('--webhook-token', default=os.getenv('TS_WITNESS_ALERT_WEBHOOK_TOKEN'))
    p.add_argument('--scheduler-metrics', action='store_true')
    p.add_argument('--prometheus-metrics', action='store_true')
    p.add_argument('--prune-scheduler-history', action='store_true')
    p.add_argument('--retention-days', type=int, default=30)
    p.add_argument('--retention-max-rows', type=int, default=10000)
    p.add_argument('--retention-dry-run', action='store_true')
    p.add_argument('--retention-vacuum', action='store_true')
    p.add_argument('--security-status', action='store_true')
    p.add_argument('--verify-security-chain', action='store_true')
    p.add_argument('--inspect-key-pair', action='store_true')
    p.add_argument('--production-readiness', action='store_true', help='Run read-only production configuration preflight')
    p.add_argument('--rotate-api-token-candidate')
    a=p.parse_args()
    if a.production_readiness:
        import json
        report = production_readiness(private_key_path=a.private_key, db_path=a.db, host=a.host)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        raise SystemExit(0 if report['status'] == 'READY' else 2)
    if a.rotate_api_token_candidate:
        print(create_token_rotation_candidate(a.rotate_api_token_candidate)); return
    if a.inspect_key_pair:
        print(inspect_key_pair(a.private_key, a.public_key)); return
    if a.security_status:
        print(security_status(a.db)); return
    if a.verify_security_chain:
        print(verify_security_chain(a.db)); return
    if a.bootstrap_keys:
        print(bootstrap_keys(a.private_key,a.public_key)); return
    if a.init_db: init_db(a.db); print(f'Initialized {a.db}'); return
    if a.export_receipts: print(export_receipts(a.db,a.public_key,a.export_receipts)); return
    if a.verify_export: print(verify_receipt_export(a.verify_export,a.public_key)); return
    if a.checkpoint:
        if not a.checkpoint_export: p.error('--checkpoint-export is required with --checkpoint')
        print(create_checkpoint(a.checkpoint_export,a.private_key,a.public_key,a.checkpoint)); return
    if a.verify_checkpoint:
        if not a.verify_export: p.error('--verify-export is required with --verify-checkpoint')
        print(verify_checkpoint(a.verify_checkpoint,a.public_key,a.verify_export)); return
    if a.restore_backup:
        if not a.restore_to: p.error('--restore-to is required with --restore-backup')
        print(restore_database(a.restore_backup,a.restore_to,a.public_key)); return
    if a.health_diagnostics: print(health_diagnostics(a.db,a.public_key)); return
    if a.replicate_to_db:
        if not (a.replica_private_key and a.replica_public_key): p.error('--replicate-to-db requires --replica-private-key and --replica-public-key')
        print(replicate_to_secondary(a.db,a.public_key,a.replicate_to_db,a.replica_private_key,a.replica_public_key)); return
    if a.compare_replica_db:
        if not a.replica_public_key: p.error('--compare-replica-db requires --replica-public-key')
        print(compare_witnesses(a.db,a.public_key,a.compare_replica_db,a.replica_public_key)); return
    if a.scheduler_metrics:
        print(scheduler_metrics(a.scheduler_state_db)); return
    if a.prometheus_metrics:
        print(prometheus_metrics(a.scheduler_state_db), end=''); return
    if a.prune_scheduler_history:
        print(prune_scheduler_history(a.scheduler_state_db,retention_days=a.retention_days,max_rows=a.retention_max_rows,vacuum=a.retention_vacuum,dry_run=a.retention_dry_run)); return
    if a.scheduler_status:
        print(scheduler_status(a.scheduler_state_db,max_lag=a.max_lag,stale_after_seconds=a.stale_after_seconds)); return
    if a.remote_scheduler or a.remote_sync_once:
        if not (a.remote_endpoint and a.remote_token and a.source_public_key): p.error('scheduler requires endpoint, token and source public key')
        ctx=build_mtls_context(ca_file=a.mtls_ca,cert_file=a.mtls_cert,key_file=a.mtls_key)
        if a.remote_scheduler:
            print(run_scheduler(a.db,a.source_public_key,a.remote_endpoint,a.remote_token,a.scheduler_state_db,interval_seconds=a.interval_seconds,max_lag=a.max_lag,chunk_size=a.chunk_size,timeout=a.timeout,ssl_context=ctx,webhook_url=a.webhook_url,webhook_token=a.webhook_token))
        else:
            print(run_sync_once(a.db,a.source_public_key,a.remote_endpoint,a.remote_token,a.scheduler_state_db,chunk_size=a.chunk_size,max_lag=a.max_lag,timeout=a.timeout,ssl_context=ctx,webhook_url=a.webhook_url,webhook_token=a.webhook_token))
        return
    if a.remote_sync:
        if not (a.remote_endpoint and a.remote_token and a.source_public_key): p.error('--remote-sync requires endpoint, token and source public key')
        ctx=build_mtls_context(ca_file=a.mtls_ca,cert_file=a.mtls_cert,key_file=a.mtls_key)
        print(sync_replication_http(a.db,a.source_public_key,a.remote_endpoint,a.remote_token,chunk_size=a.chunk_size,ssl_context=ctx)); return
    app=create_app(a.db,a.private_key)
    # Production deployment MUST terminate TLS at a trusted reverse proxy.
    app.run(host=a.host,port=a.port,debug=False,threaded=True)
if __name__=='__main__': main()
