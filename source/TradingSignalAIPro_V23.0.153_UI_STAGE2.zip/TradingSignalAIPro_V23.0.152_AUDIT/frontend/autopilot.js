/* V23.0.120: repaired AutoPilot UI bindings, selectable risk profiles and start diagnostics; paper-only control.
   No real orders anywhere; everything runs against the local paper account. */
(()=>{
  const API='';
  const $=id=>document.getElementById(id);
  const els={
    status:$('apStatus'),engineState:$('apEngineState'),equity:$('apEquity'),sessionNet:$('apSessionNet'),
    sessionWin:$('apSessionWin'),openCount:$('apOpenCount'),cycles:$('apCycles'),
    startBtn:$('apStartBtn'),stopBtn:$('apStopBtn'),stopCloseAll:$('apStopCloseAll'),tickBtn:$('apTickBtn'),
    symbolsBtn:$('apSymbolsBtn'),refreshBtn:$('apRefreshBtn'),saveCfgBtn:$('apSaveCfgBtn'),
    watchlist:$('apWatchlist'),watchMeta:$('apWatchMeta'),positions:$('apPositions'),decisions:$('apDecisions'),
    rankedCandidates:$('apRankedCandidates'),opportunityMeta:$('apOpportunityMeta'),
    preset:$('apPreset'),brain:$('apBrain'),timeframe:$('apTimeframe'),marketSpot:$('apMarketSpot'),
    marketPerp:$('apMarketPerp'),maxPositions:$('apMaxPositions'),notional:$('apNotional'),
    riskPerTrade:$('apRiskPerTrade'),maxDailyLoss:$('apMaxDailyLoss'),maxDrawdown:$('apMaxDrawdown'),capital:$('apCapital'),
    quickPreview:$('apQuickPreview'),profileCards:[...document.querySelectorAll('input[name="apQuickPreset"]')],
    sl:$('apSl'),tp:$('apTp'),trailing:$('apTrailing'),trailTrigger:$('apTrailTrigger'),trailDist:$('apTrailDist'),
    minConf:$('apMinConf'),cooldown:$('apCooldown'),
    reportKind:$('apReportKind'),reportBtn:$('apReportBtn'),csvBtn:$('apCsvBtn'),
    repClosed:$('apRepClosed'),repWin:$('apRepWin'),repNet:$('apRepNet'),repPF:$('apRepPF'),
    repDD:$('apRepDD'),repFees:$('apRepFees'),equityCanvas:$('apEquityCurve'),
    narrative:$('apNarrative'),repSymbols:$('apRepSymbols')
  };
  if(!els.status)return;
  let busy=false,refreshTimer=null,visibleOnce=false,lastCurve=null;
  const money=v=>Number.isFinite(Number(v))?Number(v).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:4}):'—';
  const pct=v=>Number.isFinite(Number(v))?`${Number(v).toFixed(2)}٪`:'—';
  const marketFa=m=>m==='spot'?'اسپات':(m==='perp'?'فیوچرز':m);
  const brainFa=b=>({hybrid:'ترکیبی',ml_only:'فقط ML',tech_only:'تکنیکال',ml:'مدل ML',ml_pool:'رأی مدل‌ها',tech:'تکنیکال'}[b]||b||'—');
  const phaseFa=p=>({entry:'ورود',manage:'مدیریت',report:'گزارش',system:'سیستم'}[p]||p);
  const actionFa=a=>({OPEN:'بازکردن',CLOSE:'بستن',AUTO_CLOSE:'بستن خودکار',REJECT:'رد سیگنال',HOLD:'بدون سیگنال',
    TRAIL_STOP:'حدضرر متحرک',COOLDOWN:'مهلت پس از زیان',STARTED:'روشن شد',STOPPED:'خاموش شد',ENTRIES_PAUSED:'ورود متوقف شد',MANAGER_DRAINING:'مدیریت موقعیت‌های باز',MANAGER_STOPPED:'مدیریت خاموش شد',MANAGER_START:'مدیر موقعیت روشن',MANAGER_EXIT:'مدیر موقعیت خاموش',ENTRY_LOOP_START:'اسکن ورود روشن',ENTRY_LOOP_EXIT:'اسکن ورود خاموش',
    ENGINE_START:'موتور روشن',ENGINE_STOP:'موتور خاموش',CONFIG_UPDATED:'تنظیمات',WATCHLIST_UPDATED:'نمادها',
    DAILY_REPORT:'گزارش روزانه',TICK:'چرخهٔ دستی',DIVERSITY_REJECT:'رد به‌علت هم‌بستگی',BASE_EXPOSURE_REJECT:'رد ریسک تکراری ارز'}[a]||a);
  const setStatus=(msg,kind='')=>{els.status.textContent=msg;els.status.className='paper-live-status '+kind;};
  const setBusy=f=>{busy=f;[els.startBtn,els.stopBtn,els.tickBtn,els.symbolsBtn,els.saveCfgBtn,els.reportBtn].forEach(b=>{if(b)b.disabled=f;});};
  const request=async(url,options={})=>{
    const r=await fetch(`${API}${url}`,{cache:'no-store',...options,headers:{'Content-Type':'application/json',...(options.headers||{})}});
    let d={};try{d=await r.json();}catch(_){throw new Error('پاسخ سرور قابل خواندن نیست');}
    if(!r.ok)throw new Error(d.error||`خطای سرور (${r.status})`);
    return d;
  };
  const safe=async fn=>{try{return await fn();}catch(e){setStatus(e.message,'err');console.warn('[autopilot]',e);return null;}};

  /* ---------- config form ---------- */
  function fillForm(cfg){
    if(!cfg)return;
    els.preset.value=cfg.risk_preset||'balanced';
    els.brain.value=cfg.brain_mode||'hybrid';
    els.timeframe.value=cfg.timeframe||'1h';
    els.marketSpot.checked=(cfg.markets||[]).includes('spot');
    els.marketPerp.checked=(cfg.markets||[]).includes('perp');
    els.maxPositions.value=cfg.max_open_positions??3;
    els.notional.value=cfg.max_position_notional_pct??10;
    els.riskPerTrade.value=cfg.risk_per_trade_pct??0.5;
    els.sl.value=cfg.stop_loss_pct??1.5;
    els.tp.value=cfg.take_profit_pct??3;
    els.maxDailyLoss.value=cfg.max_daily_loss_pct??1.5;
    els.maxDrawdown.value=cfg.max_drawdown_pct??7.5;
    if(els.capital)els.capital.value=cfg.daily_start_balance??1000;
    els.trailing.checked=!!cfg.trailing_enabled;
    els.trailTrigger.value=cfg.trail_trigger_pct??1.5;
    els.trailDist.value=cfg.trail_distance_pct??1.0;
    els.minConf.value=cfg.min_signal_confidence??0.55;
    els.cooldown.value=cfg.cooldown_after_loss_minutes??60;
    els.profileCards.forEach(card=>{card.checked=card.value===(cfg.risk_preset||'balanced');
      card.closest('.ap-profile-card')?.classList.toggle('is-selected',card.checked);});
    updateQuickPreview();
  }
  function readForm(){
    const markets=[];
    if(els.marketSpot.checked)markets.push('spot');
    if(els.marketPerp.checked)markets.push('perp');
    if(!markets.length)throw new Error('حداقل یک بازار (اسپات یا فیوچرز) باید فعال باشد.');
    return {
      risk_preset:els.preset.value, daily_start_balance:Number(els.capital ? els.capital.value : 1000),
      brain_mode:els.brain.value, timeframe:els.timeframe.value,
      markets, max_open_positions:Number(els.maxPositions.value), max_symbols:Number(els.maxSymbols?.value||({conservative:5,balanced:8,assertive:10}[els.preset.value]||8)),
      max_position_notional_pct:Number(els.notional.value), risk_per_trade_pct:Number(els.riskPerTrade.value),
      stop_loss_pct:Number(els.sl.value), take_profit_pct:Number(els.tp.value),
      max_daily_loss_pct:Number(els.maxDailyLoss.value), max_drawdown_pct:Number(els.maxDrawdown.value),
      trailing_enabled:els.trailing.checked,
      trail_trigger_pct:Number(els.trailTrigger.value), trail_distance_pct:Number(els.trailDist.value),
      min_signal_confidence:Number(els.minConf.value), cooldown_after_loss_minutes:Number(els.cooldown.value)
    };
  }
  const QUICK_PRESETS={
    conservative:{max_open_positions:2,max_position_notional_pct:8,risk_per_trade_pct:.25,stop_loss_pct:1.5,take_profit_pct:3,
      max_daily_loss_pct:1,max_drawdown_pct:5,max_portfolio_risk_pct:.75,max_spot_risk_pct:.75,max_perp_risk_pct:.25,
      max_directional_risk_pct:.5,markets:['spot'],max_symbols:5,min_signal_confidence:.65,cooldown_after_loss_minutes:90},
    balanced:{max_open_positions:3,max_position_notional_pct:10,risk_per_trade_pct:.5,stop_loss_pct:1.5,take_profit_pct:3,
      max_daily_loss_pct:1.5,max_drawdown_pct:7.5,max_portfolio_risk_pct:1,max_spot_risk_pct:1,max_perp_risk_pct:.5,
      max_directional_risk_pct:.75,markets:['spot'],max_symbols:8,min_signal_confidence:.62,cooldown_after_loss_minutes:60},
    assertive:{max_open_positions:4,max_position_notional_pct:15,risk_per_trade_pct:.75,stop_loss_pct:1.5,take_profit_pct:3,
      max_daily_loss_pct:2,max_drawdown_pct:10,max_portfolio_risk_pct:1.5,max_spot_risk_pct:1,max_perp_risk_pct:.5,
      max_directional_risk_pct:1,markets:['spot','perp'],max_symbols:10,min_signal_confidence:.58,cooldown_after_loss_minutes:45}
  };
  function updateQuickPreview(){
    if(!els.quickPreview)return;
    const capital=Number(els.capital ? els.capital.value : 1000);
    const key=els.preset?.value||'balanced';
    const profile=QUICK_PRESETS[key]||QUICK_PRESETS.balanced;
    if(!Number.isFinite(capital)||capital<10){els.quickPreview.textContent='سرمایه باید حداقل ۱۰ USDT باشد.';return;}
    const usd=n=>`${(capital*Number(n)/100).toLocaleString('en-US',{maximumFractionDigits:2})} USDT`;
    const dailyGoal=capital>=1000?30:(capital>=200?20:10);
    els.quickPreview.textContent=`هدف روزانه: ${dailyGoal} USDT (هدف، نه تضمین) · ریسک هر معامله: ${usd(profile.risk_per_trade_pct)} · سقف زیان روزانه: ${usd(profile.max_daily_loss_pct)} · سقف ریسک سبد: ${usd(profile.max_portfolio_risk_pct)}`;
  }
  function applyQuickPreset(key){
    const p=QUICK_PRESETS[key];if(!p)return;
    els.preset.value=key;
    els.maxPositions.value=p.max_open_positions;els.notional.value=p.max_position_notional_pct;
    els.riskPerTrade.value=p.risk_per_trade_pct;els.sl.value=p.stop_loss_pct;els.tp.value=p.take_profit_pct;
    els.maxDailyLoss.value=p.max_daily_loss_pct;els.maxDrawdown.value=p.max_drawdown_pct;
    els.marketSpot.checked=p.markets.includes('spot');els.marketPerp.checked=p.markets.includes('perp');
    els.minConf.value=p.min_signal_confidence;els.cooldown.value=p.cooldown_after_loss_minutes;
    els.profileCards.forEach(card=>{card.checked=card.value===key;card.closest('.ap-profile-card')?.classList.toggle('is-selected',card.checked);});
    updateQuickPreview();
  }
  async function saveConfig(){
    let body;try{body=readForm();}catch(e){setStatus(e.message,'err');return;}
    setBusy(true);setStatus('در حال ذخیرهٔ تنظیمات…','busy');
    const d=await safe(()=>request('/api/autopilot/config',{method:'POST',body:JSON.stringify(body)}));
    if(d){fillForm(d.config);setStatus('تنظیمات ذخیره شد','ok');await safe(loadState);}
    setBusy(false);
  }

  /* ---------- state rendering ---------- */
  function addCell(tr,value,color){const td=document.createElement('td');td.textContent=value;if(color)td.style.color=color;tr.append(td);return td;}
  function renderWatchlist(wl){
    els.watchlist.replaceChildren();
    const symbols=(wl&&wl.symbols)||[];
    if(!symbols.length){const s=document.createElement('span');s.className='note';s.textContent='لیست نمادها در دسترس نیست؛ دکمهٔ تازه‌سازی را بزن.';els.watchlist.append(s);}
    symbols.forEach(sym=>{
      const chip=document.createElement('span');chip.className='ap-chip';chip.textContent=sym;els.watchlist.append(chip);
    });
    if(wl&&wl.source){
      const src=wl.source==='fallback'?'لیست ثابت (اتصال صرافی برقرار نبود)':(wl.source==='binance+bybit'?'Binance + Bybit':'Binance');
      const age=wl.updated_at?` · ${new Date(wl.updated_at*1000).toLocaleTimeString('fa-IR')}`:'';
      els.watchMeta.textContent=`منبع: ${src}${age}`;
    }
  }
  function renderOpportunityRanking(summary){
    if(!els.rankedCandidates)return;
    els.rankedCandidates.replaceChildren();
    const rows=(summary&&summary.ranked)||[];
    if(!rows.length){
      const tr=document.createElement('tr'),td=document.createElement('td');
      td.colSpan=8;td.className='note';td.textContent='هنوز فرصت واجد شرایطی رتبه‌بندی نشده است.';
      tr.append(td);els.rankedCandidates.append(tr);
    }else{
      const visible=rows.slice(0,12);
      rows.slice(12).filter(x=>x.selected).forEach(x=>visible.push(x));
      visible.forEach(x=>{
        const tr=document.createElement('tr');
        addCell(tr,String(x.rank??'—'));
        addCell(tr,x.symbol||'—');
        addCell(tr,marketFa(x.market));
        addCell(tr,x.side==='LONG'?'لانگ':(x.side==='SHORT'?'شورت':'—'),x.side==='LONG'?'var(--green)':(x.side==='SHORT'?'var(--red)':''));
        addCell(tr,Number.isFinite(Number(x.score))?Number(x.score).toFixed(2):'—');
        addCell(tr,pct(Number(x.confidence)*100));
        addCell(tr,Number(x.volume_24h)>0?money(x.volume_24h):'—');
        const reason=x.selected?'انتخاب شد':(x.reason||'انتخاب نشد');
        addCell(tr,reason,x.selected?'var(--green)':'');
        els.rankedCandidates.append(tr);
      });
    }
    if(els.opportunityMeta){
      const age=summary&&summary.ts?new Date(Number(summary.ts)*1000).toLocaleTimeString('fa-IR'):'—';
      els.opportunityMeta.textContent=summary&&summary.ts?
        `آخرین رتبه‌بندی: ${age} · ارزیابی ${summary.evaluated||0} · کاندیدا ${summary.candidates||0} · بازشده ${summary.opened||0} · رد هم‌بستگی ${summary.diversity_blocked||0}`:
        'پس از هر چرخهٔ تحلیل به‌روزرسانی می‌شود';
    }
  }

  function renderPositions(positions){
    els.positions.replaceChildren();
    const rows=(positions||[]).filter(x=>x.status==='OPEN');
    if(!rows.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=9;td.className='note';
      td.textContent='موتور فعلاً موقعیت بازی باز نکرده است؛ بعد از اولین سیگنال معتبر به‌صورت خودکار باز می‌شود.';tr.append(td);els.positions.append(tr);return;}
    rows.forEach(x=>{
      const tr=document.createElement('tr');
      addCell(tr,x.symbol);addCell(tr,marketFa(x.market));addCell(tr,x.side==='LONG'?'Long':'Short',x.side==='LONG'?'var(--green)':'var(--red)');
      addCell(tr,money(x.entry_fill));
      addCell(tr,x.quote_status==='DISCONNECTED'?'قطع اتصال':money(x.last_price));
      addCell(tr,money(x.stop_price));
      addCell(tr,money(x.target_price));
      const pnl=x.unrealized_net_pnl;
      addCell(tr,pnl==null?'نامشخص':`${money(pnl)} USDT`,pnl==null?'':(Number(pnl)>=0?'var(--green)':'var(--red)'));
      const td=document.createElement('td');const btn=document.createElement('button');btn.type='button';
      btn.className='paper-live-close';btn.textContent='بستن دستی';
      btn.addEventListener('click',()=>closePosition(x.id,btn));td.append(btn);tr.append(td);
      els.positions.append(tr);
    });
  }
  function renderDecisions(decisions){
    els.decisions.replaceChildren();
    const rows=(decisions||[]).slice().reverse().slice(0,40);
    if(!rows.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=8;td.className='note';td.textContent='هنوز رویدادی ثبت نشده است.';tr.append(td);els.decisions.append(tr);return;}
    rows.forEach(x=>{
      const tr=document.createElement('tr');
      const ts=x.ts?new Date(Number(x.ts)*1000).toLocaleTimeString('fa-IR'):'—';
      addCell(tr,ts);addCell(tr,phaseFa(x.phase));
      const actTd=addCell(tr,actionFa(x.action)||x.action);
      if(x.level==='warn')actTd.style.color='var(--gold)';
      if(x.action==='OPEN')actTd.style.color='var(--green)';
      if(x.action==='AUTO_CLOSE'||x.action==='CLOSE')actTd.style.color='var(--cyan)';
      addCell(tr,x.symbol||'—');addCell(tr,x.market?marketFa(x.market):'—');
      addCell(tr,brainFa(x.brain));
      addCell(tr,Number.isFinite(Number(x.confidence))&&x.confidence!=null?Number(x.confidence).toFixed(2):'—');
      addCell(tr,x.detail||'');
      els.decisions.append(tr);
    });
  }
  async function loadState(){
    const d=await request('/api/autopilot/state');
    const entries=!!d.entries_enabled;
    const managing=!!d.managing;
    const engineLabel=entries?'ورود + مدیریت روشن ▶':(managing?'فقط مدیریت موقعیت‌های باز ◷':'خاموش ■');
    const engineMessage=entries?'اسکن و ورود خودکار فعال است':(managing?'ورودهای جدید متوقف‌اند؛ مدیریت موقعیت‌های باز ادامه دارد':'موتور خاموش است — دکمهٔ روشن‌کردن را بزن');
    const checkpoint=d.runtime_state||{};
    if(!checkpoint.loaded){
      const why=checkpoint.error?` · ${checkpoint.error}`:'';
      setStatus(`حافظهٔ پایدار اسکن بارگذاری نشده؛ ورود جدید مسدود است${why}`,'err');
    }else{
      const savedAt=checkpoint.saved_at?new Date(Number(checkpoint.saved_at)*1000).toLocaleTimeString('fa-IR'):'هنوز ذخیره نشده';
      const workerError=d.last_entry_error||d.last_manage_error||d.last_cycle_error||'';
      if(workerError){
        setStatus(`${engineMessage} · خطای آخرین اجرا: ${workerError}`, 'err');
      }else{
        setStatus(`${engineMessage} · حافظهٔ پایدار سالم (آخرین ذخیره: ${savedAt})`,entries||managing?'ok':'err');
      }
    }
    els.engineState.textContent=engineLabel;
    els.engineState.style.color=entries||managing?'var(--green)':'var(--red)';
    const a=d.account||{};
    els.equity.textContent=`${money(a.equity)} USDT`;
    const s=d.session_stats||{};
    const net=s.net_pnl==null?0:Number(s.net_pnl);
    els.sessionNet.textContent=`${net>=0?'+':''}${money(net)} USDT`;
    els.sessionNet.style.color=net>=0?'var(--green)':'var(--red)';
    els.sessionWin.textContent=pct(s.win_rate_pct);
    els.openCount.textContent=String((d.open_positions||[]).length);
    els.cycles.textContent=String(d.cycles||0);
    fillForm(d.config);
    if(d.daily_profit_goal?.complete && els.quickPreview){
      const g=d.daily_profit_goal;
      const goalState=g.reached?'هدف محقق شد؛ ورود جدید تا روز بعد متوقف است':`باقی‌مانده تا هدف امروز: ${Number(g.remaining_usdt||0).toFixed(2)} USDT`;
      els.quickPreview.textContent += ` · ${goalState}`;
    } else if(d.daily_profit_goal && !d.daily_profit_goal.complete && els.quickPreview){
      els.quickPreview.textContent += ' · بررسی سود روزانه ناموفق؛ ورود جدید مسدود می‌شود';
    }
    renderWatchlist(d.watchlist);
    renderOpportunityRanking(d.last_entry_summary);
    renderPositions(d.open_positions);
    renderDecisions(d.decisions);
    return d;
  }
  async function closePosition(id,button){
    if(button){button.disabled=true;button.textContent='در حال بستن…';}
    setStatus('در حال بستن موقعیت…','busy');
    try{await request(`/api/paper-live/positions/${id}/close`,{method:'POST',body:'{}'});
      setStatus('موقعیت بسته شد','ok');await safe(()=>loadState());}
    catch(e){setStatus(e.message,'err');if(button){button.disabled=false;btnReset(button);}}
  }
  const btnReset=b=>{b.textContent='بستن دستی';};

  /* ---------- engine actions ---------- */
  function startFailureMessage(d){
    const errors=d?.recovery_validation?.errors;
    if(Array.isArray(errors)&&errors.length){
      return `روشن نشد؛ بررسی سلامت دفتر معاملات آزمایشی رد شد: ${errors.join('، ')}`;
    }
    const labels={
      autopilot_process_lease_held:'یک نمونهٔ دیگر از برنامه در حال استفاده از دفتر معاملات آزمایشی است؛ نمونهٔ تکراری را ببند.',
      autopilot_process_lease_error:'قفل ایمنی اجرای موتور ایجاد نشد؛ گزارش خطا را بررسی کن.',
      paper_ledger_recovery_blocked:'دفتر معاملات آزمایشی از بررسی سلامت عبور نکرد؛ ورود جدید ایمن نیست.'
    };
    const reason=String(d?.reason||'');
    return `موتور روشن نشد: ${labels[reason]||reason||'سرور شروع موتور را تأیید نکرد.'}${d?.error?` · ${d.error}`:''}`;
  }
  async function startEngine(){
    let config;
    try{config=readForm();}catch(e){setStatus(e.message,'err');return;}
    setBusy(true);setStatus('در حال ذخیرهٔ پروفایل و تنظیمات پیش از شروع…','busy');
    const saved=await safe(()=>request('/api/autopilot/config',{method:'POST',body:JSON.stringify(config)}));
    if(!saved){setBusy(false);return;}
    fillForm(saved.config||saved);
    setStatus('تنظیمات ذخیره شد؛ در حال روشن‌کردن موتور آزمایشی…','busy');
    const d=await safe(()=>request('/api/autopilot/start',{method:'POST',body:'{}'}));
    if(d){
      const refreshed=await safe(()=>loadState());
      if(d.ok!==true){
        setStatus(startFailureMessage(d),'err');
      }else if(refreshed?.entries_enabled){
        setStatus('اسکن ورود و مدیریت موقعیت‌های آزمایشی روشن شد','ok');
      }else{
        const detail=refreshed?.last_entry_error||refreshed?.last_manage_error||'وضعیت اسکن ورود هنوز فعال تأیید نشده است.';
        setStatus(`شروع پاسخ مثبت داد، اما اسکن ورود فعال نیست: ${detail}`,'err');
      }
    }
    setBusy(false);
  }
  async function stopEngine(){
    const closeAll=els.stopCloseAll.checked;
    if(closeAll&&!window.confirm('با توقف موتور، همهٔ موقعیت‌های باز خودکار با قیمت زنده بسته می‌شوند. مطمئنی؟'))return;
    setBusy(true);setStatus('در حال توقف موتور…','busy');
    const d=await safe(()=>request('/api/autopilot/stop',{method:'POST',body:JSON.stringify({close_all:closeAll})}));
    if(d){
      if(d.managing)setStatus(`ورودهای جدید متوقف شد؛ مدیریت ${d.remaining_positions} موقعیت باز ادامه دارد${closeAll?` · ${d.closed.length} موقعیت بسته شد`:''}`,'ok');
      else setStatus(`ورود و مدیریت خاموش شد${closeAll?` · ${d.closed.length} موقعیت بسته شد`:''}`,'ok');
    }
    await safe(()=>loadState());setBusy(false);
  }
  async function tickOnce(){
    setBusy(true);setStatus('در حال اجرای یک چرخهٔ کامل (مدیریت + سیگنال‌گیری)…','busy');
    const d=await safe(()=>request('/api/autopilot/tick',{method:'POST',body:'{}'}));
    if(d){
      const c=d.cycle||{};
      setStatus(`چرخه کامل شد · ${c.duration_seconds}s · ارزیابی ${c.entry?.evaluated||0} · باز ${c.entry?.opened||0} · رد ${c.entry?.rejected||0}`,'ok');
      await safe(()=>loadState());
    }
    setBusy(false);
  }
  async function refreshSymbols(){
    setBusy(true);els.watchMeta.textContent='در حال دریافت تاپ حجم از صرافی‌ها…';
    const d=await safe(()=>request('/api/autopilot/symbols?force=1'));
    if(d){renderWatchlist(d);setStatus(`${(d.symbols||[]).length} نماد پرحجم دریافت شد`,'ok');}
    setBusy(false);
  }

  /* ---------- report ---------- */
  function drawEquityCurve(curve){
    const canvas=els.equityCanvas;
    if(!canvas)return;
    if(curve)lastCurve=curve;
    const data=lastCurve;
    const dpr=window.devicePixelRatio||1;
    const w=canvas.clientWidth||600,h=130;
    canvas.width=w*dpr;canvas.height=h*dpr;
    const ctx=canvas.getContext('2d');
    ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);
    ctx.fillStyle='#0a1524';ctx.fillRect(0,0,w,h);
    if(!data||data.length<2){
      ctx.fillStyle='#8fa2bd';ctx.font='12px Vazirmatn,sans-serif';ctx.textAlign='center';
      ctx.fillText('برای رسم منحنی سرمایه حداقل یک معاملهٔ بسته‌شده لازم است.',w/2,h/2);return;
    }
    const vals=data.map(p=>Number(p.equity));
    const min=Math.min(...vals),max=Math.max(...vals);
    const span=(max-min)||1;const pad=12;
    const x=i=>pad+(w-2*pad)*i/(data.length-1);
    const y=v=>h-pad-(h-2*pad)*((v-min)/span);
    const up=vals[vals.length-1]>=vals[0];
    ctx.strokeStyle=up?'#20c997':'#ff657a';ctx.lineWidth=2;ctx.beginPath();
    data.forEach((p,i)=>{i?ctx.lineTo(x(i),y(vals[i])):ctx.moveTo(x(i),y(vals[i]));});ctx.stroke();
    ctx.lineTo(x(data.length-1),h-pad);ctx.lineTo(x(0),h-pad);ctx.closePath();
    ctx.fillStyle=up?'rgba(32,201,151,.12)':'rgba(255,101,122,.12)';ctx.fill();
    ctx.fillStyle='#8fa2bd';ctx.font='11px Vazirmatn,sans-serif';ctx.textAlign='left';
    ctx.fillText(`آخرین: ${vals[vals.length-1].toLocaleString('en-US',{maximumFractionDigits:2})} USDT`,pad,14);
    ctx.fillText(`شروع: ${vals[0].toLocaleString('en-US',{maximumFractionDigits:2})}`,pad,h-pad-6);
  }
  function renderReport(rep){
    const s=rep.stats||{};
    els.repClosed.textContent=String(s.closed_trades??0);
    els.repWin.textContent=pct(s.win_rate_pct);
    const net=Number(s.net_pnl||0);
    els.repNet.textContent=`${net>=0?'+':''}${money(net)} USDT`;els.repNet.style.color=net>=0?'var(--green)':'var(--red)';
    const pf=s.profit_factor;
    els.repPF.textContent=pf==null?'—':(pf===999?'∞':Number(pf).toFixed(2));
    els.repDD.textContent=pct(s.max_drawdown_pct);
    els.repFees.textContent=`${money(s.fees_paid)} USDT`;
    els.narrative.textContent=rep.narrative||'—';
    els.repSymbols.replaceChildren();
    const by=Object.entries(s.by_symbol||{});
    if(!by.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=4;td.className='note';td.textContent='در این بازه معاملهٔ بسته‌شده‌ای وجود ندارد.';tr.append(td);els.repSymbols.append(tr);}
    by.sort((a,b)=>b[1].net_pnl-a[1].net_pnl).forEach(([sym,v])=>{
      const tr=document.createElement('tr');
      addCell(tr,sym);addCell(tr,String(v.trades));addCell(tr,String(v.wins));
      addCell(tr,`${v.net_pnl>=0?'+':''}${money(v.net_pnl)} USDT`,v.net_pnl>=0?'var(--green)':'var(--red)');
      els.repSymbols.append(tr);
    });
    drawEquityCurve(s.equity_curve);
  }
  async function loadReport(){
    setBusy(true);setStatus('در حال ساخت گزارش…','busy');
    const kind=els.reportKind.value;
    const d=await safe(()=>request(`/api/autopilot/report?kind=${kind}`));
    if(d){renderReport(d);setStatus('گزارش آماده است','ok');}
    setBusy(false);
  }

  /* ---------- wiring ---------- */
  document.addEventListener('DOMContentLoaded',async()=>{
    const nav=document.querySelector('.side-link[data-section="autopilotPanel"]');
    const enter=async()=>{if(visibleOnce)return;visibleOnce=true;
      await safe(()=>loadState());await safe(()=>loadReport());};
    nav?.addEventListener('click',enter);
    if(window.location.hash==='#autopilotPanel')void enter();
    // Wire controls before the first network request: an unavailable status
    // endpoint must never leave the controls inert.
    els.startBtn?.addEventListener('click',()=>safe(startEngine));
    els.stopBtn?.addEventListener('click',()=>safe(stopEngine));
    els.tickBtn?.addEventListener('click',()=>safe(tickOnce));
    els.symbolsBtn?.addEventListener('click',()=>safe(refreshSymbols));
    els.refreshBtn?.addEventListener('click',()=>safe(()=>loadState()));
    els.saveCfgBtn?.addEventListener('click',()=>safe(saveConfig));
    els.reportBtn?.addEventListener('click',()=>safe(loadReport));
    els.csvBtn?.addEventListener('click',()=>{window.location.href='/api/autopilot/report.csv';});
    els.preset?.addEventListener('change',()=>{
      if(QUICK_PRESETS[els.preset.value])applyQuickPreset(els.preset.value);
      else {els.profileCards.forEach(card=>{card.checked=false;card.closest('.ap-profile-card')?.classList.remove('is-selected');});updateQuickPreview();}
    });
    els.profileCards.forEach(card=>card.addEventListener('change',()=>{if(card.checked)applyQuickPreset(card.value);}));
    els.capital?.addEventListener('input',updateQuickPreview);
    // Any manual advanced edit changes the profile label to Custom.
    [els.maxPositions,els.notional,els.riskPerTrade,els.sl,els.tp,els.maxDailyLoss,els.maxDrawdown,
      els.marketSpot,els.marketPerp,els.minConf,els.cooldown].forEach(input=>{
      input?.addEventListener('input',()=>{
        if(els.preset)els.preset.value='custom';
        els.profileCards.forEach(card=>{card.checked=false;card.closest('.ap-profile-card')?.classList.remove('is-selected');});
        updateQuickPreview();
      });
      input?.addEventListener('change',()=>{
        if(els.preset)els.preset.value='custom';
        els.profileCards.forEach(card=>{card.checked=false;card.closest('.ap-profile-card')?.classList.remove('is-selected');});
        updateQuickPreview();
      });
    });
    if(refreshTimer)clearInterval(refreshTimer);
    refreshTimer=setInterval(()=>{
      if(document.visibilityState==='visible'&&document.getElementById('autopilotPanel')?.offsetParent!==null)safe(()=>loadState());
    },10000);
    window.addEventListener('resize',()=>drawEquityCurve(null));
    await safe(()=>loadState());
  });
})();
