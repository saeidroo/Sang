/* V23.0.113 — compact cross-market glance; read-only, independent of chart/trading feeds. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const fmt = value => {
    const n = Number(value);
    if (!Number.isFinite(n)) return '—';
    return new Intl.NumberFormat('en-US', {maximumFractionDigits: n >= 1000 ? 2 : n >= 1 ? 4 : 6}).format(n);
  };
  const pct = value => {
    const n = Number(value);
    if (!Number.isFinite(n)) return 'تغییر نامشخص';
    return `${n > 0 ? '+' : ''}${n.toFixed(2)}٪`;
  };
  async function refresh() {
    try {
      const response = await fetch('/api/market/overview', {cache: 'no-store'});
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
      const sources = new Set();
      (data.items || []).forEach(item => {
        const price = $('mg' + item.id + 'Price');
        const change = $('mg' + item.id + 'Change');
        const card = document.querySelector(`[data-market="${item.id}"]`);
        if (!price || !change || !card) return;
        card.classList.toggle('is-up', item.status === 'ok' && Number(item.change_pct) > 0);
        card.classList.toggle('is-down', item.status === 'ok' && Number(item.change_pct) < 0);
        if (item.status !== 'ok') {
          price.textContent = 'ناموجود'; change.textContent = 'منبع پاسخ نداد';
          card.title = item.error || 'داده فعلاً در دسترس نیست'; return;
        }
        price.textContent = fmt(item.price) + ' ' + (item.currency || 'USD');
        change.textContent = pct(item.change_pct) + ' · ' + (item.source || 'منبع نامشخص');
        card.title = `${item.label} · ${item.source || ''}`;
        if (item.source) sources.add(item.source);
      });
      const stamp = new Date((data.updated_at || Date.now()/1000) * 1000).toLocaleTimeString('fa-IR', {hour:'2-digit',minute:'2-digit'});
      if ($('marketGlanceUpdated')) $('marketGlanceUpdated').textContent = `به‌روزرسانی ${stamp}`;
      if ($('marketGlanceSource')) $('marketGlanceSource').textContent = `منابع: ${[...sources].join('، ') || 'داده‌ای دریافت نشد'} · تغییرات ۲۴ ساعته؛ قیمت‌ها دلاری و تقریبی`;
    } catch (error) {
      if ($('marketGlanceUpdated')) $('marketGlanceUpdated').textContent = 'اتصال موقتاً ناموفق';
      if ($('marketGlanceSource')) $('marketGlanceSource').textContent = 'قیمت‌های این بخش دریافت نشد؛ با تلاش بعدی دوباره بررسی می‌شود.';
    }
  }
  document.addEventListener('DOMContentLoaded', () => { refresh(); window.setInterval(refresh, 60000); });
})();
