/* V22.7.0 — structured early-opportunity intelligence view; consumes existing Scout state only. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const fa = (n, digits=1) => Number(n).toLocaleString('fa-IR', {maximumFractionDigits:digits});
  const safe = v => (v === null || v === undefined || v === '' ? '—' : String(v));
  let lastState = null;
  function phaseLabel(item) {
    if (item._tier === 'pre_pump') return 'پیش از پامپ';
    if (item._tier === 'pre_dump') return 'پیش از دامپ';
    if (item._tier === 'active_dump') return 'دامپ فعال';
    const p = String(item.phase || '').toLowerCase();
    return ({early:'شروع حرکت', storm:'طوفان', forming:'در حال شکل‌گیری', exhausted:'حرکت فرسوده'})[p] || safe(item.phase);
  }
  function riskLabel(item, state) {
    const risks = [];
    if (item.verified === false) risks.push('کندل تأییدنشده');
    if (item.identity_conflict) risks.push('اختلاف هویت/قیمت منابع');
    if (item.mtf && item.mtf.checked && item.mtf.status !== 'aligned') risks.push('ناهم‌جهتی تایم‌فریم');
    if (state?.stale) risks.push('داده قدیمی');
    return risks.length ? risks.join(' · ') : 'ریسک ویژه‌ای در داده گزارش نشده';
  }
  function render(state) {
    const target = $('radarRows');
    if (!target || !state) return;
    lastState = state;
    const groups = [
      ...(state.pre_pump || []).map(x => ({...x, _tier:'pre_pump'})),
      ...(state.pre_dump || []).map(x => ({...x, _tier:'pre_dump'})),
      ...(state.active_dump || []).map(x => ({...x, _tier:'active_dump'})),
      ...(state.early || []).map(x => ({...x, _tier:'early'})),
      ...(state.alerts || []).map(x => ({...x, _tier:'alert'})),
      ...(state.watch || []).map(x => ({...x, _tier:'watch'}))
    ];
    const seen = new Set();
    const rows = groups.filter(x => {
      const symbol = String(x.symbol || x.base || '').toUpperCase();
      const direction = String(x.direction || 'unknown').toLowerCase();
      const signalClass = ['pre_pump','pre_dump','active_dump'].includes(x._tier) ? x._tier : 'general';
      const k = `${symbol}|${direction}|${signalClass}`;
      if (!symbol || seen.has(k)) return false;
      seen.add(k); return true;
    });
    const tierOrder = {pre_pump:0, pre_dump:0, active_dump:0, early:1, alert:2, watch:3};
    const tierScore = item => item._tier === 'pre_pump' ? Number(item.pre_pump_score || 0)
      : item._tier === 'pre_dump' ? Number(item.pre_dump_score || 0)
      : item._tier === 'active_dump' ? Number(item.active_dump_score || 0) : Number(item.score || 0);
    rows.sort((a,b) => (tierOrder[a._tier] ?? 9) - (tierOrder[b._tier] ?? 9) || tierScore(b)-tierScore(a));
    document.dispatchEvent(new CustomEvent('tekar:opportunity-radar-rows', {detail:{state, rows}}));
    const earlyCount = (state.early || []).length;
    const freshCount = rows.filter(x => x.fresh).length;
    $('radarCount').textContent = fa(rows.length,0);
    $('radarNewCount').textContent = fa(earlyCount,0);
    $('radarTopScore').textContent = rows.length ? fa(Math.max(...rows.map(tierScore))) : '—';
    $('radarStatus').textContent = state.online === false ? 'منبع آفلاین یا داده در دسترس نیست' : `${fa((state.pre_pump || []).length,0)} پیش از پامپ · ${fa((state.pre_dump || []).length,0)} پیش از دامپ · ${fa((state.active_dump || []).length,0)} دامپ فعال · ${fa(earlyCount,0)} شروع حرکت · ${fa(freshCount,0)} نشانه تازه`;
    if (!rows.length) {
      target.innerHTML = '<tr><td colspan="11" class="note">دیده‌بان هنوز فرصت ساختاریافته‌ای گزارش نکرده است؛ از نمایش امتیاز ساختگی خودداری می‌شود.</td></tr>';
      return;
    }
    const frag = document.createDocumentFragment();
    rows.slice(0,12).forEach((item,index) => {
      const tr = document.createElement('tr');
      const move = Number(item.change_24h);
      const srcCount = Array.isArray(item.sources) ? item.sources.length : Number(item.price_source_count || 0);
      const learning = item.learning || {};
      const horizons = learning.horizons || {};
      const horizonText = ['1h','4h','24h'].map(k => { const v=horizons[k]||{}; return `${k}: ${v.samples ? `${fa((v.avg_return_pct||0),2)}٪ (${fa(v.samples,0)} نمونه)` : 'در انتظار'}`; }).join(' · ');
      const brain = item.brain_prediction || {};
      const brain4h = brain.horizons?.['4h'];
      const validation4h = brain.feedback_validation?.['4h'] || {};
      const validationText = validation4h.accuracy_pct !== null && validation4h.accuracy_pct !== undefined
        ? ` | دقت قبلی ۴س: ${fa(validation4h.accuracy_pct,1)}٪ از ${fa(validation4h.directional_calls,0)} پیش‌بینی`
        : ' | سابقه دقت ۴س: نمونه کافی نیست';
      const brainText = brain.status === 'historical_analogs' && brain4h
        ? `مغز تاریخی ۴س: صعود ${fa(brain4h.up_pct,0)}٪ / نزول ${fa(brain4h.down_pct,0)}٪ (${fa(brain.analogs,0)} مشابه)${validationText}`
        : `${brain.message || 'مغز تاریخی: داده کافی نیست'}${validationText}`;
      const four = horizons['4h'] || {};
      const historyText = four.samples ? `۴س: ${fa((four.win_rate||0)*100,0)}٪ موفق · ${fa(four.fake_moves||0,0)} فیک` : 'هنوز داده کافی نیست';
      const cells = [String(index+1), `${learning.star ? '⭐ ' : ''}${safe(item.base || item.symbol)}`, phaseLabel(item), Number.isFinite(move) ? `${move>0?'+':''}${fa(move)}٪` : '—', item.volume_usd ? `$${fa(item.volume_usd,0)}` : '—', srcCount ? fa(srcCount,0) : '—', Number.isFinite(Number(item.score)) ? fa(item.score) : '—', `${item.outlook?.summary || 'سناریو در انتظار داده'} | ${horizonText} | ${brainText}`, historyText, `${(item.reasons || []).join(' · ') || 'بدون توضیح'} | ${riskLabel(item,state)}`];
      cells.forEach((value,i) => { const td=document.createElement('td'); td.textContent=value; if(i===0)td.className='radar-rank'; if(i===3)td.className='radar-move '+(move<0?'down':'up'); if(i===6)td.className='radar-score'; if(i===1 && learning.star)td.className='radar-star'; if(i===9 && /تأییدنشده|اختلاف|قدیمی|ناهم/.test(value))td.className='radar-risk'; tr.append(td); });
      const actionCell=document.createElement('td');
      const button=document.createElement('button'); button.type='button'; button.className='learn radar-action'; button.textContent='تحلیل';
      button.addEventListener('click',()=>{ const sym=item.symbol || `${item.base}USDT`; if(typeof window.analyzeTrend==='function') window.analyzeTrend(sym); else { const b=[...document.querySelectorAll('#stormList button[data-act="analyze"]')].find(x=>x.dataset.sym===sym); if(b)b.click(); }});
      actionCell.append(button); tr.append(actionCell); frag.append(tr);
    });
    target.replaceChildren(frag);
    $('radarDisclaimer').textContent = `${state.disclaimer || 'این فهرست فقط برای اولویت‌بندی بررسی است.'} موارد دارای ریسک داده باید پیش از هر تصمیمی دستی بررسی شوند.`;
  }
  document.addEventListener('tekar:scout-state', e => render(e.detail));
  document.addEventListener('DOMContentLoaded', () => { if(lastState) render(lastState); });
})();
