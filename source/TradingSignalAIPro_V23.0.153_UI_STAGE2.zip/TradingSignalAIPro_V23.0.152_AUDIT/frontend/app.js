/* Trading Signal AI Pro - Frontend logic */
const $ = id => document.getElementById(id);
const API = '';  // same origin

// V19.1: escape every untrusted string (LLM output, server errors, symbol names)
// before it is placed into innerHTML.
function esc(v){
  return String(v == null ? '' : v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// Read API responses defensively. A stale server or missing route may return
// an HTML page (often beginning with <!doctype) instead of JSON.
async function readApiJson(response){
  const raw = await response.text();
  let data;
  try { data = raw ? JSON.parse(raw) : {}; }
  catch(_){
    const contentType = response.headers.get('content-type') || 'unknown';
    throw new Error(`پاسخ API معتبر نیست (HTTP ${response.status}، ${contentType}). احتمالاً نسخه دیگری از سرور روی این آدرس اجراست یا مسیر API پیدا نشده است. صفحه را با run.bat همین پوشه اجرا کن.`);
  }
  if(!response.ok) throw new Error([data.error, data.hint].filter(Boolean).join(' — ') || `خطای سرور: HTTP ${response.status}`);
  return data;
}

let symbolsData = {crypto: [], futures: [], futures_labels: {}, commodities: [], commodity_labels: {}};
const FUT_SUFFIX = 'PERP';   // V21: BTCUSDTPERP = USDT-margined perpetual futures
const FUT_SOURCES = ['auto','binance','bybit','okx','gateio','bitget','history'];
function isFuturesSym(s){ s = String(s||'').toUpperCase(); return s.length > 8 && s.endsWith('USDT'+FUT_SUFFIX); }
function futBase(s){ return isFuturesSym(s) ? String(s).toUpperCase().slice(0, -FUT_SUFFIX.length) : s; }
function symLabel(s){ return isFuturesSym(s) ? (symbolsData.futures_labels||{})[s] || (futBase(s)+' · فیوچرز دائمی') : s; }
let learnPollTimer = null;
let lastCandles = [];
let lastEmas = {};
let lastHistory = [];
let lastProb = 0.5;
let lastThreshold = 0.6;
let lastSignal = null;
let lastAtr = 0;
let chartLayout = null;
let chartHoverIndex = -1;

/** Smart auto-scroll: only force-scroll if user is already near the bottom. */
function isNearBottom(el, threshold=90){
  if(!el) return true;
  return (el.scrollHeight - el.scrollTop - el.clientHeight) <= threshold;
}
function setLogText(el, text, forceBottom=false){
  if(!el) return;
  const stick = forceBottom || isNearBottom(el);
  el.textContent = text;
  if(stick) el.scrollTop = el.scrollHeight;
  updateScrollBtn(el);
}
function appendLogLine(el, line){
  if(!el) return;
  const stick = isNearBottom(el);
  el.textContent += (el.textContent ? '\n' : '') + line;
  if(stick) el.scrollTop = el.scrollHeight;
  updateScrollBtn(el);
}
function updateScrollBtn(el){
  if(!el) return;
  const wrap = el.closest('.log-wrap');
  if(!wrap) return;
  const btn = wrap.querySelector('.scroll-bottom-btn');
  if(!btn) return;
  btn.classList.toggle('visible', !isNearBottom(el, 60));
}
function setupSmartLogs(){
  document.querySelectorAll('.smart-log').forEach(el=>{
    el.addEventListener('scroll', ()=> updateScrollBtn(el));
  });
  document.querySelectorAll('.scroll-bottom-btn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const target = $(btn.dataset.target);
      if(target){ target.scrollTop = target.scrollHeight; updateScrollBtn(target); }
    });
  });
}

function log(msg){
  const el = $('log');
  const t = new Date().toLocaleTimeString('fa-IR');
  appendLogLine(el, `[${t}] ${msg}`);
}

// V20: full decimals — digit count adapts to the price magnitude so micro-price
// coins (e.g. 0.0000012) are no longer truncated.
function fmt(n){
  if(n == null || isNaN(n)) return '—';
  n = Number(n);
  const a = Math.abs(n);
  const max = a >= 100 ? 2 : a >= 1 ? 4 : a >= 0.01 ? 6 : 10;
  return n.toLocaleString('en-US', {minimumFractionDigits: 0, maximumFractionDigits: max});
}

function fmtCompact(n){
  n = Number(n) || 0;
  const a = Math.abs(n);
  return a >= 1e9 ? (n/1e9).toFixed(2)+'B'
       : a >= 1e6 ? (n/1e6).toFixed(1)+'M'
       : a >= 1e3 ? (n/1e3).toFixed(1)+'K'
       : n.toLocaleString('en-US', {maximumFractionDigits: 2});
}

function setStatus(text, cls=''){
  const el = $('status');
  el.textContent = text;
  el.className = 'status ' + cls;
}

// Training time estimate (matches backend: 45s + 18s per 1000 candles)
function estMinutes(n){
  const sec = 45 + n / 1000 * 18;
  return Math.max(1, Math.round(sec / 60));
}
function onSourceChange(){
  const archive = $('source').value === 'history';
  const options = [...$('learnLimit').options];
  options.forEach(o => { if(o.hasAttribute('data-history-only')) o.disabled = !archive; });
  if(!archive && +$('learnLimit').value > 10000) $('learnLimit').value = '10000';
  updateTimeEst();
}

function updateTimeEst(){
  const n = +($('learnLimit').value || 3000);
  const el = $('timeEst');
  if(el) el.textContent = `برای انتخاب فعلی (${n} کندل): حدود ${estMinutes(n)} دقیقه`;
}

// ============ Init ============
async function init(){
  pollNews(); if(newsPollTimer)clearInterval(newsPollTimer); newsPollTimer=setInterval(pollNews,60000);
  log('بارگذاری...');
  try {
    // Load symbols
    const r = await fetch(API + '/api/symbols');
    symbolsData = await r.json();
    populateSymbols();

    // Load models dir info
    await refreshModels();
    await loadStatus();

    // Wire events
    $('symbol').onchange = onSymbolChange;
    $('analyze').onclick = runAnalyze;
    $('refresh').onclick = runAnalyze;
    $('learn').onclick = () => startLearning(false);
    if($('learnQuick')) $('learnQuick').onclick = () => startLearning(true);
    $('learnCancel').onclick = cancelLearning;
    if($('learnNewAdd')) $('learnNewAdd').onclick = addNewCoinForLearning;
    if($('learnNewSymbol')) $('learnNewSymbol').addEventListener('keydown', e=>{ if(e.key==='Enter'){ e.preventDefault(); addNewCoinForLearning(); } });
    refreshLearnGate();
    $('threshold').onchange = () => { if(lastCandles.length) runAnalyze(); };
    $('learnLimit').onchange = updateTimeEst;
    $('source').onchange = onSourceChange;
    onSourceChange();
    updateTimeEst();
    $('refreshModels').onclick = refreshModels;
    $('chartRange').onchange = drawChart;
    $('chartTf').onchange = () => { $('tf').value = $('chartTf').value; runAnalyze(); };
    $('tf').onchange = () => { $('chartTf').value = $('tf').value; refreshLearnGate(); refreshAdequacy(); };
    if($('learnLimit')) $('learnLimit').addEventListener('change', refreshAdequacy);
    refreshAdequacy();
    $('chartRefresh').onclick = () => { $('tf').value = $('chartTf').value; runAnalyze(); };
    setupChartInteractions();
    // V20: trendline tool buttons
    const tdBtn = $('trendDraw'); if(tdBtn) tdBtn.onclick = toggleTrendDraw;
    const tuBtn = $('trendUndo'); if(tuBtn) tuBtn.onclick = undoLastTrendLine;
    const tcBtn = $('trendClear'); if(tcBtn) tcBtn.onclick = clearTrendLines;
    window.addEventListener('resize', () => { if(lastCandles.length) drawChart(); });
    $('tv').onclick = openTradingView;
    $('sourceHealth').onclick = checkDataSources;
    // V19: narrative report panel
    const deepBtn = $('analystDeep');
    if (deepBtn) deepBtn.onclick = requestDeepReport;
    loadAnalystStatus();
    initTrending();
    initStorm();
    $('historyStart').onclick = startHistoryBackfill;
  $('historyExport').onclick = downloadHistoryArchive;
    $('historyStop').onclick = stopHistoryBackfill;
    $('lrStart').onclick = startLongRun;
    $('lrResume').onclick = resumeLongRun;
    $('lrStop').onclick = stopLongRun;
    pollLongRun(); setInterval(pollLongRun, 3000);
    pollCoachStatus(); setInterval(pollCoachStatus, 15000);
    setupSmartLogs();
    const newsBtn = $('newsRefreshBtn');
    if(newsBtn) newsBtn.onclick = ()=> pollNews();
    $('rlTrain').onclick = startRlTraining;
    $('rlStop').onclick = stopRlTraining;
    pollRlStatus(); setInterval(pollRlStatus, 2000);
    pollHistoryStatus();
    setInterval(pollHistoryStatus, 5000);

    // Start polling learn progress
    startLearnPoll();

    onSymbolChange();
    log('منابع داده: Binance، Bybit، OKX، Gate.io، MEXC، KuCoin، Coinbase، Nobitex و CoinMarketCap (با کلید API).');
    log('برای دیدن وضعیت و خطای هر سرویس، «آزمایش منابع» را بزنید.');
    log('آماده. برای شروع، روی «یادگیری» بزنید تا مدل آموزش ببیند، بعد «تحلیل و سیگنال».');
  } catch(e){
    log('خطای راه‌اندازی: ' + e.message);
    setStatus('● خطا', 'err');
  }
}

function populateSymbols(){
  const sel = $('symbol');
  sel.innerHTML = '';
  const og1 = document.createElement('optgroup');
  og1.label = 'ارز دیجیتال';
  symbolsData.crypto.forEach(s => {
    const o = document.createElement('option');
    o.value = s; o.textContent = s;
    og1.appendChild(o);
  });
  sel.appendChild(og1);
  // V21: famous perpetual futures get their own group in the chart/analysis selector
  const ogF = document.createElement('optgroup');
  ogF.label = 'فیوچرز دائمی (مشهورها)';
  (symbolsData.futures || []).forEach(s => {
    const o = document.createElement('option');
    o.value = s; o.textContent = symLabel(s);
    ogF.appendChild(o);
  });
  if((symbolsData.futures || []).length) sel.appendChild(ogF);
  const og2 = document.createElement('optgroup');
  og2.label = 'کالا (جهانی)';
  symbolsData.commodities.forEach(s => {
    const o = document.createElement('option');
    o.value = s; o.textContent = symbolsData.commodity_labels[s] || s;
    og2.appendChild(o);
  });
  sel.appendChild(og2);
  populateLrSymbols();
}

const LR_PRESETS = {
  core5: ['BTCUSDT','ETHUSDT','SOLUSDT','BNBUSDT','XRPUSDT'],
  top12: ['BTCUSDT','ETHUSDT','SOLUSDT','BNBUSDT','XRPUSDT','ADAUSDT','DOGEUSDT','LINKUSDT','AVAXUSDT','TONUSDT','DOTUSDT','LTCUSDT'],
  top12_metals: ['BTCUSDT','ETHUSDT','SOLUSDT','BNBUSDT','XRPUSDT','ADAUSDT','DOGEUSDT','LINKUSDT','AVAXUSDT','TONUSDT','DOTUSDT','LTCUSDT','GOLD','SILVER'],
  selected7: ['BTCUSDT','XAUUSD','ETHUSDT','DOGEUSDT','ICPUSDT','LINKUSDT','SOLUSDT'],
  metals_only: ['GOLD','SILVER','XAUUSD','XAGUSD'],
  // V21: perpetual futures of famous coins (ids end with USDTPERP)
  fut5: ['BTC','ETH','SOL','BNB','XRP'].map(b=>b+'USDTPERP'),
  fut12: ['BTC','ETH','SOL','BNB','XRP','DOGE','ADA','LINK','AVAX','TON','DOT','LTC'].map(b=>b+'USDTPERP'),
};

function populateLrSymbols(){
  const box = $('lrSymbolsList');
  if(!box) return;
  box.innerHTML = '';
  const all = [
    ...(symbolsData.crypto||[]).map(s=>({id:s, label:s, group:'crypto'})),
    ...(symbolsData.futures||[]).map(s=>({id:s, label:symLabel(s), group:'futures'})),
    ...(symbolsData.commodities||[]).map(s=>({id:s, label:symbolsData.commodity_labels[s]||s, group:'metal'})),
  ];
  all.forEach(item=>{
    const lab = document.createElement('label');
    lab.className = 'lr-sym-item';
    lab.dataset.sym = item.id;
    lab.dataset.group = item.group;
    lab.innerHTML = `<input type="checkbox" class="lrSym" value="${esc(item.id)}"> <span>${esc(item.label)}</span>`;
    box.appendChild(lab);
  });
  // V20: NO default selection — the user picks symbols manually.
  // Preset buttons («۵ اصلی», «۱۲ ارز», …) stay available for one-click selection.
  updateLrSymbolsCount();
  box.querySelectorAll('.lrSym').forEach(cb=> cb.addEventListener('change', updateLrSymbolsCount));
  const search = $('lrSymbolSearch');
  if(search){
    search.oninput = ()=>{
      const q = search.value.trim().toUpperCase();
      box.querySelectorAll('.lr-sym-item').forEach(el=>{
        const show = !q || el.dataset.sym.includes(q) || (el.textContent||'').toUpperCase().includes(q);
        el.style.display = show ? '' : 'none';
      });
    };
  }
  document.querySelectorAll('.lr-preset-btn').forEach(btn=>{
    btn.onclick = ()=> applyLrPreset(btn.dataset.preset);
  });
}
function applyLrPreset(name){
  const box = $('lrSymbolsList');
  if(!box) return;
  if(name === 'clear'){
    box.querySelectorAll('.lrSym').forEach(cb=> cb.checked = false);
  } else if(name === 'all'){
    box.querySelectorAll('.lrSym').forEach(cb=> cb.checked = true);
  } else {
    const set = new Set(LR_PRESETS[name] || []);
    box.querySelectorAll('.lrSym').forEach(cb=> cb.checked = set.has(cb.value));
  }
  if(name === 'selected7'){
    // Research profile: seven requested assets, two stable starter timeframes.
    document.querySelectorAll('.lrTf').forEach(cb=>cb.checked=['1h','4h'].includes(cb.value));
    $('lrHours').value='8';
    $('lrLimit').value='10000';
    $('lrTrials').value='24';
    $('lrSummary').textContent='پروفایل ۷ دارایی آماده است: ۱ساعته + ۴ساعته · ۱۰٬۰۰۰ کندل درخواستی · ۲۴ آزمون · بودجه کل ۸ ساعت. برای شروع آموزش، ▶ شروع را بزن.';
  }
  updateLrSymbolsCount();
}
function getSelectedLrSymbols(){
  return [...document.querySelectorAll('.lrSym:checked')].map(x=>x.value);
}

// V22.7.1: one-click training academy presets (priority is guidance, not model quality).
document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('.academy-pick').forEach(btn=>btn.addEventListener('click',()=>{
    const symbol=btn.dataset.symbol, tf=btn.dataset.tf;
    if(!symbol||!tf)return;
    ensureSymbol(symbol);
    document.querySelectorAll('.lrSym').forEach(cb=>cb.checked=cb.value===symbol);
    document.querySelectorAll('.lrTf').forEach(cb=>cb.checked=cb.value===tf);
    $('lrLimit').value='10000'; $('lrTrials').value='24'; $('lrHours').value='4';
    updateLrSymbolsCount();
    $('lrSummary').textContent=`آماده آموزش: ${symbol} · ${tf} · ۱۰٬۰۰۰ کندل درخواستی · ۲۴ آزمون · بودجه کل ۴ ساعت. برای اجرا «شروع» را بزن.`;
    $('longrunPanel').scrollIntoView({behavior:'smooth',block:'start'});
  }));
});
function updateLrSymbolsCount(){
  const n = getSelectedLrSymbols().length;
  const el = $('lrSymbolsCount');
  if(el) el.textContent = n ? `${n} نماد انتخاب شده` : 'هیچ نمادی انتخاب نشده — حداقل یکی را تیک بزن';
  if(typeof refreshLearnGate === 'function') refreshLearnGate();
}

async function checkDataSources(){
  const symbol = $('symbol').value;
  const timeframe = $('tf').value;
  const btn = $('sourceHealth');
  btn.disabled = true;
  btn.textContent = 'در حال آزمایش...';
  log(`آزمایش منابع برای ${symbol} ${timeframe} ...`);
  try {
    const response = await fetch(`${API}/api/data/health?symbol=${encodeURIComponent(symbol)}&timeframe=${encodeURIComponent(timeframe)}`);
    const data = await response.json();
    if(!response.ok) throw new Error(data.error || 'خطای بررسی منابع');
    (data.results || []).forEach(item => {
      const status = item.skipped ? 'تنظیم نشده' : item.ok ? `OK (${item.candles} کندل، ${item.latency_ms}ms)` : `ناموفق: ${item.error || 'داده کافی نیست'}`;
      log(`${item.label || item.source}: ${status}`);
    });
    const good = (data.results || []).filter(x => x.ok).length;
    setStatus(`● ${good} منبع سالم`, good ? 'ok' : 'err');
  } catch(error){
    log('خطای آزمایش منابع: ' + error.message);
    setStatus('● خطا در بررسی منابع', 'err');
  } finally {
    btn.disabled = false;
    btn.textContent = 'آزمایش منابع';
  }
}

function onSymbolChange(){
  pollNews();
  refreshLearnGate();
  const sym = $('symbol').value;
  const isC = symbolsData.commodities.includes(sym);
  $('source').disabled = false;
  // V21: futures only work with futures-capable feeds; pick auto if the current one cannot serve them
  if(isFuturesSym(sym) && !FUT_SOURCES.includes($('source').value)){ $('source').value = 'auto'; }
  if(isC && !['yahoo','tradingview'].includes($('source').value)) $('source').value = 'yahoo';
  else if(!isC && $('source').value === 'yahoo') $('source').value = 'auto';
}

function openTradingView(){
  const sym = $('symbol').value;
  let tv = isFuturesSym(sym) ? 'BINANCE:' + futBase(sym) + '.P' : 'BINANCE:' + sym;
  if(sym === 'XAUUSD') tv = 'OANDA:XAUUSD';
  else if(sym === 'XAGUSD') tv = 'OANDA:XAGUSD';
  else if(sym === 'WTI') tv = 'NYMEX:CL1!';
  else if(sym === 'BRENT') tv = 'NYMEX:BZ1!';
  window.open('https://www.tradingview.com/chart/?symbol=' + encodeURIComponent(tv), '_blank', 'noopener');
}

// ============ Status / Models dir ============
async function loadStatus(){
  try {
    const r = await fetch(API + '/api/status');
    const d = await r.json();
    const dirEl = $('modelsDir');
    if(dirEl) dirEl.textContent = d.models_dir || '~/.trading_ai_models/';
    return d;
  } catch(e){
    return null;
  }
}

async function refreshModels(){
  try {
    const r = await fetch(API + '/api/models');
    if(!r.ok) throw new Error('HTTP ' + r.status);
    const d = await r.json();
    renderModelsList(d.models || []);
    try {
      const info = await (await fetch(API + '/api/models/info')).json();
      const dirEl = $('modelsDir');
      if(dirEl && info.path) dirEl.textContent = info.path;
      else if($('modelsList') && info.path){
        // show path near the list when dedicated element is missing
        const pathNote = $('modelsPathNote');
        if(pathNote) pathNote.textContent = info.path;
      }
    } catch(_){ /* path info is optional */ }
  } catch(e){
    const el = $('modelsList');
    if(el) el.innerHTML = '<span class="note">خطا در بارگذاری لیست مدل‌ها: ' + esc(e.message||'') + '</span>';
  }
}

function renderModelsList(models){
  const el = $('modelsList');
  if(!models.length){
    el.innerHTML = '<span class="note">هنوز مدلی ذخیره نشده. روی «یادگیری» بزنید.</span>';
    return;
  }
  el.innerHTML = models.map(m => `
    <div class="model-row">
      <span><span class="name">${esc(m.symbol)} · ${esc(m.timeframe)}</span> —
      ذخیره: ${esc(m.saved_at)} —
      نمونه: ${m.train_samples} —
      ویژگی: ${m.feature_count}</span>
      <span>
        <span class="acc">دقت: ${((m.val_acc||0)*100).toFixed(1)}%</span>
        <span class="acc">WF: ${((m.walk_forward_acc||0)*100).toFixed(1)}%</span>
        <button class="del" data-s="${esc(m.symbol)}" data-t="${esc(m.timeframe)}">حذف</button>
      </span>
    </div>
  `).join('');
  el.querySelectorAll('.del').forEach(b => {
    b.onclick = async () => {
      if(!confirm(`مدل ${b.dataset.s} ${b.dataset.t} پاک شود؟`)) return;
      await fetch(`${API}/api/models/${b.dataset.s}/${b.dataset.t}`, {method:'DELETE'});
      refreshModels();
    };
  });
}


// ============ Historical archive ============
async function pollHistoryStatus(){
  try{
    const r=await fetch(API+'/api/history/status'); const d=await readApiJson(r);
    $('historyStatus').textContent=d.running?'در حال دریافت…':(d.message||'آماده');
    const active = d.symbol ? `${d.symbol} ${d.timeframe||''} · ` : '';
    const error = d.last_error ? ` · آخرین خطا: ${d.last_error}` : '';
    $('historyInfo').textContent=`${active}کل آرشیو: ${(d.total_candles||0).toLocaleString('en-US')} کندل | این اجرا: ${(d.downloaded||0).toLocaleString('en-US')} | صفحات: ${(d.total_requests||0)} | ${d.db_path||''}${error}`;
    $('historyStart').disabled=!!d.running; $('historyStop').disabled=!d.running;
    if(d.last_error) $('historyStatus').title=d.last_error;
  }catch(e){ $('historyInfo').textContent='وضعیت آرشیو در دسترس نیست: '+e.message; }
}
function stormArchiveSymbols(){
  const st=stormLastData||{};
  const items=[...(st.early||[]),...(st.alerts||[]),...(st.watch||[])];
  return [...new Set(items.map(x=>String(x.base||'').toUpperCase().trim())
    .filter(x=>/^[A-Z0-9]{2,15}$/.test(x)).map(x=>x.endsWith('USDT')?x:x+'USDT'))];
}
async function startHistoryBackfill(){
  const scope=$('historyScope')?.value||'selected';
  const core=['BTCUSDT','ETHUSDT','SOLUSDT','BNBUSDT','XRPUSDT','DOGEUSDT','ADAUSDT','LINKUSDT','AVAXUSDT','TONUSDT',
              'ICPUSDT','TRXUSDT','DOTUSDT','LTCUSDT','NEARUSDT','APTUSDT','ARBUSDT','OPUSDT','INJUSDT','ETCUSDT'];
  let symbols=[];
  if(scope==='storm') symbols=stormArchiveSymbols();
  else if(scope==='core') symbols=core;
  else if(scope==='all_usdt') symbols=['ALL_USDT'];
  else {
    let symbol=String($('symbol').value||'').toUpperCase();
    if(isFuturesSym(symbol)){alert('آرشیو فعلی فقط بازار نقدی USDT بایننس را ذخیره می‌کند؛ نماد فیوچرز را انتخاب نکن.');return;}
    symbols=[symbol];
  }
  if(!symbols.length){alert('فهرست ارزهای طوفان خالی است؛ ابتدا دیده‌بان طوفان را تازه‌سازی کن.');return;}
  const timeframes=[...document.querySelectorAll('.history-tf:checked')].map(x=>x.value);
  if(!timeframes.length){alert('حداقل یک تایم‌فریم برای آرشیو انتخاب کن.');return;}
  const startDate=$('historyStartDate')?.value||'2021-01-01';
  const start=new Date(`${startDate}T00:00:00Z`).toISOString();
  const summary=scope==='all_usdt'?'تمام بازارهای نقدی USDT بایننس':`${symbols.length} نماد`;
  if(!confirm(`دریافت آرشیو شروع شود؟\n\n${summary}\nتایم‌فریم‌ها: ${timeframes.join('، ')}\nشروع از: ${startDate}\n\nداده‌ها روی دیسک ذخیره می‌شوند؛ برای گرفتن فایل ZIP از دکمه «دانلود آرشیو کامل» استفاده کن.`))return;
  $('historyStart').disabled=true;
  try{
    const r=await fetch(API+'/api/history/backfill',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({symbols,timeframes,start})});
    const d=await readApiJson(r);
    log(`آرشیو شروع شد: ${summary} · ${timeframes.join('/')}؛ پیشرفت را در پنل آرشیو ببین.`);
  }catch(e){log('خطای آرشیو: '+e.message);}finally{pollHistoryStatus();}
}
async function downloadHistoryArchive(){
  const button=$('historyExport'), info=$('historyExportInfo');
  button.disabled=true; info.textContent='در حال تهیهٔ نسخهٔ پشتیبان از کل آرشیو محلی…';
  try{
    const response=await fetch(API+'/api/history/export');
    if(!response.ok){let d={};try{d=await response.json();}catch(_){}throw new Error(d.error||`خطای دریافت فایل (HTTP ${response.status})`);}
    const blob=await response.blob();
    if(!blob.size) throw new Error('فایل آرشیو خالی دریافت شد.');
    const url=URL.createObjectURL(blob), a=document.createElement('a');
    a.href=url; a.download='TradingSignalAIPro_History_Archive.zip';
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),30000);
    const count=response.headers.get('X-Archive-Candles')||'—';
    const markets=response.headers.get('X-Archive-Markets')||'—';
    info.textContent=`فایل ZIP آماده شد · ${blob.size.toLocaleString('en-US')} بایت · ${Number(count).toLocaleString('en-US')} کندل · ${markets} ترکیب نماد/تایم‌فریم. اگر فایل کوچک است، یعنی همین مقدار داده در آرشیو ذخیره شده؛ ابتدا گسترهٔ دریافت را افزایش بده.`;
  }catch(e){info.textContent='دانلود آرشیو انجام نشد: '+e.message;}
  finally{button.disabled=false;}
}
async function stopHistoryBackfill(){
  try{await fetch(API+'/api/history/stop',{method:'POST'});log('درخواست توقف آرشیو ارسال شد.');}
  catch(e){log('توقف آرشیو ناموفق بود: '+e.message);}pollHistoryStatus();
}

// ============ V21: data adequacy note under the candle selector ============
async function refreshAdequacy(){
  const el = $('learnAdequacy'); if(!el) return;
  const limit = $('learnLimit') ? $('learnLimit').value : 10000;
  try{
    const r = await fetch(API + '/api/learn/adequacy?limit=' + encodeURIComponent(limit) + '&timeframe=' + encodeURIComponent($('tf').value));
    if(!r.ok) return;
    const d = await r.json();
    el.textContent = `📊 ≈ ${Math.round(d.days)} روز داده · نمونه‌ی مستقل ≈ ${d.effective_samples} (${d.level_fa})` + (d.notes.length ? ' — ' + d.notes[0] : '');
    el.className = 'note ' + (d.level === 'weak' || d.level === 'medium' ? 'warn' : 'ok');
  }catch(_){}
}

// ============ V21: single learning = NEW coin only ============
let learnBlocked = false;
let learnSeedInfo = null;      // V21: suggestion for ⚡ quick transfer training
let _gateSeq = 0;
async function refreshLearnGate(){
  const seq = ++_gateSeq;
  const symEl = $('symbol'); const btn = $('learn'); const note = $('learnGateNote');
  if(!symEl || !btn) return;
  const sym = symEl.value;
  const localOwned = getSelectedLrSymbols().includes(sym);       // ticked in multi-hour list
  let serverOwned = false;                                        // running / recent multi-hour run
  try{
    const r = await fetch(API + '/api/learn/eligibility?symbol=' + encodeURIComponent(sym));
    if(r.ok) serverOwned = !!(await r.json()).in_multihour;
  }catch(_){}
  if(seq !== _gateSeq) return;                                    // a newer check superseded this one
  learnBlocked = localOwned || serverOwned;
  const running = $('learnStatus') && $('learnStatus').classList.contains('running');
  btn.disabled = learnBlocked || running;
  btn.title = learnBlocked ? 'این ارز در آموزش چندساعته است' : 'یادگیری تکی برای ارز جدید';
  // V21: can a neighbour's model warm-start this (untrained) market?
  learnSeedInfo = null;
  const qb = $('learnQuick');
  if(qb && !learnBlocked){
    try{
      const rs = await fetch(API + '/api/learn/seed?symbol=' + encodeURIComponent(sym) + '&timeframe=' + encodeURIComponent($('tf').value));
      if(rs.ok) learnSeedInfo = await rs.json();
    }catch(_){}
    if(seq !== _gateSeq) return;
  }
  if(qb){
    const okSeed = !!(learnSeedInfo && learnSeedInfo.available);
    qb.disabled = learnBlocked || running || !okSeed;
    qb.title = okSeed ? `شروع از مدل ${learnSeedInfo.seed.symbol}/${learnSeedInfo.seed.timeframe}`
      : (learnSeedInfo && learnSeedInfo.has_own_model ? 'این ارز مدل اختصاصی دارد' : 'مدل مبدأ سازگاری موجود نیست');
  }
  if(note){
    note.textContent = learnBlocked
      ? `⛔ ${symLabel(sym)} در آموزش چندساعته است؛ یادگیری تکی برای آن غیرفعال است. (ارز جدید را بالا وارد کن یا تیکش را از فهرست چندساعته بردار)`
      : ('✅ این ارز در فهرست چندساعته نیست؛ یادگیری تکی مجاز است.'
         + (learnSeedInfo && learnSeedInfo.available ? ` ⚡ آموزش سریع ممکن است (شروع از ${learnSeedInfo.seed.symbol}/${learnSeedInfo.seed.timeframe}).` : ''));
    note.className = 'note ' + (learnBlocked ? 'warn' : 'ok');
  }
}
function addNewCoinForLearning(){
  const inp = $('learnNewSymbol'); if(!inp) return;
  let sym = String(inp.value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if(!sym){ log('نماد ارز جدید را وارد کن (مثل PEPEUSDT).'); return; }
  if(!isFuturesSym(sym) && !sym.endsWith('USDT')) sym += 'USDT';
  if(!/^[A-Z0-9]{3,20}$/.test(sym)){ log('نماد نامعتبر است.'); return; }
  ensureSymbol(sym);
  $('symbol').value = sym;
  inp.value = '';
  onSymbolChange();
  log(`ارز جدید انتخاب شد: ${sym} — حالا «یادگیری» را بزن.`);
}

// ============ Learning ============
async function startLearning(quick){
  quick = quick === true;                         // V21: ⚡ transfer training from a neighbour's model
  const symbol = $('symbol').value;
  // V21: single learning is only for a NEW coin; multi-hour owns every coin in its list.
  await refreshLearnGate();
  if(learnBlocked){
    log(`⛔ ${symbol} در آموزش چندساعته است؛ یادگیری تکی فقط برای ارز جدید است.`);
    return;
  }
  const timeframe = $('tf').value;
  const limit = $('learnLimit').value;
  const source = $('source').value;
  let trials = 8; // fallback if status endpoint is temporarily unavailable
  try {
    const statusRes = await fetch(API + '/api/status');
    if (statusRes.ok) { const statusData = await statusRes.json(); trials = Number(statusData.hp_trials) || trials; }
  } catch (_) {}
  const mins = estMinutes(+limit);

  if(quick){
    const sd = learnSeedInfo && learnSeedInfo.seed;
    if(!sd){ log('مدل مبدأ سازگاری پیدا نشد؛ یادگیری عادی را بزن.'); return; }
    if(!confirm(`⚡ آموزش سریع با انتقال یادگیری؟\n\nدارایی: ${symbol} (${timeframe})\nشروع از مدل: ${sd.symbol}/${sd.timeframe}\nکندل: ${limit}\n\nفقط ۲ آزمون و ۲ فولد انجام می‌شود؛ خیلی سریع‌تر است ولی دقیق‌تر از آموزش کامل نیست. بعداً می‌توانی آموزش کامل را هم بزنی.`)) return;
  } else if(!confirm(`آموزش شروع شود؟\n\nدارایی: ${symbol}\nتایم‌فریم: ${timeframe}\nکندل: ${limit}\nمنبع: ${source}\nآزمون: ${trials} پیکربندی\n\n⏱ زمان تقریبی: حدود ${mins} دقیقه (به کابل شبکه/اینترنت و سرعت سیستم بستگی دارد)\nمدل قبلی اگر وجود داشته باشد، ادامه داده می‌شود (دور بعد).`)) return;

  $('learn').disabled = true;
  if($('learnQuick')) $('learnQuick').disabled = true;
  $('learnCancel').disabled = false;
  $('learnStatus').textContent = 'در حال آموزش...';
  $('learnStatus').className = 'learn-status running';
  setLogText($('learnLog'), 'شروع آموزش...', true);
  $('learnProgressBar').style.width = '0%';

  try {
    const r = await fetch(API + '/api/learn', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({symbol, timeframe, limit: +limit, source, seed: quick ? 'auto' : undefined})
    });
    const d = await r.json();
    if(!r.ok){
      throw new Error(d.error || 'خطا در شروع آموزش');
    }
    log(quick ? `⚡ آموزش سریع شروع شد: ${symbol} ${timeframe} ← از ${d.seed_from}` : `آموزش شروع شد: ${symbol} ${timeframe}`);
  } catch(e){
    $('learnStatus').textContent = 'خطا';
    $('learnStatus').className = 'learn-status error';
    setLogText($('learnLog'), 'خطا: ' + e.message, true);
    $('learn').disabled = !!learnBlocked;
    $('learnCancel').disabled = true;
    refreshLearnGate();
  }
}

async function cancelLearning(){
  await fetch(API + '/api/learn/cancel', {method:'POST'});
  log('درخواست توقف آموزش ارسال شد.');
}

function startLearnPoll(){
  if(learnPollTimer) return;
  learnPollTimer = setInterval(pollLearnProgress, 800);
}

async function pollLearnProgress(){
  try {
    const r = await fetch(API + '/api/learn/progress');
    const d = await r.json();
    if(d.log && d.log.length){
      setLogText($('learnLog'), d.log.join('\n'));
    }
    // Update progress bar based on log content (9 steps)
    const txt = (d.log || []).join('\n');
    let pct = 0;
    if(/۱\.|دریافت/.test(txt)) pct = 5;
    if(/۲\.|ویژگی/.test(txt)) pct = 12;
    if(/۳\.|تقسیم/.test(txt)) pct = 18;
    if(/۴\.|انتخاب/.test(txt)) pct = 22;
    // Trainer logs completed trials as [done/total]; avoid hard-coding grid size.
    const trialProgress = [...txt.matchAll(/\[(\d+)\s*\/\s*(\d+)\]/g)];
    if(trialProgress.length){
      const last = trialProgress[trialProgress.length-1];
      const done = Number(last[1]), total = Math.max(1, Number(last[2]));
      pct = 25 + Math.min(1, done / total) * 48;
    }
    if(/walk-forward/.test(txt)) pct = 78;
    if(/آموزش نهایی|Seed-Ensemble|کالیبراسیون/.test(txt)) pct = 88;
    if(/۸\.|آستانه بهینه/.test(txt)) pct = 94;
    if(/۹\.|ذخیره/.test(txt)) pct = 98;
    if(d.last_result) pct = 100;
    $('learnProgressBar').style.width = pct + '%';

    if(!d.running && d.last_result){
      // Training done
      const meta = d.last_result.meta || {};
      const uh = meta.ultra_high_conf_acc || 0;
      $('learn').disabled = !!learnBlocked;
      refreshLearnGate();
      $('learnCancel').disabled = true;
      let done = `✓ کامل شد · دقت: ${((meta.val_acc||0)*100).toFixed(1)}%`;
      // V21 fix: when the champion gate kept the old model, say so (the numbers shown are the challenger's)
      if(meta.sim_test_ci) done += ` · برد تست ${(meta.sim_test_ci.low*100).toFixed(0)}–${(meta.sim_test_ci.high*100).toFixed(0)}٪ (۹۵٪، ${meta.sim_test_ci.n} معامله)`;
      if(meta.promoted === false) done = `⏭ مدل قبلی حفظ شد (مدل جدید بهتر نبود) · دقت مدل جدید: ${((meta.val_acc||0)*100).toFixed(1)}%`;
      if(uh > 0) done += ` · دقت ۸۵٪+ : ${(uh*100).toFixed(1)}%`;
      if(meta.training_time_sec) done += ` · ${Math.round(meta.training_time_sec/60)} دقیقه`;
      $('learnStatus').textContent = done;
      $('learnStatus').className = 'learn-status done';
      renderTrials(d.last_result.trial_results || []);
      refreshModels();
      log(`آموزش کامل شد در ${Math.round((meta.training_time_sec||0)/60)} دقیقه. دقت تست: ${((meta.val_acc||0)*100).toFixed(1)}% | اطمینان ۸۵٪+: ${((meta.ultra_high_conf_acc||0)*100).toFixed(1)}%`);
    } else if(!d.running && !d.last_result && $('learnStatus').classList.contains('running')){
      $('learn').disabled = !!learnBlocked;
      refreshLearnGate();
      $('learnCancel').disabled = true;
      $('learnStatus').textContent = 'متوقف شد';
      $('learnStatus').className = 'learn-status error';
    }
  } catch(e){
    // ignore
  }
}

function renderTrials(trials){
  const tb = $('trialsTable').querySelector('tbody');
  if(!trials.length){
    tb.innerHTML = '<tr><td colspan="7" class="note">آزمونی ثبت نشد.</td></tr>';
    return;
  }
  let bestIdx = 0, bestScore = -1;
  trials.forEach((t,i) => {
    const simBonus = (t.sim_trades_60 >= 10) ? 0.6*((t.sim_win_rate_60||0.5)-0.5) : 0;
    const score = (t.val_acc||0)
      + 0.25 * ((t.val_high_conf_acc||0) - (t.val_acc||0)) * (t.val_high_conf_cov||0)
      + 0.40 * ((t.val_very_high_conf_acc||0) - (t.val_acc||0)) * (t.val_very_high_conf_cov||0)
      + 0.55 * ((t.val_ultra_conf_acc||0) - (t.val_acc||0)) * (t.val_ultra_conf_cov||0)
      + simBonus;
    if(score > bestScore){ bestScore = score; bestIdx = i; }
  });
  tb.innerHTML = trials.map((t,i) => `
    <tr class="${i === bestIdx ? 'best' : ''}">
      <td>${i+1}${i === bestIdx ? ' ★' : ''}</td>
      <td>${((t.val_acc||0)*100).toFixed(1)}%</td>
      <td>${((t.val_high_conf_acc||0)*100).toFixed(1)}%</td>
      <td>${((t.val_very_high_conf_acc||0)*100).toFixed(1)}%</td>
      <td>${((t.val_ultra_conf_acc||0)*100).toFixed(1)}%</td>
      <td>${t.sim_win_rate_60 != null ? ((t.sim_win_rate_60)*100).toFixed(1)+'% ('+(t.sim_trades_60||0)+')' : '—'}</td>
      <td>${(t.time_sec||0).toFixed(1)}s</td>
    </tr>
  `).join('');
}

// ============ One-button multi-hour training ============
function fmtDur(sec){ sec=Math.max(0,Math.floor(sec||0)); const h=Math.floor(sec/3600), m=Math.floor(sec%3600/60); return h? `${h} ساعت و ${m} دقیقه` : `${m} دقیقه`; }
async function startLongRun(){
  const tfs=[...document.querySelectorAll('.lrTf:checked')].map(x=>x.value);
  if(!tfs.length){ $('lrSummary').textContent='حداقل یک تایم‌فریم انتخاب کن.'; return; }
  const symbols = getSelectedLrSymbols();
  if(!symbols.length){ $('lrSummary').textContent='حداقل یک نماد (ارز یا طلا) را انتخاب کن.'; return; }
  const body={hours:+$('lrHours').value, symbols, timeframes:tfs, limit:+$('lrLimit').value, trials:+$('lrTrials').value};
  if(!confirm(`آموزش خودکار برای ${body.hours} ساعت شروع شود؟\n${symbols.length} نماد × ${tfs.length} تایم‌فریم\nبرنامه و اینترنت را باز نگه دار. می‌توانی هر لحظه توقف بزنی.\nاگر اجرای نیمه‌کاره‌ای داری، در عوض دکمه‌ی «ادامه‌ی آموزش نیمه‌کاره» را بزن.`)) return;
  $('lrStart').disabled=true;
  try{
    const r=await fetch(API+'/api/longrun/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const d=await r.json(); if(!r.ok) throw new Error(d.error||'شروع نشد');
    log('آموزش چندساعته شروع شد با ' + symbols.length + ' نماد.'); pollLongRun();
  }catch(e){ $('lrSummary').textContent='خطا: '+e.message; $('lrStart').disabled=false; }
}
async function resumeLongRun(){
  const tfs=[...document.querySelectorAll('.lrTf:checked')].map(x=>x.value);
  const symbols = getSelectedLrSymbols();
  const body={hours:+$('lrHours').value, timeframes:tfs, limit:+$('lrLimit').value, trials:+$('lrTrials').value};
  if(symbols.length) body.symbols = symbols;
  if(!confirm('ادامه‌ی اجرای نیمه‌کاره؟\nدورهای انجام‌شده و بودجه‌ی زمانی باقی‌مانده بازیابی می‌شود و آموزش از همان‌جا ادامه پیدا می‌کند.')) return;
  $('lrResume').disabled=true;
  try{
    const r=await fetch(API+'/api/longrun/resume',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const d=await r.json(); if(!r.ok) throw new Error(d.error||'ادامه دادن شروع نشد');
    log('ادامه‌ی آموزش نیمه‌کاره شروع شد؛ پیشرفت قبلی بازیابی شد.'); pollLongRun();
  }catch(e){ $('lrSummary').textContent='خطا: '+e.message; }
}
async function stopLongRun(){
  await fetch(API+'/api/longrun/stop',{method:'POST'}); $('lrSummary').textContent='درخواست توقف ارسال شد؛ دور جاری قطع می‌شود...';
}
async function pollLongRun(){
  try{
    const r=await fetch(API+'/api/longrun/status'); if(!r.ok) return; const d=await r.json();
    const running=!!d.running;
    if(window._lrWasRunning !== running){ window._lrWasRunning = running; refreshLearnGate(); }
    $('lrStart').disabled=running; $('lrStop').disabled=!running;
    $('lrStatus').textContent=running?'در حال آموزش':(d.phase==='finished'?'تمام شد':d.phase==='stopped'?'متوقف شد':d.phase==='interrupted'?'نیمه‌کاره — قابل ادامه':'آماده');
    // resume button: enabled when not running and a resumable previous run exists
    let resInfo=d.resumable_info||null;
    if(!running && !resInfo){
      try{ const rr=await fetch(API+'/api/longrun/resumable'); if(rr.ok) resInfo=await rr.json(); }catch(_){}
    }
    $('lrResume').disabled=running||!(resInfo&&resInfo.resumable);
    if(resInfo&&resInfo.resumable){
      $('lrResumeInfo').textContent=`↩ اجرای قابل ادامه: ${resInfo.jobs_done}/${resInfo.jobs_total} کار، ${resInfo.trainings_done||0} آموزش انجام‌شده`+(resInfo.remaining_sec>0?` | حدود ${fmtDur(resInfo.remaining_sec)} از بودجه‌ی زمانی مانده`: ' | بودجه‌ی زمانی تمام شده (پیشرفت حفظ می‌شود و پنجره‌ی جدید باز می‌شود)');
    } else { $('lrResumeInfo').textContent=''; }
    const total=(d.hours||0)*3600;
    $('lrBar').style.width=(running&&total? Math.min(100,(d.elapsed_sec||0)/total*100):(d.phase==='finished'?100:0))+'%';
    const cur=d.current?` | الان: ${d.current.symbol} ${d.current.timeframe} (دور ${d.current.round}، ${d.current.stage==='data'?'دریافت داده':'آموزش'})`:'';
    const resumed=d.resumed_from?` | بازیابی‌شده: ${d.resumed_from.trainings_done} آموزش قبلی`:'';
    $('lrSummary').textContent=(d.started_at? `${d.message||''}${running?` | باقی‌مانده: ${fmtDur(d.remaining_sec)}`:''}${resumed} | آموزش‌ها: ${d.trainings_done||0} · جایگزین‌شده: ${d.promoted||0} · مدل قبلی نگه‌داشته: ${d.kept_old||0} · ناموفق: ${d.failed||0}${cur}`:'هنوز اجرا نشده');
    const tb=$('lrJobs'); tb.textContent='';
    (d.jobs||[]).forEach(j=>{
      const tr=document.createElement('tr'); tr.className=j.status||'';
      const st={queued:'در صف',running:'در حال آموزش',trained:'آموزش دیده',dropped:'موقتاً کنار (بعداً دوباره امتحان می‌شود)'}[j.status]||j.status;
      const acc=j.last&&j.last.balanced_acc!=null? (j.last.balanced_acc*100).toFixed(1)+'٪':'—';
      const edge=j.last? (j.last.edge_confirmed?'تأیید ✓':'ندارد'):'—';
      [j.symbol,j.timeframe,j.rounds,st,acc,edge].forEach(v=>{const td=document.createElement('td'); td.textContent=String(v); tr.appendChild(td);});
      tb.appendChild(tr);
    });
    if(d.log&&d.log.length){ setLogText($('lrLog'), d.log.join('\n')); }
    if(d.coach_log&&d.coach_log.length){
      setLogText($('coachLog'), d.coach_log.map(c=>{
        const t=new Date((c.ts||0)*1000).toLocaleTimeString('fa-IR');
        return `[${t}] ${c.symbol} ${c.timeframe} — ${(c.assessment_fa||'')}${c.advice_fa?' | '+c.advice_fa:''}${c.hp_hints?' | تنظیم پیشنهادی دور بعد ثبت شد':''}`;
      }).join('\n'));
    }
  }catch(_){}
}

// ============ AI coach status ============
async function pollCoachStatus(){
  try{
    const r=await fetch(API+'/api/ai/coach'); if(!r.ok) return; const d=await r.json();
    if(d.available){ $('coachStatus').textContent=`✓ فعال است — مدل: ${d.model} (${d.provider==='zai_glm'?'Z.ai GLM':'سازگار با OpenAI'}). پس از هر دور آموزش، خلاصه ارسال و از تاریخچه آموزش‌های قبلی برای راهنمایی دور بعد استفاده می‌شود.`; }
    else { $('coachStatus').textContent='فعال نیست: '+ (d.note||'کلید API تنظیم نشده است. آموزش بدون مربی هم درست کار می‌کند.'); }
    if(d.recent&&d.recent.length&&!$('coachLog').textContent.includes('[')){
      setLogText($('coachLog'), d.recent.map(c=>`${c.symbol} ${c.timeframe} — ${(c.assessment_fa||'')}`).join('\n'));
    }
  }catch(_){}
}

// ============ V14 FinRL-compatible DRL ============
async function startRlTraining(){
  const symbol=$('symbol').value, timeframe=$('tf').value;
  const limit=+$('rlLimit').value, timesteps=+$('rlSteps').value;
  if($('source').value!=='history' && limit>10000){alert('برای بیش از ۱۰هزار کندل، منبع را روی آرشیو تاریخی محلی بگذار.');return;}
  if(!confirm(`آموزش ترتیبی پنج عامل DRL شروع شود؟\n${symbol} · ${timeframe} · ${limit} کندل · ${timesteps.toLocaleString('en-US')} گام برای هر عامل\nاین کار ممکن است طولانی و پرمصرف باشد.`)) return;
  $('rlTrain').disabled=true; $('rlStop').disabled=false; $('rlStatus').textContent='در حال دریافت داده و آموزش';
  $('rlLog').textContent='درخواست آموزش ارسال شد...'; $('rlProgressBar').style.width='0%';
  try{
    const r=await fetch(API+'/api/rl/train',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({symbol,timeframe,limit,timesteps,source:$('source').value,fee_bps:+$('rlFee').value,slippage_bps:+$('rlSlip').value})});
    const d=await readApiJson(r);
    log(`آموزش DRL برای ${symbol} ${timeframe} آغاز شد.`);
  }catch(e){$('rlStatus').textContent='خطا';$('rlSummary').textContent=e.message;$('rlTrain').disabled=false;$('rlStop').disabled=true;}
}
async function stopRlTraining(){
  const r=await fetch(API+'/api/rl/stop',{method:'POST'}); await readApiJson(r); $('rlStatus').textContent='درخواست توقف ارسال شد'; log('درخواست توقف DRL ارسال شد.');
}
async function pollRlStatus(){
  try{
    const r=await fetch(API+'/api/rl/status'); const d=await readApiJson(r);
    $('rlStatus').textContent=d.running?'در حال آموزش':d.stage==='complete'?'آموزش کامل شد':d.stage==='error'?'خطا':'آماده';
    $('rlTrain').disabled=!!d.running; $('rlStop').disabled=!d.running;
    $('rlProgressBar').style.width=(d.progress||0)+'%';
    if(d.log&&d.log.length){setLogText($('rlLog'), d.log.join('\n'));}
    if(d.result){
      const a=d.result.algorithms||{};
      $('rlSummary').textContent=`عامل منتخب: ${d.result.selected_algorithm||'هیچ‌کدام واجد شرایط نشدند'} · `+
        Object.entries(a).map(([k,v])=>`${k}: اعتبارسنجی ${Number(v.validation.net_return_pct).toFixed(2)}%، تست ${Number(v.test.net_return_pct).toFixed(2)}%، افت تست ${Number(v.test.max_drawdown_pct).toFixed(2)}%`).join(' | ');
    }
    if(d.error)$('rlSummary').textContent='خطا: '+d.error;
  }catch(_){}
}

// ============ Independent chart data + analysis ============
// A model/data-quality error must not hide valid market candles. Chart-only
// retrieval runs only when the signal pipeline fails, and is explicitly
// labelled as a visual/research view (not a trade-ready signal).
async function loadChartOnly(symbol, timeframe, source, limit){
  const host = $('tvChart');
  const params = new URLSearchParams({
    symbol: String(symbol || 'BTCUSDT'),
    timeframe: String(timeframe || '1h'),
    source: String(source || 'auto'),
    limit: String(limit || 1500),
  });
  try{
    const response = await fetch(`${API}/api/chart?${params.toString()}`);
    const d = await readApiJson(response);
    if(!Array.isArray(d.candles) || !d.candles.length){
      throw new Error('داده کندلی برای رسم نمودار دریافت نشد.');
    }
    lastCandles = d.candles;
    lastEmas = {};
    lastHistory = [];
    lastSignal = null;
    lastProb = 0.5;
    lastAtr = 0;

    const shown = Math.min(lastCandles.length, Number($('chartRange')?.value || 100));
    if($('chartSubtitle')){
      $('chartSubtitle').textContent = `${d.symbol} · ${d.timeframe} · نمایش ${shown} کندل از ${d.candle_count} · نمودار مستقل از مدل`;
    }
    if($('chartFootnote')){
      const status = String(d.data_quality?.status || 'UNKNOWN').toUpperCase();
      const cached = d.source === 'cache';
      $('chartFootnote').textContent = (cached || status !== 'PASS')
        ? `⚠ نمودار برای مشاهده بازار است؛ کیفیت داده ${status} و منبع ${d.source_label || d.source}. این داده به‌تنهایی مجوز صدور سیگنال نیست.`
        : `نمودار مستقل دریافت شد · ${d.source_label || d.source} · بدون وابستگی به مدل آموزش‌دیده`;
    }
    drawChart();
    updateChartSigOverlay();
    log(`📊 نمودار مستقل بارگذاری شد: ${d.symbol} ${d.timeframe} · ${d.candle_count} کندل · منبع ${d.source_label || d.source}`);
    if(d.source_chain?.length){
      log('زنجیره منابع نمودار: ' + d.source_chain.map(x=>`${x.label}: ناموفق`).join(' ← '));
    }
    if(d.hint) log(d.hint);
    return true;
  }catch(error){
    lastCandles = [];
    lastHistory = [];
    lastSignal = null;
    if(host){
      destroyTvChart();
      host.innerHTML = `<div class="note" style="padding:20px">نمودار دریافت نشد: ${esc(error.message)}<br>دکمه «منابع» را برای بررسی اتصال صرافی‌ها بزن.</div>`;
    }
    log('✖ دریافت مستقل نمودار ناموفق بود: ' + error.message);
    return false;
  }
}

// ============ Analyze ============
async function runAnalyze(){
  const symbol = $('symbol').value;
  const timeframe = $('tf').value;
  if ($('chartTf')) $('chartTf').value = timeframe;
  const limit = $('limit').value;
  const source = $('source').value;
  const threshold = parseFloat($('threshold').value);
  const strength = $('strength') ? $('strength').value : 'balanced';
  lastThreshold = threshold;

  $('analyze').disabled = true;
  $('analyze').textContent = 'در حال تحلیل...';
  setStatus('● در حال تحلیل', 'busy');

  try {
    log(`تحلیل: ${symbol} ${timeframe} (threshold=${threshold}, قدرت=${strength})`);
    const r = await fetch(API + '/api/analyze', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({symbol, timeframe, limit:+limit, source, threshold, strength})
    });
    const raw = await r.text();
    let d;
    try { d = raw ? JSON.parse(raw) : {}; }
    catch(_){ throw new Error(`پاسخ تحلیل JSON معتبر نیست (HTTP ${r.status}). سرور را با run.bat همین نسخه اجرا کن.`); }

    if(!r.ok){
      const err = d.error || `خطای تحلیل (HTTP ${r.status})`;
      if(d.hint) log(d.hint);
      $('signalCard').className = 'sigcard hold';
      $('sigBadge').className = 'sigbadge hold';
      $('sigBadge').textContent = '⏸ HOLD';
      $('sigReason').textContent = err;
      log('✖ ' + err);
      if(r.status === 404){
        log('راهنما: ابتدا همین نماد و همین تایم‌فریم را در «یادگیری تکی» آموزش بده؛ نمودار مستقل همچنان قابل نمایش است.');
        setStatus('● مدل آموزش‌دیده وجود ندارد', 'err');
      } else if(r.status === 409){
        log('راهنما: مدل ذخیره‌شده با نسخه ویژگی‌های فعلی سازگار نیست؛ همین نماد/تایم‌فریم را دوباره آموزش بده.');
        setStatus('● آموزش مجدد لازم است', 'err');
      } else {
        setStatus('● خطا در دریافت/تحلیل داده', 'err');
      }
      await loadChartOnly(symbol, timeframe, source, limit);
      return;
    }
    renderAnalysis(d);
    setStatus('● تحلیل کامل', 'ok');
    log(`منبع قیمت: ${d.source_label || d.source} | ${d.candle_count} کندل`);
    if(d.source_chain && d.source_chain.length){
      const chain = d.source_chain.map(x => `${x.label} ✖`).join(' ← ');
      log(`🔄 زنجیره fallback: ${chain} ← ✓ ${d.source_label || d.source}`);
    }
    if(d.model_pool && d.model_pool.n){
      const mp = d.model_pool;
      log(`🧠 اجماع همه آموزش‌ها: ${mp.n} مدل رای دادند (${mp.same_symbol_votes} هم‌نماد، ${mp.same_tf_votes} هم‌تایم‌فریم) | P=${mp.consensus_prob} | هم‌جهتی ${(mp.agreement*100).toFixed(0)}٪` + (d.blend_weight ? ` | وزن ترکیب در احتمال: ${(d.blend_weight*100).toFixed(0)}٪` : ''));
      (mp.votes||[]).slice(0,8).forEach(v => log(`   • ${v.symbol} ${v.timeframe}: ${v.dir} P=${v.prob} (وزن ${v.weight})`));
    }
    if(d.advisory) log('⚠ تحلیل مشورتی: مدل اختصاصی این نماد/تایم‌فریم آموزش ندیده؛ نتیجه از اجماع بقیه مدل‌های آموزش‌دیده است.');
    log(`سیگنال: ${d.signal.kind} | قدرت: ${(d.signal.power*100).toFixed(0)}%`);
    if(d.rl_review && d.rl_review.direction) log(`نظر عامل DRL ${d.rl_review.algorithm}: ${d.rl_review.direction} | پوزیشن هدف ${(d.rl_review.target_position*100).toFixed(0)}%`);
  } catch(e){
    log('خطا: ' + e.message);
    setStatus('● خطا', 'err');
    // Keep the chart useful even when the model pipeline or its response fails.
    await loadChartOnly(symbol, timeframe, source, limit);
  } finally {
    $('analyze').disabled = false;
    $('analyze').textContent = 'تحلیل';
  }
}

function renderAnalysis(d){
  lastCandles = d.candles || [];
  lastEmas = d.emas || {};
  lastHistory = d.backtest || [];
  lastProb = d.signal.prob;
  lastSignal = d.signal;
  lastAtr = Number(d.atr || d.signal.atr || 0);
  const sig = d.signal;

  // Price metrics
  const chg = d.change_pct;
  $('price').textContent = fmt(d.price);
  $('change').textContent = (chg>=0?'+':'') + chg.toFixed(2) + '%';
  $('change').className = chg >= 0 ? 'up' : 'down';
  $('rsi').textContent = (d.rsi||0).toFixed(1);
  $('atr').textContent = fmt(d.atr);

  // Model metrics
  const m = d.model_meta || {};
  $('accuracy').textContent = m.val_acc ? (m.val_acc*100).toFixed(1)+'%' : '—';
  $('wfAcc').textContent = m.walk_forward_acc ? (m.walk_forward_acc*100).toFixed(1)+'%' : '—';
  $('trainN').textContent = m.train_samples ? m.train_samples.toLocaleString('en-US') : '—';
  $('testN').textContent = m.test_samples ? m.test_samples.toLocaleString('en-US') : '—';
  $('trainAcc').textContent = m.train_acc ? (m.train_acc*100).toFixed(1)+'%' : '—';
  $('testAcc').textContent = m.val_acc ? (m.val_acc*100).toFixed(1)+'%' : '—';
  $('balanced').textContent = m.balanced_acc ? (m.balanced_acc*100).toFixed(1)+'%' : '—';
  $('hiAcc').textContent = m.high_conf_acc ? (m.high_conf_acc*100).toFixed(1)+'%' : '—';
  $('hiCov').textContent = m.high_conf_cov ? (m.high_conf_cov*100).toFixed(1)+'%' : '—';
  $('vhAcc').textContent = m.very_high_conf_acc ? (m.very_high_conf_acc*100).toFixed(1)+'%' : '—';
  $('vhCov').textContent = m.very_high_conf_cov ? (m.very_high_conf_cov*100).toFixed(1)+'%' : '—';
  $('uhAcc').textContent = m.ultra_high_conf_acc ? (m.ultra_high_conf_acc*100).toFixed(1)+'%' : '—';
  $('uhCov').textContent = m.ultra_high_conf_cov ? (m.ultra_high_conf_cov*100).toFixed(1)+'%' : '—';
  $('mxAcc').textContent = m.max_conf_acc ? (m.max_conf_acc*100).toFixed(1)+'%' : '—';
  $('mxCov').textContent = m.max_conf_cov ? (m.max_conf_cov*100).toFixed(1)+'%' : '—';
  $('nFeat').textContent = m.feature_count || '—';
  $('nTrials').textContent = m.iterations || '—';
  $('trainTime').textContent = m.training_time_sec ? m.training_time_sec.toFixed(1)+'s' : '—';
  $('trainRound').textContent = m.training_round ? `دور ${m.training_round}` : '—';
  $('warmStart').textContent = m.warm_started ? '✓ فعال' : 'اولین آموزش';
  $('wfAcc2').textContent = m.walk_forward_acc ? (m.walk_forward_acc*100).toFixed(1)+'%' : '—';
  $('metaModel').textContent = 'Log-Odds';
  $('calibrated').textContent = m.calibrated ? 'سیگموید (OOF)' : 'غیرفعال';
  $('nSeeds').textContent = m.n_seeds ? `${m.n_seeds} seed` : '—';
  const agreeEl = $('agreeAcc');
  if (agreeEl) {
    agreeEl.textContent = m.agree_acc ? (m.agree_acc*100).toFixed(1)+'%' : '—';
    const agreeCovEl = $('agreeCov');
    if (agreeCovEl) agreeCovEl.textContent = m.agree_cov ? (m.agree_cov*100).toFixed(1)+'%' : '—';
  }

  // Storage badge + hero banner
  const simTest = m.sim_test || {};
  const baseline = (m.baseline_win_rate || 0.5) * 100;
  const simWinEl = $('simWin');
  if (simTest.win_rate != null && simTest.n_trades > 0) {
    simWinEl.textContent = (simTest.win_rate*100).toFixed(1) + '%';
    // Compare against the random baseline (TP=SL=1.5xATR -> 50%)
    const edge = simTest.win_rate*100 - baseline;
    simWinEl.className = edge >= 8 ? 'up' : edge >= 2 ? 'neutral' : 'down';
    $('simN').textContent = `${simTest.n_trades || 0} معامله · +${edge.toFixed(1)}٪ نسبت به خط پایه ${baseline.toFixed(1)}٪`;
  } else {
    simWinEl.textContent = '—';
    $('simN').textContent = `خط پایه تصادفی: ${baseline.toFixed(1)}٪`;
  }
  $('bestThr').textContent = m.best_threshold ? m.best_threshold.toFixed(2) : '—';
  // OOF (leakage-free walk-forward over the whole series) model edge
  const oof = m.sim_oof || {};
  const oofEl = $('oofWin');
  if (oof.win_rate != null && oof.n_trades > 0) {
    oofEl.textContent = (oof.win_rate*100).toFixed(1) + '%';
    const oedge = oof.win_rate*100 - 50;
    oofEl.className = oedge >= 4 ? 'up' : oedge >= 1 ? 'neutral' : 'down';
    $('oofN').textContent = oedge >= 1
      ? `${oof.n_trades} معامله · لبه +${oedge.toFixed(1)}٪`
      : `${oof.n_trades} معامله · لبه کافی ندارد — احتیاط یا آموزش مجدد`;
  } else {
    oofEl.textContent = '—';
    $('oofN').textContent = 'داده کافی نبود';
  }
  const bs = d.backtest_stats || {};
  const btWinEl = $('btWin');
  if (bs.win_rate != null) {
    btWinEl.textContent = (bs.win_rate*100).toFixed(0) + '%';
    btWinEl.className = bs.win_rate >= 0.58 ? 'up' : bs.win_rate >= 0.5 ? 'neutral' : 'down';
    let detail = `${bs.wins || 0} برد / ${bs.losses || 0} باخت`;
    if (bs.ambiguous) detail += ` / ${bs.ambiguous} مبهم`;
    detail += bs.out_of_sample_only ? ' · فقط خارج از نمونه' : '';
    $('btDetail').textContent = detail;
  } else {
    btWinEl.textContent = '—';
    $('btDetail').textContent = bs.out_of_sample_only
      ? 'سیگنال خارج از نمونه‌ی کافی نبود' : 'سیگنال کافی نبود';
  }
  if (d.advisory) {
    const mp0 = d.model_pool || {};
    $('storage').innerHTML = `<span class="badge" style="background:var(--purple)">🧠 تحلیل مشورتی با اجماع ${mp0.n || 0} مدل آموزش‌دیده — مدل اختصاصی ${d.symbol} ${d.timeframe} هنوز آموزش ندیده</span>`;
  } else {
    $('storage').innerHTML = `<span class="badge ok">💾 مدل: ${d.symbol} · ${d.timeframe} · ذخیره‌شده در پوشه</span>`;
  }

  // Signal card and central decision brain
  renderSignal(sig);
  renderBrain(d.brain || null);

  // Indicators
  renderIndicators(d.indicators || {});

  // V19: scenario row + narrative report
  renderScenario(sig.scenario || null);
  renderAnalystReport(d.analyst_report || null);

  // History table
  renderHistory(d.backtest || []);

  // Trials from last_result if available
  if(d.model_meta && d.model_meta.trials){
    renderTrials(d.model_meta.trials);
  }

  // Draw chart
  const chartSubtitle = $('chartSubtitle');
  if (chartSubtitle) chartSubtitle.textContent = `${d.symbol} · ${d.timeframe} · ${Math.min(lastCandles.length, Number($('chartRange')?.value || 100))} کندل از ${d.candle_count} کندل دریافتی`;
  drawChart();
}

function renderBrain(brain){
  const panel = $('brainPanel');
  if (!panel) return;
  const decision = $('brainDecision');
  const summary = $('brainSummary');
  const rows = $('brainComponents');
  const vetoes = $('brainVetoes');
  const calibration = $('brainCalibration');
  if (!brain) {
    decision.textContent = 'اطلاعات موجود نیست';
    summary.textContent = 'پاسخ مغز مرکزی از سرور دریافت نشد.';
    rows.innerHTML = '';
    vetoes.textContent = '';
    return;
  }
  const labels = {
    ml:'مدل یادگیری ماشین', technical:'تکنیکال مستقل', regime:'رژیم بازار',
    multi_timeframe:'تأیید چندتایم‌فریم', patterns:'الگوهای کندلی',
    derivatives:'مشتقات و جریان سفارش', horizon:'چشم‌انداز آماری',
    sentiment:'ترس و طمع', drl:'عامل یادگیری تقویتی',
    divergence:'واگرایی RSI/MACD', ichimoku:'ایچیموکو', volume:'جریان پول و حجم',
    pool:'اجماع استخر مدل‌ها'
  };
  const comps = brain.components || {};
  const totalSources = Object.keys(comps).length || 14;
  const dec = brain.final_signal || 'HOLD';
  const bias = brain.decision || 'HOLD';
  decision.textContent = dec === 'BUY' ? 'سیگنال نهایی: BUY' : dec === 'SELL' ? 'سیگنال نهایی: SELL' : 'سیگنال نهایی: HOLD';
  decision.className = 'brain-badge ' + dec.toLowerCase();
  const pct = (Number(brain.score || 0) * 100).toFixed(1);
  const biasFa = bias === 'BUY' ? 'صعودی' : bias === 'SELL' ? 'نزولی' : 'خنثی';
  const shaping = brain.confluence && Number(brain.confluence.shaping_factor) !== 1
    ? ` · ضریب شکل‌دهی اجماع ${Number(brain.confluence.shaping_factor).toFixed(2)}×` : '';
  const formInfo = brain.recent_form && brain.recent_form.available
    ? ` · ضریب فرم اخیر ${Number(brain.recent_form.factor).toFixed(2)}×` : '';
  summary.textContent = `تمایل اجماع: ${biasFa} (${pct}٪) · پوشش منابع ${(Number(brain.coverage || 0)*100).toFixed(0)}٪ · ${brain.available_sources || 0} منبع فعال از ${totalSources} · ${brain.directional_sources || 0} منبع جهت‌دار${shaping}${formInfo}`;
  rows.innerHTML = Object.entries(comps).map(([key, item]) => {
    const available = !!item.available;
    const score = Number(item.score || 0);
    const width = Math.min(100, Math.abs(score)*100);
    const side = score > 0.08 ? 'bull' : score < -0.08 ? 'bear' : 'neutral';
    const direction = !available ? 'داده ناموجود' : side === 'bull' ? 'صعودی' : side === 'bear' ? 'نزولی' : 'خنثی';
    const rel = item.reliability_multiplier != null ? `ضریب وزن ${Number(item.reliability_multiplier).toFixed(2)}` : '';
    const stats = brain.reliability?.components?.[key];
    const samples = stats ? ` · ${stats.mature_samples} نمونه مستقل · دقت جهت ${Number(stats.directional_hit_rate*100).toFixed(0)}٪${stats.adaptive ? ' · تطبیقی' : ''}` : '';
    return `<div class="brain-row ${available ? side : 'missing'}">
      <div class="brain-row-top"><span>${labels[key] || key}</span><strong>${direction}</strong></div>
      <div class="brain-track"><i class="${side}" style="width:${width}%"></i></div>
      <small>امتیاز ${available ? (score*100).toFixed(0)+'٪' : '—'} · وزن مؤثر ${(Number(item.effective_weight || 0)*100).toFixed(1)}٪ ${rel}${samples}</small>
    </div>`;
  }).join('');
  const reasons = Array.isArray(brain.vetoes) ? brain.vetoes : [];
  vetoes.innerHTML = reasons.length
    ? `<strong>دلایل جلوگیری از ورود:</strong><ul>${reasons.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`
    : (brain.final_signal === 'BUY' || brain.final_signal === 'SELL'
        ? '<span class="good">اجماع چندمنبعی از سیگنال پایه پشتیبانی کرده است.</span>'
        : '<span class="note">سیگنال پایه شرایط ورود را نداشته؛ مغز مرکزی آن را به معامله تبدیل نمی‌کند.</span>');
  const mode = brain.reliability?.mode === 'adaptive_oos' ? 'کالیبراسیون خارج‌ازنمونه فعال است' : 'وزن‌های اولیه محافظه‌کارانه؛ هنوز نمونه بالغ کافی برای تطبیق همه منابع جمع نشده است';
  const form = brain.recent_form;
  const formTxt = form && form.available
    ? ` · فرم اخیر مغز: دقت جهت ${Math.round(Number(form.hit_rate || 0) * 100)}٪ در ${form.matured} مورد بالغ${Number(form.factor) < 1 ? ` · احتیاط ${Number(form.factor).toFixed(2)}×` : ''}`
    : '';
  calibration.textContent = `${mode} · افق ارزیابی منابع: ${brain.feedback?.horizon_bars || 12} کندل${formTxt}`;
}

// ---------- V19: scenario row + narrative report ----------
const SETUP_FA = {
  trend_continuation: 'ادامه روند', momentum_breakout: 'شکست مومنتوم',
  mean_reversion: 'بازگشت به میانگین', reversal_watch: 'مراقب بازگشت',
  range: 'بازار رنج', high_vol_caution: 'احتیاط در نوسان بالا'
};

function renderScenario(sc){
  const el = $('sigScenario');
  if (!el) return;
  if (!sc || sc.entry == null){
    el.innerHTML = '';
    el.style.display = 'none';
    return;
  }
  el.style.display = 'block';
  const evNet = Number(sc.ev_net_pct || 0);
  const evCls = evNet > 0 ? 'up' : evNet < 0 ? 'down' : 'neutral';
  const setupFa = SETUP_FA[sc.setup] || sc.setup || '—';
  const prov = sc.provisional ? ' · سناریوی مرجع' : '';
  el.innerHTML = `
    <div class="scenario-row">
      <span class="chip">ستاپ: <strong>${setupFa}</strong>${prov}</span>
      <span class="chip">پاداش/ریسک: <strong>${Number(sc.reward_risk).toFixed(2)}</strong></span>
      <span class="chip">EV خالص: <strong class="${evCls}">${evNet>=0?'+':''}${evNet.toFixed(2)}٪</strong></span>
      <span class="chip">ابطال: <strong>${fmt(sc.invalidation)}</strong></span>
    </div>
    <div class="note">ارزش موردانتظار از احتمال کالیبره‌شده‌ی مدل و هندسه‌ی TP/SL آموزش محاسبه می‌شود؛ هزینه رفت‌وبرگشت ${(Number(sc.cost_pct)||0).toFixed(2)}٪ کسر شده است.</div>`;
}

// ---------------- V19.3: storm scout banner (V20: early hunt + compact rows) ----------------
let stormDismissedAt = 0;
let stormLastSeenTs = 0;
let stormLastData = null;

function fmtUsd(n){
  n = Number(n) || 0;
  return n >= 1e9 ? (n/1e9).toFixed(2)+'B' : n >= 1e6 ? (n/1e6).toFixed(1)+'M' : n >= 1e3 ? (n/1e3).toFixed(0)+'K' : String(Math.round(n));
}

const STORM_PHASE_FA = {early:'اول حرکت', running:'در حرکت', late:'دیر', exhausted:'دیرشده'};

function stormRow(it, kind){
  const up = it.direction !== 'down';
  const phase = STORM_PHASE_FA[it.phase] || it.phase || '—';
  const phCls = it.phase === 'early' ? 'early' : it.phase === 'exhausted' || it.phase === 'late' ? 'late' : 'run';
  const c1 = (it.change_1h != null) ? `${Number(it.change_1h) >= 0 ? '+' : ''}${Number(it.change_1h).toFixed(1)}٪/۱س` : '';
  const unv = it.verified === false ? '<span class="storm-unverified" title="کندل‌ها تأیید نشد">؟</span>' : '';
  const reasons = (it.reasons || []).slice(0, 4).join(' · ');
  const shownScore = kind === 'pre-pump' ? Math.round(Number(it.pre_pump_score) || 0)
    : kind === 'pre-dump' ? Math.round(Number(it.pre_dump_score) || 0)
    : kind === 'active-dump' ? Math.round(Number(it.active_dump_score) || 0)
    : Math.round(Number(it.score) || 0);
  return `<div class="storm-row storm-${kind} ${it.fresh ? 'storm-fresh' : ''}">
    <span class="storm-sym" data-exchange-base="${esc(it.base)}" tabindex="0" aria-label="${esc(it.base)}؛ برای مشاهده صرافی‌های پشتیبان مکث کن">${it.learning?.star ? '⭐ ' : ''}${up ? '🟢' : '🔴'} ${esc(it.base)}${unv}<span class="storm-exchange-tooltip" hidden></span></span>
    <span class="storm-num ${up ? 'up' : 'down'}">${up ? '+' : ''}${Number(it.change_24h).toFixed(1)}٪${c1 ? ` <small>${esc(c1)}</small>` : ''}</span>
    <span class="storm-score"><i class="ph ${phCls}">${kind === 'pre-pump' ? 'پیش‌پامپ' : kind === 'pre-dump' ? 'پیش‌دامپ' : kind === 'active-dump' ? 'دامپ فعال' : esc(phase)}</i> ${shownScore}</span>
    <span class="storm-reasons" title="${esc(reasons)}">${esc(reasons)}</span>
    <span class="trend-actions">
      <button type="button" class="trend-btn" data-act="analyze" data-sym="${esc(it.symbol)}">تحلیل</button>
      <button type="button" class="trend-btn" data-act="learn" data-sym="${esc(it.symbol)}">➕</button>
    </span>
  </div>`;
}

const stormExchangeClientCache = new Map();
function stormExchangeGroupHtml(title, items){
  return `<div class="storm-tip-group"><strong>${title}</strong>${items.map(x=>{
    const status=x.status==='listed'?'listed':x.status==='unknown'?'unknown':'missing';
    const icon=x.status==='listed'?'✓':x.status==='unknown'?'؟':'—';
    const detail=x.status==='listed'?(x.markets||[]).map(m=>`${esc(m.symbol)} (${esc(m.quote_label)})`).join('، ')
      :x.status==='unknown'?'بررسی ناموفق / منبع در دسترس نیست':'در فهرست بازارهای فعال پیدا نشد';
    return `<div class="storm-tip-item"><span class="${status}">${icon} ${esc(x.name)}</span><span>${detail}</span><a href="${esc(x.site)}" target="_blank" rel="noopener noreferrer">سایت</a></div>`;
  }).join('')}</div>`;
}
async function showStormExchangeHint(node){
  const tip=node.querySelector('.storm-exchange-tooltip'); if(!tip)return;
  tip.hidden=false;
  const base=node.dataset.exchangeBase;
  tip.innerHTML=`<div class="storm-tip-title">بازارهای ${esc(base)} · در حال بررسی…</div>`;
  try{
    let item=stormExchangeClientCache.get(base);
    if(!item || item.expires<Date.now()){
      const data=await readApiJson(await fetch(`${API}/api/scout/exchanges?base=${encodeURIComponent(base)}`));
      item={data,expires:Date.now()+300000}; stormExchangeClientCache.set(base,item);
    }
    const data=item.data, groups=data.groups||{};
    tip.innerHTML=`<div class="storm-tip-title">صرافی‌های دارای بازار ${esc(base)}</div>`+
      stormExchangeGroupHtml('صرافی‌های ایرانی',groups.iranian||[])+
      stormExchangeGroupHtml('صرافی‌های بین‌المللی',groups.international||[])+
      `<div class="storm-tip-foot">بررسی: ${new Date((data.checked_at||0)*1000).toLocaleTimeString('fa-IR')} · فهرست بازار، نه تضمین واریز/برداشت یا نقدشوندگی. وضعیت «نامشخص» به معنی عدم پشتیبانی نیست.</div>`;
  }catch(e){tip.innerHTML=`<div class="storm-tip-title">بررسی ${esc(base)} انجام نشد</div><div>${esc(e.message)}</div>`;}
}
function bindStormExchangeHints(){
  document.querySelectorAll('.storm-sym[data-exchange-base]').forEach(node=>{
    if(node.dataset.exchangeBound==='1')return;
    node.dataset.exchangeBound='1';
    const show=()=>showStormExchangeHint(node);
    const hide=()=>{const tip=node.querySelector('.storm-exchange-tooltip');if(tip)tip.hidden=true;};
    node.addEventListener('mouseenter',show); node.addEventListener('focus',show);
    node.addEventListener('mouseleave',hide); node.addEventListener('blur',hide);
  });
}

function renderStorm(st){
  const banner = $('stormBanner');
  if(!banner || !st) return;
  stormLastData = st;
  document.dispatchEvent(new CustomEvent("tekar:scout-state", {detail: st}));
  const onlyEarly = $('stormOnlyEarly') ? $('stormOnlyEarly').checked : false;
  const prePump = st.pre_pump || [], preDump = st.pre_dump || [], activeDump = st.active_dump || [], early = st.early || [], alerts = st.alerts || [], watch = st.watch || [];
  const newest = Math.max(st.generated_at || 0, stormLastSeenTs);
  stormLastSeenTs = newest;
  const nothing = !st.online && !prePump.length && !preDump.length && !activeDump.length && !early.length && !alerts.length && !watch.length;
  if(nothing || (!prePump.length && !preDump.length && !activeDump.length && !early.length && !alerts.length && !watch.length && (st.generated_at || 0) <= stormDismissedAt)){
    if(nothing && st.error) log('دیده‌بان طوفان: ' + st.error);
    banner.hidden = true;
    return;
  }
  const metaBits = [];
  if(st.stale) metaBits.push('⚠ داده قدیمی');
  metaBits.push(`منابع ${st.sources_ok ?? '—'}/${st.sources_total ?? '—'}`);
  if(st.generated_at) metaBits.push(new Date(st.generated_at * 1000).toLocaleTimeString('fa-IR'));
  $('stormMeta').textContent = metaBits.join(' · ');
  $('stormDisclaimer').textContent = st.disclaimer || 'نشانه‌های اولیه‌ی احتمال حرکت شدید هستند، نه پیش‌بینی قطعی؛ همیشه حد ضرر بگذار.';
  const parts = [];
  if(prePump.length) parts.push('<div class="storm-sec storm-sec-prepump">🧲 پیش از پامپ (شتاب حجم + فشار خرید)</div>' + prePump.map(it => stormRow(it, 'pre-pump')).join(''));
  if(preDump.length) parts.push('<div class="storm-sec storm-sec-predump">🔻 پیش از دامپ (شتاب حجم + فشار فروش)</div>' + preDump.map(it => stormRow(it, 'pre-dump')).join(''));
  if(activeDump.length) parts.push('<div class="storm-sec storm-sec-predump">🚨 دامپ فعال (ریزش + تأیید فشار فروش)</div>' + activeDump.map(it => stormRow(it, 'active-dump')).join(''));
  if(early.length && !onlyEarly) parts.push('<div class="storm-sec storm-sec-early">🦅 شکار اول حرکت (تازه شروع شده)</div>' + early.map(it => stormRow(it, 'early')).join(''));
  else if(early.length && onlyEarly) parts.push(early.map(it => stormRow(it, 'early')).join(''));
  if(!onlyEarly){
    if(alerts.length) parts.push('<div class="storm-sec">⚡ طوفان فعال</div>' + alerts.map(it => stormRow(it, 'alert')).join(''));
    if(watch.length) parts.push('<div class="storm-sec">👀 در حال شکل‌گیری</div>' + watch.map(it => stormRow(it, 'watch')).join(''));
  }
  $('stormList').innerHTML = parts.length ? parts.join('')
    : (onlyEarly ? '<div class="note">فعلاً پیش‌نشانگر پامپ/دامپ یا حرکت تازه‌ای پیدا نشد.</div>'
                 : '<div class="note">فعلاً نشانه‌ی قابل‌اتکایی از طوفان دیده نشد.</div>');
  bindStormExchangeHints();
  banner.hidden = false;
  banner.querySelectorAll('.trend-btn').forEach(b => b.onclick = () =>
    b.dataset.act === 'analyze' ? analyzeTrend(b.dataset.sym) : addTrendToLearn(b.dataset.sym));
}

async function pollStorm(){
  try{
    const r = await fetch(`${API}/api/scout`);
    renderStorm(await readApiJson(r));
  }catch(e){ /* best effort: a failed poll just tries again next cycle */ }
}

let scoutFollowupSeen = new Set();
let scoutFollowupInitialized = false;
async function pollScoutFollowups(){
  const panel=$('scoutFollowupsPanel'); if(!panel)return;
  try{
    const data=await readApiJson(await fetch(`${API}/api/scout/followups?limit=40`));
    const events=data.events||[], delayedPumps=data.delayed_pumps||[], delayedDumps=data.delayed_dumps||[], delayed=[...delayedPumps,...delayedDumps], recoveries=[...(data.recovered_after_dip||[]),...(data.recovered_after_rally||[])];
    const status=$('scoutFollowupStatus'); if(status) status.textContent=`${events.length} نتیجه ثبت‌شده · ${delayedPumps.length} پامپ دیرهنگام · ${delayedDumps.length} دامپ دیرهنگام`;
    const summary=$('scoutFollowupSummary'); if(summary) summary.textContent=`نتایج جهت‌دار: ${events.length} · پامپ‌های دیرهنگام: ${delayedPumps.length} · دامپ‌های دیرهنگام: ${delayedDumps.length} · بازگشت پس از حرکت نامساعد: ${recoveries.length} · داده فاقد قیمت معتبر، موفق یا ناموفق فرض نمی‌شود.`;
    const pr=data.performance_report||{}, pc=pr.counts||{};
    const categoryLabels=[['immediate_pump','حرکت صعودی سریع'],['immediate_dump','حرکت نزولی سریع'],['next_day_pump','هدف صعودی روز بعد'],['next_day_dump','هدف نزولی روز بعد'],['delayed_pump','پامپ با تأخیر'],['delayed_dump','دامپ با تأخیر'],['recovered_after_dip','هدف صعودی پس از اصلاح'],['recovered_after_rally','هدف نزولی پس از جهش'],['never_reached_target','هدف هم‌جهت محقق‌نشده'],['pending','در انتظار'],['insufficient_observations','داده ناکافی']];
    const categoryBox=$('scoutFollowupCategories');
    if(categoryBox){
      const groups=categoryLabels.map(([k,label])=>{
        const items=(pr.categories||{})[k]||[];
        const names=items.slice(0,30).map(x=>`${esc(x.symbol)} (${x.first_success_horizon||'—'})`).join('، ');
        const extra=items.length>30?` و ${items.length-30} مورد دیگر در API`:'';
        return `<div><b>${label} (${Number(pc[k]||0)}):</b> ${names||'—'}${extra}</div>`;
      }).join('');
      categoryBox.innerHTML=`<b>گزارش تجمیعی همه معرفی‌ها (${Number(pr.total_recommendations||0)} مورد)</b>${groups}`;
    }
    const insightBox=$('scoutFollowupLearning'), insights=data.historical_insights||[];
    if(insightBox) insightBox.textContent=insights.length
      ? 'یادگیری از معرفی‌های قبلی (حداقل ۵ نتیجه واقعی، تفکیک جهت): '+insights.slice(0,4).map(x=>`${x.direction==='down'?'نزولی':'صعودی'} / ${x.phase} / امتیاز ${x.score_band} / ${x.horizon}: موفقیت هم‌جهت ${(Number(x.success_rate)*100).toFixed(0)}٪ از ${x.samples} نمونه (بازه اطمینان ۹۵٪: ${(Number(x.success_rate_ci95?.[0])*100).toFixed(0)} تا ${(Number(x.success_rate_ci95?.[1])*100).toFixed(0)}٪؛ شواهد ${x.evidence_level||'نامشخص'}), بازده هم‌جهت ${Number(x.avg_return_pct).toFixed(2)}٪`).join(' | ')
      : 'هنوز نمونه کافی برای کشف الگوی قابل اتکا وجود ندارد؛ با ثبت نتایج واقعی این بخش به‌روز می‌شود.';
    const pp=data.early_move_report||data.pre_pump_report||{}, ppH=pp.horizons||{};
    const ppBox=$('scoutPrePumpLearning');
    if(ppBox){
      const order=[['1h','۱س'],['4h','۴س'],['24h','۱روز'],['3d','۳روز'],['7d','۷روز']];
      const parts=order.map(([k,label])=>{
        const h=ppH[k]||{}, n=Number(h.samples||0), pending=Number(h.pending||0), missing=Number(h.missing_observations||0);
        const rate=h.success_rate==null?'—':`${(Number(h.success_rate)*100).toFixed(0)}٪`;
        return `${label}: ${n} نتیجه معتبر، ${Number(h.successes||0)} موفق (${rate})${pending?`، ${pending} در انتظار`:''}${missing?`، ${missing} مشاهده مفقود`:''}`;
      }).join(' | ');
      const gradeNames={exchange_taker:'تیکر واقعی',candle_proxy:'پروکسی کندلی',unknown:'نامشخص'};
      const gradeStats=pp.flow_grade_horizons||{};
      const grades=Object.entries(pp.flow_grades||{}).map(([k,v])=>{
        const h24=(gradeStats[k]||{})['24h']||{}, h3d=(gradeStats[k]||{})['3d']||{};
        const rate=x=>x.success_rate==null?'—':`${(Number(x.success_rate)*100).toFixed(0)}٪ از ${Number(x.samples||0)}`;
        return `${gradeNames[k]||k}: ${Number(v.events||0)} رویداد؛ ۱روز ${rate(h24)}؛ ۳روز ${rate(h3d)}`;
      }).join(' | ');
      const scoreBands=pp.score_band_horizons||{};
      const scoreInfo=Object.entries(scoreBands).map(([k,v])=>{
        const h=v['24h']||{}; return Number(h.samples||0)>=5?`امتیاز ${k}: موفقیت روزانه ${(Number(h.success_rate||0)*100).toFixed(0)}٪ از ${h.samples}`:null;
      }).filter(Boolean).join(' | ');
      const moveTypes=pp.event_types||{}, pumpN=Number(moveTypes.pump?.events||0), dumpN=Number(moveTypes.dump?.events||0);
      const dirH=pp.directional_horizons||{};
      const dirBrief=['up','down'].map(side=>{
        const h=(dirH[side]||{})['24h']||{};
        return `${side==='down'?'نزولی':'صعودی'} ۲۴س: ${Number(h.successes||0)} موفق از ${Number(h.samples||0)}`;
      }).join(' · ');
      ppBox.textContent=Number(pp.total_events||0)
        ? `ارزیابی مستقل سیگنال‌های هر دو جهت: ${Number(pp.total_events||0)} رویداد یکتا از ${Number(pp.unique_symbols||0)} نماد؛ ${pumpN} پیش‌پامپ و ${dumpN} پیش‌دامپ (تکرار هر نماد تا ۲۴ ساعت حذف می‌شود). ${dirBrief}. ${parts}. ${grades||''} ${scoreInfo}. آستانه‌ها فعلاً ثابت‌اند؛ بازبینی فقط پس از حداقل ${Number(pp.minimum_samples_for_review||30)} نتیجه معتبر در هر افق. ${pp.threshold_policy_note||''}`
        : 'هنوز رویداد پیش‌پامپ یا پیش‌دامپی برای ارزیابی ثبت نشده است؛ پس از گذشت زمان و دریافت قیمت واقعی، نتیجه جهت‌دار ۱ساعته تا ۷روزه اینجا نمایش داده می‌شود.';
    }
    const comboBox=$('scoutPrePumpPatternLearning');
    if(comboBox){
      const cohorts=(pp.feature_combo_learning||{}).cohorts||[];
      const explain=(horizon,label)=>{
        const candidates=cohorts
          .map(c=>({c,h:(c.horizons||{})[horizon]||{}}))
          .filter(x=>Number(x.h.samples||0)>=5)
          .sort((a,b)=>Number(b.h.samples||0)-Number(a.h.samples||0));
        const chosen=[], seen=new Set();
        // Show the strongest supported cohort from each BTC regime first so
        // a high-volume regime cannot hide the others in the compact panel.
        ['UP','DOWN','NEUTRAL','UNKNOWN'].forEach(regime=>{
          const item=candidates.find(x=>(x.c.market_regime||'UNKNOWN')===regime);
          if(item){chosen.push(item);seen.add(item.c.key);}
        });
        for(const item of candidates){
          if(chosen.length>=4)break;
          if(!seen.has(item.c.key)){chosen.push(item);seen.add(item.c.key);}
        }
        return chosen.slice(0,4).map(x=>`${x.c.market_regime_label_fa||'وضعیت بازار نامشخص'} · ${x.c.label_fa} [${x.c.flow_label_fa}]: ${Number(x.h.successes||0)} موفق، ${Number(x.h.failures||0)} ناموفق از ${Number(x.h.samples||0)}؛ نرخ ${x.h.success_rate==null?'—':(Number(x.h.success_rate)*100).toFixed(0)+'٪'}؛ میانگین ${x.h.avg_return_pct==null?'—':Number(x.h.avg_return_pct).toFixed(2)+'٪'} (${x.h.evidence_level||'نامشخص'})`).join(' | ');
      };
      const regimeNames={UP:'صعودی',DOWN:'نزولی',NEUTRAL:'خنثی',UNKNOWN:'نامشخص'};
      const regimeSummary=Object.entries((pp.feature_combo_learning||{}).regime_cohort_counts||{})
        .map(([k,v])=>`${regimeNames[k]||k}: ${Number(v)} گروه`).join('، ');
      const short24=explain('24h','۱روز'), short3=explain('3d','۳روز');
      comboBox.textContent=cohorts.length
        ? `یادگیری ترکیب پیش‌حرکت صعودی/نزولی بر اساس رژیم بیت‌کوین (صرفاً گزارش): ${regimeSummary?`گروه‌بندی: ${regimeSummary}. `:''}${short24?'نتیجه ۲۴ساعته: '+short24:'برای مقایسه ترکیب‌ها هنوز ۵ نتیجه ۲۴ساعته در یک گروه جمع نشده است.'} ${short3?'نتیجه ۳روزه: '+short3:''} فشار خرید و فشار فروش جداگانه ارزیابی می‌شوند؛ گروه‌های زیر ۱۰ نمونه شواهد ناکافی دارند.`
        : 'هنوز ترکیب قابل ارزیابی از شتاب حجم، فشار خرید/فروش و قدرت نسبی ثبت نشده است.';
    }
    const labels={ '1h':'۱ ساعت','4h':'۴ ساعت','24h':'۱ روز','3d':'۳ روز','7d':'۷ روز' };
    const rows=$('scoutFollowupRows');
    if(rows) rows.innerHTML=events.length?events.map(e=>{
      const good=e.result==='success', fake=e.result==='fake';
      const label=e.recovered_after_dip?'↗️ اصلاح و سپس پامپ':e.recovered_after_rally?'↘️ جهش و سپس دامپ':e.delayed_pump?'🚀 پامپ با تأخیر':e.delayed_dump?'📉 دامپ با تأخیر':good?(e.direction==='down'?'موفق نزولی':'موفق صعودی'):fake?(e.direction==='down'?'جهش خلاف انتظار':'افت خلاف انتظار'):'خنثی';
      const ret=Number(e.return_pct);
      return `<tr><td>${esc(e.symbol)}</td><td>${new Date(e.spotted_at*1000).toLocaleString('fa-IR')}</td><td>${labels[e.horizon]||esc(e.horizon)}</td><td class="${ret>=0?'up':'down'}">${ret>=0?'+':''}${ret.toFixed(2)}٪</td><td>${label}</td></tr>`;
    }).join(''):'<tr><td colspan="5" class="note">هنوز نتیجه‌ای ثبت نشده؛ با گذشت زمان گزارش‌ها تکمیل می‌شوند.</td></tr>';
    // Optional browser alerts: only newly resolved delayed pumps, once per browser profile.
    for(const e of delayed){
      if(scoutFollowupSeen.has(e.id)) continue;
      scoutFollowupSeen.add(e.id);
      if(!scoutFollowupInitialized){ sessionStorage.setItem('scout-followup-'+e.id,'1'); continue; }
      if(scoutFollowupSeen.size>500) scoutFollowupSeen=new Set(Array.from(scoutFollowupSeen).slice(-250));
      if(window.Notification && Notification.permission==='granted' && !sessionStorage.getItem('scout-followup-'+e.id)){
        const adverse=e.direction==='down'?e.adverse_excursion_pct:e.adverse_excursion_pct;
        const title=e.recovered_after_dip?`اصلاح و سپس پامپ: ${e.symbol}`:e.recovered_after_rally?`جهش و سپس دامپ: ${e.symbol}`:e.delayed_dump?`دامپ با تأخیر: ${e.symbol}`:`پامپ با تأخیر: ${e.symbol}`;
        new Notification(title,{body:`پس از ${labels[e.horizon]||e.horizon} بازده خام ${Number(e.return_pct).toFixed(2)}٪؛ نتیجه بر اساس جهت ${e.direction==='down'?'نزولی':'صعودی'} ارزیابی شده است.`});
        sessionStorage.setItem('scout-followup-'+e.id,'1');
      }
    }
    scoutFollowupInitialized = true;
  }catch(e){const status=$('scoutFollowupStatus');if(status)status.textContent='گزارش موقتاً در دسترس نیست';}
}

async function pollScoutBrainStatus(){
  const panel=$('scoutBrainPanel'); if(!panel)return;
  const put=(id,value)=>{const el=$(id);if(el)el.textContent=value;};
  try{
    const data=await readApiJson(await fetch(`${API}/api/scout/brain/status`));
    const h=data.historical_learning||{}, f=data.forecast_feedback||{};
    const stateFa={starting:'در صف شروع یادگیری',running:'در حال بررسی آرشیو',completed:'یادگیری تاریخی کامل شد',completed_cached:'حافظه تاریخی بازیابی شد',no_symbols:'نماد معتبر پیدا نشد',no_history_archive:'آرشیو تاریخی موجود نیست',not_started:'شروع نشده',error:'خطا در یادگیری'};
    const hasUsableHistory=Number(h.symbols||0)>0 && Number(h.candles||0)>0;
    const displayedState=(!hasUsableHistory && ['completed','completed_cached'].includes(h.status))?'no_symbols':(stateFa[h.status]||h.status||'نامشخص');
    put('scoutBrainState',displayedState);
    put('brainHistState',displayedState);
    const progress=Math.max(0,Math.min(100,Number(h.progress_pct||0)));
    const progressStages={checking_cache:'بررسی حافظهٔ یادگیری',loading_archive:'بارگذاری آرشیو تاریخی',scanning_patterns:'تحلیل موازی الگوهای پامپ و دامپ',saving_cache:'ذخیرهٔ نتایج یادگیری',cache_ready:'حافظهٔ تاریخی آماده است',complete:'یادگیری تاریخی کامل شد',blocked:'آرشیو تاریخی در دسترس نیست',error:'خطا در یادگیری'};
    put('brainProgressLabel',progressStages[h.stage]||'آماده‌سازی موتور یادگیری');
    put('brainProgressPct',`${progress.toLocaleString('fa-IR')}٪`);
    const progressBar=$('brainLearningProgress');
    if(progressBar){progressBar.value=progress;progressBar.setAttribute('aria-valuetext',`${progress}%`);}
    put('brainPumpCount',Number(h.pump_events||0).toLocaleString('fa-IR'));
    put('brainDumpCount',Number(h.dump_events||0).toLocaleString('fa-IR'));
    put('brainPatternCount',Number(h.patterns||0).toLocaleString('fa-IR'));
    const horizons=f.horizons||{}; let resolved=0;
    Object.values(horizons).forEach(x=>resolved+=Number(x.resolved||0));
    put('brainResolvedCount',resolved.toLocaleString('fa-IR'));
    put('brainPendingCount',Number(f.pending||0).toLocaleString('fa-IR'));
    const elapsed=h.started_ts&&h.finished_ts?` · زمان بررسی ${(Math.max(0,h.finished_ts-h.started_ts)).toFixed(1)} ثانیه`:'';
    const cache=h.cache_hit?' · بازیابی از حافظه ذخیره‌شده':'';
    const engine=h.accelerator?` · موتور ${h.accelerator==='numpy'?'NumPy شتاب‌دهنده':'پایتون پایه'} · ${Number(h.workers||0).toLocaleString('fa-IR')} پردازشگر`:'';
    const throughput=h.status==='running'?` · نماد ${Number(h.symbols_done||0).toLocaleString('fa-IR')}/${Number(h.symbols_total||0).toLocaleString('fa-IR')}${engine}`:engine;
    const detail=`نمادهای معتبر ۱ساعته: ${Number(h.symbols||0).toLocaleString('fa-IR')} · کندل‌های معتبر: ${Number(h.candles||0).toLocaleString('fa-IR')}${throughput}${elapsed}${cache}`;
    put('brainHistoryDetail',h.error?`خطا: ${h.error}`:detail);
    const byH=['1h','4h','24h'].map(k=>`${k}: ${Number(horizons[k]?.resolved||0).toLocaleString('fa-IR')} ارزیابی`).join(' · ');
    put('brainFeedbackDetail',`ارزیابی پیش‌بینی‌ها: ${byH} · موارد فاقد مشاهده معتبر از آمار موفقیت حذف می‌شوند.`);
  }catch(e){put('scoutBrainState','گزارش موقتاً در دسترس نیست');}
}

function initStorm(){
  if(!$('stormBanner')) return;
  const soe = $('stormOnlyEarly');
  if(soe) soe.onchange = () => { if(stormLastData) renderStorm(stormLastData); };
  $('stormRefresh').onclick = async () => {
    $('stormRefresh').disabled = true;
    try{ await readApiJson(await fetch(`${API}/api/scout/refresh`, {method:'POST'})); log('دیده‌بان طوفان: بررسی دستی شروع شد…'); }
    catch(e){ log('شروع بررسی دستی ناموفق بود: ' + e.message); }
    setTimeout(() => $('stormRefresh').disabled = false, 4000);
  };
  $('stormClose').onclick = () => { stormDismissedAt = stormLastSeenTs; $('stormBanner').hidden = true; };
  pollStorm();
  pollScoutBrainStatus();
  pollScoutFollowups();
  const notifyBtn=$('scoutFollowupNotify');
  if(notifyBtn) notifyBtn.onclick=async()=>{
    if(!window.Notification){log('مرورگر از اعلان دسکتاپ پشتیبانی نمی‌کند.');return;}
    const permission=await Notification.requestPermission();
    log(permission==='granted'?'اعلان حرکت‌های صعودی و نزولی دیرهنگام فعال شد.':'مجوز اعلان داده نشد.');
  };
  setInterval(pollStorm, 30 * 1000);
  setInterval(pollScoutFollowups, 60 * 1000);
  setInterval(pollScoutBrainStatus, 5 * 1000);
}

// ---------------- V19.2: trending coins ----------------
let trendData = null;

function ensureSymbol(sym){
  sym = String(sym || '').toUpperCase();
  if(!sym) return;
  if(!(symbolsData.crypto || []).includes(sym)){
    symbolsData.crypto.push(sym);
    const og = $('symbol').querySelector('optgroup');
    if(og){ const o = document.createElement('option'); o.value = sym; o.textContent = sym; og.appendChild(o); }
  }
  const box = $('lrSymbolsList');
  if(box && !box.querySelector(`.lrSym[value="${sym}"]`)){
    const lab = document.createElement('label');
    lab.className = 'lr-sym-item'; lab.dataset.sym = sym; lab.dataset.group = 'crypto';
    lab.innerHTML = `<input type="checkbox" class="lrSym" value="${esc(sym)}"> <span>${esc(sym)}</span>`;
    box.appendChild(lab);
    lab.querySelector('.lrSym').addEventListener('change', updateLrSymbolsCount);
  }
}

function analyzeTrend(sym){
  ensureSymbol(sym);
  $('symbol').value = sym;
  onSymbolChange();
  runAnalyze();
}

function addTrendToLearn(sym, quiet){
  ensureSymbol(sym);
  const cb = document.querySelector(`.lrSym[value="${sym}"]`);
  if(cb) cb.checked = true;
  $('symbol').value = sym;            // also ready for «یادگیری تکی»
  updateLrSymbolsCount();
  if(!quiet) log(`➕ ${sym} به فهرست آموزش چندساعته اضافه شد و برای یادگیری تکی انتخاب شد.`);
}

function renderTrending(){
  const list = $('trendList'), hint = $('trendHint');
  if(!list || !trendData) return;
  const mode = $('trendMode').value;
  const rows = trendData[mode] || [];
  hint.textContent = `منبع: ${trendData.source || 'Binance'} · ${trendData.universe || 0} ارز با حجم کافی (≥ ${(trendData.min_quote_volume/1e6).toFixed(0)}M USDT در ۲۴س)`;
  if(!rows.length){ list.innerHTML = '<div class="note">موردی یافت نشد.</div>'; return; }
  list.innerHTML = rows.map(r => {
    const up = r.change_pct >= 0;
    const vol = r.quote_volume >= 1e9 ? (r.quote_volume/1e9).toFixed(2)+'B' : (r.quote_volume/1e6).toFixed(0)+'M';
    return `<div class="trend-row">
      <span class="trend-sym">${esc(r.base)}</span>
      <span class="${up ? 'up' : 'down'}">${up ? '+' : ''}${Number(r.change_pct).toFixed(2)}٪</span>
      <span class="note">حجم ${esc(vol)}</span>
      <span class="trend-actions">
        <button type="button" class="trend-btn" data-act="analyze" data-sym="${esc(r.symbol)}">تحلیل</button>
        <button type="button" class="trend-btn" data-act="learn" data-sym="${esc(r.symbol)}">➕ آموزش</button>
      </span>
    </div>`;
  }).join('');
  list.querySelectorAll('.trend-btn').forEach(b => b.onclick = () =>
    b.dataset.act === 'analyze' ? analyzeTrend(b.dataset.sym) : addTrendToLearn(b.dataset.sym));
}

async function loadTrending(force){
  const hint = $('trendHint');
  try{
    if(hint) hint.textContent = 'در حال دریافت…';
    const r = await fetch(`${API}/api/trending?limit=12${force ? '&refresh=1' : ''}`);
    trendData = await readApiJson(r);
    renderTrending();
  }catch(e){
    if(hint) hint.textContent = 'دریافت ارزهای ترند ناموفق بود (احتمالاً نیاز به VPN): ' + e.message;
    const list = $('trendList'); if(list) list.innerHTML = '';
  }
}

function initTrending(){
  const panel = $('trendPanel');
  if(!panel) return;
  let initialized = false;
  let refreshTimer = null;
  $('trendMode').onchange = renderTrending;
  $('trendRefresh').onclick = () => loadTrending(true);
  $('trendAddTop').onclick = () => {
    const top = ((trendData && trendData.trending) || []).slice(0, 5);
    if(!top.length){ log('اول فهرست ترند باید بارگذاری شود.'); return; }
    top.forEach(r => addTrendToLearn(r.symbol, true));
    log(`➕ ${top.length} ارز ترند به آموزش چندساعته اضافه شد: ${top.map(r=>r.base).join('، ')}`);
  };
  panel.addEventListener('toggle', () => {
    if(panel.open){
      if(!initialized){ initialized = true; loadTrending(false); }
      if(!refreshTimer) refreshTimer = setInterval(() => {
        if(panel.open) loadTrending(false);
      }, 5 * 60 * 1000);
    } else if(refreshTimer){
      clearInterval(refreshTimer);
      refreshTimer = null;
    }
  });
}

function renderAnalystReport(report){
  const body = $('analystBody');
  const engine = $('analystEngine');
  if (!body) return;
  if (!report){
    body.innerHTML = '<div class="note">پس از تحلیل، گزارش خودکار ساخته می‌شود.</div>';
    if (engine) engine.textContent = '—';
    return;
  }
  if (engine){
    const eng = String(report.engine || 'local');
    engine.textContent = eng.startsWith('glm') ? 'GLM' : 'محلی';
    engine.className = 'engine-badge ' + (eng.startsWith('glm') ? 'glm' : 'local');
  }
  const verdict = report.verdict ? `<div class="verdict-box">${esc(report.verdict)}</div>` : '';
  const sections = (report.sections || []).map(s => `
    <div class="rep-section">
      <h4>${esc(s.title)}</h4>
      <div class="rep-body">${String(s.body || '').split('\n').map(line => `<p>${esc(line)}</p>`).join('')}</div>
    </div>`).join('');
  const note = report.note ? `<div class="note rep-note">${esc(report.note)}</div>` : '';
  body.innerHTML = verdict + sections + note +
    `<div class="note rep-disclaimer">${esc(report.disclaimer || '')}</div>`;
}

async function requestDeepReport(){
  const btn = $('analystDeep');
  if (!btn) return;
  if (!lastSignal){ log('اول یک تحلیل اجرا کن، بعد گزارش عمیق بگیر.'); return; }
  const symbol = $('symbol').value, timeframe = $('tf').value;
  const limit = +($('limit').value || 1500);
  const source = $('source').value;
  const threshold = lastThreshold || parseFloat($('threshold').value);
  const strength = $('strength') ? $('strength').value : 'balanced';
  btn.disabled = true;
  const old = btn.textContent;
  btn.textContent = 'در حال ساخت گزارش عمیق…';
  const body = $('analystBody');
  if (body) body.innerHTML = '<div class="note">در حال گفتگو با GLM… معمولاً چند ثانیه طول می‌کشد.</div>';
  try {
    const r = await fetch(API + '/api/analyst/report', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({symbol, timeframe, limit, source, threshold, strength, deep: true})
    });
    const d = await r.json();
    if (!r.ok){ throw new Error(d.error || 'خطا'); }
    renderAnalystReport(d.report);
    log(`گزارش عمیق ساخته شد (${(d.report && d.report.engine) || 'local'}).`);
  } catch(e){
    log('✖ گزارش عمیق: ' + e.message);
    if (body) body.innerHTML = `<div class="note">گزارش عمیق ناموفق بود: ${esc(e.message)}</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = old;
  }
}

async function loadAnalystStatus(){
  const btn = $('analystDeep');
  const hint = $('analystHint');
  if (!btn || !hint) return;
  try {
    const r = await fetch(API + '/api/analyst/status');
    const d = await r.json();
    if (d.available){ hint.textContent = 'گزارش عمیق GLM فعال است.'; }
    else { hint.textContent = d.note || 'برای گزارش عمیق، ZAI_API_KEY را در .env تنظیم کن.'; }
  } catch(e){ hint.textContent = 'وضعیت گزارش عمیق نامشخص است.'; }
}

function renderSignal(sig){
  const card = $('signalCard'), badge = $('sigBadge');
  card.className = 'sigcard ' + sig.kind.toLowerCase();
  badge.className = 'sigbadge ' + sig.kind.toLowerCase();
  const advTag = sig.advisory ? ' (مشورتی)' : '';
  if(sig.kind === 'BUY'){
    badge.textContent = '🟢 BUY / خرید' + advTag;
    $('sigPower').textContent = (sig.power*100).toFixed(0) + '%';
    $('sigPower').className = 'up';
  } else if(sig.kind === 'SELL'){
    badge.textContent = '🔴 SELL / فروش' + advTag;
    $('sigPower').textContent = (sig.power*100).toFixed(0) + '%';
    $('sigPower').className = 'down';
  } else {
    badge.textContent = '⏸ HOLD / صبر' + advTag;
    $('sigPower').textContent = (sig.power*100).toFixed(0) + '%';
    $('sigPower').className = 'neutral';
  }
  const provisional = Boolean(sig.levels_provisional || sig.kind === 'HOLD');
  $('sigEntry').textContent = fmt(sig.entry);
  $('sigTp').textContent = fmt(sig.tp);
  $('sigSl').textContent = fmt(sig.sl);
  $('sigEntryLabel').textContent = provisional ? 'قیمت مبنا' : 'ورود';
  $('sigTpLabel').textContent = provisional ? 'هدف سناریویی' : 'حد سود (TP)';
  $('sigSlLabel').textContent = provisional ? 'حد ضرر سناریویی' : 'حد ضرر (SL)';
  const list = (sig.reasons||[]).map(r => `<li class="${esc(r[0])}">${r[0]==='pos'?'✔':r[0]==='neg'?'✖':'•'} ${esc(r[1])}</li>`).join('');
  let agreeHtml = '';
  if (sig.agreement) {
    const lbl = sig.agreement === 'high' ? 'بالا ✓ (مدل‌های داخلی هم‌رأیی‌اند — قابل اعتمادتر)'
              : sig.agreement === 'medium' ? 'متوسط'
              : 'پایین ⚠ (مدل‌های داخلی اختلاف دارند — احتیاط)';
    agreeHtml = `<div class="note" style="margin-top:6px">هم‌رأیی مدل‌ها: <strong>${lbl}</strong> (انحراف: ${(sig.agreement_std||0).toFixed(3)})</div>`;
  }
  let poolHtml = '';
  if (sig.pool_consensus && sig.pool_consensus.n) {
    const pc = sig.pool_consensus;
    const dirFa = pc.consensus_dir === 'UP' ? 'صعودی' : 'نزولی';
    poolHtml = `<div class="note" style="margin-top:6px">🧠 اجماع همه آموزش‌ها: <strong>${pc.n} مدل رای دادند</strong> · تمایل ${dirFa} · P=${Number(pc.consensus_prob).toFixed(3)} · هم‌جهتی ${(pc.agreement*100).toFixed(0)}٪` +
      (pc.blend_weight ? ` · وزن ترکیب در احتمال نهایی: ${(pc.blend_weight*100).toFixed(0)}٪` : '') + `</div>`;
  }
  $('sigReason').innerHTML = `
    <div style="margin-bottom:6px"><strong>${esc(sig.reason)}</strong></div>
    ${provisional ? `<div class="note">سطوح نمایش‌داده‌شده فقط سناریوی مرجع ${sig.levels_side === 'SHORT' ? 'نزولی' : 'صعودی'} هستند و به معنی توصیه به ورود نیستند.</div>` : ''}
    <div class="note">امتیاز صعود: ${sig.bull_score.toFixed(1)} · امتیاز نزول: ${sig.bear_score.toFixed(1)} · خالص: ${sig.net_score.toFixed(1)}</div>
    ${agreeHtml}
    ${poolHtml}
    <ul>${list}</ul>
  `;
  const stLbl = {conservative:'محافظه‌کارانه', balanced:'متعادل', assertive:'جسورانه'}[sig.strength_profile] || sig.strength_profile || 'متعادل';
  const stNote = $('sigStrengthNote');
  if (stNote) {
    stNote.textContent = `قدرت سیگنال فعال: ${stLbl}` +
      (sig.strength_profile === 'assertive' ? ' (حداقل‌های اجماع پایین‌ترند؛ گیت برتری خارج‌ازنمونه همچنان فعال است)' : '') +
      (sig.brain_confirmed ? ' · تأیید مغز مرکزی ✓' : '');
  }
}

function renderIndicators(ind){
  const fields = [
    ['RSI (14)', ind.rsi_14, v => v.toFixed(1) + (v>70?' اشباع خرید':v<30?' اشباع فروش':'')],
    ['RSI (7)', ind.rsi_7, v => v.toFixed(1)],
    ['RSI (21)', ind.rsi_21, v => v.toFixed(1)],
    ['EMA 20', ind.ema_20, v => fmt(v)],
    ['EMA 50', ind.ema_50, v => fmt(v)],
    ['EMA 100', ind.ema_100, v => fmt(v)],
    ['EMA 200', ind.ema_200, v => fmt(v)],
    ['MACD خط', ind.macd_line, v => fmt(v)],
    ['MACD سیگنال', ind.macd_signal, v => fmt(v)],
    ['MACD هیستوگرام', ind.macd_hist, v => fmt(v) + (v>0?' +':v<0?' -':'')],
    ['Stochastic %K', ind.stoch_k, v => v.toFixed(1)],
    ['Stochastic %D', ind.stoch_d, v => v.toFixed(1)],
    ['Williams %R', ind.williams_r_14, v => v.toFixed(1)],
    ['CCI (20)', ind.cci_20, v => v.toFixed(1)],
    ['ATR (14)', ind.atr_14, v => fmt(v)],
    ['ATR (7)', ind.atr_7, v => fmt(v)],
    ['Bollinger %', ind.bb_pct, v => (v*100).toFixed(1) + '%'],
    ['Bollinger Width', ind.bb_width, v => v.toFixed(4)],
    ['MFI (14)', ind.mfi_14, v => v.toFixed(1)],
    ['CMF (20)', ind.cmf_20, v => v.toFixed(3)],
    ['ADX (14)', ind.adx_14, v => v.toFixed(1) + (v>25?' روند قوی':'')],
    ['+DI', ind.plus_di, v => v.toFixed(1)],
    ['-DI', ind.minus_di, v => v.toFixed(1)],
    ['Aroon Up', ind.aroon_up, v => v.toFixed(1)],
    ['Aroon Down', ind.aroon_down, v => v.toFixed(1)],
    ['Supertrend', ind.supertrend, v => v > 0 ? 'صعودی 🟢' : 'نزولی 🔴'],
    ['Ichimoku Tenkan', ind.ich_tenkan, v => fmt(v)],
    ['Ichimoku Kijun', ind.ich_kijun, v => fmt(v)],
    ['Coppock', ind.coppock, v => v.toFixed(2)],
    ['TSI', ind.tsi, v => v.toFixed(2)],
    ['Ultimate Osc', ind.uo, v => v.toFixed(1)],
    ['OBV', ind.obv, v => fmt(v)],
    ['Force Index', ind.force_index_13, v => fmt(v)],
  ];
  const rows = fields.filter(f => f[1] != null && !isNaN(f[1]))
    .map(f => `<tr><td>${f[0]}</td><td>${f[2](f[1])}</td></tr>`);
  $('indicators').innerHTML = '<tbody>' + (rows.length ? rows.join('') : '<tr><td class="note">داده‌ای موجود نیست</td></tr>') + '</tbody>';
}

function renderHistory(hist){
  const tb = $('sigHistory');
  if(!hist.length){
    tb.innerHTML = '<tr><td colspan="8" class="note">در بازه فعلی سیگنال تأییدشده‌ای ثبت نشد.</td></tr>';
    return;
  }
  tb.innerHTML = hist.map((h,i) => {
    const t = new Date(h.ts).toLocaleString('fa-IR', {month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});
    const cls = h.kind === 'BUY' ? 'buy' : 'sell';
    const resCls = h.result === 'win' ? 'win' : h.result === 'loss' ? 'loss'
                 : h.result === 'ambiguous' ? 'neutral' : 'open';
    const resTxt = h.result === 'win' ? 'برد ✔' : h.result === 'loss' ? 'باخت ✖'
                 : h.result === 'ambiguous' ? 'مبهم ~' : 'باز';
    const ret = (h.result === 'open' || h.result === 'ambiguous')
      ? '—' : (h.ret_pct>=0?'+':'') + h.ret_pct.toFixed(2) + '%';
    return `<tr>
      <td>${i+1}</td>
      <td>${t}</td>
      <td class="${cls}">${h.kind}</td>
      <td>${fmt(h.entry)}</td>
      <td class="up">${fmt(h.tp)}</td>
      <td class="down">${fmt(h.sl)}</td>
      <td class="${resCls}" title="مبهم: در یک کندل هم حد سود و هم حد ضرر لمس شده — ترتیب برخورد از OHLC معلوم نیست">${resTxt}</td>
      <td class="${resCls}">${ret}</td>
    </tr>`;
  }).join('');
}

// ============ Chart (TradingView Lightweight Charts) ============
let tvChart = null;
let tvCandleSeries = null;
let tvVolumeSeries = null;
let tvEma20 = null;
let tvEma50 = null;
let tvMarkers = [];
// V20: precision, analysis price lines, manual trendlines, OHLC hover legend
let tvPriceLines = [];
let tvTrendLines = [];
let tvDrawing = false;
let tvDrawPoint1 = null;
let tvChartTimes = [];
let tvLastPrecision = 2;
let tvDrawCtx = null;

function emaSeries(values, period){
  const k=2/(period+1), out=[]; let prev=null;
  values.forEach(value=>{ const v=Number(value); prev=prev==null?v:(v*k+prev*(1-k)); out.push(prev); });
  return out;
}

function toUnix(ts){
  const n = Number(ts);
  if(!Number.isFinite(n)) return null;
  return n > 1e12 ? Math.floor(n/1000) : Math.floor(n);
}

function destroyTvChart(){
  if(tvChart){
    try{ tvChart.remove(); }catch(_){}
  }
  tvChart = null; tvCandleSeries = null; tvVolumeSeries = null; tvEma20 = null; tvEma50 = null;
  tvPriceLines = []; tvTrendLines = []; tvDrawing = false; tvDrawPoint1 = null; tvChartTimes = [];
}

function ensureTvChart(){
  const el = $('tvChart');
  if(!el) return null;
  if(tvChart) return tvChart;
  if(typeof LightweightCharts === 'undefined'){
    el.innerHTML = '<div class="note" style="padding:20px">کتابخانه نمودار بارگذاری نشد. اتصال اینترنت را بررسی کن.</div>';
    return null;
  }
  tvChart = LightweightCharts.createChart(el, {
    layout: {
      background: { type: 'solid', color: '#091321' },
      textColor: '#a8bad2',
      fontFamily: 'Tahoma, Vazirmatn, sans-serif',
    },
    grid: {
      vertLines: { color: 'rgba(94,121,155,.12)', style: 2 },
      horzLines: { color: 'rgba(94,121,155,.16)', style: 2 },
    },
    crosshair: {
      mode: LightweightCharts.CrosshairMode.Normal,
      vertLine: { color: 'rgba(85,214,232,.55)', width: 1, style: 2, labelBackgroundColor: '#1a2a3d' },
      horzLine: { color: 'rgba(85,214,232,.55)', width: 1, style: 2, labelBackgroundColor: '#1a2a3d' },
    },
    rightPriceScale: {
      borderColor: 'rgba(94,121,155,.35)',
      scaleMargins: { top: 0.10, bottom: 0.24 },
      minimumWidth: 72,
      entireTextOnly: true,
    },
    timeScale: {
      borderColor: 'rgba(94,121,155,.35)',
      timeVisible: true,
      secondsVisible: false,
      rightOffset: 7,
      barSpacing: 8,
      minBarSpacing: 3,
      fixLeftEdge: true,
      lockVisibleTimeRangeOnResize: true,
      tickMarkFormatter: (time) => {
        if (typeof time === 'number') { const d = new Date(time * 1000); return d.toLocaleString('fa-IR', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }); }
        return '';
      },
    },
    handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: true },
    handleScale: { axisPressedMouseMove: true, mouseWheel: true, pinch: true },
  });
  tvCandleSeries = tvChart.addCandlestickSeries({
    upColor: '#16c79a', downColor: '#f05d75',
    borderUpColor: '#16c79a', borderDownColor: '#f05d75',
    wickUpColor: '#16c79a', wickDownColor: '#f05d75',
    lastValueVisible: true, priceLineVisible: true,
  });
  tvVolumeSeries = tvChart.addHistogramSeries({
    priceFormat: { type: 'volume' },
    priceScaleId: '',
    scaleMargins: { top: 0.82, bottom: 0 },
  });
  tvEma20 = tvChart.addLineSeries({ color: '#f2bd63', lineWidth: 2, priceScaleId: 'right', lastValueVisible: false, priceLineVisible: false, crosshairMarkerVisible: false });
  tvEma50 = tvChart.addLineSeries({ color: '#91a4ff', lineWidth: 2, priceScaleId: 'right', lastValueVisible: false, priceLineVisible: false, crosshairMarkerVisible: false });
  // V20: manual trendline drawing + OHLC hover legend
  tvChart.subscribeClick(onChartClick);
  tvChart.subscribeCrosshairMove(updateOhlcLegend);
  const resizeChart = ()=>{
    if(!tvChart || !el) return;
    tvChart.applyOptions({ width: el.clientWidth, height: Math.max(360, el.clientHeight || 460) });
  };
  if(typeof ResizeObserver !== 'undefined'){
    const ro = new ResizeObserver(resizeChart);
    ro.observe(el);
  } else {
    window.addEventListener('resize', resizeChart);
  }
  resizeChart();
  return tvChart;
}

function setupChartInteractions(){
  // Lightweight Charts handles crosshair, zoom, pan natively.
  ensureTvChart();
}

function formatChartStat(value){
  const n = Number(value);
  if(!Number.isFinite(n)) return '—';
  return n.toLocaleString('en-US',{maximumFractionDigits: pricePrecisionFor([n]), minimumFractionDigits: 0});
}
function updateChartQuickStats(candles){
  if(!candles || !candles.length) return;
  const last = candles[candles.length-1];
  const prev = candles.length > 1 ? candles[candles.length-2] : null;
  const change = prev && Number(prev.close) ? ((last.close-prev.close)/prev.close)*100 : null;
  const high = Math.max(...candles.map(c=>Number(c.high)).filter(Number.isFinite));
  const low = Math.min(...candles.map(c=>Number(c.low)).filter(Number.isFinite));
  const put=(id,value,cls='')=>{const el=$(id);if(el){el.textContent=value;el.className=cls;}};
  put('chartStatPrice',formatChartStat(last.close));
  put('chartStatChange',change==null?'—':`${change>=0?'+':''}${change.toFixed(2)}٪`,change==null?'':change>=0?'up':'down');
  put('chartStatHigh',formatChartStat(high));
  put('chartStatLow',formatChartStat(low));
  put('chartStatVolume',Number(last.volume||0).toLocaleString('en-US',{maximumFractionDigits:2}));
}

function drawChart(){
  if(!lastCandles || !lastCandles.length) return;
  const chart = ensureTvChart();
  if(!chart || !tvCandleSeries) return;

  const requested = Number($('chartRange')?.value || 100);
  const arr = lastCandles.slice(-Math.min(requested, lastCandles.length));
  if(!arr.length) return;

  const candles = [];
  const volumes = [];
  const closes = [];
  arr.forEach(c=>{
    const t = toUnix(c.t);
    if(t == null) return;
    const o=+c.o, h=+c.h, l=+c.l, cl=+c.c, v=+c.v||0;
    candles.push({ time: t, open: o, high: h, low: l, close: cl, volume: v });
    volumes.push({ time: t, value: v, color: cl >= o ? 'rgba(32,201,151,.35)' : 'rgba(255,101,122,.35)' });
    closes.push(cl);
  });
  if(!candles.length) return;

  // V20: full decimal precision — give every price series enough digits based on
  // the smallest price magnitude on screen (fixes truncated decimals).
  const prec = pricePrecisionFor([...closes, ...candles.map(c=>c.high), ...candles.map(c=>c.low)]);
  tvLastPrecision = prec;
  const pf = { type: 'price', precision: prec, minMove: Math.pow(10, -prec) };
  tvCandleSeries.applyOptions({ priceFormat: pf });
  tvEma20.applyOptions({ priceFormat: pf });
  tvEma50.applyOptions({ priceFormat: pf });

  tvCandleSeries.setData(candles);
  tvVolumeSeries.setData(volumes);

  tvChartTimes = candles.map(c=>c.time);
  updateChartQuickStats(candles);
  // V20: trendlines belong to a market — clear them when symbol/timeframe changes
  const drawCtx = ($('symbol')?.value||'') + '|' + ($('chartTf')?.value||'');
  if(tvDrawCtx && tvDrawCtx !== drawCtx && tvTrendLines.length){
    tvTrendLines.forEach(s=>{ try{ tvChart.removeSeries(s); }catch(_){}});
    tvTrendLines = [];
    log('خطوط روند به‌خاطر تغییر بازار پاک شدند.');
  }
  tvDrawCtx = drawCtx;

  const e20 = emaSeries(closes, 20);
  const e50 = emaSeries(closes, 50);
  tvEma20.setData(candles.map((c,i)=>({ time: c.time, value: e20[i] })));
  tvEma50.setData(candles.map((c,i)=>({ time: c.time, value: e50[i] })));

  // Signal markers from history
  const markers = [];
  const tsMap = new Map(candles.map((c,i)=>[c.time, i]));
  (lastHistory||[]).forEach(h=>{
    const t = toUnix(h.ts);
    if(t == null || !tsMap.has(t)) return;
    const buy = h.kind === 'BUY';
    markers.push({
      time: t,
      position: buy ? 'belowBar' : 'aboveBar',
      color: buy ? '#20c997' : '#ff657a',
      shape: buy ? 'arrowUp' : 'arrowDown',
      text: buy ? 'خرید' : 'فروش',
    });
  });
  // Current signal
  const sig = lastSignal || {};
  if(sig.kind === 'BUY' || sig.kind === 'SELL'){
    const lastT = candles[candles.length-1].time;
    markers.push({
      time: lastT,
      position: sig.kind === 'BUY' ? 'belowBar' : 'aboveBar',
      color: sig.kind === 'BUY' ? '#20c997' : '#ff657a',
      shape: sig.kind === 'BUY' ? 'arrowUp' : 'arrowDown',
      text: sig.kind === 'BUY' ? 'سیگنال خرید' : 'سیگنال فروش',
    });
  }
  markers.sort((a,b)=> a.time - b.time);
  tvCandleSeries.setMarkers(markers);

  // V20: نتیجه تحلیل روی نمودار — خطوط افقی ورود/TP/SL/ابطال + نشانگرها
  clearTvPriceLines();
  addSignalPriceLines(sig);

  chart.timeScale().fitContent();

  const sub = $('chartSubtitle');
  const tf = $('chartTf')?.value || $('tf')?.value || '';
  const pUp = Number(lastProb || 0.5);
  if(sub){
    sub.textContent = `${$('symbol')?.value||''} · ${tf} · ${candles.length} کندل · احتمال صعود ${(pUp*100).toFixed(1)}٪ · احتمال نزول ${((1-pUp)*100).toFixed(1)}٪`;
  }
  const foot = $('chartFootnote');
  const isTrade = sig && (sig.kind === 'BUY' || sig.kind === 'SELL');
  if(foot){
    foot.textContent = isTrade
      ? `مدل ${sig.kind} داده است؛ خطوط ورود/TP/SL روی نمودار رسم شدند. زوم با اسکرول ماوس، جابه‌جایی با درگ.`
      : 'نمودار حرفه‌ای با TradingView Lightweight Charts · زوم و اسکرول فعال · هنوز سیگنال ورود معتبر نیست.';
  }
  updateChartSigOverlay();
}

// ---------- V20: precision, analysis price lines, trendline tool, OHLC legend ----------
function pricePrecisionFor(values){
  let min = Infinity;
  for(const v of values){
    const x = Math.abs(Number(v));
    if(x > 0 && isFinite(x) && x < min) min = x;
  }
  if(!isFinite(min)) return 2;
  let p = 2;
  if(min >= 100) p = 2;
  else if(min >= 10) p = 3;
  else if(min >= 1) p = 4;
  else if(min >= 0.01) p = 6;
  else if(min >= 0.0001) p = 8;
  else p = 10;
  return Math.min(p, 10);
}

function clearTvPriceLines(){
  if(!tvCandleSeries) return;
  tvPriceLines.forEach(l=>{ try{ tvCandleSeries.removePriceLine(l); }catch(_){}});
  tvPriceLines = [];
}

function addSignalPriceLines(sig){
  if(!tvCandleSeries || !sig) return;
  const mk = (price, color, title) => {
    const v = Number(price);
    if(price == null || !isFinite(v) || v <= 0) return;
    tvPriceLines.push(tvCandleSeries.createPriceLine({
      price: v, color, lineWidth: 1, lineStyle: 2,
      axisLabelVisible: true, title,
    }));
  };
  const isTrade = sig.kind === 'BUY' || sig.kind === 'SELL';
  if(isTrade){
    mk(sig.entry, '#55d6e8', 'ورود');
    mk(sig.tp, '#20c997', 'TP');
    mk(sig.sl, '#ff657a', 'SL');
    const inv = sig.scenario ? sig.scenario.invalidation : null;
    mk(inv, '#f4bd60', 'ابطال');
  } else if(sig.entry != null){
    mk(sig.entry, 'rgba(143,162,189,.85)', 'مبنای قیمت');
  }
}

function updateChartSigOverlay(){
  const el = $('chartSigOverlay');
  if(!el) return;
  const sig = lastSignal;
  if(!sig || !lastCandles.length){ el.hidden = true; return; }
  const isTrade = sig.kind === 'BUY' || sig.kind === 'SELL';
  const cls = sig.kind === 'BUY' ? 'buy' : sig.kind === 'SELL' ? 'sell' : 'hold';
  const rr = (sig.scenario && sig.scenario.reward_risk != null) ? Number(sig.scenario.reward_risk).toFixed(2) : null;
  const pUp = Number(lastProb || 0.5);
  el.innerHTML =
    `<span class="cs-badge ${cls}">${sig.kind === 'BUY' ? '🟢 BUY' : sig.kind === 'SELL' ? '🔴 SELL' : '⏸ HOLD'} · قدرت ${(Number(sig.power||0)*100).toFixed(0)}٪</span>` +
    `<span class="cs-chip">احتمال صعود ${(pUp*100).toFixed(1)}٪</span>` +
    `<span class="cs-chip">ورود ${fmt(sig.entry)}</span>` +
    (isTrade
      ? `<span class="cs-chip tp">TP ${fmt(sig.tp)}</span><span class="cs-chip sl">SL ${fmt(sig.sl)}</span>` +
        (rr ? `<span class="cs-chip">پاداش/ریسک ${rr}</span>` : '')
      : '');
  el.hidden = false;
}

function toggleTrendDraw(){
  tvDrawing = !tvDrawing;
  tvDrawPoint1 = null;
  const btn = $('trendDraw');
  if(btn) btn.classList.toggle('active', tvDrawing);
  const stage = $('chartStage');
  if(stage) stage.classList.toggle('drawing', tvDrawing);
  const foot = $('chartFootnote');
  if(foot) foot.textContent = tvDrawing
    ? '📈 حالت خط روند فعال — دو نقطه کلیک کن؛ خط تا ۶ کندل بعد از لبه راست امتداد می‌یابد. (خروج با همان دکمه)'
    : 'زوم با اسکرول · درگ برای جابه‌جایی · کراس‌هیر فعال · دکمه «خط روند» برای رسم خط دستی.';
  log(tvDrawing ? '📈 حالت خط روند فعال شد: نقطه اول و دوم را روی نمودار کلیک کن. (خروج: دوباره دکمه را بزن)'
                : 'حالت خط روند خاموش شد.');
}

function undoLastTrendLine(){
  const s = tvTrendLines.pop();
  if(!s){ log('خطی برای حذف نیست.'); return; }
  try{ tvChart.removeSeries(s); log('آخرین خط روند حذف شد.'); }catch(_){}
}

function clearTrendLines(){
  if(!tvTrendLines.length){ log('خطی برای پاک‌کردن نیست.'); return; }
  tvTrendLines.forEach(s=>{ try{ tvChart.removeSeries(s); }catch(_){}});
  tvTrendLines = [];
  log('همه خطوط روند پاک شدند.');
}

function snapTimeToBars(t){
  const times = tvChartTimes;
  if(!times || !times.length || t == null || !isFinite(t)) return t;
  const first = times[0], last = times[times.length-1];
  const dt = times.length > 1 ? (last - first) / (times.length - 1) : 3600;
  if(t >= last) return last + Math.max(1, Math.round((t - last) / dt)) * dt;
  if(t <= first) return first;
  const k = Math.round((t - first) / dt);
  return Math.max(first, Math.min(last, first + k * dt));
}

function onChartClick(param){
  if(!tvDrawing || !tvCandleSeries || !param || !param.point) return;
  const price = tvCandleSeries.coordinateToPrice(param.point.y);
  let t = (typeof param.time === 'number') ? param.time : tvChart.timeScale().coordinateToTime(param.point.x);
  if(price == null || !isFinite(price) || t == null || !isFinite(t)) return;
  t = snapTimeToBars(Math.floor(t));
  if(tvDrawPoint1 == null){
    tvDrawPoint1 = { t, price };
    log(`نقطه اول ثبت شد: ${fmt(price)} — حالا نقطه دوم را کلیک کن.`);
    return;
  }
  const p1 = tvDrawPoint1;
  tvDrawPoint1 = null;
  if(Math.abs(t - p1.t) < 1){ tvDrawPoint1 = { t, price }; return; }
  drawTrendLine(p1, { t, price });
}

function drawTrendLine(a, b){
  let t1 = a.t, p1 = a.price, t2 = b.t, p2 = b.price;
  if(t1 > t2){ [t1, p1, t2, p2] = [t2, p2, t1, p1]; }
  const prec = tvLastPrecision || 2;
  const times = tvChartTimes;
  const lastT = times.length ? times[times.length-1] : t2;
  const firstT = times.length ? times[0] : t1;
  const dt = times.length > 1 ? (lastT - firstT) / (times.length - 1) : 3600;
  const t3 = t2 + Math.max(1, Math.round((lastT - t2) / dt) + 6) * dt;   // امتداد تا ۶ کندل بعد از لبه راست
  const slope = (p2 - p1) / (t2 - t1);
  const s = tvChart.addLineSeries({
    color: '#f4bd60', lineWidth: 1, lineStyle: 0,
    priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false,
    priceFormat: { type: 'price', precision: prec, minMove: Math.pow(10, -prec) },
  });
  s.setData([{ time: t1, value: p1 }, { time: t3, value: p1 + slope * (t3 - t1) }]);
  tvTrendLines.push(s);
  log(`📈 خط روند کشیده شد (${fmt(p1)} → ${fmt(p2)}).`);
}

function updateOhlcLegend(param){
  const el = $('ohlcLegend');
  if(!el) return;
  if(!param || param.time == null || !tvCandleSeries){ el.innerHTML = ''; return; }
  const bar = param.seriesData ? param.seriesData.get(tvCandleSeries) : null;
  if(!bar){ el.innerHTML = ''; return; }
  const vol = (param.seriesData && tvVolumeSeries) ? param.seriesData.get(tvVolumeSeries) : null;
  const chg = bar.open ? (bar.close - bar.open) / bar.open * 100 : 0;
  const cls = chg >= 0 ? 'up' : 'down';
  el.innerHTML =
    `<span>O <b>${fmt(bar.open)}</b></span>` +
    `<span>H <b class="up">${fmt(bar.high)}</b></span>` +
    `<span>L <b class="down">${fmt(bar.low)}</b></span>` +
    `<span>C <b class="${cls}">${fmt(bar.close)}</b></span>` +
    `<span class="${cls}">${chg >= 0 ? '+' : ''}${chg.toFixed(2)}٪</span>` +
    (vol ? `<span>حجم <b>${fmtCompact(vol.value)}</b></span>` : '');
}

// Start
window.addEventListener('DOMContentLoaded', init);


// v6: news and macro-event monitor
let newsPollTimer = null;
async function pollNews(){
  const symbolEl=document.getElementById('symbol');
  const symbol=(symbolEl && symbolEl.value) || 'BTCUSDT';
  try{const response=await fetch(`${API}/api/news/impact?symbol=${encodeURIComponent(symbol)}`);
    if(!response.ok)throw new Error(`HTTP ${response.status}`); renderNewsAlert(await response.json());
  }catch(err){const body=document.getElementById('newsBody');if(body)body.textContent='دریافت اخبار موقتاً ناموفق است؛ فیلتر خبری غیرفعال نشده اما داده تازه نداریم.';}
}
function renderNewsAlert(data){
  const panel=document.getElementById('newsPanel'),dot=document.getElementById('newsDot'),body=document.getElementById('newsBody'),updated=document.getElementById('newsUpdated');
  if(!panel||!dot||!body)return; const danger=!!data.block_trading;
  panel.classList.toggle('danger',danger);dot.className='news-dot '+(danger?'danger':'ok');
  if(updated)updated.textContent=new Date().toLocaleTimeString('fa-IR');
  body.replaceChildren();
  const add=(tag,label,text,url)=>{
    const row=document.createElement('div'); row.className='news-item';
    const badge=document.createElement('span'); badge.className='tag '+tag; badge.textContent=label;
    const content=document.createElement(url?'a':'span');
    content.textContent=text;
    if(url){ content.href=url; content.target='_blank'; content.rel='noopener'; content.className='news-link'; }
    row.append(badge,content); body.append(row);
  };
  if(data.alert_text) add('high','هشدار',data.alert_text);
  (data.macro_events||[]).slice(0,6).forEach(e=>{
    const m=Number(e.minutes_away);
    const title = e.title_fa || e.title || 'رویداد اقتصادی';
    add('high','اقتصادی',`${title} (${e.currency||'USD'}) — ${m>=0?`${m} دقیقه دیگر`:`${Math.abs(m)} دقیقه پیش`}`);
  });
  const sent=data.sentiment||{};
  if(sent.label) add(sent.label==='bullish'?'bull':sent.label==='bearish'?'bear':'neutral','احساسات',`${data.asset||''}: ${sent.label_fa || 'خنثی'} (${Number(sent.score||0).toFixed(2)})`);
  (data.breaking||[]).slice(0,6).forEach(a=>{
    const fa = (a.title_fa||'').trim();
    const en = (a.title||'').trim();
    let text = fa;
    if(!text || text.includes('موقتاً در دسترس نیست') || text.includes('عنوانی برای ترجمه')) text = en || 'خبر بدون عنوان';
    else if(en && fa !== en && !fa.includes(en.slice(0,12))) text = fa + (en ? ` · ${en}` : '');
    add('neutral','خبر', text, a.url || null);
  });
  if(data.fear_greed) add('neutral','ترس/طمع',`${data.fear_greed.classification_fa || data.fear_greed.classification || 'خنثی'} (${data.fear_greed.value}/100)`);
  const st = data.sources_status || {};
  const srcParts = [];
  if(st.coindesk_rss) srcParts.push('CoinDesk');
  if(st.fear_greed) srcParts.push('Fear&Greed');
  if(st.macro_calendar) srcParts.push('تقویم اقتصادی');
  if(srcParts.length) add('neutral','منابع', srcParts.join(' · '));
  if(!body.children.length) body.textContent='هشدار فعالی گزارش نشده است. دکمه ↻ را بزن یا چند لحظه صبر کن.';
}

// V22.1 P5: lightweight, read-only observability and experiment performance view.
async function refreshPerformanceCenter(){
  const summary=document.getElementById('performanceSummary');
  const list=document.getElementById('performanceExperiments');
  if(!summary||!list)return;
  summary.textContent='در حال دریافت وضعیت…'; list.textContent='';
  try{
    const [h,p]=await Promise.all([
      fetch(`${API}/api/observability/health`).then(r=>{if(!r.ok)throw new Error('health');return r.json()}),
      fetch(`${API}/api/performance/center`).then(r=>{if(!r.ok)throw new Error('performance');return r.json()})
    ]);
    const free=h.storage?.free_bytes;
    const freeText=Number.isFinite(free)?`${(free/1024/1024/1024).toFixed(1)} GB`:'نامشخص';
    summary.textContent=`وضعیت: ${h.status==='ok'?'سالم':'نیازمند بررسی'} · آموزش: ${h.training?.running?'در حال اجرا':'متوقف'} · مدل‌ها: ${h.models?.count??0} · فضای آزاد: ${freeText} · رویدادهای خطا در نمونه اخیر: ${h.events?.error_events_sampled??0}`;
    const items=p.recent_experiments||[];
    list.textContent=`آزمایش‌ها: ${p.total_experiments_started??0} شروع · ${p.total_experiments_finished??0} پایان · ${p.negative_results_count??0} نتیجه منفی/ناموفق`;
    if(items.length){
      const ul=document.createElement('ul'); ul.style.paddingRight='20px';
      items.slice(0,8).forEach(x=>{const li=document.createElement('li');const metric=Object.entries(x.metrics||{}).slice(0,3).map(([k,v])=>`${k}: ${typeof v==='number'?v.toFixed(3):String(v)}`).join(' · ');li.textContent=`${x.symbol||'—'} ${x.timeframe||''} · ${x.status||'—'} · ${metric}`;ul.append(li)});
      list.append(ul);
    }
    const note=document.createElement('div');note.className='note';note.textContent=p.note||'اطلاعات عملکردی صرفاً توصیفی است.';list.append(note);
  }catch(e){summary.textContent='مرکز پایش فعلاً در دسترس نیست؛ اتصال API را بررسی کنید.';}
}
document.addEventListener('DOMContentLoaded',()=>{
  const btn=document.getElementById('refreshPerformance');
  if(btn)btn.addEventListener('click',refreshPerformanceCenter);
  refreshPerformanceCenter();
});

// V22.6: public new-listing discovery with explicit cold-start / risk labels.
async function refreshNewListings(){
  const box=document.getElementById('newListingList'), meta=document.getElementById('newListingMeta');
  if(!box||!meta)return;
  meta.textContent='در حال جستجو در صرافی‌ها…'; box.textContent='';
  try{
    const r=await fetch(`${API}/api/scout/new-listings?days=30&limit=30`);
    if(!r.ok)throw new Error('منابع در دسترس نیستند');
    const d=await r.json(); const items=d.items||[];
    meta.textContent=`${d.count||0} مورد · ${d.source_ok_count||0} منبع پاسخ‌گو`;
    if(!items.length){box.textContent='در این بررسی، ارز تازه‌وارد با زمان فهرست‌شدن قابل تأیید پیدا نشد.';return;}
    items.forEach(x=>{
      const row=document.createElement('div');row.className='storm-row';
      const age=x.age_days==null?'سن نامشخص':`${x.age_days} روز`;
      const vol=Number(x.quote_volume||0);
      const risk=x.risk==='very_high'?'ریسک بسیار بالا':'ریسک بالا';
      const status=x.status==='cold_start_watch'?'قابل پایش اولیه':x.status==='thin_market'?'نقدشوندگی ناکافی':x.status==='age_unknown'?'زمان لیست نامشخص':'خارج از بازه';
      const label=document.createElement('span');
      label.textContent=`${x.exchange} · ${x.symbol} · ${age} · حجم ۲۴س: ${vol.toLocaleString('en-US',{maximumFractionDigits:0})} USDT · ${risk} · ${status} — ${x.advice}`;
      const analyze=document.createElement('button'); analyze.type='button'; analyze.className='learn'; analyze.textContent='تحلیل سریع';
      analyze.addEventListener('click',()=>analyzeNewListing(x, row, analyze));
      const walls=document.createElement('button'); walls.type='button'; walls.className='learn'; walls.textContent='پایش دیوارها';
      walls.addEventListener('click',()=>monitorNewListingWalls(x,row,walls));
      row.append(label, analyze, walls); box.append(row);
    });
  }catch(e){meta.textContent='خطا در دریافت اطلاعات';box.textContent='اتصال منابع عمومی برقرار نشد؛ بعداً دوباره تلاش کن.';}
}


async function monitorNewListingWalls(item, row, button){
  button.disabled=true; button.textContent='در حال بررسی دفتر…';
  try{
    const q=new URLSearchParams({exchange:item.exchange,symbol:item.symbol,levels:'20'});
    const r=await fetch(`${API}/api/scout/new-listings/walls?${q}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({exchange:item.exchange,symbol:item.symbol,levels:20})});
    const d=await r.json(); if(!r.ok)throw new Error(d.error||d.status||'دفتر سفارش در دسترس نیست');
    const prior=row.querySelector('.wall-watch-result'); if(prior)prior.remove();
    const panel=document.createElement('div');panel.className='note wall-watch-result';
    const c=d.wall_counts||{};
    panel.textContent=`وضعیت دفتر: ${d.status} · دیوار جدید: ${c.appeared||0} · پایدار در snapshot: ${c.persisted||0} · ناپدیدشده: ${c.disappeared||0} · ${d.warning||'تغییر دیوارها به‌تنهایی جهت بازار را اثبات نمی‌کند.'}`;
    row.append(panel);
  }catch(e){button.textContent='خطا؛ تلاش مجدد';}
  finally{button.disabled=false;if(button.textContent==='در حال بررسی دفتر…')button.textContent='پایش دیوارها';}
}

async function analyzeNewListing(item, row, button){
  button.disabled=true; button.textContent='در حال تحلیل…';
  try{
    const q=new URLSearchParams({exchange:item.exchange,symbol:item.symbol,base:item.base||'',quote:item.quote||'USDT'});
    const r=await fetch(`${API}/api/scout/new-listings/analyze?${q}`);
    const d=await r.json(); if(!r.ok)throw new Error(d.error||'تحلیل ناموفق بود');
    const panel=document.createElement('div'); panel.className='note';
    const lines=(d.analyses||[]).map(a=>`${a.timeframe}: ${a.status==='analysis_ready'?`${a.trend} · بازده ۲۰ کندل ${a.return_20_bars_pct}% · ATR ${a.atr14_pct}%`:'داده ناکافی'}`);
    panel.textContent=`وضعیت: ${d.status} · هویت قرارداد: ${d.identity_status||'تأییدنشده'} · ${lines.join(' | ')} · ${d.advice}`;
    const prior=row.querySelector('.cold-start-result'); if(prior)prior.remove(); panel.classList.add('cold-start-result'); row.append(panel);
  }catch(e){button.textContent='خطا؛ تلاش مجدد';}
  finally{button.disabled=false; if(button.textContent==='در حال تحلیل…')button.textContent='تحلیل سریع';}
}

// V22.7.8: New Listings is a truly on-demand panel; no startup fetch/open.
document.addEventListener('DOMContentLoaded',()=>{
  const panel=document.getElementById('newListingPanel');
  const nav=document.querySelector('.side-link[data-section="newListingPanel"]');
  const refresh=document.getElementById('newListingRefresh');
  const close=document.getElementById('newListingClose');
  if(!panel)return;
  const setClosed=()=>{
    panel.hidden=true; panel.setAttribute('aria-hidden','true'); panel.style.display='none';
    if(nav){nav.classList.remove('active');nav.setAttribute('aria-expanded','false');}
  };
  const openPanel=(event)=>{
    if(event)event.preventDefault();
    panel.hidden=false; panel.setAttribute('aria-hidden','false'); panel.style.display='';
    if(nav){nav.classList.add('active');nav.setAttribute('aria-expanded','true');}
    panel.scrollIntoView({behavior:'smooth',block:'start'});
    refreshNewListings();
  };
  const closePanel=(event)=>{if(event)event.preventDefault();setClosed();};
  // Force closed even if an old browser session retained #newListingPanel.
  setClosed();
  if(window.location.hash==='#newListingPanel'){
    history.replaceState(null,'',window.location.pathname+window.location.search);
  }
  if(nav)nav.addEventListener('click',event=>{
    event.preventDefault();
    if(panel.hidden || panel.style.display==='none')openPanel();else closePanel();
  });
  if(refresh)refresh.addEventListener('click',()=>refreshNewListings());
  if(close)close.addEventListener('click',closePanel);
});
