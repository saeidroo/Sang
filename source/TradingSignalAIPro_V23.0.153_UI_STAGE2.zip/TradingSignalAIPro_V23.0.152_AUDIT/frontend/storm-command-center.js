/* V23.0.153 UI Stage 2 — Storm Scout command center.
   Presentation only: consumes normalized Scout rows; does not calculate signals or scores. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const fa = (value, digits=0) => Number(value).toLocaleString('fa-IR', {maximumFractionDigits:digits});
  const finite = value => value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value));
  let firstSnapshot = true;
  let previousKeys = new Set();

  function directionOf(item) {
    if (item._tier === 'pre_pump') return 'up';
    if (item._tier === 'pre_dump' || item._tier === 'active_dump') return 'down';
    const raw = String(item.direction || '').trim().toLowerCase();
    if (['up','bullish','long','pump','positive','buy'].includes(raw)) return 'up';
    if (['down','bearish','short','dump','negative','sell'].includes(raw)) return 'down';
    return 'unknown';
  }
  function scoreOf(item) {
    const key = item._tier === 'pre_pump' ? 'pre_pump_score'
      : item._tier === 'pre_dump' ? 'pre_dump_score'
      : item._tier === 'active_dump' ? 'active_dump_score' : 'score';
    return finite(item[key]) ? Number(item[key]) : null;
  }
  function symbolOf(item) {
    return String(item.base || item.symbol || '—').toUpperCase();
  }
  function keyOf(item) {
    return `${symbolOf(item)}|${directionOf(item)}|${item._tier || 'general'}`;
  }
  function labelOf(item) {
    return ({pre_pump:'پیش از پامپ',pre_dump:'پیش از دامپ',active_dump:'دامپ فعال',early:'شروع حرکت',alert:'طوفان فعال',watch:'در حال شکل‌گیری'})[item._tier] || 'فرصت دیده‌شده';
  }
  function freshnessOf(item, state) {
    if (state && state.stale === true) return 'داده قدیمی';
    if (item.fresh === true) return 'تازه';
    if (item.fresh === false) return 'تازه نیست';
    return 'نامشخص';
  }
  function evidenceCountOf(item) {
    return finite(item.evidence_count) ? fa(item.evidence_count) : '—';
  }
  function sourceCountOf(item) {
    if (Array.isArray(item.sources)) return fa(item.sources.length);
    return finite(item.price_source_count) ? fa(item.price_source_count) : '—';
  }
  function tierScoreValue(item) {
    const value = scoreOf(item);
    return value === null ? 0 : Math.max(0, Math.min(100, value));
  }
  function hashText(value) {
    let hash = 2166136261;
    for (let i=0; i<value.length; i++) hash = Math.imul(hash ^ value.charCodeAt(i), 16777619);
    return hash >>> 0;
  }
  function targetPosition(item) {
    const seed = hashText(keyOf(item));
    const angle = (seed % 360) * Math.PI / 180;
    const radius = 22 + ((seed >>> 9) % 18);
    return {x:50 + Math.cos(angle)*radius, y:50 + Math.sin(angle)*radius};
  }
  function pulseOnce(node) {
    node.classList.add('is-arrival');
    window.setTimeout(() => node.classList.remove('is-arrival'), 820);
  }
  function makeRadarPoint(item, isNew) {
    const direction = directionOf(item);
    const pos = targetPosition(item);
    const score = tierScoreValue(item);
    const point = document.createElement('span');
    point.className = `storm-radar-point ${direction}`;
    point.style.left = `${pos.x.toFixed(2)}%`;
    point.style.top = `${pos.y.toFixed(2)}%`;
    point.style.setProperty('--point-size', `${6 + score * 0.075}px`);
    point.style.setProperty('--point-alpha', String(0.48 + score * 0.005));
    point.title = `${symbolOf(item)} · ${labelOf(item)} · ${scoreOf(item) === null ? 'امتیاز —' : `امتیاز ${fa(scoreOf(item),1)}`}`;
    point.setAttribute('aria-label', point.title);
    if (isNew) pulseOnce(point);
    return point;
  }
  function makeMetric(label, value, extraClass='') {
    const box = document.createElement('div');
    box.className = `storm-ob-metric ${extraClass}`.trim();
    const small = document.createElement('small'); small.textContent = label;
    const strong = document.createElement('strong'); strong.textContent = value;
    box.append(small,strong);
    return box;
  }
  function makeOpportunityCard(item, state, isNew) {
    const direction = directionOf(item);
    const card = document.createElement('article');
    card.className = `storm-ob-item ${direction}`;
    const top = document.createElement('div'); top.className = 'storm-ob-item-top';
    const identity = document.createElement('div'); identity.className = 'storm-ob-identity';
    const symbol = document.createElement('strong'); symbol.textContent = symbolOf(item);
    const phase = document.createElement('span'); phase.className = 'storm-ob-phase'; phase.textContent = labelOf(item);
    identity.append(symbol,phase);
    const score = document.createElement('div'); score.className = 'storm-ob-score';
    const scoreValue = scoreOf(item);
    const scoreLabel = document.createElement('small'); scoreLabel.textContent = 'SCORE';
    const scoreNumber = document.createElement('strong'); scoreNumber.textContent = scoreValue === null ? '—' : fa(scoreValue,1);
    score.append(scoreLabel,scoreNumber);
    top.append(identity,score);

    const metrics = document.createElement('div'); metrics.className = 'storm-ob-metrics';
    metrics.append(
      makeMetric('تازگی', freshnessOf(item,state)),
      makeMetric('تعداد شواهد', evidenceCountOf(item)),
      makeMetric('تعداد منابع', sourceCountOf(item))
    );
    const actions = document.createElement('div'); actions.className = 'storm-ob-actions';
    const reason = document.createElement('span');
    reason.textContent = Array.isArray(item.reasons) && item.reasons.length ? item.reasons.slice(0,2).join(' · ') : 'جزئیات بیشتر در تحلیل';
    const analyze = document.createElement('button'); analyze.type = 'button'; analyze.className = 'storm-ob-analyze'; analyze.textContent = 'تحلیل';
    analyze.addEventListener('click', () => {
      const symbolArg = item.symbol || (item.base ? `${item.base}USDT` : '');
      if (symbolArg && typeof window.analyzeTrend === 'function') window.analyzeTrend(symbolArg);
    });
    actions.append(reason,analyze);
    card.append(top,metrics,actions);
    if (isNew) pulseOnce(card);
    return card;
  }
  function renderList(target, items, state, freshKeys, emptyText) {
    if (!target) return;
    target.replaceChildren();
    if (!items.length) {
      const empty = document.createElement('div'); empty.className = 'storm-empty'; empty.textContent = emptyText;
      target.append(empty); return;
    }
    items.slice(0,8).forEach(item => target.append(makeOpportunityCard(item,state,freshKeys.has(keyOf(item)))));
  }
  function mirrorStatus(targetId, sourceId, fallback) {
    const target = $(targetId), source = $(sourceId);
    if (!target) return;
    const update = () => {
      const value = source && source.textContent.trim() ? source.textContent.trim() : fallback;
      target.textContent = value;
      const text = value.toLowerCase();
      target.dataset.state = /خاموش|خطا|آفلاین|ناموفق|offline|error/.test(text) ? 'offline'
        : /در انتظار|بارگذاری|آماده‌سازی|شروع نشده|نامشخص/.test(text) ? 'pending' : 'reported';
    };
    update();
    if (source && 'MutationObserver' in window) {
      const observer = new MutationObserver(update);
      observer.observe(source,{childList:true,subtree:true,characterData:true});
    }
  }
  function updateStatus(state) {
    const status = $('stormCcScoutStatus'), live = $('stormCcLive');
    if (!status || !live) return;
    let label='وضعیت نامشخص', mode='unknown';
    if (state && state.online === false) { label='OFFLINE'; mode='offline'; }
    else if (state && state.stale === true) { label='STALE · داده قدیمی'; mode='stale'; }
    else if (state && state.online === true) { label='ONLINE'; mode='online'; }
    status.textContent=label; status.dataset.state=mode;
    live.textContent=label; live.dataset.state=mode;
    const updated=$('stormCcUpdated');
    if (updated) {
      const ts=state && Number(state.generated_at);
      updated.textContent=ts>0 ? `آخرین داده: ${new Date(ts*1000).toLocaleTimeString('fa-IR')}` : 'زمان آخرین داده: —';
    }
  }
  function render(payload) {
    if (!payload) return;
    const rows = Array.isArray(payload.rows) ? payload.rows : [];
    const state = payload.state || {};
    const nextKeys = new Set(rows.map(keyOf));
    const freshKeys = new Set();
    if (!firstSnapshot) nextKeys.forEach(key => { if (!previousKeys.has(key)) freshKeys.add(key); });
    firstSnapshot=false; previousKeys=nextKeys;

    const pump = rows.filter(item => directionOf(item)==='up');
    const dump = rows.filter(item => directionOf(item)==='down');
    const neutral = rows.filter(item => directionOf(item)==='unknown');
    const points = $('stormRadarPoints');
    if (points) {
      points.replaceChildren();
      rows.slice(0,24).forEach(item => points.append(makeRadarPoint(item,freshKeys.has(keyOf(item)))));
    }
    const count = $('stormRadarCount'); if (count) count.textContent=fa(rows.length);
    const pumpCount = $('stormPumpCount'); if (pumpCount) pumpCount.textContent=fa(pump.length);
    const dumpCount = $('stormDumpCount'); if (dumpCount) dumpCount.textContent=fa(dump.length);
    renderList($('stormPumpList'),pump,state,freshKeys,'فعلاً فرصت صعودی ساختاریافته‌ای از Scout دریافت نشده است.');
    renderList($('stormDumpList'),dump,state,freshKeys,'فعلاً فرصت نزولی ساختاریافته‌ای از Scout دریافت نشده است.');
    updateStatus(state);

    const foot=$('stormRadarFoot');
    if (foot) {
      if (state.online === false) foot.textContent='منبع Scout آفلاین است؛ آخرین داده معتبر در صورت وجود جداگانه مشخص می‌شود.';
      else if (state.stale === true) foot.textContent='داده Scout قدیمی است؛ نشانگرها آخرین خروجی را نشان می‌دهند و نباید زنده تلقی شوند.';
      else foot.textContent=`${fa(pump.length)} نشانه صعودی · ${fa(dump.length)} نشانه نزولی · ${fa(neutral.length)} مورد با جهت نامشخص. رادار گرافیکی صرفاً نمایش بصری است.`;
    }
  }

  document.addEventListener('tekar:opportunity-radar-rows', event => render(event.detail));
  // Scripts are loaded at the end of body; initialize mirrors immediately.
  mirrorStatus('stormCcHistoricalStatus','scoutBrainState','در انتظار گزارش مغز');
  mirrorStatus('stormCcAutopilotStatus','apEngineState','در انتظار وضعیت موتور');
  mirrorStatus('stormCcPaperLearningStatus','paperLearningStatus','در انتظار حافظه یادگیری');
})();
