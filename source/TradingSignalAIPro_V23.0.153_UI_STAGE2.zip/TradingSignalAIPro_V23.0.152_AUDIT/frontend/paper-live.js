/* V23.0.11: ATR-aware risk plus settled futures funding reconciliation; paper only. */
(()=>{
  const API='';
  const $=id=>document.getElementById(id);
  const els={
    status:$('paperLiveStatus'),symbol:$('paperLiveSymbol'),market:$('paperLiveMarket'),
    exchange:$('paperLiveExchange'),side:$('paperLiveSide'),timeframe:$('paperLiveTimeframe'),quote:$('paperLiveQuote'),
    connections:$('paperLiveConnections'),positions:$('paperLivePositions'),
    equity:$('paperEquity'),available:$('paperAvailable'),realized:$('paperRealized'),
    unrealized:$('paperUnrealized'),openCount:$('paperOpenCount'),drawdown:$('paperDrawdown'),risk:$('paperPortfolioRisk'),
    quoteBtn:$('paperLiveQuoteBtn'),openBtn:$('paperLiveOpenBtn'),checkBtn:$('paperLiveCheckBtn'),refreshBtn:$('paperLiveRefreshBtn'),
    learningStatus:$('paperLearningStatus'),learningCount:$('paperLearningCount'),learningWinRate:$('paperLearningWinRate'),
    learningAvgReturn:$('paperLearningAvgReturn'),learningPF:$('paperLearningPF'),learningNet:$('paperLearningNet'),
    learningProfiles:$('paperLearningProfiles'),learningEvents:$('paperLearningEvents'),learningLastRun:$('paperLearningLastRun'),
    learningRebuildBtn:$('paperLearningRebuildBtn'),learningExportBtn:$('paperLearningExportBtn'),initialBalance:$('paperLiveInitialBalance')
  };
  if(!els.status)return;
  let busy=false,lastQuote=null,refreshTimer=null,lastLearningEventCount=-1;
  const money=v=>Number.isFinite(Number(v))?Number(v).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:4}):'—';
  const pct=v=>Number.isFinite(Number(v))?`${Number(v).toFixed(2)}٪`:'—';
  const setStatus=(message,kind='')=>{els.status.textContent=message;els.status.className='paper-live-status '+kind;};
  const setBusy=(flag)=>{busy=flag;[els.quoteBtn,els.openBtn,els.checkBtn,els.refreshBtn].forEach(b=>{if(b)b.disabled=flag;});};
  const request=async(url,options={})=>{
    const r=await fetch(`${API}${url}`,{cache:'no-store',...options,headers:{'Content-Type':'application/json',...(options.headers||{})}});
    let d={};try{d=await r.json();}catch(_){throw new Error('پاسخ سرور قابل خواندن نیست');}
    if(!r.ok)throw new Error(d.error||`خطای سرور (${r.status})`);
    return d;
  };
  function readForm(){
    const symbol=String(els.symbol.value||'').toUpperCase().replace(/\s+/g,'').replace('/','');
    if(!/^[A-Z0-9]{3,24}USDT$/.test(symbol))throw new Error('نماد را به‌شکل BTCUSDT وارد کن.');
    return {symbol,market:els.market.value,exchange:els.exchange.value,timeframe:els.timeframe?.value||'1h'};
  }
  async function loadQuote(){
    let q;try{q=readForm();}catch(e){setStatus(e.message,'err');return;}
    setBusy(true);setStatus('در حال اتصال به بازار…','busy');
    try{
      const params=new URLSearchParams(q);
      const d=await request(`/api/paper-live/quote?${params}`);
      lastQuote=d;
      els.quote.replaceChildren();
      const title=document.createElement('b');title.textContent=`${d.symbol} · ${d.exchange_name} · ${d.market==='spot'?'اسپات':'فیوچرز'}`;
      const price=document.createElement('strong');price.textContent=money(d.price);
      const meta=document.createElement('span');meta.textContent=`USDT · ${d.cached?'قیمت کش‌شدهٔ کوتاه‌مدت':'دریافت مستقیم'} · ${new Date(d.timestamp).toLocaleTimeString('fa-IR')}`;
      els.quote.append(title,price,meta);
      setStatus(`قیمت زنده از ${d.exchange_name} دریافت شد`,'ok');
      return d;
    }catch(e){lastQuote=null;els.quote.textContent=e.message;setStatus('اتصال قیمت ناموفق','err');throw e;}
    finally{setBusy(false);}
  }
  async function checkConnections(){
    let q;try{q=readForm();}catch(e){setStatus(e.message,'err');return;}
    setBusy(true);setStatus('در حال آزمایش اتصال صرافی‌ها…','busy');els.connections.textContent='در حال بررسی شش منبع عمومی…';
    try{
      const params=new URLSearchParams({symbol:q.symbol,market:q.market});
      const d=await request(`/api/paper-live/connections?${params}`);
      els.connections.replaceChildren();
      (d.providers||[]).forEach(x=>{
        const item=document.createElement('span');item.className='paper-live-provider '+(x.ok?'ok':'err');
        item.textContent=x.ok?`${x.name}: متصل · ${money(x.price)}`:`${x.name}: ناموفق`;
        item.title=x.error||'API عمومی پاسخ نداد';els.connections.append(item);
      });
      setStatus(`${d.ok_count} از ${d.total} صرافی در دسترس` , d.ok_count?'ok':'err');
      if(d.ok_count===0){const note=document.createElement('div');note.className='note';note.textContent='هیچ API عمومی پاسخ نداد. اتصال اینترنت، VPN یا فایروال ویندوز را بررسی کن.';els.connections.append(note);}
      return d;
    }catch(e){els.connections.textContent=e.message;setStatus('آزمایش اتصال ناموفق','err');throw e;}
    finally{setBusy(false);}
  }
  function addCell(tr,value){const td=document.createElement('td');td.textContent=value;tr.append(td);return td;}
  function makeIdempotencyKey(positionId){
    const token=(window.crypto&&crypto.randomUUID)?crypto.randomUUID():`${Date.now()}-${Math.random().toString(36).slice(2)}`;
    return `ui-${positionId}-${token}`;
  }
  async function partialClosePosition(position, fraction, button, customQuantity=null){
    const remaining=Number(position.quantity||0);
    const quantity=customQuantity==null?remaining*fraction:customQuantity;
    if(!Number.isFinite(quantity)||quantity<=0||quantity>=remaining){setStatus('مقدار خروج باید بیشتر از صفر و کمتر از مقدار باقی‌مانده باشد.','err');return;}
    const label=button?.textContent||'خروج جزئی';
    if(button){button.disabled=true;button.textContent='در حال ثبت…';}
    setStatus('در حال اجرای خروج جزئی آزمایشی با قیمت همان صرافی…','busy');
    try{
      const d=await request(`/api/paper-live/positions/${position.id}/partial-close`,{
        method:'POST',body:JSON.stringify({quantity,idempotency_key:makeIdempotencyKey(position.id),reason:'PARTIAL_MANUAL_UI'})
      });
      setStatus(`خروج جزئی ثبت شد · ${money(d.quantity)} واحد · سود/زیان تحقق‌یافته ${money(d.net_pnl)} USDT · مانده ${money(d.remaining_quantity)}`,'ok');
      await loadState(false);
    }catch(e){setStatus(e.message,'err');if(button){button.disabled=false;button.textContent=label;}}
  }
  async function closePosition(id,button){
    if(button){button.disabled=true;button.textContent='در حال بستن…';}
    setStatus('در حال دریافت قیمت خروج…','busy');
    try{const d=await request(`/api/paper-live/positions/${id}/close`,{method:'POST',body:'{}'});setStatus(`موقعیت بسته شد · ${money(d.net_pnl)} USDT`,'ok');await loadState(false);}
    catch(e){setStatus(e.message,'err');if(button){button.disabled=false;button.textContent='بستن';}}
  }
  async function loadState(refreshQuotes=true){
    const d=await request(`/api/paper-live/state?refresh=${refreshQuotes?'1':'0'}`);
    const a=d.account||{};
    if(els.initialBalance)els.initialBalance.textContent=`${money(d.settings?.initial_balance??a.initial_balance)} USDT`;
    els.equity.textContent=a.equity==null?'نامشخص':`${money(a.equity)} USDT`;
    els.available.textContent=a.available_balance==null?'نیازمند به‌روزرسانی':`${money(a.available_balance)} USDT`;
    els.realized.textContent=a.realized_pnl==null?'نامشخص':`${money(a.realized_pnl)} USDT`;
    els.unrealized.textContent=a.unrealized_pnl==null?'نامشخص':`${money(a.unrealized_pnl)} USDT`;
    els.openCount.textContent=`${a.open_positions||0} / ${d.settings?.max_open_positions||3}`;
    els.drawdown.textContent=pct(a.drawdown_pct);
    els.drawdown.style.color=Number(a.drawdown_pct)<-5?'var(--red)':'var(--text)';
    if(els.risk){
      const pr=a.portfolio_risk||{};
      if(pr.complete===false){els.risk.textContent='نامشخص';els.risk.title='ریسک حدضرر یک موقعیت قابل محاسبه نیست؛ ورود جدید باید متوقف بماند.';}
      else {
        els.risk.textContent=`${money(pr.total||0)} / ${money(pr.portfolio_cap_usdt||0)} USDT`;
        els.risk.title=`اسپات: ${money(pr.by_market?.spot||0)} / ${money(pr.spot_cap_usdt||0)} USDT · فیوچرز: ${money(pr.by_market?.perp||0)} / ${money(pr.perp_cap_usdt||0)} USDT · Long: ${money(pr.by_side?.LONG||0)} · Short: ${money(pr.by_side?.SHORT||0)}`;
        els.risk.style.color=Number(pr.total||0)>=Number(pr.portfolio_cap_usdt||0)*0.9?'var(--red)':'var(--text)';
      }
    }
    els.positions.replaceChildren();
    const rows=(d.open_positions||[]).filter(x=>x.status==='OPEN');
    if(!rows.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=15;td.className='note';td.textContent='هیچ موقعیت بازی وجود ندارد. قیمت زنده با انتخاب نماد و زدن دکمه دریافت قیمت بررسی می‌شود.';tr.append(td);els.positions.append(tr);}
    rows.forEach(x=>{
      const tr=document.createElement('tr');
      addCell(tr,x.symbol);addCell(tr,x.market==='spot'?'اسپات':'فیوچرز');addCell(tr,x.timeframe||'نامشخص');addCell(tr,x.live_exchange||x.exchange);
      addCell(tr,x.side==='LONG'?'Long':'Short');addCell(tr,money(x.entry_fill));
      const price=x.quote_status==='DISCONNECTED'?'قطع اتصال':(!refreshQuotes?'نیازمند تازه‌سازی':money(x.last_price));addCell(tr,price);
      addCell(tr,money(x.stop_price));addCell(tr,money(x.target_price));
      let netRr='—';
      try{const ctx=typeof x.entry_context_json==='string'?JSON.parse(x.entry_context_json):{};const rr=ctx?.decision_context?.atr_risk_bracket?.net_reward_risk;if(Number.isFinite(Number(rr))&&Number(rr)>0)netRr=`${Number(rr).toFixed(2)}R`;}catch(_e){}
      addCell(tr,netRr);
      const funding=Number(x.funding_total||0);
      const fundingCell=addCell(tr, x.market==='perp' ? `${funding>=0?'+':''}${money(funding)} USDT` : '—');
      if(x.market==='perp'){
        fundingCell.style.color=funding>0?'var(--green)':(funding<0?'var(--red)':'var(--text)');
        fundingCell.title=x.funding_status==='SYNCED'?'تسویه‌های ثبت‌شده از تاریخچهٔ عمومی صرافی':(x.funding_error||'در انتظار همگام‌سازی Funding');
      }
      const pnl=x.unrealized_net_pnl;const pnlCell=addCell(tr,pnl==null?'نامشخص':`${money(pnl)} USDT`);if(pnl!=null)pnlCell.style.color=Number(pnl)>=0?'var(--green)':'var(--red)';
      addCell(tr,`${money(x.original_quantity??x.quantity)} / ${money(x.partial_exited_quantity||0)} / ${money(x.quantity)} `);
      const realized=Number(x.partial_realized_net_pnl||0);const realizedCell=addCell(tr,`${money(realized)} USDT`);realizedCell.style.color=realized>=0?'var(--green)':'var(--red)';
      const td=document.createElement('td');td.className='paper-live-actions';
      [['۲۵٪',.25],['۵۰٪',.5]].forEach(([label,fraction])=>{const part=document.createElement('button');part.type='button';part.className='paper-live-partial';part.textContent=label;part.title='خروج درصدی از مقدار باقی‌مانده؛ Funding در زمان هر تسویه با مقدار باز همان لحظه محاسبه می‌شود';part.addEventListener('click',()=>partialClosePosition(x,fraction,part));td.append(part);});
      const custom=document.createElement('button');custom.type='button';custom.className='paper-live-partial';custom.textContent='مقدار…';custom.addEventListener('click',()=>{const raw=window.prompt(`مقدار خروج (حداکثر کمتر از ${x.quantity})`,String(Number(x.quantity)*.25));if(raw===null)return;const value=Number(raw);if(!Number.isFinite(value)||value<=0){setStatus('مقدار واردشده معتبر نیست.','err');return;}void partialClosePosition(x,null,custom,value);});td.append(custom);
      if(x.market==='perp'){const audit=document.createElement('button');audit.type='button';audit.className='paper-live-partial';audit.textContent='دفتر Funding';audit.addEventListener('click',()=>loadFundingAudit(x.id));td.append(audit);}
      const btn=document.createElement('button');btn.type='button';btn.className='paper-live-close';btn.textContent='بستن کامل';btn.addEventListener('click',()=>closePosition(x.id,btn));td.append(btn);tr.append(td);
      if(x.quote_status==='DISCONNECTED'){tr.title=x.quote_error||'اتصال قیمت برقرار نیست';}else if(!refreshQuotes){tr.title='آخرین قیمت ذخیره‌شده است؛ برای نمایش قیمت زنده تازه‌سازی کن.';}
      els.positions.append(tr);
    });
    const eventCount=Number(d.learning_event_count||0);
    if(eventCount!==lastLearningEventCount){lastLearningEventCount=eventCount;await loadLearning();}
    if(rows.some(x=>x.quote_status==='DISCONNECTED'))setStatus('یک یا چند قیمت در دسترس نیست؛ موقعیت‌ها حفظ شده‌اند و ورود جدید متوقف است','err');
    else if(Number(a.funding_incomplete_positions||0)>0)setStatus('تاریخچهٔ Funding یک یا چند معامله کامل نیست؛ سود تحقق‌یافته و موجودی قطعی نمایش داده نمی‌شود و ورود جدید متوقف است','warn');
    else if(a.unrealized_pnl_complete===false)setStatus('برای نمایش موجودی و سود شناور دقیق، قیمت موقعیت‌ها را تازه‌سازی کن','busy');
    else if(rows.length)setStatus('پایش قیمت موقعیت‌های باز فعال است','ok');
    return d;
  }
  async function loadFundingAudit(positionId){
    const status=$('paperFundingAuditStatus'),fundingRows=$('paperFundingAuditRows'),partialRows=$('paperPartialAuditRows');
    const panel=$('paperFundingAuditPanel');if(!status||!fundingRows||!partialRows)return;
    status.textContent='در حال دریافت دفتر حسابداری…';fundingRows.replaceChildren();partialRows.replaceChildren();
    try{
      const d=await request(`/api/paper-live/positions/${positionId}/funding-audit`);
      const t=d.trade||{};status.textContent=`معامله #${t.id} · ${t.symbol} · وضعیت Funding: ${t.funding_status} · جمع رویدادها: ${money(d.funding_event_sum)} USDT · ${d.audit_complete?'تطبیق کامل':'تاریخچه ناقص یا در انتظار'}`;
      (d.funding_events||[]).forEach(x=>{const tr=document.createElement('tr');[
        new Date(Number(x.settlement_ts_ms)).toLocaleString('fa-IR'),`${(Number(x.funding_rate)*100).toFixed(5)}٪`,money(x.position_quantity),money(x.partial_exited_quantity),money(x.event_notional),`${money(x.cashflow)} USDT`,x.source
      ].forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.append(td);});fundingRows.append(tr);});
      if(!fundingRows.children.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=7;td.textContent='رویداد Funding ثبت‌شده‌ای وجود ندارد.';tr.append(td);fundingRows.append(tr);}
      (d.partial_exits||[]).forEach(x=>{const tr=document.createElement('tr');[
        new Date(Number(x.created_at)*1000).toLocaleString('fa-IR'),money(x.quantity),money(x.exit_fill),money(x.exit_fee),`${money(x.net_pnl)} USDT`,x.reason
      ].forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.append(td);});partialRows.append(tr);});
      if(!partialRows.children.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=6;td.textContent='خروج جزئی ثبت نشده است.';tr.append(td);partialRows.append(tr);}
      panel.open=true;panel.scrollIntoView({behavior:'smooth',block:'nearest'});
    }catch(e){status.textContent=`دریافت دفتر ممیزی ناموفق: ${e.message}`;}
  }
  function learningStateLabel(value){
    return ({COLLECTING:'در حال جمع‌آوری',NO_EDGE:'برتری مشاهده نشد',SHADOW_VALIDATION:'اعتبارسنجی سایه',PAPER_EVIDENCE_ONLY:'شواهد آزمایشی'}[value]||value||'—');
  }
  async function loadLearning(){
    if(!els.learningStatus)return;
    try{
      const d=await request('/api/paper-live/learning');
      const s=d.summary||{};
      els.learningCount.textContent=String(s.closed_trades||0);
      els.learningWinRate.textContent=pct(s.win_rate_pct);
      els.learningAvgReturn.textContent=pct(s.avg_net_return_pct);
      els.learningPF.textContent=s.profit_factor==null?'—':Number(s.profit_factor).toFixed(2);
      els.learningNet.textContent=`${money(s.total_net_pnl)} USDT`;
      els.learningNet.style.color=Number(s.total_net_pnl)>=0?'var(--green)':'var(--red)';
      els.learningStatus.textContent=(s.closed_trades||0)<30?'در حال جمع‌آوری تجربه':`حافظه به‌روز · ${s.closed_trades} نتیجه`;
      els.learningStatus.className='paper-learning-state '+((s.closed_trades||0)>=30?'ready':'collecting');
      els.learningLastRun.textContent=s.last_learned_at?`آخرین نتیجه: ${new Date(Number(s.last_learned_at)*1000).toLocaleString('fa-IR')}`:'هنوز معامله بسته‌شده‌ای ثبت نشده است.';
      els.learningProfiles.replaceChildren();
      const profiles=d.profiles||[];
      if(!profiles.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=9;td.className='note';td.textContent='با بسته‌شدن اولین معامله، حافظه به‌صورت خودکار نمونه می‌گیرد.';tr.append(td);els.learningProfiles.append(tr);}
      profiles.forEach(x=>{
        const tr=document.createElement('tr');
        [x.symbol,x.market==='spot'?'اسپات':'فیوچرز',x.timeframe,x.side==='LONG'?'Long':'Short',String(x.sample_count),pct(x.win_rate_pct),pct(x.avg_net_return_pct),x.profit_factor==null?'—':Number(x.profit_factor).toFixed(2),learningStateLabel(x.learning_state)].forEach((v,i)=>{
          const td=document.createElement('td');td.textContent=v;if(i===8)td.className='paper-learning-tag '+String(x.learning_state||'').toLowerCase();tr.append(td);
        });
        els.learningProfiles.append(tr);
      });
      if(els.learningEvents){
        els.learningEvents.replaceChildren();
        const events=d.recent_events||[];
        if(!events.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=9;td.className='note';td.textContent='هنوز معامله بسته‌شده‌ای ثبت نشده است.';tr.append(td);els.learningEvents.append(tr);}
        events.forEach(x=>{
          const tr=document.createElement('tr');
          const outcome=Number(x.outcome)===1?'سودده':'زیان‌ده';
          const values=[new Date(Number(x.closed_at)*1000).toLocaleString('fa-IR'),x.symbol,x.market==='spot'?'اسپات':'فیوچرز',x.timeframe,x.side==='LONG'?'Long':'Short',outcome,x.exit_reason||'—',`${money(x.net_pnl)} USDT`,pct(x.return_pct)];
          values.forEach((v,i)=>{const td=document.createElement('td');td.textContent=v;if(i===5)td.style.color=Number(x.outcome)===1?'var(--green)':'var(--red)';if(i===7)td.style.color=Number(x.net_pnl)>=0?'var(--green)':'var(--red)';tr.append(td);});
          els.learningEvents.append(tr);
        });
      }
    }catch(e){els.learningStatus.textContent=`خطا در حافظه یادگیری: ${e.message}`;els.learningStatus.className='paper-learning-state error';}
  }
  async function rebuildLearning(){
    if(els.learningRebuildBtn){els.learningRebuildBtn.disabled=true;}
    try{await request('/api/paper-live/learning/rebuild',{method:'POST',body:'{}'});await loadLearning();setStatus('حافظه معاملات آزمایشی بازسازی شد','ok');}
    catch(e){setStatus(`بازسازی یادگیری ناموفق: ${e.message}`,'err');}
    finally{if(els.learningRebuildBtn)els.learningRebuildBtn.disabled=false;}
  }
  async function openPosition(){
    let q;try{q=readForm();}catch(e){setStatus(e.message,'err');return;}
    const side=els.side.value;
    if(q.market==='spot'&&side==='SHORT'){setStatus('در اسپات فقط Long مجاز است؛ برای Short فیوچرز را انتخاب کن.','err');return;}
    setBusy(true);setStatus('در حال دریافت قیمت و ثبت معاملهٔ مجازی…','busy');
    try{
      const d=await request('/api/paper-live/positions',{method:'POST',body:JSON.stringify({...q,side})});
      lastQuote=d.quote||null;setStatus(`موقعیت ${d.side} ثبت شد · ${d.exchange} · بدون سفارش واقعی`,'ok');
      await loadState(false);
    }catch(e){setStatus(e.message,'err');}
    finally{setBusy(false);}
  }
  async function safe(fn){try{await fn();}catch(e){console.warn('[paper-live]',e);}}
  async function enterPaperLive(){
    // Connect only when the user opens this workspace; avoid background exchange calls elsewhere.
    await safe(loadQuote);
    await safe(checkConnections);
    await safe(()=>loadState(true));
  }
  document.addEventListener('DOMContentLoaded',async()=>{
    await safe(()=>loadState(false));
    const paperNav=document.querySelector('.side-link[data-section="paperWorkspace"]');
    paperNav?.addEventListener('click',()=>{void enterPaperLive();});
    if(window.location.hash==='#paperWorkspace')void enterPaperLive();
    els.quoteBtn?.addEventListener('click',()=>safe(loadQuote));
    els.checkBtn?.addEventListener('click',()=>safe(checkConnections));
    els.refreshBtn?.addEventListener('click',()=>safe(()=>loadState(true)));
    els.openBtn?.addEventListener('click',openPosition);
    els.learningRebuildBtn?.addEventListener('click',()=>safe(rebuildLearning));
    els.learningExportBtn?.addEventListener('click',()=>{window.location.href='/api/paper-live/learning/export.csv';});
    els.market?.addEventListener('change',()=>{if(els.market.value==='spot'&&els.side.value==='SHORT')els.side.value='LONG';lastQuote=null;});
    els.symbol?.addEventListener('change',()=>{lastQuote=null;});
    if(refreshTimer)clearInterval(refreshTimer);
    refreshTimer=setInterval(()=>{
      if(document.visibilityState==='visible')safe(()=>loadState(true));
    },10000);
  });
})();
