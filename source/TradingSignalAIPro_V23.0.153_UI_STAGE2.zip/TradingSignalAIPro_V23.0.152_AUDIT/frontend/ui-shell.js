/* V22.6.7 navigation shell; isolated from trading logic. */
(()=>{const sidebar=document.getElementById('appSidebar'),toggle=document.getElementById('mobileNavToggle');if(!sidebar||!toggle)return;const links=[...sidebar.querySelectorAll('.side-link')];const close=()=>{sidebar.classList.remove('open');toggle.setAttribute('aria-expanded','false')};toggle.addEventListener('click',()=>{const open=sidebar.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open))});links.forEach(link=>link.addEventListener('click',()=>{links.forEach(x=>x.classList.remove('active'));link.classList.add('active');close()}));const targets=links.map(a=>document.getElementById(a.dataset.section)).filter(Boolean);if('IntersectionObserver'in window){const observer=new IntersectionObserver(entries=>{const visible=entries.filter(e=>e.isIntersecting).sort((a,b)=>b.intersectionRatio-a.intersectionRatio)[0];if(!visible)return;links.forEach(a=>a.classList.toggle('active',a.dataset.section===visible.target.id))},{rootMargin:'-18% 0px -68% 0px',threshold:[0,.15,.35]});targets.forEach(el=>observer.observe(el))}document.addEventListener('keydown',e=>{if(e.key==='Escape')close()})})();

/* V23.0.120 compact workspace: major work areas collapse independently. */
(()=>{
  const targets=['opportunityRadar','marketWorkspace','learnPanel','longrunPanel','archivePanel','labWorkspace','performanceCenter','paperWorkspace','autopilotPanel'];
  const storageKey='trading-ai-section-state-v1';
  let saved={};
  try{saved=JSON.parse(localStorage.getItem(storageKey)||'{}')||{}}catch(_){saved={}}
  const titleOf=(el)=>el.getAttribute('aria-label')||el.querySelector('h2,h3,.card-head h2,.charthead h2')?.textContent?.trim()||el.id;
  const setOpen=(el,body,button,open,persist=true)=>{
    el.classList.toggle('is-collapsed',!open);body.hidden=!open;
    button.setAttribute('aria-expanded',String(open));
    button.querySelector('.compact-toggle-state').textContent=open?'− بستن':'＋ باز کردن';
    if(persist){saved[el.id]=open;try{localStorage.setItem(storageKey,JSON.stringify(saved))}catch(_){}}
  };
  targets.forEach(id=>{
    const el=document.getElementById(id);if(!el||el.dataset.compactReady==='1')return;
    el.dataset.compactReady='1';
    const body=document.createElement('div');body.className='compact-section-body';
    while(el.firstChild)body.appendChild(el.firstChild);
    const button=document.createElement('button');button.type='button';button.className='compact-section-toggle';
    button.setAttribute('aria-controls',id+'-compact-body');
    const label=document.createElement('span');label.className='compact-toggle-title';label.textContent=titleOf(body)||titleOf(el);
    const state=document.createElement('span');state.className='compact-toggle-state';
    button.append(label,state);body.id=id+'-compact-body';
    el.append(button,body);
    button.addEventListener('click',()=>setOpen(el,body,button,body.hidden));
    const defaultOpen=['marketWorkspace','autopilotPanel'].includes(id);
    setOpen(el,body,button,Object.prototype.hasOwnProperty.call(saved,id)?!!saved[id]:defaultOpen,false);
  });
  document.querySelectorAll('.side-link[href^="#"]').forEach(link=>link.addEventListener('click',()=>{
    const id=link.getAttribute('href').slice(1),el=document.getElementById(id);
    if(!el||!el.classList.contains('is-collapsed'))return;
    const button=el.querySelector(':scope > .compact-section-toggle'),body=el.querySelector(':scope > .compact-section-body');
    if(button&&body)setOpen(el,body,button,true);
  }));
})();
