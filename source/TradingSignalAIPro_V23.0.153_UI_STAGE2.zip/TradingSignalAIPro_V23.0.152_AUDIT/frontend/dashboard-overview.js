/* V22.6.8 — read-only overview; mirrors existing UI, never fetches market data. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const text = (id, value) => { const el = $(id); const next = value || '—'; if (el && el.textContent !== next) el.textContent = next; };
  const value = id => { const el = $(id); return el ? (el.textContent || '').trim() : ''; };
  const compact = (s, n=110) => (s || '').replace(/\s+/g, ' ').trim().slice(0,n);
  function update() {
    const symbol = $('symbol');
    const tf = $('tf');
    const selected = symbol && symbol.selectedOptions[0] ? symbol.selectedOptions[0].textContent.trim() : (symbol?.value || '—');
    text('ovAsset', selected || '—');
    text('ovTimeframe', `تایم‌فریم: ${tf && tf.selectedOptions[0] ? tf.selectedOptions[0].textContent.trim() : '—'}`);
    const price = value('chartStatPrice');
    const change = value('chartStatChange');
    text('ovPrice', price && price !== '—' ? price : 'داده موجود نیست');
    text('ovChange', `تغییر کندل: ${change && change !== '—' ? change : 'نامشخص'}`);
    const signal = $('signalCard');
    const signalText = compact(signal?.innerText || '', 48);
    const signalClass = signal?.className || '';
    text('ovSignal', signalText || 'در انتظار تحلیل');
    text('ovSignalDetail', signalText ? 'آخرین خروجی کارت سیگنال' : 'پس از اجرای تحلیل نمایش داده می‌شود');
    const storm = value('stormList');
    const fresh = value('newListingList');
    const stormCount = (storm.match(/\n/g) || []).length;
    const listingCount = (fresh.match(/\n/g) || []).length;
    const stormAvailable = storm && !/در انتظار|خطا|خالی/.test(storm);
    text('ovStorm', stormAvailable ? 'فهرست به‌روزشده' : 'در انتظار بررسی');
    text('ovStormDetail', fresh ? `تازه‌لیست‌شده‌ها: ${compact(fresh, 58)}` : 'داده تازه‌لیست‌شده هنوز دریافت نشده');
    const learn = compact(value('learnStatus') || value('lrStatus'), 75);
    text('ovLearning', learn || 'آماده‌به‌کار');
    text('ovLearningDetail', value('learnAdequacy') || 'جزئیات آموزش از پنل یادگیری خوانده می‌شود');
    const news = compact(value('newsBody'), 78);
    text('ovNews', news ? 'خوراک خبری موجود' : 'در انتظار خبر');
    text('ovNewsDetail', news || 'هنوز محتوای خبری در پنل ثبت نشده');
    const stamp = new Date().toLocaleTimeString('fa-IR', {hour:'2-digit',minute:'2-digit'});
    text('overviewUpdated', `آخرین همگام‌سازی رابط: ${stamp}`);
    const card = $('ovSignal');
    if (card) card.dataset.signalState = /buy|خرید/i.test(signalText) ? 'buy' : /sell|فروش/i.test(signalText) ? 'sell' : 'neutral';
  }
  document.addEventListener('DOMContentLoaded', () => {
    update();
    const root = document.querySelector('.wrap') || document.body;
    if (window.MutationObserver) new MutationObserver(() => update()).observe(root, {subtree:true,childList:true,characterData:true});
    ['symbol','tf'].forEach(id => $(id)?.addEventListener('change', update));
    window.setInterval(update, 5000);
  });
})();
