/*
 * Local, dependency-free candlestick renderer.
 * It is installed before the optional Lightweight Charts CDN script. If that
 * CDN loads successfully it replaces this compatibility layer; otherwise the
 * dashboard still gets candles, volume, EMA lines, markers and price levels.
 */
(function (global) {
  'use strict';
  if (global.LightweightCharts && typeof global.LightweightCharts.createChart === 'function') return;

  const COLORS = {
    up: '#16c79a', down: '#f05d75', grid: 'rgba(123,145,174,.16)',
    text: '#a8bad2', bg: '#091321', volumeUp: 'rgba(32,201,151,.34)',
    volumeDown: 'rgba(255,101,122,.34)',
  };

  function createChart(container, initialOptions) {
    if (!container) throw new Error('محل نمودار پیدا نشد');
    const canvas = document.createElement('canvas');
    canvas.setAttribute('role', 'img');
    canvas.setAttribute('aria-label', 'نمودار کندلی داخلی');
    canvas.style.cssText = 'display:block;width:100%;height:100%;min-height:360px;touch-action:pan-y;';
    container.innerHTML = '';
    container.appendChild(canvas);

    let width = 0, height = 0, removed = false;
    let options = Object.assign({}, initialOptions || {});
    const series = [];
    const clickHandlers = [];
    const moveHandlers = [];
    let priceRange = { min: 0, max: 1, top: 20, bottom: 300 };
    let plotRange = { left: 14, right: 74, top: 22, bottom: 330 };
    let pointer = null;

    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('مرورگر امکان رسم Canvas را ندارد');

    function candleSeries() { return series.find(s => s.type === 'candles'); }
    function volumeSeries() { return series.find(s => s.type === 'histogram'); }
    function ordered(data) {
      return (Array.isArray(data) ? data.slice() : []).sort((a, b) => Number(a.time) - Number(b.time));
    }
    function resize() {
      if (removed) return;
      const rect = container.getBoundingClientRect();
      width = Math.max(320, Math.floor(rect.width || container.clientWidth || 800));
      height = Math.max(360, Math.floor(rect.height || container.clientHeight || 460));
      const dpr = Math.max(1, Math.min(2, Number(global.devicePixelRatio) || 1));
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = width + 'px';
      canvas.style.height = height + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      render();
    }
    function priceToY(price) {
      const span = Math.max(1e-12, priceRange.max - priceRange.min);
      return plotRange.top + (priceRange.max - Number(price)) / span * (plotRange.bottom - plotRange.top);
    }
    function yToPrice(y) {
      const span = Math.max(1e-12, plotRange.bottom - plotRange.top);
      return priceRange.max - ((Number(y) - plotRange.top) / span) * (priceRange.max - priceRange.min);
    }
    function timeIndex(x) {
      const candles = candleSeries()?.data || [];
      if (!candles.length) return -1;
      const span = Math.max(1, plotRange.right - plotRange.left);
      return Math.max(0, Math.min(candles.length - 1,
        Math.round(((Number(x) - plotRange.left) / span) * (candles.length - 1))));
    }
    function timeToX(index, count) {
      if (count <= 1) return (plotRange.left + plotRange.right) / 2;
      return plotRange.left + (index / (count - 1)) * (plotRange.right - plotRange.left);
    }
    function formatPrice(v) {
      const n = Number(v);
      if (!Number.isFinite(n)) return '—';
      const a = Math.abs(n);
      const digits = a >= 100 ? 2 : a >= 1 ? 4 : a >= .01 ? 6 : 10;
      return n.toLocaleString('en-US', { maximumFractionDigits: digits });
    }
    function formatTime(t) {
      const d = new Date(Number(t) * 1000);
      if (Number.isNaN(d.getTime())) return '';
      return d.toLocaleDateString('fa-IR', { month: '2-digit', day: '2-digit' });
    }
    function render() {
      if (removed || !ctx) return;
      const w = width || Math.max(320, container.clientWidth || 800);
      const h = height || Math.max(360, container.clientHeight || 460);
      if (!canvas.width || !canvas.height) return;
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = COLORS.bg;
      ctx.fillRect(0, 0, w, h);

      const candles = candleSeries()?.data || [];
      const volumes = volumeSeries()?.data || [];
      if (!candles.length) {
        ctx.fillStyle = COLORS.text;
        ctx.font = '13px Tahoma, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('پس از دریافت داده بازار، نمودار نمایش داده می‌شود', w / 2, h / 2);
        return;
      }

      const left = 14, right = Math.max(left + 180, w - 76), top = 22, bottom = h - 82;
      plotRange = { left, right, top, bottom };
      const vals = [];
      candles.forEach(c => vals.push(Number(c.low), Number(c.high)));
      series.filter(s => s.type === 'line').forEach(s => s.data.forEach(p => vals.push(Number(p.value))));
      series.forEach(s => (s.priceLines || []).forEach(p => vals.push(Number(p.price))));
      const valid = vals.filter(Number.isFinite);
      let min = Math.min(...valid), max = Math.max(...valid);
      if (!Number.isFinite(min) || !Number.isFinite(max)) { min = 0; max = 1; }
      const pad = Math.max((max - min) * .07, Math.abs(max) * .0005, 1e-10);
      min -= pad; max += pad;
      if (max <= min) max = min + 1;
      priceRange = { min, max, top, bottom };

      ctx.font = '11px Tahoma, sans-serif';
      ctx.lineWidth = 1;
      ctx.strokeStyle = COLORS.grid;
      ctx.fillStyle = COLORS.text;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      for (let k = 0; k <= 5; k++) {
        const y = top + (bottom - top) * k / 5;
        ctx.beginPath(); ctx.moveTo(left, y); ctx.lineTo(right, y); ctx.stroke();
        const price = max - (max - min) * k / 5;
        ctx.fillText(formatPrice(price), right + 7, y);
      }
      for (let k = 0; k <= 6; k++) {
        const x = left + (right - left) * k / 6;
        ctx.beginPath(); ctx.moveTo(x, top); ctx.lineTo(x, h - 25); ctx.stroke();
        const idx = Math.min(candles.length - 1, Math.round((candles.length - 1) * k / 6));
        ctx.textAlign = 'center';
        ctx.fillText(formatTime(candles[idx].time), x, h - 12);
      }

      const count = candles.length;
      const step = (right - left) / Math.max(1, count - 1);
      const bodyW = Math.max(1.6, Math.min(11, step * .62));
      const maxVol = Math.max(1, ...volumes.map(v => Number(v.value) || 0));
      const volTop = h - 70, volBottom = h - 27;
      volumes.forEach((v, i) => {
        const x = timeToX(i, count), value = Math.max(0, Number(v.value) || 0);
        const barH = value / maxVol * (volBottom - volTop);
        ctx.fillStyle = v.color || 'rgba(130,150,180,.35)';
        ctx.fillRect(x - Math.max(1, bodyW * .42), volBottom - barH,
          Math.max(1, bodyW * .84), barH);
      });

      candles.forEach((c, i) => {
        const x = timeToX(i, count);
        const o = Number(c.open), cl = Number(c.close), hi = Number(c.high), lo = Number(c.low);
        const up = cl >= o, color = up ? COLORS.up : COLORS.down;
        const yo = priceToY(o), yc = priceToY(cl);
        ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = 1.1;
        ctx.beginPath(); ctx.moveTo(x, priceToY(hi)); ctx.lineTo(x, priceToY(lo)); ctx.stroke();
        const bh = Math.max(1.3, Math.abs(yc - yo));
        ctx.fillRect(x - bodyW / 2, Math.min(yo, yc), bodyW, bh);
      });

      // EMA and manually-drawn trend lines are all regular line series.
      series.filter(s => s.type === 'line').forEach(s => {
        const points = s.data.filter(p => Number.isFinite(Number(p.value)));
        if (!points.length) return;
        const byTime = new Map(candles.map((c, i) => [Number(c.time), i]));
        ctx.beginPath(); ctx.strokeStyle = s.options.color || '#91a4ff';
        ctx.lineWidth = Number(s.options.lineWidth || 2);
        let started = false;
        points.forEach(p => {
          let idx = byTime.get(Number(p.time));
          if (idx == null) {
            const firstT = Number(candles[0].time), lastT = Number(candles[count - 1].time);
            idx = Number(p.time) <= firstT ? 0 : Number(p.time) >= lastT ? count - 1 : null;
          }
          if (idx == null) return;
          const x = timeToX(idx, count), y = priceToY(p.value);
          if (!started) { ctx.moveTo(x, y); started = true; } else ctx.lineTo(x, y);
        });
        if (started) ctx.stroke();
      });

      // Signal and historical markers.
      const markerList = candleSeries()?.markers || [];
      markerList.forEach(m => {
        const idx = candles.findIndex(c => Number(c.time) === Number(m.time));
        if (idx < 0) return;
        const c = candles[idx], x = timeToX(idx, count);
        const isBelow = m.position === 'belowBar';
        const y = isBelow ? Math.min(bottom - 2, priceToY(c.low) + 20) : Math.max(top + 2, priceToY(c.high) - 20);
        ctx.fillStyle = m.color || COLORS.text;
        ctx.beginPath();
        ctx.moveTo(x, y + (isBelow ? 7 : -7));
        ctx.lineTo(x - 5, y + (isBelow ? -2 : 2));
        ctx.lineTo(x + 5, y + (isBelow ? -2 : 2));
        ctx.closePath(); ctx.fill();
        if (m.text) { ctx.font = '10px Tahoma,sans-serif'; ctx.textAlign = 'center'; ctx.fillText(String(m.text), x, y + (isBelow ? 18 : -17)); }
      });

      // Signal entry/TP/SL and invalidation levels.
      series.forEach(s => (s.priceLines || []).forEach(line => {
        const y = priceToY(line.price);
        ctx.save(); ctx.strokeStyle = line.color || '#fff'; ctx.lineWidth = Number(line.lineWidth || 1);
        if (line.lineStyle === 2) ctx.setLineDash([5, 4]);
        ctx.beginPath(); ctx.moveTo(left, y); ctx.lineTo(right, y); ctx.stroke(); ctx.setLineDash([]);
        if (line.title) { ctx.fillStyle = line.color || '#fff'; ctx.textAlign = 'left'; ctx.font = '10px Tahoma,sans-serif'; ctx.fillText(String(line.title), left + 4, y - 7); }
        ctx.restore();
      }));

      if (pointer && pointer.x >= left && pointer.x <= right && pointer.y >= top && pointer.y <= bottom) {
        ctx.save(); ctx.strokeStyle = 'rgba(85,214,232,.7)'; ctx.setLineDash([3, 4]);
        ctx.beginPath(); ctx.moveTo(pointer.x, top); ctx.lineTo(pointer.x, h - 25);
        ctx.moveTo(left, pointer.y); ctx.lineTo(right, pointer.y); ctx.stroke(); ctx.restore();
      }
      ctx.fillStyle = '#8ea4c3'; ctx.font = '10px Tahoma,sans-serif'; ctx.textAlign = 'right';
      ctx.fillText('نمودار داخلی · OHLCV', w - 8, 11);
    }

    function addSeries(type, opts) {
      const item = {
        type, options: Object.assign({}, opts || {}), data: [], markers: [], priceLines: [],
        applyOptions(next) { Object.assign(this.options, next || {}); render(); },
        setData(next) { this.data = ordered(next); render(); },
        setMarkers(next) { this.markers = Array.isArray(next) ? next.slice() : []; render(); },
        createPriceLine(lineOptions) {
          const line = Object.assign({}, lineOptions || {}); this.priceLines.push(line); render(); return line;
        },
        removePriceLine(line) { this.priceLines = this.priceLines.filter(x => x !== line); render(); },
        coordinateToPrice(y) { return yToPrice(y); },
        priceToCoordinate(price) { return priceToY(price); },
      };
      series.push(item); render(); return item;
    }

    const timeScale = {
      fitContent() { render(); },
      coordinateToTime(x) {
        const idx = timeIndex(x), data = candleSeries()?.data || [];
        return idx >= 0 && data[idx] ? data[idx].time : null;
      },
      timeToCoordinate(time) {
        const data = candleSeries()?.data || [];
        const idx = data.findIndex(c => Number(c.time) === Number(time));
        return idx < 0 ? null : timeToX(idx, data.length);
      },
    };

    const chart = {
      addCandlestickSeries(opts) { return addSeries('candles', opts); },
      addHistogramSeries(opts) { return addSeries('histogram', opts); },
      addLineSeries(opts) { return addSeries('line', opts); },
      removeSeries(s) { const i = series.indexOf(s); if (i >= 0) series.splice(i, 1); render(); },
      applyOptions(next) {
        Object.assign(options, next || {});
        if (next && (next.width || next.height)) {
          width = Math.max(320, Number(next.width || width));
          height = Math.max(360, Number(next.height || height));
          const dpr = Math.max(1, Math.min(2, Number(global.devicePixelRatio) || 1));
          canvas.width = Math.floor(width * dpr); canvas.height = Math.floor(height * dpr);
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        }
        render();
      },
      timeScale() { return timeScale; },
      subscribeClick(fn) { if (typeof fn === 'function') clickHandlers.push(fn); },
      subscribeCrosshairMove(fn) { if (typeof fn === 'function') moveHandlers.push(fn); },
      remove() {
        removed = true;
        canvas.removeEventListener('click', onClick);
        canvas.removeEventListener('mousemove', onMove);
        canvas.removeEventListener('mouseleave', onLeave);
        if (canvas.parentNode) canvas.parentNode.removeChild(canvas);
      },
      _render: render,
    };

    function eventParam(event) {
      const rect = canvas.getBoundingClientRect();
      const x = event.clientX - rect.left, y = event.clientY - rect.top;
      const idx = timeIndex(x), candles = candleSeries()?.data || [];
      const candle = idx >= 0 ? candles[idx] : null;
      const map = new Map();
      if (candle) {
        const cs = candleSeries(), vs = volumeSeries();
        map.set(cs, candle);
        if (vs) {
          const volume = vs.data.find(v => Number(v.time) === Number(candle.time));
          if (volume) map.set(vs, volume);
        }
        series.filter(s => s.type === 'line').forEach(s => {
          const point = s.data.find(v => Number(v.time) === Number(candle.time));
          if (point) map.set(s, point);
        });
      }
      return { point: { x, y }, time: candle ? candle.time : null, seriesData: map };
    }
    function onClick(event) { const param = eventParam(event); clickHandlers.forEach(fn => { try { fn(param); } catch (_) {} }); }
    function onMove(event) {
      const param = eventParam(event); pointer = param.point; render();
      moveHandlers.forEach(fn => { try { fn(param); } catch (_) {} });
    }
    function onLeave() { pointer = null; render(); moveHandlers.forEach(fn => { try { fn({ time: null, seriesData: new Map() }); } catch (_) {} }); }
    canvas.addEventListener('click', onClick);
    canvas.addEventListener('mousemove', onMove);
    canvas.addEventListener('mouseleave', onLeave);

    resize();
    if (typeof global.ResizeObserver === 'function') {
      const observer = new global.ResizeObserver(resize);
      observer.observe(container);
      const oldRemove = chart.remove.bind(chart);
      chart.remove = function () { try { observer.disconnect(); } catch (_) {} oldRemove(); };
    }
    return chart;
  }

  global.LightweightCharts = {
    createChart,
    CrosshairMode: { Normal: 0, Magnet: 1, Hidden: 2 },
    __fallback: true,
  };
})(window);
