# V22 Data Contract — نسخه 0.1 (مبنای پیاده‌سازی V22.1)

## 1. هدف و اصل

هیچ آموزش، تحلیل قابل معامله یا سفارش Paper نباید بر پایه داده‌ای انجام شود که کیفیت، ترتیب زمانی، تازگی یا منبع آن نامعلوم است. نقض قرارداد باید به خطای صریح و وضعیت `BLOCKED` منجر شود؛ پاک‌سازی بی‌صدا مجاز نیست. Fail-Closed یعنی در شک، سیگنال جدید صادر نشود.

## 2. طرح استاندارد داده

هر کندل باید به این schema نرمال شود:

| فیلد | نوع | قرارداد |
|---|---|---|
| `t` | int64 | زمان بازشدن کندل به میلی‌ثانیه UTC از epoch |
| `open` | float64 | محدود، متناهی و بزرگ‌تر از صفر |
| `high` | float64 | متناهی و بزرگ‌تر یا مساوی open/close/low |
| `low` | float64 | متناهی، مثبت و کوچک‌تر یا مساوی open/close/high |
| `close` | float64 | محدود، متناهی و بزرگ‌تر از صفر |
| `volume` | float64 یا missing با پرچم | متناهی و نامنفی؛ missing نباید بی‌پرچم به صفر تبدیل شود |
| `source` | string metadata | شناسه منبع واقعی؛ `cache` باید صریح باشد |
| `is_closed` | bool metadata | فقط کندل بسته‌شده مجاز به آموزش/تصمیم است |

تایم‌فریم‌های مجاز فعلی از `backend/data.py::TIMEFRAME_SECONDS` گرفته می‌شوند.

## 3. قوانین قطعی (Hard Invariants)

1. **کندل تکراری:** در خروجی پذیرفته‌شده تعداد timestamp تکراری دقیقاً صفر است. تکرار کاملاً یکسان OHLCV می‌تواند با ثبت audit حذف شود؛ دو ردیف با timestamp یکسان و OHLCV متعارض قابل اتکا نیستند و در Paper/Live مسدود می‌شوند.
2. **ترتیب:** خروجی نهایی باید strictly increasing باشد. مرتب‌سازی ورودی معکوس/نامرتب، اگر پس از آن timestampها معتبر و بدون تعارض باشند، یک نرمال‌سازی مجاز است و باید در audit گزارش شود.
3. **OHLC:** همه قیمت‌ها finite و مثبت؛ `high >= max(open, close, low)` و `low <= min(open, close, high)`.
4. **حجم:** منفی/NaN/Inf به‌صورت silent قابل‌قبول نیست. اگر منبع حجم ندارد، `volume_available=false` ثبت شود و مصرف‌کننده‌ای که به حجم وابسته است مجاز به استفاده نباشد.
5. **کندل باز:** کندل جاری/ناتمام از آموزش و سیگنال حذف شود و زمان آخرین کندل بسته‌شده گزارش شود.
6. **نشت آینده:** صفر. تمام ویژگی‌های زمان t فقط از داده‌های زمان <= t استفاده کنند. هر label باید `label_end_t` داشته باشد و هیچ label interval از مرز split عبور نکند.
7. **منبع و cache:** cache باید به‌عنوان داده‌ی stale/offline شناخته شود. cache می‌تواند برای نمایش یا پژوهش آفلاین با هشدار استفاده شود، اما در مسیر سیگنال قابل معامله و Paper Trading زنده، تا زمان تعیین freshness معتبر، ممنوع است.
8. **Fail-Closed:** خطای validator، نبود داده کافی، feed stale یا پایش‌ناپذیر = `BLOCKED`; هیچ fallback به آخرین سیگنال یا مدل/داده‌ی قدیمی برای صدور ورود جدید انجام نشود.

## 4. کنترل فاصله زمانی و شکاف‌ها

- فاصله‌ی موردانتظار هر نماد/تایم‌فریم برابر interval تعریف‌شده است.
- تمام gapها با `expected_t`, `actual_t`, `gap_bars`, منبع و زمان کشف ثبت شوند.
- gap تاریخی لزوماً به معنی حذف کل مجموعه نیست؛ اما باید برچسب کیفیت داشته باشد و از اتصال مصنوعی دو سوی gap در محاسبه اندیکاتور/بازده جلوگیری شود.
- gap در انتهای سری، آخرین کندل کهنه یا فاصله غیرعادی نزدیک زمان جاری، Hard Block برای Paper/Live است.
- آستانه‌های مجاز gap و freshness باید در config نسخه‌دار و متناسب با provider/timeframe تعریف شوند؛ تا وقتی آستانه برای منبعی تعریف نشده، آن منبع برای تصمیم خودکار تأییدشده نیست.

## 5. داده تاریخی و زنده

مسیر مشترک اجباری:

`Provider/Archive -> Raw Capture -> Normalize -> Contract Validate -> Quality Report -> Consumer`

تاریخی و زنده باید از همان normalize/validate استفاده کنند. تفاوت تنها در adapter دریافت و سیاست freshness است. هیچ منبعی مجاز نیست با schema اختصاصی مستقیم وارد Feature Engine شود.

## 6. گزارش الزامی Validator

هر اجرا حداقل این فیلدها را ثبت کند:

`contract_version, symbol, timeframe, source, received_at, first_t, last_closed_t, row_count_raw, row_count_valid, duplicate_count, malformed_count, missing_volume_count, gap_count, max_gap_bars, unclosed_count, cache_age_sec, status, block_reasons`.

`status` یکی از `PASS`, `WARN`, `BLOCKED` است. WARN برای پژوهش قابل مشاهده است؛ برای Paper/Live فقط در صورت policy صریح قابل عبور است.

## 7. آزمون‌های قراردادی لازم

| شناسه | آزمون | انتظار |
|---|---|---|
| DC-001 | duplicate timestamps | duplicate کاملاً یکسان با audit حذف شود؛ OHLCV متعارض در Paper/Live مسدود شود |
| DC-002 | out-of-order timestamps | ورودی مرتب‌سازی شود و audit ثبت کند؛ خروجی strictly increasing باشد |
| DC-003 | NaN/Inf/price<=0 | ردیف نامعتبر شمارش و سیاست رد اجرا شود |
| DC-004 | invalid OHLC geometry | BLOCKED برای batch آلوده یا رد ردیف همراه با نرخ آلودگی |
| DC-005 | negative/missing volume | missing با پرچم؛ منفی رد؛ featureهای حجمی در نبود حجم غیرفعال |
| DC-006 | missing interval | gap report دقیق و عدم ساخت کندل جعلی |
| DC-007 | unclosed final candle | آخرین کندل باز وارد feature/model نشود |
| DC-008 | stale cache | نمایش مجاز با برچسب cache؛ Paper/Live BLOCKED |
| DC-009 | timeframe alignment | timestampها با interval و timezone policy سازگار باشند |
| DC-010 | historical/live parity | یک ورودی خام یکسان از هر دو مسیر، schema و خروجی validator یکسان بدهد |
| DC-011 | causal feature invariance | افزودن کندل‌های آینده نباید featureهای قبلی را تغییر دهد |
| DC-012 | label boundary | `label_end_t` هیچ split بعدی را لمس نکند؛ purge/embargo اثبات شود |
| DC-013 | source failure | قطع provider و نبود داده معتبر => no signal، نه استفاده بی‌هشدار از cache |
| DC-014 | validator failure | trainer و signal endpoint باید fail-closed شوند |

## 8. نگاشت به کد V21

- Data Engine: `backend/data.py::_clean_candles`, `_drop_unclosed`, `fetch_candles`, `SOURCE_FUNCS`.
  - `_clean_candles` در `DataFrame.attrs['normalization_audit']` تعداد ردیف‌های نامعتبر، تکراری، متعارض، حجم ناقص و مرتب‌سازی را ثبت می‌کند.
  - مرتب‌سازی زمانی و حذف duplicate کاملاً یکسان مجاز است؛ این عملیات‌ها به‌تنهایی داده را BLOCK نمی‌کنند. duplicate متعارض و OHLC نامعتبر همچنان قابل‌تشخیص می‌مانند.
  - در حالت `research` حذف جزئی ردیف نامعتبر تا سقف ۵٪ با WARN قابل مشاهده است؛ آلودگی بیش از ۵٪ BLOCK می‌شود. gap و حجم ناقص همچنان WARN باقی می‌مانند و باید در مصرف‌کننده لحاظ شوند.
  - در `paper/live` مرتب‌سازی و حذف duplicate کاملاً یکسان مجاز است، اما حذف OHLC نامعتبر، duplicate متعارض، حجم ناقص، داده stale، cache یا freshness نامعتبر همچنان BLOCK می‌شود.
- مصرف آموزش: `backend/trainer.py::validate_training_batch` و `TrainingSession.run`; مسیر DRL در `backend/api.py::rl_train` از همان gate استفاده می‌کند.
  - آموزش فقط PASS را می‌پذیرد؛ gap، حجم ناقص/صفرگذاری‌شده، OHLC نامعتبر یا duplicate متعارض آموزش را متوقف می‌کند. مرتب‌سازی زمانی و حذف duplicate کاملاً یکسان مانع آموزش نیست.
  - گزارش قرارداد در متادیتای مدل ذخیره می‌شود.
- مصرف تحلیل/سیگنال: `backend/api.py::_run_analysis`, `backend/api.py::_collect_brain_context` و `backend/signal.py::compute_signal`; فیدهای چندتایم‌فریمی هم PASS/freshness می‌خواهند.
  - منابع exchange با حالت paper-grade و `TS_AI_SIGNAL_MAX_AGE_BARS` (پیش‌فرض ۲) اعتبارسنجی می‌شوند؛ آرشیو صریح history در research mode است.
  - Signal Engine با هر وضعیت غیر PASS، HOLD و `data_blocked=true` برمی‌گرداند.
- تاریخچه: `backend/historical.py` و `history_backfill.py`؛ مسیر fetch نهایی همچنان از همان قرارداد می‌گذرد.
- تست‌ها: `tests/test_v22_data_contract.py`, `tests/test_v22_pipeline_contract.py` و تست‌های سازگاری `tests/test_data_normalization.py`, `tests/test_provider_fallback.py`, `tests/test_historical_store.py`, `tests/test_v21_futures_data.py`.

## 9. معیار پذیرش V22.1

- تمام Hard Invariants به تست خودکار تبدیل شده باشند.
- مسیر train فقط پس از PASS ادامه یابد؛ WARN در آموزش مجاز نیست.
- مسیر سیگنال exchange فقط پس از PASS و freshness معتبر ادامه یابد؛ history پژوهشی نیز در Signal Engine باید PASS باشد.
- cache برای Paper/Live مسدود شود؛ cache پژوهشی فقط با برچسب منبع قابل استفاده است.
- گزارش validator در `data_quality` پاسخ تحلیل و متادیتای مدل موجود است.
- هر تغییر normalizer از طریق audit قابل مشاهده است؛ فقط حذف‌های مبهم/نامعتبر یا عبور از آستانه آلودگی، مسیر Provider را مسدود می‌کند.
- هیچ خطای قرارداد به‌صورت silent repair و ادامه‌ی معامله ختم نشود.
