# V22 Evaluation Protocol — نسخه 0.1 (مبنای پیاده‌سازی V22.1/V22.2a)

## 1. اصل پذیرش

هیچ مدل، اندیکاتور، استراتژی یا تغییری در منطق تصمیم‌گیری بدون فرضیه ثبت‌شده، آزمایش مستقل، ارزیابی آماری و اثبات بهبود وارد Champion نمی‌شود. مثبت بودن یک عدد یا دقت جهت‌دار بالا به‌تنهایی معیار پذیرش نیست. «عدم معامله» خروجی معتبر سیستم است.

## 2. سطوح ارزیابی

1. **Data gate:** Data Contract باید PASS باشد؛ داده stale یا مشکوک، ارزیابی قابل‌قبول تولید نمی‌کند.
2. **Code/feature gate:** آزمون causal invariance و leakage باید سبز باشد.
3. **Model gate:** ارزیابی احتمالات و کالیبراسیون روی داده زمانی مستقل.
4. **Strategy gate:** شبیه‌سازی معامله با CostModel یکسان در backtest و Paper.
5. **Portfolio gate:** ریسک کل، همبستگی و drawdown در سطح سبد.
6. **Promotion gate:** Challenger تنها با معیارهای ازپیش‌ثبت‌شده و مقایسه paired با Champion ارتقا می‌یابد.

## 3. طراحی داده و تقسیم زمانی

- تقسیم تصادفی ممنوع است.
- ارزیابی پایه: chronological walk-forward؛ هر fold فقط گذشته را برای fit می‌بیند و آینده را برای ارزیابی.
- Triple Barrier افق ۱۲ کندل دارد؛ هر نمونه باید `entry_t`, `label_end_t`, `entry_pos`, `label_end_pos` داشته باشد. Purge هر نمونه‌ای را حذف می‌کند که بازه‌ی `[entry_t, label_end_t]` آن با مرز بخش بعدی هم‌پوشانی دارد. Embargo یک فاصله‌ی جداگانه و نسخه‌دار برحسب کندل خام است؛ جایگزین purge واقعی نیست.
- فیلتر labelهای neutral/ambiguous نباید index زمانی را فشرده کند. splitها روی timeline خام تعیین می‌شوند؛ آموزش/معیارهای طبقه‌بندی از labelهای معتبر استفاده می‌کنند اما simulator باید تمام کندل‌های پیوسته‌ی OHLC را ببیند.
- مجموعه‌های train، calibration، threshold selection، validation و final test باید از هم تفکیک شوند.
- final test تا پایان انتخاب مدل/پارامتر/آستانه قفل است و برای تنظیم مجدد استفاده نمی‌شود.
- حداقل چند پنجره زمانی و چند رژیم بازار باید گزارش شوند؛ عملکرد تجمیعی نباید ضعف در یک رژیم را پنهان کند.

## 4. معیارهای الزامی

### 4.1 کیفیت احتمال

- Brier Score (کمتر بهتر) در برابر baseline ازپیش‌تعریف‌شده.
- ECE و نمودار reliability.
- decomposition به reliability و resolution در نسخه Performance Center.
- Calibration method و تعداد نمونه calibration ثبت شود؛ Platt و Isotonic فقط با مقایسه out-of-sample انتخاب شوند.
- اگر calibration ناکافی/ناپایدار است، اعتماد مدل `UNASSESSED` و تصمیم `HOLD` باشد.

### 4.2 کیفیت معامله

- Net Expectancy پس از تمام هزینه‌ها > 0.
- Profit Factor > 1.
- Maximum Drawdown کمتر از سقف پورتفوی ازپیش‌ثبت‌شده.
- Sharpe مثبت و پایدار؛ سالانه‌سازی متناسب با تایم‌فریم.
- PSR/DSR با ثبت تعداد trialها و اصلاح Multiple Testing.
- تعداد معاملات بسته‌شده و پوشش (trade coverage) حتماً کنار معیارها گزارش شود.

### 4.3 عدم قطعیت آماری

- فاصله اطمینان ۹۵٪ برای Net Expectancy، PF و اختلاف عملکرد Challenger-Champion با Block Bootstrap زمانی.
- بلوک‌ها باید وابستگی زمانی و هم‌پوشانی معاملات را حفظ کنند.
- برای ارتقا، کران پایین CI امید ریاضی خالص باید از صفر بالاتر باشد؛ اگر CI صفر را قطع کند، نتیجه «نامشخص» است نه «موفق».
- تعداد معاملات حداقل باید پیش از آزمایش در Registry ثبت شود؛ مقدار اولیه پیشنهادی برای Paper برابر ۱۰۰ معامله بسته‌شده است، اما برای بازار/تایم‌فریم کم‌تکرار باید با تحلیل توان آماری توجیه و پیش از دیدن نتیجه ثبت شود.

## 5. CostModel مشترک

هزینه‌ها باید در یک ماژول واحد محاسبه شوند و backtest و Paper از همان تابع/تنظیمات استفاده کنند:

- maker/taker fee یا نرخ قابل تنظیم هر صرافی؛
- slippage با مدل نسخه‌دار؛
- funding برای Futures؛
- spread و در صورت دسترسی اثر نقدشوندگی؛
- هزینه ورود و خروج؛
- partial fills و رد سفارش در Paper در صورت شبیه‌سازی اجرا.

هم نتیجه gross و هم net گزارش شود. اختلاف هزینه مدل‌شده با Paper observed به‌صورت درصد و bps پایش شود. سقف مجاز divergence باید در Registry/config پیش از آزمایش ثبت شود؛ عبور از آن هشدار قرمز و توقف ارتقاست.

## 6. پذیرش Champion/Challenger

- Champion نسخه فعال و قفل‌شده است.
- Challenger در shadow/paper track جداگانه اجرا می‌شود.
- فقط یک Challenger فعال در هر scope (نماد/تایم‌فریم/سبد) مجاز است.
- قبل از شروع آزمایش، فرضیه، معیار اصلی، حداقل نمونه، پنجره، ریسک مجاز و rollback threshold ثبت شود.
- مقایسه روی پنجره‌های زمانی مشترک و ترجیحاً تصمیم‌های paired انجام شود.
- ارتقا فقط با برتری معنادار پس از Multiple Testing Correction و عدم نقض محدودیت ریسک مجاز است.
- در صورت افت عملکرد، rollback به Champion قبلی انجام و علت ثبت شود.

## 7. Paper Trading و عملکرد

- شروع از V22.2a پس از عبور Data Contract و صحت بک‌تست.
- هر track نسخه‌دار باشد؛ V22.2a پس از ورود V22.2b خاموش یا بازنویسی نشود.
- سفارش/معامله با شناسه مدل، registry hypothesis، داده، قیمت سیگنال، قیمت اجرا، هزینه و دلیل خروج ثبت شود.
- عملکرد روی بازه مشترک مقایسه شود.
- اعتماد مدل در نمونه کم با برچسب `PROVISIONAL/LOW_SAMPLE` نمایش داده شود.

## 8. Kill Switch و توقف

Kill Switch سه محرک دارد:

- **Data:** feed stale، نقض Contract، gap بحرانی یا توقف watchdog.
- **Model:** افت Brier/ECE، drift یا افت expectancy در پنجره غلتان.
- **Market:** جهش نوسان، شکاف قیمت یا افت نقدشوندگی.

هر trigger باید ورودی جدید را متوقف کند و رویداد را ثبت کند. رفتار پوزیشن باز جداگانه است: توقف ورود به معنی رها کردن پوزیشن باز نیست؛ فقط طبق سیاست مدیریت/خروج ازپیش‌آزموده‌شده اقدام می‌شود. روشن‌شدن مجدد پس از خطای داده فقط بعد از PASS مجدد و hysteresis؛ پس از خطای مدل نیازمند تأیید انسانی.

## 9. گزارش اجباری هر آزمایش

`hypothesis_id, experiment_id, trial_count, model_version, code_commit, data_hash, config_hash, seed, timeframe, symbols, date_range, split_definition, calibration_method, n_samples, n_trades, coverage, Brier, ECE, reliability, resolution, net_expectancy, profit_factor, max_drawdown, Sharpe, PSR, DSR, bootstrap_CI, regime_metrics, modeled_cost, observed_cost, decision, reason`.

## 10. مقادیر قابل تنظیم و ممنوعیت تغییر پس از مشاهده

سقف Max Drawdown، حداقل تعداد معاملات، سطح PSR، تعداد folds، طول بلوک bootstrap، حد واگرایی هزینه و آستانه‌های drift باید در config نسخه‌دار و Registry پیش از شروع هر آزمایش ثبت شوند. تغییر این مقادیر پس از مشاهده نتیجه، آزمایش جدید محسوب می‌شود و trial_count را افزایش می‌دهد.

## 11. نگاشت به V21 و فایل‌های V22

- بک‌تست و معامله: `backend/signal.py`, `backend/advanced.py`; خروجی پیش‌بینی OOF باید روی timeline خام پیوسته هم‌تراز باشد و labelهای حذف‌شده نباید کندل‌های بین ورود و خروج را از مسیر شبیه‌سازی حذف کنند.
- آموزش و split: `backend/trainer.py`, `backend/features.py`.
- احتمال/کالیبراسیون: `backend/model.py`.
- متادیتا: `backend/storage.py`.
- مدل و مغز تصمیم: `backend/brain.py`, `backend/consensus.py`, `backend/api.py`.
- Paper: `backend/advanced.py` و endpointهای `/api/paper/*` در `backend/api.py`.
- ماژول‌های جدید: `backend/costs.py`, `backend/performance.py`, `backend/experiment_registry.py`, `backend/observability.py`.
