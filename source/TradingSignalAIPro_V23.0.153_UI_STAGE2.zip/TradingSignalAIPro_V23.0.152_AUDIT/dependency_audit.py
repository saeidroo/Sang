"""Offline dependency inventory and consistency audit for TradingSignalAIPro."""
from __future__ import annotations
import importlib.metadata as metadata
import importlib.util
import json
import platform
import struct
import sys
from pathlib import Path

CORE = {
    "flask": ("Flask", "flask"),
    "requests": ("requests", "requests"),
    "numpy": ("numpy", "numpy"),
    "pandas": ("pandas", "pandas"),
    "scikit-learn": ("scikit-learn", "sklearn"),
    "joblib": ("joblib", "joblib"),
    "cryptography": ("cryptography", "cryptography"),
}
OPTIONAL = {
    "xgboost": ("xgboost", "xgboost"),
    "lightgbm": ("lightgbm", "lightgbm"),
    "pywebview": ("pywebview", "webview"),
    "gymnasium": ("gymnasium", "gymnasium"),
    "stable-baselines3": ("stable-baselines3", "stable_baselines3"),
    "finrl": ("finrl", "finrl"),
    "tvdatafeed": ("tvDatafeed", "tvDatafeed"),
}


def _item(dist: str, module: str, required: bool) -> dict:
    try:
        version = metadata.version(dist)
        installed = True
    except metadata.PackageNotFoundError:
        version, installed = None, importlib.util.find_spec(module) is not None
    return {"distribution": dist, "module": module, "required": required,
            "installed": installed, "version": version}


def audit() -> dict:
    core = [_item(d, m, True) for d, m in CORE.values()]
    optional = [_item(d, m, False) for d, m in OPTIONAL.values()]
    missing = [x["distribution"] for x in core if not x["installed"]]
    py_ok = (3, 10) <= sys.version_info[:2] < (3, 13)
    bits = struct.calcsize("P") * 8
    arch_ok = bits == 64
    return {
        "schema_version": "dependency-audit-v1",
        "python": platform.python_version(),
        "python_supported": py_ok,
        "architecture_bits": bits,
        "architecture_supported": arch_ok,
        "core": core,
        "optional": optional,
        "optional_install_files": {
            "desktop": Path("requirements-desktop.txt").is_file(),
            "tradingview": Path("requirements-tradingview.txt").is_file(),
            "reinforcement_learning": Path("requirements-rl.txt").is_file(),
        },
        "missing_core": missing,
        "status": "BLOCKED" if missing or not py_ok or not arch_ok else "READY",
        "notes": [
            "Optional XGBoost/LightGBM models fall back to sklearn estimators when absent.",
            "FinRL/RL packages are isolated in requirements-rl.txt.",
            "This offline inventory does not replace pip check or vulnerability scanning.",
        ],
    }


if __name__ == "__main__":
    report = audit()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report["status"] == "READY" else 2)
