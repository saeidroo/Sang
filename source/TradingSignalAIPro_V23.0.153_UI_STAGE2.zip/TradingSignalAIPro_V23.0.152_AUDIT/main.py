"""
Trading Signal AI Pro V23.0.152 — ATR risk and futures funding-aware paper trader launcher.

Starts the Flask backend in a background thread, then opens a PyWebView
window pointed at it. If PyWebView is unavailable, falls back to opening
the system browser.

Usage:
    python main.py                # desktop window
    python main.py --browser      # open in browser instead
    python main.py --port 8765    # custom port
    # Server is intentionally loopback-only; remote binding is disabled.
"""
import sys
import os
import time
import threading
import webbrowser
import argparse
import atexit
from pathlib import Path

# Ensure backend is importable
HERE = Path(__file__).parent.resolve()
sys.path.insert(0, str(HERE))

from backend.api import app, run_server


def wait_for_server(host, port, timeout=10):
    """Wait until the Flask server responds."""
    import urllib.request
    url = f"http://{host}:{port}/api/health"
    start = time.time()
    while time.time() - start < timeout:
        try:
            urllib.request.urlopen(url, timeout=1)
            return True
        except Exception:
            time.sleep(0.15)
    return False


def graceful_shutdown(*_event_args):
    """Best-effort shutdown: persist paper state and signal background workers."""
    results = {}
    try:
        from backend import autopilot
        results['autopilot'] = autopilot.shutdown(timeout=8.0)
    except Exception as exc:
        results['autopilot_error'] = str(exc)[:240]
    for module_name, fn_name in (('scout', 'stop_background'), ('longrun', 'stop'), ('historical', 'stop_backfill')):
        try:
            module = __import__(f'backend.{module_name}', fromlist=[fn_name])
            results[module_name] = bool(getattr(module, fn_name)())
        except Exception as exc:
            results[f'{module_name}_error'] = str(exc)[:200]
    print(f"Shutdown report: {results}", flush=True)
    return results


def open_desktop_window(host, port, title="Trading Signal AI Pro v23.0.152", width=1500, height=950):
    """Open a PyWebView desktop window."""
    try:
        import webview
    except Exception as e:
        print(f"PyWebView not available ({e}), falling back to browser.")
        url = f"http://{host}:{port}/"
        webbrowser.open(url)
        print(f"Opened in browser: {url}")
        print("Press Ctrl+C to stop.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nShutting down.")
            graceful_shutdown()
        return

    url = f"http://{host}:{port}/"
    window = webview.create_window(title, url, width=width, height=height,
                                   min_size=(900, 600))
    try:
        window.events.closed += graceful_shutdown
    except Exception:
        pass
    webview.start(debug=False)
    print("Window closed. Shutting down.")
    graceful_shutdown()


def main():
    parser = argparse.ArgumentParser(description="Trading Signal AI Pro")
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--browser', action='store_true',
                        help='Open in browser instead of desktop window')
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    # Fail before starting threads or opening a browser if a remote host is requested.
    from backend.local_security import is_loopback_bind_host
    if not is_loopback_bind_host(args.host):
        parser.error('Remote binding is disabled because the local API has no user authentication. Use 127.0.0.1, localhost, or ::1.')

    # Show startup banner
    print("=" * 60)
    print("  Trading Signal AI Pro V23.0.152 — AutoPilot · ATR Net R/R · Funding · Paper Only")
    print("  ML: XGBoost + LightGBM + RandomForest + ExtraTrees + HistGB + NeuralNet")
    print("  V19: 13-source brain (divergence/ichimoku/volume) · confluence shaping ·")
    print("        scenario+EV inside signals · strategy-quality gate · Persian reports")
    print("=" * 60)
    print(f"  Server: http://{args.host}:{args.port}")
    from backend.storage import get_models_dir
    print(f"  Models dir: {get_models_dir()}")
    print("=" * 60)
    print()

    # Start Flask in background thread
    def flask_thread():
        # Disable reloader to avoid double-start
        run_server(host=args.host, port=args.port, debug=args.debug)
    t = threading.Thread(target=flask_thread, daemon=True)
    t.start()

    # Wait for server to be ready
    print("Starting backend...")
    if not wait_for_server(args.host, args.port, timeout=15):
        print("ERROR: Backend failed to start.")
        sys.exit(1)
    print("Backend ready.")

    if os.getenv('AUTO_BACKFILL','0').strip()=='1':
        from backend.historical import start_backfill
        syms=[x.strip().upper() for x in os.getenv('HISTORY_SYMBOLS','ALL_USDT,GOLD,SILVER').split(',') if x.strip()]
        tfs=[x.strip() for x in os.getenv('HISTORY_TIMEFRAMES','1h,4h,1d').split(',') if x.strip()]
        started=start_backfill(syms,tfs,os.getenv('HISTORY_START','2017-01-01T00:00:00+00:00'))
        print(f'[history] backfill started={started}: {syms} / {tfs}')

    if os.getenv('AUTO_RETRAIN','0').strip()=='1':
        # Same engine as the "آموزش خودکار چندساعته" button in the web UI.
        from backend import longrun
        auto_resume = os.getenv('AUTO_RETRAIN_RESUME', '1').strip() == '1'
        try:
            cfg = longrun.start(longrun.config_from_env(), resume=auto_resume)
            print(f"[longrun] started (resume={auto_resume}): {cfg['hours']:g} h, "
                  f"{len(cfg['symbols'])} markets x {cfg['timeframes']}")
        except Exception as exc:
            print(f'[longrun] could not start: {exc}')

    if args.browser:
        url = f"http://{args.host}:{args.port}/"
        webbrowser.open(url)
        print(f"\nOpened in browser: {url}\nPress Ctrl+C to stop.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nShutting down.")
            graceful_shutdown()
    else:
        open_desktop_window(args.host, args.port)


if __name__ == '__main__':
    atexit.register(graceful_shutdown)
    main()
