#!/usr/bin/env bash
# Trading Signal AI Pro — Linux/macOS installer
# Usage:  bash install.sh
set -e

echo "================================================"
echo "  Trading Signal AI Pro — نصب‌کننده"
echo "================================================"

cd "$(dirname "$0")"

# Detect a supported 64-bit Python. The project targets Python 3.10-3.12.
PY=""
for c in python3.12 python3.11 python3.10 python3 python; do
    if command -v "$c" >/dev/null 2>&1 && \
       "$c" -c 'import struct,sys; raise SystemExit(0 if sys.version_info[:2] in ((3,10),(3,11),(3,12)) and struct.calcsize("P") == 8 else 1)' >/dev/null 2>&1; then
        PY="$c"
        break
    fi
done
if [ -z "$PY" ]; then
    echo "✖ نسخهٔ سازگار پایتون پیدا نشد. Python 3.10، 3.11 یا 3.12 با معماری ۶۴بیتی نصب کنید."
    echo "   https://www.python.org/downloads/"
    exit 1
fi
echo "• پایتون: $($PY --version)"
"$PY" windows_preflight.py

# Check pip
if ! "$PY" -m pip --version >/dev/null 2>&1; then
    echo "✖ pip نصب نیست."
    exit 1
fi

# Optional: create virtual environment
read -r -p "می‌خواهید در محیط مجازی (venv) نصب شود؟ [y/N] " USE_VENV
if [[ "$USE_VENV" =~ ^[Yy]$ ]]; then
    "$PY" -m venv venv
    # shellcheck disable=SC1091
    source venv/bin/activate
    PY=python
    echo "• محیط مجازی ساخته شد."
fi

echo "• نصب وابستگی‌ها..."
"$PY" -m pip install --upgrade pip --quiet
"$PY" -m pip install -r requirements.txt
"$PY" -m pip check
"$PY" dependency_audit.py
"$PY" smoke_check.py

# Linux: optional webview deps
if [[ "$(uname -s)" == "Linux" ]] && ! "$PY" -c "import webview" 2>/dev/null; then
    echo
    echo "⚠ برای اجرای پنجره‌ی دسکتاپ در لینوکس، کتابخانه‌های زیر لازم است:"
    echo "   sudo apt install libgtk-3-dev libwebkit2gtk-4.1-dev"
    echo "   (یا نسخه‌ی قدیمی‌تر: libwebkit2gtk-4.0-dev)"
    echo "   در غیر این صورت، برنامه در مرورگر اجرا می‌شود."
fi

echo
echo "✅ نصب کامل شد!"
echo
echo "برای اجرا:"
if [[ "$USE_VENV" =~ ^[Yy]$ ]]; then
    echo "  source venv/bin/activate"
fi
echo "  $PY main.py"
echo
echo "یا برای اجرا در مرورگر:"
echo "  $PY main.py --browser"
echo
echo "مدل‌های آموزش‌دیده در این پوشه ذخیره می‌شوند:"
echo "  ~/.trading_ai_models/"
echo
