from backend import storm_learning


def _candidate(symbol, regime, *, volume=1.7, buy=0.70, buy_change=0.10, strength=90.0):
    return {
        'symbol': symbol, 'price': 100.0, 'score': 52.0, 'phase': 'early',
        'direction': 'up', 'verified': True, 'fresh': True,
        'pre_pump_candidate': True, 'pre_pump_score': 78.0,
        'pre_pump_grade': 'exchange_taker',
        'volume_acceleration_ratio': volume, 'recent_volume_ratio': 1.8,
        'buy_pressure_ratio': buy, 'buy_pressure_change': buy_change,
        'flow_persistence': 0.82, 'pre_pump_price_change_1h_pct': 0.4,
        'relative_strength_score': strength, 'btc_regime_4h': regime,
    }


def test_same_pre_pump_combo_is_evaluated_separately_by_btc_regime(monkeypatch, tmp_path):
    monkeypatch.setattr(storm_learning, 'DB_PATH', tmp_path / 'learning.sqlite3')
    t0 = 1_700_000_000.0
    items, snapshots, later_prices = [], {}, {}

    # Identical signal evidence, different BTC regimes and distinct outcomes.
    for regime, prefix, later_price in (
        ('up', 'UP', 101.5),
        ('down', 'DN', 97.0),
        ({'state': 'neutral'}, 'NE', 100.1),
        ('unavailable', 'UK', 101.5),
    ):
        for i in range(6):
            symbol = f'{prefix}{i}USDT'
            items.append(_candidate(symbol, regime))
            base = symbol[:-4]
            snapshots[base] = {'price': 100.0}
            later_prices[base] = {'price': later_price}

    stored = storm_learning.record_scan(items, timestamp=t0, snapshots=snapshots)
    assert stored['pre_pump_events_recorded'] == 24
    resolved = storm_learning.record_scan([], timestamp=t0 + 3600, snapshots=later_prices)
    assert resolved['pre_pump_outcomes_resolved'] == 24

    report = storm_learning.pre_pump_performance_report()['feature_combo_learning']
    cohorts = report['cohorts']
    by_regime = {c['market_regime']: c for c in cohorts}

    assert set(by_regime) == {'UP', 'DOWN', 'NEUTRAL', 'UNKNOWN'}
    assert by_regime['UP']['horizons']['1h']['successes'] == 6
    assert by_regime['DOWN']['horizons']['1h']['failures'] == 6
    assert by_regime['NEUTRAL']['horizons']['1h']['neutral'] == 6
    assert by_regime['UNKNOWN']['horizons']['1h']['successes'] == 6
    assert by_regime['UNKNOWN']['market_regime_label_fa'] == 'وضعیت بازار نامشخص'
    assert report['threshold_policy'] == 'descriptive_only_no_auto_tuning'
    assert report['regime_cohort_counts'] == {'UP': 1, 'DOWN': 1, 'NEUTRAL': 1, 'UNKNOWN': 1}


def test_regime_parser_accepts_nested_btc_context_and_fails_closed():
    assert storm_learning._market_regime({'btc_regime_4h': {'state': 'up'}}) == 'UP'
    assert storm_learning._market_regime({'features': {'btc_regime_4h': {'state': 'down'}}}) == 'DOWN'
    assert storm_learning._market_regime({'btc_regime_4h': 'sideways'}) == 'UNKNOWN'
    assert storm_learning._market_regime({}) == 'UNKNOWN'
