import threading

from backend import autopilot, paper_process_lease


def _reset_worker_state(monkeypatch):
    with autopilot._LOCK:
        autopilot._STATE['manager_thread'] = None
        autopilot._STATE['entry_thread'] = None
    monkeypatch.setattr(autopilot, 'status', lambda: {'paper_only': True})
    monkeypatch.setattr(autopilot, '_watchlist_view', lambda: {'symbols': ['BTC/USDT']})


def test_manual_cycle_claims_and_releases_transient_lease(tmp_path, monkeypatch):
    db = tmp_path / 'paper.sqlite3'
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(db))
    _reset_worker_state(monkeypatch)
    old_token = autopilot._PROCESS_LEASE_TOKEN
    autopilot._PROCESS_LEASE_TOKEN = None
    monkeypatch.setattr(autopilot, '_cycle_once', lambda: {'entry': {'opened': 0}})
    try:
        result = autopilot.run_manual_cycle()
        assert result['ok'] is True
        assert result['cycle']['entry']['opened'] == 0
        assert paper_process_lease.lease_status(db)['held'] is False
    finally:
        autopilot._PROCESS_LEASE_TOKEN = old_token


def test_manual_cycle_blocks_when_another_process_owns_lease(tmp_path, monkeypatch):
    db = tmp_path / 'paper.sqlite3'
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(db))
    _reset_worker_state(monkeypatch)
    old_token = autopilot._PROCESS_LEASE_TOKEN
    autopilot._PROCESS_LEASE_TOKEN = None
    external = paper_process_lease.claim_lease(db, owner_token='external-owner')
    assert external['ok']
    called = []
    monkeypatch.setattr(autopilot, '_cycle_once', lambda: called.append(True))
    try:
        result = autopilot.run_manual_cycle()
        assert result['ok'] is False
        assert result['reason'] == 'autopilot_process_lease_held'
        assert not called
    finally:
        paper_process_lease.release_lease(db, 'external-owner')
        autopilot._PROCESS_LEASE_TOKEN = old_token


def test_manual_cycle_blocks_while_background_worker_is_alive(tmp_path, monkeypatch):
    db = tmp_path / 'paper.sqlite3'
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(db))
    _reset_worker_state(monkeypatch)
    old_token = autopilot._PROCESS_LEASE_TOKEN
    autopilot._PROCESS_LEASE_TOKEN = None
    stop = threading.Event()
    worker = threading.Thread(target=stop.wait, daemon=True)
    worker.start()
    with autopilot._LOCK:
        autopilot._STATE['manager_thread'] = worker
    called = []
    monkeypatch.setattr(autopilot, '_cycle_once', lambda: called.append(True))
    try:
        result = autopilot.run_manual_cycle()
        assert result['ok'] is False
        assert result['reason'] == 'autopilot_background_worker_active'
        assert not called
        assert not paper_process_lease.lease_status(db)['held']
    finally:
        stop.set()
        worker.join(2)
        with autopilot._LOCK:
            autopilot._STATE['manager_thread'] = None
        autopilot._PROCESS_LEASE_TOKEN = old_token
