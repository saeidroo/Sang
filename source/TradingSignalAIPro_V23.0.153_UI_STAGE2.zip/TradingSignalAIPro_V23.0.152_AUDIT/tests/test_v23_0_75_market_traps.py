import pytest
from backend.market_trap_detector import detect_market_traps


def test_bull_trap_candidate_and_paper_only():
    c={'symbol':'ETHUSDT','direction':'short','swing_high':105,
       'candles':[{'open':102,'high':104,'low':101,'close':103,'volume':100},
                  {'open':104,'high':107,'low':103,'close':104,'volume':180}]}
    r=detect_market_traps([c]); x=r['results'][0]
    assert x['trap_type']=='BULL_TRAP_CANDIDATE'
    assert x['decision']=='WATCH' and x['entry_authorized'] is False
    assert r['real_orders_enabled'] is False and r['capital_usdt']==1000


def test_bear_trap_candidate():
    c={'symbol':'BTCUSDT','swing_low':95,
       'candles':[{'open':98,'high':99,'low':96,'close':97},
                  {'open':96,'high':97,'low':93,'close':96}]}
    x=detect_market_traps([c])['results'][0]
    assert x['trap_type']=='BEAR_TRAP_CANDIDATE'


def test_invalid_and_missing_data_fail_closed():
    x=detect_market_traps([{'symbol':'X','candles':[]}])['results'][0]
    assert x['decision']=='INSUFFICIENT_DATA' and x['entry_authorized'] is False
    with pytest.raises(ValueError): detect_market_traps({})


def test_conflicting_sweeps_are_not_directional_signal():
    c={'symbol':'X','swing_high':105,'swing_low':95,
       'candles':[{'open':100,'high':104,'low':96,'close':100},
                  {'open':100,'high':107,'low':93,'close':100}]}
    x=detect_market_traps([c])['results'][0]
    assert x['decision']=='CONFLICTING_EVIDENCE'
