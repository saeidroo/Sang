import pandas as pd
import pytest
from backend.portfolio_risk import detect_breakout_pullback


def long_frame(last_close=111.5, last_low=109.8):
    closes = [100,103,108,108,104,102,103,105,109,113,last_close]
    highs = [101,105,110,110,106,104,105,107,113,114,112]
    lows = [99,102,107,107,103,101,102,104,108,112,last_low]
    opens = [c - .4 for c in closes]
    return pd.DataFrame({'open': opens, 'high': highs, 'low': lows, 'close': closes})


def test_long_breakout_waits_then_confirms_retest():
    df = long_frame()
    result = detect_breakout_pullback(df, side='LONG', atr_value=2, pivot_width=2)
    assert result['state'] == 'PULLBACK_CONFIRMED'
    assert result['level'] == 110
    assert result['data_policy'] == 'CLOSED_CANDLES_ONLY'


def test_long_retest_without_reclaim_does_not_confirm():
    result = detect_breakout_pullback(long_frame(last_close=109.5, last_low=108.9),
                                      side='LONG', atr_value=2, pivot_width=2)
    assert result['state'] == 'RETEST_FAILED'


def test_latest_breakout_is_not_immediate_pullback_entry():
    df = long_frame().iloc[:-1].copy()
    result = detect_breakout_pullback(df, side='LONG', atr_value=2, pivot_width=2)
    assert result['state'] == 'WAITING_FOR_RETEST'


def test_invalid_side_and_short_input_validation():
    with pytest.raises(ValueError):
        detect_breakout_pullback(long_frame(), side='FLAT', atr_value=2, pivot_width=2)
    with pytest.raises(ValueError):
        detect_breakout_pullback(long_frame(), side='LONG', atr_value=0, pivot_width=2)
