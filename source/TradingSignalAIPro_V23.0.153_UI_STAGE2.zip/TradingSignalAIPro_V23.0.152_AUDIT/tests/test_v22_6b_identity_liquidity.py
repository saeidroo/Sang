from backend.token_identity import verify_token_contract, _CACHE, _LOCK

def setup_function():
    with _LOCK: _CACHE.clear()
from backend.liquidity_stability import LiquidityStabilityTracker

ADDR='0x'+'a'*40

def test_identity_requires_all_exact_fields():
    r=verify_token_contract('', 'ethereum', ADDR, fetch_json=lambda u: {})
    assert not r['verified'] and r['status']=='identity_unverified'

def test_identity_exact_contract_match():
    def fake(url): return {'platforms': {'ethereum': ADDR}}
    r=verify_token_contract('sample-coin','ethereum',ADDR,fetch_json=fake,now=1)
    assert r['verified'] and r['status']=='identity_verified'

def test_identity_mismatch_fails_closed():
    def fake(url): return {'platforms': {'ethereum': '0x'+'b'*40}}
    r=verify_token_contract('sample-coin','ethereum',ADDR,fetch_json=fake,now=2)
    assert not r['verified'] and r['status']=='identity_mismatch'

def test_identity_source_failure_is_unverified():
    def fail(url): raise RuntimeError('offline')
    r=verify_token_contract('sample-coin','ethereum',ADDR,fetch_json=fail,now=3)
    assert not r['verified'] and r['status']=='identity_check_unavailable'

def test_liquidity_needs_multiple_spaced_observations():
    t=LiquidityStabilityTracker(min_interval_seconds=600,required_samples=3,min_span_seconds=1200)
    a=t.record('Binance','ABCUSDT',500000,timestamp=1000)
    b=t.record('Binance','ABCUSDT',510000,timestamp=1600)
    c=t.record('Binance','ABCUSDT',490000,timestamp=2200)
    assert a['status']=='insufficient_observations'
    assert b['status']=='insufficient_observations'
    assert c['stable'] is True
    assert c['entry_ready'] is False

def test_liquidity_spike_does_not_count_as_stable():
    t=LiquidityStabilityTracker(min_interval_seconds=600,required_samples=3,min_span_seconds=1200)
    t.record('MEXC','XYZUSDT',500000,timestamp=1000)
    t.record('MEXC','XYZUSDT',500000,timestamp=1600)
    r=t.record('MEXC','XYZUSDT',10000,timestamp=2200)
    assert r['status']=='liquidity_unstable' and not r['stable']

def test_too_soon_and_out_of_order_rejected():
    t=LiquidityStabilityTracker(min_interval_seconds=600)
    t.record('Bybit','QUSDT',200000,timestamp=1000)
    assert t.record('Bybit','QUSDT',200000,timestamp=1100)['status']=='sample_too_soon'
    assert t.record('Bybit','QUSDT',200000,timestamp=900)['status']=='out_of_order_snapshot'
