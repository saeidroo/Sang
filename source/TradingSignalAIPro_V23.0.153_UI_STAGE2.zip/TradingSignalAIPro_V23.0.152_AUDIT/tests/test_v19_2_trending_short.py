"""V19.2: trending coins, 5m/30m timeframes, one-sentence verdict."""
from backend import analyst, trending
from backend.api import app, _validated_market
from backend.data import TIMEFRAME_SECONDS, _aggregate
from backend.memory import TF_MS as MEM_TF
from backend.brain import TF_MS as BRAIN_TF
import pandas as pd


def _t(sym, chg, vol, price=1.0):
    return {'symbol': sym, 'priceChangePercent': str(chg), 'quoteVolume': str(vol), 'lastPrice': str(price)}


def test_new_timeframes_are_registered_everywhere():
    for tf, sec in (('5m', 300), ('30m', 1800)):
        assert TIMEFRAME_SECONDS[tf] == sec
        assert MEM_TF[tf] == sec * 1000 and BRAIN_TF[tf] == sec * 1000
        assert _validated_market('BTCUSDT', tf)[1] == tf
    c = app.test_client()
    assert '5m' in c.get('/api/timeframes').get_json()['timeframes']


def test_coinbase_style_30m_aggregation():
    t0 = 1_700_000_400_000 - (1_700_000_400_000 % 1_800_000)
    df = pd.DataFrame({'t': [t0 + i * 900_000 for i in range(4)], 'open': [1, 2, 3, 4],
                       'high': [2, 3, 4, 5], 'low': [0, 1, 2, 3], 'close': [2, 3, 4, 5], 'volume': [1] * 4})
    out = _aggregate(df, 1800)
    assert len(out) == 2 and out.iloc[0]['open'] == 1 and out.iloc[0]['close'] == 3
    assert out.iloc[0]['volume'] == 2


def test_trending_filters_and_ranks():
    raw = [_t('PEPEUSDT', 40, 900_000_000), _t('ABCUSDT', 80, 1_000_000),          # illiquid -> dropped
           _t('USDCUSDT', 0.01, 9e9), _t('BTCUPUSDT', 50, 9e8),                     # stable / leveraged -> dropped
           _t('SOLUSDT', -12, 500_000_000), _t('ETHBTC', 5, 9e9), _t('BADUSDT', 'x', 9e9)]
    out = trending.rank_tickers(raw, 10)
    syms = [r['symbol'] for r in out['trending']]
    assert syms == ['PEPEUSDT', 'SOLUSDT']
    assert [r['symbol'] for r in out['gainers']] == ['PEPEUSDT']
    assert [r['symbol'] for r in out['losers']] == ['SOLUSDT']
    assert out['trending'][1]['direction'] == 'down'


def test_trending_route_reports_error_not_fake_data(monkeypatch=None):
    orig = trending._fetch_tickers
    trending._CACHE.update(ts=0.0, data=None)
    trending._fetch_tickers = lambda: (_ for _ in ()).throw(RuntimeError('offline'))
    try:
        r = app.test_client().get('/api/trending')
        assert r.status_code == 502 and 'error' in r.get_json()
        assert app.test_client().get('/api/trending?limit=abc').status_code == 400
    finally:
        trending._fetch_tickers = orig


def _analysis(kind, score, conf, short):
    return {'symbol': 'BTCUSDT', 'timeframe': '1h', 'price': 100.0,
            'signal': {'kind': kind, 'power': 0.6, 'scenario': {'ev_net_pct': 0.4}},
            'brain': {'score': score, 'confidence': conf, 'components': {}},
            'market_context': {'short_term': short}}


def test_verdict_is_one_sentence_and_uses_short_term():
    up = [{'timeframe': '5m', 'score': 0.5, 'available': True, 'momentum_5_pct': 0.3},
          {'timeframe': '30m', 'score': 0.4, 'available': True, 'momentum_5_pct': 0.5}]
    dn = [dict(x, score=-0.5) for x in up]
    v = analyst.build_verdict(_analysis('BUY', 0.5, 0.7, up), 0.45)
    assert v.startswith('برآورد کلی') and v.endswith('.') and '. ' not in v and 'صعودی' in v and 'هم‌راستا' in v
    v = analyst.build_verdict(_analysis('BUY', 0.5, 0.7, dn), -0.5)
    assert 'تعارض' in v
    v = analyst.build_verdict(_analysis('HOLD', 0.0, 0.1, []), None)
    assert 'خنثی' in v and 'در دسترس نبود' in v and 'صبر' in v


def test_local_report_contains_short_term_section_and_verdict():
    rep = analyst.local_report(_analysis('HOLD', 0.0, 0.1, []))
    assert rep['verdict'].startswith('برآورد کلی')
    assert any(s['key'] == 'short_term' for s in rep['sections'])
