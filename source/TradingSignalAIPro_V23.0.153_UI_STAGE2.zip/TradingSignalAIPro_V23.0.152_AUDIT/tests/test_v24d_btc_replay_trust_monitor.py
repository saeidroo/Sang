import json
from datetime import datetime, timezone, timedelta
import pytest
from backend.btc_replay_trust_monitor import (evaluate_replay_trust_policy,
    append_replay_trust_health_report, audit_trust_health_reports)


def test_rotation_policy_warns_on_age_and_sequence(tmp_path,monkeypatch):
    root=tmp_path/'trust'; monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR',str(root))
    from backend import signed_anchor
    signed_anchor.ensure_keypair()
    active=json.loads((root/'active_key.json').read_text())
    active['created_at']=(datetime(2024,1,1,tzinfo=timezone.utc)).isoformat()
    (root/'active_key.json').write_text(json.dumps(active))
    (root/'sequence.json').write_text(json.dumps({'highest_sequence':995}))
    report=evaluate_replay_trust_policy(max_key_age_days=365,rotation_warning_days=30,
        max_signing_sequence=1000,sequence_warning_margin=10,
        now=datetime(2026,11,17,tzinfo=timezone.utc))
    assert report['status']=='WARNING'
    assert 'active_key_rotation_overdue' in report['warnings']
    assert 'signing_sequence_limit_approaching' in report['warnings']


def test_health_report_log_is_append_only_and_auditable(tmp_path,monkeypatch):
    monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR',str(tmp_path/'trust'))
    from backend import signed_anchor
    signed_anchor.ensure_keypair()
    report=evaluate_replay_trust_policy()
    path=tmp_path/'ops'/'health.jsonl'
    append_replay_trust_health_report(report,report_path=path)
    append_replay_trust_health_report(report,report_path=path)
    assert audit_trust_health_reports(path)['report_count']==2
    rows=[json.loads(x) for x in path.read_text().splitlines()]
    rows[0]['report']['status']='CRITICAL'
    path.write_text('\n'.join(json.dumps(x) for x in rows)+'\n')
    with pytest.raises(ValueError,match='hash_mismatch'):
        audit_trust_health_reports(path)


def test_monitor_rejects_naive_clock(tmp_path,monkeypatch):
    monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR',str(tmp_path/'trust'))
    from backend import signed_anchor
    signed_anchor.ensure_keypair()
    with pytest.raises(ValueError,match='timezone_aware'):
        evaluate_replay_trust_policy(now=datetime(2026,11,17))
