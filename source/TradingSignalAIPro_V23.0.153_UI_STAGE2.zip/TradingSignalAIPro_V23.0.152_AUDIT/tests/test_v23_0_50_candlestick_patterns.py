import pandas as pd
from backend.candlestick_patterns import analyze_candlestick_patterns


def candles(last_open=9.0, last_close=12.0):
    rows=[]
    for _ in range(19): rows.append({'open':10.0,'high':10.5,'low':9.5,'close':10.0,'volume':100.0})
    rows.append({'open':11.0,'high':11.2,'low':9.8,'close':10.0,'volume':100.0})
    rows.append({'open':last_open,'high':max(last_open,last_close)+0.2,'low':min(last_open,last_close)-0.2,'close':last_close,'volume':200.0})
    return pd.DataFrame(rows)


def test_bullish_engulfing_is_aligned_for_long():
    result=analyze_candlestick_patterns(candles(),side='LONG')
    assert 'BULLISH_ENGULFING' in [p['name'] for p in result['patterns']]
    assert not result['blocking']


def test_bullish_engulfing_with_volume_blocks_short():
    result=analyze_candlestick_patterns(candles(),side='SHORT')
    assert result['state']=='OPPOSING_CONFIRMED'
    assert result['blocking'] is True
    assert result['volume_confirmed'] is True


def test_shooting_star_is_detected():
    df=candles(10.1,10.0)
    df.loc[df.index[-1],['high','low']]=[12.0,9.9]
    result=analyze_candlestick_patterns(df,side='LONG')
    assert 'SHOOTING_STAR' in [p['name'] for p in result['patterns']]


def test_bad_ohlc_fails_closed():
    df=candles(); df.loc[df.index[-1],'high']=1
    result=analyze_candlestick_patterns(df,side='LONG')
    assert result['state']=='INVALID'
    assert not result['blocking']


def test_invalid_side_raises():
    try: analyze_candlestick_patterns(candles(),side='BUY')
    except ValueError: return
    assert False, 'invalid side accepted'
