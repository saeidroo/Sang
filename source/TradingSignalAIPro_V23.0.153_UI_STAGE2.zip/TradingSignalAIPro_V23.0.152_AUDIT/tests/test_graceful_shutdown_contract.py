from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_autopilot_shutdown_is_fail_closed_and_checkpoints():
    source = (ROOT / 'backend' / 'autopilot.py').read_text(encoding='utf-8')
    body = source.split('def shutdown(', 1)[1].split('\ndef status(', 1)[0]
    assert 'entries_enabled"] = False' in body
    assert 'entry_event.set()' in body and 'manager_event.set()' in body
    assert '_persist_runtime_state()' in body
    assert 'paper_live.get_state(refresh_quotes=False)' in body
    assert 'open_positions_detected' in body


def test_launcher_uses_graceful_shutdown_not_os_exit():
    source = (ROOT / 'main.py').read_text(encoding='utf-8')
    assert 'def graceful_shutdown' in source
    assert 'window.events.closed += graceful_shutdown' in source
    assert 'atexit.register(graceful_shutdown)' in source
    assert 'os._exit(0)' not in source


def test_background_workers_receive_stop_signals():
    source = (ROOT / 'main.py').read_text(encoding='utf-8')
    for worker in ("('scout', 'stop_background')", "('longrun', 'stop')", "('historical', 'stop_backfill')"):
        assert worker in source
    scout = (ROOT / 'backend' / 'scout.py').read_text(encoding='utf-8')
    assert 'def stop_background(' in scout
