import copy
import pytest
from backend.btc_oof_audit import audit_oof_report, compare_oof_reports, replay_oof_audit
from backend.btc_training_registry import register_training_run
from test_v23o_btc_training_registry import _dataset
from backend.btc_baseline import evaluate_btc_4h_baselines


def _report():
    return {'predictions': [
        {'sample_index': 10, 'fold': 1, 'model': 'm', 'y_true': 1, 'y_pred': 1,
         'p_down': .1, 'p_neutral': .2, 'p_up': .7},
        {'sample_index': 11, 'fold': 2, 'model': 'm', 'y_true': 0, 'y_pred': 0,
         'p_down': .8, 'p_neutral': .1, 'p_up': .1}],
        'fold_reports': [{'fold': 1, 'model': 'm'}, {'fold': 2, 'model': 'm'}],
        'evaluation_hash': 'e'*64}


def test_oof_audit_passes_full_expected_coverage():
    result = audit_oof_report(_report(), model_name='m', expected_fold_ids=[1, 2], expected_sample_indices=[10, 11])
    assert result['status'] == 'PASS' and result['prediction_count'] == 2


def test_oof_duplicate_prediction_blocked():
    r = _report(); r['predictions'].append(copy.deepcopy(r['predictions'][0]))
    with pytest.raises(ValueError, match='duplicate_prediction'):
        audit_oof_report(r, model_name='m')


def test_oof_missing_fold_or_sample_blocked():
    with pytest.raises(ValueError, match='fold_coverage_mismatch'):
        audit_oof_report(_report(), model_name='m', expected_fold_ids=[1, 2, 3])
    with pytest.raises(ValueError, match='sample_coverage_mismatch'):
        audit_oof_report(_report(), model_name='m', expected_sample_indices=[10, 11, 12])


def test_oof_invalid_probability_blocked():
    r = _report(); r['predictions'][0]['p_up'] = 1.5
    with pytest.raises(ValueError, match='invalid_probabilities'):
        audit_oof_report(r, model_name='m')


def test_compare_reports_is_deterministic_and_explains_differences():
    a = _report(); b = copy.deepcopy(a)
    assert compare_oof_reports(a, b)['status'] == 'IDENTICAL'
    b['predictions'][0]['y_pred'] = 0
    diff = compare_oof_reports(a, b)
    assert diff['status'] == 'DIFFERENT' and diff['changed_keys']


def test_replay_audits_registered_oof_without_training(tmp_path):
    ds = _dataset(tmp_path)
    result = evaluate_btc_4h_baselines(ds, training_registry_dir=tmp_path/'reg')
    model, artifact = next(iter(result['training_runs'].items()))
    report = replay_oof_audit(artifact['run_id'], registry_dir=tmp_path/'reg')
    assert report['audit']['status'] == 'PASS'
    assert report['replay_mode'] == 'OFFLINE_AUDIT_ONLY_NO_RETRAINING'
    assert report['lineage_sha256'] == ds['manifest']['lineage_sha256']
