import pytest


def _fake_quote(paper_live):
    def fake_fetch(exchange, symbol, market):
        return {'symbol': symbol, 'market': market, 'exchange': exchange,
                'exchange_name': paper_live.EXCHANGE_NAMES[exchange], 'price': 101.0,
                'timestamp': '2026-11-19T00:00:00+00:00', 'authenticated': False}
    return fake_fetch


def test_closed_trade_pnl_reconciles_after_partial_exit(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'reconcile.sqlite3'))
    paper_live._CACHE.clear()
    monkeypatch.setattr(paper_live, '_fetch_one', _fake_quote(paper_live))
    opened = paper_live.open_position('BTCUSDT', 'LONG', 'spot', 'binance')
    paper_live.partial_close_position(opened['id'], opened['quantity'] * .25,
                                      idempotency_key='reconcile-partial-1')
    closed = paper_live.close_position(opened['id'])
    result = paper_live.reconcile_trade_pnl(opened['id'])
    assert result['valid'] is True
    assert result['trade_count'] == 1
    assert result['trades'][0]['partial_exit_count'] == 1
    assert result['trades'][0]['recorded_net_pnl'] == pytest.approx(closed['net_pnl'])


def test_reconciliation_is_read_only_and_detects_funding_mismatch(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'mismatch.sqlite3'))
    paper_live._CACHE.clear()
    monkeypatch.setattr(paper_live, '_fetch_one', _fake_quote(paper_live))
    opened = paper_live.open_position('BTCUSDT', 'LONG', 'spot', 'binance')
    paper_live.close_position(opened['id'])
    with paper_live._connect() as conn:
        conn.execute('UPDATE paper_live_trades SET funding_total=12 WHERE id=?', (opened['id'],))
    result = paper_live.reconcile_trade_pnl(opened['id'])
    assert result['valid'] is False
    assert any(x['check'] == 'funding_total_mismatch' for x in result['issues'])
    with paper_live._connect() as conn:
        assert conn.execute('SELECT funding_total FROM paper_live_trades WHERE id=?', (opened['id'],)).fetchone()[0] == 12
