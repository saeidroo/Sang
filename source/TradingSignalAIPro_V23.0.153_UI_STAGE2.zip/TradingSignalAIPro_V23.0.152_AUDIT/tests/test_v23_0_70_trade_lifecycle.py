from backend.trade_lifecycle import evaluate_trade_lifecycle

BASE = {'position_id':'p1','symbol':'BTCUSDT','side':'LONG','entry_price':100,
        'current_price':104,'stop_price':98,'initial_stop_price':98,'atr':1,
        'quantity':1,'status':'OPEN','paper_only':True,'quote_age_seconds':1}

def test_lifecycle_combines_management_and_exit_review():
    p = dict(BASE, current_price=90, structure_break_against_position=True)
    r = evaluate_trade_lifecycle([p])
    assert r['lifecycle'][0]['lifecycle_state'] == 'EXIT_REVIEW_REQUIRED'
    assert r['lifecycle'][0]['exit_assessment']['decision'] == 'EXIT_REVIEW_REQUIRED'
    assert r['read_only'] and not r['creates_orders'] and not r['real_orders_enabled']

def test_stale_quote_does_not_authorize_exit():
    p = dict(BASE, quote_age_seconds=999, current_price=90)
    r = evaluate_trade_lifecycle([p])
    assert r['lifecycle'][0]['lifecycle_state'] == 'HOLD_STALE_DATA'

def test_learning_audit_requires_closed_paper_reconciled_trade():
    rows = [
      {'trade_id':'1','status':'CLOSED','paper_only':True,'reconciled':True,'net_pnl':2.0},
      {'trade_id':'2','status':'OPEN','paper_only':True,'reconciled':True,'net_pnl':1.0},
      {'trade_id':'3','status':'CLOSED','paper_only':False,'reconciled':True,'net_pnl':1.0},
      {'trade_id':'4','status':'CLOSED','paper_only':True,'reconciled':False,'net_pnl':1.0},
      {'trade_id':'5','status':'CLOSED','paper_only':True,'reconciled':True,'funding_status':'PENDING','net_pnl':1.0},
    ]
    r = evaluate_trade_lifecycle([], rows)
    assert [x['eligible'] for x in r['closed_trade_learning_audit']] == [True,False,False,False,False]
    assert all(not x['writes_learning_data'] for x in r['closed_trade_learning_audit'])

def test_duplicate_closed_trade_ids_rejected():
    row={'trade_id':'x','status':'CLOSED','paper_only':True,'reconciled':True,'net_pnl':0}
    r=evaluate_trade_lifecycle([], [row,row])
    assert [x['eligible'] for x in r['closed_trade_learning_audit']] == [True,False]

def test_invalid_payloads_fail_closed():
    import pytest
    with pytest.raises(ValueError): evaluate_trade_lifecycle({}, [])
    with pytest.raises(ValueError): evaluate_trade_lifecycle([], {}, {})
