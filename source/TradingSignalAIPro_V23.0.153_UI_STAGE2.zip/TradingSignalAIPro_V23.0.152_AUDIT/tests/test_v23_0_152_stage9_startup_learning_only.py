"""Stage 9: app startup starts the brain but never silently starts AutoPilot."""
from backend import autopilot, scout, startup


def test_historical_brain_starts_without_live_scout_or_button(monkeypatch, capsys):
    calls = []
    monkeypatch.setenv('SCOUT_ENABLED', '0')
    monkeypatch.setattr('backend.market_brain.start_startup_learning',
                        lambda: calls.append('historical_learning') or True)

    # This is the same startup hook used by api.run_server(). No UI/API click is
    # involved, and disabling live polling does not disable archive learning.
    assert scout.start_background() is False
    assert calls == ['historical_learning']
    assert 'یادگیری آرشیو تاریخی' in capsys.readouterr().out


def test_autopilot_does_not_start_automatically_by_default(monkeypatch):
    calls = []
    monkeypatch.delenv('AUTOPILOT_ENABLED', raising=False)
    monkeypatch.setattr(autopilot, 'start', lambda **kwargs: calls.append(kwargs) or {'ok': True})

    result = startup.start_autopilot_on_server_start()

    assert result['started'] is False
    assert result['reason'] == 'startup_opt_in_required'
    assert result['entries_enabled'] is False
    assert calls == []


def test_autopilot_requires_explicit_opt_in(monkeypatch):
    calls = []
    monkeypatch.setenv('AUTOPILOT_ENABLED', '1')
    monkeypatch.setattr(autopilot, '_CONFIG', {'enabled': True, 'entries_enabled': True})
    monkeypatch.setattr(autopilot, 'start',
                        lambda **kwargs: calls.append(kwargs) or {'ok': True, 'entries_enabled': True})

    result = startup.start_autopilot_on_server_start()

    assert result['ok'] is True
    assert calls == [{'resume_entries': True}]


def test_persisted_autopilot_disabled_config_stays_disabled(monkeypatch):
    calls = []
    monkeypatch.setenv('AUTOPILOT_ENABLED', '1')
    monkeypatch.setattr(autopilot, '_CONFIG', {'enabled': False, 'entries_enabled': True})
    monkeypatch.setattr(autopilot, 'start', lambda **kwargs: calls.append(kwargs) or {'ok': True})

    result = startup.start_autopilot_on_server_start()

    assert result['started'] is False
    assert result['reason'] == 'disabled_in_config'
    assert calls == []
