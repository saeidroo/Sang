import json
from backend import experiment_registry as registry, evaluation
from backend.reproducible_run import create_run_manifest, link_run_provenance, save_run_manifest, sha256_bytes
from backend.audit_report import build_audit_report


def test_end_to_end_registry_manifest_paper_ledger_and_restart(tmp_path, monkeypatch):
    registry_dir=tmp_path/'registry'
    exp=registry.start_experiment('BTC-4H',symbol='BTCUSDT',timeframe='4h',
        data_hash=sha256_bytes(b'dataset-v1'),config={'lr':0.001},custom_dir=registry_dir)
    registry.finish_experiment(exp['experiment_id'],'ACCEPTED',metrics={'sharpe':1.1},custom_dir=registry_dir)
    db=tmp_path/'paper.sqlite3'
    monkeypatch.setenv('TRADING_AI_V22_PAPER_DB',str(db))
    evaluation.paper_v22_record('run-e2e','trade_opened',{'symbol':'BTCUSDT'},'open-1')
    evaluation.paper_v22_record('run-e2e','trade_closed',{'net_return':0.012},'close-1')
    events=registry.read_events(registry_dir)
    paper=evaluation.paper_v22_events(run_id='run-e2e')
    manifest=create_run_manifest(data_hash=sha256_bytes(b'dataset-v1'),config={'lr':0.001},
        cost_model={'version':'cost-v1','cost_hash':'a'*64},test_block_id='btc-4h-test',run_id='run-e2e')
    manifest=link_run_provenance(manifest,registry_events=events,paper_events=paper,experiment_id=exp['experiment_id'])
    mdir=tmp_path/'manifests'
    save_run_manifest(manifest,mdir)

    # Simulate process restart: reconstruct all state from persisted files/SQLite.
    registry_after=registry.read_events(registry_dir)
    paper_after=evaluation.paper_v22_events(run_id='run-e2e')
    report=build_audit_report(registry_events=registry_after,paper_events=paper_after,
        manifest_dir=mdir,registry_integrity=registry.audit_integrity(registry_dir),
        paper_integrity=evaluation.paper_v22_audit_integrity())
    assert report['status']=='ok'
    assert report['manifest_count']==1
    assert report['manifests'][0]['experiment_finished'] is True
    assert report['manifests'][0]['paper_event_count_current']==2
    assert report['errors']==[]


def test_audit_report_flags_run_and_event_link_mismatch(tmp_path):
    mdir=tmp_path/'manifests'; mdir.mkdir()
    m={'run_id':'r1','manifest_sha256':'invalid','experiment_registry':{'experiment_id':'missing'},
       'paper_ledger':{'run_id':'other','event_ids':['gone']}}
    (mdir/'r1.json').write_text(json.dumps(m),encoding='utf-8')
    report=build_audit_report(registry_events=[],paper_events=[],manifest_dir=mdir)
    assert report['status']=='attention_required'
    assert any('experiment_missing_from_registry' in x for x in report['errors'])
    assert any('manifest_ledger_run_id_mismatch' in x for x in report['errors'])
    assert any('paper_event_missing' in x for x in report['errors'])
