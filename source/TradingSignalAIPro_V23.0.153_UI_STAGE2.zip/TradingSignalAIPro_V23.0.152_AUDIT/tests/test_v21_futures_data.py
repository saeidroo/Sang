"""V21 part 1: perpetual-futures data layer (symbols like BTCUSDTPERP)."""
import time
import pytest
from backend import data


@pytest.fixture(autouse=True)
def _isolated_cache(tmp_path, monkeypatch):
    """Never write test candles into the user's real ~/.trading_ai_models cache."""
    monkeypatch.setattr(data, '_cache_dir', lambda: tmp_path)
    yield


def _rows(n=300, tf='1h', start_price=100.0):
    step = data.TIMEFRAME_SECONDS[tf] * 1000
    now = int(time.time() * 1000)
    t0 = now - (n + 5) * step
    t0 -= t0 % step
    out = []
    for i in range(n):
        p = start_price + i * 0.1
        out.append([t0 + i * step, p, p + 1, p - 1, p + 0.5, 10 + i])
    return out


def test_symbol_helpers():
    assert data.is_futures_symbol('BTCUSDTPERP')
    assert data.is_futures_symbol('btcusdtperp')
    assert not data.is_futures_symbol('PERPUSDT')      # real spot coin named PERP
    assert not data.is_futures_symbol('USDTPERP')      # no base asset
    assert data.futures_base_symbol('ETHUSDTPERP') == 'ETHUSDT'
    assert data.futures_base_symbol('ETHUSDT') == 'ETHUSDT'


def test_binance_fut_endpoint_and_strip(monkeypatch):
    seen = {}
    rows = _rows()

    def fake_get(url, timeout=15, params=None, headers=None):
        seen['url'], seen['params'] = url, params
        return rows
    monkeypatch.setattr(data, '_get', fake_get)
    df = data.fetch_binance_fut('BTCUSDTPERP', '1h', 250)
    assert 'fapi.binance.com' in seen['url']
    assert seen['params']['symbol'] == 'BTCUSDT'
    assert len(df) == 250


def test_binance_fut_error_dict(monkeypatch):
    monkeypatch.setattr(data, '_get', lambda *a, **k: {'code': -1121, 'msg': 'Invalid symbol.'})
    with pytest.raises(RuntimeError, match='Invalid symbol'):
        data.fetch_binance_fut('NOPEUSDTPERP', '1h', 250)


def test_bybit_uses_linear_category(monkeypatch):
    seen = {}
    rows = _rows()

    def fake_get(url, timeout=15, params=None, headers=None):
        seen['params'] = params
        return {'retCode': 0, 'result': {'list': [[str(r[0])] + [str(x) for x in r[1:]] for r in rows]}}
    monkeypatch.setattr(data, '_get', fake_get)
    df = data.fetch_bybit_fut('SOLUSDTPERP', '1h', 250)
    assert seen['params']['category'] == 'linear'
    assert seen['params']['symbol'] == 'SOLUSDT'
    assert len(df) >= 210


def test_okx_swap_inst_id(monkeypatch):
    seen = []
    rows = _rows(300)

    def fake_get(url, timeout=15, params=None, headers=None):
        seen.append(params['instId'])
        return {'code': '0', 'data': [[str(r[0])] + [str(x) for x in r[1:]] for r in reversed(rows)]}
    monkeypatch.setattr(data, '_get', fake_get)
    df = data.fetch_okx_fut('BTCUSDTPERP', '1h', 250)
    assert seen[0] == 'BTC-USDT-SWAP'
    assert len(df) >= 210


def test_gate_fut_parsing(monkeypatch):
    rows = _rows()
    payload = [{'t': r[0] // 1000, 'o': r[1], 'h': r[2], 'l': r[3], 'c': r[4], 'v': r[5]} for r in rows]
    seen = {}

    def fake_get(url, timeout=15, params=None, headers=None):
        seen['params'] = params
        return payload
    monkeypatch.setattr(data, '_get', fake_get)
    df = data.fetch_gateio_fut('ETHUSDTPERP', '1h', 250)
    assert seen['params']['contract'] == 'ETH_USDT'
    assert len(df) == 250


def test_bitget_fut_params(monkeypatch):
    rows = _rows()
    seen = {}

    def fake_get(url, timeout=15, params=None, headers=None):
        seen['params'] = params
        return {'code': '00000', 'data': [[str(r[0])] + [str(x) for x in r[1:]] + ['0'] for r in rows]}
    monkeypatch.setattr(data, '_get', fake_get)
    df = data.fetch_bitget_fut('XRPUSDTPERP', '1h', 250)
    assert seen['params']['productType'] == 'USDT-FUTURES'
    assert seen['params']['symbol'] == 'XRPUSDT'
    assert len(df) >= 210


def test_fetch_candles_auto_uses_futures_chain(monkeypatch, _isolated_cache):
    data.reset_source_health()
    calls = []
    rows = _rows(300)
    good = data._clean_candles([{'t': r[0], 'open': r[1], 'high': r[2], 'low': r[3],
                                 'close': r[4], 'volume': r[5]} for r in rows])

    def boom(*a, **k):
        calls.append('binance_fut')
        raise RuntimeError('timed out')

    def ok(*a, **k):
        calls.append('bybit_fut')
        return good
    monkeypatch.setitem(data.SOURCE_FUNCS, 'binance_fut', boom)
    monkeypatch.setitem(data.SOURCE_FUNCS, 'bybit_fut', ok)
    monkeypatch.setattr(data, '_SOURCE_SUCCESS_TS', {})
    df = data.fetch_candles('BTCUSDTPERP', '1h', 250, 'auto')
    assert calls == ['binance_fut', 'bybit_fut']
    assert df.attrs['source'] == 'bybit_fut'
    assert df.attrs['fallback_chain'][0]['source'] == 'binance_fut'
    data.reset_source_health()


def test_spot_source_maps_to_futures_twin(monkeypatch, _isolated_cache):
    rows = _rows(300)
    good = data._clean_candles([{'t': r[0], 'open': r[1], 'high': r[2], 'low': r[3],
                                 'close': r[4], 'volume': r[5]} for r in rows])
    monkeypatch.setitem(data.SOURCE_FUNCS, 'okx_fut', lambda *a, **k: good)
    df = data.fetch_candles('ETHUSDTPERP', '1h', 250, 'okx')
    assert df.attrs['source'] == 'okx_fut'


def test_unsupported_source_for_futures():
    with pytest.raises(ValueError):
        data.fetch_candles('BTCUSDTPERP', '1h', 250, 'kraken')


def test_spot_chain_never_contains_futures():
    assert not set(data.FUTURES_AUTO_ORDER) & set(data.CRYPTO_AUTO_ORDER)
