"""Controlled recovery/chaos drills for the V22.2 Witness pipeline."""
import sqlite3
from pathlib import Path
import pytest

from backend.witness_server import bootstrap_keys, init_db, record_anchor, backup_database
from backend.witness_remote import build_replication_batch
from backend.witness_replication import accept_remote_entries, compare_witnesses
from backend.witness_ops import restore_database, health_diagnostics, _records
from backend.witness_scheduler import run_sync_once, scheduler_status
import backend.witness_scheduler as scheduler
import backend.witness_alerting as alerting


def _witness(root, name):
    folder = Path(root) / name
    folder.mkdir()
    private, public, db = folder/'private.pem', folder/'public.pem', folder/'witness.sqlite'
    bootstrap_keys(private, public)
    init_db(db)
    return db, private, public


def test_network_interruption_mid_stream_resumes_without_loss_or_duplicates(tmp_path):
    sdb, spriv, spub = _witness(tmp_path, 'source')
    ddb, dpriv, dpub = _witness(tmp_path, 'replica')
    for n in range(11):
        record_anchor(sdb, spriv, {'event': n}, witness_id='source')
    # First chunk committed; simulated process/network death occurs before ACK/next chunk.
    chunk1 = build_replication_batch(sdb, spub, after_sequence=0, limit=4)
    assert accept_remote_entries(ddb, dpriv, spub, chunk1, after_sequence=0)['sequence'] == 4
    with pytest.raises(TimeoutError):
        raise TimeoutError('simulated_link_drop_after_chunk_1')
    # A fresh process discovers the durable cursor and resumes.
    cursor = len(_records(ddb))
    chunk2 = build_replication_batch(sdb, spub, after_sequence=cursor, limit=4)
    assert accept_remote_entries(ddb, dpriv, spub, chunk2, after_sequence=cursor)['sequence'] == 8
    chunk3 = build_replication_batch(sdb, spub, after_sequence=8, limit=4)
    assert accept_remote_entries(ddb, dpriv, spub, chunk3, after_sequence=8)['sequence'] == 11
    assert len(_records(ddb)) == 11
    assert compare_witnesses(sdb, spub, ddb, dpub)['consistent']


def test_lost_ack_retry_is_idempotent_and_gap_is_rejected(tmp_path):
    sdb, spriv, spub = _witness(tmp_path, 's')
    ddb, dpriv, _ = _witness(tmp_path, 'd')
    for n in range(3): record_anchor(sdb, spriv, {'n': n})
    batch = build_replication_batch(sdb, spub, after_sequence=0, limit=2)
    assert accept_remote_entries(ddb, dpriv, spub, batch, after_sequence=0)['appended'] == 2
    assert accept_remote_entries(ddb, dpriv, spub, batch, after_sequence=0)['appended'] == 0
    final = build_replication_batch(sdb, spub, after_sequence=2, limit=2)
    with pytest.raises(ValueError, match='source_sequence_gap'):
        accept_remote_entries(ddb, dpriv, spub, final, after_sequence=1)


def test_backup_restore_after_restart_preserves_signed_anchors(tmp_path):
    db, private, public = _witness(tmp_path, 'primary')
    for n in range(5): record_anchor(db, private, {'trade': n})
    backup = tmp_path/'backup.sqlite'
    backup_database(db, backup)
    restored = tmp_path/'recovered'/'witness.sqlite'
    report = restore_database(backup, restored, public)
    assert report['restored'] and report['records'] == 5
    assert health_diagnostics(restored, public)['healthy']
    assert [r['anchor_digest'] for r in _records(restored)] == [r['anchor_digest'] for r in _records(db)]


def test_webhook_timeout_is_reported_without_raising(monkeypatch):
    def timeout(*args, **kwargs): raise TimeoutError('simulated webhook timeout')
    monkeypatch.setattr(alerting, 'urlopen', timeout)
    result = alerting.notify_if_needed({'status':'failed','alerts':['replication_failed'], 'error':'network'},
                                       'https://monitor.example/hook')
    assert result['status'] == 'failed' and 'TimeoutError' in result['error']


def test_scheduler_failure_then_restart_recovery_is_durable(tmp_path, monkeypatch):
    db, private, public = _witness(tmp_path, 'source')
    state = tmp_path/'scheduler.sqlite'
    for n in range(2): record_anchor(db, private, {'n': n})
    def fail(*args, **kwargs): raise TimeoutError('network down')
    monkeypatch.setattr(scheduler, 'sync_replication_http', fail)
    monkeypatch.setattr(scheduler, '_request', lambda *a, **k: {'sequence':0})
    failed = run_sync_once(db, public, 'https://replica.example', 'token', state)
    assert failed['status'] == 'failed'
    # Simulate process restart: durable history remains and next successful run clears health.
    monkeypatch.setattr(scheduler, 'sync_replication_http', lambda *a, **k: {'chunks':1,'appended':2})
    monkeypatch.setattr(scheduler, '_request', lambda *a, **k: {'sequence':2,'head_digest':'head'})
    recovered = run_sync_once(db, public, 'https://replica.example', 'token', state)
    assert recovered['status'] == 'success'
    health = scheduler_status(state, max_lag=0, stale_after_seconds=3600)
    assert health['healthy'] and health['last_run']['run_status'] == 'success'
    with sqlite3.connect(state) as conn:
        assert conn.execute('SELECT COUNT(*) FROM replication_runs').fetchone()[0] == 2


def test_retention_never_deletes_anchor_records(tmp_path):
    from backend.witness_alerting import prune_scheduler_history
    db, private, public = _witness(tmp_path, 'witness')
    for n in range(4): record_anchor(db, private, {'anchor': n})
    state = tmp_path/'scheduler.sqlite'
    from backend.witness_scheduler import init_scheduler_db
    init_scheduler_db(state)
    with sqlite3.connect(state) as conn:
        conn.execute("INSERT INTO replication_runs(started_at,finished_at,status,source_sequence,replica_sequence,lag,chunks,appended,duration_seconds) VALUES('2020','2020','success',4,4,0,1,4,0.1)")
    prune_scheduler_history(state, retention_days=1, max_rows=1)
    assert len(_records(db)) == 4
    assert health_diagnostics(db, public)['healthy']
