"""Stage 10: accelerated scanning must preserve historical labels exactly."""
import math
import random

from backend import market_brain as brain


def _history(symbol='FASTUSDT', count=1400, seed=31):
    rng = random.Random(seed)
    rows = []
    price = 100.0
    start = 1_700_000_000_000
    for i in range(count):
        # Alternate volatility clusters and inject both sharp rallies and drops.
        if i in (180, 650, 1080):
            price *= 1.14
        elif i in (260, 740, 1160):
            price *= 0.84
        op = price
        price = max(1.0, price * (1.0 + rng.uniform(-0.018, 0.018)))
        high = max(op, price) * (1.0 + rng.random() * 0.006)
        low = min(op, price) * (1.0 - rng.random() * 0.006)
        rows.append((symbol, start + i * 3_600_000, op, high, low, price,
                     rng.uniform(10.0, 5000.0)))
    return rows


def test_numpy_extreme_event_scan_matches_python_reference():
    if brain._np is None:
        return
    rows = _history()
    expected = list(brain._iter_extreme_events_python(rows))
    actual = list(brain._iter_extreme_events_numpy(rows))
    assert actual == expected
    assert any(pump for _, pump, _ in actual)
    assert any(dump for _, _, dump in actual)


def test_numpy_symbol_learning_matches_python_reference(monkeypatch):
    histories = [_history(f'COIN{i}USDT', seed=31 + i) for i in range(4)]
    segments = [[rows] for rows in histories]
    fast = [brain._scan_symbol_segments(item) for item in segments]
    monkeypatch.setattr(brain, '_np', None)
    reference = [brain._scan_symbol_segments(item) for item in segments]
    assert fast == reference


def test_ordered_segment_preparation_matches_general_path():
    rows = _history(count=100)
    rows.extend([rows[20], rows[40]])
    expected_segments, expected_audit = brain._prepare_hourly_segments(rows)
    actual_segments, actual_audit = brain._prepare_hourly_segments(rows, presorted=False)
    assert actual_segments == expected_segments
    assert actual_audit == expected_audit

    # The fast SQL path is used only for already sorted rows.
    ordered = sorted(rows, key=lambda row: row[1])
    fast_segments, fast_audit = brain._prepare_hourly_segments(ordered, presorted=True)
    normal_segments, normal_audit = brain._prepare_hourly_segments(ordered)
    assert fast_segments == normal_segments
    assert fast_audit == normal_audit


def test_worker_count_is_bounded_and_configurable(monkeypatch):
    monkeypatch.setenv('TRADING_AI_BRAIN_WORKERS', '3')
    assert brain._learning_worker_count(20) <= 3
    assert brain._learning_worker_count(2) <= 2
    monkeypatch.setenv('TRADING_AI_BRAIN_WORKERS', 'invalid')
    assert brain._learning_worker_count(0) == 1


def test_accelerated_scan_status_exposes_progress_and_runtime(tmp_path, monkeypatch):
    import sqlite3

    db = tmp_path / 'history.sqlite3'
    con = sqlite3.connect(db)
    con.execute('''CREATE TABLE candles(
        symbol TEXT, timeframe TEXT, t INTEGER, open REAL, high REAL,
        low REAL, close REAL, volume REAL)''')
    rows = []
    start = 1_700_000_000_000
    for symbol in ('AAAUSDT', 'BBBUSDT'):
        for i in range(70):
            price = 100.0 * (1.001 ** i)
            rows.append((symbol, '1h', start + i * 3_600_000,
                         price, price * 1.002, price * .998, price, 1000.0))
    con.executemany('INSERT INTO candles VALUES(?,?,?,?,?,?,?,?)', rows)
    con.commit()
    con.close()
    monkeypatch.setattr(brain, 'HISTORY_DB_PATH', db)
    monkeypatch.setattr(brain, 'FEEDBACK_DB_PATH', tmp_path / 'feedback.sqlite3')
    monkeypatch.setenv('TRADING_AI_BRAIN_WORKERS', '2')

    result = brain.learn_historical_extremes(now=1_800_000_000)

    assert result['status'] == 'completed'
    assert result['stage'] == 'complete'
    assert result['progress_pct'] == 100
    assert result['symbols_done'] == result['symbols_total'] == 2
    assert result['workers'] == 2
    assert result['accelerator'] in ('numpy', 'python')


def test_predict_reuses_analog_index_and_invalidates_after_archive_change(tmp_path, monkeypatch):
    import copy
    import sqlite3

    db = tmp_path / 'history.sqlite3'
    con = sqlite3.connect(db)
    con.execute('''CREATE TABLE candles(
        symbol TEXT, timeframe TEXT, t INTEGER, open REAL, high REAL,
        low REAL, close REAL, volume REAL)''')
    start = 1_700_000_000_000
    rows = []
    for symbol, drift in (('BTCUSDT', 0.0004), ('ALTUSDT', 0.0007), ('XYZUSDT', -0.0002)):
        price = 100.0
        for i in range(161):
            op = price
            price *= 1.0 + drift + (0.0004 if (i // 24) % 2 == 0 else -0.0003)
            rows.append((symbol, '1h', start + i * 3_600_000,
                         op, max(op, price) * 1.001, min(op, price) * 0.999,
                         price, 1000.0 + i))
    con.executemany('INSERT INTO candles VALUES(?,?,?,?,?,?,?,?)', rows)
    con.commit()
    con.close()
    monkeypatch.setattr(brain, 'HISTORY_DB_PATH', db)
    monkeypatch.setattr(brain, 'FEEDBACK_DB_PATH', tmp_path / 'feedback.sqlite3')
    now = (start + 161 * 3_600_000) / 1000 - 10

    first_items = [{'symbol': 'ALTUSDT', 'price': 120.0}]
    first = brain.predict(first_items, now=now)
    second_items = [{'symbol': 'ALTUSDT', 'price': 120.0}]
    second = brain.predict(second_items, now=now)

    assert first['cache_hit'] is False
    assert second['cache_hit'] is True
    assert first_items[0]['brain_prediction'] == second_items[0]['brain_prediction']
    assert first['archive_quality'] == second['archive_quality']

    # The next hourly bar becomes closed 20 seconds later, so the cache must
    # refresh even when the SQLite file itself did not change.
    newly_closed = brain.predict([{'symbol': 'ALTUSDT', 'price': 100.1}], now=now + 20)
    assert newly_closed['cache_hit'] is False

    con = sqlite3.connect(db)
    last = start + 161 * 3_600_000
    con.execute('INSERT INTO candles VALUES(?,?,?,?,?,?,?,?)',
                ('ALTUSDT', '1h', last, 100.0, 100.2, 99.8, 100.1, 900.0))
    con.commit()
    con.close()
    changed_archive = brain.predict([{'symbol': 'ALTUSDT', 'price': 100.1}], now=now + 3600)
    assert changed_archive['cache_hit'] is False


def test_vectorized_pattern_signatures_match_reference_for_every_candle(monkeypatch):
    rows = _history(count=900, seed=991)
    fast = list(brain._iter_bucket_signatures_numpy(rows))
    monkeypatch.setattr(brain, '_np', None)
    reference = list(brain._iter_bucket_signatures_numpy(rows))
    assert fast == reference
