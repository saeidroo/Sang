from backend.dynamic_position_manager import evaluate_open_paper_positions

BASE={'position_id':'p1','symbol':'BTCUSDT','side':'LONG','entry_price':100,
      'current_price':103,'initial_stop_price':98,'stop_price':98,'atr':1,'quantity':2}

def test_breakeven_and_atr_trailing_only_tighten_stop():
    r=evaluate_open_paper_positions([BASE])['positions'][0]
    assert r['recommended_stop_price'] >= 100
    assert 'MOVE_STOP_TO_COST_ADJUSTED_BREAKEVEN' in r['actions']
    assert r['read_only'] if 'read_only' in r else True

def test_partial_take_profit_is_recommended_once_with_idempotency_key():
    r=evaluate_open_paper_positions([BASE])['positions'][0]
    assert 'PARTIAL_TAKE_PROFIT_RECOMMENDED' in r['actions']
    assert r['partial_event_key']=='p1:PARTIAL:1R'
    done=dict(BASE,partial_take_profit_done=True)
    assert 'PARTIAL_TAKE_PROFIT_RECOMMENDED' not in evaluate_open_paper_positions([done])['positions'][0]['actions']

def test_short_position_stop_never_loosened():
    p=dict(BASE,position_id='p2',side='SHORT',entry_price=100,current_price=97,
           initial_stop_price=102,stop_price=102)
    r=evaluate_open_paper_positions([p])['positions'][0]
    assert r['recommended_stop_price'] <= 100

def test_invalid_and_duplicate_positions_are_reported_and_paper_only():
    r=evaluate_open_paper_positions([BASE,BASE,{'symbol':'ETHUSDT'}])
    assert len(r['invalid_positions'])==2
    assert r['paper_only'] and r['read_only'] and not r['real_orders_enabled'] and not r['execution_authorized']

def test_bad_direction_of_initial_stop_is_rejected():
    p=dict(BASE,initial_stop_price=101)
    r=evaluate_open_paper_positions([p])
    assert 'جهت حد ضرر' in r['invalid_positions'][0]['reason']
