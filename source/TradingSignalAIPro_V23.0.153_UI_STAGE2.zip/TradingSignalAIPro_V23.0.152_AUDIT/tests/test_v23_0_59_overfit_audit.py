import json
import pytest
from backend.strategy_validation import audit_strategy_overfitting


def row(pnl, i, strategy='alpha'):
    return {'symbol':'BTCUSDT','market':'perp','timeframe':'1h','side':'LONG','net_pnl':pnl,
            'closed_at':f'2026-01-{i:02d}T00:00:00Z','trade_id':str(i),
            'context_json':json.dumps({'strategy':strategy,'market_regime':'BULLISH','volatility_regime':'LOW'})}


def test_chronological_holdout_flags_development_edge_that_fails_later():
    result=audit_strategy_overfitting([row(2,i) for i in range(1,15)]+[row(-1,i) for i in range(15,21)],min_total=20,min_holdout=5)
    cohort=result['cohorts'][0]
    assert cohort['state']=='POSSIBLE_OVERFIT'
    assert cohort['development']['expectancy_usdt']>0
    assert cohort['holdout']['expectancy_usdt']<0
    assert cohort['chronological_split'] is True
    assert result['authorizes_entries'] is False


def test_insufficient_sample_never_claims_validation():
    r=audit_strategy_overfitting([row(1,i) for i in range(1,8)],min_total=20,min_holdout=5)
    assert r['cohorts'][0]['state']=='INSUFFICIENT_EVIDENCE'


def test_invalid_fraction_rejected():
    with pytest.raises(ValueError): audit_strategy_overfitting([],train_fraction=.4)
