from backend import paper_live


def _bar(ts):
    return {"t": ts, "open": 100.0, "high": 101.0, "low": 99.0, "close": 100.5}


def test_pagination_advances_cursor_and_collects_all_pages(monkeypatch):
    calls = []
    pages = [[_bar(0), _bar(300_000)], [_bar(600_000), _bar(900_000)], [_bar(1_200_000)]]

    def fake_fetch(row, *, limit=1000):
        calls.append(row.get("replay_last_candle_open_ms"))
        return pages[len(calls) - 1]

    monkeypatch.setattr(paper_live, "fetch_pinned_closed_candles", fake_fetch)
    result = paper_live.fetch_pinned_closed_candles_complete(
        {"exchange": "binance", "replay_last_candle_open_ms": None}, page_limit=2, max_pages=5)
    assert [x["t"] for x in result] == [0, 300_000, 600_000, 900_000, 1_200_000]
    assert calls == [None, 300_000, 900_000]


def test_pagination_stops_at_page_cap(monkeypatch):
    calls = []

    def fake_fetch(row, *, limit=1000):
        calls.append(row.get("replay_last_candle_open_ms"))
        start = 0 if len(calls) == 1 else int(calls[-1]) + 300_000
        return [_bar(start + i * 300_000) for i in range(limit)]

    monkeypatch.setattr(paper_live, "fetch_pinned_closed_candles", fake_fetch)
    result = paper_live.fetch_pinned_closed_candles_complete(
        {"exchange": "binance", "replay_last_candle_open_ms": None}, page_limit=2, max_pages=2)
    assert len(result) == 4
    assert len(calls) == 2


def test_pagination_rejects_non_advancing_page(monkeypatch):
    def fake_fetch(row, *, limit=1000):
        return [_bar(0), _bar(300_000)]

    monkeypatch.setattr(paper_live, "fetch_pinned_closed_candles", fake_fetch)
    try:
        paper_live.fetch_pinned_closed_candles_complete(
            {"exchange": "binance", "replay_last_candle_open_ms": None}, page_limit=2, max_pages=2)
    except RuntimeError as exc:
        assert "advance" in str(exc)
    else:
        raise AssertionError("non-advancing pagination must fail closed")
