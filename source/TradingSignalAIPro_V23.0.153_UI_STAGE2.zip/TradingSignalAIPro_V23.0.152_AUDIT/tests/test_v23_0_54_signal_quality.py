from backend.signal_quality import analyze_signal_quality


def test_strong_confluence_scores_higher_than_empty():
    low = analyze_signal_quality({"score": 0, "evidence": []})
    high = analyze_signal_quality({"score": 8, "evidence": [{"points": 2} for _ in range(4)]})
    assert high["quality_index"] > low["quality_index"]
    assert high["quality_label"] in ("MEDIUM", "HIGH")


def test_opposing_sources_reduce_quality():
    aligned = analyze_signal_quality({"score": 4, "evidence": [{"points": 2}, {"points": 2}]})
    conflict = analyze_signal_quality({"score": 0, "evidence": [{"points": 2}, {"points": -2}]})
    assert conflict["quality_index"] < aligned["quality_index"]


def test_small_history_is_shrunk_and_not_profit_probability():
    a = analyze_signal_quality({"score": 2, "evidence": [{"points": 2}]}, {"closed_trades": 2, "win_rate": 1.0})
    b = analyze_signal_quality({"score": 2, "evidence": [{"points": 2}]}, {"closed_trades": 100, "win_rate": 1.0})
    assert b["quality_index"] > a["quality_index"]
    assert a["confidence_is_probability"] is False


def test_invalid_history_does_not_crash():
    r = analyze_signal_quality({}, {"closed_trades": 10, "win_rate": 5})
    assert r["history_sample_size"] == 10
    assert r["historical_win_rate_used"] is None
