import math
import pytest
from backend.execution_model import execution_costs
from backend.partial_exit import validate_partial_quantity, calculate_partial_exit


def test_partial_quantity_must_leave_positive_remainder():
    assert validate_partial_quantity(original_quantity=10, already_exited=2, requested_quantity=3) == 5
    with pytest.raises(ValueError):
        validate_partial_quantity(original_quantity=10, already_exited=2, requested_quantity=8)
    with pytest.raises(ValueError):
        validate_partial_quantity(original_quantity=10, already_exited=10, requested_quantity=1)


@pytest.mark.parametrize('side', ['LONG', 'SHORT'])
def test_partial_exit_cost_and_pnl_for_both_directions(side):
    costs = execution_costs(500)
    result = calculate_partial_exit(side=side, quantity=2, entry_fill=100,
        entry_fee_allocated=0.2, exit_reference=110 if side == 'LONG' else 90,
        execution_costs=costs)
    assert result['exit_fee'] > 0
    assert result['gross_pnl'] > 0
    assert result['net_pnl'] < result['gross_pnl']


def test_partial_exit_rejects_nonfinite_or_invalid_inputs():
    with pytest.raises(ValueError):
        validate_partial_quantity(original_quantity=10, already_exited=0, requested_quantity=float('nan'))
    with pytest.raises(ValueError):
        calculate_partial_exit(side='BUY', quantity=1, entry_fill=10,
            entry_fee_allocated=0, exit_reference=11, execution_costs=execution_costs(100))


def test_spot_partial_exit_is_idempotent_and_final_close_aggregates(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'partial.sqlite3'))
    paper_live._CACHE.clear()
    def fake_fetch(exchange, symbol, market):
        return {'symbol': symbol, 'market': market, 'exchange': exchange,
                'exchange_name': paper_live.EXCHANGE_NAMES[exchange], 'price': 100.0,
                'timestamp': '2026-11-19T00:00:00+00:00', 'authenticated': False}
    monkeypatch.setattr(paper_live, '_fetch_one', fake_fetch)
    opened = paper_live.open_position('BTCUSDT', 'LONG', 'spot', 'auto')
    quote = {'symbol':'BTCUSDT','market':'spot','exchange':opened['exchange'],'price':105.0,
             'timestamp':'2026-11-19T00:00:00+00:00','checked_at_epoch':__import__('time').time()}
    monkeypatch.setattr(paper_live, 'get_quote', lambda *a, **k: dict(quote))
    first = paper_live.partial_close_position(opened['id'], opened['quantity'] * 0.25, idempotency_key='p1')
    replay = paper_live.partial_close_position(opened['id'], opened['quantity'] * 0.25, idempotency_key='p1')
    assert first['status'] == 'PARTIAL' and replay['idempotent_replay'] is True
    assert first['remaining_quantity'] == pytest.approx(opened['quantity'] * 0.75)
    state = paper_live.get_state(refresh_quotes=False)
    live_row = state['open_positions'][0]
    assert live_row['quantity'] == pytest.approx(opened['quantity'] * 0.75)
    assert live_row['original_quantity'] == pytest.approx(opened['quantity'])
    assert live_row['partial_exited_quantity'] == pytest.approx(opened['quantity'] * 0.25)
    assert live_row['partial_exit_count'] == 1
    assert math.isfinite(live_row['partial_realized_net_pnl'])
    closed = paper_live.close_position(opened['id'])
    assert closed['status'] == 'CLOSED'
    assert closed['partial_exit_count'] == 1
    assert closed['partial_quantity'] == pytest.approx(opened['quantity'] * 0.25)
    assert math.isfinite(closed['net_pnl'])
    with paper_live._connect() as conn:
        events = conn.execute('SELECT COUNT(*) FROM paper_partial_exits WHERE trade_id=?', (opened['id'],)).fetchone()[0]
    assert events == 1


def test_partial_exit_allows_perpetual_market_after_funding_allocation(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'perp.sqlite3'))
    paper_live._CACHE.clear()
    def fake_fetch(exchange, symbol, market):
        return {'symbol': symbol, 'market': market, 'exchange': exchange,
                'exchange_name': paper_live.EXCHANGE_NAMES[exchange], 'price': 100.0,
                'timestamp': '2026-11-19T00:00:00+00:00', 'authenticated': False}
    monkeypatch.setattr(paper_live, '_fetch_one', fake_fetch)
    opened = paper_live.open_position('BTCUSDT', 'LONG', 'perp', 'auto')
    result = paper_live.partial_close_position(opened['id'], opened['quantity'] * .25, idempotency_key='p1')
    assert result['status'] == 'PARTIAL'
    assert result['remaining_quantity'] == pytest.approx(opened['quantity'] * .75)
