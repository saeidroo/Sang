import hashlib, json
import numpy as np
import pandas as pd
import pytest
from backend.btc_dataset import build_btc_4h_dataset
from backend.btc_source_reconciliation import reconcile_candles
from backend.btc_training_lineage import build_lineage_manifest, require_training_lineage, create_training_run_artifact


def _canonical(x): return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)
def _sha(x): return hashlib.sha256(_canonical(x).encode()).hexdigest()
def _candles(n=260):
    rows=[]; price=30000.0
    for i in range(n):
        price *= 1 + 0.0005 + 0.003*np.sin(i/8)
        rows.append({'t': i*14400000, 'open':price*.999, 'high':price*1.003,
                     'low':price*.997, 'close':price, 'volume':100+i})
    return rows

def _fixtures(tmp_path):
    rows=_candles(); snap={'version':'btc-4h-store-v1','symbol':'BTCUSDT','timeframe':'4h',
        'data_sha256':_sha(rows),'candles':rows,'source_batches':['a'*64]}
    sp=tmp_path/'snapshot.json'; sp.write_text(json.dumps(snap, sort_keys=True), encoding='utf-8')
    r=reconcile_candles(rows, rows)
    r.update({'status':'PASS','training_allowed':True,'previous_snapshot':'prior.json'})
    r['report_sha256']=_sha(r)
    rp=tmp_path/'reconciliation.json'; rp.write_text(json.dumps(r, sort_keys=True), encoding='utf-8')
    ds=build_btc_4h_dataset(rows, n_splits=3)
    lineage=build_lineage_manifest(sp, rp, ds['manifest'])
    return rows, sp, rp, ds, lineage

def test_valid_lineage_and_run_artifact(tmp_path):
    rows,sp,rp,ds,lineage=_fixtures(tmp_path)
    assert require_training_lineage(lineage, expected_snapshot_hash=_sha(rows))
    ds2=build_btc_4h_dataset(rows, n_splits=3, lineage_manifest=lineage)
    artifact=create_training_run_artifact(ds2,lineage,model_name='baseline',run_id='run-001',output_path=tmp_path/'run.json')
    assert artifact['dataset_hash']==ds['manifest']['dataset_hash']
    assert artifact['lineage_sha256']==lineage['lineage_sha256']
    assert json.loads((tmp_path/'run.json').read_text())['snapshot_data_sha256']==_sha(rows)

def test_tampered_snapshot_blocks(tmp_path):
    rows,sp,rp,ds,lineage=_fixtures(tmp_path)
    snap=json.loads(sp.read_text()); snap['candles'][4]['close'] += 1; sp.write_text(json.dumps(snap))
    with pytest.raises(ValueError, match='snapshot_hash_mismatch'):
        build_lineage_manifest(sp,rp,ds['manifest'])

def test_blocked_reconciliation_blocks(tmp_path):
    rows,sp,rp,ds,lineage=_fixtures(tmp_path)
    r=json.loads(rp.read_text()); r['status']='BLOCKED'; r['training_allowed']=False
    body=dict(r); body.pop('report_sha256'); r['report_sha256']=_sha(body); rp.write_text(json.dumps(r))
    with pytest.raises(ValueError, match='drift_blocks'):
        build_lineage_manifest(sp,rp,ds['manifest'])

def test_snapshot_hash_mismatch_blocks(tmp_path):
    rows,sp,rp,ds,lineage=_fixtures(tmp_path)
    with pytest.raises(ValueError, match='snapshot_hash_mismatch'):
        require_training_lineage(lineage, expected_snapshot_hash='0'*64)

def test_manifest_reproducible(tmp_path):
    rows,sp,rp,ds,lineage=_fixtures(tmp_path)
    other=build_lineage_manifest(sp,rp,ds['manifest'])
    assert other['lineage_sha256']==lineage['lineage_sha256']

def test_tampered_lineage_and_dataset_binding_block(tmp_path):
    rows,sp,rp,ds,lineage=_fixtures(tmp_path)
    bad=dict(lineage); bad['snapshot']=dict(bad['snapshot']); bad['snapshot']['data_sha256']='f'*64
    with pytest.raises(ValueError, match='lineage_hash_mismatch'): require_training_lineage(bad)
    tampered={**lineage,'dataset':{**lineage['dataset'],'dataset_hash':'0'*64}}
    tampered.pop('lineage_sha256'); tampered['lineage_sha256']=_sha(tampered)
    with pytest.raises(ValueError, match='dataset_lineage_hash_mismatch'):
        build_btc_4h_dataset(rows,n_splits=3,lineage_manifest=tampered)

def test_labels_and_metadata_never_enter_features(tmp_path):
    rows,sp,rp,ds,lineage=_fixtures(tmp_path)
    forbidden=('label','forward','future','target','outcome','profit','return_after')
    assert all(not any(t in c.lower() for t in forbidden) for c in ds['X'].columns)
    assert not set(ds['metadata'].columns).intersection(ds['X'].columns)
