import json
import pytest
from backend.btc_ingestion_store import append_ingestion, replay_snapshot, verify_audit
from backend.btc_walkforward import FOUR_HOURS_MS

def _batch(start, end):
    rows=[]
    for i in range(start,end+1):
        o=100+i; c=o+0.2; t=i*FOUR_HOURS_MS
        rows.append({"t":t,"open":float(o),"high":float(c+1),"low":float(o-1),"close":float(c),"volume":12.0})
    import hashlib
    raw=json.dumps(rows,sort_keys=True,separators=(",",":"),allow_nan=False)
    return {"status":"PASS","symbol":"BTCUSDT","candles":rows,"data_sha256":hashlib.sha256(raw.encode()).hexdigest()}

def test_snapshot_append_replay_and_idempotent_overlap(tmp_path):
    first=append_ingestion(tmp_path,_batch(10,15))
    assert first["added_rows"] == 6
    second=append_ingestion(tmp_path,_batch(14,19))
    assert second["added_rows"] == 4 and second["row_count"] == 10
    replay=replay_snapshot(tmp_path)
    assert replay["network_used"] is False and replay["row_count"] == 10
    assert replay["candles"][0]["t"] == 10*FOUR_HOURS_MS
    assert verify_audit(tmp_path)["valid"] is True

def test_conflicting_overlap_is_rejected(tmp_path):
    append_ingestion(tmp_path,_batch(10,15))
    bad=_batch(14,19); bad["candles"][0]["close"] += 3
    import hashlib
    raw=json.dumps(bad["candles"],sort_keys=True,separators=(",",":"),allow_nan=False)
    bad["data_sha256"]=hashlib.sha256(raw.encode()).hexdigest()
    with pytest.raises(ValueError,match="conflicting_overlap"):
        append_ingestion(tmp_path,bad)

def test_snapshot_tampering_is_detected(tmp_path):
    result=append_ingestion(tmp_path,_batch(10,15))
    path=tmp_path/"snapshots"/result["snapshot"]
    payload=json.loads(path.read_text()); payload["candles"][0]["close"] += 1
    path.write_text(json.dumps(payload))
    with pytest.raises(ValueError,match="snapshot_hash_mismatch"):
        replay_snapshot(tmp_path)

def test_audit_tampering_is_detected(tmp_path):
    append_ingestion(tmp_path,_batch(10,15))
    p=tmp_path/"audit.jsonl"; p.write_text(p.read_text().replace('"added_rows": 6','"added_rows": 7'))
    assert verify_audit(tmp_path)["valid"] is False
    with pytest.raises(ValueError,match="audit_chain_corrupt"):
        replay_snapshot(tmp_path)

def test_quality_gate_blocks_non_pass(tmp_path):
    with pytest.raises(ValueError,match="btc_data_quality_gate_blocked"):
        append_ingestion(tmp_path,{"status":"BLOCKED","reasons":["gap"]})
