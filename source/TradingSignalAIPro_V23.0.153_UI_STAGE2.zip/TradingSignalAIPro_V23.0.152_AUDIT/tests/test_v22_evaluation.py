import numpy as np, pytest
from backend.evaluation import cost_model, net_returns, baseline_returns, calibration_metrics, performance_metrics, paper_v22_record, paper_v22_events

def test_cost_model_hash_and_net_returns():
 c=cost_model(5,2,1); assert c['cost_hash'] and c['version']=='cost-v1'
 assert np.allclose(net_returns([.01,-.01],costs=c),[.0092,-.0108])
 with pytest.raises(ValueError): cost_model(-1,0,0)

def test_baselines():
 assert np.allclose(baseline_returns([100,110,99]),[.1,-.1])
 assert np.allclose(baseline_returns([100,110,99],kind='flat'),[0,0])

def test_calibration_metrics():
 m=calibration_metrics([0,1,1,0],[.1,.9,.8,.2]); assert m['brier']<.03 and m['ece']<.2 and m['n']==4

def test_performance_metrics_deterministic():
 a=performance_metrics([.01,-.005,.02,-.01],bootstrap_samples=100,seed=4)
 b=performance_metrics([.01,-.005,.02,-.01],bootstrap_samples=100,seed=4)
 assert a==b and a['n']==4 and a['max_drawdown']<0

def test_paper_ledger_append_only(tmp_path,monkeypatch):
 monkeypatch.setenv('TRADING_AI_V22_PAPER_DB',str(tmp_path/'paper.sqlite'))
 paper_v22_record('run-1','signal',{'side':'LONG'})
 paper_v22_record('run-1','fill_simulated',{'price':100})
 rows=paper_v22_events('run-1'); assert len(rows)==2 and rows[0]['schema_version']=='paper-v1'
