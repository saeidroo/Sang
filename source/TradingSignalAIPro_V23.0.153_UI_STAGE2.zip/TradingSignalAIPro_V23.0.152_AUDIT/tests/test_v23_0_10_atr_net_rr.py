import json
import math
import time

import pytest

from backend import autopilot, paper_live
from backend.portfolio_risk import compute_atr_bracket, size_for_risk
from backend.trade_contract import atr_bracket as canonical_atr_bracket


@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(tmp_path / "atr_rr.sqlite3"))
    paper_live._CACHE.clear()


def fake_quote(symbol, market="spot", exchange="auto", **kwargs):
    return {
        "symbol": symbol, "market": market, "exchange": "binance",
        "exchange_name": "Binance", "price": 100.0,
        "timestamp": "2026-11-19T00:00:00+00:00",
        "checked_at_epoch": time.time(), "authenticated": False,
    }


def test_atr_bracket_long_and_short_respects_direction_and_net_rr():
    long = compute_atr_bracket(entry_price=100, atr_value=1.0, side="LONG")
    short = compute_atr_bracket(entry_price=100, atr_value=1.0, side="SHORT")
    assert long["stop_price"] < 100 < long["target_price"]
    assert short["target_price"] < 100 < short["stop_price"]
    assert long["net_reward_risk"] == pytest.approx(1.8, rel=1e-7)
    assert short["net_reward_risk"] == pytest.approx(1.8, rel=1e-7)
    assert long["funding_included"] is False


def test_wider_atr_creates_wider_stop_and_lower_position_size():
    low_vol = compute_atr_bracket(entry_price=100, atr_value=0.5, side="LONG")
    high_vol = compute_atr_bracket(entry_price=100, atr_value=1.0, side="LONG")
    assert high_vol["stop_loss_pct"] > low_vol["stop_loss_pct"]
    low_size = size_for_risk(equity=1000, risk_budget_cash=5,
                             stop_loss_pct=low_vol["stop_loss_pct"],
                             max_position_notional_pct=50, available_balance=1000)
    high_size = size_for_risk(equity=1000, risk_budget_cash=5,
                              stop_loss_pct=high_vol["stop_loss_pct"],
                              max_position_notional_pct=50, available_balance=1000)
    assert high_size["notional"] < low_size["notional"]
    assert high_size["estimated_stop_risk"] <= 5.0


def test_net_rr_accounts_for_round_trip_fees_and_slippage():
    bracket = compute_atr_bracket(entry_price=100, atr_value=1.2, side="LONG",
                                  fee_bps_per_side=12, slippage_bps_per_side=8,
                                  target_net_rr=1.8)
    assert bracket["round_trip_cost_pct"] == pytest.approx(0.4)
    assert bracket["net_reward_risk"] >= 1.8
    assert bracket["take_profit_pct"] > bracket["stop_loss_pct"] * 1.8


def test_atr_guard_rejects_extreme_volatility_and_invalid_inputs():
    with pytest.raises(ValueError, match="نوسان ATR"):
        compute_atr_bracket(entry_price=100, atr_value=4.0, side="LONG")
    with pytest.raises(ValueError):
        compute_atr_bracket(entry_price=100, atr_value=float("nan"), side="LONG")


def test_open_position_uses_atr_bracket_and_stores_training_context(monkeypatch):
    monkeypatch.setattr(paper_live, "get_consensus_quote", fake_quote)
    result = paper_live.open_position(
        "BTCUSDT", "LONG", "spot", "auto", timeframe="1h",
        overrides={"risk_per_trade_pct": 0.5, "max_position_notional_pct": 20.0},
        entry_source="autopilot", atr_value=1.0,
        decision_context={"signal": "BUY", "atr_risk_input": {"atr_pct": 1.0}},
    )
    assert result["atr_risk_bracket"] is not None
    assert result["stop_price"] < result["entry_fill"] < result["target_price"]
    trade = paper_live.list_trades(status="OPEN", limit=5)[0]
    context = json.loads(trade["entry_context_json"])
    bracket = context["decision_context"]["atr_risk_bracket"]
    settings = json.loads(trade["settings_json"])
    expected = canonical_atr_bracket(
        entry_price=result["entry_fill"], atr_value=1.0, side="LONG",
        fee_bps_per_side=result["execution_costs"]["fee_bps_per_side"],
        slippage_bps_per_side=result["execution_costs"]["total_adverse_price_bps_per_side"],
        entry_price_is_fill=True,
    )
    assert bracket["net_reward_risk"] == pytest.approx(expected["net_reward_risk"])
    assert bracket["stop_price"] == pytest.approx(expected["stop_price"])
    assert bracket["target_price"] == pytest.approx(expected["target_price"])
    assert result["estimated_stop_risk"] <= result["portfolio_risk_budget"] + 1e-7
    assert settings["stop_loss_pct"] == pytest.approx(bracket["stop_loss_pct"])
    assert settings["take_profit_pct"] == pytest.approx(bracket["take_profit_pct"])
    assert trade["stop_price"] == pytest.approx(bracket["stop_price"], rel=2e-4)
    assert context["decision_context"]["atr_risk_input"]["atr_pct"] == pytest.approx(1.0)


def test_manual_paper_entry_without_atr_keeps_configured_fixed_bracket(monkeypatch):
    monkeypatch.setattr(paper_live, "get_consensus_quote", fake_quote)
    result = paper_live.open_position(
        "ETHUSDT", "LONG", "spot", "auto", overrides={"stop_loss_pct": 1.25, "take_profit_pct": 2.5}
    )
    assert result["atr_risk_bracket"] is None
    assert result["settings"]["stop_loss_pct"] == pytest.approx(1.25)
    assert result["settings"]["take_profit_pct"] == pytest.approx(2.5)


def test_entry_atr_context_requires_same_closed_candle(monkeypatch):
    import numpy as np
    import pandas as pd
    monkeypatch.setattr(autopilot, "_analysis_symbol", lambda base, market: base + "USDT")
    expected_ts = 1_700_000_000_000.0
    n = 240
    close = 100.0 + np.arange(n) * 0.02 + np.sin(np.arange(n) / 7.0)
    frame = pd.DataFrame({
        "t": expected_ts - (n - 1) * 3_600_000 + np.arange(n) * 3_600_000,
        "open": close, "high": close + 0.8, "low": close - 0.8,
        "close": close, "volume": np.full(n, 1000.0),
    })
    monkeypatch.setattr(autopilot, "fetch_candles", lambda *a, **k: frame.copy())
    context = autopilot._entry_atr_context("BTC", "spot", "1h", {
        "candle_ts": expected_ts,
        "technical_snapshot": {"atr_14": 1.2, "close": 100.0, "candle_ts": expected_ts},
    })
    assert context["atr_value"] == pytest.approx(1.2)
    assert context["atr_pct"] == pytest.approx(1.2)
    with pytest.raises(ValueError, match="هم‌تراز"):
        autopilot._entry_atr_context("BTC", "spot", "1h", {
            "candle_ts": expected_ts,
            "technical_snapshot": {"atr_14": 1.2, "close": 100.0, "candle_ts": expected_ts - 1.0},
        })


def test_tech_signal_snapshot_carries_candle_timestamp():
    from pathlib import Path
    source = (Path(__file__).resolve().parents[1] / "backend" / "autopilot.py").read_text(encoding="utf-8")
    assert '"candle_ts": float(df["t"].iloc[-1])' in source


def test_dashboard_exposes_net_reward_risk_column():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    markup = (root / "frontend" / "index.html").read_text(encoding="utf-8")
    script = (root / "frontend" / "paper-live.js").read_text(encoding="utf-8")
    assert "نسبت خالص R/R" in markup
    assert "atr_risk_bracket" in script and "net_reward_risk" in script
    assert "td.colSpan=15" in script


def test_paper_atr_bracket_reports_final_net_rr_after_size_impact(monkeypatch):
    monkeypatch.setattr(paper_live, "get_consensus_quote", fake_quote)
    result = paper_live.open_position(
        "SOLUSDT", "LONG", "spot", "auto", timeframe="1h",
        overrides={"risk_per_trade_pct": 0.5, "max_position_notional_pct": 20.0},
        entry_source="autopilot", atr_value=1.0,
    )
    bracket = result["atr_risk_bracket"]
    validation = bracket["final_execution_validation"]
    assert bracket["net_reward_risk"] > 0
    assert validation["valid"] is True
    assert validation["net_reward_risk"] == pytest.approx(bracket["net_reward_risk"], rel=1e-6)
    assert validation["method"] == "final_notional_execution_cost_validation"


def test_paper_atr_bracket_reports_net_rr_for_short(monkeypatch):
    monkeypatch.setattr(paper_live, "get_consensus_quote", fake_quote)
    result = paper_live.open_position(
        "XRPUSDT", "SHORT", "perp", "auto", timeframe="1h",
        overrides={"risk_per_trade_pct": 0.5, "max_position_notional_pct": 20.0},
        entry_source="autopilot", atr_value=1.0,
    )
    bracket = result["atr_risk_bracket"]
    assert bracket["stop_price"] > bracket["entry_price"] > bracket["target_price"]
    expected = canonical_atr_bracket(
        entry_price=result["entry_fill"], atr_value=1.0, side="SHORT",
        fee_bps_per_side=result["execution_costs"]["fee_bps_per_side"],
        slippage_bps_per_side=result["execution_costs"]["total_adverse_price_bps_per_side"],
        entry_price_is_fill=True,
    )
    assert bracket["net_reward_risk"] == pytest.approx(expected["net_reward_risk"])
    assert bracket["stop_price"] == pytest.approx(expected["stop_price"])
    assert bracket["target_price"] == pytest.approx(expected["target_price"])
    assert bracket["final_execution_validation"]["valid"] is True
