"""Regression tests for strict lower-timeframe aggregation and audit propagation."""

import pandas as pd
import pytest

from backend import data as D


def _hourly_rows(start_ms: int, count: int):
    rows = []
    for i in range(count):
        t = start_ms + i * 3_600_000
        price = 100.0 + (i % 13) * 0.1
        rows.append({
            "t": t,
            "open": price,
            "high": price + 1.0,
            "low": price - 1.0,
            "close": price + 0.2,
            "volume": 10.0,
        })
    return rows


def test_strict_4h_aggregation_drops_bucket_with_missing_hour():
    now_ms = int(pd.Timestamp.now(tz="UTC").timestamp() * 1000)
    current_4h = (now_ms // (4 * 3_600_000)) * (4 * 3_600_000)
    start = current_4h - 8 * 3_600_000
    rows = _hourly_rows(start, 8)
    # Remove one of four source bars from the first 4h bucket.
    rows.pop(2)
    frame = D._clean_candles(rows)

    aggregated = D._aggregate(frame, 4 * 3600, source_seconds=3600)

    assert len(aggregated) == 1
    assert int(aggregated.iloc[0]["t"]) == current_4h - 4 * 3_600_000
    assert aggregated.attrs["aggregation_audit"] == {
        "source_seconds": 3600,
        "target_seconds": 4 * 3600,
        "expected_source_bars": 4,
        "incomplete_bucket_count": 1,
        "incomplete_source_rows_dropped": 3,
    }


def test_aggregation_preserves_normalization_audit():
    now_ms = int(pd.Timestamp.now(tz="UTC").timestamp() * 1000)
    current_4h = (now_ms // (4 * 3_600_000)) * (4 * 3_600_000)
    rows = _hourly_rows(current_4h - 4 * 3_600_000, 4)
    conflicting = dict(rows[1])
    conflicting["close"] = conflicting["close"] + 0.4
    conflicting["high"] = max(conflicting["high"], conflicting["close"])
    rows.append(conflicting)

    normalized = D._clean_candles(rows)
    assert normalized.attrs["normalization_audit"]["duplicate_conflict_groups"] == 1

    aggregated = D._aggregate(normalized, 4 * 3600, source_seconds=3600)

    assert len(aggregated) == 1
    assert aggregated.attrs["normalization_audit"]["duplicate_conflict_groups"] == 1


def test_aggregate_rejects_invalid_source_interval():
    frame = pd.DataFrame(columns=["t", "open", "high", "low", "close", "volume"])
    with pytest.raises(ValueError, match="positive divisor"):
        D._aggregate(frame, 3600, source_seconds=700)


def test_paper_fetch_fails_closed_when_aggregation_hides_conflicting_duplicate(monkeypatch, tmp_path):
    """A provider's pre-aggregation conflict must not disappear before the contract."""
    now_ms = int(pd.Timestamp.now(tz="UTC").timestamp() * 1000)
    now_bucket = (now_ms // (4 * 3_600_000)) * (4 * 3_600_000)
    # 210 complete 4h bars, ending at the previous fully closed 4h boundary.
    raw = _hourly_rows(now_bucket - 210 * 4 * 3_600_000, 210 * 4)
    conflicting = dict(raw[100])
    conflicting["close"] = conflicting["close"] + 0.3
    conflicting["high"] = max(conflicting["high"], conflicting["close"])
    raw.append(conflicting)
    normalized = D._clean_candles(raw)
    provider_frame = D._aggregate(normalized, 4 * 3600, source_seconds=3600)

    assert len(provider_frame) == 210
    assert provider_frame.attrs["normalization_audit"]["duplicate_conflict_groups"] == 1

    monkeypatch.setattr(D, "SOURCE_FUNCS", {"coinbase": lambda *args: provider_frame.copy()})
    monkeypatch.setattr(D, "_cache_dir", lambda: tmp_path)
    monkeypatch.setattr(D, "_save_cache", lambda *args: None)
    monkeypatch.setattr(D, "_load_cache", lambda *args: None)
    D.reset_source_health()

    with pytest.raises(RuntimeError, match="normalizer_removed_ambiguous_rows"):
        D.fetch_candles(
            "BTCUSDT", "4h", limit=210, source="coinbase",
            validation_mode="paper", max_age_bars=3,
        )


def test_fetch_candles_exposes_aggregation_audit(monkeypatch, tmp_path):
    now_ms = int(pd.Timestamp.now(tz="UTC").timestamp() * 1000)
    now_bucket = (now_ms // (4 * 3_600_000)) * (4 * 3_600_000)
    raw = _hourly_rows(now_bucket - 210 * 4 * 3_600_000, 210 * 4)
    provider_frame = D._aggregate(D._clean_candles(raw), 4 * 3600, source_seconds=3600)

    monkeypatch.setattr(D, "SOURCE_FUNCS", {"coinbase": lambda *args: provider_frame.copy()})
    monkeypatch.setattr(D, "_cache_dir", lambda: tmp_path)
    monkeypatch.setattr(D, "_save_cache", lambda *args: None)
    monkeypatch.setattr(D, "_load_cache", lambda *args: None)

    out = D.fetch_candles(
        "BTCUSDT", "4h", limit=210, source="coinbase",
        validation_mode="paper", max_age_bars=3,
    )

    audit = out.attrs["data_contract"]["aggregation_audit"]
    assert audit["expected_source_bars"] == 4
    assert audit["incomplete_bucket_count"] == 0


def test_nobitex_missing_volume_is_not_fabricated_as_zero():
    rows = D._rows_from_arrays({
        "t": [1_800_000_000],
        "o": [100], "h": [102], "l": [99], "c": [101],
    }, timestamp_unit="s")
    frame = D._clean_candles(rows)
    assert frame.attrs["normalization_audit"]["volume_available"] is False
    assert frame.attrs["normalization_audit"]["missing_volume_rows"] == 1


def test_bingx_missing_volume_is_reported(monkeypatch):
    ts = int(pd.Timestamp.now(tz="UTC").timestamp() * 1000) - 3_600_000
    payload = {"code": 0, "data": {"list": [{
        "time": ts, "open": "100", "high": "102", "low": "99", "close": "101"
    }]}}
    monkeypatch.setattr(D, "_get", lambda *args, **kwargs: payload)
    frame = D.fetch_bingx("BTCUSDT", "1h", limit=1)
    assert frame.attrs["normalization_audit"]["volume_available"] is False
    assert frame.attrs["normalization_audit"]["missing_volume_rows"] == 1


def test_yahoo_missing_volume_is_reported(monkeypatch):
    ts = int(pd.Timestamp.now(tz="UTC").timestamp()) - 3_600
    payload = {"chart": {"result": [{
        "timestamp": [ts],
        "indicators": {"quote": [{
            "open": [100], "high": [102], "low": [99], "close": [101]
        }]},
    }]}}
    monkeypatch.setattr(D, "_get", lambda *args, **kwargs: payload)
    frame = D.fetch_yahoo("BTCUSDT", "1h", limit=1)
    assert frame.attrs["normalization_audit"]["volume_available"] is False
    assert frame.attrs["normalization_audit"]["missing_volume_rows"] == 1


def test_coinmarketcap_missing_volume_is_reported(monkeypatch):
    ts = pd.Timestamp.now(tz="UTC").floor("h") - pd.Timedelta(hours=1)
    payload = {"data": [{
        "time_open": ts.isoformat(),
        "quote": {"USD": {"open": 100, "high": 102, "low": 99, "close": 101}},
    }]}
    monkeypatch.setenv("CMC_API_KEY", "test-key")
    monkeypatch.setattr(D, "_get", lambda *args, **kwargs: payload)
    frame = D.fetch_coinmarketcap("BTCUSDT", "1h", limit=1)
    assert frame.attrs["normalization_audit"]["volume_available"] is False
    assert frame.attrs["normalization_audit"]["missing_volume_rows"] == 1


def _fake_yahoo_response(payload):
    class Response:
        def raise_for_status(self):
            return None

        def json(self):
            return payload

    class Session:
        def get(self, *args, **kwargs):
            return Response()

    return Session()


def test_historical_metal_backfill_fails_closed_without_real_volume(monkeypatch):
    from backend import historical

    ts = int(pd.Timestamp("2024-01-01T00:00:00Z").timestamp())
    payload = {"chart": {"result": [{
        "timestamp": [ts],
        "indicators": {"quote": [{
            "open": [100], "high": [102], "low": [99], "close": [101]
        }]},
    }]}}
    monkeypatch.setattr(historical, "_new_session", lambda: _fake_yahoo_response(payload))

    with pytest.raises(RuntimeError, match="حجم واقعی"):
        historical._fetch_yahoo_metal("GOLD", "1h", "2024-01-01T00:00:00+00:00")


def test_historical_metal_4h_backfill_drops_incomplete_aggregation_bucket(monkeypatch):
    from backend import historical

    start = int(pd.Timestamp("2024-01-01T00:00:00Z").timestamp())
    stamps = [start + i * 3600 for i in (0, 1, 3, 4, 5, 6, 7)]
    payload = {"chart": {"result": [{
        "timestamp": stamps,
        "indicators": {"quote": [{
            "open": [100 + i for i in range(len(stamps))],
            "high": [102 + i for i in range(len(stamps))],
            "low": [99 + i for i in range(len(stamps))],
            "close": [101 + i for i in range(len(stamps))],
            "volume": [10 + i for i in range(len(stamps))],
        }]},
    }]}}
    monkeypatch.setattr(historical, "_new_session", lambda: _fake_yahoo_response(payload))

    frame = historical._fetch_yahoo_metal("GOLD", "4h", "2024-01-01T00:00:00+00:00")

    assert len(frame) == 1
    assert int(frame.iloc[0]["t"]) == (start + 4 * 3600) * 1000
    assert frame.attrs["aggregation_audit"]["incomplete_bucket_count"] == 1


def test_fractional_millisecond_timestamp_is_not_silently_truncated():
    base = (int(pd.Timestamp.now(tz="UTC").timestamp() * 1000) // 3_600_000) * 3_600_000
    rows = _hourly_rows(base - 2 * 3_600_000, 2)
    rows[1]["t"] += 0.5

    frame = D._clean_candles(rows)

    assert len(frame) == 1
    assert frame.attrs["normalization_audit"]["malformed_rows_dropped"] == 1
