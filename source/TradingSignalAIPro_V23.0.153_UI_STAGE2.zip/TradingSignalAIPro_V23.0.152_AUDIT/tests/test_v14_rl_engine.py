import numpy as np
import pandas as pd

from backend import rl_engine


def sample_candles(n=900):
    rng=np.random.default_rng(7)
    ret=rng.normal(0,0.008,n)
    close=100*np.exp(np.cumsum(ret))
    op=np.r_[close[0],close[:-1]]
    high=np.maximum(op,close)*(1+rng.uniform(0,.004,n))
    low=np.minimum(op,close)*(1-rng.uniform(0,.004,n))
    return pd.DataFrame({'t':np.arange(n)*3600000,'open':op,'high':high,'low':low,'close':close,
                         'volume':rng.lognormal(5,.4,n)})


def test_rl_features_are_finite_and_aligned():
    x,y,p=rl_engine._features(sample_candles())
    assert x.shape == (900,11)
    assert y.shape == p.shape == (900,)
    assert np.isfinite(x).all()
    assert np.isfinite(y).all()
    assert (p>0).all()


def test_rl_status_has_stable_shape():
    d=rl_engine.status()
    assert 'running' in d and 'stage' in d and 'log' in d
    assert isinstance(d['log'],list)


def test_rl_algorithm_allowlist():
    try:
        rl_engine.start_training('BTCUSDT','1h',sample_candles(),algorithms=['NOT_REAL'])
    except ValueError as e:
        assert 'الگوریتم نامعتبر' in str(e)
    else:
        raise AssertionError('invalid algorithm was accepted')
