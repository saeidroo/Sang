import pytest
from backend.absorption_intelligence import analyze_absorption


def samples(kind, n=5):
    if kind == 'bid':
        return [{'aggressive_buy_volume': 20, 'aggressive_sell_volume': 100, 'price_change_pct': 0.03} for _ in range(n)]
    if kind == 'ask':
        return [{'aggressive_buy_volume': 100, 'aggressive_sell_volume': 20, 'price_change_pct': -0.04} for _ in range(n)]
    if kind == 'sell_breakdown':
        return [{'aggressive_buy_volume': 20, 'aggressive_sell_volume': 100, 'price_change_pct': -0.5} for _ in range(n)]
    return [{'aggressive_buy_volume': 50, 'aggressive_sell_volume': 50, 'price_change_pct': 0.01} for _ in range(n)]


def test_persistent_bid_absorption_candidate():
    result = analyze_absorption([{'symbol': 'BTCUSDT', 'samples': samples('bid')}])['results'][0]
    assert result['decision'] == 'PERSISTENT_BID_ABSORPTION_CANDIDATE'
    assert result['context'] == 'POTENTIALLY_BULLISH'
    assert result['evidence']['bid_absorption_persistence'] == 1.0


def test_persistent_ask_absorption_candidate():
    result = analyze_absorption([{'symbol': 'ETHUSDT', 'samples': samples('ask')}])['results'][0]
    assert result['decision'] == 'PERSISTENT_ASK_ABSORPTION_CANDIDATE'
    assert result['context'] == 'POTENTIALLY_BEARISH'


def test_heavy_sell_flow_with_real_down_move_is_not_absorption():
    result = analyze_absorption([{'symbol': 'X', 'samples': samples('sell_breakdown')}])['results'][0]
    assert result['decision'] == 'NO_PERSISTENT_ABSORPTION_EVIDENCE'


def test_candle_volume_or_missing_price_change_is_not_enough():
    data = [{'aggressive_buy_volume': 100, 'aggressive_sell_volume': 20} for _ in range(5)]
    result = analyze_absorption([{'symbol': 'X', 'samples': data}])['results'][0]
    assert result['decision'] == 'INSUFFICIENT_DATA'


def test_persistence_prevents_single_interval_false_positive():
    data = samples('bid')
    data[-1] = {'aggressive_buy_volume': 50, 'aggressive_sell_volume': 50, 'price_change_pct': -0.2}
    result = analyze_absorption([{'symbol': 'X', 'samples': data}])['results'][0]
    assert result['decision'] == 'PERSISTENT_BID_ABSORPTION_CANDIDATE'
    assert result['evidence']['bid_absorption_persistence'] == 0.8


def test_validation_and_paper_only():
    with pytest.raises(ValueError):
        analyze_absorption([], dominance_ratio=1.0)
    result = analyze_absorption([{'symbol': 'X', 'samples': samples('bid')}])
    assert result['real_orders_enabled'] is False
    assert result['results'][0]['entry_authorized'] is False
    assert result['results'][0]['execution_authorized'] is False
