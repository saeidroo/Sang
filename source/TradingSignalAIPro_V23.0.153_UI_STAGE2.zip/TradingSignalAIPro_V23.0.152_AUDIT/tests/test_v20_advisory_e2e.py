"""V20 e2e: analyze a pair with NO primary model — advisory consensus mode.

Fake OHLCV data + 4 fake trained models in the pool. The response must be 200,
labelled advisory, carry the pool votes, and any BUY/SELL must be clearly
marked as advisory with provisional levels.
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend import api, consensus  # noqa: E402

FEATURES = ['ret_1', 'ret_5', 'close_to_ema_20', 'ema_20_over_50', 'rsi_14_norm']  # real feature columns


class FakeModel:
    is_fitted = True

    def __init__(self, prob):
        self.prob = prob
        self.feature_names = FEATURES

    def predict_proba(self, X, use_meta=True):
        return float(self.prob)


def synthetic_candles(n=900):
    rng = np.random.default_rng(42)
    base = 100.0
    steps = rng.normal(0.0004, 0.008, size=n)
    close = base * np.exp(np.cumsum(steps))
    high = close * (1 + np.abs(rng.normal(0, 0.004, n)))
    low = close * (1 - np.abs(rng.normal(0, 0.004, n)))
    open_ = np.concatenate([[close[0]], close[:-1]])
    vol = rng.uniform(1000, 5000, n)
    ts = pd.date_range('2024-01-01', periods=n, freq='1h').astype('int64') // 10**6
    df = pd.DataFrame({'t': ts, 'open': open_, 'high': high, 'low': low,
                       'close': close, 'volume': vol})
    df.attrs['source'] = 'test'
    df.attrs['source_label'] = 'تست'
    return df


@pytest.fixture
def advisory_env(tmp_path, monkeypatch):
    models_dir = tmp_path / 'models'
    models_dir.mkdir()
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(models_dir))
    consensus._CACHE.clear()
    # 4 pool models, 3 bullish with edge confirmed -> strong consensus
    pool_cfg = [
        ('ETHUSDT', '4h', 0.78, True, 0.63),
        ('SOLUSDT', '1h', 0.72, True, 0.59),
        ('ADAUSDT', '15m', 0.80, True, 0.61),
        ('XRPUSDT', '1d', 0.35, False, 0.53),
    ]
    for sym, tf, prob, edge, acc in pool_cfg:
        (models_dir / f'model_{sym}_{tf}.joblib').write_bytes(b'x')
        meta = {'symbol': sym, 'timeframe': tf, 'feature_schema_version': 6,
                'edge_confirmed': edge, 'walk_forward_acc': acc}
        (models_dir / f'meta_{sym}_{tf}.json').write_text(json.dumps(meta),
                                                          encoding='utf-8')
    def fake_loader(path):
        name = Path(path).stem[len('model_'):]
        sym, tf = name.rsplit('_', 1)
        for s, t, p, _e, _a in pool_cfg:
            if (s, t) == (sym, tf):
                return FakeModel(p)
        return None
    monkeypatch.setattr(consensus, '_load_model_cached', fake_loader)

    df = synthetic_candles()
    monkeypatch.setattr(api, 'fetch_candles', lambda *a, **k: df)
    monkeypatch.setattr(api, 'build_news_alert', lambda sym: None)
    return models_dir


def test_analyze_without_primary_model_uses_pool(advisory_env):
    api.app.config['TESTING'] = True
    with api.app.test_client() as c:
        resp = c.post('/api/analyze', json={'symbol': 'NEWUSDT', 'timeframe': '1h',
                                            'limit': 900, 'source': 'auto'})
        assert resp.status_code == 200, resp.get_json()
        d = resp.get_json()
        assert d['has_model'] is True
        assert d['advisory'] is True
        assert d['model_pool']['n'] == 4
        assert d['model_pool']['consensus_dir'] == 'UP'
        assert d['model_pool']['consensus_prob'] > 0.55
        assert d['primary_prob'] is None
        assert d['blend_weight'] == 1.0
        sig = d['signal']
        assert sig['advisory'] is True
        if sig['kind'] in ('BUY', 'SELL'):
            assert sig['levels_provisional'] is True
            assert 'مشورتی' in sig['reason']
        # pool consensus note attached to the reasons list
        assert any('اجماع' in str(r[1]) for r in sig.get('reasons', []))
        # no fabricated backtest for a pair without its own model
        assert d['backtest'] == []


def test_analyze_with_no_models_at_all_returns_404(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(tmp_path / 'empty'))
    consensus._CACHE.clear()
    df = synthetic_candles()
    df.attrs['source'] = 'test'
    df.attrs['source_label'] = 'تست'
    monkeypatch.setattr(api, 'fetch_candles', lambda *a, **k: df)
    monkeypatch.setattr(api, 'build_news_alert', lambda sym: None)
    api.app.config['TESTING'] = True
    with api.app.test_client() as c:
        resp = c.post('/api/analyze', json={'symbol': 'NEWUSDT', 'timeframe': '1h',
                                            'limit': 900, 'source': 'auto'})
        assert resp.status_code == 404
        d = resp.get_json()
        assert d['has_model'] is False
