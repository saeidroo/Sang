from backend import storm_learning as sl


def _coin(symbol, regime):
    return {
        'symbol': symbol, 'price': 100, 'score': 75, 'phase': 'early',
        'direction': 'up', 'verified': True,
        'btc_regime_4h': {'state': regime},
    }


def test_historical_learning_separates_btc_regimes(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'regime.sqlite3')
    base = 1_820_000_000
    for i in range(5):
        for regime, price in (('up', 103), ('down', 100)):
            symbol = f'{regime}{i}'
            ts = base + i * 1_000_000 + (0 if regime == 'up' else 100_000)
            sl.record_scan([_coin(symbol, regime)], timestamp=ts)
            sl.record_scan([], timestamp=ts + 4 * 3600,
                           snapshots={symbol: {'price': price}})

    insights = sl.followups()['historical_insights']
    bull = next(x for x in insights if x['horizon'] == '4h' and x['market_regime'] == 'UP')
    bear = next(x for x in insights if x['horizon'] == '4h' and x['market_regime'] == 'DOWN')
    assert bull['samples'] == bear['samples'] == 5
    assert bull['success_rate'] == 1.0
    assert bear['success_rate'] == 0.0


def test_missing_regime_is_not_guessed(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'unknown.sqlite3')
    sl.record_scan([{'symbol': 'ABCUSDT', 'price': 10, 'score': 60,
                     'phase': 'early', 'direction': 'up', 'verified': True}],
                   timestamp=1_830_000_000)
    with sl._db() as con:
        row = con.execute('SELECT market_regime FROM scout_sightings').fetchone()
    assert row['market_regime'] == 'UNKNOWN'


def test_old_database_gets_safe_unknown_regime_migration(tmp_path, monkeypatch):
    import sqlite3
    db = tmp_path / 'legacy.sqlite3'
    con = sqlite3.connect(db)
    con.execute('''CREATE TABLE scout_sightings (
        id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, ts REAL NOT NULL,
        price REAL NOT NULL, score REAL NOT NULL, phase TEXT NOT NULL,
        direction TEXT NOT NULL, verified INTEGER NOT NULL, pattern TEXT NOT NULL,
        UNIQUE(symbol, ts))''')
    con.execute("INSERT INTO scout_sightings(symbol,ts,price,score,phase,direction,verified,pattern) VALUES('OLDUSDT',1,1,50,'early','up',1,'legacy')")
    con.commit(); con.close()
    monkeypatch.setattr(sl, 'DB_PATH', db)
    with sl._db() as migrated:
        row = migrated.execute('SELECT market_regime FROM scout_sightings').fetchone()
    assert row['market_regime'] == 'UNKNOWN'
