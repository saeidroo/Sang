from backend import paper_live


def _seed_closed_trade(monkeypatch, tmp_path):
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'ledger.sqlite3'))
    paper_live.init_db()
    with paper_live._connect() as c:
        cur = c.execute('''INSERT INTO paper_live_trades(
            opened_at,symbol,market,exchange,requested_exchange,side,quantity,notional,
            reference_entry,entry_fill,entry_fee,stop_price,target_price,status,closed_at,
            reference_exit,exit_fill,exit_fee,gross_pnl,net_pnl,exit_reason,settings_json,
            timeframe,entry_context_json,funding_total,funding_event_count,funding_status
        ) VALUES(1,'BTCUSDT','spot','binance','binance','LONG',1,100,100,100,0.1,90,120,
                 'CLOSED',2,110,110,0.1,10,9.8,'TEST','{}','1h','{}',0,0,'NOT_APPLICABLE')''')
        trade_id = cur.lastrowid
        c.execute('''INSERT INTO paper_learning_events(
            trade_id,closed_at,symbol,market,timeframe,exchange,side,exit_reason,outcome,
            net_pnl,return_pct,duration_seconds,notional,gross_pnl,total_fees,entry_fill,exit_fill,context_json
        ) VALUES(?,2,'BTCUSDT','spot','1h','binance','LONG','TEST',1,9.8,9.8,1,100,10,0.2,100,110,'{}')''', (trade_id,))
    return trade_id


def test_startup_ledger_reconciliation_accepts_consistent_learning_pair(monkeypatch, tmp_path):
    _seed_closed_trade(monkeypatch, tmp_path)
    report = paper_live.validate_paper_ledger()
    assert report['valid'] is True
    assert report['checks']['learning_trade_mismatches'] == 0
    assert report['checks']['missing_reconciled_learning_events'] == 0


def test_startup_ledger_reconciliation_blocks_learning_pnl_mismatch(monkeypatch, tmp_path):
    trade_id = _seed_closed_trade(monkeypatch, tmp_path)
    with paper_live._connect() as c:
        c.execute('UPDATE paper_learning_events SET net_pnl=999 WHERE trade_id=?', (trade_id,))
    report = paper_live.validate_paper_ledger()
    assert report['valid'] is False
    assert 'learning_trade_mismatches:1' in report['errors']


def test_startup_ledger_reconciliation_detects_missing_learning_event(monkeypatch, tmp_path):
    trade_id = _seed_closed_trade(monkeypatch, tmp_path)
    with paper_live._connect() as c:
        c.execute('DELETE FROM paper_learning_events WHERE trade_id=?', (trade_id,))
    report = paper_live.validate_paper_ledger()
    assert report['valid'] is False
    assert 'missing_reconciled_learning_events:1' in report['errors']
