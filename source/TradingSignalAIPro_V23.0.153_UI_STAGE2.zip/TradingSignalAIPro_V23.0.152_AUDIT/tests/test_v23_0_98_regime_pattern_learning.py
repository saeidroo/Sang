import sqlite3
from backend import market_brain


def _db(path, rows):
    con = sqlite3.connect(path)
    con.execute('''CREATE TABLE brain_forecasts (
        id INTEGER PRIMARY KEY, symbol TEXT, horizon TEXT, created_ts REAL, due_ts REAL,
        start_price REAL, predicted_up REAL, predicted_down REAL, observed_ts REAL,
        observed_return REAL, outcome TEXT, pattern_signature TEXT, market_regime TEXT)''')
    con.executemany('''INSERT INTO brain_forecasts
        (id,symbol,horizon,created_ts,due_ts,start_price,predicted_up,predicted_down,
         observed_ts,observed_return,outcome,pattern_signature,market_regime)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''', rows)
    con.commit(); con.close()


def test_pattern_feedback_is_scoped_to_current_regime(tmp_path, monkeypatch):
    db = tmp_path / 'feedback.sqlite3'
    monkeypatch.setattr(market_brain, 'FEEDBACK_DB_PATH', db)
    rows = []
    # Bull: 20 directional calls, all correct.
    for i in range(20):
        rows.append((i+1, 'BTCUSDT', '4h', i, i+1, 100, 70, 30, i+2, 2, 'up', 'sig', 'bull'))
    # Bear: 20 directional calls, all wrong for bullish forecast.
    for i in range(20):
        rows.append((i+21, 'ETHUSDT', '4h', i, i+1, 100, 70, 30, i+2, -2, 'down', 'sig', 'bear'))
    _db(db, rows)
    bull = market_brain._pattern_feedback('sig', 'bull')
    bear = market_brain._pattern_feedback('sig', 'bear')
    overall = market_brain._pattern_feedback('sig')
    assert bull['directional_calls'] == 20 and bull['accuracy_pct'] == 100.0
    assert bear['directional_calls'] == 20 and bear['accuracy_pct'] == 0.0
    assert overall['directional_calls'] == 40 and overall['accuracy_pct'] == 50.0
    assert bull['weight'] > 1.0
    assert bear['weight'] < 1.0


def test_regime_pattern_feedback_keeps_sample_gate(tmp_path, monkeypatch):
    db = tmp_path / 'feedback.sqlite3'
    monkeypatch.setattr(market_brain, 'FEEDBACK_DB_PATH', db)
    rows = [(i+1, 'BTCUSDT', '4h', i, i+1, 100, 80, 20, i+2, 2, 'up', 'sig', 'bull') for i in range(19)]
    _db(db, rows)
    result = market_brain._pattern_feedback('sig', 'bull')
    assert result['directional_calls'] == 19
    assert result['weight'] == 1.0
    assert result['reliability'] == 'insufficient_samples'
