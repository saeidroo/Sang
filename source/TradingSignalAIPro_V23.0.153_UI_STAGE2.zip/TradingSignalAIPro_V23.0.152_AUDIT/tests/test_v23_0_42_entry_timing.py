import numpy as np
import pandas as pd
from backend.entry_timing import evaluate_entry_timing


def candles(n=80, trend=0.0):
    close = 100 + np.arange(n) * trend + np.sin(np.arange(n) * 0.7) * 0.15
    return pd.DataFrame({'open': close-0.03, 'high': close+0.25, 'low': close-0.25,
                         'close': close, 'volume': np.full(n, 1000.0)})


def test_insufficient_candles_are_neutral_and_safe():
    r = evaluate_entry_timing(candles(10), 'LONG')
    assert not r['available'] and r['ranking_multiplier'] == 1.0
    assert r['real_orders_enabled'] is False


def test_invalid_side_is_neutral():
    assert evaluate_entry_timing(candles(), 'BUY')['ranking_multiplier'] == 1.0


def test_extended_move_is_flagged_as_late_entry():
    r = evaluate_entry_timing(candles(trend=0.8), 'LONG')
    assert r['setup'] == 'LATE_ENTRY'
    assert r['ranking_multiplier'] == 0.90


def test_flat_market_near_ema_is_pullback_zone_not_entry_signal():
    r = evaluate_entry_timing(candles(trend=0), 'LONG')
    assert r['setup'] == 'PULLBACK_ZONE'
    assert r['ranking_multiplier'] == 1.01
    assert r['read_only'] is True


def test_missing_volume_does_not_confirm_breakout():
    f = candles(trend=0.02).drop(columns=['volume'])
    r = evaluate_entry_timing(f, 'LONG')
    assert r['available'] is True
    assert r['volume_confirmation'] is None
    assert r['real_orders_enabled'] is False
