from backend.master_market_intelligence import analyze_master_market_intelligence


def test_fuses_multiple_aligned_sources():
    r = analyze_master_market_intelligence([{'symbol':'BTCUSDT','evidence':{
        'technical':{'score':90,'direction':'BUY'},
        'smart_money_flow':{'score':85,'flow_direction':'BUY_PRESSURE'},
        'liquidity':{'score':80,'bias':'BULLISH'},
        'opportunity':{'score':88,'direction':'LONG'},
    }}])
    x = r['results'][0]
    assert x['decision'] == 'HIGH_CONVICTION_WATCH'
    assert x['direction'] == 'BULLISH'
    assert x['entry_authorized'] is False
    assert r['capital_usdt'] == 1000 and r['real_orders_enabled'] is False


def test_conflicting_directions_are_penalized():
    x = analyze_master_market_intelligence([{'symbol':'ETHUSDT','evidence':{
        'technical':{'score':90,'direction':'BUY'},
        'smart_money_flow':{'score':90,'direction':'SELL'},
        'liquidity':{'score':90,'direction':'BUY'},
        'market_trap':{'score':90,'direction':'SELL'},
    }}])['results'][0]
    assert x['decision'] == 'CONFLICTING_EVIDENCE'
    assert x['score'] < 90


def test_missing_and_invalid_sources_do_not_create_signal():
    x = analyze_master_market_intelligence([{'symbol':'X','evidence':{
        'technical':{'score':101,'direction':'BUY'},
        'smart_money_flow':{'score':float('nan'),'direction':'BUY'},
    }}])['results'][0]
    assert x['decision'] == 'INSUFFICIENT_DATA'
    assert x['score'] == 0


def test_single_source_is_insufficient_and_orders_never_enabled():
    r = analyze_master_market_intelligence([{'symbol':'SOLUSDT','evidence':{
        'technical':{'score':99,'direction':'BUY'}
    }}])
    assert r['results'][0]['decision'] == 'INSUFFICIENT_EVIDENCE'
    assert r['creates_orders'] is False
    assert r['execution_authorized'] is False
