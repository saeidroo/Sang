const fs = require('fs');
const vm = require('vm');
const noop = () => {};
const context2d = new Proxy({
  setTransform: noop, clearRect: noop, fillRect: noop, beginPath: noop,
  moveTo: noop, lineTo: noop, stroke: noop, fill: noop, closePath: noop,
  fillText: noop, setLineDash: noop, save: noop, restore: noop,
}, { set(target, key, value) { target[key] = value; return true; } });
function makeCanvas() {
  const listeners = {};
  return {
    style: {}, width: 0, height: 0, parentNode: null,
    setAttribute: noop, getContext: () => context2d,
    addEventListener: (name, fn) => { listeners[name] = fn; },
    removeEventListener: noop,
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 800, height: 480 }),
  };
}
const host = {
  clientWidth: 800, clientHeight: 480, children: [],
  appendChild(node) { node.parentNode = this; this.children.push(node); },
  removeChild(node) { this.children = this.children.filter(x => x !== node); node.parentNode = null; },
  getBoundingClientRect: () => ({ width: 800, height: 480 }),
  set innerHTML(value) { this.html = value; this.children = []; },
  get innerHTML() { return this.html || ''; },
};
const sandbox = {
  console, Math, Date, Map, Set, Number, String, Array, Object, JSON, Intl,
  document: { createElement: () => makeCanvas() }, devicePixelRatio: 1,
};
sandbox.window = sandbox;
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync('frontend/chart-fallback.js', 'utf8'), sandbox);
if (!sandbox.LightweightCharts.__fallback) throw new Error('Canvas fallback was not installed');
const chart = sandbox.LightweightCharts.createChart(host, {});
const candles = chart.addCandlestickSeries({});
const volume = chart.addHistogramSeries({});
const ema = chart.addLineSeries({ color: '#91a4ff' });
candles.setData([
  { time: 1, open: 10, high: 12, low: 9, close: 11 },
  { time: 2, open: 11, high: 13, low: 10, close: 12 },
]);
volume.setData([{ time: 1, value: 100 }, { time: 2, value: 120 }]);
ema.setData([{ time: 1, value: 10.5 }, { time: 2, value: 11.5 }]);
candles.setMarkers([{ time: 2, position: 'belowBar', color: '#0f0', text: 'BUY' }]);
const priceLine = candles.createPriceLine({ price: 11, color: '#ff0', title: 'Entry', lineStyle: 2 });
chart.timeScale().fitContent();
if (!Number.isFinite(candles.coordinateToPrice(200))) throw new Error('Price coordinate conversion failed');
candles.removePriceLine(priceLine);
chart.removeSeries(ema);
chart.remove();
console.log('V22.7.3 Canvas fallback smoke test: PASS');
