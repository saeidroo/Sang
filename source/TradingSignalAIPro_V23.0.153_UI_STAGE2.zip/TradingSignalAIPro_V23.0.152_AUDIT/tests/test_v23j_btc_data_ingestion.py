import pytest

from backend.btc_data_ingestion import (
    VERSION, fetch_btc_4h_history, require_training_quality,
)
from backend.btc_walkforward import FOUR_HOURS_MS


def _kline(pos, *, close_time=None, close=None):
    ts = pos * FOUR_HOURS_MS
    o = 100.0 + pos
    c = o + 0.25 if close is None else close
    return [ts, str(o), str(max(o, c) + 1), str(min(o, c) - 1), str(c), "12.5",
            ts + FOUR_HOURS_MS - 1 if close_time is None else close_time,
            "0", 10, "0", "0", "0"]


def _fixture_fetcher(rows):
    calls = []
    def fetch(params):
        calls.append(dict(params))
        eligible = [r for r in rows if r[0] >= params["startTime"]]
        if "endTime" in params:
            eligible = [r for r in eligible if r[0] <= params["endTime"]]
        return eligible[:params["limit"]]
    fetch.calls = calls
    return fetch


def test_paginates_and_returns_only_closed_candles_with_hash():
    now = 10 * FOUR_HOURS_MS + 1000
    rows = [_kline(i) for i in range(3, 10)] + [_kline(10)]  # candle 10 is still open
    fetch = _fixture_fetcher(rows)
    result = fetch_btc_4h_history(start_time_ms=3 * FOUR_HOURS_MS, now_ms=now,
                                  page_limit=3, fetch_page=fetch)
    assert result["version"] == VERSION
    assert result["status"] == "PASS"
    assert result["row_count"] == 7
    assert result["page_count"] == 3
    assert result["candles"][-1]["t"] == 9 * FOUR_HOURS_MS
    assert len(result["data_sha256"]) == 64
    assert len(fetch.calls) == 3
    assert result["safety"]["training_allowed"] is True
    assert result["safety"]["live_order_submission"] is False


def test_quality_gate_blocks_gap_without_filling_it():
    now = 10 * FOUR_HOURS_MS + 1000
    rows = [_kline(i) for i in (3, 4, 6, 7, 8, 9)]
    result = fetch_btc_4h_history(start_time_ms=3 * FOUR_HOURS_MS, now_ms=now,
                                  page_limit=100, fetch_page=_fixture_fetcher(rows))
    assert result["status"] == "BLOCKED"
    assert any("gaps_exceed_policy" in reason for reason in result["reasons"])
    assert result["candles"] == []
    assert result["safety"]["training_allowed"] is False


def test_stale_latest_candle_blocks_training():
    now = 10 * FOUR_HOURS_MS + 1000
    rows = [_kline(i) for i in range(3, 9)]
    result = fetch_btc_4h_history(start_time_ms=3 * FOUR_HOURS_MS, now_ms=now,
                                  fetch_page=_fixture_fetcher(rows))
    assert result["status"] == "BLOCKED"
    assert any("latest_candle_stale" in reason for reason in result["reasons"])


def test_invalid_range_and_duplicate_across_pages_rejected():
    with pytest.raises(ValueError, match="align"):
        fetch_btc_4h_history(start_time_ms=1, now_ms=10 * FOUR_HOURS_MS,
                             fetch_page=lambda _: [])
    row = _kline(3)
    with pytest.raises(ValueError, match="duplicate_candle"):
        fetch_btc_4h_history(start_time_ms=3 * FOUR_HOURS_MS, now_ms=10 * FOUR_HOURS_MS,
                             page_limit=1, max_pages=5,
                             fetch_page=lambda p: [row, _kline(4)] if p["startTime"] == 3 * FOUR_HOURS_MS else [row])


def test_training_gate_accepts_only_clean_pass():
    now = 10 * FOUR_HOURS_MS + 1000
    result = fetch_btc_4h_history(start_time_ms=3 * FOUR_HOURS_MS, now_ms=now,
                                  fetch_page=_fixture_fetcher([_kline(i) for i in range(3, 10)]))
    frame = require_training_quality(result)
    assert len(frame) == 7
    with pytest.raises(ValueError, match="quality_gate_blocked"):
        require_training_quality({"status": "WARN", "reasons": ["review_required"]})
