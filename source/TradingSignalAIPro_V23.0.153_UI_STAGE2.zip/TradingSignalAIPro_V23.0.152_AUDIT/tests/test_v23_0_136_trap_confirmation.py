from backend.market_trap_detector import detect_market_traps


def test_single_wick_is_candidate_not_confirmed_trap():
    c = {'symbol': 'ETHUSDT', 'swing_high': 105, 'candles': [
        {'open': 102, 'high': 104, 'low': 101, 'close': 103, 'volume': 100},
        {'open': 104, 'high': 107, 'low': 103, 'close': 104, 'volume': 180},
    ]}
    x = detect_market_traps([c])['results'][0]
    assert x['trap_type'] == 'BULL_TRAP_CANDIDATE'
    assert x['confirmed_by_follow_through'] is False


def test_bull_trap_follow_through_needs_third_candle():
    c = {'symbol': 'ETHUSDT', 'swing_high': 105, 'candles': [
        {'open': 103, 'high': 107, 'low': 102, 'close': 104, 'volume': 120},
        {'open': 104, 'high': 105, 'low': 100, 'close': 102, 'volume': 140},
        {'open': 102, 'high': 103, 'low': 98, 'close': 99, 'volume': 200},
    ]}
    x = detect_market_traps([c])['results'][0]
    assert x['trap_type'] == 'BULL_TRAP_CANDIDATE'
    assert x['confirmed_by_follow_through'] is True
    assert x['evidence']['bull_trap_follow_through'] is True


def test_bear_trap_follow_through_is_separate_direction():
    c = {'symbol': 'BTCUSDT', 'swing_low': 95, 'candles': [
        {'open': 97, 'high': 99, 'low': 93, 'close': 96, 'volume': 100},
        {'open': 96, 'high': 100, 'low': 95, 'close': 98, 'volume': 150},
        {'open': 98, 'high': 102, 'low': 97, 'close': 101, 'volume': 180},
    ]}
    x = detect_market_traps([c])['results'][0]
    assert x['trap_type'] == 'BEAR_TRAP_CANDIDATE'
    assert x['confirmed_by_follow_through'] is True


def test_no_execution_authority_even_when_confirmed():
    c = {'symbol': 'X', 'swing_high': 105, 'candles': [
        {'open': 103, 'high': 107, 'low': 102, 'close': 104},
        {'open': 104, 'high': 105, 'low': 100, 'close': 102},
        {'open': 102, 'high': 103, 'low': 98, 'close': 99},
    ]}
    r = detect_market_traps([c])
    assert r['real_orders_enabled'] is False
    assert r['results'][0]['entry_authorized'] is False
    assert r['results'][0]['execution_authorized'] is False
