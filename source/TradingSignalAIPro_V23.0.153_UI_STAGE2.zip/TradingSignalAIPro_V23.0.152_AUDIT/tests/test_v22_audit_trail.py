import json

from backend.audit_trail import seal_event, verify_events
from backend import experiment_registry as registry
from backend import evaluation


def test_hash_chain_detects_tampering():
    a=seal_event({'event_id':'a','value':1})
    b=seal_event({'event_id':'b','value':2},a['event_hash'])
    assert verify_events([a,b])['valid']
    b['value']=99
    report=verify_events([a,b])
    assert not report['valid']
    assert any('event_hash_mismatch' in x for x in report['errors'])


def test_registry_chain_and_tamper_detection(tmp_path):
    registry.register_hypothesis('H1','title','hypothesis',custom_dir=tmp_path)
    registry.start_experiment('H1',symbol='BTC',timeframe='4h',data_hash='a'*64,config={},custom_dir=tmp_path)
    assert registry.audit_integrity(tmp_path)['valid']
    p=tmp_path/'experiments'/'registry.jsonl'
    rows=[json.loads(x) for x in p.read_text().splitlines()]
    rows[0]['title']='changed'
    p.write_text('\n'.join(json.dumps(x) for x in rows)+'\n')
    assert not registry.audit_integrity(tmp_path)['valid']


def test_paper_ledger_idempotency_and_integrity(tmp_path, monkeypatch):
    db=tmp_path/'paper.sqlite3'
    monkeypatch.setenv('TRADING_AI_V22_PAPER_DB',str(db))
    first=evaluation.paper_v22_record('run-1','trade_opened',{'symbol':'BTC'},'key-1')
    second=evaluation.paper_v22_record('run-1','trade_opened',{'symbol':'BTC'},'key-1')
    assert first['event_id']==second['event_id']
    assert second['duplicate'] is True
    assert evaluation.paper_v22_audit_integrity()['valid']
    with __import__('sqlite3').connect(db) as c:
        c.execute("UPDATE paper_events SET payload=? WHERE event_id=?",('{"symbol":"ETH"}',first['event_id']))
    report=evaluation.paper_v22_audit_integrity()
    assert not report['valid']
