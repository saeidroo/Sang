import json, zipfile
import pytest
from backend.btc_readonly_review_bundle import (build_readonly_external_review_bundle,
    verify_readonly_external_review_bundle)


def test_review_bundle_build_and_verify(tmp_path):
    files=[]
    for name,content in [('fetch.json','{}'),('drift.json','{}'),('pilot.json','{}')]:
        p=tmp_path/name; p.write_text(content); files.append(p)
    out=tmp_path/'review.zip'
    result=build_readonly_external_review_bundle(artifact_paths=files,output_path=out,release_version='22.4.16')
    assert result['artifact_count']==3
    assert verify_readonly_external_review_bundle(out)['valid']


def test_review_bundle_rejects_secrets_duplicates_and_tamper(tmp_path):
    secret=tmp_path/'private.pem'; secret.write_text('private')
    with pytest.raises(ValueError,match='sensitive'):
        build_readonly_external_review_bundle(artifact_paths=[secret],output_path=tmp_path/'s.zip',release_version='x')
    f=tmp_path/'a.json'; f.write_text('{}')
    with pytest.raises(ValueError,match='duplicate'):
        build_readonly_external_review_bundle(artifact_paths=[f,f],output_path=tmp_path/'d.zip',release_version='x')
    out=tmp_path/'good.zip'
    build_readonly_external_review_bundle(artifact_paths=[f],output_path=out,release_version='x')
    with zipfile.ZipFile(out) as z: items={n:z.read(n) for n in z.namelist()}
    items['artifacts/a.json']=b'{"changed":true}'
    with zipfile.ZipFile(tmp_path/'tampered.zip','w') as z:
        for n,b in items.items(): z.writestr(n,b)
    with pytest.raises(ValueError,match='artifact_hash_mismatch'):
        verify_readonly_external_review_bundle(tmp_path/'tampered.zip')
