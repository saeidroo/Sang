from backend.scout import _apply_brain_priority


def test_validated_pattern_history_reorders_without_changing_score():
    items = [
        {'symbol': 'AAAUSDT', 'score': 80, 'brain_prediction': {'pattern_learning': {
            'weight': 0.75, 'directional_calls': 30, 'reliability': 'historically_weak'}}},
        {'symbol': 'BBBUSDT', 'score': 75, 'brain_prediction': {'pattern_learning': {
            'weight': 1.15, 'directional_calls': 25, 'reliability': 'historically_supportive'}}},
    ]
    ranked = _apply_brain_priority(items)
    assert [x['symbol'] for x in ranked] == ['BBBUSDT', 'AAAUSDT']
    assert {x['symbol']: x['score'] for x in ranked} == {'AAAUSDT': 80, 'BBBUSDT': 75}
    assert ranked[0]['brain_priority_score'] == 86.25


def test_insufficient_samples_cannot_change_priority():
    items = [
        {'symbol': 'AAAUSDT', 'score': 80, 'brain_prediction': {'pattern_learning': {
            'weight': 0.75, 'directional_calls': 19}}},
        {'symbol': 'BBBUSDT', 'score': 75, 'brain_prediction': {'pattern_learning': {
            'weight': 1.15, 'directional_calls': 2}}},
    ]
    ranked = _apply_brain_priority(items)
    assert [x['symbol'] for x in ranked] == ['AAAUSDT', 'BBBUSDT']
    assert all(x['brain_priority_weight'] == 1.0 for x in ranked)


def test_missing_feedback_is_neutral_and_external_weight_is_capped():
    items = [
        {'symbol': 'AAAUSDT', 'score': 60},
        {'symbol': 'BBBUSDT', 'score': 55, 'brain_prediction': {'pattern_learning': {
            'weight': 99, 'directional_calls': 100}}},
    ]
    ranked = _apply_brain_priority(items)
    assert [x['symbol'] for x in ranked] == ['BBBUSDT', 'AAAUSDT']
    assert ranked[0]['brain_priority_weight'] == 1.15
    assert ranked[1]['brain_priority_weight'] == 1.0
