"""Concurrent PAPER ledger operations: idempotency and quantity invariants."""
from concurrent.futures import ThreadPoolExecutor
import sqlite3

from backend import paper_live


def _seed_trade(tmp_path, monkeypatch):
    db = tmp_path / "stage2k.sqlite3"
    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(db))
    paper_live.init_db(backfill_learning=False)
    with paper_live._connect() as c:
        cur = c.execute(
            """INSERT INTO paper_live_trades(
                opened_at,symbol,market,exchange,requested_exchange,side,quantity,notional,
                reference_entry,entry_fill,entry_fee,stop_price,target_price,status,settings_json,
                timeframe,replay_status,funding_status,execution_costs_json
            ) VALUES(1,'BTCUSDT','spot','binance','binance','LONG',1,100,100,100,0.1,
                     95,110,'OPEN','{}','5m','PENDING','NOT_APPLICABLE','{}')"""
        )
        return db, int(cur.lastrowid)


def test_concurrent_same_partial_exit_key_is_idempotent(tmp_path, monkeypatch):
    db, trade_id = _seed_trade(tmp_path, monkeypatch)
    monkeypatch.setattr(paper_live, "get_quote", lambda *a, **k: {
        "price": 101.0, "exchange": "binance", "timestamp": 1_800_000_000.0
    })

    def invoke(_):
        return paper_live.partial_close_position(
            trade_id, 0.25, idempotency_key="same-request", reason="CONCURRENCY_TEST"
        )

    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(invoke, range(8)))

    assert sum(not r.get("idempotent_replay", False) for r in results) == 1
    assert sum(bool(r.get("idempotent_replay", False)) for r in results) == 7
    with sqlite3.connect(db) as c:
        assert c.execute(
            "SELECT COUNT(*) FROM paper_partial_exits WHERE trade_id=?", (trade_id,)
        ).fetchone()[0] == 1
        assert c.execute(
            "SELECT COALESCE(SUM(quantity),0) FROM paper_partial_exits WHERE trade_id=?", (trade_id,)
        ).fetchone()[0] == 0.25


def test_concurrent_distinct_partial_exits_cannot_overdraw_position(tmp_path, monkeypatch):
    db, trade_id = _seed_trade(tmp_path, monkeypatch)
    monkeypatch.setattr(paper_live, "get_quote", lambda *a, **k: {
        "price": 101.0, "exchange": "binance", "timestamp": 1_800_000_000.0
    })

    def invoke(i):
        try:
            return paper_live.partial_close_position(
                trade_id, 0.7, idempotency_key=f"distinct-{i}", reason="OVERDRAW_TEST"
            )
        except ValueError as exc:
            return {"rejected": str(exc)}

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(invoke, range(2)))

    accepted = [r for r in results if not r.get("rejected")]
    rejected = [r for r in results if r.get("rejected")]
    assert len(accepted) == 1
    assert len(rejected) == 1
    with sqlite3.connect(db) as c:
        total = c.execute(
            "SELECT COALESCE(SUM(quantity),0) FROM paper_partial_exits WHERE trade_id=?", (trade_id,)
        ).fetchone()[0]
    assert total == 0.7
    assert total <= 1.0


def test_entry_idempotency_unique_index_is_enforced(tmp_path, monkeypatch):
    db, _ = _seed_trade(tmp_path, monkeypatch)
    with sqlite3.connect(db) as c:
        c.execute("UPDATE paper_live_trades SET entry_idempotency_key='signal-42' WHERE id=1")
        try:
            c.execute("""INSERT INTO paper_live_trades(
                opened_at,symbol,market,exchange,requested_exchange,side,quantity,notional,
                reference_entry,entry_fill,entry_fee,stop_price,target_price,status,settings_json,
                timeframe,replay_status,funding_status,entry_idempotency_key
            ) VALUES(2,'ETHUSDT','spot','binance','binance','LONG',1,100,100,100,0.1,
                     95,110,'OPEN','{}','5m','PENDING','NOT_APPLICABLE','signal-42')""")
        except sqlite3.IntegrityError:
            pass
        else:
            raise AssertionError("duplicate entry idempotency key was accepted")
