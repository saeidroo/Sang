from __future__ import annotations

import sqlite3

import pytest

from backend import paper_live


def test_database_connection_is_closed_after_context(tmp_path, monkeypatch):
    db = tmp_path / "paper.sqlite3"
    monkeypatch.setattr(paper_live, "_db_path", lambda: db)
    paper_live.init_db()
    with paper_live._connect() as conn:
        conn.execute("SELECT 1")
    with pytest.raises(sqlite3.ProgrammingError, match="closed"):
        conn.execute("SELECT 1")


def test_database_context_rolls_back_on_exception(tmp_path, monkeypatch):
    db = tmp_path / "paper.sqlite3"
    monkeypatch.setattr(paper_live, "_db_path", lambda: db)
    paper_live.init_db()
    with pytest.raises(RuntimeError):
        with paper_live._connect() as conn:
            conn.execute("INSERT INTO paper_live_meta(key,value) VALUES('rollback_probe','1')")
            raise RuntimeError("simulated abrupt failure")
    with sqlite3.connect(db) as conn:
        assert conn.execute("SELECT 1 FROM paper_live_meta WHERE key='rollback_probe'").fetchone() is None


def test_hot_path_indexes_are_created(tmp_path, monkeypatch):
    db = tmp_path / "paper.sqlite3"
    monkeypatch.setattr(paper_live, "_db_path", lambda: db)
    paper_live.init_db()
    with sqlite3.connect(db) as conn:
        names = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='index'")}
    assert {
        "idx_paper_live_open_symbol_market",
        "idx_paper_live_closed_at",
        "idx_paper_live_funding_status",
        "idx_paper_funding_settlement",
        "idx_paper_learning_closed_at",
    } <= names


def test_funding_event_primary_key_prevents_duplicate_settlement(tmp_path, monkeypatch):
    db = tmp_path / "paper.sqlite3"
    monkeypatch.setattr(paper_live, "_db_path", lambda: db)
    paper_live.init_db()
    with sqlite3.connect(db) as conn:
        trade_id = conn.execute("""INSERT INTO paper_live_trades(
            opened_at,symbol,market,exchange,side,quantity,notional,reference_entry,
            entry_fill,entry_fee,stop_price,target_price,settings_json
        ) VALUES(1,'BTCUSDT','perp','binance','LONG',1,100,100,100,0,95,110,'{}')""").lastrowid
        event = (trade_id, 1700000000000, "binance", "BTCUSDT", "LONG", 0.001,
                 100.0, 100.0, "mark_price", -0.1, "test", 1.0)
        conn.execute("""INSERT OR IGNORE INTO paper_funding_events(
            trade_id,settlement_ts_ms,exchange,symbol,side,funding_rate,mark_price,
            event_notional,notional_basis,cashflow,source,created_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", event)
        conn.execute("""INSERT OR IGNORE INTO paper_funding_events(
            trade_id,settlement_ts_ms,exchange,symbol,side,funding_rate,mark_price,
            event_notional,notional_basis,cashflow,source,created_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", event)
        count = conn.execute("SELECT COUNT(*) FROM paper_funding_events WHERE trade_id=?", (trade_id,)).fetchone()[0]
    assert count == 1
