import time
import pytest


def _seed(paper_live, rows):
    paper_live.init_db(backfill_learning=False)
    with paper_live._connect() as c:
        for i, pnl, days, symbol, tf in rows:
            c.execute("""INSERT INTO paper_learning_events
                (trade_id,closed_at,symbol,market,timeframe,exchange,side,exit_reason,outcome,net_pnl,
                 return_pct,duration_seconds,notional,gross_pnl,total_fees,entry_fill,exit_fill,context_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (i,time.time()-days*86400,symbol,'spot',tf,'binance','LONG','TEST',int(pnl>0),pnl,pnl,60,100,pnl,0,100,100,'{}'))


def test_performance_analytics_scopes_and_net_metrics(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB',str(tmp_path/'perf.sqlite3'))
    paper_live._CACHE.clear()
    _seed(paper_live,[(1,10,0,'BTCUSDT','1h'),(2,-4,2,'BTCUSDT','1h'),(3,7,10,'ETHUSDT','4h')])
    all_stats=paper_live.get_performance_analytics(period='all')
    assert all_stats['overall']['trade_count']==3
    assert all_stats['overall']['win_rate_pct']==pytest.approx(66.6666667)
    assert all_stats['overall']['net_pnl_usdt']==pytest.approx(13)
    assert len(all_stats['by_symbol_market_timeframe_side'])==2
    week=paper_live.get_performance_analytics(period='week')
    assert week['overall']['trade_count']==2
    assert week['real_orders_enabled'] is False


def test_invalid_period_rejected(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB',str(tmp_path/'invalid.sqlite3'))
    paper_live._CACHE.clear()
    with pytest.raises(ValueError):
        paper_live.get_performance_analytics(period='quarter')
