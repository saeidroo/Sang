import pandas as pd
import pytest
from backend.market_structure_advanced import analyze_bos_choch


def frame(n=60):
    rows=[]
    for i in range(n):
        c=100 + (i % 8) * 0.7 + i * 0.03
        rows.append({'open':c-0.2,'high':c+0.6,'low':c-0.6,'close':c})
    return pd.DataFrame(rows)


def test_missing_columns_safe_unavailable():
    out=analyze_bos_choch(pd.DataFrame({'close':[1,2,3]}), side='LONG')
    assert out['state']=='UNAVAILABLE' and not out['blocking']


def test_insufficient_history_safe_unavailable():
    out=analyze_bos_choch(frame(8), side='LONG', pivot_width=3)
    assert out['state']=='UNAVAILABLE' and not out['blocking']


def test_invalid_ohlc_rejected_as_invalid_not_blocking():
    d=frame(); d.loc[len(d)-1,'high']=1
    out=analyze_bos_choch(d, side='LONG')
    assert out['state']=='INVALID' and not out['blocking']


def test_side_validation():
    with pytest.raises(ValueError):
        analyze_bos_choch(frame(), side='HOLD')


def test_result_contains_causal_structure_fields():
    out=analyze_bos_choch(frame(), side='LONG')
    assert 'trend' in out and 'events' in out and 'blocking' in out
    assert out['trend'] in {'BULLISH','BEARISH','NEUTRAL'}
