import numpy as np
import pandas as pd

from backend.scout import volume_flow_features, select_pre_pump_candidates, merge_unique_candidates


def _build_frame(*, proxy=False, concentrated=False, already_moved=False):
    n = 160
    close = np.full(n, 100.0, dtype=float)
    # Keep the last hour quiet unless the test explicitly checks extension.
    close[-8:] = np.linspace(100.0, 100.8 if not already_moved else 108.0, 8)
    high = close + 0.40
    low = close - 0.40
    high[-8:] = close[-8:] + 0.20
    low[-8:] = close[-8:] - 0.50
    volume = np.full(n, 100.0, dtype=float)
    volume[-8:-4] = 140.0
    volume[-4:] = 220.0
    if concentrated:
        volume[-4:] = [100.0, 100.0, 100.0, 1600.0]
    data = {
        "high": high, "low": low, "close": close, "volume": volume,
    }
    if not proxy:
        taker = volume * 0.50
        taker[-8:] = volume[-8:] * 0.75
        data["taker_buy_base_volume"] = taker
    return pd.DataFrame(data)


def test_detects_quiet_pre_pump_build_up_with_actual_taker_flow():
    result = volume_flow_features(_build_frame())
    assert result["pre_pump_candidate"] is True
    assert result["pre_pump_grade"] == "exchange_taker"
    assert result["volume_acceleration_ratio"] > 1.1
    assert result["recent_volume_ratio"] > 1.3
    assert result["buy_pressure_change"] >= 0.04
    assert result["pre_pump_score"] >= 60


def test_proxy_flow_is_explicitly_labelled_not_claimed_as_taker_data():
    result = volume_flow_features(_build_frame(proxy=True))
    assert result["pre_pump_grade"] == "candle_proxy"
    assert result["flow_data_quality"] == "proxy_only"
    assert result["flow_mode"] == "candle_signed_volume_proxy"


def test_single_concentrated_volume_bar_does_not_qualify():
    result = volume_flow_features(_build_frame(concentrated=True))
    assert result["pre_pump_candidate"] is False


def test_already_extended_last_hour_is_not_pre_pump():
    result = volume_flow_features(_build_frame(already_moved=True))
    assert result["pre_pump_candidate"] is False


def test_directional_watchlist_keeps_verified_items_and_normalizes_signal_side():
    base = {
        "base": "AAA", "verified": True, "phase": "early", "direction": "up",
        "change_24h": 2.0, "pre_pump_candidate": True,
        "pre_pump_price_change_1h_pct": 0.5, "pre_pump_score": 75.0,
        "relative_strength_score": 80.0, "score": 50.0,
    }
    items = [
        dict(base),
        {**base, "base": "UNVERIFIED", "verified": False},
        {**base, "base": "EXTENDED", "change_24h": 9.0},
        {**base, "base": "BEAR", "direction": "down"},
        {**base, "base": "LOW", "pre_pump_score": 40.0},
    ]
    selected = select_pre_pump_candidates(items)
    assert [x["base"] for x in selected] == ["AAA", "BEAR"]
    assert all(x["direction"] == "up" for x in selected)


def test_pre_pump_watchlist_is_ordered_by_indicator_score_not_main_score():
    a = {"base":"A", "verified":True, "phase":"early", "direction":"up",
         "change_24h":1.0, "pre_pump_candidate":True,
         "pre_pump_price_change_1h_pct":0.2, "pre_pump_score":80, "score":20}
    b = {**a, "base":"B", "pre_pump_score":70, "score":90}
    assert [x["base"] for x in select_pre_pump_candidates([b, a])] == ["A", "B"]


def test_pre_pump_candidates_are_included_in_learning_once_per_symbol():
    pre = {"symbol": "AAAUSDT", "base": "AAA"}
    early = {"symbol": "AAAUSDT", "base": "AAA"}
    alert = {"symbol": "BBBUSDT", "base": "BBB"}
    merged = merge_unique_candidates([pre], [early, alert])
    assert [x["symbol"] for x in merged] == ["AAAUSDT", "BBBUSDT"]
    assert merged[0] is pre


def test_pre_pump_indicator_does_not_modify_main_scout_score():
    candidate = {"base":"AAA", "verified":True, "phase":"early", "direction":"up",
                 "change_24h":1.0, "pre_pump_candidate":True,
                 "pre_pump_price_change_1h_pct":0.5, "pre_pump_score":75.0, "score":46.5}
    selected = select_pre_pump_candidates([candidate])
    assert selected[0]["score"] == 46.5
    assert selected[0]["pre_pump_score"] == 75.0


def test_insufficient_candle_history_returns_no_pre_pump_signal():
    short = _build_frame().iloc[:110].copy()
    result = volume_flow_features(short)
    assert result["pre_pump_candidate"] is False
    assert result["pre_pump_grade"] == "insufficient"
