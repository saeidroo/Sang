import json
import pytest
from backend import witness_server as ws
from backend import witness_ops as ops

@pytest.fixture
def setup_witness(tmp_path):
    priv,pub=tmp_path/'private.pem',tmp_path/'public.pem'
    ws.bootstrap_keys(priv,pub)
    db=tmp_path/'witness.sqlite3'; ws.init_db(db)
    for i in range(4): ws.record_anchor(db,priv,{'backup':i,'digest':str(i)})
    return tmp_path,priv,pub,db

def test_export_verify_checkpoint_and_tamper_detection(setup_witness):
    root,priv,pub,db=setup_witness
    export=root/'receipts.jsonl'
    info=ops.export_receipts(db,pub,export)
    assert info['records']==4
    verified=ops.verify_receipt_export(export,pub)
    assert verified['valid'] and verified['head_sequence']==4
    cp=root/'checkpoint.json'
    ops.create_checkpoint(export,priv,pub,cp)
    assert ops.verify_checkpoint(cp,pub,export)['valid']
    rows=export.read_text().splitlines(); row=json.loads(rows[1]); row['receipt']['anchor_digest']='f'*64
    rows[1]=json.dumps(row); export.write_text('\n'.join(rows)+'\n')
    with pytest.raises(Exception): ops.verify_checkpoint(cp,pub,export)

def test_export_rejects_missing_sequence_or_bad_signature(setup_witness):
    root,priv,pub,db=setup_witness
    with __import__('sqlite3').connect(db) as c:
        c.execute('DROP TRIGGER anchors_no_update')
        c.execute("UPDATE anchors SET signature='bad' WHERE sequence=2")
    with pytest.raises(Exception): ops.export_receipts(db,pub,root/'bad.jsonl')

def test_health_and_restore_from_backup(setup_witness):
    root,priv,pub,db=setup_witness
    assert ops.health_diagnostics(db,pub)['healthy']
    backup=root/'backup.sqlite3'; ws.backup_database(db,backup)
    restored=root/'restored'/'witness.sqlite3'
    result=ops.restore_database(backup,restored,pub)
    assert result['restored'] and ops.health_diagnostics(restored,pub)['healthy']
    with pytest.raises(FileExistsError): ops.restore_database(backup,restored,pub)

def test_health_detects_sequence_gap(setup_witness):
    root,priv,pub,db=setup_witness
    with __import__('sqlite3').connect(db) as c:
        c.execute('DROP TRIGGER anchors_no_delete')
        c.execute('DELETE FROM anchors WHERE sequence=2')
    report=ops.health_diagnostics(db,pub)
    assert not report['healthy']
