from pathlib import Path
import sqlite3
from backend import market_brain as brain


def test_brain_reports_no_archive_without_fabricating_predictions(tmp_path, monkeypatch):
    monkeypatch.setattr(brain, 'HISTORY_DB_PATH', tmp_path / 'missing.sqlite3')
    candidate = {'symbol': 'ABCUSDT'}
    result = brain.predict([candidate], now=2_000_000)
    assert result['status'] == 'no_history_archive'
    assert candidate == {'symbol': 'ABCUSDT'}


def test_brain_uses_archived_candles_and_requires_enough_analogs(tmp_path, monkeypatch):
    db = tmp_path / 'candles.sqlite3'
    con = sqlite3.connect(db)
    con.execute('''CREATE TABLE candles (symbol TEXT, timeframe TEXT, t INTEGER,
        open REAL, high REAL, low REAL, close REAL, volume REAL,
        PRIMARY KEY(symbol,timeframe,t))''')
    # Repeated low-volatility, flat-momentum windows create historical analogs.
    start = 1_700_000_000_000
    rows = []
    for i in range(180):
        price = 100.0 + (i % 3) * 0.02
        rows.append(('ABCUSDT', '1h', start + i * 3_600_000,
                     price, price + 0.2, price - 0.2, price, 1000.0))
    con.executemany('INSERT INTO candles VALUES (?,?,?,?,?,?,?,?)', rows)
    con.commit(); con.close()
    monkeypatch.setattr(brain, 'HISTORY_DB_PATH', db)
    candidate = {'symbol': 'ABCUSDT'}
    result = brain.predict([candidate], now=(start + 180 * 3_600_000) / 1000 + 3600)
    assert result['status'] == 'ok'
    assert candidate['brain_prediction']['status'] in {'historical_analogs', 'few_historical_analogs'}
    if candidate['brain_prediction']['status'] == 'historical_analogs':
        assert candidate['brain_prediction']['analogs'] >= brain.MIN_ANALOGS
        assert candidate['brain_prediction']['horizons']['4h']['up_pct'] is not None


def test_startup_learning_accepts_normalized_hourly_timeframe_aliases(tmp_path, monkeypatch):
    db = tmp_path / 'candles.sqlite3'
    con = sqlite3.connect(db)
    con.execute('''CREATE TABLE candles (symbol TEXT, timeframe TEXT, t INTEGER,
        open REAL, high REAL, low REAL, close REAL, volume REAL,
        PRIMARY KEY(symbol,timeframe,t))''')
    start = 1_700_000_000_000
    rows = []
    for i in range(60):
        price = 100.0 + (i % 2) * 0.01
        rows.append(('ALIASUSDT', '1H', start+i*3_600_000, price, price*1.002,
                     price*.998, price, 1000.0))
    con.executemany('INSERT INTO candles VALUES (?,?,?,?,?,?,?,?)', rows)
    con.commit(); con.close()
    monkeypatch.setattr(brain, 'HISTORY_DB_PATH', db)
    monkeypatch.setattr(brain, 'FEEDBACK_DB_PATH', tmp_path / 'feedback.sqlite3')
    result = brain.learn_historical_extremes(now=1_800_000_000)
    assert result['status'] == 'completed'
    assert result['symbols'] == 1
    assert result['candles'] == 60


def test_startup_learning_reports_missing_candle_schema(tmp_path, monkeypatch):
    db = tmp_path / 'candles.sqlite3'
    con = sqlite3.connect(db)
    con.execute('CREATE TABLE candles (symbol TEXT, timeframe TEXT)')
    con.commit(); con.close()
    monkeypatch.setattr(brain, 'HISTORY_DB_PATH', db)
    monkeypatch.setattr(brain, 'FEEDBACK_DB_PATH', tmp_path / 'feedback.sqlite3')
    result = brain.learn_historical_extremes(now=1_800_000_000)
    assert result['status'] == 'error'
    assert 'ساختار جدول candles ناقص است' in result['error']


def test_startup_learning_includes_uncheckpointed_wal_in_cache_fingerprint(tmp_path, monkeypatch):
    """New archived candles in WAL must invalidate the historical-learning cache."""
    db = tmp_path / 'wal_candles.sqlite3'
    writer = sqlite3.connect(db)
    writer.execute('PRAGMA journal_mode=WAL')
    writer.execute('PRAGMA wal_autocheckpoint=0')
    writer.execute('''CREATE TABLE candles (symbol TEXT, timeframe TEXT, t INTEGER,
        open REAL, high REAL, low REAL, close REAL, volume REAL,
        PRIMARY KEY(symbol,timeframe,t))''')
    start = 1_700_000_000_000
    flat = [('WALUSDT', '1h', start + i * 3_600_000,
             100.0, 100.2, 99.8, 100.0, 1000.0) for i in range(30)]
    writer.executemany('INSERT INTO candles VALUES (?,?,?,?,?,?,?,?)', flat)
    writer.commit()
    monkeypatch.setattr(brain, 'HISTORY_DB_PATH', db)
    monkeypatch.setattr(brain, 'FEEDBACK_DB_PATH', tmp_path / 'feedback.sqlite3')

    first = brain.learn_historical_extremes(now=1_800_000_000)
    assert first['status'] == 'completed'
    assert first['candles'] == 30
    assert first['pump_events'] == 0

    main_before = db.stat()
    wal_path = Path(str(db) + '-wal')
    wal_before = wal_path.stat()
    rising = []
    for i in range(30, 55):
        price = 100.0 + (20.0 * (i - 30) / 24.0)
        rising.append(('WALUSDT', '1h', start + i * 3_600_000,
                       price, price * 1.002, price * 0.998, price, 1000.0))
    writer.executemany('INSERT INTO candles VALUES (?,?,?,?,?,?,?,?)', rising)
    writer.commit()

    main_after = db.stat()
    wal_after = wal_path.stat()
    # Confirm this test genuinely exercises uncheckpointed WAL-only change.
    assert (main_before.st_size, main_before.st_mtime_ns) == (main_after.st_size, main_after.st_mtime_ns)
    assert (wal_before.st_size, wal_before.st_mtime_ns) != (wal_after.st_size, wal_after.st_mtime_ns)

    second = brain.learn_historical_extremes(now=1_800_000_001)
    assert second['status'] == 'completed'
    assert second['cache_hit'] is False
    assert second['candles'] == 55
    assert second['pump_events'] >= 1
    writer.close()


def test_startup_learning_marks_starting_before_thread_is_scheduled(tmp_path, monkeypatch):
    import threading

    starts = []

    class DeferredThread:
        def __init__(self, target, name, daemon):
            self.target = target
            self.name = name
            self.daemon = daemon

        def start(self):
            starts.append(self.name)

    monkeypatch.setattr(threading, 'Thread', DeferredThread)
    monkeypatch.setattr(brain, '_STARTUP_STATE', {**brain._STARTUP_STATE, 'status': 'not_started'})
    assert brain.start_startup_learning() is True
    assert brain._STARTUP_STATE['status'] == 'starting'
    assert brain.start_startup_learning() is False
    assert starts == ['market-brain-history']
