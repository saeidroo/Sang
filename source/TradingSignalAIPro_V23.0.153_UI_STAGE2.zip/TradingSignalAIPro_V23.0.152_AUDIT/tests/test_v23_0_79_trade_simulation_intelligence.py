import pytest
from backend.trade_simulation_intelligence import preview_trade_plans


def test_long_preview_costs_and_risk_are_calculated_without_position():
    r = preview_trade_plans([{'symbol': 'BTCUSDT', 'decision': 'PAPER_BUY_CANDIDATE', 'price': 50000, 'atr': 500}])
    p = r['results'][0]
    assert p['status'] == 'PREVIEW_READY'
    assert p['side'] == 'LONG'
    assert p['stop_loss'] < p['reference_entry'] < p['take_profit']
    assert p['estimated_total_execution_cost_usdt'] > 0
    assert p['creates_position'] is False and r['creates_positions'] is False


def test_short_preview_direction():
    p = preview_trade_plans([{'symbol': 'ETHUSDT', 'decision': 'PAPER_SELL_CANDIDATE', 'price': 2000}])['results'][0]
    assert p['side'] == 'SHORT'
    assert p['take_profit'] < p['reference_entry'] < p['stop_loss']


def test_missing_price_and_non_candidate_are_not_previewed():
    r = preview_trade_plans([{'symbol': 'BTCUSDT', 'decision': 'PAPER_BUY_CANDIDATE'},
                             {'symbol': 'ETHUSDT', 'decision': 'NO_ENTRY', 'price': 2000}])
    assert r['results'][0]['status'] == 'INSUFFICIENT_DATA'
    assert r['results'][1]['status'] == 'NOT_ELIGIBLE'


def test_invalid_capital_rejected():
    with pytest.raises(ValueError):
        preview_trade_plans([], capital_usdt=0)
