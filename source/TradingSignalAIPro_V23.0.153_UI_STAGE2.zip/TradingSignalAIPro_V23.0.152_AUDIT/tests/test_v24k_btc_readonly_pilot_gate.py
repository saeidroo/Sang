import json
import pytest
from backend.btc_live_snapshot import ingest_readonly_live_snapshot
from backend.btc_live_drift_monitor import evaluate_live_drift
from backend.btc_readonly_pilot_gate import evaluate_readonly_pilot_gate, append_readonly_pilot_evidence
from tests.test_v24i_btc_live_snapshot import _report


def test_readonly_pilot_requires_all_checks_and_manual_approval(tmp_path):
    report=_report()
    ingestion=ingest_readonly_live_snapshot(report,store_root=tmp_path/'store')
    drift=evaluate_live_drift(live_report={'status':'PASS','latest_age_hours':1},
        reconciliation_report={'status':'PASS','revision_count':0,'removed_count':0,'added_count':3})
    blocked=evaluate_readonly_pilot_gate(live_report={'status':'PASS','read_only':True},
        ingestion_result=ingestion,drift_alert=drift,operator_approved=False)
    assert blocked['status']=='BLOCKED'
    ready=evaluate_readonly_pilot_gate(live_report={'status':'PASS','read_only':True},
        ingestion_result=ingestion,drift_alert=drift,operator_approved=True)
    assert ready['status']=='READY_READONLY_PILOT'
    assert ready['training_allowed'] is False and ready['live_orders'] is False
    result=append_readonly_pilot_evidence(ready,log_path=tmp_path/'pilot'/'evidence.jsonl')
    assert result['status']=='READY_READONLY_PILOT'


def test_readonly_pilot_blocks_drift_and_tampered_evidence(tmp_path):
    report=_report(); ingestion=ingest_readonly_live_snapshot(report,store_root=tmp_path/'store')
    drift=evaluate_live_drift(reconciliation_report={'status':'BLOCKED','revision_count':1,'removed_count':0})
    gate=evaluate_readonly_pilot_gate(live_report={'status':'PASS','read_only':True},
        ingestion_result=ingestion,drift_alert=drift,operator_approved=True)
    assert gate['status']=='BLOCKED'
    gate['status']='READY_READONLY_PILOT'
    with pytest.raises(ValueError,match='hash_mismatch'):
        append_readonly_pilot_evidence(gate,log_path=tmp_path/'bad.jsonl')
