from backend.liquidity_sweep_intelligence import analyze_liquidity_sweeps


def flat_rows(n=10):
    return [{'open': 100, 'high': 102, 'low': 98, 'close': 100, 'volume': 1000}
            for _ in range(n)]


def test_equal_high_pool_and_bearish_sweep_detected():
    rows = flat_rows()
    rows[2]['high'] = 105
    rows[5]['high'] = 105.05
    rows[-1].update(open=104, high=106, low=101, close=104, volume=1800)
    r = analyze_liquidity_sweeps([{'symbol': 'ETHUSDT', 'candles': rows}])['results'][0]
    assert r['decision'] == 'WATCH_BEARISH_SWEEP'
    assert r['sweep_type'] == 'BUY_SIDE'
    assert r['evidence']['buy_side_liquidity_swept'] is True


def test_equal_low_pool_and_bullish_sweep_detected():
    rows = flat_rows()
    rows[2]['low'] = 95
    rows[5]['low'] = 95.05
    rows[-1].update(open=96, high=101, low=94, close=96, volume=1700)
    r = analyze_liquidity_sweeps([{'symbol': 'BTCUSDT', 'candles': rows}])['results'][0]
    assert r['decision'] == 'WATCH_BULLISH_SWEEP'
    assert r['sweep_type'] == 'SELL_SIDE'


def test_breakout_close_is_not_mislabelled_as_sweep():
    rows = flat_rows()
    rows[2]['high'] = 105
    rows[5]['high'] = 105.05
    rows[-1].update(open=104, high=107, low=103, close=106)
    r = analyze_liquidity_sweeps([{'symbol': 'X', 'candles': rows}])['results'][0]
    assert r['decision'] == 'NO_SWEEP_EVIDENCE'


def test_invalid_or_short_candles_are_safe():
    r = analyze_liquidity_sweeps([{'symbol': 'X', 'candles': flat_rows(3)}])
    assert r['results'][0]['decision'] == 'INSUFFICIENT_DATA'


def test_never_authorizes_execution():
    rows = flat_rows()
    rows[2]['high'] = 105
    rows[5]['high'] = 105.05
    rows[-1].update(high=106, close=104)
    r = analyze_liquidity_sweeps([{'symbol': 'X', 'candles': rows}])
    assert r['real_orders_enabled'] is False
    assert r['results'][0]['entry_authorized'] is False
    assert r['results'][0]['execution_authorized'] is False
