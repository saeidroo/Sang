#!/usr/bin/env python3
"""
End-to-end test for the ML pipeline.
Generates synthetic OHLCV data, runs the full training pipeline,
and verifies that:
- indicators compute without NaN/inf blow-ups
- features build to expected shape
- the ensemble trains and predicts
- the model can be saved and loaded back
- the signal engine produces sane output
"""
__test__ = False  # This is an executable smoke-test script, not pytest fixture tests.

import sys
import numpy as np
import pandas as pd
from pathlib import Path

HERE = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(HERE))

from backend.indicators import all_indicators
from backend.features import build_features
from backend.model import TradingEnsemble
from backend.trainer import HP_GRID, walk_forward_eval, temporal_split
from backend.signal import compute_signal
from backend.storage import model_path, save_meta, load_meta, get_models_dir


def make_synthetic_candles(n=1500, seed=42):
    """Build synthetic OHLCV with trend + noise + regime changes."""
    rng = np.random.default_rng(seed)
    returns = np.zeros(n)
    # Regime switches
    regimes = []
    cur = 0
    for i in range(n):
        if i % 200 == 0:
            cur = rng.choice([-1, 0, 1]) * 0.0015
        regimes.append(cur)
    # Add noise + occasional jumps
    noise = rng.normal(0, 0.012, n)
    jumps = (rng.random(n) < 0.02) * rng.normal(0, 0.05, n)
    returns = np.array(regimes) + noise + jumps
    closes = 100 * np.exp(np.cumsum(returns))
    opens = closes * (1 + rng.normal(0, 0.002, n))
    highs = np.maximum(opens, closes) * (1 + np.abs(rng.normal(0, 0.004, n)))
    lows = np.minimum(opens, closes) * (1 - np.abs(rng.normal(0, 0.004, n)))
    volumes = rng.lognormal(10, 1, n)
    ts = (np.arange(n) * 3600 * 1000).astype(int) + 1700000000000
    return pd.DataFrame({
        't': ts, 'open': opens, 'high': highs,
        'low': lows, 'close': closes, 'volume': volumes,
    })


def step_indicators(df):
    print("1. محاسبه‌ی ۲۵+ اندیکاتور...")
    ind = all_indicators(df)
    n_cols = len(ind.columns)
    n_nan = int(ind.isna().sum().sum())
    print(f"   ✓ {n_cols} ستون اندیکاتور ساخته شد")
    print(f"   ✓ مجموع NaN (در دوره‌ی گرم): {n_nan}")
    assert n_cols >= 50, f"اندیکاتورها کافی نیستند: {n_cols}"
    # Check last row has minimal NaN
    last = ind.iloc[-1]
    nan_last = int(last.isna().sum())
    print(f"   ✓ سطر آخر: {nan_last} NaN")
    assert nan_last < 10, f"تعداد NaN در سطر آخر زیاد: {nan_last}"
    return ind


def step_features(df):
    print("2. ساخت ۱۲۰+ ویژگی...")
    (features, y, raw_ret, last_row, ind_train,
     features_full, ind_full, y_raw, raw_ret_full, amb_full) = build_features(df)
    print(f"   ✓ شکل: {features.shape} ({features.shape[1]} ویژگی)")
    assert features.shape[1] >= 60, f"ویژگی‌ها کافی نیستند: {features.shape[1]}"
    print(f"   ✓ نمونه‌های آموزش: {len(features)} (از {len(features_full)} کل، فیلتر نویز)")
    print(f"   ✓ نمونه‌های مبهم (TP و SL هم‌زمان): {int(amb_full.sum())} حذف شد")
    print(f"   ✓ توزیع کلاس: up={int(y.sum())} ({y.mean()*100:.1f}%)")
    n_inf = int(np.isinf(features.values).sum())
    print(f"   ✓ مقادیر inf: {n_inf}")
    assert n_inf == 0
    return features, y, raw_ret, last_row, ind_full


def step_train(features, y):
    print("3. آموزش مدل ensemble...")
    X_tr, y_tr, X_val, y_val, X_te, y_te = temporal_split(features, y)
    print(f"   آموزش: {len(X_tr)} | اعتبارسنجی: {len(X_val)} | تست: {len(X_te)}")
    m = TradingEnsemble()
    m.fit(X_tr, y_tr, X_val=X_val, y_val=y_val, params=HP_GRID[0])
    print(f"   ✓ مدل‌ها آموزش دیدند: {list(m.models.keys())}")
    print(f"   ✓ وزن‌ها: {m.weights}")
    train_ev = m.evaluate(X_tr, y_tr)
    test_ev = m.evaluate(X_te, y_te)
    print(f"   ✓ دقت آموزش: {train_ev['accuracy']*100:.2f}%")
    print(f"   ✓ دقت تست: {test_ev['accuracy']*100:.2f}%")
    print(f"   ✓ balanced: {test_ev['balanced_acc']*100:.2f}%")
    print(f"   ✓ دقت اطمینان-بالا: {test_ev['high_conf_acc']*100:.2f}% "
          f"({test_ev['high_conf_cov']*100:.0f}% پوشش)")
    return m, test_ev


def step_walk_forward(features, y):
    print("4. آزمون walk-forward...")
    wf = walk_forward_eval(features, y, HP_GRID[0], n_folds=3)
    print(f"   ✓ دقت walk-forward: {wf*100:.2f}%")
    return wf


def step_save_load(m, symbol='TESTUSDT', tf='1h'):
    print("5. ذخیره/بارگذاری مدل...")
    mp = model_path(symbol, tf)
    m.save(mp)
    print(f"   ✓ ذخیره شد: {mp}")
    print(f"   ✓ اندازه: {mp.stat().st_size / 1024:.1f} KB")
    m2 = TradingEnsemble.load(mp)
    assert m2 is not None, "بارگذاری ناموفق"
    assert m2.is_fitted
    # Verify predict works
    sample = m.feature_names
    X = pd.DataFrame({k: [0.1] for k in sample})
    p1 = float(m.predict_proba(X))
    p2 = float(m2.predict_proba(X))
    print(f"   ✓ پیش‌بینی اصلی: {p1:.4f}")
    print(f"   ✓ پیش‌بینی بارگذاری‌شده: {p2:.4f}")
    assert abs(p1 - p2) < 0.001, "اختلاف پیش‌بینی زیاد"
    save_meta(symbol, tf, {
        'val_acc': 0.55, 'walk_forward_acc': 0.52,
        'train_samples': 1000, 'feature_count': len(m.feature_names),
        'iterations': 5, 'training_time_sec': 12.5,
        'data_points': 1500,
    })
    meta = load_meta(symbol, tf)
    print(f"   ✓ متادیتا: {meta.get('symbol')} {meta.get('timeframe')} acc={meta.get('val_acc')}")
    return mp


def step_signal(ind, prob=0.62):
    print("6. موتور سیگنال...")
    sig = compute_signal(ind, prob, threshold=0.6)
    print(f"   ✓ سیگنال: {sig['kind']}")
    print(f"   ✓ قدرت: {sig['power']*100:.0f}%")
    print(f"   ✓ ورود: {sig['entry']:.2f} | TP: {sig['tp']:.2f} | SL: {sig['sl']:.2f}")
    print(f"   ✓ دلایل: {len(sig['reasons'])}")
    assert sig['kind'] in ['BUY', 'SELL', 'HOLD']
    return sig


def main():
    print("=" * 60)
    print("  Trading Signal AI Pro — تست ML Pipeline")
    print("=" * 60)
    print()
    print(f"  پوشه‌ی مدل‌ها: {get_models_dir()}")
    print()

    df = make_synthetic_candles(1500)
    print(f"✓ داده‌ی مصنوعی: {len(df)} کندل")
    print()

    ind = step_indicators(df)
    print()
    features, y, raw_ret, last_row, ind2 = step_features(df)
    print()
    model, test_ev = step_train(features, y)
    print()
    wf = step_walk_forward(features, y)
    print()
    mp = step_save_load(model)
    print()
    sig = step_signal(ind2, prob=float(model.predict_proba(features.iloc[[-1]][model.feature_names])))
    print()

    print("=" * 60)
    print("  ✅ همه‌ی تست‌ها موفق بودند!")
    print("=" * 60)
    print()
    print(f"  خلاصه:")
    print(f"  • اندیکاتورها: {len(ind.columns)} ستون")
    print(f"  • ویژگی‌ها: {features.shape[1]}")
    print(f"  • دقت تست: {test_ev['accuracy']*100:.2f}%")
    print(f"  • دقت walk-forward: {wf*100:.2f}%")
    print(f"  • مدل ذخیره شد: {mp}")
    print(f"  • سیگنال نهایی: {sig['kind']}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
