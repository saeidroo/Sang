from backend import market_overview as market


def test_market_overview_uses_fallback_for_crypto(monkeypatch):
    market._CACHE.update(at=0, data=None)
    calls = []
    def yahoo(symbol):
        calls.append(('yahoo', symbol))
        if symbol in ('BTC-USD', 'ETH-USD'):
            raise RuntimeError('provider down')
        return {'price': 2300.0, 'change_pct': -0.5, 'source': 'Yahoo Finance',
                'currency': 'USD', 'as_of': 1}
    def cg(coin):
        calls.append(('coingecko', coin))
        return {'price': 50000.0, 'change_pct': 1.25, 'source': 'CoinGecko',
                'currency': 'USD', 'as_of': 1}
    monkeypatch.setattr(market, '_yahoo', yahoo)
    monkeypatch.setattr(market, '_coingecko', cg)
    result = market.get_market_overview(force=True)
    assert [x['id'] for x in result['items']] == ['BTC', 'ETH', 'GOLD', 'OIL']
    assert result['items'][0]['source'] == 'CoinGecko'
    assert result['items'][1]['source'] == 'CoinGecko'
    assert result['items'][2]['source'] == 'Yahoo Finance'
    assert result['items'][3]['status'] == 'ok'


def test_market_overview_reports_unavailable_without_fake_values(monkeypatch):
    market._CACHE.update(at=0, data=None)
    monkeypatch.setattr(market, '_yahoo', lambda symbol: (_ for _ in ()).throw(RuntimeError('offline')))
    monkeypatch.setattr(market, '_coingecko', lambda coin: (_ for _ in ()).throw(RuntimeError('offline')))
    result = market.get_market_overview(force=True)
    assert all(x['status'] == 'unavailable' for x in result['items'])
    assert all('price' not in x and 'change_pct' not in x for x in result['items'])
