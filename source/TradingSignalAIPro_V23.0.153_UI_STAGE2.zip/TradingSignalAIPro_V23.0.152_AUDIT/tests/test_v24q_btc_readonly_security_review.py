import json
import pytest
from backend.btc_readonly_security_review import (evaluate_readonly_security_review,
    record_readonly_operator_acceptance, MODULES)


def _project(tmp):
    root=tmp/'project'
    for rel in MODULES:
        p=root/rel; p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text('READ_ONLY = True\nURL = "https://example.test"\n')
    return root


def test_static_readonly_review_and_acceptance(tmp_path):
    root=_project(tmp_path)
    report=evaluate_readonly_security_review(project_root=root)
    assert report['status']=='PASS' and report['modules_reviewed']==len(MODULES)
    result=record_readonly_operator_acceptance(report,decision='ACCEPT_READONLY',output_path=tmp_path/'accept.json')
    assert result['saved'] and result['decision']=='ACCEPT_READONLY'
    acceptance=json.loads((tmp_path/'accept.json').read_text())
    assert acceptance['training_allowed'] is False and acceptance['live_orders'] is False


def test_security_review_blocks_order_endpoint_and_acceptance(tmp_path):
    root=_project(tmp_path)
    (root/MODULES[0]).write_text('client.create_order(symbol="BTCUSDT")\n')
    report=evaluate_readonly_security_review(project_root=root)
    assert report['status']=='BLOCKED'
    with pytest.raises(ValueError,match='review_blocked'):
        record_readonly_operator_acceptance(report,decision='ACCEPT_READONLY',output_path=tmp_path/'bad.json')


def test_security_review_rejects_tampered_report(tmp_path):
    report=evaluate_readonly_security_review(project_root=_project(tmp_path))
    report['status']='BLOCKED'
    with pytest.raises(ValueError,match='hash_mismatch'):
        record_readonly_operator_acceptance(report,decision='REJECT',output_path=tmp_path/'reject.json')
