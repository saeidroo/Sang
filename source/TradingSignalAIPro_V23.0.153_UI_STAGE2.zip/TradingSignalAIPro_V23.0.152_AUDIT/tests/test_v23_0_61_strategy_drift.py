import json
from backend.strategy_drift import detect_strategy_drift


def make(pnl, i, regime='BULLISH'):
    return {'symbol':'BTCUSDT','market':'perp','timeframe':'1h','side':'LONG',
            'net_pnl':pnl,'closed_at':f'2026-01-{i:02d}T00:00:00Z','trade_id':f'{i:03d}',
            'context_json':json.dumps({'strategy':'alpha','market_regime':regime,'volatility_regime':'LOW'})}


def test_detects_recent_deterioration_chronologically():
    rows=[make(2,i) for i in range(1,21)] + [make(-2,i) for i in range(21,31)]
    r=detect_strategy_drift(rows,min_baseline=10,min_recent=5,recent_fraction=.30)
    c=r['cohorts'][0]
    assert c['state'] in {'SEVERE_DRIFT','DRIFT_DETECTED'}
    assert c['baseline_end'] < c['recent_start']
    assert c['baseline']['expectancy_usdt'] > 0 > c['recent']['expectancy_usdt']
    assert r['future_data_used_for_past'] is False
    assert r['authorizes_entries'] is False and r['real_orders_enabled'] is False


def test_no_clear_drift_for_consistent_positive_results():
    r=detect_strategy_drift([make(1,i) for i in range(1,31)],min_baseline=10,min_recent=5)
    assert r['cohorts'][0]['state']=='NO_CLEAR_DRIFT'


def test_small_sample_and_contexts_are_separated():
    rows=[make(1,i) for i in range(1,8)] + [make(-1,i,'BEARISH') for i in range(8,15)]
    r=detect_strategy_drift(rows,min_baseline=10,min_recent=5)
    assert len(r['cohorts']) == 2
    assert all(x['state']=='INSUFFICIENT_DATA' for x in r['cohorts'])
    assert r['paper_only'] is True


def test_invalid_parameters_rejected():
    try:
        detect_strategy_drift([],recent_fraction=.8)
    except ValueError:
        pass
    else:
        raise AssertionError('invalid recent_fraction must fail')
