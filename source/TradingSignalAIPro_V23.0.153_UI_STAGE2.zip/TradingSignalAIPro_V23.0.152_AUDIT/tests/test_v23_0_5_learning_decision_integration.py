"""V23.0.5: closed paper outcomes inform later AutoPilot decisions."""
import json
import sqlite3

import pytest

from backend import autopilot, paper_live


@pytest.fixture(autouse=True)
def isolated_paper_learning(tmp_path, monkeypatch):
    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(tmp_path / "paper_live.sqlite3"))
    monkeypatch.setenv("TRADING_AI_MODELS_DIR", str(tmp_path / "models"))
    paper_live._CACHE.clear()
    paper_live.init_db()


def _gate(state="NO_DATA", samples=0, avg_return=None, pf=None, win_rate=None):
    return {
        "symbol": "BTCUSDT", "market": "spot", "timeframe": "1h", "side": "LONG",
        "learning_state": state, "sample_count": samples, "avg_net_return_pct": avg_return,
        "profit_factor": pf, "win_rate_pct": win_rate,
        "paper_evidence_available": state == "PAPER_EVIDENCE_ONLY",
        "live_execution_allowed": False,
    }


def test_learning_no_data_allows_reduced_risk_and_builds_context(monkeypatch):
    raw = {
        "kind": "BUY", "brain": "tech", "confidence": 0.8,
        "feature_snapshot": {"rsi_14": 57.0, "ema_21": 101.0, "atr_pct": 1.2},
        "detail": "trend up",
    }
    monkeypatch.setattr(autopilot, "_decide_entry_raw", lambda *_: raw)
    monkeypatch.setattr(paper_live, "get_learning_gate", lambda *args: _gate())

    decision = autopilot._decide_entry("BTCUSDT", "spot")

    assert decision["kind"] == "BUY"
    assert decision["learning_gate"]["risk_scale"] == pytest.approx(0.5)
    assert decision["decision_context"]["technical"]["rsi_14"] == 57.0
    assert decision["decision_context"]["learning"]["learning_state"] == "NO_DATA"


def test_no_edge_profile_blocks_only_the_exact_candidate(monkeypatch):
    monkeypatch.setattr(autopilot, "_decide_entry_raw", lambda *_: {
        "kind": "BUY", "brain": "tech", "confidence": 0.9, "detail": "candidate"
    })
    monkeypatch.setattr(paper_live, "get_learning_gate", lambda *args: _gate(
        "NO_EDGE", samples=34, avg_return=-0.42, pf=0.81, win_rate=42.0
    ))

    decision = autopilot._decide_entry("BTCUSDT", "spot")

    assert decision["kind"] == "HOLD"
    assert decision["learning_blocked"] is True
    assert "34" in decision["detail"]


def test_negative_small_sample_reduces_risk_more_without_premature_block(monkeypatch):
    monkeypatch.setattr(autopilot, "_decide_entry_raw", lambda *_: {
        "kind": "BUY", "brain": "ml", "confidence": 0.88,
        "ml_snapshot": {"prob": 0.82, "indicators": {"rsi_14": 61.0}},
        "edge_confirmed": True,
    })
    monkeypatch.setattr(paper_live, "get_learning_gate", lambda *args: _gate(
        "COLLECTING", samples=12, avg_return=-0.08, pf=0.9, win_rate=45.0
    ))

    decision = autopilot._decide_entry("BTCUSDT", "spot")

    assert decision["kind"] == "BUY"
    assert decision["learning_gate"]["risk_scale"] == pytest.approx(0.25)
    assert decision["decision_context"]["model"]["indicators"]["rsi_14"] == 61.0


def test_mature_positive_profile_uses_configured_paper_risk(monkeypatch):
    monkeypatch.setattr(autopilot, "_decide_entry_raw", lambda *_: {
        "kind": "BUY", "brain": "hybrid", "confidence": 0.91,
        "technical_snapshot": {"rsi_14": 58.0},
    })
    monkeypatch.setattr(paper_live, "get_learning_gate", lambda *args: _gate(
        "PAPER_EVIDENCE_ONLY", samples=65, avg_return=0.22, pf=1.42, win_rate=61.5
    ))

    decision = autopilot._decide_entry("BTCUSDT", "spot")

    assert decision["learning_gate"]["risk_scale"] == pytest.approx(1.0)
    assert decision["learning_context"]["entry_policy"] == "PAPER_EVIDENCE"


def test_learning_gate_failure_is_fail_closed(monkeypatch):
    monkeypatch.setattr(autopilot, "_decide_entry_raw", lambda *_: {
        "kind": "BUY", "brain": "tech", "confidence": 0.8
    })
    def fail(*args):
        raise RuntimeError("database unavailable")
    monkeypatch.setattr(paper_live, "get_learning_gate", fail)

    decision = autopilot._decide_entry("BTCUSDT", "spot")

    assert decision["kind"] == "HOLD"
    assert decision["learning_blocked"] is True


def test_learning_context_is_persisted_in_closed_trade_event(monkeypatch):
    prices = iter([100.0, 102.0])
    monkeypatch.setattr(paper_live, "get_quote", lambda *a, **k: {
        "symbol": "BTCUSDT", "market": "spot", "exchange": "binance",
        "price": next(prices), "timestamp": "2026-11-19T00:00:00+00:00",
        "source": "public_rest_ticker", "authenticated": False,
    })
    context = {
        "schema_version": "paper-entry-context-v1",
        "decision": {"kind": "BUY", "brain": "hybrid", "confidence": 0.81},
        "technical": {"rsi_14": 59.2},
        "learning": {"learning_state": "COLLECTING", "sample_count": 3, "risk_scale": 0.5},
    }
    opened = paper_live.open_position(
        "BTCUSDT", "LONG", "spot", "auto", "1h",
        entry_source="autopilot", decision_context=context,
    )
    paper_live.close_position(opened["id"])

    rows = paper_live.get_learning_export_rows()
    saved = json.loads(rows[0]["context_json"])
    assert saved["decision_context"]["technical"]["rsi_14"] == 59.2
    assert saved["decision_context"]["learning"]["risk_scale"] == 0.5


def test_learning_risk_scale_changes_only_position_sizing_overrides():
    base = {
        "max_open_positions": 5, "max_position_notional_pct": 10.0,
        "risk_per_trade_pct": 1.0, "stop_loss_pct": 1.5,
        "take_profit_pct": 3.0, "max_daily_loss_pct": 3.0,
    }
    scaled = autopilot._apply_learning_risk_scale(base, {"risk_scale": 0.5})
    assert scaled["risk_per_trade_pct"] == pytest.approx(0.5)
    assert scaled["max_position_notional_pct"] == pytest.approx(5.0)
    assert scaled["max_open_positions"] == 5
    assert scaled["stop_loss_pct"] == 1.5


def test_invalid_or_out_of_range_learning_scale_is_rejected():
    with pytest.raises(ValueError):
        autopilot._apply_learning_risk_scale({"risk_per_trade_pct": 1.0}, {"risk_scale": 0.0})


def test_gate_lookup_does_not_rebuild_all_profiles_on_every_symbol_scan(monkeypatch):
    paper_live.init_db()
    calls = {"n": 0}
    def should_not_rebuild(conn):
        calls["n"] += 1
        raise AssertionError("unexpected full history rebuild")
    monkeypatch.setattr(paper_live, "_rebuild_learning_profiles_conn", should_not_rebuild)

    result = paper_live.get_learning_gate("BTCUSDT", "spot", "1h", "LONG")

    assert result["learning_state"] == "NO_DATA"
    assert calls["n"] == 0


def test_learning_gate_live_orders_remain_disabled():
    result = paper_live.get_learning_gate("BTCUSDT", "spot", "1h", "LONG")
    assert result["live_execution_allowed"] is False
    assert result["entry_blocked"] is False
    assert result["risk_scale"] == pytest.approx(0.5)


def test_real_persisted_negative_profile_blocks_next_matching_decision(monkeypatch):
    paper_live.init_db()
    with sqlite3.connect(paper_live._db_path()) as conn:
        for trade_id in range(1, 31):
            conn.execute("""INSERT INTO paper_learning_events(
                trade_id,closed_at,symbol,market,timeframe,exchange,side,exit_reason,outcome,
                net_pnl,return_pct,duration_seconds,notional,gross_pnl,total_fees,entry_fill,exit_fill,context_json
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                trade_id, float(trade_id), "BTCUSDT", "spot", "1h", "binance", "LONG", "STOP_LOSS",
                0, -1.0, -1.0, 300.0, 100.0, -0.8, 0.2, 100.0, 99.0, "{}"
            ))
    paper_live.rebuild_learning()
    monkeypatch.setattr(autopilot, "_decide_entry_raw", lambda *_: {
        "kind": "BUY", "brain": "tech", "confidence": 0.9, "detail": "candidate"
    })

    decision = autopilot._decide_entry("BTCUSDT", "spot")

    assert decision["kind"] == "HOLD"
    assert decision["learning_gate"]["learning_state"] == "NO_EDGE"
    assert decision["learning_gate"]["sample_count"] == 30


def test_full_entry_feature_vector_survives_learning_event_sanitization(monkeypatch):
    prices = iter([100.0, 101.0])
    monkeypatch.setattr(paper_live, "get_quote", lambda *a, **k: {
        "symbol": "BTCUSDT", "market": "spot", "exchange": "binance",
        "price": next(prices), "timestamp": "2026-11-19T00:00:00+00:00",
        "source": "public_rest_ticker", "authenticated": False,
    })
    vector = {f"feature_{index:03d}": index / 10.0 for index in range(120)}
    opened = paper_live.open_position(
        "BTCUSDT", "LONG", "spot", "auto", "1h",
        entry_source="autopilot",
        decision_context={"model": {"features": vector}},
    )
    paper_live.close_position(opened["id"])
    saved_context = json.loads(paper_live.get_learning_export_rows()[0]["context_json"])
    saved_vector = saved_context["decision_context"]["model"]["features"]
    assert len(saved_vector) == 120
    assert saved_vector["feature_119"] == pytest.approx(11.9)


def test_ml_signal_captures_entry_time_model_and_feature_lineage(monkeypatch):
    import sys
    import types
    from unittest.mock import Mock

    fake_api = types.ModuleType("backend.api")
    fake_api._run_analysis = lambda *args, **kwargs: ({
        "signal": {"kind": "BUY", "prob": 0.82, "power": 0.8},
        "model_meta": {"edge_confirmed": True, "feature_schema_version": 6,
                       "experiment_id": "exp-123", "data_hash": "abc"},
        "has_model": True,
        "indicators": {"rsi_14": 61.0},
        "latest_features": {"ema_gap": 0.12, "rsi_scaled": 0.61},
        "model_feature_names": ["ema_gap", "rsi_scaled"],
        "data_quality": {"status": "PASS", "gap_count": 0},
    }, 200)
    monkeypatch.setitem(sys.modules, "backend.api", fake_api)
    fake_model_path = Mock()
    fake_model_path.exists.return_value = True
    monkeypatch.setattr("backend.storage.model_path", lambda *args: fake_model_path)
    monkeypatch.setattr(autopilot, "_last_candle_ts", lambda *args: 1234.0)

    result = autopilot._ml_signal("BTCUSDT", "spot", "1h")

    assert result["kind"] == "BUY"
    assert result["ml_snapshot"]["features"] == {"ema_gap": 0.12, "rsi_scaled": 0.61}
    assert result["ml_snapshot"]["model"]["feature_schema_version"] == 6
    assert result["ml_snapshot"]["data_quality"]["status"] == "PASS"
