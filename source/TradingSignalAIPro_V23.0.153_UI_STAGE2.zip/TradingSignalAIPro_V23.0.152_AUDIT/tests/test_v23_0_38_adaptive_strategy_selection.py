import time


def _seed(module, rows):
    module.init_db(backfill_learning=False)
    with module._connect() as conn:
        for trade_id, symbol, pnl in rows:
            conn.execute("""INSERT INTO paper_learning_events
                (trade_id,closed_at,symbol,market,timeframe,exchange,side,exit_reason,outcome,net_pnl,
                 return_pct,duration_seconds,notional,gross_pnl,total_fees,entry_fill,exit_fill,context_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (trade_id, time.time(), symbol, 'spot', '1h', 'binance', 'LONG', 'TEST',
                 int(pnl > 0), pnl, pnl, 60, 100, pnl, 0, 100, 100, '{}'))


def test_adaptation_is_bounded_and_rewards_stronger_observed_scope(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'adaptive.sqlite3'))
    paper_live._CACHE.clear()
    rows = []
    for i in range(6):
        rows.append((i + 1, 'BTCUSDT', 10.0))
        rows.append((i + 101, 'ETHUSDT', -10.0))
    _seed(paper_live, rows)
    result = paper_live.get_strategy_entry_adjustments(min_trades=5)
    adjustments = result['adjustments']
    btc = adjustments[('BTCUSDT', 'spot', '1h', 'LONG')]
    eth = adjustments[('ETHUSDT', 'spot', '1h', 'LONG')]
    assert btc['multiplier'] > 1.0
    assert eth['multiplier'] < 1.0
    assert 0.8 <= btc['multiplier'] <= 1.2
    assert 0.8 <= eth['multiplier'] <= 1.2
    assert result['read_only'] is True
    assert result['real_orders_enabled'] is False


def test_no_history_is_neutral_and_small_sample_is_shrunk(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'neutral.sqlite3'))
    paper_live._CACHE.clear()
    empty = paper_live.get_strategy_entry_adjustments()
    assert empty['adjustments'] == {}
    _seed(paper_live, [(1, 'BTCUSDT', 100.0)])
    result = paper_live.get_strategy_entry_adjustments(min_trades=5)
    row = result['adjustments'][('BTCUSDT', 'spot', '1h', 'LONG')]
    assert row['eligible'] is False
    assert abs(row['multiplier'] - 1.0) < 0.05
    assert row['status'] == 'نمونه کم؛ اثر محدود'
