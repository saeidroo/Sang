"""Independent-process SQLite contention tests for PAPER partial exits."""
import multiprocessing as mp
import os
import sqlite3
import time


def _worker(db_path, trade_id, quantity, key, barrier, queue):
    os.environ["TRADING_AI_PAPER_LIVE_DB"] = str(db_path)
    from backend import paper_live

    paper_live.get_quote = lambda *a, **k: {
        "price": 101.0, "exchange": "binance", "timestamp": time.time()
    }
    try:
        barrier.wait(timeout=10)
        result = paper_live.partial_close_position(
            trade_id, quantity, idempotency_key=key, reason="MULTIPROCESS_TEST"
        )
        queue.put({"ok": True, "replay": bool(result.get("idempotent_replay"))})
    except Exception as exc:
        queue.put({"ok": False, "error": type(exc).__name__, "message": str(exc)})


def _seed(path):
    os.environ["TRADING_AI_PAPER_LIVE_DB"] = str(path)
    from backend import paper_live
    paper_live.init_db(backfill_learning=False)
    with paper_live._connect() as c:
        cur = c.execute(
            """INSERT INTO paper_live_trades(
                opened_at,symbol,market,exchange,requested_exchange,side,quantity,notional,
                reference_entry,entry_fill,entry_fee,stop_price,target_price,status,settings_json,
                timeframe,replay_status,funding_status,execution_costs_json
            ) VALUES(1,'BTCUSDT','spot','binance','binance','LONG',1,100,100,100,0.1,
                     95,110,'OPEN','{}','5m','PENDING','NOT_APPLICABLE','{}')"""
        )
        return int(cur.lastrowid)


def _run_workers(path, trade_id, specs):
    ctx = mp.get_context("spawn")
    barrier = ctx.Barrier(len(specs))
    queue = ctx.Queue()
    workers = [ctx.Process(target=_worker, args=(path, trade_id, q, key, barrier, queue))
               for q, key in specs]
    for p in workers:
        p.start()
    results = [queue.get(timeout=20) for _ in workers]
    for p in workers:
        p.join(20)
        assert p.exitcode == 0
    return results


def test_two_processes_same_idempotency_key_record_once(tmp_path):
    db = tmp_path / "multiprocess_same_key.sqlite3"
    trade_id = _seed(db)
    results = _run_workers(db, trade_id, [(0.25, "same-key"), (0.25, "same-key")])
    assert all(r["ok"] for r in results), results
    assert sum(not r["replay"] for r in results) == 1
    assert sum(r["replay"] for r in results) == 1
    with sqlite3.connect(db) as c:
        assert c.execute("SELECT COUNT(*) FROM paper_partial_exits WHERE trade_id=?", (trade_id,)).fetchone()[0] == 1
        assert c.execute("SELECT SUM(quantity) FROM paper_partial_exits WHERE trade_id=?", (trade_id,)).fetchone()[0] == 0.25


def test_two_processes_distinct_keys_cannot_overdraw(tmp_path):
    db = tmp_path / "multiprocess_overdraw.sqlite3"
    trade_id = _seed(db)
    results = _run_workers(db, trade_id, [(0.7, "process-a"), (0.7, "process-b")])
    assert sum(bool(r["ok"]) for r in results) == 1, results
    assert sum(not r["ok"] for r in results) == 1, results
    with sqlite3.connect(db) as c:
        total = c.execute("SELECT COALESCE(SUM(quantity),0) FROM paper_partial_exits WHERE trade_id=?", (trade_id,)).fetchone()[0]
    assert total == 0.7
    assert total <= 1.0
