# -*- coding: utf-8 -*-
"""Regression tests for V23.0.1 fail-closed AutoPilot decision policy."""
from pathlib import Path
from unittest.mock import patch, Mock

from backend import autopilot
import sys
import types
import backend
import pytest


@pytest.fixture(autouse=True)
def _isolated_api_stub(monkeypatch):
    """Stub the lazy API dependency only inside this module's individual tests.

    A module-level sys.modules assignment poisoned later API tests during the
    same pytest process. monkeypatch restores both references after each test.
    """
    api_module = types.ModuleType("backend.api")
    api_module._run_analysis = lambda *args, **kwargs: ({"error": "not mocked"}, 500)
    monkeypatch.setitem(sys.modules, "backend.api", api_module)
    monkeypatch.setattr(backend, "api", api_module, raising=False)
    yield


def test_perp_never_borrows_spot_model():
    fake_path = Mock()
    fake_path.exists.return_value = True
    payload = {
        "signal": {"kind": "BUY", "prob": 0.82, "power": 0.8},
        "model_meta": {"edge_confirmed": True},
        "has_model": True,
    }
    with patch("backend.storage.model_path", return_value=fake_path) as model_path_mock, \
         patch("backend.api._run_analysis", return_value=(payload, 200)) as run_mock, \
         patch.object(autopilot, "_last_candle_ts", return_value=123.0):
        got = autopilot._ml_signal("BTCUSDT", "perp", "1h")
    assert model_path_mock.call_args.args == ("BTCUSDTPERP", "1h")
    assert run_mock.call_args.args[0] == "BTCUSDTPERP"
    assert got["model_symbol"] == "BTCUSDTPERP"
    assert got["edge_confirmed"] is True


def test_missing_edge_confirmation_defaults_to_false():
    fake_path = Mock()
    fake_path.exists.return_value = True
    payload = {"signal": {"kind": "BUY", "prob": 0.9}, "has_model": True}
    with patch("backend.storage.model_path", return_value=fake_path), \
         patch("backend.api._run_analysis", return_value=(payload, 200)), \
         patch.object(autopilot, "_last_candle_ts", return_value=123.0):
        got = autopilot._ml_signal("BTCUSDT", "spot", "1h")
    assert got["edge_confirmed"] is False


def test_ml_pipeline_error_is_not_treated_as_missing_model():
    fake_path = Mock()
    fake_path.exists.return_value = True
    with patch("backend.storage.model_path", return_value=fake_path), \
         patch("backend.api._run_analysis", return_value=({"error": "model load failed"}, 500)):
        got = autopilot._ml_signal("BTCUSDT", "spot", "1h")
    assert got is not None
    assert got["kind"] == "UNAVAILABLE"


def test_hybrid_explicit_ml_hold_stops_before_technical_fallback():
    with patch.object(autopilot, "_ml_signal", return_value={
        "kind": "HOLD", "confidence": 0.95, "edge_confirmed": False,
        "brain": "ml", "detail": "test hold"
    }), patch.object(autopilot, "_tech_signal") as tech:
        result = autopilot._decide_entry("BTCUSDT", "spot")
    assert result["kind"] == "HOLD"
    tech.assert_not_called()


def test_hybrid_requires_same_direction_and_edge_approval():
    ml = {"kind": "BUY", "confidence": 0.9, "edge_confirmed": True,
          "brain": "ml", "detail": "approved"}
    tech_sell = {"kind": "SELL", "confidence": 0.9, "brain": "tech", "detail": "opposite"}
    with patch.object(autopilot, "_ml_signal", return_value=ml), \
         patch.object(autopilot, "_tech_signal", return_value=tech_sell):
        result = autopilot._decide_entry("BTCUSDT", "spot")
    assert result["kind"] == "HOLD"
    assert "عدم توافق" in result["detail"]

    tech_buy = {"kind": "BUY", "confidence": 0.8, "brain": "tech", "detail": "aligned"}
    with patch.object(autopilot, "_ml_signal", return_value=ml), \
         patch.object(autopilot, "_tech_signal", return_value=tech_buy):
        result = autopilot._decide_entry("BTCUSDT", "spot")
    assert result["kind"] == "BUY"
    assert result["brain"] == "hybrid"
    assert result["confidence"] == 0.8


def test_hybrid_pipeline_error_does_not_fall_back():
    with patch.object(autopilot, "_ml_signal", return_value={
        "kind": "UNAVAILABLE", "confidence": None, "edge_confirmed": False,
        "brain": "ml", "detail": "pipeline error"
    }), patch.object(autopilot, "_tech_signal") as tech:
        result = autopilot._decide_entry("BTCUSDT", "spot")
    assert result["kind"] == "HOLD"
    tech.assert_not_called()


def test_technical_fallback_only_when_exact_market_model_is_absent():
    tech_buy = {"kind": "BUY", "confidence": 0.8, "brain": "tech", "detail": "uptrend"}
    with patch.object(autopilot, "_ml_signal", return_value=None), \
         patch.object(autopilot, "_tech_signal", return_value=tech_buy):
        result = autopilot._decide_entry("BTCUSDT", "perp")
    assert result["kind"] == "BUY"
    assert result["fallback_reason"] == "market_model_missing"


def test_ml_only_requires_edge_approval():
    old = autopilot._CONFIG.get("brain_mode")
    try:
        autopilot._CONFIG["brain_mode"] = "ml_only"
        with patch.object(autopilot, "_ml_signal", return_value={
            "kind": "BUY", "confidence": 0.95, "edge_confirmed": False,
            "brain": "ml", "detail": "not approved"
        }):
            result = autopilot._decide_entry("BTCUSDT", "spot")
        assert result["kind"] == "HOLD"
    finally:
        autopilot._CONFIG["brain_mode"] = old
