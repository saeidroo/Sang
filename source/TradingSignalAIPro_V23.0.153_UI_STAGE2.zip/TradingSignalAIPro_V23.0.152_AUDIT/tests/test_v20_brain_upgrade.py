"""V20 part-6 tests: learning-brain upgrade (central-brain-v4).

Covers:
  * pool consensus as the 14th brain evidence stream (bounded weight)
  * recent_form — bounded caution factor from matured outcomes (damping only)
  * brain_track_records — feedback-weighted pool vote quality
  * trainer.brain_feedback_summary — closed learning loop
  * model.calibration_report — ECE/Brier honesty report
"""
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend import brain, consensus  # noqa: E402
from backend.features import FEATURE_SCHEMA_VERSION  # noqa: E402
from backend.brain import (BASE_WEIGHTS, FORM_FACTOR_MIN, build_component_scores,  # noqa: E402
                           make_brain_decision, pool_consensus_vote,
                           recent_form)


# ---------------------------------------------------------------- helpers
def _indicator_frame(n=120, rising=True):
    close = np.linspace(100, 135, n) if rising else np.linspace(135, 100, n)
    frame = pd.DataFrame({
        't': np.arange(n, dtype=np.int64) * 3_600_000 + 1_700_000_000_000,
        'close': close,
        'ema_20': pd.Series(close).ewm(span=20, adjust=False).mean(),
        'ema_50': pd.Series(close).ewm(span=50, adjust=False).mean(),
        'macd_hist': np.full(n, 0.2 if rising else -0.2),
        'plus_di': np.full(n, 30.0 if rising else 10.0),
        'minus_di': np.full(n, 10.0 if rising else 30.0),
        'cmf_20': np.full(n, 0.12 if rising else -0.12),
        'supertrend': close - 1 if rising else close + 1,
        'adx_14': np.full(n, 28.0),
    })
    return frame


POOL_UP = {'n': 5, 'consensus_prob': 0.72, 'consensus_dir': 'UP',
           'agreement': 0.80, 'edge_share': 0.6, 'votes': []}
POOL_DOWN = {'n': 4, 'consensus_prob': 0.35, 'consensus_dir': 'DOWN',
             'agreement': 0.70, 'edge_share': 0.5, 'votes': []}


def _seed_matured(symbol, timeframe, entries):
    """Insert matured brain observations directly (bar_ts, scores, realized)."""
    with brain._connection() as conn:
        for bar_ts, scores, ret in entries:
            conn.execute(
                '''INSERT OR REPLACE INTO brain_observations
                   (symbol,timeframe,bar_ts,entry_price,components_json,
                    realized_return,created_at)
                   VALUES(?,?,?,?,?,?,?)''',
                (symbol, timeframe, int(bar_ts), 100.0,
                 json.dumps(scores, separators=(',', ':')), float(ret), time.time()))


def _spaced_entries(count, scores, ret, step_hours=50):
    base = 1_700_000_000_000
    return [(base - i * step_hours * 3_600_000, dict(scores), ret)
            for i in range(count)]


@pytest.fixture
def brain_db(tmp_path, monkeypatch):
    monkeypatch.setenv('TS_AI_BRAIN_DB', str(tmp_path / 'brain.sqlite3'))
    yield tmp_path


# ---------------------------------------------------------------- pool vote
def test_v20_weights_sum_to_one():
    assert abs(sum(BASE_WEIGHTS.values()) - 1.0) < 1e-9
    assert BASE_WEIGHTS['pool'] == 0.05
    assert BASE_WEIGHTS['pool'] < BASE_WEIGHTS['ml'] * 0.25, \
        'pool must stay far smaller than the primary ML channel'


def test_pool_consensus_vote_scaled_by_agreement():
    score, meta = pool_consensus_vote(POOL_UP)
    assert meta['available'] and score > 0
    assert score == pytest.approx((0.72 - 0.5) * 2 * 0.80, abs=1e-6)
    s2, _ = pool_consensus_vote({'n': 5, 'consensus_prob': 0.72,
                                 'agreement': 0.30})
    assert 0 < s2 < score, 'weak agreement must vote weaker'


def test_pool_consensus_vote_unavailable_without_votes():
    score, meta = pool_consensus_vote(None)
    assert score == 0.0 and not meta['available']
    score, meta = pool_consensus_vote({'n': 0, 'consensus_prob': None})
    assert score == 0.0 and not meta['available']
    score, meta = pool_consensus_vote({'n': 3, 'consensus_prob': float('nan')})
    assert score == 0.0 and not meta['available']


def test_build_component_scores_includes_pool():
    comps, meta = build_component_scores(
        0.8, _indicator_frame(), {'regime': 'bull', 'confidence': .8},
        [], [], {'available': False}, {'error': 'x'},
        {'fear_greed': {'value': 50}}, None, None, pool=POOL_UP)
    assert comps['pool']['available'] is True
    assert comps['pool']['score'] > 0
    assert meta['pool']['n'] == 5
    # and without a pool nothing changes except the pool stream
    comps2, _ = build_component_scores(
        0.8, _indicator_frame(), {'regime': 'bull', 'confidence': .8},
        [], [], {'available': False}, {'error': 'x'},
        {'fear_greed': {'value': 50}}, None, None)
    assert comps2['pool']['available'] is False
    for key in ('ml', 'technical', 'regime'):
        assert comps2[key]['score'] == comps[key]['score']


def test_brain_v4_end_to_end_with_pool(brain_db):
    base = {'kind': 'BUY', 'reason': 'base', 'power': 0.6, 'meta_blocked': False}
    result = make_brain_decision(
        symbol='BTCUSDT', timeframe='1h', bar_ts=1_700_000_000_000,
        price=100.0, model_prob=0.75, indicators=_indicator_frame(),
        regime={'regime': 'bull', 'confidence': 0.7}, edge_confirmed=True,
        base_signal=base, pool=POOL_UP)
    assert result['version'] == 'central-brain-v4'
    assert 'pool' in result['components']
    assert result['components']['pool']['available'] is True
    assert result['components']['pool']['base_weight'] == 0.05
    assert 'recent_form' in result
    assert result['recent_form']['factor'] == 1.0  # empty ledger -> untouched


def test_base_hold_never_promoted_even_with_strong_pool(brain_db):
    base = {'kind': 'HOLD', 'reason': 'base hold', 'power': 0.2,
            'meta_blocked': False}
    make_brain_decision(
        symbol='BTCUSDT', timeframe='1h', bar_ts=1_700_000_000_000,
        price=100.0, model_prob=0.5, indicators=_indicator_frame(),
        edge_confirmed=False, base_signal=base,
        pool={'n': 8, 'consensus_prob': 0.95, 'agreement': 1.0})
    assert base['kind'] == 'HOLD', 'brain must never promote a base HOLD'


# ---------------------------------------------------------------- recent form
def test_recent_form_bad_form_damps(brain_db):
    _seed_matured('AAAUSDT', '1h', _spaced_entries(12, {'technical': 0.8}, -0.02))
    form = recent_form('AAAUSDT', '1h')
    assert form['available'] is True
    assert form['hit_rate'] == 0.0
    assert FORM_FACTOR_MIN <= form['factor'] < 1.0
    assert form['factor'] == pytest.approx(FORM_FACTOR_MIN, abs=0.01)


def test_recent_form_good_form_no_damping(brain_db):
    _seed_matured('BBBUSDT', '1h', _spaced_entries(12, {'technical': 0.8}, +0.02))
    form = recent_form('BBBUSDT', '1h')
    assert form['available'] is True
    assert form['hit_rate'] == 1.0
    assert form['factor'] == 1.0


def test_recent_form_insufficient_samples(brain_db):
    _seed_matured('CCCUSDT', '1h', _spaced_entries(5, {'technical': 0.8}, -0.02))
    form = recent_form('CCCUSDT', '1h')
    assert form['available'] is False
    assert form['factor'] == 1.0
    assert form['matured'] == 5


def test_recent_form_spacing_counts_one_per_horizon(brain_db):
    # 30 observations packed inside ONE 12-bar horizon window -> only 1 counts
    base = 1_700_000_000_000
    step = 24 * 60_000  # 24 minutes apart: 30 bars span ~11.6h < 12h horizon
    entries = [(base - i * step, {'technical': 0.8}, +0.02)
               for i in range(30)]
    _seed_matured('DDDUSDT', '1h', entries)
    form = recent_form('DDDUSDT', '1h')
    assert form['available'] is False, 'spacing rule must prevent inflated form'
    assert form['matured'] == 1


def test_recent_form_damps_score_but_not_sign(brain_db):
    # same decision with and without a bad-form ledger
    def _decide():
        base = {'kind': 'BUY', 'reason': 'base', 'power': 0.6,
                'meta_blocked': False}
        res = make_brain_decision(
            symbol='EEEUSDT', timeframe='1h', bar_ts=1_700_000_000_000,
            price=100.0, model_prob=0.72, indicators=_indicator_frame(),
            regime={'regime': 'bull', 'confidence': 0.7},
            edge_confirmed=True, base_signal=base, pool=POOL_UP)
        return res['score']

    clean_score = _decide()
    _seed_matured('EEEUSDT', '1h', _spaced_entries(12, {'pool': 0.9}, -0.02))
    damped_score = _decide()
    assert damped_score < clean_score, 'bad form must damp the consensus'
    assert np.sign(damped_score) == np.sign(clean_score) > 0, \
        'damping must never flip the sign'
    assert clean_score - damped_score <= clean_score * (1 - FORM_FACTOR_MIN) + 0.02


# ------------------------------------------------------- brain track records
def test_brain_track_records_good_bad_and_unknown(brain_db):
    _seed_matured('GOODUSDT', '1h', _spaced_entries(24, {'ml': 0.8}, +0.02))
    _seed_matured('BADUSDT', '1h', _spaced_entries(24, {'ml': 0.8}, -0.02))
    tracks = consensus.brain_track_records(
        [('GOODUSDT', '1h'), ('BADUSDT', '1h'), ('NONEUSDT', '1h')])
    assert tracks[('GOODUSDT', '1h')] > 1.0
    assert tracks[('BADUSDT', '1h')] == pytest.approx(consensus.BRAIN_MULT_MIN)
    assert tracks[('NONEUSDT', '1h')] == 1.0


def test_brain_track_records_ignores_small_ml_scores(brain_db):
    # scores below the 0.15 conviction floor must not build a track record
    _seed_matured('WEAKUSDT', '1h', _spaced_entries(24, {'ml': 0.05}, +0.02))
    tracks = consensus.brain_track_records([('WEAKUSDT', '1h')])
    assert tracks[('WEAKUSDT', '1h')] == 1.0


def test_brain_track_records_never_raises(brain_db, monkeypatch):
    monkeypatch.setattr(consensus, '_connection_missing_guard', True,
                        raising=False)
    # corrupt rows must be skipped silently
    _seed_matured('CORRUSDT', '1h', [(1_700_000_000_000, 'not-json', 0.01),
                                     (1_700_010_000_000, {'ml': 'x'}, 0.01)])
    tracks = consensus.brain_track_records([('CORRUSDT', '1h')])
    assert tracks[('CORRUSDT', '1h')] == 1.0


def test_consensus_quality_applies_brain_mult():
    meta = {'walk_forward_acc': 0.62, 'edge_confirmed': True}
    q1 = consensus._quality(meta)
    q_up = consensus._quality(meta, brain_mult=1.15)
    q_dn = consensus._quality(meta, brain_mult=0.85)
    assert q_up > q1 > q_dn
    assert 0.30 <= q_dn and q_up <= 1.0


def test_list_pool_candidates_have_brain_mult(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(tmp_path))
    monkeypatch.setenv('TS_AI_BRAIN_DB', str(tmp_path / 'brain.sqlite3'))
    consensus._CACHE.clear()
    (tmp_path / 'model_ETHUSDT_4h.joblib').write_bytes(b'x')
    meta = {'walk_forward_acc': 0.62, 'edge_confirmed': True,
            'feature_schema_version': FEATURE_SCHEMA_VERSION, 'symbol': 'ETHUSDT', 'timeframe': '4h'}
    (tmp_path / 'meta_ETHUSDT_4h.json').write_text(json.dumps(meta), encoding='utf-8')
    cands = consensus.list_pool_candidates('BTCUSDT', '1h')
    assert len(cands) == 1
    assert cands[0]['brain_mult'] == 1.0  # empty ledger -> neutral
    assert cands[0]['quality'] == pytest.approx(
        consensus._quality(meta), abs=1e-6)


# --------------------------------------------------------- trainer feedback
def test_brain_feedback_summary_closed_loop(brain_db):
    from backend.trainer import brain_feedback_summary
    assert brain_feedback_summary('NOPEUSDT', '1h') is None
    _seed_matured('FEEDUSDT', '1h', _spaced_entries(14, {'ml': 0.7}, +0.03))
    summary = brain_feedback_summary('FEEDUSDT', '1h')
    assert summary is not None
    assert summary['samples'] >= 10
    assert summary['hit_rate'] == 1.0
    assert 'weight_multiplier' in summary
    # below the sample floor -> None
    _seed_matured('TINYUSDT', '1h', _spaced_entries(4, {'ml': 0.7}, +0.03))
    assert brain_feedback_summary('TINYUSDT', '1h') is None


def test_brain_feedback_summary_fail_soft(monkeypatch, tmp_path):
    from backend.trainer import brain_feedback_summary
    monkeypatch.setenv('TS_AI_BRAIN_DB', str(tmp_path / 'no' / 'dir' / 'b.sqlite3'))
    assert brain_feedback_summary('X', '1h') is None


# ------------------------------------------------------ calibration report
def test_calibration_report_keys_and_bounds():
    from backend.model import TradingEnsemble
    rng = np.random.default_rng(7)
    n = 700
    X = pd.DataFrame(rng.normal(size=(n, 8)), columns=[f'f{i}' for i in range(8)])
    y = pd.Series((X['f0'] + rng.normal(scale=0.5, size=n) > 0).astype(int))
    cut = int(n * 0.7)
    params = {
        'random_forest': {'n_estimators': 10, 'max_depth': 3},
        'extra_trees': {'n_estimators': 10, 'max_depth': 3},
        'hist_gb': {'max_iter': 10},
        'neural_net': {'max_iter': 30, 'hidden': (8,)},
    }
    if not TradingEnsemble().models:  # pragma: no cover
        pass
    ens = TradingEnsemble()
    ens.fit(X.iloc[:cut], y.iloc[:cut], params=params)
    report = ens.calibration_report(X.iloc[cut:], y.iloc[cut:])
    assert {'ece', 'brier', 'buckets', 'n'} <= set(report)
    assert 0.0 <= report['ece'] <= 1.0
    assert 0.0 <= report['brier'] <= 1.0
    assert report['n'] == n - cut
    assert report['buckets'], 'at least one populated probability bucket'
    total = sum(b['n'] for b in report['buckets'])
    assert total == report['n']
    for b in report['buckets']:
        assert 0.0 <= b['hit_rate'] <= 1.0
        assert 0.0 <= b['mean_prob'] <= 1.0
        assert b['n'] > 0


def test_calibration_report_perfectly_calibrated_low_ece():
    """A constant-honest predictor (prob == true rate) must have tiny ECE."""
    from backend.model import TradingEnsemble
    rng = np.random.default_rng(11)
    n = 4000
    p = np.full(n, 0.70)
    y = (rng.random(n) < 0.70).astype(int)
    X = pd.DataFrame(rng.normal(size=(n, 4)), columns=[f'f{i}' for i in range(4)])
    ens = TradingEnsemble()
    ens.models = {'random_forest': _HonestStub(p)}
    ens.weights = {'random_forest': 1.0}
    ens.feature_names = list(X.columns)
    ens.is_fitted = True
    report = ens.calibration_report(X, y, n_bins=10)
    assert report['ece'] <= 0.05, f'ECE must be tiny for honest probs, got {report["ece"]}'


class _HonestStub:
    """Estimator stub returning a constant P(up) independent of X."""
    def __init__(self, p_arr):
        self._p = np.asarray(p_arr, dtype=float)

    def predict_proba(self, X):
        p = np.clip(self._p[:len(X)], 1e-6, 1 - 1e-6)
        return np.column_stack([1 - p, p])
