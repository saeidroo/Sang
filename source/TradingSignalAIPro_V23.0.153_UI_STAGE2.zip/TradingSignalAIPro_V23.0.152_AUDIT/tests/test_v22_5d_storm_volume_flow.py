import numpy as np
import pandas as pd
from backend.scout import volume_flow_features, candle_features


def frame(kind='neutral', n=180):
    rng = np.random.default_rng(7)
    close = 100 + np.cumsum(rng.normal(0, .08, n))
    high, low = close + .2, close - .2
    volume = np.full(n, 1000.0)
    if kind in ('buy', 'sell', 'spike'):
        for i in range(8):
            idx = n - 8 + i
            volume[idx] = 1500
            if kind == 'buy':
                close[idx] = 100.15
                high[idx], low[idx] = 100.2, 99.9
            elif kind == 'sell':
                close[idx] = 99.95
                high[idx], low[idx] = 100.2, 99.8
            else:
                volume[idx] = 1000
                close[idx] = 100.19 if i == 7 else 100.0
                high[idx], low[idx] = 100.2, 99.8
        if kind == 'spike':
            volume[-1] = 10000
    return pd.DataFrame({'high': high, 'low': low, 'close': close, 'volume': volume})


def test_short_history_fails_closed():
    assert volume_flow_features(frame(n=100))['flow_data_quality'] == 'insufficient'


def test_candle_proxy_detects_persistent_buy_pressure():
    x = volume_flow_features(frame('buy'))
    assert x['flow_mode'] == 'candle_signed_volume_proxy'
    assert x['accumulation_proxy']
    assert not x['distribution_proxy']


def test_candle_proxy_detects_persistent_sell_pressure():
    x = volume_flow_features(frame('sell'))
    assert x['distribution_proxy']
    assert not x['accumulation_proxy']


def test_single_volume_spike_does_not_count_as_accumulation():
    x = volume_flow_features(frame('spike'))
    assert not x['accumulation_proxy']
    assert not x['distribution_proxy']


def test_real_taker_buy_field_is_used_when_valid():
    d = frame('buy')
    d['taker_buy_base_volume'] = d['volume'] * .8
    x = volume_flow_features(d)
    assert x['flow_mode'] == 'taker_buy_volume'
    assert x['flow_data_quality'] == 'exchange_taker_field'
    assert x['accumulation_proxy']


def test_invalid_taker_field_fails_closed():
    d = frame('buy')
    d['taker_buy_base_volume'] = d['volume'] * 2
    x = volume_flow_features(d)
    assert x['flow_data_quality'] == 'insufficient'
    assert not x['accumulation_proxy']


def test_candle_features_exposes_flow_diagnostics():
    from backend.scout import candle_features
    x = candle_features(frame('buy'))
    assert x is not None
    assert 'flow_mode' in x and 'flow_persistence' in x
