import pytest
from backend import paper_execution_orchestrator as engine


def candidate(**kw):
    x = {'symbol': 'BTCUSDT', 'decision': 'PAPER_BUY_CANDIDATE', 'score': 82,
         'coverage_pct': 78, 'conflict_ratio': 0.1, 'risk_blockers': [],
         'idempotency_key': 'signal:BTCUSDT:20261119:1h:001', 'timeframe': '1h'}
    x.update(kw)
    return x


def test_execution_requires_explicit_arm_and_never_sends_orders(monkeypatch):
    called = []
    monkeypatch.setattr('backend.paper_live.open_position', lambda **kw: called.append(kw) or {'id': 4})
    result = engine.execute_paper_candidates([candidate()])
    assert result['status'] == 'ARMING_REQUIRED'
    assert called == [] and result['creates_orders'] is False


def test_qualified_candidate_creates_only_paper_position(monkeypatch):
    called = []
    monkeypatch.setattr('backend.paper_live.open_position', lambda **kw: called.append(kw) or {'id': 4})
    result = engine.execute_paper_candidates([candidate()], confirm_paper_execution=True)
    assert result['opened'] == 1
    assert called[0]['side'] == 'LONG'
    assert called[0]['idempotency_key'].startswith('signal:')
    assert result['creates_orders'] is False and result['real_orders_enabled'] is False


def test_risk_blocked_or_low_quality_candidate_rejected(monkeypatch):
    called = []
    monkeypatch.setattr('backend.paper_live.open_position', lambda **kw: called.append(kw) or {'id': 4})
    result = engine.execute_paper_candidates([
        candidate(risk_blockers=['HIGH_RISK_FLAG']),
        candidate(symbol='ETHUSDT', score=60, idempotency_key='signal:ETH:001')
    ], confirm_paper_execution=True)
    assert len(called) == 0
    assert all(x['status'] == 'REJECTED' for x in result['results'])


def test_missing_idempotency_key_rejected(monkeypatch):
    called = []
    monkeypatch.setattr('backend.paper_live.open_position', lambda **kw: called.append(kw) or {'id': 4})
    result = engine.execute_paper_candidates([candidate(idempotency_key='')], confirm_paper_execution=True)
    assert result['results'][0]['reason'] == 'VALID_IDEMPOTENCY_KEY_REQUIRED'
    assert called == []


def test_invalid_candidate_collection_rejected():
    with pytest.raises(ValueError):
        engine.execute_paper_candidates({}, confirm_paper_execution=True)
