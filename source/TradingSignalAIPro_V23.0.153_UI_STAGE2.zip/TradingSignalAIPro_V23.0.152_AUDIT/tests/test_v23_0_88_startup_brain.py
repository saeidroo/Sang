import sqlite3
from backend import market_brain as brain


def test_startup_historical_learning_counts_severe_pump_and_dump(tmp_path, monkeypatch):
    db = tmp_path / 'candles.sqlite3'
    con = sqlite3.connect(db)
    con.execute('''CREATE TABLE candles (symbol TEXT, timeframe TEXT, t INTEGER,
        open REAL, high REAL, low REAL, close REAL, volume REAL,
        PRIMARY KEY(symbol,timeframe,t))''')
    start = 1_700_000_000_000
    rows = []
    # 30 flat candles, then 24h pump; a separate symbol has a 24h dump.
    for symbol, final in [('PUMPUSDT', 120.0), ('DUMPUSDT', 80.0)]:
        for i in range(55):
            price = 100.0 if i < 30 else (final if i >= 54 else 100.0 + (final-100.0)*(i-30)/24)
            rows.append((symbol, '1h', start+i*3_600_000, price, price*1.002,
                         price*.998, price, 1000.0))
    con.executemany('INSERT INTO candles VALUES (?,?,?,?,?,?,?,?)', rows)
    con.commit(); con.close()
    monkeypatch.setattr(brain, 'HISTORY_DB_PATH', db)
    result = brain.learn_historical_extremes(now=1_800_000_000)
    assert result['status'] == 'completed'
    assert result['symbols'] == 2
    assert result['candles'] == 110
    # One sustained move must not be counted once for every overlapping
    # 24-hour look-ahead window. The two directions remain independent.
    assert result['pump_events'] == 1
    assert result['dump_events'] == 1


def test_startup_historical_learning_reports_missing_archive(tmp_path, monkeypatch):
    monkeypatch.setattr(brain, 'HISTORY_DB_PATH', tmp_path / 'missing.sqlite3')
    result = brain.learn_historical_extremes(now=1_800_000_000)
    assert result['status'] == 'no_history_archive'
    assert result['pump_events'] == 0


def test_historical_patterns_are_cached_and_reused_on_restart(tmp_path, monkeypatch):
    db = tmp_path / 'candles.sqlite3'
    con = sqlite3.connect(db)
    con.execute('''CREATE TABLE candles (symbol TEXT, timeframe TEXT, t INTEGER,
        open REAL, high REAL, low REAL, close REAL, volume REAL,
        PRIMARY KEY(symbol,timeframe,t))''')
    start = 1_700_000_000_000
    rows = []
    for i in range(60):
        price = 100.0 if i < 30 else 100.0 + (25.0 * (i-30) / 24)
        rows.append(('PUMPUSDT', '1h', start+i*3_600_000, price, price*1.002,
                     price*.998, price, 1000.0))
    con.executemany('INSERT INTO candles VALUES (?,?,?,?,?,?,?,?)', rows)
    con.commit(); con.close()
    monkeypatch.setattr(brain, 'HISTORY_DB_PATH', db)
    monkeypatch.setattr(brain, 'FEEDBACK_DB_PATH', tmp_path / 'feedback.sqlite3')
    first = brain.learn_historical_extremes(now=1_800_000_000)
    second = brain.learn_historical_extremes(now=1_800_000_001)
    assert first['status'] == 'completed'
    assert first['cache_hit'] is False
    assert second['status'] == 'completed_cached'
    assert second['cache_hit'] is True
    cache = sqlite3.connect(tmp_path / 'feedback.sqlite3')
    assert cache.execute('SELECT COUNT(*) FROM brain_historical_patterns').fetchone()[0] > 0
    cache.close()
