import math
import pytest
from backend import advanced


def test_paper_trade_stop_must_be_on_correct_side(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_PAPER_DB', str(tmp_path / 'paper.sqlite3'))
    with pytest.raises(ValueError):
        advanced.paper_open('BTCUSDT', 'LONG', 1, 100, 101)
    with pytest.raises(ValueError):
        advanced.paper_open('BTCUSDT', 'SHORT', 1, 100, 99)
    opened = advanced.paper_open('BTCUSDT', 'LONG', 1, 100, 95)
    assert opened['status'] == 'OPEN'
    closed = advanced.paper_close(opened['id'], 110)
    assert closed['status'] == 'CLOSED'
    assert closed['pnl'] == 10


def test_paper_trade_rejects_non_finite_values(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_PAPER_DB', str(tmp_path / 'paper.sqlite3'))
    with pytest.raises(ValueError):
        advanced.paper_open('BTCUSDT', 'LONG', math.inf, 100, 90)
    opened = advanced.paper_open('BTCUSDT', 'SHORT', 1, 100, 110)
    with pytest.raises(ValueError):
        advanced.paper_close(opened['id'], math.nan)


def test_risk_plan_rejects_excessive_risk():
    with pytest.raises(ValueError):
        advanced.risk_plan(1000, 6, 100, 90)
