import math
import pytest

from backend.execution_model import DEFAULTS, execution_costs, fill_price


def test_cost_model_includes_half_spread_slippage_and_size_impact():
    costs = execution_costs(2000)
    assert costs['half_spread_bps_per_side'] == 1.0
    assert costs['base_slippage_bps_per_side'] == 5.0
    assert costs['size_impact_bps_per_side'] == 1.0
    assert costs['total_adverse_price_bps_per_side'] == 7.0
    assert costs['is_orderbook_measured'] is False


def test_impact_increases_with_notional_and_is_capped():
    small = execution_costs(100)
    large = execution_costs(10000)
    huge = execution_costs(1_000_000)
    assert small['size_impact_bps_per_side'] < large['size_impact_bps_per_side']
    assert huge['size_impact_bps_per_side'] == DEFAULTS['max_impact_bps_per_side']


@pytest.mark.parametrize('side,action,expected_direction', [
    ('LONG', 'entry', 1), ('LONG', 'exit', -1),
    ('SHORT', 'entry', -1), ('SHORT', 'exit', 1),
])
def test_fills_are_adverse_for_both_sides(side, action, expected_direction):
    costs = execution_costs(1000)
    fill = fill_price(100, side, action, costs)
    assert math.copysign(1, fill - 100) == expected_direction


def test_zero_cost_model_returns_reference_price():
    zero = {key: 0 for key in DEFAULTS}
    costs = execution_costs(1000, zero)
    assert fill_price(123.45, 'LONG', 'entry', costs) == pytest.approx(123.45)
    assert fill_price(123.45, 'SHORT', 'exit', costs) == pytest.approx(123.45)


@pytest.mark.parametrize('notional', [0, -1, float('nan'), float('inf')])
def test_invalid_notional_rejected(notional):
    with pytest.raises(ValueError):
        execution_costs(notional)


def test_negative_cost_rejected():
    with pytest.raises(ValueError):
        execution_costs(1000, {'spread_bps_full': -1})


def test_fill_rejects_invalid_price_and_side():
    costs = execution_costs(1000)
    with pytest.raises(ValueError):
        fill_price(0, 'LONG', 'entry', costs)
    with pytest.raises(ValueError):
        fill_price(100, 'BUY', 'entry', costs)


def test_paper_open_close_persists_cost_snapshot_and_reuses_it(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'paper.sqlite3'))
    paper_live._CACHE.clear()

    def fake_fetch(exchange, symbol, market):
        return {
            'symbol': symbol, 'market': market, 'exchange': exchange,
            'exchange_name': paper_live.EXCHANGE_NAMES[exchange], 'price': 100.0,
            'timestamp': '2026-11-19T00:00:00+00:00', 'authenticated': False,
        }

    monkeypatch.setattr(paper_live, '_fetch_one', fake_fetch)
    opened = paper_live.open_position('BTCUSDT', 'LONG', 'spot', 'auto')
    assert opened['entry_fill'] > opened['reference_entry']
    assert opened['execution_costs']['size_impact_bps_per_side'] > 0

    with paper_live._connect() as conn:
        row = conn.execute('SELECT execution_costs_json FROM paper_live_trades WHERE id=?', (opened['id'],)).fetchone()
    stored = __import__('json').loads(row[0])
    assert stored['model'] == 'deterministic_spread_slippage_size_impact_v1'

    # Changing current global settings after entry must not rewrite this trade's fill model.
    original_fee = paper_live.SETTINGS['fee_bps_per_side']
    paper_live.SETTINGS['fee_bps_per_side'] = 99.0
    try:
        closed = paper_live.close_position(opened['id'])
    finally:
        paper_live.SETTINGS['fee_bps_per_side'] = original_fee
    assert closed['exit_fill'] < closed['reference_exit']
    assert closed['exit_fee'] == pytest.approx(opened['quantity'] * closed['exit_fill'] * stored['fee_bps_per_side'] / 10000)
    assert closed['status'] == 'CLOSED'
