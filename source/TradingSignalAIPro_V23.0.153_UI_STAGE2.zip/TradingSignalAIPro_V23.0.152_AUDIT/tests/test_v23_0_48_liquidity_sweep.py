import pandas as pd
import pytest
from backend.portfolio_risk import detect_liquidity_sweep


def base_frame():
    # Confirmed support at 95, resistance at 105; last row is the sweep candle.
    rows = []
    for i in range(40):
        rows.append({'open': 100.0, 'high': 102.0, 'low': 98.0, 'close': 100.0, 'volume': 1000.0})
    rows[15].update(high=103.0, low=95.0)
    rows[25].update(high=105.0, low=97.0)
    return rows


def test_bullish_support_sweep_detected_for_long():
    rows = base_frame()
    rows[-1].update(open=96.0, high=101.0, low=94.0, close=99.0)
    result = detect_liquidity_sweep(pd.DataFrame(rows), side='LONG', atr_value=2.0, pivot_width=2)
    assert result['state'] == 'SWEEP_RECLAIMED'
    assert result['sweep_type'] == 'BULLISH_SUPPORT_SWEEP'
    assert result['data_policy'] == 'CLOSED_CANDLES_ONLY'


def test_bearish_resistance_sweep_detected_for_short():
    rows = base_frame()
    rows[-1].update(open=104.0, high=106.0, low=99.0, close=101.0)
    result = detect_liquidity_sweep(pd.DataFrame(rows), side='SHORT', atr_value=2.0, pivot_width=2)
    assert result['state'] == 'SWEEP_RECLAIMED'
    assert result['sweep_type'] == 'BEARISH_RESISTANCE_SWEEP'


def test_no_wick_reclaim_means_no_sweep():
    rows = base_frame()
    rows[-1].update(open=100.0, high=102.0, low=98.0, close=100.0)
    result = detect_liquidity_sweep(pd.DataFrame(rows), side='LONG', atr_value=2.0, pivot_width=2)
    assert result['state'] == 'NO_SWEEP'


def test_invalid_side_rejected():
    with pytest.raises(ValueError):
        detect_liquidity_sweep(pd.DataFrame(base_frame()), side='FLAT', atr_value=2.0, pivot_width=2)


def test_missing_ohlc_rejected():
    with pytest.raises(ValueError):
        detect_liquidity_sweep(pd.DataFrame({'close':[100]*20}), side='LONG', atr_value=2.0)
