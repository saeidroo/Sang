import threading

from backend import autopilot


def test_concurrent_start_creates_only_one_entry_worker(monkeypatch):
    release = threading.Event()
    created = []
    results = []
    errors = []

    def worker_target():
        release.wait(2)

    original = dict(autopilot._STATE)
    original_events = {
        "stop_event": autopilot._STATE["stop_event"],
        "entry_stop_event": autopilot._STATE["entry_stop_event"],
        "manager_stop_event": autopilot._STATE["manager_stop_event"],
    }
    monkeypatch.setattr(autopilot, "_load_config", lambda: None)
    monkeypatch.setattr(autopilot, "_save_config", lambda cfg: None)
    monkeypatch.setattr(autopilot, "_start_manager_worker", lambda: None)
    monkeypatch.setattr(autopilot, "_log_decision", lambda *a, **k: None)
    monkeypatch.setattr(autopilot, "status", lambda: {"running": True})

    real_thread = threading.Thread

    def tracked_thread(*args, **kwargs):
        thread = real_thread(*args, **kwargs)
        if kwargs.get("name") == "autopilot-entry-scanner":
            created.append(thread)
        return thread

    monkeypatch.setattr(autopilot.threading, "Thread", tracked_thread)
    try:
        with autopilot._LOCK:
            autopilot._STATE.update({
                "entry_thread": None,
                "manager_thread": None,
                "entry_stop_event": threading.Event(),
                "manager_stop_event": threading.Event(),
                "stop_event": threading.Event(),
                "entries_enabled": False,
                "running": False,
                "started_at": None,
            })
            autopilot._CONFIG = dict(autopilot.DEFAULT_CONFIG)

        barrier = threading.Barrier(3)

        def call_start():
            try:
                barrier.wait()
                results.append(autopilot.start(resume_entries=True))
            except Exception as exc:  # pragma: no cover - assertion reports details
                errors.append(exc)

        # Replace the scanner target before start() constructs its Thread.
        monkeypatch.setattr(autopilot, "_entry_loop", worker_target)
        callers = [real_thread(target=call_start) for _ in range(2)]
        for caller in callers:
            caller.start()
        barrier.wait()
        for caller in callers:
            caller.join(3)

        assert not errors
        assert len(created) == 1
        assert len(results) == 2
        assert sum(bool(item.get("already_running")) for item in results) == 1
        assert created[0].is_alive()
    finally:
        release.set()
        for thread in created:
            thread.join(3)
        with autopilot._LOCK:
            autopilot._STATE.clear()
            autopilot._STATE.update(original)
            autopilot._STATE.update(original_events)


def test_lifecycle_decorator_uses_reentrant_lock():
    assert autopilot._LIFECYCLE_LOCK.acquire(timeout=1)
    try:
        # The RLock permits lifecycle helpers to call one another (stop -> manager start).
        assert autopilot._LIFECYCLE_LOCK.acquire(timeout=1)
        autopilot._LIFECYCLE_LOCK.release()
    finally:
        autopilot._LIFECYCLE_LOCK.release()
