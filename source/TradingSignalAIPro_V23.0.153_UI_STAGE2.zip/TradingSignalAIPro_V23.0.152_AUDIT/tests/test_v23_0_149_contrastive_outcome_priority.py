from backend.scout import _apply_contrastive_outcome_priority


def _report():
    return {
        'baseline': [{'direction': 'up', 'horizon': '24h', 'decisive_samples': 100,
                      'successes': 50, 'failures': 50, 'failure_rate': 0.5}],
        'patterns': [
            {'direction': 'up', 'horizon': '24h', 'phase': 'early', 'market_regime': 'up',
             'score_band': 'high', 'samples': 50, 'successes': 40, 'failures': 10},
            {'direction': 'up', 'horizon': '24h', 'phase': 'breakout', 'market_regime': 'sideways',
             'score_band': 'medium', 'samples': 50, 'successes': 10, 'failures': 40},
        ],
    }


def test_successful_context_gets_positive_rank_adjustment():
    item = {'phase': 'early', 'market_regime': 'up', 'score': 80,
            'directional_priority_score': 70}
    result = _apply_contrastive_outcome_priority([item], 'up', _report())[0]
    assert result['contrastive_outcome_adjustment'] > 0
    assert result['directional_priority_score'] > 70
    assert result['contrastive_outcome_success_lift_pp'] > 0


def test_failed_context_gets_negative_rank_adjustment():
    item = {'phase': 'breakout', 'market_regime': 'sideways', 'score': 55,
            'directional_priority_score': 70}
    result = _apply_contrastive_outcome_priority([item], 'up', _report())[0]
    assert result['contrastive_outcome_adjustment'] < 0
    assert result['directional_priority_score'] < 70
    assert result['contrastive_outcome_success_lift_pp'] < 0


def test_missing_context_and_insufficient_baseline_are_neutral():
    item = {'phase': 'unknown', 'market_regime': 'unknown', 'score': 80,
            'directional_priority_score': 66}
    result = _apply_contrastive_outcome_priority([item], 'up', _report())[0]
    assert result['contrastive_outcome_adjustment'] == 0
    assert result['directional_priority_score'] == 66
    small = {'baseline': [{'direction': 'up', 'horizon': '24h',
                          'decisive_samples': 20, 'failure_rate': .2}], 'patterns': []}
    result = _apply_contrastive_outcome_priority([item], 'up', small)[0]
    assert result['contrastive_outcome_adjustment'] == 0


def test_directional_evidence_does_not_cross():
    item = {'phase': 'early', 'market_regime': 'up', 'score': 80,
            'directional_priority_score': 66}
    result = _apply_contrastive_outcome_priority([item], 'down', _report())[0]
    assert result['contrastive_outcome_adjustment'] == 0
    assert result['directional_priority_score'] == 66


def test_adjustment_is_bounded():
    report = {
        'baseline': [{'direction': 'up', 'horizon': '24h', 'decisive_samples': 100,
                      'failure_rate': .99}],
        'patterns': [{'direction': 'up', 'horizon': '24h', 'phase': 'early',
                      'market_regime': 'up', 'score_band': 'high',
                      'samples': 10000, 'successes': 10000, 'failures': 0}],
    }
    item = {'phase': 'early', 'market_regime': 'up', 'score': 90,
            'directional_priority_score': 50}
    result = _apply_contrastive_outcome_priority([item], 'up', report)[0]
    assert 0 <= result['contrastive_outcome_adjustment'] <= 1.5
