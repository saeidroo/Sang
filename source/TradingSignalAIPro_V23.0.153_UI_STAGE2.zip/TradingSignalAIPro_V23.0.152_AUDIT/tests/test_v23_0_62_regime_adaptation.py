import json
import pytest
from backend.regime_adaptation import build_regime_adaptation_report


def trade(i, pnl, regime='UPTREND', symbol='BTCUSDT', tf='1h', strategy='alpha'):
    return {'symbol': symbol, 'market': 'perp', 'timeframe': tf, 'side': 'LONG',
            'net_pnl': pnl, 'closed_at': f'2026-01-{i:02d}T00:00:00Z',
            'trade_id': str(i), 'context_json': json.dumps({'strategy': strategy,
            'market_regime': regime, 'volatility_regime': 'LOW'})}


def test_regime_transition_and_exact_regime_candidate_only():
    rows = [trade(i, 2, 'UPTREND') for i in range(1, 11)]
    rows += [trade(i, -1, 'DOWNTREND') for i in range(11, 21)]
    r = build_regime_adaptation_report(rows, symbol='BTCUSDT', timeframe='1h',
        previous_regime='UPTREND', current_regime='DOWNTREND', min_trades=5)
    assert r['regime_transition_detected'] is True
    assert r['transition'] == {'from': 'UPTREND', 'to': 'DOWNTREND'}
    assert all(x['market_regime'] == 'DOWNTREND' for x in r['current_regime_strategy_evidence'])
    assert r['recommended_action'] == 'NO_STRATEGY_HAS_SUFFICIENT_POSITIVE_EVIDENCE'
    assert r['cross_regime_fallback'] is False and r['automatic_strategy_switch'] is False


def test_no_data_means_no_strategy_not_fallback():
    r = build_regime_adaptation_report([trade(i, 1, 'UPTREND') for i in range(1, 12)],
        symbol='BTCUSDT', timeframe='1h', current_regime='RANGE')
    assert r['current_regime_strategy_evidence'] == []
    assert r['recommended_action'] == 'NO_STRATEGY_HAS_SUFFICIENT_POSITIVE_EVIDENCE'
    assert r['authorizes_entries'] is False and r['real_orders_enabled'] is False


def test_symbol_and_timeframe_are_isolated():
    rows = [trade(i, 3, 'RANGE', symbol='ETHUSDT') for i in range(1, 12)]
    rows += [trade(i, -2, 'RANGE', tf='15m') for i in range(12, 23)]
    r = build_regime_adaptation_report(rows, symbol='BTCUSDT', timeframe='1h', current_regime='RANGE')
    assert r['matching_closed_trade_count'] == 0


def test_small_sample_is_not_promoted():
    r = build_regime_adaptation_report([trade(i, 5, 'RANGE') for i in range(1, 4)],
        symbol='BTCUSDT', timeframe='1h', current_regime='RANGE', min_trades=8)
    assert r['current_regime_strategy_evidence'][0]['evidence_state'] == 'INSUFFICIENT_DATA'


def test_invalid_regime_rejected():
    with pytest.raises(ValueError):
        build_regime_adaptation_report([], symbol='BTCUSDT', timeframe='1h', current_regime='MAGIC')
