import pytest
from backend.paper_candle_replay import replay_closed_candles

STEP = 60_000

def candle(t, o=100, h=103, l=97, c=101):
    return {"t": t, "open": o, "high": h, "low": l, "close": c}


def test_replays_only_closed_candles_and_advances_cursor():
    rows = [candle(0), candle(STEP), candle(2 * STEP)]
    result = replay_closed_candles(side="LONG", stop_price=95, target_price=110,
        candles=rows, timeframe_seconds=60, now_ms=2 * STEP + 1)
    assert result["processed_count"] == 2
    assert result["last_processed_open_ms"] == STEP
    assert result["exit"] is None


def test_replay_stops_at_first_bracket_touch_and_stop_wins_both_touch():
    rows = [candle(0), candle(STEP, h=112, l=94)]
    result = replay_closed_candles(side="LONG", stop_price=95, target_price=110,
        candles=rows, timeframe_seconds=60, now_ms=3 * STEP)
    assert result["processed_count"] == 2
    assert result["exit"]["reason"] == "STOP_LOSS"
    assert result["exit"]["both_hit"] is True


def test_resume_skips_already_processed_candles():
    result = replay_closed_candles(side="LONG", stop_price=95, target_price=110,
        candles=[candle(2 * STEP)], timeframe_seconds=60,
        last_processed_open_ms=STEP, now_ms=4 * STEP)
    assert result["processed_count"] == 1
    assert result["last_processed_open_ms"] == 2 * STEP


def test_replay_rejects_gap_duplicate_and_reordering():
    base = dict(side="LONG", stop_price=95, target_price=110,
                timeframe_seconds=60, now_ms=10 * STEP)
    with pytest.raises(ValueError, match="candle_gap_detected"):
        replay_closed_candles(candles=[candle(0), candle(2 * STEP)], **base)
    with pytest.raises(ValueError, match="duplicate_or_reordered"):
        replay_closed_candles(candles=[candle(STEP), candle(STEP)], **base)
    with pytest.raises(ValueError, match="duplicate_or_reordered"):
        replay_closed_candles(candles=[candle(2 * STEP), candle(STEP)], **base)


def test_replay_does_not_process_open_candle():
    result = replay_closed_candles(side="LONG", stop_price=95, target_price=110,
        candles=[candle(0), candle(STEP)], timeframe_seconds=60,
        now_ms=STEP + 30_000)
    assert result["processed_count"] == 1
    assert result["last_processed_open_ms"] == 0


def test_replay_rejects_invalid_timeframe_and_ohlc():
    with pytest.raises(ValueError):
        replay_closed_candles(side="LONG", stop_price=95, target_price=110,
            candles=[], timeframe_seconds=0)
    with pytest.raises(ValueError):
        replay_closed_candles(side="LONG", stop_price=95, target_price=110,
            candles=[{**candle(0), "high": 90}], timeframe_seconds=60,
            now_ms=STEP)


def test_replay_time_exit_occurs_on_horizon_candle_close():
    candles = [
        {"t": i * 300_000, "open": 100, "high": 101, "low": 99, "close": 100 + i * 0.01}
        for i in range(12)
    ]
    result = replay_closed_candles(
        side="LONG", stop_price=90, target_price=120, candles=candles,
        timeframe_seconds=300, opened_at_ms=0, now_ms=12 * 300_000,
        horizon_bars=12)
    assert result["processed_count"] == 12
    assert result["exit"]["reason"] == "TIME_EXIT"
    assert result["exit"]["fill_reference"] == candles[-1]["close"]


def test_replay_trailing_state_is_updated_for_next_candle():
    candles = [
        {"t": 0, "open": 100, "high": 103, "low": 99, "close": 102},
        {"t": 300_000, "open": 102, "high": 104, "low": 101.99, "close": 103},
    ]
    result = replay_closed_candles(
        side="LONG", stop_price=90, target_price=120, candles=candles,
        timeframe_seconds=300, opened_at_ms=0, now_ms=600_000,
        trailing_trigger_pct=1.5, trailing_distance_pct=1.0,
        entry_price=100)
    assert result["trailing_active"] is True
    assert result["trailing_peak_price"] == 104
    assert result["stop_price"] == pytest.approx(102.96)


def test_time_horizon_counts_across_separate_replay_batches():
    first_batch = [
        {"t": i * 300_000, "open": 100, "high": 101, "low": 99, "close": 100}
        for i in range(6)
    ]
    first = replay_closed_candles(
        side="LONG", stop_price=90, target_price=120, candles=first_batch,
        timeframe_seconds=300, opened_at_ms=0, now_ms=1_800_000,
        horizon_bars=12)
    assert first["exit"] is None
    second_batch = [
        {"t": i * 300_000, "open": 100, "high": 101, "low": 99, "close": 100}
        for i in range(6, 12)
    ]
    second = replay_closed_candles(
        side="LONG", stop_price=90, target_price=120, candles=second_batch,
        timeframe_seconds=300, last_processed_open_ms=first["last_processed_open_ms"],
        opened_at_ms=0, now_ms=3_600_000, horizon_bars=12)
    assert second["exit"]["reason"] == "TIME_EXIT"


def test_entry_mid_candle_skips_partial_bar_and_starts_next_full_bar():
    result = replay_closed_candles(
        side="LONG", stop_price=95, target_price=110,
        candles=[candle(0), candle(STEP)], timeframe_seconds=60,
        opened_at_ms=30_000, now_ms=2 * STEP)
    assert result["processed_count"] == 1
    assert result["last_processed_open_ms"] == STEP


def test_first_replay_detects_missing_first_post_entry_candle():
    with pytest.raises(ValueError, match="candle_gap_detected"):
        replay_closed_candles(
            side="LONG", stop_price=95, target_price=110,
            candles=[candle(0), candle(2 * STEP)], timeframe_seconds=60,
            opened_at_ms=30_000, now_ms=4 * STEP)
