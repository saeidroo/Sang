from datetime import datetime, timezone, timedelta
import json
import pytest
from backend.btc_live_environment_validation import validate_live_environment
from backend.btc_live_validation_review import (
    verify_live_validation_evidence, review_live_validation_reports,
    verify_live_validation_review, save_live_validation_review,
)

NOW = datetime(2026, 11, 17, 12, 0, tzinfo=timezone.utc)

def fetcher(**kwargs):
    return {'status':'PASS','selected_source':'Binance','fallback_used':False,
        'reconciliation':{'status':'PASS','compared_candles':120,
            'primary_sha256':'a'*64,'backup_sha256':'b'*64},
        'read_only':True,'training_allowed':False,'live_orders':False}

def make_report(at):
    return validate_live_environment(fetcher=fetcher, now_utc=at)

def test_repeated_passes_require_operator_approval():
    reports=[make_report(NOW-timedelta(hours=2)),make_report(NOW-timedelta(hours=1)),make_report(NOW)]
    pending=review_live_validation_reports(reports, now_utc=NOW)
    assert pending['decision']=='REVIEW_REQUIRED'
    accepted=review_live_validation_reports(reports, operator_approved=True, now_utc=NOW)
    assert accepted['decision']=='ACCEPT_READONLY'
    assert verify_live_validation_review(accepted)['valid'] is True
    assert accepted['training_allowed'] is False and accepted['live_orders'] is False

def test_blocked_report_cannot_be_overridden():
    def fail(**kwargs): raise OSError('offline')
    blocked=validate_live_environment(fetcher=fail, now_utc=NOW)
    reports=[make_report(NOW-timedelta(hours=1)), blocked]
    result=review_live_validation_reports(reports, operator_approved=True, now_utc=NOW)
    assert result['decision']=='BLOCKED'

def test_stale_and_future_reports_rejected():
    with pytest.raises(ValueError, match='stale'):
        verify_live_validation_evidence(make_report(NOW-timedelta(days=2)), now_utc=NOW)
    with pytest.raises(ValueError, match='future'):
        verify_live_validation_evidence(make_report(NOW+timedelta(hours=1)), now_utc=NOW)

def test_duplicate_and_out_of_order_reports_rejected():
    one=make_report(NOW-timedelta(hours=1)); two=make_report(NOW)
    with pytest.raises(ValueError, match='duplicate'):
        review_live_validation_reports([one,one], now_utc=NOW)
    with pytest.raises(ValueError, match='chronological'):
        review_live_validation_reports([two,one], now_utc=NOW)

def test_tampered_environment_fingerprint_rejected():
    report=make_report(NOW); report['environment']['platform']='forged'
    with pytest.raises(ValueError, match='hash_mismatch'):
        verify_live_validation_evidence(report, now_utc=NOW)

def test_review_artifact_is_immutable(tmp_path):
    reports=[make_report(NOW-timedelta(hours=2)),make_report(NOW-timedelta(hours=1)),make_report(NOW)]
    review=review_live_validation_reports(reports, operator_approved=True, now_utc=NOW)
    path=tmp_path/'review.json'
    save_live_validation_review(review, output_path=path)
    with pytest.raises(FileExistsError): save_live_validation_review(review, output_path=path)
    assert json.loads(path.read_text())['decision']=='ACCEPT_READONLY'
