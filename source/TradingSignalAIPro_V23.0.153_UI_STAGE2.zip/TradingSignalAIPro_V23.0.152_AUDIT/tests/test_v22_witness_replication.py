import json
import pytest
from pathlib import Path
from backend.witness_server import bootstrap_keys, init_db, record_anchor
from backend.witness_replication import compare_witnesses, replicate_to_secondary


def setup_witness(tmp, name):
    root=Path(tmp)/name; root.mkdir()
    priv=root/'private.pem'; pub=root/'public.pem'; db=root/'w.sqlite'
    bootstrap_keys(priv,pub); init_db(db)
    return db,priv,pub


def test_replication_copies_and_compares_independent_witnesses(tmp_path):
    pdb, ppriv, ppub=setup_witness(tmp_path,'p')
    sdb, spriv, spub=setup_witness(tmp_path,'s')
    for i in range(5): record_anchor(pdb,ppriv,{'event':i,'value':f'x{i}'},witness_id='primary')
    result=replicate_to_secondary(pdb,ppub,sdb,spriv,spub)
    assert result['status']=='synchronized' and result['appended']==5
    assert result['primary_count']==result['secondary_count']==5
    assert compare_witnesses(pdb,ppub,sdb,spub)['consistent']
    assert replicate_to_secondary(pdb,ppub,sdb,spriv,spub)['appended']==0


def test_replication_detects_divergent_prefix(tmp_path):
    pdb,ppriv,ppub=setup_witness(tmp_path,'p')
    sdb,spriv,spub=setup_witness(tmp_path,'s')
    record_anchor(pdb,ppriv,{'event':'A'})
    record_anchor(sdb,spriv,{'event':'B'})
    with pytest.raises(ValueError,match='divergence'):
        replicate_to_secondary(pdb,ppub,sdb,spriv,spub)


def test_replication_rejects_tampered_source_payload(tmp_path):
    pdb,ppriv,ppub=setup_witness(tmp_path,'p')
    sdb,spriv,spub=setup_witness(tmp_path,'s')
    record_anchor(pdb,ppriv,{'event':'A'})
    import sqlite3
    with sqlite3.connect(pdb) as db:
        db.execute('DROP TRIGGER anchors_no_update')
        db.execute("UPDATE anchors SET anchor_json='{}'")
    with pytest.raises(ValueError,match='payload_digest'):
        replicate_to_secondary(pdb,ppub,sdb,spriv,spub)
