import json
import pytest
from pathlib import Path
from backend.witness_server import bootstrap_keys, init_db, record_anchor, create_app
from backend.witness_remote import build_replication_batch
from backend.witness_replication import accept_remote_entries, compare_witnesses


def setup(tmp, name):
    p=Path(tmp)/name; p.mkdir()
    priv=p/'private.pem'; pub=p/'public.pem'; db=p/'db.sqlite'
    bootstrap_keys(priv,pub); init_db(db)
    return db,priv,pub


def test_remote_protocol_validates_source_and_signs_locally(tmp_path):
    sdb,spriv,spub=setup(tmp_path,'source'); ddb,dpriv,dpub=setup(tmp_path,'dest')
    for i in range(4): record_anchor(sdb,spriv,{'n':i},witness_id='source')
    batch=build_replication_batch(sdb,spub)
    result=accept_remote_entries(ddb,dpriv,spub,batch,witness_id='destination')
    assert result['appended']==4 and result['status']=='synchronized'
    assert accept_remote_entries(ddb,dpriv,spub,batch)['appended']==0


def test_remote_protocol_rejects_tampered_and_untrusted_batch(tmp_path):
    sdb,spriv,spub=setup(tmp_path,'source'); ddb,dpriv,dpub=setup(tmp_path,'dest')
    record_anchor(sdb,spriv,{'n':1})
    batch=build_replication_batch(sdb,spub)
    batch[0]['anchor']['n']=2
    with pytest.raises(ValueError,match='digest_mismatch'):
        accept_remote_entries(ddb,dpriv,spub,batch)
    with pytest.raises(ValueError):
        accept_remote_entries(ddb,dpriv,dpub,build_replication_batch(sdb,spub))


def test_flask_remote_endpoint_auth_and_push(tmp_path):
    pytest.importorskip('flask')
    sdb,spriv,spub=setup(tmp_path,'source'); ddb,dpriv,dpub=setup(tmp_path,'dest')
    record_anchor(sdb,spriv,{'n':1})
    app=create_app(ddb,dpriv,api_token='secret',witness_id='dest',trusted_source_public_key_path=spub)
    client=app.test_client()
    batch=build_replication_batch(sdb,spub)
    assert client.post('/v1/replication/push',json={'entries':batch}).status_code==401
    r=client.post('/v1/replication/push',json={'entries':batch},headers={'Authorization':'Bearer secret'})
    assert r.status_code==200 and r.json['appended']==1
    assert client.get('/v1/replication/status',headers={'Authorization':'Bearer secret'}).json['sequence']==1


def test_chunked_replication_resumes_and_retries_after_partial_batch(tmp_path):
    from backend.witness_remote import build_replication_batch
    sdb,spriv,spub=setup(tmp_path,'chunk-source'); ddb,dpriv,dpub=setup(tmp_path,'chunk-dest')
    for i in range(7): record_anchor(sdb,spriv,{'chunk':i},witness_id='source')
    first=build_replication_batch(sdb,spub,after_sequence=0,limit=3)
    assert [x['receipt']['sequence'] for x in first] == [1,2,3]
    r=accept_remote_entries(ddb,dpriv,spub,first,after_sequence=0)
    assert r['sequence']==3 and r['appended']==3
    # Retry the same chunk after a lost acknowledgement: no duplicates.
    r=accept_remote_entries(ddb,dpriv,spub,first,after_sequence=0)
    assert r['sequence']==3 and r['appended']==0
    second=build_replication_batch(sdb,spub,after_sequence=3,limit=3)
    r=accept_remote_entries(ddb,dpriv,spub,second,after_sequence=3)
    assert r['sequence']==6 and r['appended']==3
    last=build_replication_batch(sdb,spub,after_sequence=6,limit=3)
    r=accept_remote_entries(ddb,dpriv,spub,last,after_sequence=6)
    assert r['sequence']==7 and r['appended']==1
    assert compare_witnesses(sdb,spub,ddb,dpub)['consistent']


def test_chunk_builder_rejects_invalid_cursor_and_limit(tmp_path):
    from backend.witness_remote import build_replication_batch
    db,priv,pub=setup(tmp_path,'cursor')
    record_anchor(db,priv,{'x':1})
    with pytest.raises(ValueError,match='invalid_replication_cursor_or_limit'):
        build_replication_batch(db,pub,after_sequence=-1)
    with pytest.raises(ValueError,match='invalid_replication_cursor_or_limit'):
        build_replication_batch(db,pub,limit=5001)
