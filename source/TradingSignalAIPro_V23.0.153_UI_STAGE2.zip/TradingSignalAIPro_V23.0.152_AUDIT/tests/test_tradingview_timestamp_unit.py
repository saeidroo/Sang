"""Regression coverage for TradingView timestamps under newer pandas versions."""
from __future__ import annotations

import pandas as pd

from backend import data


class _FakeInterval:
    in_5_minute = "5m"
    in_15_minute = "15m"
    in_30_minute = "30m"
    in_1_hour = "1h"
    in_4_hour = "4h"
    in_daily = "1d"


class _FakeTvDatafeed:
    def get_hist(self, *, symbol, exchange, interval, n_bars):
        assert symbol == "BTCUSDT"
        assert exchange == "BINANCE"
        assert interval == "1h"
        assert n_bars == 10
        index = pd.DatetimeIndex([pd.Timestamp("2024-01-01T00:00:00Z")], name="datetime")
        return pd.DataFrame(
            {"open": [100.0], "high": [102.0], "low": [99.0], "close": [101.0], "volume": [5.0]},
            index=index,
        )


def test_tradingview_timestamp_is_milliseconds(monkeypatch):
    monkeypatch.setattr(data, "HAS_TV", True)
    monkeypatch.setattr(data, "TvDatafeed", _FakeTvDatafeed)
    monkeypatch.setattr(data, "TvInterval", _FakeInterval)

    frame = data.fetch_tradingview("BTCUSDT", "1h", limit=10)

    assert len(frame) == 1
    assert int(frame.iloc[0]["t"]) == 1_704_067_200_000
    assert int(frame.iloc[0]["t"]) > 10**12
