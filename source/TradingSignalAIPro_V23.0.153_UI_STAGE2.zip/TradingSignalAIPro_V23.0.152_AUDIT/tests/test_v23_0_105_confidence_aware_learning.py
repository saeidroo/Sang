from backend import storm_learning as sl


def _coin(symbol):
    return {'symbol': symbol, 'price': 100, 'score': 75, 'phase': 'early',
            'direction': 'up', 'verified': True}


def test_wilson_interval_is_bounded_and_widens_for_small_samples():
    lo_small, hi_small = sl._wilson_interval(4, 5)
    lo_large, hi_large = sl._wilson_interval(80, 100)
    assert 0 <= lo_small < 0.8 < hi_small <= 1
    assert 0 <= lo_large < 0.8 < hi_large <= 1
    assert hi_small - lo_small > hi_large - lo_large


def test_historical_insight_exposes_confidence_and_evidence_level(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'confidence.sqlite3')
    base = 1_800_000_000
    # Ten separate recommendations: six successful 4h outcomes, four neutral.
    for i in range(10):
        symbol = f'C{i}'
        ts = base + i * 100_000
        sl.record_scan([_coin(symbol)], timestamp=ts)
        price = 103 if i < 6 else 100
        sl.record_scan([], timestamp=ts + 4 * 3600, snapshots={symbol: {'price': price}})
    insights = sl.followups()['historical_insights']
    row = next(x for x in insights if x['horizon'] == '4h' and x['phase'] == 'early')
    assert row['samples'] == 10
    assert row['success_rate'] == 0.6
    assert len(row['success_rate_ci95']) == 2
    assert row['success_rate_ci95'][0] < row['success_rate'] < row['success_rate_ci95'][1]
    assert row['evidence_level'] == 'مقدماتی'


def test_no_insight_created_from_fewer_than_five_samples(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'few.sqlite3')
    base = 1_810_000_000
    for i in range(4):
        symbol = f'F{i}'
        ts = base + i * 100_000
        sl.record_scan([_coin(symbol)], timestamp=ts)
        sl.record_scan([], timestamp=ts + 4 * 3600, snapshots={symbol: {'price': 103}})
    assert sl.followups()['historical_insights'] == []
