import json
from backend.walk_forward_validation import walk_forward_validate


def make(pnl, i, strategy='alpha'):
    return {'symbol':'BTCUSDT','market':'perp','timeframe':'1h','side':'LONG',
            'net_pnl':pnl,'closed_at':f'2026-01-{i:02d}T00:00:00Z','trade_id':f'{i:03d}',
            'context_json':json.dumps({'strategy':strategy,'market_regime':'BULLISH','volatility_regime':'LOW'})}


def test_walk_forward_uses_expanding_chronological_windows_without_leakage():
    result=walk_forward_validate([make(1,i) for i in range(1,31)], min_total=20, min_train=8, min_test=3, folds=4)
    c=result['cohorts'][0]
    assert c['fold_count'] == 4
    assert c['state'] == 'STABLE_ACROSS_WINDOWS'
    assert all(f['chronology_valid'] and f['train_end'] < f['test_start'] for f in c['folds'])
    assert result['authorizes_entries'] is False and result['real_orders_enabled'] is False
    assert result['future_data_used_for_past'] is False


def test_walk_forward_flags_mixed_windows():
    rows=[make(2,i) for i in range(1,17)] + [make(-2,i) for i in range(17,31)]
    c=walk_forward_validate(rows,min_total=20,min_train=8,min_test=3,folds=4)['cohorts'][0]
    assert c['state'] in {'MIXED_WINDOW_PERFORMANCE','UNSTABLE_OR_NEGATIVE'}


def test_small_sample_is_insufficient_and_never_authorizes():
    r=walk_forward_validate([make(1,i) for i in range(1,8)],min_total=20,min_train=8,min_test=3)
    assert r['cohorts'][0]['state']=='INSUFFICIENT_EVIDENCE'
    assert r['paper_only'] is True and r['authorizes_entries'] is False
