from backend.scout import select_active_dump_candidates


def _item(symbol, **updates):
    row = {
        'symbol': symbol, 'base': symbol.replace('USDT', ''), 'verified': True,
        'direction': 'up', 'change_1h': -3.8, 'change_24h': -7.2,
        'sell_pressure_ratio': 0.68, 'sell_flow_persistence': 0.75,
        'recent_volume_ratio': 1.8,
    }
    row.update(updates)
    return row


def test_active_dump_is_separate_from_early_pre_dump_and_directional():
    good = _item('FALLUSDT')
    bullish_flow = _item('WRONGUSDT', sell_pressure_ratio=0.42)
    weak_volume = _item('QUIETUSDT', recent_volume_ratio=1.05)
    unverified = _item('UNVERIFIEDUSDT', verified=False)
    result = select_active_dump_candidates([good, bullish_flow, weak_volume, unverified])
    assert [x['symbol'] for x in result] == ['FALLUSDT']
    assert result[0]['direction'] == 'down'
    assert result[0]['priority_signal_type'] == 'active_dump'
    assert result[0]['active_dump_score'] > 0


def test_active_dump_accepts_24h_selloff_even_if_one_hour_is_quiet():
    row = _item('DAYDROPUSDT', change_1h=-0.4, change_24h=-9.0)
    assert len(select_active_dump_candidates([row])) == 1


def test_active_dump_rejects_fast_fall_without_directional_sell_flow():
    row = _item('NOFLOWUSDT', sell_flow_persistence=0.2)
    assert select_active_dump_candidates([row]) == []
