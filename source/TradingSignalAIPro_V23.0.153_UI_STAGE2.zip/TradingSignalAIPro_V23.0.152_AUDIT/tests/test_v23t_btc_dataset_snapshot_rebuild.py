import hashlib
import json
import pandas as pd
import pytest
from backend.btc_dataset import build_btc_4h_dataset, rebuild_btc_4h_dataset_from_snapshot
from backend.btc_ingestion_store import append_ingestion, replay_snapshot
from backend.btc_oof_coverage import build_oof_coverage_contract
from test_v23d_btc_dataset import candles


def _store_candles(tmp_path):
    frame = candles(420)
    rows = [{k: (int(v) if k == 't' else float(v)) for k, v in row.items()}
            for row in frame.to_dict('records')]
    raw = json.dumps(rows, sort_keys=True, separators=(',', ':'), allow_nan=False)
    batch = {'status': 'PASS', 'symbol': 'BTCUSDT', 'candles': rows,
             'data_sha256': hashlib.sha256(raw.encode()).hexdigest()}
    return frame, append_ingestion(tmp_path, batch)


def test_dataset_rejects_out_of_order_samples_even_if_integrity_opt_out():
    frame = candles(420).iloc[::-1].reset_index(drop=True)
    with pytest.raises(ValueError, match='dataset_sample_timestamp_order_invalid'):
        build_btc_4h_dataset(frame, n_splits=3, require_integrity=False)


def test_dataset_rejects_duplicate_timestamps_even_if_integrity_opt_out():
    frame = candles(420)
    frame.loc[101, 't'] = frame.loc[100, 't']
    with pytest.raises(ValueError, match='dataset_sample_timestamp_duplicate'):
        build_btc_4h_dataset(frame, n_splits=3, require_integrity=False)


def test_snapshot_rebuild_preserves_dataset_and_sample_identity(tmp_path):
    frame, saved = _store_candles(tmp_path)
    direct = build_btc_4h_dataset(frame, n_splits=3)
    rebuilt = rebuild_btc_4h_dataset_from_snapshot(tmp_path, snapshot=saved['snapshot'], n_splits=3)
    identity_cols = ['sample_id', 'timestamp_utc', 'row_identity_sha256']
    assert direct['metadata'][identity_cols].equals(rebuilt['metadata'][identity_cols])
    assert direct['manifest']['sample_identity_sha256'] == rebuilt['manifest']['sample_identity_sha256']
    assert direct['manifest']['dataset_hash'] == rebuilt['manifest']['dataset_hash']
    assert direct['folds'] == rebuilt['folds']
    assert direct['X'].equals(rebuilt['X'])
    assert direct['y'].equals(rebuilt['y'])
    assert rebuilt['manifest']['snapshot_replay']['network_used'] is False
    assert build_oof_coverage_contract(direct) == build_oof_coverage_contract(rebuilt)


def test_snapshot_manifest_hash_mismatch_blocks_replay(tmp_path):
    _, saved = _store_candles(tmp_path)
    manifest_path = tmp_path / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    manifest['snapshots'][0]['data_sha256'] = '0' * 64
    manifest_path.write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match='snapshot_manifest_hash_mismatch'):
        replay_snapshot(tmp_path, snapshot=saved['snapshot'])


def test_rebuilt_dataset_identity_digest_is_stable_across_repeated_replays(tmp_path):
    _, saved = _store_candles(tmp_path)
    a = rebuild_btc_4h_dataset_from_snapshot(tmp_path, snapshot=saved['snapshot'], n_splits=3)
    b = rebuild_btc_4h_dataset_from_snapshot(tmp_path, snapshot=saved['snapshot'], n_splits=3)
    assert a['manifest']['sample_identity_sha256'] == b['manifest']['sample_identity_sha256']
    assert a['manifest']['dataset_hash'] == b['manifest']['dataset_hash']
