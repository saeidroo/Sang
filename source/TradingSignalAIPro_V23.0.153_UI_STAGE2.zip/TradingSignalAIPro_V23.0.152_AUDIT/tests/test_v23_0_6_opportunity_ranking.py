"""V23.0.6: ranked shortlist and portfolio diversification tests."""
from unittest.mock import patch

import pytest

from backend import autopilot, paper_live


@pytest.fixture(autouse=True)
def restore_autopilot_state(monkeypatch):
    # _entry_scan now adds read-only market-regime and 4h/1h/15m confirmation.
    # Keep these unit tests offline and deterministic; individual tests can
    # override fetch_candles when they explicitly test candle retrieval.
    import pandas as pd
    close = [100.0 + i * 0.1 for i in range(120)]
    frame = pd.DataFrame({
        "open": [v * 0.999 for v in close],
        "high": [v * 1.005 for v in close],
        "low": [v * 0.995 for v in close],
        "close": close,
        "volume": [1000.0] * len(close),
    })
    monkeypatch.setattr(autopilot, "fetch_candles", lambda symbol, timeframe, **kwargs: frame.copy())
    monkeypatch.setattr(autopilot, "_entry_atr_context", lambda base, market, timeframe, decision: {
        "atr_value": 1.0, "atr_pct": 1.0, "reference_close": 100.0,
        "candle_ts": float(decision.get("candle_ts") or 9_999_999_999.0),
        "timeframe": timeframe, "market_symbol": base + "USDT", "source": "test",
    })
    config = dict(autopilot._CONFIG)
    watched = list(autopilot._STATE.get("watchlist") or [])
    watch_at = autopilot._STATE.get("watchlist_at", 0.0)
    watch_source = autopilot._STATE.get("watchlist_source", "fallback")
    candle_seen = dict(autopilot._STATE.get("candle_seen") or {})
    cooldowns = dict(autopilot._STATE.get("cooldowns") or {})
    entries_enabled = autopilot._STATE.get("entries_enabled", False)
    last_summary = dict(autopilot._STATE.get("last_entry_summary") or {})
    yield
    autopilot._CONFIG.clear()
    autopilot._CONFIG.update(config)
    autopilot._STATE["watchlist"] = watched
    autopilot._STATE["watchlist_at"] = watch_at
    autopilot._STATE["watchlist_source"] = watch_source
    autopilot._STATE["candle_seen"] = candle_seen
    autopilot._STATE["cooldowns"] = cooldowns
    autopilot._STATE["entries_enabled"] = entries_enabled
    autopilot._STATE["last_entry_summary"] = last_summary


def _series(values, start=1000):
    return {start + i: float(v) for i, v in enumerate(values)}


def _decision(kind="BUY", confidence=0.8, brain="hybrid", edge=True):
    return {
        "kind": kind, "confidence": confidence, "brain": brain,
        "edge_confirmed": edge, "tech_confirmation": True,
        "candle_ts": 9_999_999_999.0,
        "learning_gate": {"risk_scale": 0.5, "learning_state": "COLLECTING", "sample_count": 0},
        "decision_context": {"schema_version": "paper-entry-context-v1"},
        "detail": "test decision",
    }


def _scan_setup(symbols, markets=None, max_positions=2):
    autopilot._STATE["watchlist"] = [
        {"symbol": sym, "volume": float((len(symbols) - i) * 1_000_000)}
        for i, sym in enumerate(symbols)
    ]
    autopilot._STATE["watchlist_at"] = 9999999999.0
    autopilot._STATE["watchlist_source"] = "test"
    autopilot._STATE["candle_seen"] = {}
    autopilot._STATE["cooldowns"] = {}
    autopilot._STATE["entries_enabled"] = True
    autopilot._CONFIG.update({
        "markets": markets or ["spot"], "max_open_positions": max_positions,
        "max_positions_per_base": 1, "diversification_enabled": False,
        "correlation_threshold": 0.82, "correlation_lookback": 60,
        "timeframe": "1h", "risk_preset": "balanced",
    })


def test_candidate_score_prefers_confidence_and_hybrid_quality():
    strong = {"decision": _decision(confidence=0.9, brain="hybrid", edge=True), "volume_24h": 10_000_000}
    weak = {"decision": _decision(confidence=0.65, brain="tech", edge=False), "volume_24h": 10_000_000}
    assert autopilot._candidate_rank_score(strong, 10_000_000) > autopilot._candidate_rank_score(weak, 10_000_000)


def test_pearson_uses_timestamp_intersection_and_positive_corr():
    a = _series([0.01, 0.02, -0.01, 0.03, 0.00] * 6)
    b = _series([0.01, 0.02, -0.01, 0.03, 0.00] * 6)
    c = _series([-x for x in a.values()])
    assert autopilot._pearson_aligned(a, b) > 0.999
    assert autopilot._pearson_aligned(a, c) < -0.999
    # Non-overlapping timestamps must not be treated as correlated.
    assert autopilot._pearson_aligned(a, _series(list(b.values()), start=5000)) is None


def test_entry_scan_opens_highest_ranked_candidates_first():
    _scan_setup(["AAAUSDT", "BBBUSDT", "CCCUSDT"], max_positions=1)
    decisions = {
        "AAAUSDT": _decision(confidence=0.66, brain="tech", edge=False),
        "BBBUSDT": _decision(confidence=0.93, brain="hybrid", edge=True),
        "CCCUSDT": {**_decision(), "kind": "HOLD"},
    }
    opened = []

    def fake_open(symbol, side, market, *_args, **_kwargs):
        opened.append(symbol)
        return {"id": len(opened), "notional": 100.0, "stop_price": 90.0, "target_price": 120.0}

    with patch.object(autopilot, "_decide_entry", side_effect=lambda sym, m: decisions[sym]), \
         patch.object(paper_live, "get_state", return_value={"open_positions": []}), \
         patch.object(paper_live, "open_position", side_effect=fake_open):
        result = autopilot._entry_scan()

    assert opened == ["BBBUSDT"]
    assert result["opened"] == 1
    assert result["ranked"][0]["symbol"] == "BBBUSDT"
    assert result["ranked"][0]["selected"] is True
    assert result["capacity_blocked"] == 1


def test_entry_scan_blocks_same_base_across_spot_and_perp():
    _scan_setup(["AAAUSDT"], markets=["spot", "perp"], max_positions=2)
    decisions = {
        "spot": _decision(confidence=0.91, brain="hybrid", edge=True),
        "perp": _decision(confidence=0.85, brain="hybrid", edge=True),
    }
    opened = []

    def fake_open(symbol, side, market, *_args, **_kwargs):
        opened.append((symbol, market))
        return {"id": len(opened), "notional": 100.0, "stop_price": 90.0, "target_price": 120.0}

    with patch.object(autopilot, "_decide_entry", side_effect=lambda _sym, m: decisions[m]), \
         patch.object(paper_live, "get_state", return_value={"open_positions": []}), \
         patch.object(paper_live, "open_position", side_effect=fake_open):
        result = autopilot._entry_scan()

    assert len(opened) == 1
    assert opened[0] == ("AAAUSDT", "spot")
    assert result["base_exposure_blocked"] == 1


def test_entry_scan_blocks_highly_correlated_second_asset():
    _scan_setup(["AAAUSDT", "BBBUSDT", "CCCUSDT"], max_positions=3)
    autopilot._CONFIG["diversification_enabled"] = True
    decisions = {
        "AAAUSDT": _decision(confidence=0.95),
        "BBBUSDT": _decision(confidence=0.90),
        "CCCUSDT": _decision(confidence=0.80),
    }
    series = {
        "AAAUSDT": _series([0.01, 0.02, -0.01, 0.03] * 15),
        "BBBUSDT": _series([0.01, 0.02, -0.01, 0.03] * 15),
        "CCCUSDT": _series([-0.01, 0.02, 0.01, -0.02] * 15),
    }
    opened = []

    def fake_open(symbol, side, market, *_args, **_kwargs):
        opened.append(symbol)
        return {"id": len(opened), "notional": 100.0, "stop_price": 90.0, "target_price": 120.0}

    with patch.object(autopilot, "_decide_entry", side_effect=lambda sym, _m: decisions[sym]), \
         patch.object(autopilot, "_recent_return_series", side_effect=lambda sym, *_a, **_k: series[sym]), \
         patch.object(paper_live, "get_state", return_value={"open_positions": []}), \
         patch.object(paper_live, "open_position", side_effect=fake_open):
        result = autopilot._entry_scan()

    assert opened[0] == "AAAUSDT"
    assert "BBBUSDT" not in opened
    assert "CCCUSDT" in opened
    assert result["diversity_blocked"] == 1


def test_last_ranked_summary_is_exposed_in_status():
    autopilot._STATE["last_entry_summary"] = {"ts": 123.0, "ranked": [{"symbol": "AAAUSDT"}]}
    with patch.object(paper_live, "get_state", return_value={"account": {}, "open_positions": [], "recent_trades": []}), \
         patch.object(autopilot, "_closed_autopilot_trades", return_value=[]):
        result = autopilot.status()
    assert result["last_entry_summary"]["ranked"][0]["symbol"] == "AAAUSDT"


def test_recent_return_series_uses_complete_exchange_symbol():
    import pandas as pd
    calls = []
    frame = pd.DataFrame({"t": list(range(1, 31)), "close": [100.0 + i for i in range(30)]})
    with patch.object(autopilot, "fetch_candles", side_effect=lambda symbol, *a, **k: (calls.append(symbol) or frame)):
        result = autopilot._recent_return_series("BTCUSDT", "spot", "1h", {})
    assert calls == ["BTCUSDT"]
    assert result is not None and len(result) == 29


def test_high_correlation_is_allowed_when_candidate_hedges_open_direction():
    _scan_setup(["AAAUSDT", "BBBUSDT"], markets=["perp"], max_positions=2)
    autopilot._CONFIG["diversification_enabled"] = True
    decisions = {
        "AAAUSDT": _decision(kind="BUY", confidence=0.95),
        "BBBUSDT": _decision(kind="SELL", confidence=0.90),
    }
    series = {
        "AAAUSDT": _series([0.01, 0.02, -0.01, 0.03] * 15),
        "BBBUSDT": _series([0.01, 0.02, -0.01, 0.03] * 15),
    }
    opened = []
    def fake_open(symbol, side, market, *_args, **_kwargs):
        opened.append((symbol, side))
        return {"id": len(opened), "notional": 100.0, "stop_price": 90.0, "target_price": 120.0}
    with patch.object(autopilot, "_decide_entry", side_effect=lambda sym, _m: decisions[sym]), \
         patch.object(autopilot, "_recent_return_series", side_effect=lambda sym, *_a, **_k: series[sym]), \
         patch.object(paper_live, "get_state", return_value={"open_positions": []}), \
         patch.object(paper_live, "open_position", side_effect=fake_open):
        result = autopilot._entry_scan()
    assert opened == [("AAAUSDT", "LONG"), ("BBBUSDT", "SHORT")]
    assert result["diversity_blocked"] == 0


def test_diversification_controls_are_range_validated():
    assert autopilot._config_value("diversification_enabled", True) is True
    assert autopilot._config_value("max_positions_per_base", 2) == 2
    assert autopilot._config_value("correlation_lookback", 60) == 60
    assert autopilot._config_value("correlation_threshold", 0.82) == pytest.approx(0.82)
    with pytest.raises(ValueError):
        autopilot._config_value("correlation_threshold", 1.2)
    with pytest.raises(ValueError):
        autopilot._config_value("correlation_lookback", 5)
