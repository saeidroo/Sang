import pytest
from backend.witness_security import FixedWindowRateLimiter, validate_json_shape


def test_fixed_window_rate_limit_and_reset():
    now = [100.0]
    limiter = FixedWindowRateLimiter(2, 10, clock=lambda: now[0])
    assert limiter.allow('client-a') is True
    assert limiter.allow('client-a') is True
    assert limiter.allow('client-a') is False
    assert limiter.allow('client-b') is True
    now[0] = 111.0
    assert limiter.allow('client-a') is True


def test_limiter_rejects_invalid_configuration():
    with pytest.raises(ValueError):
        FixedWindowRateLimiter(0, 10)
    with pytest.raises(ValueError):
        FixedWindowRateLimiter(10, 0)


def test_json_shape_accepts_normal_payload():
    assert validate_json_shape({'entries': [{'sequence': 1, 'anchor': {'x': 'ok'}}]})


def test_json_shape_rejects_deep_nesting():
    value = {}
    current = value
    for _ in range(15):
        current['x'] = {}
        current = current['x']
    with pytest.raises(ValueError, match='nesting'):
        validate_json_shape(value, max_depth=12)


def test_json_shape_rejects_large_strings_and_node_count():
    with pytest.raises(ValueError, match='string'):
        validate_json_shape({'x': 'a' * 20}, max_string=10)
    with pytest.raises(ValueError, match='complexity'):
        validate_json_shape([1, 2, 3, 4], max_nodes=3)


def test_json_shape_rejects_long_keys():
    with pytest.raises(ValueError, match='key'):
        validate_json_shape({'x' * 300: 1})
