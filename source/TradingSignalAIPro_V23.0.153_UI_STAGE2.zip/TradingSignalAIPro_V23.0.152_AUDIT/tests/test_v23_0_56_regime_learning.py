from backend.strategy_learning import rank_strategy_performance


def test_strategy_results_are_separated_by_recorded_market_regime():
    rows = []
    for _ in range(12):
        rows.append({"symbol":"BTCUSDT", "market":"perp", "timeframe":"1h", "side":"LONG",
                     "net_pnl":2, "return_pct":1, "context_json":'{"strategy":"alpha","market_regime":"bullish"}'})
        rows.append({"symbol":"BTCUSDT", "market":"perp", "timeframe":"1h", "side":"LONG",
                     "net_pnl":-1, "return_pct":-0.5, "context_json":'{"strategy":"alpha","decision":{"regime":"ranging"}}'})
    result = rank_strategy_performance(rows, min_samples=10)
    assert result["group_count"] == 2
    by_regime = {g["market_regime"]: g for g in result["groups"]}
    assert by_regime["BULLISH"]["learning_state"] == "REVIEWABLE"
    assert by_regime["RANGING"]["learning_state"] == "NO_POSITIVE_EDGE"
    assert result["regime_segmentation"] == "RECORDED_CONTEXT_ONLY"
    assert result["authorizes_entries"] is False
    assert result["real_orders_enabled"] is False


def test_missing_regime_is_not_mixed_with_known_regimes():
    rows = [dict(symbol="ETHUSDT", market="spot", timeframe="15m", side="LONG",
                 net_pnl=1, return_pct=0.2, context_json="{}")]
    result = rank_strategy_performance(rows, min_samples=1)
    assert result["groups"][0]["market_regime"] == "UNKNOWN"


def test_regime_aliases_are_normalized():
    rows = [dict(net_pnl=1, return_pct=1, context_json='{"regime":"sideways"}')]
    result = rank_strategy_performance(rows, min_samples=1)
    assert result["groups"][0]["market_regime"] == "RANGING"
