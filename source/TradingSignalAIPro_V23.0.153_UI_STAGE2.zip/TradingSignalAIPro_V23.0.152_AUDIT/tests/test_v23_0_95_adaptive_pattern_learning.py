import sqlite3
from backend import market_brain as brain


def test_pattern_feedback_requires_minimum_sample_count(tmp_path, monkeypatch):
    db = tmp_path / 'feedback.sqlite3'
    con = sqlite3.connect(db)
    con.execute('''CREATE TABLE brain_forecasts (
        id INTEGER PRIMARY KEY, symbol TEXT, horizon TEXT, created_ts REAL, due_ts REAL,
        start_price REAL, predicted_up REAL, predicted_down REAL, observed_ts REAL,
        observed_return REAL, outcome TEXT, pattern_signature TEXT)''')
    rows = []
    for i in range(19):
        rows.append((i + 1, 'BTCUSDT', '4h', i, i + 1, 100, 70, 30, i + 1, 1,
                     'up' if i < 15 else 'down', 'v2|bull|high'))
    con.executemany('''INSERT INTO brain_forecasts
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''', rows)
    con.commit(); con.close()
    monkeypatch.setattr(brain, 'FEEDBACK_DB_PATH', db)
    result = brain._pattern_feedback('v2|bull|high')
    assert result['directional_calls'] == 19
    assert result['accuracy_pct'] == round(100 * 15 / 19, 1)
    assert result['weight'] == 1.0
    assert result['reliability'] == 'insufficient_samples'


def test_pattern_feedback_adapts_weight_only_after_20_samples(tmp_path, monkeypatch):
    db = tmp_path / 'feedback.sqlite3'
    con = sqlite3.connect(db)
    con.execute('''CREATE TABLE brain_forecasts (
        id INTEGER PRIMARY KEY, symbol TEXT, horizon TEXT, created_ts REAL, due_ts REAL,
        start_price REAL, predicted_up REAL, predicted_down REAL, observed_ts REAL,
        observed_return REAL, outcome TEXT, pattern_signature TEXT)''')
    rows = []
    for i in range(20):
        rows.append((i + 1, 'BTCUSDT', '4h', i, i + 1, 100, 70, 30, i + 1, 1,
                     'up' if i < 15 else 'down', 'v2|bull|high'))
    con.executemany('''INSERT INTO brain_forecasts
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''', rows)
    con.commit(); con.close()
    monkeypatch.setattr(brain, 'FEEDBACK_DB_PATH', db)
    result = brain._pattern_feedback(('v2', 'bull', 'high'))
    assert result['directional_calls'] == 20
    assert result['accuracy_pct'] == 75.0
    assert result['weight'] == 1.15
    assert result['reliability'] == 'historically_supportive'


def test_record_feedback_migrates_old_database_and_saves_pattern_signature(tmp_path, monkeypatch):
    db = tmp_path / 'feedback.sqlite3'
    con = sqlite3.connect(db)
    con.execute('''CREATE TABLE brain_forecasts (
        id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, horizon TEXT NOT NULL,
        created_ts REAL NOT NULL, due_ts REAL NOT NULL, start_price REAL NOT NULL,
        predicted_up REAL NOT NULL, predicted_down REAL NOT NULL, observed_ts REAL,
        observed_return REAL, outcome TEXT, UNIQUE(symbol,horizon,created_ts))''')
    con.commit(); con.close()
    monkeypatch.setattr(brain, 'FEEDBACK_DB_PATH', db)
    items = [{'symbol': 'BTCUSDT', 'price': 100, 'brain_prediction': {
        'status': 'historical_analogs', 'pattern_signature': 'v2|up|high',
        'horizons': {h: {'up_pct': 70, 'down_pct': 20} for h in ('1h', '4h', '24h')}}}]
    brain.record_feedback(items, now=1000)
    con = sqlite3.connect(db)
    cols = {r[1] for r in con.execute('PRAGMA table_info(brain_forecasts)')}
    row = con.execute('SELECT pattern_signature FROM brain_forecasts LIMIT 1').fetchone()
    con.close()
    assert 'pattern_signature' in cols
    assert row[0] == 'v2|up|high'
