import base64, json, sqlite3
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import pytest
from cryptography.hazmat.primitives import serialization
from backend import witness_server as ws

@pytest.fixture
def keys(tmp_path):
    priv, pub = tmp_path/'private.pem', tmp_path/'public.pem'
    info=ws.bootstrap_keys(priv,pub)
    return priv,pub,info

def test_bootstrap_refuses_overwrite_and_permissions(tmp_path):
    priv,pub=tmp_path/'k.pem',tmp_path/'p.pem'
    ws.bootstrap_keys(priv,pub)
    assert priv.stat().st_mode & 0o077 == 0
    with pytest.raises(FileExistsError): ws.bootstrap_keys(priv,pub)

def test_record_sign_verify_duplicate_and_append_only(tmp_path,keys):
    priv,pub,_=keys; db=tmp_path/'w.sqlite3'; ws.init_db(db)
    a={'backup_digest':'a'*64,'counter':3}
    r1=ws.record_anchor(db,priv,a); r2=ws.record_anchor(db,priv,a)
    assert r1['sequence']==r2['sequence']==1 and r2['duplicate']
    assert ws.verify_anchor_record(r1,pub)
    with sqlite3.connect(db) as c:
        with pytest.raises(sqlite3.IntegrityError): c.execute("UPDATE anchors SET anchor_digest='x'")
        with pytest.raises(sqlite3.IntegrityError): c.execute('DELETE FROM anchors')
    r3=ws.record_anchor(db,priv,{'backup_digest':'b'*64})
    assert r3['sequence']==2 and ws.verify_anchor_record(r3,pub)

def test_concurrent_sequence_is_unique_and_contiguous(tmp_path,keys):
    priv,_,_=keys; db=tmp_path/'w.sqlite3'; ws.init_db(db)
    anchors=[{'n':i} for i in range(12)]
    with ThreadPoolExecutor(max_workers=6) as ex:
        results=list(ex.map(lambda a: ws.record_anchor(db,priv,a),anchors))
    assert sorted(x['sequence'] for x in results)==list(range(1,13))

def test_backup_database_is_consistent_and_non_overwriting(tmp_path,keys):
    priv,_,_=keys; db=tmp_path/'w.sqlite3'; ws.init_db(db)
    ws.record_anchor(db,priv,{'x':1})
    backup=tmp_path/'backup.sqlite3'; info=ws.backup_database(db,backup)
    assert len(info['sha256'])==64
    with sqlite3.connect(backup) as c:
        assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert c.execute('SELECT COUNT(*) FROM anchors').fetchone()[0]==1
    with pytest.raises(FileExistsError): ws.backup_database(db,backup)

def test_bad_key_type_rejected(tmp_path):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    p=tmp_path/'bad.pem'
    key=Ed25519PrivateKey.generate()
    p.write_bytes(key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo))
    with pytest.raises(Exception): ws.record_anchor(tmp_path/'x.db',p,{'a':1})
