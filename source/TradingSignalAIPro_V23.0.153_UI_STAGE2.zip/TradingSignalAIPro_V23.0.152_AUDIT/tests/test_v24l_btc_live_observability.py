import json
import pytest
from backend.btc_live_observability import (build_live_source_observability,
    save_live_source_observability,build_observability_from_jsonl)


def test_observability_aggregates_source_reliability_and_saves(tmp_path):
    live=[{'status':'PASS','read_only':True,'latest_age_hours':1,'fetched_at_utc':'2026-11-17T00:00:00+00:00'},
          {'status':'PASS','read_only':True,'latest_age_hours':2,'fetched_at_utc':'2026-11-17T04:00:00+00:00'}]
    reconciliation=[{'previous_rows':100,'revision_count':0,'removed_count':0}]
    alerts=[{'status':'HEALTHY'}]
    report=build_live_source_observability(live_reports=live,reconciliation_reports=reconciliation,drift_alerts=alerts)
    assert report['status']=='HEALTHY'
    assert report['metrics']['fetch_success_rate']==1.0
    assert report['metrics']['median_fetch_interval_hours']==4.0
    assert save_live_source_observability(report,output_path=tmp_path/'obs.json')['saved']


def test_observability_marks_stale_revision_and_critical_alerts(tmp_path):
    report=build_live_source_observability(
        live_reports=[{'status':'PASS','read_only':True,'latest_age_hours':12}],
        reconciliation_reports=[{'previous_rows':10,'revision_count':2,'removed_count':1}],
        drift_alerts=[{'status':'CRITICAL'}],max_revision_rate=0.0)
    assert report['status']=='CRITICAL'
    assert 'stale_live_reports_observed' in report['errors']
    assert report['training_allowed'] is False


def test_observability_jsonl_ingestion_rejects_corrupt_input(tmp_path):
    path=tmp_path/'live.jsonl'; path.write_text('{bad json}\n')
    with pytest.raises(ValueError,match='corrupt_line'):
        build_observability_from_jsonl(live_reports_path=path)
