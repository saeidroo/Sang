import json
import pytest
from backend.reproducible_run import create_run_manifest, save_run_manifest, verify_run_manifest, sha256_bytes

COST={"version":"cost-v1","cost_hash":"abc123"}
DATA=sha256_bytes(b"fixed-test-data")

def test_manifest_roundtrip_and_artifact_integrity(tmp_path):
    artifact=tmp_path/"model.bin"; artifact.write_bytes(b"model")
    m=create_run_manifest(data_hash=DATA,config={"lr":0.01},cost_model=COST,test_block_id="test-2026-01",
                          seed=7,trial_count=12,model_artifacts={"primary":str(artifact)})
    p=save_run_manifest(m,tmp_path/"runs")
    # Artifact manifest is stored alongside manifest; verify against its actual directory.
    (tmp_path/"runs"/"model.bin").write_bytes(b"model")
    assert verify_run_manifest(p,verify_artifacts_dir=tmp_path/"runs")["valid"]
    (tmp_path/"runs"/"model.bin").write_bytes(b"tampered")
    assert not verify_run_manifest(p,verify_artifacts_dir=tmp_path/"runs")["valid"]

def test_manifest_rejects_missing_provenance():
    with pytest.raises(ValueError): create_run_manifest(data_hash="bad",config={},cost_model=COST,test_block_id="x")
    with pytest.raises(ValueError): create_run_manifest(data_hash=DATA,config={},cost_model={},test_block_id="x")
    with pytest.raises(ValueError): create_run_manifest(data_hash=DATA,config={},cost_model=COST,test_block_id="")

def test_manifest_tampering_detected():
    m=create_run_manifest(data_hash=DATA,config={"a":1},cost_model=COST,test_block_id="holdout")
    m["seed"]=99
    assert "manifest_hash_mismatch" in verify_run_manifest(m)["errors"]
