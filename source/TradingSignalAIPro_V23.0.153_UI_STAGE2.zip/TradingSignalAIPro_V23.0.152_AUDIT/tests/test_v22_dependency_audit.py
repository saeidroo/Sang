from dependency_audit import audit, CORE, OPTIONAL


def test_dependency_audit_has_core_and_optional_separation():
    report = audit()
    assert report["schema_version"] == "dependency-audit-v1"
    assert {x["distribution"] for x in report["core"]} == {v[0] for v in CORE.values()}
    assert {x["distribution"] for x in report["optional"]} == {v[0] for v in OPTIONAL.values()}
    assert all(x["required"] for x in report["core"])
    assert not any(x["required"] for x in report["optional"])


def test_optional_ml_is_not_a_core_install_blocker():
    report = audit()
    assert "xgboost" not in report["missing_core"]
    assert "lightgbm" not in report["missing_core"]


def test_dependency_audit_never_reports_secret_values():
    serialized = str(audit()).lower()
    assert "token" not in serialized
    assert "private_key" not in serialized


def test_dependency_audit_reports_64_bit_runtime_requirement():
    report = audit()
    assert report["architecture_bits"] in (32, 64)
    assert report["architecture_supported"] is (report["architecture_bits"] == 64)
