import json
from backend.experiment_registry import (register_hypothesis,start_experiment,finish_experiment,read_events,trial_count,negative_results,stable_hash)

def test_registry_append_only_and_trial_count(tmp_path):
    register_hypothesis('H1','title','falsifiable',custom_dir=tmp_path)
    a=start_experiment('H1',symbol='BTC/USDT',timeframe='4h',data_hash='abc',config={'x':1},custom_dir=tmp_path)
    b=start_experiment('H1',symbol='BTC/USDT',timeframe='4h',data_hash='abc',config={'x':1},custom_dir=tmp_path)
    assert a['trial_count_at_start']==1 and b['trial_count_at_start']==2
    finish_experiment(a['experiment_id'],'REJECTED',metrics={'n':10},negative_result='no edge',custom_dir=tmp_path)
    assert trial_count('H1',tmp_path)==2
    assert len(negative_results(tmp_path))==1
    assert len(read_events(tmp_path))==4

def test_hash_is_stable_and_config_sensitive():
    assert stable_hash({'a':1,'b':2})==stable_hash({'b':2,'a':1})
    assert stable_hash({'a':1})!=stable_hash({'a':2})

def test_reject_missing_reproducibility_inputs(tmp_path):
    import pytest
    with pytest.raises(ValueError): start_experiment('H1',symbol='BTC',timeframe='1h',data_hash='',config={},custom_dir=tmp_path)
