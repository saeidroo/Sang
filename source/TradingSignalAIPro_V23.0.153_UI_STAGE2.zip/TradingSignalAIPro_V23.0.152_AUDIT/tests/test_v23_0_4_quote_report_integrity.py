import csv
import io
import json

import pytest

from backend import autopilot, paper_live


@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(tmp_path / "paper_live.sqlite3"))
    monkeypatch.setenv("TRADING_AI_MODELS_DIR", str(tmp_path / "models"))
    paper_live._CACHE.clear()


def _autotrade(trade_id, *, status="CLOSED", pnl=0.0, notional=100.0, entry=100.0,
               closed_at=20.0, opened_at=10.0, symbol="BTCUSDT"):
    return {
        "id": trade_id, "trade_id": trade_id, "status": status,
        "symbol": symbol, "market": "spot", "timeframe": "1h", "exchange": "binance",
        "side": "LONG", "notional": notional, "entry_fill": entry,
        "exit_fill": entry, "net_pnl": pnl, "gross_pnl": pnl + 0.2,
        "entry_fee": 0.1, "exit_fee": 0.1, "opened_at": opened_at,
        "closed_at": closed_at, "exit_reason": "TAKE_PROFIT",
        "entry_context_json": json.dumps({"entry_source": "autopilot"}),
    }


def test_stats_use_notional_return_and_count_open_positions_with_baseline():
    closed = [
        _autotrade(1, pnl=4.0, notional=200.0, entry=100.0, closed_at=20.0),
        _autotrade(2, pnl=-5.0, notional=1000.0, entry=100.0, closed_at=30.0),
    ]
    opened = [_autotrade(3, status="OPEN", pnl=0.0, notional=150.0, closed_at=None)]

    stats = autopilot._stats_from_trades(closed, open_trades=opened, starting_equity=1000.0)

    assert stats["trades"] == 3
    assert stats["closed_trades"] == 2
    assert stats["open_trades"] == 1
    assert stats["avg_return_pct"] == pytest.approx((2.0 - 0.5) / 2)
    assert stats["total_return_pct"] == pytest.approx(-0.1)
    assert stats["starting_equity"] == pytest.approx(1000.0)
    assert stats["ending_realized_equity"] == pytest.approx(999.0)
    assert len(stats["equity_curve"]) == 3
    assert stats["equity_curve"][0]["equity"] == pytest.approx(1000.0)
    assert stats["equity_curve"][1]["equity"] == pytest.approx(1004.0)
    assert stats["equity_curve"][2]["equity"] == pytest.approx(999.0)
    assert stats["max_drawdown_pct"] == pytest.approx((999 / 1004 - 1) * 100, abs=0.01)


def test_build_report_includes_actual_open_autopilot_trade_count(monkeypatch):
    closed = [_autotrade(1, pnl=2.0, notional=100.0)]
    opened = [_autotrade(2, status="OPEN", pnl=0.0, notional=200.0, closed_at=None)]
    monkeypatch.setattr(autopilot, "_closed_autopilot_trades", lambda **kwargs: closed)
    monkeypatch.setattr(autopilot, "_open_autopilot_trades", lambda **kwargs: opened)
    monkeypatch.setattr(paper_live, "get_state", lambda refresh_quotes=False: {"account": {"equity": 1002.0}})
    monkeypatch.setattr(autopilot, "_watchlist_view", lambda: {"symbols": []})
    monkeypatch.setattr(autopilot, "_CONFIG", dict(autopilot.DEFAULT_CONFIG))

    report = autopilot.build_report("full")
    assert report["stats"]["closed_trades"] == 1
    assert report["stats"]["open_trades"] == 1
    assert "1 موقعیت باز" in report["narrative"]


def test_csv_return_pct_uses_position_notional(monkeypatch):
    rows = [_autotrade(1, pnl=4.0, notional=200.0, entry=100.0)]
    monkeypatch.setattr(autopilot, "_closed_autopilot_trades", lambda **kwargs: rows)
    out = autopilot.autopilot_trades_csv()
    parsed = list(csv.DictReader(io.StringIO(out)))
    assert len(parsed) == 1
    assert float(parsed[0]["return_pct"]) == pytest.approx(2.0)


def test_open_position_refresh_stays_on_exact_entry_exchange(monkeypatch):
    calls = []

    def fake_fetch(exchange, symbol, market):
        calls.append(exchange)
        if exchange in {"binance", "bybit", "okx"}:
            return {"symbol": symbol, "market": market, "exchange": exchange,
                    "price": 100.0, "timestamp": "2026-11-19T00:00:00+00:00"}
        raise AssertionError("AUTO entry should query only its first three consensus venues")

    monkeypatch.setattr(paper_live, "_fetch_one", fake_fetch)
    # This case verifies the pinned ticker fallback, not historical candle replay.
    monkeypatch.setattr(paper_live, "fetch_pinned_closed_candles_complete", lambda row: [])
    opened = paper_live.open_position("ETHUSDT", "LONG", "spot", "auto")
    assert opened["exchange"] == "binance"
    assert calls[:3] == ["binance", "bybit", "okx"]
    paper_live._CACHE.clear()
    calls.clear()
    state = paper_live.get_state(refresh_quotes=True)
    assert calls == ["binance"]
    assert state["open_positions"][0]["quote_status"] == "LIVE"
    assert state["open_positions"][0]["live_exchange"] == "binance"


def test_report_curve_has_baseline_even_with_no_closed_trades():
    stats = autopilot._stats_from_trades([], open_trades=[], starting_equity=1000.0)
    assert stats["equity_curve"] == [{"ts": None, "equity": 1000.0, "kind": "START"}]
    assert stats["max_drawdown_pct"] == 0.0


def test_disconnected_pinned_quote_has_no_unrealized_pnl_and_blocks_free_balance(monkeypatch):
    calls = {"btc": 0}

    def fake_fetch(exchange, symbol, market):
        if exchange == "binance" and symbol == "BTCUSDT":
            calls["btc"] += 1
            if calls["btc"] > 1:
                raise RuntimeError("exchange unavailable")
        return {"symbol": symbol, "market": market, "exchange": exchange,
                "price": 100.0, "timestamp": "2026-11-19T00:00:00+00:00"}

    monkeypatch.setattr(paper_live, "_fetch_one", fake_fetch)
    paper_live.open_position("BTCUSDT", "LONG", "spot", "binance")
    paper_live._CACHE.clear()
    state = paper_live.get_state(refresh_quotes=True)

    position = state["open_positions"][0]
    assert position["quote_status"] == "DISCONNECTED"
    assert position["unrealized_net_pnl"] is None
    assert state["account"]["quote_health"] == "DEGRADED"
    assert state["account"]["unrealized_pnl_complete"] is False
    assert state["account"]["disconnected_positions"] == 1
    assert state["account"]["available_balance"] is None


def test_new_entry_is_blocked_when_existing_position_quote_is_disconnected(monkeypatch):
    def fake_fetch(exchange, symbol, market):
        if symbol == "BTCUSDT":
            raise RuntimeError("pinned venue unavailable")
        return {"symbol": symbol, "market": market, "exchange": exchange,
                "price": 100.0, "timestamp": "2026-11-19T00:00:00+00:00"}

    monkeypatch.setattr(paper_live, "_fetch_one", fake_fetch)
    # Create the existing position while its first quote is available.
    calls = {"btc": 0}

    def first_quote_then_disconnect(exchange, symbol, market):
        if symbol == "BTCUSDT":
            calls["btc"] += 1
            if calls["btc"] > 1:
                raise RuntimeError("pinned venue unavailable")
        return {"symbol": symbol, "market": market, "exchange": exchange,
                "price": 100.0, "timestamp": "2026-11-19T00:00:00+00:00"}

    monkeypatch.setattr(paper_live, "_fetch_one", first_quote_then_disconnect)
    paper_live.open_position("BTCUSDT", "LONG", "spot", "binance")
    with pytest.raises(ValueError, match="قیمت یک موقعیت باز"):
        paper_live.open_position("ETHUSDT", "LONG", "spot", "binance")
    assert len(paper_live.list_trades(status="OPEN", limit=None)) == 1


def test_refreshed_quote_timestamp_is_persisted_as_epoch_seconds(monkeypatch):
    monkeypatch.setattr(paper_live, "_fetch_one", lambda exchange, symbol, market: {
        "symbol": symbol, "market": market, "exchange": exchange,
        "price": 100.0, "timestamp": "2026-11-19T00:00:00+00:00",
    })
    paper_live.open_position("BTCUSDT", "LONG", "spot", "binance")
    paper_live._CACHE.clear()
    state = paper_live.get_state(refresh_quotes=True)
    last_price_at = state["open_positions"][0]["last_price_at"]
    assert isinstance(last_price_at, float)
    assert last_price_at > 1_700_000_000


def test_network_quote_is_fetched_without_holding_database_write_lock(monkeypatch):
    import sqlite3

    paper_live.init_db()
    db_path = paper_live._db_path()
    seen = {"write_lock_acquired": False}

    def fake_fetch(exchange, symbol, market):
        # The quote callback can acquire a SQLite write transaction. This would
        # fail under a read-to-write upgrade if get_state held its DB snapshot
        # open across the network request in rollback-journal mode.
        with sqlite3.connect(db_path, timeout=1) as other:
            other.execute("BEGIN IMMEDIATE")
            other.execute("INSERT INTO paper_live_meta(key,value) VALUES('quote_probe','ok') "
                          "ON CONFLICT(key) DO UPDATE SET value=excluded.value")
            seen["write_lock_acquired"] = True
            other.commit()
        return {"symbol": symbol, "market": market, "exchange": exchange,
                "price": 100.0, "timestamp": "2026-11-19T00:00:00+00:00"}

    monkeypatch.setattr(paper_live, "_fetch_one", fake_fetch)
    monkeypatch.setattr(paper_live, "fetch_pinned_closed_candles_complete", lambda row: [])
    paper_live.open_position("BTCUSDT", "LONG", "spot", "binance")
    paper_live._CACHE.clear()
    state = paper_live.get_state(refresh_quotes=True)
    assert seen["write_lock_acquired"] is True
    assert state["open_positions"][0]["quote_status"] == "LIVE"


def test_manual_close_uses_fresh_quote_from_entry_exchange(monkeypatch):
    calls = []

    def fake_fetch(exchange, symbol, market):
        calls.append((exchange, symbol, market))
        return {"symbol": symbol, "market": market, "exchange": exchange,
                "price": 101.0, "timestamp": "2026-11-19T00:00:00+00:00"}

    monkeypatch.setattr(paper_live, "_fetch_one", fake_fetch)
    opened = paper_live.open_position("BTCUSDT", "LONG", "spot", "auto")
    paper_live._CACHE.clear()
    closed = paper_live.close_position(opened["id"])
    assert calls[-1] == ("binance", "BTCUSDT", "spot")
    assert closed["status"] == "CLOSED"
    assert closed["quote"]["exchange"] == opened["exchange"]


def test_unrefreshed_open_positions_do_not_report_partial_equity_as_final(monkeypatch):
    monkeypatch.setattr(paper_live, "_fetch_one", lambda exchange, symbol, market: {
        "symbol": symbol, "market": market, "exchange": exchange,
        "price": 100.0, "timestamp": "2026-11-19T00:00:00+00:00",
    })
    paper_live.open_position("BTCUSDT", "LONG", "spot", "binance")
    state = paper_live.get_state(refresh_quotes=False)
    account = state["account"]
    assert account["quote_health"] == "NOT_REFRESHED"
    assert account["unrealized_pnl_complete"] is False
    assert account["equity"] is None
    assert account["available_balance"] is None
    assert account["unrealized_pnl"] is None
    assert account["known_realized_equity"] == pytest.approx(1000.0)


def test_older_concurrent_quote_cannot_overwrite_newer_persisted_mark(monkeypatch):
    import sqlite3
    import time

    calls = {"count": 0}
    def fake_fetch(exchange, symbol, market):
        calls["count"] += 1
        return {"symbol": symbol, "market": market, "exchange": exchange,
                "price": 100.0 if calls["count"] == 1 else 90.0,
                "timestamp": "2026-11-19T00:00:00+00:00"}
    monkeypatch.setattr(paper_live, "_fetch_one", fake_fetch)
    opened = paper_live.open_position("BTCUSDT", "LONG", "spot", "binance")
    with sqlite3.connect(paper_live._db_path()) as c:
        c.execute("UPDATE paper_live_trades SET last_price=?,last_price_at=? WHERE id=?",
                  (102.0, time.time() + 20.0, opened["id"]))
    paper_live._CACHE.clear()
    state = paper_live.get_state(refresh_quotes=True)
    position = state["open_positions"][0]
    assert position["status"] == "OPEN"
    assert position["last_price"] == pytest.approx(102.0)
    assert position["quote_mark_source"] == "newer_persisted_mark"


def test_failed_older_refresh_keeps_newer_persisted_pinned_mark(monkeypatch):
    import sqlite3
    import time

    calls = {"count": 0}
    def fake_fetch(exchange, symbol, market):
        calls["count"] += 1
        if calls["count"] > 1:
            raise RuntimeError("late refresh failed")
        return {"symbol": symbol, "market": market, "exchange": exchange,
                "price": 100.0, "timestamp": "2026-11-19T00:00:00+00:00"}

    monkeypatch.setattr(paper_live, "_fetch_one", fake_fetch)
    opened = paper_live.open_position("BTCUSDT", "LONG", "spot", "binance")
    with sqlite3.connect(paper_live._db_path()) as c:
        c.execute("UPDATE paper_live_trades SET last_price=?,last_price_at=? WHERE id=?",
                  (101.0, time.time() + 20.0, opened["id"]))
    paper_live._CACHE.clear()
    state = paper_live.get_state(refresh_quotes=True)
    position = state["open_positions"][0]
    assert position["quote_status"] == "LIVE"
    assert position["last_price"] == pytest.approx(101.0)
    assert position["quote_mark_source"] == "newer_persisted_mark"
    assert position["unrealized_net_pnl"] is not None
