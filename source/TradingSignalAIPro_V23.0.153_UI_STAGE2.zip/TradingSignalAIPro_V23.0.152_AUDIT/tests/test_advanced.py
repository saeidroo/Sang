import numpy as np
import pandas as pd
from backend.advanced import market_regime, multi_horizon_outlook, detect_patterns, early_trend_change, strategy_lab, risk_plan


def frame(n=500):
    x=np.arange(n); close=100*np.exp(0.0008*x + 0.01*np.sin(x/8))
    return pd.DataFrame({'open':close*.999,'high':close*1.01,'low':close*.99,'close':close,'volume':1000})


def test_regime_and_horizons():
    d=frame(); assert market_regime(d)['regime'] in ('bull','bear','sideways','high_volatility')
    assert len(multi_horizon_outlook(d)['outlooks'])==4


def test_patterns_and_trend():
    d=frame(); assert isinstance(detect_patterns(d),list)
    assert 'state' in early_trend_change(d)


def test_strategy_lab_holdout():
    r=strategy_lab(frame()); assert len(r['results'])==3 and r['holdout_bars']>0


def test_risk_plan():
    r=risk_plan(10000,1,100,95); assert r['risk_cash']==100 and r['position_quantity']==20
