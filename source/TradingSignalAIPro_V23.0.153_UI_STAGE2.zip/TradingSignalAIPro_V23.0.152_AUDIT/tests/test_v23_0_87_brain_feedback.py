from backend import market_brain as brain


def test_forecast_feedback_is_saved_and_resolved_from_later_prices(tmp_path, monkeypatch):
    monkeypatch.setattr(brain, 'FEEDBACK_DB_PATH', tmp_path / 'feedback.sqlite3')
    item = {
        'symbol': 'ABCUSDT', 'price': 100.0,
        'brain_prediction': {'status': 'historical_analogs', 'horizons': {
            '1h': {'up_pct': 70, 'down_pct': 10},
            '4h': {'up_pct': 60, 'down_pct': 20},
            '24h': {'up_pct': 55, 'down_pct': 25},
        }}
    }
    first = brain.record_feedback([item], snapshots={}, now=1_000_000)
    assert first['forecasts_total'] == 3
    assert first['pending'] == 3
    second = brain.record_feedback([], snapshots={'ABC': {'price': 102.0}}, now=1_003_700)
    assert second['resolved_now'] == 1
    summary = brain.feedback_summary()
    assert summary['horizons']['1h']['resolved'] == 1
    assert summary['horizons']['1h']['up'] == 1
    assert summary['horizons']['4h']['resolved'] == 0


def test_missing_late_observation_is_not_counted_as_success(tmp_path, monkeypatch):
    monkeypatch.setattr(brain, 'FEEDBACK_DB_PATH', tmp_path / 'feedback.sqlite3')
    item = {'symbol': 'ABCUSDT', 'price': 100.0,
            'brain_prediction': {'status': 'historical_analogs', 'horizons': {
                h: {'up_pct': 60, 'down_pct': 20} for h in ('1h', '4h', '24h')}}}
    brain.record_feedback([item], now=1_000_000)
    result = brain.record_feedback([], snapshots={'ABC': {'price': 120}}, now=1_200_000)
    assert result['resolved_now'] == 0
    assert result['pending'] == 0
    assert brain.feedback_summary()['horizons']['1h']['resolved'] == 0
