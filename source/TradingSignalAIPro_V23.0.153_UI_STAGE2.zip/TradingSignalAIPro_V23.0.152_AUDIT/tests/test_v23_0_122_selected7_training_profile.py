from pathlib import Path

from backend import longrun


def test_selected7_backend_preset_is_exact_and_valid():
    expected = [
        "BTCUSDT", "XAUUSD", "ETHUSDT", "DOGEUSDT",
        "ICPUSDT", "LINKUSDT", "SOLUSDT",
    ]
    assert longrun.PRESETS["selected7"] == expected
    cfg = longrun.normalize_config({"preset": "selected7", "timeframes": ["1h", "4h"]})
    assert cfg["symbols"] == expected
    assert cfg["timeframes"] == ["1h", "4h"]


def test_selected7_ui_profile_sets_requested_assets_and_training_budget():
    root = Path(__file__).resolve().parents[1]
    js = (root / "frontend" / "app.js").read_text(encoding="utf-8")
    html = (root / "frontend" / "index.html").read_text(encoding="utf-8")
    expected = ["BTCUSDT", "XAUUSD", "ETHUSDT", "DOGEUSDT", "ICPUSDT", "LINKUSDT", "SOLUSDT"]
    assert "selected7" in js and 'data-preset="selected7"' in html
    for symbol in expected:
        assert symbol in js
    assert "['1h','4h']" in js
    assert "$('lrHours').value='8'" in js
    assert "$('lrLimit').value='10000'" in js
    assert "$('lrTrials').value='24'" in js
