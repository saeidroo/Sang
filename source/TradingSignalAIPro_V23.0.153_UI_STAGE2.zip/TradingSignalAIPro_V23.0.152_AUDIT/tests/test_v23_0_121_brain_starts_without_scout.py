from backend import scout


def test_historical_brain_starts_even_when_live_scout_is_disabled(monkeypatch):
    calls = []
    monkeypatch.setenv('SCOUT_ENABLED', '0')
    monkeypatch.setattr('backend.market_brain.start_startup_learning',
                        lambda: calls.append('started') or True)

    # The live scanner remains disabled, but historical learning is independent.
    assert scout.start_background() is False
    assert calls == ['started']
