import time
from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest

from backend import data
from backend.data_contract import DataContractError
from backend.signal import compute_signal
from backend.trainer import validate_training_batch


def fresh_frame(n=260, tf='1h'):
    step = data.TIMEFRAME_SECONDS[tf] * 1000
    now = int(time.time() * 1000)
    base = (now // step) * step - n * step
    return pd.DataFrame([
        {'t': base + i * step, 'open': 100 + i, 'high': 103 + i,
         'low': 99 + i, 'close': 102 + i, 'volume': 10.0}
        for i in range(n)
    ])


def test_data_engine_attaches_contract_and_accepts_fresh_provider():
    frame = fresh_frame()
    with patch.dict(data.SOURCE_FUNCS, {'bybit': lambda *a, **k: frame.copy()}), \
         patch.object(data, '_save_cache'):
        out = data.fetch_candles('BTCUSDT', '1h', 250, 'bybit',
                                 validation_mode='paper', max_age_bars=2)
    assert out.attrs['data_contract']['status'] == 'PASS'
    assert out.attrs['source'] == 'bybit'


def test_data_engine_rejects_stale_cache_in_paper_mode():
    frame = fresh_frame()
    with patch.dict(data.SOURCE_FUNCS, {'bybit': lambda *a, **k: (_ for _ in ()).throw(RuntimeError('offline'))}), \
         patch.object(data, '_load_cache', lambda *a, **k: frame.copy()):
        with pytest.raises(DataContractError):
            data.fetch_candles('BTCUSDT', '1h', 250, 'bybit',
                               validation_mode='paper', max_age_bars=2)


def test_data_engine_accepts_exact_duplicate_cleanup_in_research():
    frame = fresh_frame()
    rows = frame.to_dict('records')
    rows.append(dict(rows[10]))  # identical repeated candle is safe to collapse
    raw = pd.DataFrame(rows)
    with patch.dict(data.SOURCE_FUNCS, {'bybit': lambda *a, **k: raw.copy()}), \
         patch.object(data, '_save_cache'):
        out = data.fetch_candles('BTCUSDT', '1h', 250, 'bybit', validation_mode='research')
    report = out.attrs['data_contract']
    assert report['status'] == 'PASS'
    assert report['normalization_summary']['duplicate_rows_dropped'] == 1
    assert report['normalization_summary']['duplicate_conflict_groups'] == 0
    assert report['normalization_notes']
    assert len(out) == 250


def test_data_engine_accepts_exact_duplicate_cleanup_in_paper_mode():
    frame = fresh_frame()
    rows = frame.to_dict('records')
    rows.append(dict(rows[10]))
    raw = pd.DataFrame(rows)
    with patch.dict(data.SOURCE_FUNCS, {'bybit': lambda *a, **k: raw.copy()}), \
         patch.object(data, '_save_cache'):
        out = data.fetch_candles('BTCUSDT', '1h', 250, 'bybit',
                                 validation_mode='paper', max_age_bars=2)
    assert out.attrs['data_contract']['status'] == 'PASS'
    assert out.attrs['data_contract']['normalization_summary']['duplicate_rows_dropped'] == 1


def test_data_engine_accepts_reverse_order_after_safe_sort_in_paper_mode():
    frame = fresh_frame()
    reversed_frame = frame.iloc[::-1].reset_index(drop=True)
    with patch.dict(data.SOURCE_FUNCS, {'bybit': lambda *a, **k: reversed_frame.copy()}), \
         patch.object(data, '_save_cache'):
        out = data.fetch_candles('BTCUSDT', '1h', 250, 'bybit',
                                 validation_mode='paper', max_age_bars=2)
    report = out.attrs['data_contract']
    assert report['status'] == 'PASS'
    assert report['normalization_summary']['reordered'] is True
    assert out['t'].is_monotonic_increasing


def test_data_engine_warns_about_conflicting_duplicate_in_research():
    frame = fresh_frame()
    rows = frame.to_dict('records')
    conflicting = dict(rows[10])
    conflicting['close'] = float(conflicting['close']) - 0.25
    rows.append(conflicting)
    raw = pd.DataFrame(rows)
    with patch.dict(data.SOURCE_FUNCS, {'bybit': lambda *a, **k: raw.copy()}), \
         patch.object(data, '_save_cache'):
        out = data.fetch_candles('BTCUSDT', '1h', 250, 'bybit', validation_mode='research')
    report = out.attrs['data_contract']
    assert report['status'] == 'WARN'
    assert report['normalization_summary']['duplicate_conflict_groups'] == 1


def test_data_engine_still_rejects_conflicting_duplicate_in_paper_mode():
    frame = fresh_frame()
    rows = frame.to_dict('records')
    conflicting = dict(rows[10])
    conflicting['close'] = float(conflicting['close']) - 0.25
    rows.append(conflicting)
    raw = pd.DataFrame(rows)
    with patch.dict(data.SOURCE_FUNCS, {'bybit': lambda *a, **k: raw.copy()}), \
         patch.object(data, '_load_cache', lambda *a, **k: None):
        with pytest.raises(RuntimeError, match='Data Contract'):
            data.fetch_candles('BTCUSDT', '1h', 250, 'bybit',
                               validation_mode='paper', max_age_bars=2)


def test_data_engine_warns_for_small_amount_of_malformed_rows_in_research():
    frame = fresh_frame()
    rows = frame.to_dict('records')
    rows[10]['high'] = rows[10]['open'] - 1
    raw = pd.DataFrame(rows)
    with patch.dict(data.SOURCE_FUNCS, {'bybit': lambda *a, **k: raw.copy()}), \
         patch.object(data, '_save_cache'):
        out = data.fetch_candles('BTCUSDT', '1h', 250, 'bybit', validation_mode='research')
    assert out.attrs['data_contract']['status'] == 'WARN'
    assert out.attrs['data_contract']['normalization_summary']['malformed_rows_dropped'] == 1


def test_data_engine_blocks_materially_damaged_research_batch():
    frame = fresh_frame(n=400)
    rows = frame.to_dict('records')
    for row in rows[:30]:
        row['high'] = row['open'] - 1
    raw = pd.DataFrame(rows)
    with patch.dict(data.SOURCE_FUNCS, {'bybit': lambda *a, **k: raw.copy()}), \
         patch.object(data, '_load_cache', lambda *a, **k: None):
        with pytest.raises(RuntimeError, match='normalizer_removed_too_many_rows'):
            data.fetch_candles('BTCUSDT', '1h', 250, 'bybit', validation_mode='research')

def test_trainer_rejects_gaps_even_in_research_mode():
    frame = fresh_frame()
    frame = frame.drop(index=100).reset_index(drop=True)
    with pytest.raises(DataContractError, match='فقط PASS'):
        validate_training_batch(frame, 'BTCUSDT', '1h', 'history')


def test_trainer_rejects_missing_volume():
    frame = fresh_frame()
    frame['volume'] = np.nan
    with pytest.raises(DataContractError, match='حجم ناقص'):
        validate_training_batch(frame, 'BTCUSDT', '1h', 'history')


def test_trainer_accepts_clean_contiguous_batch():
    frame = fresh_frame()
    clean, report = validate_training_batch(frame, 'BTCUSDT', '1h', 'history')
    assert len(clean) == len(frame)
    assert report['status'] == 'PASS'


def test_trainer_accepts_safely_normalized_order_and_exact_duplicates():
    frame = fresh_frame()
    rows = frame.to_dict('records')
    rows.append(dict(rows[15]))
    normalized = data._clean_candles(list(reversed(rows)))
    clean, report = validate_training_batch(normalized, 'BTCUSDT', '1h', 'history')
    assert len(clean) == len(frame)
    assert report['status'] == 'PASS'


def test_signal_engine_fails_closed_on_warn_report():
    report = {'status': 'WARN', 'warnings': ['internal_gaps:1'], 'block_reasons': []}
    signal = compute_signal(pd.DataFrame(), 0.72, data_contract_report=report)
    assert signal['kind'] == 'HOLD'
    assert signal['data_blocked'] is True

