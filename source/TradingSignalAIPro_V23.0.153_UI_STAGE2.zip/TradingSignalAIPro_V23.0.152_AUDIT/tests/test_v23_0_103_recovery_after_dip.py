from backend import storm_learning as sl


def test_delayed_pump_after_observed_interim_dip_is_reported(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'recovery.sqlite3')
    base = 1_730_000_000
    sl.record_scan([{'symbol': 'RECUSDT', 'price': 100, 'score': 74,
                     'phase': 'early', 'direction': 'up', 'verified': True}], timestamp=base)
    # Real recorded snapshots show a 5% dip, then a 12% gain by day three.
    sl.record_scan([], timestamp=base + 86400, snapshots={'REC': {'price': 95}})
    sl.record_scan([], timestamp=base + 3 * 86400, snapshots={'REC': {'price': 112}})
    report = sl.followups()
    event = next(x for x in report['events'] if x['horizon'] == '3d')
    assert event['delayed_pump'] is True
    assert event['recovered_after_dip'] is True
    assert event['observed_max_drawdown_pct'] == -5.0
    assert len(report['recovered_after_dip']) == 1


def test_delayed_pump_without_observed_dip_is_not_recovery(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'no_dip.sqlite3')
    base = 1_740_000_000
    sl.record_scan([{'symbol': 'NODIPUSDT', 'price': 100, 'score': 70,
                     'phase': 'early', 'direction': 'up', 'verified': True}], timestamp=base)
    sl.record_scan([], timestamp=base + 3 * 86400, snapshots={'NODIP': {'price': 112}})
    report = sl.followups()
    event = next(x for x in report['events'] if x['horizon'] == '3d')
    assert event['delayed_pump'] is True
    assert event['recovered_after_dip'] is False
    assert report['recovered_after_dip'] == []
