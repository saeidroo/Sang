import numpy as np
import pandas as pd
from backend.scout import compression_features, candle_features


def frame(kind='normal', n=180):
    rng = np.random.default_rng(41)
    close = 100 + np.cumsum(rng.normal(0, .22, n))
    high = close + .18
    low = close - .18
    volume = np.full(n, 1000.0)
    if kind in ('squeeze', 'no_volume', 'fakeout', 'valid'):
        # A quiet, sustained coil in the final 16 pre-release bars.
        center = close[-20]
        close[-20:-4] = center + rng.normal(0, .012, 16)
        high[-20:-4] = close[-20:-4] + .025
        low[-20:-4] = close[-20:-4] - .025
        volume[-20:-4] = 700
        if kind == 'valid':
            close[-4:] = center + np.array([.03, .07, .11, .34])
            high[-4:] = close[-4:] + .05
            low[-4:] = close[-4:] - .04
            volume[-4:] = 2600
        elif kind == 'no_volume':
            close[-4:] = center + np.array([.03, .07, .11, .34])
            high[-4:] = close[-4:] + .05
            low[-4:] = close[-4:] - .04
            volume[-4:] = 700
        elif kind == 'fakeout':
            close[-4:] = center + np.array([.03, .07, .11, .12])
            high[-4:] = close[-4:] + .45
            low[-4:] = close[-4:] - .03
            volume[-4:] = 2600
    return pd.DataFrame({'high': high, 'low': low, 'close': close, 'volume': volume})


def test_short_history_fails_closed():
    assert compression_features(frame(n=100))['squeeze_release'] is False
    assert candle_features(frame(n=100)) is None


def test_no_compression_not_promoted():
    x = compression_features(frame('normal'))
    assert not x['squeeze_release']


def test_compression_without_release_is_not_signal():
    x = compression_features(frame('squeeze'))
    assert x['compression_duration_bars'] >= 6
    assert not x['release_confirmed']


def test_release_without_volume_is_not_confirmed():
    x = compression_features(frame('no_volume'))
    assert x['release_volume_ratio'] < 1.8
    assert not x['release_confirmed']


def test_valid_squeeze_release_confirmed():
    x = compression_features(frame('valid'))
    assert x['compression_quality'] >= .35
    assert x['release_confirmed']
    assert x['squeeze_release']


def test_wick_rejection_fakeout_not_confirmed():
    x = compression_features(frame('fakeout'))
    assert not x['release_confirmed']
    assert x['fakeout_risk'] > .62


def test_flat_or_zero_volume_fails_closed():
    d = frame('valid')
    d['high'] = 100
    d['low'] = 100
    d['close'] = 100
    d['volume'] = 0
    assert not compression_features(d)['release_confirmed']


def test_nan_and_future_append_do_not_change_past_result():
    d = frame('valid')
    a = compression_features(d)
    d2 = pd.concat([d, pd.DataFrame({'high':[500], 'low':[499], 'close':[500], 'volume':[999999]})], ignore_index=True)
    b = compression_features(d2.iloc[:-1])
    assert a == b
    d.loc[179, 'close'] = np.nan
    assert not compression_features(d)['release_confirmed']
