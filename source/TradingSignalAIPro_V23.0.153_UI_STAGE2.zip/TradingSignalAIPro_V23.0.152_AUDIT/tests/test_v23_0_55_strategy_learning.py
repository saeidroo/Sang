from backend.strategy_learning import rank_strategy_performance


def test_groups_are_scoped_by_strategy_and_market_dimensions():
    rows = [dict(strategy='alpha', symbol='BTCUSDT', market='spot', timeframe='1h', side='LONG', net_pnl=2, return_pct=1, context_json='{"strategy":"alpha"}') for _ in range(12)]
    rows += [dict(symbol='BTCUSDT', market='perp', timeframe='1h', side='LONG', net_pnl=-1, return_pct=-.5, context_json='{"strategy":"beta"}') for _ in range(12)]
    result = rank_strategy_performance(rows, min_samples=10)
    assert result['group_count'] == 2
    assert result['groups'][0]['strategy'] == 'alpha'
    assert result['groups'][0]['learning_state'] == 'REVIEWABLE'
    assert result['groups'][1]['learning_state'] == 'NO_POSITIVE_EDGE'


def test_small_sample_is_collecting_and_never_authorizes_entry():
    rows = [dict(symbol='ETHUSDT', market='spot', timeframe='15m', side='LONG', net_pnl=5, return_pct=1, context_json='{}')]
    result = rank_strategy_performance(rows)
    assert result['groups'][0]['learning_state'] == 'COLLECTING'
    assert result['groups'][0]['ranking_score'] is None
    assert result['authorizes_entries'] is False
    assert result['real_orders_enabled'] is False


def test_bad_or_nonfinite_rows_are_ignored():
    rows = [dict(net_pnl='nan', return_pct=1), dict(net_pnl=1, return_pct=1, context_json='bad')]
    result = rank_strategy_performance(rows, min_samples=1)
    assert result['event_count'] == 1
    assert result['groups'][0]['strategy'] == 'UNATTRIBUTED'
