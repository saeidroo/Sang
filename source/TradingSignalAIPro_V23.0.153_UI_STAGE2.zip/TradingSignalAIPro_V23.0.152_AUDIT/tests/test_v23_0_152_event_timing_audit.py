import sqlite3
from pathlib import Path

import pytest

from backend.event_timing_audit import audit_event_timing


def make_db(path: Path):
    con = sqlite3.connect(path)
    con.executescript('''
    CREATE TABLE scout_sightings(id INTEGER PRIMARY KEY,symbol TEXT,ts REAL,price REAL,direction TEXT);
    CREATE TABLE scout_outcomes(id INTEGER PRIMARY KEY,sighting_id INTEGER,horizon TEXT,due_ts REAL,resolved_ts REAL,result TEXT);
    CREATE TABLE scout_price_observations(id INTEGER PRIMARY KEY,symbol TEXT,ts REAL,price REAL);
    ''')
    events = [
        (1, 'UP1', 'up', 101.2),       # favorable first after 30m
        (2, 'UP2', 'up', 98.8),        # adverse first after 30m
        (3, 'DOWN1', 'down', 98.7),    # favorable first after 60m
        (4, 'DOWN2', 'down', 101.3),   # adverse first after 30m
        (5, 'FLAT', 'up', 100.2),      # no touch
    ]
    for sid, symbol, direction, final in events:
        con.execute('INSERT INTO scout_sightings VALUES(?,?,?,?,?)', (sid, symbol, 1000, 100, direction))
        con.execute('INSERT INTO scout_outcomes VALUES(?,?,?,?,?,?)', (sid, sid, '24h', 87400, 87401, 'success'))
        if symbol == 'DOWN1':
            con.execute('INSERT INTO scout_price_observations VALUES(?,?,?,?)', (sid, symbol, 4600, 99.5))
            con.execute('INSERT INTO scout_price_observations VALUES(?,?,?,?)', (sid+10, symbol, 8200, final))
        elif symbol == 'FLAT':
            con.execute('INSERT INTO scout_price_observations VALUES(?,?,?,?)', (sid, symbol, 4600, final))
        else:
            con.execute('INSERT INTO scout_price_observations VALUES(?,?,?,?)', (sid, symbol, 2800, final))
    con.commit()
    con.close()


def test_reports_directional_first_touch_and_latency(tmp_path):
    db = tmp_path / 'learning.sqlite3'
    make_db(db)
    result = audit_event_timing(db, threshold_pct=1.0, min_samples=2)
    assert result['status'] == 'ok'
    assert result['is_forecast'] is False
    assert result['ranking_effect'] == 0.0
    assert result['directions']['up']['favorable_first'] == 1
    assert result['directions']['up']['adverse_first'] == 1
    assert result['directions']['up']['no_threshold_touch'] == 1
    assert result['directions']['down']['favorable_first'] == 1
    assert result['directions']['down']['adverse_first'] == 1
    assert result['directions']['down']['median_minutes_to_favorable'] == 120.0


def test_missing_archive_and_validation_are_safe(tmp_path):
    result = audit_event_timing(tmp_path / 'missing.sqlite3')
    assert result['status'] == 'no_archive'
    assert result['ranking_effect'] == 0.0
    with pytest.raises(ValueError):
        audit_event_timing(tmp_path / 'missing.sqlite3', horizon='10m')
    with pytest.raises(ValueError):
        audit_event_timing(tmp_path / 'missing.sqlite3', threshold_pct=50)


def test_archive_is_not_modified(tmp_path):
    db = tmp_path / 'learning.sqlite3'
    make_db(db)
    before = db.read_bytes()
    audit_event_timing(db)
    assert db.read_bytes() == before
