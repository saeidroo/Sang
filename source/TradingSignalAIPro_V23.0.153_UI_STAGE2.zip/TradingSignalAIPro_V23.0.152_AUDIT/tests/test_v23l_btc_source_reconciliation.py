import pytest
from backend.btc_source_reconciliation import reconcile_candles, require_reconciliation_clear
from backend.btc_ingestion_store import append_ingestion
from backend.btc_walkforward import FOUR_HOURS_MS

def rows(a=10,b=15):
    return [{"t":i*FOUR_HOURS_MS,"open":100.+i,"high":102.+i,"low":99.+i,"close":101.+i,"volume":20.} for i in range(a,b+1)]

def test_clean_increment_is_pass():
    r=reconcile_candles(rows(),rows(10,18))
    assert r["status"]=="PASS" and r["added_count"]==3
    assert require_reconciliation_clear({**r,"training_allowed":True})

def test_historical_revision_blocks_training():
    changed=rows(); changed[2]["close"] += .01
    r=reconcile_candles(rows(),changed)
    assert r["status"]=="BLOCKED" and r["revision_count"]==1
    with pytest.raises(ValueError,match="btc_source_drift_blocks_training"):
        require_reconciliation_clear({**r,"training_allowed":False})

def test_removed_history_blocks_training():
    r=reconcile_candles(rows(),rows(11,15))
    assert r["status"]=="BLOCKED" and r["removed_count"]==1

def test_tolerance_is_explicit_and_configurable():
    changed=rows(); changed[0]["close"] += .001
    assert reconcile_candles(rows(),changed,abs_tolerance=.002)["status"]=="PASS"
    assert reconcile_candles(rows(),changed)["status"]=="BLOCKED"

def test_duplicate_and_invalid_tolerance_rejected():
    x=rows(); x.append(x[0])
    with pytest.raises(ValueError,match="duplicate_timestamp"):
        reconcile_candles(rows(),x)
    with pytest.raises(ValueError,match="tolerances"):
        reconcile_candles(rows(),rows(),abs_tolerance=-1)

def test_store_reconciliation_persists_report(tmp_path):
    import hashlib,json
    candles=rows()
    raw=json.dumps(candles,sort_keys=True,separators=(",",":"),allow_nan=False)
    batch={"status":"PASS","symbol":"BTCUSDT","candles":candles,"data_sha256":hashlib.sha256(raw.encode()).hexdigest()}
    append_ingestion(tmp_path,batch)
    from backend.btc_source_reconciliation import reconcile_store
    current=rows(); current[-1]["close"] += 2
    report=reconcile_store(tmp_path,snapshot=current)
    assert report["status"]=="BLOCKED"
    assert list((tmp_path/"reconciliation").glob("*.json"))
