import pytest
from backend.strategy_learning import rank_strategy_performance, recommend_strategy_for_context


def _row(pnl, strategy='alpha', regime='BULLISH', vol='LOW'):
    import json
    return {'symbol':'BTCUSDT','market':'perp','timeframe':'1h','side':'LONG',
            'net_pnl':pnl,'return_pct':pnl/10,
            'context_json':json.dumps({'strategy':strategy,'market_regime':regime,'volatility_regime':vol})}


def test_recommendation_requires_exact_six_dimension_match_and_minimum_evidence():
    rows = [_row(2) for _ in range(12)] + [_row(-2, regime='RANGING') for _ in range(12)]
    ranking = rank_strategy_performance(rows, min_samples=10)
    result = recommend_strategy_for_context(ranking, symbol='BTC/USDT', market='perp',
        timeframe='1h', side='LONG', market_regime='BULLISH', volatility_regime='LOW', min_samples=10)
    assert result['state'] == 'SHADOW_CANDIDATE'
    assert result['recommendation']['strategy'] == 'alpha'
    assert result['candidate_count'] == 1
    assert result['authorizes_entries'] is False
    assert result['real_orders_enabled'] is False


def test_no_cross_regime_or_volatility_fallback():
    ranking = rank_strategy_performance([_row(2) for _ in range(15)], min_samples=5)
    result = recommend_strategy_for_context(ranking, symbol='BTCUSDT', market='perp',
        timeframe='1h', side='LONG', market_regime='BEARISH', volatility_regime='HIGH', min_samples=5)
    assert result['recommendation'] is None
    assert result['state'] == 'COLLECTING_EVIDENCE'
    assert result['cross_regime_fallback'] is False


def test_invalid_context_rejected():
    with pytest.raises(ValueError):
        recommend_strategy_for_context({}, symbol='BTCUSDT', market='margin', timeframe='1h',
            side='LONG', market_regime='BULLISH', volatility_regime='LOW')
