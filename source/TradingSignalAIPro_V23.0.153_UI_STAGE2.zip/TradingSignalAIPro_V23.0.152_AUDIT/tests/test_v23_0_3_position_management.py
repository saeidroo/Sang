"""V23.0.3: independent entry/position-manager lifecycles and safe draining."""
import threading
import time

import pytest
from unittest.mock import patch

from backend import autopilot, paper_live


@pytest.fixture(autouse=True)
def isolate_paper_process_lease(tmp_path, monkeypatch):
    # Lifecycle tests must not share a persistent process-lease database with
    # other test modules or a prior test run.
    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(tmp_path / "paper_live.sqlite3"))
    monkeypatch.setenv("TRADING_AI_MODELS_DIR", str(tmp_path / "models"))


def _reset_state():
    # Stop any worker left by another test before replacing the state handles.
    for key in ("entry_stop_event", "manager_stop_event"):
        event = autopilot._STATE.get(key)
        if event:
            event.set()
    for key in ("entry_thread", "manager_thread"):
        thread = autopilot._STATE.get(key)
        if thread and thread.is_alive():
            thread.join(timeout=1)
    with autopilot._LOCK:
        autopilot._STATE.update({
            "running": False, "thread": None, "entry_thread": None, "manager_thread": None,
            "entry_stop_event": threading.Event(), "manager_stop_event": threading.Event(),
            "stop_event": threading.Event(), "entries_enabled": False, "managing": False,
            "stop_after_flat": False, "started_at": None, "last_manage_at": 0.0,
            "last_entry_scan_at": 0.0, "last_cycle_error": "", "last_manage_error": "",
            "last_entry_error": "", "cycles": 0, "manage_cycles": 0, "entry_cycles": 0,
            "last_closed_check_ts": 0.0,
        })
        autopilot._CONFIG.clear()
        autopilot._CONFIG.update(autopilot.DEFAULT_CONFIG)


def _open_position():
    return {
        "id": 17, "symbol": "BTCUSDT", "market": "spot", "side": "LONG",
        "status": "OPEN", "entry_fill": 100.0, "stop_price": 98.5,
        "target_price": 103.0, "last_price": 100.1,
        "entry_context_json": '{"entry_source":"autopilot"}',
    }


def test_entry_worker_can_stop_while_manager_keeps_running():
    _reset_state()
    manager_called = threading.Event()
    entry_called = threading.Event()

    def fake_manager():
        manager_called.set()
        return {"open_autopilot_positions": 1}

    def fake_entry(*, allow_when_stopped=False):
        entry_called.set()
        return {"evaluated": 1, "opened": 0, "rejected": 0, "skipped": 0}

    with patch.object(autopilot, "_manager_cycle_once", side_effect=fake_manager), \
         patch.object(autopilot, "_entry_cycle_once", side_effect=fake_entry):
        autopilot._STATE["entries_enabled"] = True
        autopilot._STATE["entry_stop_event"] = threading.Event()
        autopilot._STATE["manager_stop_event"] = threading.Event()
        manager = threading.Thread(target=autopilot._manager_loop, daemon=True)
        entry = threading.Thread(target=autopilot._entry_loop, daemon=True)
        autopilot._STATE["manager_thread"] = manager
        autopilot._STATE["entry_thread"] = entry
        autopilot._STATE["managing"] = True
        autopilot._STATE["running"] = True
        manager.start(); entry.start()
        assert manager_called.wait(2)
        assert entry_called.wait(2)
        autopilot._STATE["entries_enabled"] = False
        autopilot._STATE["entry_stop_event"].set()
        entry.join(timeout=2)
        assert not entry.is_alive(), "entry worker should stop independently"
        assert manager.is_alive(), "manager must continue while open positions may exist"
        autopilot._STATE["manager_stop_event"].set()
        manager.join(timeout=2)
        assert not manager.is_alive()


def test_stop_without_close_all_pauses_entries_and_keeps_manager(tmp_path):
    _reset_state()
    position = _open_position()
    with patch.object(paper_live, "get_state", return_value={"open_positions": [position]}), \
         patch.object(autopilot, "_save_config", return_value=None), \
         patch.object(autopilot, "_log_decision", return_value=None), \
         patch.object(autopilot, "_manager_cycle_once", return_value={"open_autopilot_positions": 1}), \
         patch.object(autopilot, "build_report", return_value={"stats": {"trades": 0}}), \
         patch.object(autopilot, "status", return_value={"entries_enabled": False, "managing": True}):
        result = autopilot.stop(close_all=False)
        assert result["entries_stopped"] is True
        assert result["remaining_positions"] == 1
        assert result["managing"] is True
        assert result["full_stop"] is False
        assert autopilot._STATE["entries_enabled"] is False
        manager = autopilot._STATE["manager_thread"]
        assert manager and manager.is_alive()
        autopilot._STATE["manager_stop_event"].set()
        manager.join(timeout=2)
        assert not manager.is_alive()


def test_stop_with_close_all_stops_everything_when_flat():
    _reset_state()
    position = _open_position()
    states = [
        {"open_positions": [position]},
        {"open_positions": []},
    ]
    closed = []

    def fake_state(refresh_quotes=False):
        return states.pop(0) if states else {"open_positions": []}

    def fake_close(trade_id):
        closed.append(trade_id)
        return {"net_pnl": 1.25}

    with patch.object(paper_live, "get_state", side_effect=fake_state), \
         patch.object(paper_live, "close_position", side_effect=fake_close), \
         patch.object(autopilot, "_save_config", return_value=None), \
         patch.object(autopilot, "_log_decision", return_value=None), \
         patch.object(autopilot, "build_report", return_value={"stats": {"trades": 0}}), \
         patch.object(autopilot, "status", return_value={"entries_enabled": False, "managing": False}):
        result = autopilot.stop(close_all=True)
        assert result["closed"] == [{"id": 17, "symbol": "BTCUSDT", "net_pnl": 1.25}]
        assert result["remaining_positions"] == 0
        assert result["full_stop"] is True
        assert closed == [17]
        assert autopilot._STATE["manager_stop_event"].is_set()


def test_close_failure_does_not_abandon_open_position_manager():
    _reset_state()
    position = _open_position()
    with patch.object(paper_live, "get_state", return_value={"open_positions": [position]}), \
         patch.object(paper_live, "close_position", side_effect=RuntimeError("quote unavailable")), \
         patch.object(autopilot, "_save_config", return_value=None), \
         patch.object(autopilot, "_log_decision", return_value=None), \
         patch.object(autopilot, "_manager_cycle_once", return_value={"open_autopilot_positions": 1}), \
         patch.object(autopilot, "build_report", return_value={"stats": {"trades": 0}}), \
         patch.object(autopilot, "status", return_value={"entries_enabled": False, "managing": True}):
        result = autopilot.stop(close_all=True)
        assert result["remaining_positions"] == 1
        assert result["managing"] is True
        manager = autopilot._STATE["manager_thread"]
        assert manager and manager.is_alive()
        autopilot._STATE["manager_stop_event"].set()
        manager.join(timeout=2)
        assert not manager.is_alive()


def test_manual_entry_scan_refuses_to_open_when_entries_paused(monkeypatch):
    _reset_state()
    autopilot._STATE["entries_enabled"] = False
    called = []
    monkeypatch.setattr(autopilot, "_watchlist_view", lambda: {"symbols": ["BTCUSDT"]})
    monkeypatch.setattr(autopilot, "_decide_entry", lambda *a: called.append(a) or {"kind": "BUY"})
    result = autopilot._entry_scan(allow_when_stopped=False)
    assert result["stopped"] is True
    assert result["evaluated"] == 0
    assert called == []


def test_start_can_resume_manager_without_resuming_entries():
    _reset_state()
    manager_ran = threading.Event()

    def fake_manager_cycle():
        manager_ran.set()
        autopilot._finish_manager_when_flat()
        return {"open_autopilot_positions": 0}

    with patch.object(autopilot, "_load_config", return_value=None), \
         patch.object(autopilot, "_save_config", return_value=None), \
         patch.object(autopilot, "_log_decision", return_value=None), \
         patch.object(autopilot, "_manager_cycle_once", side_effect=fake_manager_cycle), \
         patch.object(autopilot, "status", return_value={"entries_enabled": False, "managing": True}):
        result = autopilot.start(resume_entries=False)
        assert result["ok"] is True
        assert autopilot._STATE["entries_enabled"] is False
        assert autopilot._STATE["entry_thread"] is None
        manager = autopilot._STATE["manager_thread"]
        assert manager is not None
        assert manager_ran.wait(2)
        manager.join(timeout=2)
        assert not manager.is_alive()
        assert autopilot._CONFIG["enabled"] is False
        assert autopilot._CONFIG["entries_enabled"] is False


def test_paused_entries_persist_across_restart_while_manager_remains_enabled(tmp_path, monkeypatch):
    import json
    monkeypatch.setenv("TRADING_AI_MODELS_DIR", str(tmp_path / "models"))
    _reset_state()
    with patch.object(paper_live, "get_state", return_value={"open_positions": [_open_position()]}), \
         patch.object(autopilot, "_manager_cycle_once", return_value={"open_autopilot_positions": 1}), \
         patch.object(autopilot, "_log_decision", return_value=None), \
         patch.object(autopilot, "build_report", return_value={"stats": {"trades": 0}}), \
         patch.object(autopilot, "status", return_value={"entries_enabled": False, "managing": True}):
        result = autopilot.stop(close_all=False)
        assert result["remaining_positions"] == 1
        manager = autopilot._STATE["manager_thread"]
        config_path = autopilot._config_path()
        saved = json.loads(config_path.read_text(encoding="utf-8"))
        assert saved["enabled"] is True
        assert saved["entries_enabled"] is False
        autopilot._STATE["manager_stop_event"].set()
        manager.join(timeout=2)
        assert not manager.is_alive()

        # Simulate process restart: clear process memory, reload durable config.
        _reset_state()
        autopilot._load_config()
        assert autopilot._CONFIG["enabled"] is True
        assert autopilot._CONFIG["entries_enabled"] is False


def test_full_stop_persists_disabled_service_after_all_positions_close(tmp_path, monkeypatch):
    import json
    monkeypatch.setenv("TRADING_AI_MODELS_DIR", str(tmp_path / "models"))
    _reset_state()
    states = [{"open_positions": [_open_position()]}, {"open_positions": []}]
    with patch.object(paper_live, "get_state", side_effect=lambda **kwargs: states.pop(0) if states else {"open_positions": []}), \
         patch.object(paper_live, "close_position", return_value={"net_pnl": 0.5}), \
         patch.object(autopilot, "_log_decision", return_value=None), \
         patch.object(autopilot, "build_report", return_value={"stats": {"trades": 0}}), \
         patch.object(autopilot, "status", return_value={"entries_enabled": False, "managing": False}):
        result = autopilot.stop(close_all=True)
        saved = json.loads(autopilot._config_path().read_text(encoding="utf-8"))
        assert result["full_stop"] is True
        assert saved["enabled"] is False
        assert saved["entries_enabled"] is False
