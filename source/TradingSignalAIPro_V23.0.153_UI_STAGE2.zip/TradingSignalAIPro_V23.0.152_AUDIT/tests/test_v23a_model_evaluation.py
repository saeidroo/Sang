import numpy as np
import pandas as pd
import pytest
from backend.model_evaluation import (audit_feature_schema, chronological_split,
    assert_label_horizon_purged, classification_report, evaluate_binary_model)


def test_schema_audit_warns_on_future_and_target_names():
    r = audit_feature_schema(['rsi', 'future_return', 'volume'])
    assert r['status'] == 'WARN' and 'future_return' in r['suspicious_columns']


def test_chronological_split_boundaries_and_sizes():
    df = pd.DataFrame({'time': pd.date_range('2025-01-01', periods=100, freq='4h'), 'x': range(100)})
    s = chronological_split(df, timestamp_column='time')
    assert (len(s['train']), len(s['validation']), len(s['test'])) == (70, 15, 15)
    assert s['train'].time.max() < s['validation'].time.min() < s['test'].time.min()


def test_split_rejects_unsorted_and_duplicate_times():
    df = pd.DataFrame({'t': pd.date_range('2025-01-01', periods=20, freq='h')})
    with pytest.raises(ValueError): chronological_split(df.iloc[::-1], timestamp_column='t')
    df.loc[1, 't'] = df.loc[0, 't']
    with pytest.raises(ValueError): chronological_split(df, timestamp_column='t')


def test_label_horizon_purge_detects_overlap():
    assert assert_label_horizon_purged([1, 2, 3], 5)['valid']
    r = assert_label_horizon_purged([1, 5, 6], 5)
    assert not r['valid'] and r['leaking_indices'] == [1, 2]


def test_classification_and_baseline_metrics():
    y = np.array([0, 0, 1, 1]); p = np.array([.1, .2, .8, .9])
    r = classification_report(y, p)
    assert r['accuracy'] == 1 and r['f1'] == 1 and r['brier'] < .03
    out = evaluate_binary_model(y, p)
    assert out['beats_majority_accuracy'] and out['test_block'] == 'caller_asserted_untouched'


def test_rejects_invalid_probability():
    with pytest.raises(ValueError): classification_report([0, 1], [.2, 1.2])
