import pandas as pd
import pytest
from backend.portfolio_risk import analyze_volume_confirmation


def frame(side='LONG', current_volume=300.0, bullish=True):
    opens = [100.0] * 21
    closes = [101.0 if side == 'LONG' else 99.0] * 20
    opens[-1] = 100.0
    closes.append(101.0 if bullish else 99.0)
    volumes = [100.0] * 20 + [current_volume]
    return pd.DataFrame({'open': opens, 'close': closes, 'volume': volumes})


def test_long_volume_confirmation_uses_previous_closed_candles():
    result = analyze_volume_confirmation(frame(), side='LONG', lookback=20)
    assert result['state'] == 'VOLUME_CONFIRMED'
    assert result['relative_volume'] == 3.0
    assert result['data_policy'] == 'CLOSED_CANDLES_ONLY'


def test_short_volume_confirmation_requires_bearish_candle():
    result = analyze_volume_confirmation(frame('SHORT', bullish=True), side='SHORT')
    assert result['state'] == 'WEAK_VOLUME'
    assert not result['confirmed']


def test_weak_volume_is_not_confirmed():
    result = analyze_volume_confirmation(frame(current_volume=80), side='LONG')
    assert result['state'] == 'WEAK_VOLUME'


def test_missing_volume_fails_closed_as_unavailable():
    result = analyze_volume_confirmation(pd.DataFrame({'open':[1]*30,'close':[2]*30}), side='LONG')
    assert result['state'] == 'UNAVAILABLE'
    assert not result['confirmed']


def test_invalid_side_rejected():
    with pytest.raises(ValueError):
        analyze_volume_confirmation(frame(), side='FLAT')
