import time


def test_funding_audit_returns_chronological_events_and_partial_exits(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'audit.sqlite3'))
    paper_live._CACHE.clear()

    def fake_fetch(exchange, symbol, market):
        return {'symbol': symbol, 'market': market, 'exchange': exchange,
                'exchange_name': paper_live.EXCHANGE_NAMES[exchange], 'price': 100.0,
                'timestamp': '2026-11-19T00:00:00+00:00', 'authenticated': False}

    monkeypatch.setattr(paper_live, '_fetch_one', fake_fetch)
    opened = paper_live.open_position('BTCUSDT', 'LONG', 'perp', 'auto')
    paper_live.partial_close_position(opened['id'], opened['quantity'] * .25, idempotency_key='audit-exit-1')
    with paper_live._connect() as c:
        c.execute("""INSERT INTO paper_funding_events(
            trade_id,settlement_ts_ms,exchange,symbol,side,funding_rate,mark_price,event_notional,
            notional_basis,position_quantity,partial_exited_quantity,cashflow,source,created_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
            opened['id'], 1795046400000, opened['exchange'], 'BTCUSDT', 'LONG', .0001,
            100.0, 75.0, 'MARK_PRICE', opened['quantity']*.75, opened['quantity']*.25,
            -.0075, 'test_fixture', time.time()))
    audit = paper_live.get_funding_audit(opened['id'])
    assert audit['trade']['id'] == opened['id']
    assert len(audit['funding_events']) == 1
    assert audit['funding_events'][0]['position_quantity'] == opened['quantity'] * .75
    assert len(audit['partial_exits']) == 1
    assert audit['funding_event_sum'] == -0.0075
    assert audit['audit_complete'] is False  # fixture position remains pending


def test_funding_audit_missing_trade_raises_value_error(tmp_path, monkeypatch):
    import pytest
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'missing.sqlite3'))
    with pytest.raises(ValueError):
        paper_live.get_funding_audit(999999)
