from backend.scout import _apply_historical_pattern_priority


def make_item(symbol='ABCUSDT', score=60):
    return {'symbol': symbol, 'score': score, 'directional_priority_score': score,
            'pre_pump_score': score, 'pre_dump_score': score}


def matcher_for(bias, pump, dump, samples=20):
    def matcher(**kwargs):
        return {'status': 'completed', 'matches': [{
            'symbol': kwargs['symbol'], 'historical_bias': bias,
            'historical_samples': samples, 'pump_share_pct': pump,
            'dump_share_pct': dump, 'evidence_reliability': 'moderate'}]}
    return matcher


def test_pump_history_boosts_only_up_direction():
    up = _apply_historical_pattern_priority([make_item()], 'up', matcher_for('pump_favored', 80, 20))[0]
    down = _apply_historical_pattern_priority([make_item()], 'down', matcher_for('pump_favored', 80, 20))[0]
    assert up['historical_pattern_priority_score'] > 60
    assert down['historical_pattern_priority_score'] < 60


def test_dump_history_boosts_down_and_penalizes_up():
    up = _apply_historical_pattern_priority([make_item()], 'up', matcher_for('dump_favored', 20, 80))[0]
    down = _apply_historical_pattern_priority([make_item()], 'down', matcher_for('dump_favored', 20, 80))[0]
    assert up['historical_pattern_priority_score'] < 60
    assert down['historical_pattern_priority_score'] > 60


def test_mixed_and_insufficient_samples_are_neutral():
    for bias, n in [('mixed', 20), ('pump_favored', 4), ('insufficient_samples', 0)]:
        item = _apply_historical_pattern_priority([make_item()], 'up', matcher_for(bias, 50, 50, n))[0]
        assert item['historical_pattern_evidence']['priority_adjustment'] == 0
        assert item['historical_pattern_priority_score'] == 60


def test_missing_archive_and_errors_are_neutral():
    def missing(**kwargs): return {'status': 'no_history_archive', 'matches': []}
    item = _apply_historical_pattern_priority([make_item()], 'down', missing)[0]
    assert item['historical_pattern_priority_score'] == 60
    def broken(**kwargs): raise RuntimeError('archive locked')
    item = _apply_historical_pattern_priority([make_item()], 'down', broken)[0]
    assert item['historical_pattern_priority_score'] == 60


def test_adjustment_is_bounded():
    item = _apply_historical_pattern_priority([make_item()], 'up', matcher_for('pump_favored', 100, 0, 10000))[0]
    assert item['historical_pattern_evidence']['priority_adjustment'] <= 2.5
    assert item['historical_pattern_priority_score'] <= 62.5
