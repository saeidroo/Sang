import time
import unittest
import pandas as pd
from backend.data import _clean_candles, _aggregate, _drop_unclosed, to_display


class CandleNormalizationTests(unittest.TestCase):
    def setUp(self):
        now = int(time.time() * 1000)
        # Align fixture to a 4-hour boundary so aggregation always yields 3 buckets.
        now = (now // (4 * 3600_000)) * (4 * 3600_000)
        self.frame = _clean_candles([
            {'t': now - (12-i) * 3600_000, 'open': 100+i, 'high': 104+i,
             'low': 98+i, 'close': 102+i, 'volume': 10}
            for i in range(12)
        ])

    def test_stable_schema(self):
        self.assertEqual(list(self.frame.columns), ['t','open','high','low','close','volume'])

    def test_aggregate_schema_and_ohlc(self):
        out = _aggregate(self.frame, 4 * 3600)
        self.assertEqual(list(out.columns), list(self.frame.columns))
        self.assertEqual(len(out), 3)
        self.assertTrue((out.high >= out.low).all())

    def test_display_schema(self):
        display = to_display(self.frame)
        self.assertTrue({'t','o','h','l','c','v'}.issubset(display[0]))

    def test_drop_unclosed(self):
        closed = _drop_unclosed(self.frame, '1h')
        self.assertTrue((closed.t + 3600_000 <= int(time.time()*1000)).all())


if __name__ == '__main__':
    unittest.main()
