"""V22.5a Storm Scout cross-source quality gates."""
from backend import scout


def row(base, price, source, *, change=4.0, volume=5_000_000):
    return {
        'base': base, 'price': price, 'c24': change, 'c1h': 1.0, 'c7d': 2.0,
        'vol': volume, 'mcap': 50_000_000.0, 'rank': 100,
        'trending': False, 'source': source,
    }


def test_trend_only_source_does_not_inflate_price_breadth():
    merged = scout.merge([row('AAA', 1.0, 'binance'),
                          {'flag_only': True, 'base': 'AAA', 'source': 'coingecko_trending'}])
    coin = merged['AAA']
    assert coin['trending'] is True
    assert coin['price_source_count'] == 1
    assert coin['sources'] == {'binance'}


def test_price_median_and_conservative_volume_aggregation():
    coin = scout.merge([row('AAA', 10.0, 'binance', volume=4_000_000),
                        row('AAA', 10.1, 'okx', volume=8_000_000),
                        row('AAA', 9.9, 'coingecko', volume=6_000_000)])['AAA']
    assert coin['price'] == 10.0
    assert coin['vol'] == 6_000_000
    assert coin['identity_conflict'] is False


def test_price_disagreement_quarantines_even_with_strong_candles():
    coin = scout.merge([row('AAA', 1.0, 'binance'),
                        row('AAA', 1.01, 'okx'),
                        row('AAA', 1.2, 'coingecko')])['AAA']
    score, _phase, verified = scout.final_score(coin, {'candle_score': 100, 'direction': 'up'})
    assert coin['identity_conflict'] is True
    assert coin['price_dispersion_pct'] > scout.MAX_PRICE_DISPERSION_PCT
    assert score <= scout.UNVERIFIED_CAP
    assert verified is False


def test_normal_price_spread_remains_eligible_for_candle_verification():
    coin = scout.merge([row('AAA', 10.0, 'binance'),
                        row('AAA', 10.1, 'okx'),
                        row('AAA', 9.95, 'coingecko')])['AAA']
    assert coin['identity_conflict'] is False
    score, _phase, verified = scout.final_score(coin, {'candle_score': 70, 'direction': 'up'})
    assert verified is True
    assert score > scout.UNVERIFIED_CAP
