import json, zipfile
import pytest
from backend.replay_release_evidence import (build_replay_release_evidence_pack,
    verify_replay_release_evidence_pack)


def test_release_evidence_pack_build_verify_and_secret_exclusion(tmp_path):
    project=tmp_path/'project'; project.mkdir()
    (project/'backend.py').write_text('VERSION = 1\n')
    (project/'private.pem').write_text('DO NOT INCLUDE PRIVATE KEY')
    (project/'.env').write_text('TOKEN=do-not-include')
    out=tmp_path/'evidence.zip'
    result=build_replay_release_evidence_pack(project_root=project,output_path=out,
        test_summary={'passed':255,'failed':0,'skipped':1},
        gate_report={'status':'READY','checks':{'anchor':True}},release_version='22.4.7')
    assert result['created'] and result['source_file_count']==1
    assert verify_replay_release_evidence_pack(out)['valid']
    with zipfile.ZipFile(out) as z:
        manifest=json.loads(z.read('manifest.json'))
        assert all('private' not in row['path'] and '.env' not in row['path'] for row in manifest['source_inventory'])


def test_release_evidence_rejects_failed_tests_and_tampering(tmp_path):
    project=tmp_path/'project'; project.mkdir(); (project/'x.py').write_text('x=1')
    with pytest.raises(ValueError,match='tests_not_passing'):
        build_replay_release_evidence_pack(project_root=project,output_path=tmp_path/'no.zip',
            test_summary={'passed':2,'failed':1},gate_report={'status':'READY'},release_version='x')
    out=tmp_path/'evidence.zip'
    build_replay_release_evidence_pack(project_root=project,output_path=out,
        test_summary={'passed':1,'failed':0},gate_report={'status':'BLOCKED'},release_version='x')
    with zipfile.ZipFile(out) as z: files={n:z.read(n) for n in z.namelist()}
    manifest=json.loads(files['manifest.json']); manifest['release_version']='tampered'
    files['manifest.json']=json.dumps(manifest).encode()
    with zipfile.ZipFile(tmp_path/'tampered.zip','w') as z:
        for name,raw in files.items(): z.writestr(name,raw)
    with pytest.raises(ValueError,match='manifest_hash_mismatch'):
        verify_replay_release_evidence_pack(tmp_path/'tampered.zip')
