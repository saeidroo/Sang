import pytest
from backend.bracket_execution import evaluate_bracket_candle


def test_long_stop_touched_intrabar_even_when_close_recovers():
    result = evaluate_bracket_candle(side='LONG', stop_price=95, target_price=110,
        candle={'open': 100, 'high': 103, 'low': 94, 'close': 101})
    assert result['triggered'] and result['reason'] == 'STOP_LOSS'
    assert result['fill_reference'] == 95


def test_short_stop_touched_intrabar():
    result = evaluate_bracket_candle(side='SHORT', stop_price=105, target_price=90,
        candle={'open': 100, 'high': 106, 'low': 98, 'close': 101})
    assert result['reason'] == 'STOP_LOSS'
    assert result['fill_reference'] == 105


def test_both_brackets_touched_stop_wins_conservatively():
    result = evaluate_bracket_candle(side='LONG', stop_price=95, target_price=105,
        candle={'open': 100, 'high': 106, 'low': 94, 'close': 101})
    assert result['reason'] == 'STOP_LOSS'
    assert result['both_hit'] is True
    assert result['policy'] == 'STOP_FIRST_CONSERVATIVE'


def test_stop_gap_uses_worse_open_for_long_and_short():
    long_result = evaluate_bracket_candle(side='LONG', stop_price=95, target_price=110,
        candle={'open': 90, 'high': 93, 'low': 88, 'close': 91})
    short_result = evaluate_bracket_candle(side='SHORT', stop_price=105, target_price=90,
        candle={'open': 112, 'high': 114, 'low': 108, 'close': 110})
    assert long_result['fill_reference'] == 90 and long_result['gap']
    assert short_result['fill_reference'] == 112 and short_result['gap']


def test_target_gap_is_capped_at_target():
    result = evaluate_bracket_candle(side='LONG', stop_price=95, target_price=105,
        candle={'open': 108, 'high': 110, 'low': 107, 'close': 109})
    assert result['reason'] == 'TAKE_PROFIT'
    assert result['fill_reference'] == 105
    assert result['gap'] is True


def test_no_touch_does_not_close():
    result = evaluate_bracket_candle(side='SHORT', stop_price=105, target_price=90,
        candle={'open': 100, 'high': 103, 'low': 97, 'close': 101})
    assert result['triggered'] is False


@pytest.mark.parametrize('candle', [
    {'open': 100, 'high': 99, 'low': 95, 'close': 98},
    {'open': 100, 'high': 105, 'low': 96, 'close': 106},
])
def test_invalid_ohlc_rejected(candle):
    with pytest.raises(ValueError):
        evaluate_bracket_candle(side='LONG', stop_price=95, target_price=110, candle=candle)


def test_invalid_side_and_nonfinite_rejected():
    with pytest.raises(ValueError):
        evaluate_bracket_candle(side='BUY', stop_price=95, target_price=110,
            candle={'open': 100, 'high': 105, 'low': 96, 'close': 101})
    with pytest.raises(ValueError):
        evaluate_bracket_candle(side='LONG', stop_price=95, target_price=110,
            candle={'open': 100, 'high': float('nan'), 'low': 96, 'close': 101})
