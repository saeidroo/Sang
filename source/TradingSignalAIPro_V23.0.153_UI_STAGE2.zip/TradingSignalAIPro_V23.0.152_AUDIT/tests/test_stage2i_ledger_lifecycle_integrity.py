from backend import paper_live


def _db(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'stage2i.sqlite3'))
    paper_live.init_db(backfill_learning=False)
    with paper_live._connect() as c:
        cur = c.execute('''INSERT INTO paper_live_trades(
            opened_at,symbol,market,exchange,requested_exchange,side,quantity,notional,
            reference_entry,entry_fill,entry_fee,stop_price,target_price,status,settings_json,
            timeframe,replay_status)
            VALUES(1,'BTCUSDT','spot','binance','binance','LONG',1,100,100,100,0.1,95,110,'OPEN','{}','5m','PENDING')''')
        return cur.lastrowid


def test_clean_ledger_passes_extended_lifecycle_checks(tmp_path, monkeypatch):
    _db(tmp_path, monkeypatch)
    report = paper_live.validate_paper_ledger()
    assert report['valid'] is True
    assert report['checks']['partial_quantity_overruns'] == 0
    assert report['checks']['invalid_funding_events'] == 0
    assert report['checks']['invalid_replay_state'] == 0


def test_validator_detects_partial_exit_quantity_overrun(tmp_path, monkeypatch):
    trade_id = _db(tmp_path, monkeypatch)
    with paper_live._connect() as c:
        for key, qty in [('a', 0.7), ('b', 0.5)]:
            c.execute('''INSERT INTO paper_partial_exits(
                trade_id,idempotency_key,created_at,quantity,reference_exit,exit_fill,
                entry_fee_allocated,exit_fee,gross_pnl,net_pnl)
                VALUES(?,?,2,?,100,100,0.01,0.01,0, -0.02)''', (trade_id, key, qty))
    report = paper_live.validate_paper_ledger()
    assert report['valid'] is False
    assert 'partial_quantity_overruns:1' in report['errors']


def test_validator_detects_invalid_funding_event(tmp_path, monkeypatch):
    trade_id = _db(tmp_path, monkeypatch)
    with paper_live._connect() as c:
        c.execute('''INSERT INTO paper_funding_events(
            trade_id,settlement_ts_ms,exchange,symbol,side,funding_rate,event_notional,
            notional_basis,position_quantity,partial_exited_quantity,cashflow,created_at)
            VALUES(?,1000,'binance','BTCUSDT','LONG',2.0,100,'mark',1,0,0.2,2)''', (trade_id,))
    report = paper_live.validate_paper_ledger()
    assert report['valid'] is False
    assert 'invalid_funding_events:1' in report['errors']


def test_validator_detects_invalid_replay_lifecycle_state(tmp_path, monkeypatch):
    trade_id = _db(tmp_path, monkeypatch)
    with paper_live._connect() as c:
        c.execute("UPDATE paper_live_trades SET replay_status='EXITED' WHERE id=?", (trade_id,))
    report = paper_live.validate_paper_ledger()
    assert report['valid'] is False
    assert 'invalid_replay_state:1' in report['errors']


def test_validator_does_not_mutate_ledger_rows(tmp_path, monkeypatch):
    trade_id = _db(tmp_path, monkeypatch)
    with paper_live._connect() as c:
        before = tuple(c.execute('SELECT status,replay_status,replay_last_candle_open_ms FROM paper_live_trades WHERE id=?', (trade_id,)).fetchone())
    paper_live.validate_paper_ledger()
    with paper_live._connect() as c:
        after = tuple(c.execute('SELECT status,replay_status,replay_last_candle_open_ms FROM paper_live_trades WHERE id=?', (trade_id,)).fetchone())
    assert before == after
