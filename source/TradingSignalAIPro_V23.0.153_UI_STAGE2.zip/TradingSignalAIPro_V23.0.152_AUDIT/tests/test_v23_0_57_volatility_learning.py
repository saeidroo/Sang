from backend.strategy_learning import rank_strategy_performance


def _row(pnl, ctx):
    return {"symbol": "BTCUSDT", "market": "perp", "timeframe": "1h", "side": "LONG",
            "net_pnl": pnl, "return_pct": pnl / 10, "context_json": ctx}


def test_volatility_regimes_are_separated_from_closed_paper_outcomes():
    rows = [_row(2, '{"strategy":"alpha","market_regime":"bullish","atr":50,"entry_price":10000}') for _ in range(12)]
    rows += [_row(-1, '{"strategy":"alpha","market_regime":"bullish","atr":400,"entry_price":10000}') for _ in range(12)]
    result = rank_strategy_performance(rows, min_samples=10)
    assert result["group_count"] == 2
    by_vol = {g["volatility_regime"]: g for g in result["groups"]}
    assert by_vol["LOW"]["learning_state"] == "REVIEWABLE"
    assert by_vol["HIGH"]["learning_state"] == "NO_POSITIVE_EDGE"
    assert result["volatility_segmentation"] == "RECORDED_LABEL_OR_ATR_PERCENT_AT_ENTRY_ONLY"
    assert result["authorizes_entries"] is False
    assert result["real_orders_enabled"] is False


def test_unknown_volatility_stays_separate_and_labels_normalize():
    rows = [_row(1, '{}'), _row(1, '{"volatility_regime":"extreme"}')]
    result = rank_strategy_performance(rows, min_samples=1)
    assert {g["volatility_regime"] for g in result["groups"]} == {"UNKNOWN", "HIGH"}
