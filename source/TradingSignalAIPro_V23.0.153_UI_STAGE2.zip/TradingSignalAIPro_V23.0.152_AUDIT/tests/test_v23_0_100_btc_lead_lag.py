from backend import market_brain


def _rows(symbol, prices, start=1_700_000_000_000):
    rows = []
    for i, price in enumerate(prices):
        ts = start + i * 3_600_000
        rows.append((symbol, ts, price, price * 1.01, price * 0.99, price, 1000.0))
    return rows


def test_btc_lead_lag_requires_both_symbols_and_enough_history():
    assert market_brain._btc_lead_lag_summary({}, 'ETHUSDT')['status'] == 'insufficient_data'


def test_btc_lead_lag_reports_follow_through_from_separate_historical_events():
    n = 170
    btc = [100.0] * n
    alt = [100.0] * n
    for i in (30, 45, 60, 75, 90, 105, 120, 135):
        btc[i + 4] = 103.0
        alt[i + 4] = 100.0
        alt[i + 8] = 102.0
        alt[i + 16] = 103.0
    # Current BTC impulse is positive, so only positive historical impulses match.
    btc[-5:] = [100.0, 100.5, 101.0, 102.0, 103.0]
    result = market_brain._btc_lead_lag_summary(
        {'BTCUSDT': _rows('BTCUSDT', btc), 'ETHUSDT': _rows('ETHUSDT', alt)}, 'ETHUSDT')
    assert result['status'] == 'available'
    assert result['historical_events'] >= market_brain.MIN_ANALOGS
    assert result['follow_through_4h_pct'] == 100.0
    assert result['follow_through_12h_pct'] == 100.0


def test_btc_lead_lag_does_not_claim_a_signal_without_current_impulse():
    prices = [100.0] * 80
    result = market_brain._btc_lead_lag_summary(
        {'BTCUSDT': _rows('BTCUSDT', prices), 'ETHUSDT': _rows('ETHUSDT', prices)}, 'ETHUSDT')
    assert result['status'] == 'no_current_btc_impulse'
    assert result['historical_events'] == 0
