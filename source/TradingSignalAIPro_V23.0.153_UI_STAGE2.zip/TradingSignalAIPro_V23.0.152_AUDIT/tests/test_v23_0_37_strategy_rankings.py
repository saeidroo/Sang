import time
import pytest


def _seed(module, values):
    module.init_db(backfill_learning=False)
    with module._connect() as conn:
        for trade_id, pnl, symbol, timeframe in values:
            conn.execute("""INSERT INTO paper_learning_events
                (trade_id,closed_at,symbol,market,timeframe,exchange,side,exit_reason,outcome,net_pnl,
                 return_pct,duration_seconds,notional,gross_pnl,total_fees,entry_fill,exit_fill,context_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (trade_id, time.time(), symbol, 'spot', timeframe, 'binance', 'LONG', 'TEST',
                 int(pnl > 0), pnl, pnl, 60, 100, pnl, 0, 100, 100, '{}'))


def test_rankings_require_minimum_sample_and_rank_eligible_first(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'ranking.sqlite3'))
    paper_live._CACHE.clear()
    _seed(paper_live, [
        (1, 10, 'BTCUSDT', '1h'), (2, 8, 'BTCUSDT', '1h'),
        (3, 7, 'BTCUSDT', '1h'), (4, 6, 'BTCUSDT', '1h'), (5, 5, 'BTCUSDT', '1h'),
        (6, 100, 'ETHUSDT', '4h'),
    ])
    result = paper_live.get_strategy_rankings(min_trades=5)
    assert result['eligible_count'] == 1
    assert result['rankings'][0]['symbol'] == 'BTCUSDT'
    assert result['rankings'][0]['rank'] == 1
    assert result['rankings'][1]['rank'] is None
    assert result['rankings'][1]['status'] == 'نمونه ناکافی'
    assert result['real_orders_enabled'] is False


def test_ranking_shrinks_small_samples_and_validates_inputs(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'shrink.sqlite3'))
    paper_live._CACHE.clear()
    _seed(paper_live, [(1, 10, 'BTCUSDT', '1h'), (2, -2, 'BTCUSDT', '1h'),
                       (3, 3, 'ETHUSDT', '4h')])
    result = paper_live.get_strategy_rankings(min_trades=2)
    btc = next(x for x in result['rankings'] if x['symbol'] == 'BTCUSDT')
    assert btc['reliability_pct'] == pytest.approx(2 / 7 * 100)
    assert btc['adjusted_expectancy_usdt'] != pytest.approx(btc['expectancy_usdt'])
    with pytest.raises(ValueError):
        paper_live.get_strategy_rankings(min_trades=1)
    with pytest.raises(ValueError):
        paper_live.get_strategy_rankings(period='quarter')
