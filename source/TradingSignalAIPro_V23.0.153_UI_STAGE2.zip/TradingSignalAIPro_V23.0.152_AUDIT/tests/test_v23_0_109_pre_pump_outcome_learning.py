from backend import storm_learning


def _candidate(symbol='AAAUSDT', *, grade='exchange_taker', score=76.0, price=100.0):
    return {
        'symbol': symbol,
        'price': price,
        'score': 52.0,
        'phase': 'early',
        'direction': 'up',
        'verified': True,
        'fresh': True,
        'pre_pump_candidate': True,
        'pre_pump_score': score,
        'pre_pump_grade': grade,
        'volume_acceleration_ratio': 1.6,
        'recent_volume_ratio': 1.8,
        'buy_pressure_ratio': 0.68,
        'buy_pressure_change': 0.09,
        'flow_persistence': 0.8,
        'pre_pump_price_change_1h_pct': 0.4,
        'btc_regime_4h': 'up',
    }


def _scan(item, ts, price=None):
    item_list = [] if item is None else [item]
    base = (item['symbol'][:-4] if item and item['symbol'].endswith('USDT') else 'AAA')
    snap_price = price if price is not None else (item['price'] if item else 100.0)
    return storm_learning.record_scan(
        item_list, timestamp=ts, snapshots={base: {'price': snap_price}}
    )


def test_pre_pump_candidate_creates_independent_event_and_all_horizons(monkeypatch, tmp_path):
    monkeypatch.setattr(storm_learning, 'DB_PATH', tmp_path / 'learning.sqlite3')
    result = _scan(_candidate(), 1_700_000_000.0)
    report = storm_learning.pre_pump_performance_report()
    assert result['pre_pump_events_recorded'] == 1
    assert report['total_events'] == 1
    assert report['unique_symbols'] == 1
    assert report['horizons']['1h']['pending'] == 1
    assert report['horizons']['7d']['pending'] == 1


def test_repeated_same_symbol_within_24h_is_not_double_counted(monkeypatch, tmp_path):
    monkeypatch.setattr(storm_learning, 'DB_PATH', tmp_path / 'learning.sqlite3')
    t0 = 1_700_000_000.0
    assert _scan(_candidate(), t0)['pre_pump_events_recorded'] == 1
    assert _scan(_candidate(price=100.2), t0 + 900)['pre_pump_events_recorded'] == 0
    report = storm_learning.pre_pump_performance_report()
    assert report['total_events'] == 1
    assert report['deduplication_window_hours'] == 24


def test_new_episode_after_24h_is_recorded(monkeypatch, tmp_path):
    monkeypatch.setattr(storm_learning, 'DB_PATH', tmp_path / 'learning.sqlite3')
    t0 = 1_700_000_000.0
    _scan(_candidate(), t0)
    result = _scan(_candidate(price=101.0), t0 + 86401)
    assert result['pre_pump_events_recorded'] == 1
    assert storm_learning.pre_pump_performance_report()['total_events'] == 2


def test_real_observation_resolves_pre_pump_horizon(monkeypatch, tmp_path):
    monkeypatch.setattr(storm_learning, 'DB_PATH', tmp_path / 'learning.sqlite3')
    t0 = 1_700_000_000.0
    _scan(_candidate(), t0, 100.0)
    resolution = storm_learning.record_scan([], timestamp=t0 + 3600,
        snapshots={'AAA': {'price': 101.5}})
    report = storm_learning.pre_pump_performance_report()
    assert resolution['pre_pump_outcomes_resolved'] == 1
    assert report['horizons']['1h']['samples'] == 1
    assert report['horizons']['1h']['successes'] == 1
    assert report['horizons']['1h']['success_rate'] == 1.0
    assert report['horizons']['1h']['avg_return_pct'] == 1.5


def test_missing_observation_never_becomes_success(monkeypatch, tmp_path):
    monkeypatch.setattr(storm_learning, 'DB_PATH', tmp_path / 'learning.sqlite3')
    t0 = 1_700_000_000.0
    _scan(_candidate(), t0)
    # For a 1h horizon the allowed observation delay is 2h; move beyond it.
    storm_learning.record_scan([], timestamp=t0 + 3 * 3600 + 1, snapshots={})
    h = storm_learning.pre_pump_performance_report()['horizons']['1h']
    assert h['samples'] == 0
    assert h['successes'] == 0
    assert h['missing_observations'] == 1


def test_taker_and_candle_proxy_are_reported_separately(monkeypatch, tmp_path):
    monkeypatch.setattr(storm_learning, 'DB_PATH', tmp_path / 'learning.sqlite3')
    t0 = 1_700_000_000.0
    _scan(_candidate('AAAUSDT', grade='exchange_taker'), t0)
    _scan(_candidate('BBBUSDT', grade='candle_proxy'), t0 + 1)
    grades = storm_learning.pre_pump_performance_report()['flow_grades']
    assert grades['exchange_taker']['events'] == 1
    assert grades['candle_proxy']['events'] == 1


def test_non_pre_pump_candidate_does_not_enter_special_ledger(monkeypatch, tmp_path):
    monkeypatch.setattr(storm_learning, 'DB_PATH', tmp_path / 'learning.sqlite3')
    item = _candidate()
    item['pre_pump_candidate'] = False
    result = _scan(item, 1_700_000_000.0)
    assert result['pre_pump_events_recorded'] == 0
    assert storm_learning.pre_pump_performance_report()['total_events'] == 0


def test_thresholds_are_never_auto_adjusted_from_small_samples(monkeypatch, tmp_path):
    monkeypatch.setattr(storm_learning, 'DB_PATH', tmp_path / 'learning.sqlite3')
    _scan(_candidate(), 1_700_000_000.0)
    report = storm_learning.pre_pump_performance_report()
    assert report['threshold_policy'] == 'fixed_no_auto_adjustment'
    assert report['minimum_samples_for_review'] == 30
    assert report['horizons']['1h']['evidence_level'] == 'insufficient'


def test_followups_exposes_pre_pump_report(monkeypatch, tmp_path):
    monkeypatch.setattr(storm_learning, 'DB_PATH', tmp_path / 'learning.sqlite3')
    _scan(_candidate(), 1_700_000_000.0)
    data = storm_learning.followups(limit=10)
    assert data['pre_pump_report']['total_events'] == 1
    assert data['pre_pump_report']['flow_grades']['exchange_taker']['events'] == 1


def test_flow_grade_cohorts_keep_taker_and_proxy_outcomes_separate(monkeypatch, tmp_path):
    monkeypatch.setattr(storm_learning, 'DB_PATH', tmp_path / 'learning.sqlite3')
    t0 = 1_700_000_000.0
    _scan(_candidate('AAAUSDT', grade='exchange_taker'), t0, 100.0)
    storm_learning.record_scan([], timestamp=t0 + 3600, snapshots={'AAA': {'price': 101.2}})
    report = storm_learning.pre_pump_performance_report()
    taker = report['flow_grade_horizons']['exchange_taker']['1h']
    proxy = report['flow_grade_horizons']['candle_proxy']['1h']
    assert taker['samples'] == 1 and taker['successes'] == 1
    assert proxy['samples'] == 0


def test_score_band_cohort_is_descriptive_and_not_an_auto_tuning_action(monkeypatch, tmp_path):
    monkeypatch.setattr(storm_learning, 'DB_PATH', tmp_path / 'learning.sqlite3')
    t0 = 1_700_000_000.0
    _scan(_candidate(score=84.0), t0, 100.0)
    storm_learning.record_scan([], timestamp=t0 + 3600, snapshots={'AAA': {'price': 101.2}})
    report = storm_learning.pre_pump_performance_report()
    assert report['score_band_horizons']['80+']['1h']['samples'] == 1
    assert report['threshold_policy'] == 'fixed_no_auto_adjustment'
