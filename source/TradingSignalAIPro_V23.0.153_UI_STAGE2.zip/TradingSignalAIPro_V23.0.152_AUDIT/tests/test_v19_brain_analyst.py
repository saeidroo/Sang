"""V19: analyst report + brain v3 components, confluence, scenario."""
import numpy as np
import pandas as pd
import pytest

from backend import analyst
from backend.brain import (BASE_WEIGHTS, build_component_scores,
                           ichimoku_vote, volume_vote, make_brain_decision,
                           CONFLUENCE_MAX_FACTOR)


def _indicator_frame(n=120, rising=True):
    close = np.linspace(100, 135, n) if rising else np.linspace(135, 100, n)
    frame = pd.DataFrame({
        't': np.arange(n, dtype=np.int64) * 3_600_000 + 1_700_000_000_000,
        'close': close,
        'open': close,
        'high': close * 1.003,
        'low': close * 0.997,
        'volume': np.full(n, 1000.0),
        'ema_20': pd.Series(close).ewm(span=20, adjust=False).mean(),
        'ema_50': pd.Series(close).ewm(span=50, adjust=False).mean(),
        'macd_line': np.linspace(0.5, 1.5, n),
        'macd_signal': np.linspace(0.4, 1.0, n),
        'macd_hist': np.linspace(0.1, 0.5, n),
        'plus_di': np.full(n, 30.0 if rising else 10.0),
        'minus_di': np.full(n, 10.0 if rising else 30.0),
        'cmf_20': np.full(n, 0.12 if rising else -0.12),
        'supertrend': close - 1 if rising else close + 1,
        'ich_span_a': close * 0.99,
        'ich_span_b': close * 0.98,
        'ich_tenkan': close * 1.001,
        'ich_kijun': close * 0.999,
        'mfi_14': np.full(n, 72.0 if rising else 28.0),
        'adx_14': np.full(n, 28.0),
        'obv': np.cumsum(np.full(n, 100.0)) if rising else np.cumsum(np.full(n, -100.0)),
    })
    return frame


def _minimal_analysis():
    return {
        'symbol': 'BTCUSDT', 'timeframe': '1h', 'price': 65432.1,
        'change_pct': 1.2, 'candle_count': 1500, 'source_label': 'Binance',
        'signal': {'kind': 'BUY', 'power': 0.62, 'prob': 0.67, 'brain_confirmed': True,
                   'agreement': 'high', 'entry': 65432.1, 'tp': 66500.0, 'sl': 64300.0,
                   'levels_side': 'LONG', 'levels_provisional': False,
                   'news_alert': {}, 'news_blocked': False, 'meta_blocked': False,
                   'scenario': {'setup': 'trend_continuation', 'entry': 65432.1,
                                'tp': 66500.0, 'sl': 64300.0, 'reward_risk': 0.973,
                                'prob_tp_first': 0.67, 'ev_gross_pct': 0.048,
                                'ev_net_pct': -0.072, 'cost_pct': 0.12,
                                'invalidation': 64300.0, 'provisional': False}},
        'brain': {'decision': 'BUY', 'final_signal': 'BUY', 'score': 0.31,
                  'confidence': 0.31, 'coverage': 0.77, 'available_sources': 11,
                  'directional_sources': 5, 'edge_confirmed': True, 'vetoes': [],
                  'confluence': {'bull_sources': ['ml', 'technical'],
                                 'bear_sources': [], 'shaping_factor': 1.06,
                                 'raw_score': 0.29},
                  'components': {'ml': {'score': 0.34, 'available': True},
                                 'technical': {'score': 0.58, 'available': True},
                                 'derivatives': {'score': 0.0, 'available': False,
                                                 'detail': {'reason': 'not available'}}}},
        'model_meta': {'val_acc': 0.563, 'edge_confirmed': True, 'best_threshold': 0.6},
        'market_context': {'regime': {'regime': 'bull', 'annualized_volatility': 0.42},
                           'feed_errors': []},
        'backtest_stats': {'win_rate': 0.58},
        'rl_review': {},
    }


# ---------------- brain v3 ----------------
def test_v19_weights_still_sum_to_one():
    assert abs(sum(BASE_WEIGHTS.values()) - 1.0) < 1e-9
    assert set(BASE_WEIGHTS) >= {'divergence', 'ichimoku', 'volume'}


def test_new_components_present_and_missing_are_flagged():
    frame = _indicator_frame()
    components, _ = build_component_scores(
        0.8, frame, {'regime': 'bull', 'confidence': 0.8}, [], [],
        {'available': False}, {}, {}, None, None)
    for name in ('divergence', 'ichimoku', 'volume'):
        assert name in components
        assert isinstance(components[name]['score'], float)
        assert -1.0 <= components[name]['score'] <= 1.0
    # missing everything -> the new votes degrade gracefully
    empty = pd.DataFrame({'close': [1.0]})
    comp2, _ = build_component_scores(0.5, empty, {}, [], [], {}, {}, {}, None, None)
    assert comp2['ichimoku']['available'] is False
    assert comp2['volume']['available'] is False


def test_ichimoku_and_volume_votes_directional():
    up = _indicator_frame(rising=True)
    score_up, meta_up = ichimoku_vote(up)
    assert score_up > 0.3 and meta_up['available']
    score_vol, meta_vol = volume_vote(up)
    assert score_vol > 0 and meta_vol['available']
    assert set(meta_vol['subsignals']) <= {'obv', 'mfi', 'thrust'}


def test_confluence_shaping_is_bounded_and_direction_preserving():
    signal = {'kind': 'HOLD'}
    brain = make_brain_decision(
        symbol='TESTUSDT', timeframe='1h', bar_ts=1_700_000_000_000,
        price=100.0, model_prob=0.5, indicators=_indicator_frame(),
        edge_confirmed=False, base_signal=signal)
    shaped = brain['confluence']['shaping_factor']
    assert 0.8 <= shaped <= CONFLUENCE_MAX_FACTOR
    raw = brain['confluence']['raw_score']
    assert np.sign(raw) == np.sign(brain['score']) or brain['score'] == 0


def test_scenario_attached_to_signal():
    signal = {'kind': 'BUY', 'entry': 100.0, 'tp': 103.0, 'sl': 97.0,
              'levels_side': 'LONG', 'power': 0.6, 'prob': 0.7,
              'trend_up': True}
    brain = make_brain_decision(
        symbol='TESTUSDT', timeframe='1h', bar_ts=1_700_000_000_000,
        price=100.0, model_prob=0.7, indicators=_indicator_frame(),
        edge_confirmed=True, base_signal=signal)
    sc = signal.get('scenario')
    assert isinstance(sc, dict) and sc
    # tp and sl are both 3% away -> reward:risk = 1.0
    assert sc['reward_risk'] == pytest.approx(1.0)
    # EV uses the same representative round-trip fee/spread/slippage model as PAPER.
    from backend.signal import ROUND_TRIP_COST_PCT
    assert sc['ev_gross_pct'] == pytest.approx(1.2, abs=0.01)
    assert sc['cost_pct'] == pytest.approx(ROUND_TRIP_COST_PCT)
    assert sc['ev_net_pct'] == pytest.approx(1.2 - ROUND_TRIP_COST_PCT, abs=0.02)
    assert sc['invalidation'] == 97.0


# ---------------- analyst ----------------
def test_local_report_builds_all_sections_and_cites_payload():
    analysis = _minimal_analysis()
    memory = {'available': True,
              'latest': {'bar_ts': 1_700_000_000_000, 'signal_kind': 'HOLD',
                         'price': 64000.0},
              'diff': {'price_change_pct': 2.24},
              'stats': {'matured_trades': 6, 'directional_hit_rate': 0.667,
                        'avg_return_pct': 0.84},
              'timeline': []}
    rep = analyst.local_report(analysis, memory)
    assert rep['engine'] == 'local'
    keys = [s['key'] for s in rep['sections']]
    assert keys == ['summary', 'evidence', 'agreement', 'scenario',
                    'risks', 'short_term', 'memory', 'conclusion']
    body_all = '\n'.join(s['body'] for s in rep['sections'])
    # only payload numbers may appear
    assert '65432.1' in body_all
    assert '99999.9' not in body_all
    # power shown as a percentage
    assert '62' in body_all
    # unavailable feed is reported as missing, not invented
    assert 'غیرفعال' in body_all
    assert '2.24' in body_all  # memory diff cited


def test_local_report_handles_empty_payload():
    rep = analyst.local_report({}, {})
    assert rep['engine'] == 'local'
    assert len(rep['sections']) == 8   # V19.2 added the 5m/30m section


def test_deep_report_falls_back_without_key(monkeypatch):
    monkeypatch.delenv('ZAI_API_KEY', raising=False)
    monkeypatch.delenv('AI_COACH_API_KEY', raising=False)
    analysis = _minimal_analysis()
    rep = analyst.deep_report(analysis, None)
    assert rep['engine'] == 'local'
    assert 'note' in rep
