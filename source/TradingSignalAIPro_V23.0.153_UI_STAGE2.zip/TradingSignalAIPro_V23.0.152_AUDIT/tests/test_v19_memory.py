"""V19: market memory — snapshots, honest maturation, signed outcome stats."""
import os

import pandas as pd
import pytest


@pytest.fixture()
def memory_db(tmp_path, monkeypatch):
    monkeypatch.setenv('TS_AI_MEMORY_DB', str(tmp_path / 'mem.sqlite3'))
    import importlib
    from backend import memory
    importlib.reload(memory)
    return memory


def test_snapshot_and_maturation(memory_db):
    memory = memory_db
    step = memory.TF_MS['1h']
    t0 = 1_700_000_000_000
    brain = {'decision': 'BUY', 'score': 0.4}
    assert memory.save_snapshot('BTCUSDT', '1h', t0, 100.0,
                                {'kind': 'BUY', 'prob': 0.66, 'power': 0.5},
                                brain, {'regime': 'bull'},
                                {'technical': 0.6, 'ml': 0.32})
    # duplicate snapshot for the same bar is ignored (idempotent)
    assert not memory.save_snapshot('BTCUSDT', '1h', t0, 100.0,
                                    {'kind': 'BUY'}, brain)

    rep = memory.memory_report('BTCUSDT', '1h', current_price=101.0)
    assert rep['available'] and rep['snapshots'] == 1
    assert rep['diff']['price_change_pct'] == pytest.approx(1.0)
    assert rep['stats']['matured_trades'] == 0  # nothing matured yet

    frame = pd.DataFrame({'t': [t0, t0 + 12 * step], 'close': [100.0, 105.0]})
    assert memory.mature_snapshots('BTCUSDT', '1h', frame) == 1
    rep = memory.memory_report('BTCUSDT', '1h')
    assert rep['stats']['matured_trades'] == 1
    assert rep['stats']['directional_wins'] == 1
    assert rep['stats']['avg_return_pct'] == pytest.approx(5.0)


def test_sell_rows_report_their_own_pnl(memory_db):
    memory = memory_db
    step = memory.TF_MS['1h']
    t0 = 1_700_000_000_000
    memory.save_snapshot('BTCUSDT', '1h', t0, 100.0, {'kind': 'SELL'}, {'decision': 'SELL'})
    # price RISES 2% -> the SELL lost money
    frame = pd.DataFrame({'t': [t0, t0 + 12 * step], 'close': [100.0, 102.0]})
    memory.mature_snapshots('BTCUSDT', '1h', frame)
    rep = memory.memory_report('BTCUSDT', '1h')
    assert rep['stats']['matured_trades'] == 1
    assert rep['stats']['directional_wins'] == 0
    assert rep['stats']['avg_return_pct'] == pytest.approx(-2.0)


def test_unmatured_snapshots_never_get_fabricated(memory_db):
    memory = memory_db
    t0 = 1_700_000_000_000
    memory.save_snapshot('BTCUSDT', '1h', t0, 100.0, {'kind': 'BUY'}, {'decision': 'BUY'})
    # frame without the exact horizon bar -> stays pending, no invented result
    frame = pd.DataFrame({'t': [t0 + 5 * memory.TF_MS['1h']], 'close': [101.0]})
    memory.mature_snapshots('BTCUSDT', '1h', frame)
    rep = memory.memory_report('BTCUSDT', '1h')
    assert rep['stats']['matured_trades'] == 0
    assert rep['timeline'][0]['realized_return'] is None


def test_hold_rows_excluded_from_directional_stats(memory_db):
    memory = memory_db
    step = memory.TF_MS['1h']
    t0 = 1_700_000_000_000
    memory.save_snapshot('BTCUSDT', '1h', t0, 100.0, {'kind': 'HOLD'}, {'decision': 'HOLD'})
    frame = pd.DataFrame({'t': [t0, t0 + 12 * step], 'close': [100.0, 103.0]})
    memory.mature_snapshots('BTCUSDT', '1h', frame)
    rep = memory.memory_report('BTCUSDT', '1h')
    assert rep['stats']['matured_trades'] == 0  # HOLD is not a directional bet
