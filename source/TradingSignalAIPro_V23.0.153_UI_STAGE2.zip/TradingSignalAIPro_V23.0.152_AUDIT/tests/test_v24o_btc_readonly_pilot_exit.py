import pytest
from backend.btc_readonly_pilot_exit import evaluate_readonly_pilot_exit, append_readonly_pilot_handoff


def _evidence():
    obs={'metrics':{'fetch_pass_count':80,'observation_window_hours':30,'stale_report_count':0,
        'removed_candle_count':0,'drift_critical_count':0,'revision_rate_per_previous_row':0}}
    fail={'status':'READY_READONLY_FAILOVER'}
    pilot={'status':'READY_READONLY_PILOT'}
    sources=[{'status':'PASS'} for _ in range(8)]
    return obs,fail,pilot,sources


def test_pilot_exit_requires_evidence_then_operator_decision(tmp_path):
    obs,fail,pilot,sources=_evidence()
    review=evaluate_readonly_pilot_exit(observability_report=obs,failover_drill=fail,
        pilot_gate_evidence=pilot,cross_source_reports=sources)
    assert review['status']=='REVIEW_REQUIRED'
    proceed=evaluate_readonly_pilot_exit(observability_report=obs,failover_drill=fail,
        pilot_gate_evidence=pilot,cross_source_reports=sources,operator_decision='CONTINUE_READONLY')
    assert proceed['status']=='CONTINUE_READONLY'
    assert proceed['training_allowed'] is False and proceed['live_orders'] is False
    assert append_readonly_pilot_handoff(proceed,handoff_path=tmp_path/'handoff'/'log.jsonl')['status']=='CONTINUE_READONLY'


def test_pilot_exit_blocks_insufficient_evidence_and_supports_stop():
    obs,fail,pilot,sources=_evidence(); obs['metrics']['stale_report_count']=1
    blocked=evaluate_readonly_pilot_exit(observability_report=obs,failover_drill=fail,
        pilot_gate_evidence=pilot,cross_source_reports=sources,operator_decision='CONTINUE_READONLY')
    assert blocked['status']=='BLOCKED'
    obs,fail,pilot,sources=_evidence()
    stopped=evaluate_readonly_pilot_exit(observability_report=obs,failover_drill=fail,
        pilot_gate_evidence=pilot,cross_source_reports=sources,operator_decision='STOP')
    assert stopped['status']=='STOPPED'
