from backend.exit_intelligence import evaluate_exit_intelligence

BASE = {'position_id':'p1','symbol':'BTCUSDT','side':'LONG','entry_price':100,
        'current_price':99,'stop_price':98,'atr':1,'quantity':2,'status':'OPEN'}

def test_long_emergency_and_structure_break_produce_stable_event_key():
    p = dict(BASE, current_price=96, structure_break_against_position=True)
    a = evaluate_exit_intelligence([p])['positions'][0]
    b = evaluate_exit_intelligence([p])['positions'][0]
    assert a['decision'] == 'EXIT_REVIEW_REQUIRED'
    assert a['event_key'] == b['event_key']
    assert 'EMERGENCY_ATR_SHOCK' in a['reasons']

def test_short_stop_breach_is_detected():
    p = dict(BASE, side='SHORT', entry_price=100, current_price=103, stop_price=102)
    r = evaluate_exit_intelligence([p])['positions'][0]
    assert 'STOP_LEVEL_BREACHED' in r['reasons']

def test_closed_non_paper_and_stale_positions_are_not_exited():
    closed = dict(BASE, status='CLOSED')
    nonpaper = dict(BASE, position_id='p2', paper_only=False)
    stale = dict(BASE, position_id='p3', quote_age_seconds=999)
    rows = evaluate_exit_intelligence([closed, nonpaper, stale])['positions']
    assert [x['decision'] for x in rows] == ['IGNORE','IGNORE','HOLD_NO_ACTION']

def test_invalid_atr_and_duplicate_ids_are_rejected():
    bad = dict(BASE, atr=float('nan'))
    result = evaluate_exit_intelligence([bad, BASE])
    assert len(result['invalid_positions']) == 2

def test_no_trigger_holds_and_never_authorizes_execution():
    result = evaluate_exit_intelligence([BASE])
    assert result['positions'][0]['decision'] == 'HOLD_AND_MONITOR'
    assert result['read_only'] and result['paper_only']
    assert not result['creates_orders'] and not result['execution_authorized']
    assert not result['real_orders_enabled']
