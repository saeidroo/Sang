"""V20 tests: pool-of-all-trainings consensus + advisory gate + no-default-ticks."""
import json
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend import consensus  # noqa: E402
from backend.features import FEATURE_SCHEMA_VERSION  # noqa: E402
from backend.consensus import (advisory_gate, blend_probability,  # noqa: E402
                               list_pool_candidates, pool_votes)


# ---------------------------------------------------------------- helpers
class FakeModel:
    """Minimal stand-in for TradingEnsemble (predict on 1 row)."""
    def __init__(self, prob, feature_names):
        self.prob = prob
        self.feature_names = feature_names
        self.is_fitted = True

    def predict_proba(self, X, use_meta=True):
        return float(self.prob)


FEATURES = [f'f{i}' for i in range(5)]


def make_meta_row(prob):
    import pandas as pd
    import numpy as np
    return pd.DataFrame([{k: np.float64(0.5) for k in FEATURES}])


@pytest.fixture
def pool_env(tmp_path, monkeypatch):
    """Isolated models dir with fake metas + stubbed model loader."""
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(tmp_path))
    consensus._CACHE.clear()
    metas = [
        ('ETHUSDT', '4h', {'walk_forward_acc': 0.62, 'edge_confirmed': True,
                           'feature_schema_version': FEATURE_SCHEMA_VERSION}),
        ('SOLUSDT', '1h', {'walk_forward_acc': 0.58, 'edge_confirmed': False,
                           'feature_schema_version': FEATURE_SCHEMA_VERSION}),
        ('ADAUSDT', '15m', {'walk_forward_acc': 0.55, 'edge_confirmed': True,
                            'feature_schema_version': FEATURE_SCHEMA_VERSION}),
        ('XRPUSDT', '1d', {'val_acc': 0.54, 'edge_confirmed': False,
                           'feature_schema_version': FEATURE_SCHEMA_VERSION}),
        ('OLDUSDT', '1h', {'val_acc': 0.99, 'edge_confirmed': True,
                           'feature_schema_version': FEATURE_SCHEMA_VERSION - 1}),  # old schema -> excluded
    ]
    for sym, tf, meta in metas:
        (tmp_path / f'model_{sym}_{tf}.joblib').write_bytes(b'x')
        meta = dict(meta)
        meta['symbol'], meta['timeframe'] = sym, tf
        (tmp_path / f'meta_{sym}_{tf}.json').write_text(
            json.dumps(meta), encoding='utf-8')

    probs = {('ETHUSDT', '4h'): 0.75, ('SOLUSDT', '1h'): 0.40,
             ('ADAUSDT', '15m'): 0.70, ('XRPUSDT', '1d'): 0.30}
    def fake_loader(path):
        name = Path(path).stem[len('model_'):]
        sym, tf = name.rsplit('_', 1)
        if (sym, tf) in probs:
            return FakeModel(probs[(sym, tf)], FEATURES)
        return None
    monkeypatch.setattr(consensus, '_load_model_cached', fake_loader)
    yield tmp_path


# ---------------------------------------------------------------- tests
def test_old_schema_model_excluded(pool_env):
    cands = list_pool_candidates('BTCUSDT', '1h')
    syms = {c['symbol'] for c in cands}
    assert 'OLDUSDT' not in syms, 'model with old feature schema must not vote'
    assert {'ETHUSDT', 'SOLUSDT', 'ADAUSDT', 'XRPUSDT'} <= syms


def test_primary_pair_excluded(pool_env):
    cands = list_pool_candidates('ETHUSDT', '4h')
    assert all(not (c['symbol'] == 'ETHUSDT' and c['timeframe'] == '4h')
               for c in cands), 'primary pair must not vote on itself'


def test_pool_votes_direction_and_weights(pool_env):
    df = make_meta_row(0.5)
    res = pool_votes('BTCUSDT', '1h', df)
    assert res['n'] == 4
    assert res['consensus_dir'] == 'UP'          # two strong UP votes dominate
    assert 0.0 <= res['consensus_prob'] <= 1.0
    assert 0.0 <= res['agreement'] <= 1.0
    assert res['same_symbol_votes'] == 0         # BTC has no other models here
    assert res['same_tf_votes'] == 1             # only SOLUSDT is 1h (OLDUSDT excluded)
    # same-symbol relation must outrank unrelated pairs
    eth = next(v for v in res['votes'] if v['symbol'] == 'ETHUSDT')
    xrp = next(v for v in res['votes'] if v['symbol'] == 'XRPUSDT')
    assert eth['weight'] > xrp['weight']
    # edge_confirmed voters: ETHUSDT + ADAUSDT -> edge_share > 0
    assert res['edge_share'] and res['edge_share'] > 0


def test_same_symbol_other_tf_relation(pool_env):
    res = pool_votes('ETHUSDT', '1h', make_meta_row(0.5))
    eth = next(v for v in res['votes'] if v['symbol'] == 'ETHUSDT')
    assert eth['relation'] == 'same_symbol_other_tf'
    assert res['same_symbol_votes'] == 1


def test_blend_probability_bounded():
    pool = {'n': 10, 'consensus_prob': 0.9}      # would push weight > max
    final, w = blend_probability(0.40, pool)
    assert w == pytest.approx(consensus.BLEND_MAX)
    assert 0.40 < final < 0.9                    # primary still dominates
    final0, w0 = blend_probability(0.62, {'n': 0, 'consensus_prob': None})
    assert final0 == 0.62 and w0 == 0.0
    final1, w1 = blend_probability(0.62, {'n': 1, 'consensus_prob': 0.50})
    assert w1 == pytest.approx(consensus.BLEND_PER_VOTE)
    assert 0.50 < final1 < 0.62


def test_advisory_gate():
    strong = {'n': 4, 'agreement': 0.9, 'edge_share': 0.8}
    ok, note = advisory_gate(strong)
    assert ok
    few = {'n': 2, 'agreement': 0.9, 'edge_share': 0.9}
    ok2, note2 = advisory_gate(few)
    assert not ok2 and 'مدل' in note2
    split = {'n': 5, 'agreement': 0.5, 'edge_share': 0.9}
    ok3, note3 = advisory_gate(split)
    assert not ok3 and 'هم‌جهتی' in note3
    no_edge = {'n': 5, 'agreement': 0.9, 'edge_share': 0.1}
    ok4, note4 = advisory_gate(no_edge)
    assert not ok4 and 'لبه' in note4


def test_pool_votes_empty_when_no_models(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(tmp_path))
    consensus._CACHE.clear()
    res = pool_votes('BTCUSDT', '1h', make_meta_row(0.5))
    assert res['n'] == 0 and res['votes'] == []


def test_pool_votes_never_raises_on_bad_model(pool_env, monkeypatch):
    def bad_loader(path):
        raise RuntimeError('corrupt pickle')
    monkeypatch.setattr(consensus, '_load_model_cached', bad_loader)
    res = pool_votes('BTCUSDT', '1h', make_meta_row(0.5))
    assert res['n'] == 0
    assert res['errors'], 'per-model failures must be recorded'


def test_no_default_ticks_in_ui():
    html = (ROOT / 'frontend' / 'index.html').read_text(encoding='utf-8')
    assert 'class="lrTf" value="1h" checked' not in html
    assert 'class="lrTf" value="4h" checked' not in html
    js = (ROOT / 'frontend' / 'app.js').read_text(encoding='utf-8')
    assert "applyLrPreset('core5')" not in js, 'no automatic preset selection'


def test_longrun_resume_unions_old_markets():
    """Resuming with no UI selection must still continue the old run's markets."""
    from backend import longrun
    old_jobs = [{'symbol': 'BTCUSDT', 'timeframe': '30m'},
                {'symbol': 'ETHUSDT', 'timeframe': '4h'}]
    cfg = longrun.normalize_config({'hours': 1, 'symbols': [], 'timeframes': []})
    assert cfg['timeframes'] == ['1h', '4h']           # backend fallback
    # replicate the union logic from longrun.start (pure part)
    old_syms = {j.get('symbol') for j in old_jobs if j.get('symbol')}
    old_tfs = {j.get('timeframe') for j in old_jobs if j.get('timeframe')}
    merged_syms = list(dict.fromkeys(list(cfg['symbols']) + sorted(old_syms)))[:60]
    merged_tfs = [t for t in longrun.ALLOWED_TFS if t in ({*cfg['timeframes'], *old_tfs})]
    assert set(old_syms) <= set(merged_syms)
    assert {'30m', '4h'} <= set(merged_tfs)
