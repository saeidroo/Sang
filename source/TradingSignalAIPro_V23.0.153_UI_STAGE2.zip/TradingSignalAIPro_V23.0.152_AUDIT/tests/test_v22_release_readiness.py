from backend.release_readiness import production_readiness


def test_readiness_blocks_missing_secrets_and_keys(tmp_path):
    report = production_readiness(env={}, private_key_path=str(tmp_path/'missing.pem'),
                                  trusted_source_key_path=str(tmp_path/'trusted.pem'),
                                  db_path=str(tmp_path/'db.sqlite'), host='127.0.0.1')
    assert report['status'] == 'BLOCKED'
    assert 'api_token_present' in report['failed_blocking_checks']
    assert 'signing_private_key_present' in report['failed_blocking_checks']
    assert 'trusted_source_key_present' in report['failed_blocking_checks']


def test_readiness_never_discloses_token_value(tmp_path):
    token = 'VERY_SECRET_DO_NOT_PRINT'
    report = production_readiness(env={'TS_WITNESS_API_TOKEN': token, 'TS_WITNESS_REMOTE_ENDPOINT':'https://example.invalid'},
                                  private_key_path=str(tmp_path/'missing.pem'), host='0.0.0.0')
    rendered = repr(report)
    assert token not in rendered
    assert report['status'] == 'BLOCKED'
    assert 'remote_endpoint_https' not in report['failed_blocking_checks']
    assert 'service_bind_loopback_or_proxy' in report['warnings']


def test_readiness_rejects_non_https_remote_endpoint():
    report = production_readiness(env={'TS_WITNESS_REMOTE_ENDPOINT':'http://example.invalid'},
                                  private_key_path='/not/present', host='127.0.0.1')
    assert 'remote_endpoint_https' in report['failed_blocking_checks']
