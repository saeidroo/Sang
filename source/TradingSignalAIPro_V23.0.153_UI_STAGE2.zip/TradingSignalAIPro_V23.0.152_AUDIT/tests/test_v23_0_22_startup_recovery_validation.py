import os

from backend import paper_live, autopilot


def test_empty_paper_ledger_passes_read_only_validation(tmp_path, monkeypatch):
    db = tmp_path / 'paper.sqlite3'
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(db))
    result = paper_live.validate_paper_ledger()
    assert result['valid'] is True
    assert result['read_only'] is True
    assert result['trade_rows'] == 0
    assert result['blocks_new_entries'] is False


def test_inconsistent_open_trade_blocks_entry_start(monkeypatch):
    original = autopilot.status
    calls = []
    monkeypatch.setattr(autopilot, '_load_config', lambda: None)
    monkeypatch.setattr(autopilot, 'status', lambda: {'running': False})
    monkeypatch.setattr(autopilot, '_log_decision', lambda *a, **k: calls.append((a, k)))
    monkeypatch.setattr(paper_live, 'validate_paper_ledger', lambda: {
        'valid': False, 'errors': ['incomplete_closed_rows:1'], 'blocks_new_entries': True
    })
    result = autopilot.start(resume_entries=True)
    assert result['ok'] is False
    assert result['blocked'] is True
    assert result['entries_enabled'] is False
    assert result['recovery_validation']['errors'] == ['incomplete_closed_rows:1']
    assert any(x[0][0] == 'PAPER_LEDGER_RECOVERY_BLOCKED' for x in calls)
    monkeypatch.setattr(autopilot, 'status', original)


def test_ledger_validation_detects_invalid_status(tmp_path, monkeypatch):
    db = tmp_path / 'paper.sqlite3'
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(db))
    paper_live.init_db()
    with paper_live._connect() as c:
        c.execute("""INSERT INTO paper_live_trades
            (opened_at,symbol,market,exchange,requested_exchange,side,quantity,notional,
             reference_entry,entry_fill,entry_fee,stop_price,target_price,status,settings_json)
            VALUES(1,'BTCUSDT','spot','binance','auto','LONG',1,100,100,100,0,95,110,'BROKEN','{}')""")
    result = paper_live.validate_paper_ledger()
    assert result['valid'] is False
    assert 'unknown_status_rows:1' in result['errors']
