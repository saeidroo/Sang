from backend import storm_learning as sl


def _setup(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'storm_learning.sqlite3')


def _add(con, direction, result, ts, phase='early', regime='down', score=80):
    cur = con.execute('''INSERT INTO scout_sightings
        (symbol,ts,price,score,phase,direction,verified,pattern,market_regime)
        VALUES(?,?,?,?,?,?,?,?,?)''',
        ('XYZUSDT', ts, 100, score, phase, direction, 1, 'test', regime))
    con.execute('''INSERT INTO scout_outcomes
        (sighting_id,horizon,due_ts,resolved_ts,return_pct,result)
        VALUES(?,?,?,?,?,?)''',
        (cur.lastrowid, '1h', ts + 3600, ts + 3600, 2 if result == 'success' else -3, result))


def test_audit_finds_repeated_bearish_failure_context(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    with sl._db() as con:
        for i in range(4): _add(con, 'down', 'fake', 1000 + i)
        _add(con, 'down', 'success', 1010)
        _add(con, 'up', 'success', 1020)
    report = sl.failure_pattern_audit(min_samples=5)
    assert report['groups_meeting_min_samples'] == 1
    pattern = report['patterns'][0]
    assert pattern['direction'] == 'down' and pattern['failures'] == 4
    assert pattern['successes'] == 1 and pattern['failure_rate'] == 0.8
    assert report['paper_only'] is True


def test_insufficient_groups_are_not_reported(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    with sl._db() as con:
        for i in range(4): _add(con, 'up', 'fake', 2000 + i)
    assert sl.failure_pattern_audit(min_samples=5)['patterns'] == []


def test_groups_separate_market_context(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    with sl._db() as con:
        for i in range(5): _add(con, 'up', 'fake', 3000 + i, regime='up')
        for i in range(5): _add(con, 'up', 'success', 4000 + i, regime='sideways', phase='breakout', score=55)
    report = sl.failure_pattern_audit(min_samples=5)
    assert len(report['patterns']) == 2
    assert {p['market_regime'] for p in report['patterns']} == {'up', 'sideways'}


def test_invalid_limits_rejected(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    try: sl.failure_pattern_audit(min_samples=1)
    except ValueError: pass
    else: raise AssertionError('invalid min_samples accepted')
