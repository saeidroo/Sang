from __future__ import annotations

import json
import sqlite3
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch

import pytest

from backend import autopilot, paper_live


@pytest.fixture

def isolated_paper_db(tmp_path, monkeypatch):
    db = tmp_path / "paper_live.sqlite3"
    monkeypatch.setattr(paper_live, "_db_path", lambda: db)
    monkeypatch.setattr(paper_live, "get_quote", lambda symbol, market="spot", exchange="auto", use_cache=True: {
        "symbol": symbol, "market": market, "exchange": "binance", "exchange_name": "Binance",
        "price": 100.0, "timestamp": time.time(), "source": "test-public-ticker",
        "authenticated": False, "cached": False, "fallback": False,
    })
    monkeypatch.setattr(paper_live, "get_state", lambda refresh_quotes=True: {
        "account": {"disconnected_positions": 0}, "open_positions": [],
    })
    paper_live.init_db()
    return db


def test_same_idempotency_key_returns_same_trade_without_second_quote(isolated_paper_db, monkeypatch):
    quote_calls = []
    original_get_quote = paper_live.get_quote

    def counted_quote(*args, **kwargs):
        quote_calls.append(args[0])
        return original_get_quote(*args, **kwargs)

    monkeypatch.setattr(paper_live, "get_quote", counted_quote)
    first = paper_live.open_position(
        "BTCUSDT", "LONG", "spot", "auto", "1h", entry_source="autopilot",
        idempotency_key="autopilot-v23:BTCUSDT:spot:1h:1700000000000",
    )
    replay = paper_live.open_position(
        "BTCUSDT", "LONG", "spot", "auto", "1h", entry_source="autopilot",
        idempotency_key="autopilot-v23:BTCUSDT:spot:1h:1700000000000",
    )

    assert first["id"] == replay["id"]
    assert replay["idempotent_replay"] is True
    assert replay["status"] == "OPEN"
    assert len(quote_calls) == 1
    with sqlite3.connect(isolated_paper_db) as conn:
        assert conn.execute("SELECT COUNT(*) FROM paper_live_trades").fetchone()[0] == 1


def test_idempotency_survives_closed_trade_and_process_style_replay(isolated_paper_db):
    key = "autopilot-v23:ETHUSDT:perp:4h:1700000000000"
    first = paper_live.open_position("ETHUSDT", "LONG", "perp", "auto", "4h", idempotency_key=key)
    with sqlite3.connect(isolated_paper_db) as conn:
        conn.execute("UPDATE paper_live_trades SET status='CLOSED', closed_at=? WHERE id=?",
                     (time.time(), first["id"]))
        conn.commit()

    replay = paper_live.open_position("ETHUSDT", "LONG", "perp", "auto", "4h", idempotency_key=key)
    assert replay["id"] == first["id"]
    assert replay["idempotent_replay"] is True
    assert replay["status"] == "CLOSED"
    with sqlite3.connect(isolated_paper_db) as conn:
        assert conn.execute("SELECT COUNT(*) FROM paper_live_trades").fetchone()[0] == 1


def test_concurrent_same_key_creates_exactly_one_trade(isolated_paper_db):
    key = "autopilot-v23:SOLUSDT:spot:15m:1700000000000"
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda _: paper_live.open_position(
            "SOLUSDT", "LONG", "spot", "auto", "15m", idempotency_key=key
        ), range(2)))
    assert results[0]["id"] == results[1]["id"]
    assert sum(1 for r in results if not r.get("idempotent_replay")) == 1
    with sqlite3.connect(isolated_paper_db) as conn:
        assert conn.execute("SELECT COUNT(*) FROM paper_live_trades").fetchone()[0] == 1


def test_different_candle_keys_can_create_later_trade_after_close(isolated_paper_db):
    first = paper_live.open_position(
        "XRPUSDT", "LONG", "spot", "auto", "1h", idempotency_key="autopilot-v23:XRPUSDT:spot:1h:1000"
    )
    with sqlite3.connect(isolated_paper_db) as conn:
        conn.execute("UPDATE paper_live_trades SET status='CLOSED', closed_at=? WHERE id=?",
                     (time.time(), first["id"]))
        conn.commit()
    second = paper_live.open_position(
        "XRPUSDT", "LONG", "spot", "auto", "1h", idempotency_key="autopilot-v23:XRPUSDT:spot:1h:2000"
    )
    assert second["id"] != first["id"]
    assert second["idempotent_replay"] is False


def test_idempotency_key_validation_rejects_unbounded_or_unsafe_key(isolated_paper_db):
    with pytest.raises(ValueError, match="شناسهٔ یکتای ورود"):
        paper_live.open_position("BTCUSDT", "LONG", "spot", idempotency_key="bad key with spaces")
    with pytest.raises(ValueError, match="شناسهٔ یکتای ورود"):
        paper_live.open_position("BTCUSDT", "LONG", "spot", idempotency_key="x" * 181)


def _prepare_autopilot(monkeypatch, tmp_path):
    runtime_db = tmp_path / "autopilot_runtime.sqlite3"
    # Entry scan's auxiliary regime/MTF enrichments are optional and must fail
    # neutrally in this offline idempotency test; do not reach public exchanges.
    monkeypatch.setattr(autopilot, "fetch_candles", lambda *a, **k: (_ for _ in ()).throw(
        RuntimeError("offline unit-test candle source")))
    monkeypatch.setattr(autopilot, "_entry_atr_context", lambda base, market, timeframe, decision: {
        "atr_value": 1.0, "atr_pct": 1.0, "reference_close": 100.0,
        "candle_ts": float(decision.get("candle_ts") or 1_700_000_000_000.0),
        "timeframe": timeframe, "market_symbol": base + "USDT", "source": "test",
    })
    monkeypatch.setattr(autopilot, "_runtime_state_db", lambda: runtime_db)
    with autopilot._LOCK:
        autopilot._STATE.update({
            "entries_enabled": True,
            "runtime_state_loaded": True,
            "runtime_state_error": "",
            "cooldowns": {},
            "candle_seen": {},
            "watchlist": [{"symbol": "BTCUSDT", "volume": 1_000_000_000.0}],
            "watchlist_at": time.time(),
            "watchlist_source": "test",
            "last_entry_summary": {},
        })
    autopilot._CONFIG.update({
        "markets": ["spot"], "timeframe": "1h", "max_open_positions": 3,
        "max_positions_per_base": 1, "diversification_enabled": False,
        "max_symbols": 1,
    })
    monkeypatch.setattr(autopilot, "_watchlist_view", lambda: {
        "symbols": ["BTCUSDT"], "detail": [{"symbol": "BTCUSDT", "volume": 1_000_000_000.0}],
    })
    monkeypatch.setattr(autopilot, "_decide_entry", lambda *a, **k: {
        "kind": "BUY", "confidence": 0.9, "brain": "ml", "detail": "test signal",
        "candle_ts": 1_700_000_000_000.0, "edge_confirmed": True,
        "decision_context": {"test_feature": 1.0}, "learning_gate": {},
    })
    monkeypatch.setattr(autopilot, "_candidate_rank_score", lambda *a, **k: 90.0)
    monkeypatch.setattr(autopilot, "_risk_overrides", lambda: {})
    monkeypatch.setattr(autopilot, "_apply_learning_risk_scale", lambda overrides, gate: overrides)


def test_failed_open_does_not_consume_candidate_candle(monkeypatch, tmp_path):
    _prepare_autopilot(monkeypatch, tmp_path)
    with patch.object(paper_live, "get_state", return_value={"open_positions": [], "account": {}}), \
         patch.object(paper_live, "open_position", side_effect=RuntimeError("simulated crash before commit")):
        result = autopilot._entry_scan()
    key = autopilot._candle_seen_key("BTCUSDT", "spot", "1h")
    assert result["opened"] == 0
    assert key not in autopilot._STATE["candle_seen"]


def test_committed_open_with_lost_checkpoint_replays_without_duplicate(monkeypatch, tmp_path):
    _prepare_autopilot(monkeypatch, tmp_path)
    key = autopilot._candle_seen_key("BTCUSDT", "spot", "1h")
    mark_calls = {"n": 0}
    original_mark = autopilot._mark_candle_seen

    def fail_first_post_commit_mark(candle_key, candle_ts):
        mark_calls["n"] += 1
        if mark_calls["n"] == 1:
            return False
        return original_mark(candle_key, candle_ts)

    open_calls = []

    def idempotent_open(*args, **kwargs):
        open_calls.append(kwargs.get("idempotency_key"))
        if len(open_calls) == 1:
            return {"id": 44, "notional": 100.0, "stop_price": 98.0, "target_price": 103.0,
                    "idempotent_replay": False, "status": "OPEN"}
        return {"id": 44, "notional": 100.0, "stop_price": 98.0, "target_price": 103.0,
                "idempotent_replay": True, "status": "OPEN"}

    with patch.object(paper_live, "get_state", return_value={"open_positions": [], "account": {}}), \
         patch.object(paper_live, "open_position", side_effect=idempotent_open), \
         patch.object(autopilot, "_mark_candle_seen", side_effect=fail_first_post_commit_mark):
        first = autopilot._entry_scan()
        assert key not in autopilot._STATE["candle_seen"]
        second = autopilot._entry_scan()

    assert first["opened"] == 1
    assert second["opened"] == 0
    assert second["skipped"] >= 1
    assert open_calls[0] == open_calls[1]
    assert key in autopilot._STATE["candle_seen"]
    assert autopilot._STATE["candle_seen"][key] == 1_700_000_000_000.0


def test_entry_key_is_scope_specific_but_direction_independent():
    first = autopilot._entry_idempotency_key("btcusdt", "spot", "1h", 1234.0)
    same_opportunity = autopilot._entry_idempotency_key("BTCUSDT", "spot", "1h", 1234.0)
    other_market = autopilot._entry_idempotency_key("BTCUSDT", "perp", "1h", 1234.0)
    other_tf = autopilot._entry_idempotency_key("BTCUSDT", "spot", "4h", 1234.0)
    other_candle = autopilot._entry_idempotency_key("BTCUSDT", "spot", "1h", 5678.0)
    assert first == same_opportunity
    assert len({first, other_market, other_tf, other_candle}) == 4


def test_database_migration_adds_unique_key_column_and_index(isolated_paper_db):
    with sqlite3.connect(isolated_paper_db) as conn:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(paper_live_trades)")}
        indexes = {row[1] for row in conn.execute("PRAGMA index_list(paper_live_trades)")}
    assert "entry_idempotency_key" in columns
    assert "ux_paper_live_entry_idempotency" in indexes


def test_migrates_legacy_paper_trades_table_additively(tmp_path, monkeypatch):
    db = tmp_path / "legacy_paper_live.sqlite3"
    monkeypatch.setattr(paper_live, "_db_path", lambda: db)
    with sqlite3.connect(db) as conn:
        conn.execute("""CREATE TABLE paper_live_trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            opened_at REAL NOT NULL, symbol TEXT NOT NULL, market TEXT NOT NULL,
            exchange TEXT NOT NULL, side TEXT NOT NULL, quantity REAL NOT NULL,
            notional REAL NOT NULL, reference_entry REAL NOT NULL, entry_fill REAL NOT NULL,
            entry_fee REAL NOT NULL, stop_price REAL NOT NULL, target_price REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'OPEN', closed_at REAL, reference_exit REAL,
            exit_fill REAL, exit_fee REAL, gross_pnl REAL, net_pnl REAL, exit_reason TEXT,
            last_price REAL, last_price_at REAL, settings_json TEXT NOT NULL
        )""")
        conn.commit()
    paper_live.init_db()
    with sqlite3.connect(db) as conn:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(paper_live_trades)")}
        indexes = {row[1] for row in conn.execute("PRAGMA index_list(paper_live_trades)")}
    assert {"requested_exchange", "timeframe", "entry_context_json", "entry_idempotency_key"}.issubset(columns)
    assert "ux_paper_live_entry_idempotency" in indexes
