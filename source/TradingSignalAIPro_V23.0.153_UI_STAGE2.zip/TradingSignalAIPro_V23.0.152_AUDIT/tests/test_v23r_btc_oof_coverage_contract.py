import copy, json, hashlib
import pytest
from backend.btc_oof_coverage import build_oof_coverage_contract, require_oof_coverage_contract
from backend.btc_baseline import evaluate_btc_4h_baselines
from backend.btc_training_registry import load_training_run, register_training_run
from test_v23o_btc_training_registry import _dataset, _canonical


def test_contract_is_deterministic_and_bound_to_dataset(tmp_path):
    ds = _dataset(tmp_path)
    a = build_oof_coverage_contract(ds)
    b = build_oof_coverage_contract(ds)
    assert a == b
    assert a['expected_prediction_count_per_model'] == sum(map(len, a['fold_sample_indices'].values()))
    assert require_oof_coverage_contract(a, dataset_hash=ds['manifest']['dataset_hash']) == a
    with pytest.raises(ValueError, match='dataset_hash_mismatch'):
        require_oof_coverage_contract(a, dataset_hash='0'*64)


def test_trainer_registers_exact_dataset_fold_coverage(tmp_path):
    ds = _dataset(tmp_path)
    result = evaluate_btc_4h_baselines(ds, training_registry_dir=tmp_path/'registry')
    contract = result['oof_coverage_contract']
    assert contract['schema_version'] == 'btc-oof-coverage-v1'
    assert contract['expected_fold_ids'] == [int(x) for x in contract['fold_sample_indices']]
    for run in result['training_runs'].values():
        record = load_training_run(run['run_id'], registry_dir=tmp_path/'registry')
        assert record['oof_coverage_contract'] == contract
        assert record['oof_audit']['status'] == 'PASS'


def test_registry_rejects_fold_sample_mismatch_even_if_global_counts_match(tmp_path):
    ds = _dataset(tmp_path)
    result = evaluate_btc_4h_baselines(ds)
    model, artifact = next(iter(result['training_runs'].items()))
    rows = result['oof_predictions']
    report = {'predictions': rows[rows.model == model].to_dict(orient='records'),
              'fold_reports': [r for r in result['fold_reports'] if r['model'] == model],
              'evaluation_hash': result['summary']['evaluation_hash']}
    contract = copy.deepcopy(result['oof_coverage_contract'])
    first_fold = next(iter(contract['fold_sample_indices']))
    contract['fold_sample_indices'][first_fold][0] += 999999
    contract['expected_sample_indices'] = sorted(x for values in contract['fold_sample_indices'].values() for x in values)
    body = dict(contract); body.pop('contract_sha256')
    contract['contract_sha256'] = hashlib.sha256(_canonical(body).encode()).hexdigest()
    with pytest.raises(ValueError, match='fold_sample_coverage_mismatch'):
        register_training_run(artifact, ds['manifest']['lineage'], report,
                              registry_dir=tmp_path/'registry', expected_coverage_contract=contract)
    assert not (tmp_path/'registry'/'btc_training_runs.jsonl').exists()


def test_registry_load_rechecks_coverage_contract(tmp_path):
    ds = _dataset(tmp_path)
    result = evaluate_btc_4h_baselines(ds, training_registry_dir=tmp_path/'registry')
    run = next(iter(result['training_runs'].values()))
    path = tmp_path/'registry'/'btc_training_runs.jsonl'
    row = json.loads(path.read_text().splitlines()[0])
    row['oof_coverage_contract']['expected_sample_indices'].append(123456789)
    # Re-sign outer record to ensure nested contract validation is exercised.
    body = dict(row); body.pop('record_sha256', None)
    row['record_sha256'] = hashlib.sha256(_canonical(body).encode()).hexdigest()
    path.write_text(_canonical(row)+'\n')
    with pytest.raises(ValueError, match='oof_coverage_contract_hash_mismatch|oof_coverage_summary_mismatch'):
        load_training_run(run['run_id'], registry_dir=tmp_path/'registry')
