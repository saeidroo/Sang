"""V19: API surface — new endpoints registered, analyze stays intact."""
import numpy as np
import pandas as pd
import pytest

from backend.api import app


@pytest.fixture()
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client


def test_v19_routes_registered():
    rules = {r.rule for r in app.url_map.iter_rules()}
    assert '/api/analyst/report' in rules
    assert '/api/analyst/status' in rules
    assert '/api/memory' in rules
    assert '/api/analyze' in rules


def test_health_reports_v19_brain(client):
    from backend.api import APP_VERSION
    data = client.get('/api/health').get_json()
    # keep the test in sync with the app instead of hardcoding a version
    assert data['version'] == APP_VERSION
    from backend.brain import BRAIN_VERSION
    assert data['decision_brain'] == BRAIN_VERSION


def test_analyst_status_shape(client):
    data = client.get('/api/analyst/status').get_json()
    assert 'available' in data and 'model' in data and 'note' in data


def test_memory_endpoint_validates_symbol(client):
    resp = client.get('/api/memory?symbol=BAD;DROP&timeframe=1h')
    assert resp.status_code == 400
    resp = client.get('/api/memory?symbol=BTCUSDT&timeframe=1h')
    assert resp.status_code == 200
    data = resp.get_json()
    assert 'available' in data


def test_analyst_report_requires_valid_market(client):
    resp = client.post('/api/analyst/report', json={'symbol': 'X', 'timeframe': '1h'})
    assert resp.status_code == 400


def test_analyst_report_without_model_returns_404(client, tmp_path, monkeypatch):
    # point models dir at an empty temp dir so no saved model exists
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(tmp_path / 'models'))
    import importlib
    from backend import storage, api
    importlib.reload(storage)
    importlib.reload(api)
    api.app.config['TESTING'] = True
    # V21: no live network in the test: hand the pipeline a synthetic frame so the
    # "no trained model -> 404" branch is what is actually exercised.
    import time as _t
    n, step = 400, 3600 * 1000
    t0 = int(_t.time() * 1000) - (n + 5) * step
    rng = np.random.default_rng(7)
    close = 100 + np.cumsum(rng.normal(0, 0.5, n))
    frame = pd.DataFrame({'t': [t0 + i * step for i in range(n)], 'open': close - 0.1,
                          'high': close + 0.6, 'low': close - 0.6, 'close': close,
                          'volume': rng.uniform(10, 20, n)})
    frame.attrs['source'] = 'test'
    monkeypatch.setattr(api, 'fetch_candles', lambda *a, **k: frame)
    with api.app.test_client() as c:
        resp = c.post('/api/analyst/report', json={'symbol': 'BTCUSDT', 'timeframe': '1h'})
        assert resp.status_code == 404
        data = resp.get_json()
        assert data.get('has_model') is False
