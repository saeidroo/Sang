"""Shared offline adapters for legacy paper-entry tests.

Older tests stubbed get_quote before AUTO entries required cross-exchange
consensus. When a test replaces get_quote, route the AUTO consensus call through
that stub; otherwise retain the production consensus implementation. Tests
that explicitly stub get_consensus_quote continue to take precedence.
"""
from __future__ import annotations

import pytest

from backend import paper_live

_ORIGINAL_GET_QUOTE = paper_live.get_quote
_ORIGINAL_GET_CONSENSUS_QUOTE = paper_live.get_consensus_quote
_ORIGINAL_FETCH_CANDLES = paper_live.fetch_pinned_closed_candles_complete


@pytest.fixture(autouse=True)
def _adapt_legacy_quote_mocks(monkeypatch):
    def consensus_adapter(symbol, market="spot", **kwargs):
        if paper_live.get_quote is not _ORIGINAL_GET_QUOTE:
            return paper_live.get_quote(symbol, market, "auto")
        return _ORIGINAL_GET_CONSENSUS_QUOTE(symbol, market, **kwargs)

    def candle_adapter(row, **kwargs):
        # Legacy unit tests that stub ticker quotes do not model historical OHLCV.
        # Return no replay candles in that isolated mock-only case; production
        # code still performs the complete pinned-venue replay.
        if paper_live.get_quote is not _ORIGINAL_GET_QUOTE:
            return []
        return _ORIGINAL_FETCH_CANDLES(row, **kwargs)

    monkeypatch.setattr(paper_live, "get_consensus_quote", consensus_adapter)
    monkeypatch.setattr(paper_live, "fetch_pinned_closed_candles_complete", candle_adapter)
