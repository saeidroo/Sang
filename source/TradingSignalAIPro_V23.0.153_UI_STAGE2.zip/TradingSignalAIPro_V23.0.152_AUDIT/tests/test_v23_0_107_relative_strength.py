from backend.scout import _annotate_relative_strength, _apply_brain_priority


def test_relative_strength_ranks_stronger_peer_higher():
    items = [
        {"base": "AAA", "change_1h": 4.0, "change_24h": 12.0, "volume_usd": 9_000_000},
        {"base": "BBB", "change_1h": 1.0, "change_24h": 3.0, "volume_usd": 2_000_000},
        {"base": "CCC", "change_1h": -1.0, "change_24h": -2.0, "volume_usd": 500_000},
    ]
    _annotate_relative_strength(items)
    scores = {x["base"]: x["relative_strength_score"] for x in items}
    assert scores["AAA"] > scores["BBB"] > scores["CCC"]
    assert all(x["relative_strength_basis"] == "same_scan_direction_adjusted_percentile" for x in items)


def test_missing_fields_are_not_fabricated_and_weights_renormalize():
    items = [
        {"base": "AAA", "change_1h": 2.0, "change_24h": None, "volume_usd": None},
        {"base": "BBB", "change_1h": -1.0, "change_24h": None, "volume_usd": None},
        {"base": "CCC", "change_1h": None, "change_24h": None, "volume_usd": None},
    ]
    _annotate_relative_strength(items)
    assert items[0]["relative_strength_score"] == 100.0
    assert items[1]["relative_strength_score"] == 0.0
    assert items[2]["relative_strength_score"] is None
    assert items[2]["relative_strength_basis"] == "insufficient_peer_data"


def test_relative_strength_is_display_tiebreaker_only():
    items = [
        {"score": 60, "relative_strength_score": 10},
        {"score": 60, "relative_strength_score": 90},
    ]
    ordered = _apply_brain_priority(items)
    assert ordered[0]["relative_strength_score"] == 90
    assert all(x["score"] == 60 for x in ordered)
