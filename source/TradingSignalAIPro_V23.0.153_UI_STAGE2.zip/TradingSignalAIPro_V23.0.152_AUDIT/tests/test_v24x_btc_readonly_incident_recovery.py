import json,pytest
from backend.btc_readonly_incident_export import build_incident_export_bundle,verify_incident_export_bundle
from backend.btc_readonly_incident_recovery import verify_incident_witness_receipt,run_incident_recovery_drill
from backend.witness_server import bootstrap_keys,init_db,record_anchor,digest_anchor


def make_anchor(bundle):
 v=verify_incident_export_bundle(bundle); m=v['manifest']
 return {'schema_version':'ts-ai-readonly-incident-anchor-v1','bundle_sha256':v['bundle_sha256'],
  'manifest_sha256':m['manifest_sha256'],'incident_log_sha256':m['incident_log_sha256'],
  'incident_head_sha256':m['head_sha256'],'event_count':m['event_count'],
  'scope':'read_only_btc_4h_incident_audit','training_allowed':False,'live_orders':False}

def fixture(tmp_path):
 log=tmp_path/'incidents.jsonl'; log.write_bytes(b'')
 bundle=tmp_path/'export.zip'; build_incident_export_bundle(log_path=log,output_path=bundle)
 priv=tmp_path/'private.pem'; pub=tmp_path/'public.pem'; db=tmp_path/'witness.sqlite'
 bootstrap_keys(priv,pub); init_db(db)
 receipt=record_anchor(db,priv,make_anchor(bundle))
 return log,bundle,priv,pub,db,receipt

def test_receipt_verification_and_non_destructive_recovery(tmp_path):
 log,bundle,priv,pub,db,receipt=fixture(tmp_path)
 report=run_incident_recovery_drill(bundle,receipt,pinned_public_key_path=pub,
   highwater_path=tmp_path/'highwater.json',recovery_dir=tmp_path/'restore')
 assert report['restore_verification_passed'] and report['tamper_detection_passed']
 assert report['training_allowed'] is False and report['live_orders'] is False
 assert (tmp_path/'restore'/'recovered-incidents.jsonl').read_bytes()==log.read_bytes()

def test_anti_rollback_rejects_older_witness_sequence(tmp_path):
 log,bundle1,priv,pub,db,receipt1=fixture(tmp_path)
 bundle2=tmp_path/'second.zip'; build_incident_export_bundle(log_path=log,output_path=bundle2)
 receipt2=record_anchor(db,priv,make_anchor(bundle2))
 high=tmp_path/'highwater.json'
 verify_incident_witness_receipt(bundle2,receipt2,pinned_public_key_path=pub,highwater_path=high)
 with pytest.raises(ValueError,match='rollback'):
  verify_incident_witness_receipt(bundle1,receipt1,pinned_public_key_path=pub,highwater_path=high)

def test_receipt_cannot_be_reused_for_different_bundle(tmp_path):
 log,bundle,priv,pub,db,receipt=fixture(tmp_path)
 second=tmp_path/'second.zip'; build_incident_export_bundle(log_path=log,output_path=second)
 with pytest.raises(ValueError,match='anchor_mismatch'):
  verify_incident_witness_receipt(second,receipt,pinned_public_key_path=pub)

def test_tampered_export_blocks_recovery(tmp_path):
 log,bundle,priv,pub,db,receipt=fixture(tmp_path)
 bundle.write_bytes(b'not a zip')
 with pytest.raises(Exception):
  run_incident_recovery_drill(bundle,receipt,pinned_public_key_path=pub,recovery_dir=tmp_path/'restore')

def test_highwater_equivocation_rejected(tmp_path):
 log,bundle,priv,pub,db,receipt=fixture(tmp_path); high=tmp_path/'highwater.json'
 verify_incident_witness_receipt(bundle,receipt,pinned_public_key_path=pub,highwater_path=high)
 forged=dict(receipt); forged['anchor_digest']='f'*64
 # Invalid signatures are rejected before high-water state can be changed.
 with pytest.raises(Exception): verify_incident_witness_receipt(bundle,forged,pinned_public_key_path=pub,highwater_path=high)
