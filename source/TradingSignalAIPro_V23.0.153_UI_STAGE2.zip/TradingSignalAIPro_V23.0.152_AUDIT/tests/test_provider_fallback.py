import unittest
from unittest.mock import patch
import pandas as pd
from backend import data


class ProviderFallbackTests(unittest.TestCase):
    def test_auto_falls_through_to_next_provider(self):
        frame = pd.DataFrame([{
            't': (1700000000000 // 3600_000) * 3600_000 + i * 3600_000, 'open': 100+i,
            'high': 102+i, 'low': 99+i, 'close': 101+i, 'volume': 5
        } for i in range(260)])
        calls = []
        def fail(*args):
            calls.append('binance')
            raise RuntimeError('blocked')
        def succeed(*args):
            calls.append('bybit')
            return frame.copy()
        with patch.dict(data.SOURCE_FUNCS, {'binance': fail, 'bybit': succeed}), \
             patch.object(data, '_save_cache'), \
             patch.object(data, '_SOURCE_SUCCESS_TS', {}):
            out = data.fetch_candles('BTCUSDT', '1h', 250, 'auto')
        self.assertEqual(out.attrs['source'], 'bybit')
        self.assertEqual(calls, ['binance', 'bybit'])
        self.assertEqual(len(out), 250)

    def test_coinmarketcap_requires_key(self):
        with patch.dict('os.environ', {'CMC_API_KEY': ''}):
            with self.assertRaisesRegex(RuntimeError, 'CMC_API_KEY'):
                data.fetch_coinmarketcap('BTCUSDT', '1h', 250)


if __name__ == '__main__':
    unittest.main()
