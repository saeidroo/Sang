from backend.autopilot import RISK_PRESETS, _config_value


def test_three_quick_profiles_are_bounded_and_distinct():
    assert set(RISK_PRESETS) == {"conservative", "balanced", "assertive"}
    assert RISK_PRESETS["conservative"]["risk_per_trade_pct"] < RISK_PRESETS["balanced"]["risk_per_trade_pct"]
    assert RISK_PRESETS["balanced"]["risk_per_trade_pct"] < RISK_PRESETS["assertive"]["risk_per_trade_pct"]
    assert RISK_PRESETS["conservative"]["markets"] == ["spot"]
    assert RISK_PRESETS["balanced"]["markets"] == ["spot"]
    assert RISK_PRESETS["assertive"]["markets"] == ["spot", "perp"]
    for preset in RISK_PRESETS.values():
        assert preset["max_daily_loss_pct"] <= 2.0
        assert preset["max_drawdown_pct"] <= 10.0
        assert preset["max_portfolio_risk_pct"] <= 1.5
        assert preset["max_open_positions"] <= 4


def test_capital_setting_validation():
    assert _config_value("daily_start_balance", 2500) == 2500.0
    for invalid in (0, 9.99, float("nan"), float("inf"), "not-a-number"):
        try:
            _config_value("daily_start_balance", invalid)
        except ValueError:
            pass
        else:
            raise AssertionError(f"invalid capital accepted: {invalid!r}")


def test_profile_values_are_compatible_with_backend_validators():
    for preset in RISK_PRESETS.values():
        for key, value in preset.items():
            if key == "risk_preset":
                continue
            _config_value(key, value)


def test_capital_change_persists_to_paper_ledger_and_config(tmp_path, monkeypatch):
    from backend import autopilot, paper_live
    import copy
    monkeypatch.setenv("TRADING_AI_MODELS_DIR", str(tmp_path / "models"))
    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(tmp_path / "paper.sqlite3"))
    monkeypatch.setattr(autopilot, "status", lambda: {"ok": True})
    monkeypatch.setattr(autopilot, "_log_decision", lambda *args, **kwargs: None)
    original_config = copy.deepcopy(autopilot._CONFIG)
    original_balance = paper_live.SETTINGS["initial_balance"]
    try:
        autopilot._CONFIG = dict(autopilot.DEFAULT_CONFIG)
        paper_live.SETTINGS["initial_balance"] = 1000.0
        result = autopilot.update_config({"daily_start_balance": 2500})
        assert result == {"ok": True}
        assert paper_live.SETTINGS["initial_balance"] == 2500.0
        saved = (tmp_path / "models" / "autopilot_config.json").read_text(encoding="utf-8")
        assert '"daily_start_balance": 2500.0' in saved
        ledger = paper_live.reconcile_account_equity()
        assert ledger["initial_balance"] == 2500.0
        assert ledger["valid"]
        # Simulate a process restart: config load must restore the Paper balance.
        autopilot._CONFIG = dict(autopilot.DEFAULT_CONFIG)
        autopilot._load_config()
        assert paper_live.SETTINGS["initial_balance"] == 2500.0
    finally:
        autopilot._CONFIG = original_config
        paper_live.SETTINGS["initial_balance"] = original_balance


def test_capital_change_is_blocked_when_open_paper_positions_exist(tmp_path, monkeypatch):
    from backend import autopilot, paper_live
    import copy
    monkeypatch.setenv("TRADING_AI_MODELS_DIR", str(tmp_path / "models"))
    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(tmp_path / "paper.sqlite3"))
    monkeypatch.setattr(autopilot, "status", lambda: {"ok": True})
    monkeypatch.setattr(autopilot, "_log_decision", lambda *args, **kwargs: None)
    monkeypatch.setattr(paper_live, "list_trades", lambda **kwargs: [{"id": 7}] if kwargs.get("status") == "OPEN" else [])
    original_config = copy.deepcopy(autopilot._CONFIG)
    original_balance = paper_live.SETTINGS["initial_balance"]
    try:
        autopilot._CONFIG = dict(autopilot.DEFAULT_CONFIG)
        paper_live.SETTINGS["initial_balance"] = 1000.0
        try:
            autopilot.update_config({"daily_start_balance": 2500})
        except ValueError as exc:
            assert "موقعیت آزمایشی باز" in str(exc)
        else:
            raise AssertionError("capital change should be blocked with open positions")
        assert paper_live.SETTINGS["initial_balance"] == 1000.0
        assert autopilot._CONFIG["daily_start_balance"] == 1000.0
    finally:
        autopilot._CONFIG = original_config
        paper_live.SETTINGS["initial_balance"] = original_balance


def test_legacy_untouched_balanced_profile_migrates_to_new_balanced_defaults(tmp_path, monkeypatch):
    import json
    from backend import autopilot, paper_live
    import copy
    monkeypatch.setenv("TRADING_AI_MODELS_DIR", str(tmp_path / "models"))
    original_config = copy.deepcopy(autopilot._CONFIG)
    original_balance = paper_live.SETTINGS["initial_balance"]
    path = tmp_path / "models" / "autopilot_config.json"
    path.parent.mkdir(parents=True)
    legacy = dict(autopilot.DEFAULT_CONFIG)
    legacy.update(autopilot.LEGACY_RISK_PRESETS["balanced"])
    legacy["risk_preset"] = "balanced"
    path.write_text(json.dumps(legacy), encoding="utf-8")
    try:
        autopilot._load_config()
        assert autopilot._CONFIG["risk_preset"] == "balanced"
        assert autopilot._CONFIG["risk_per_trade_pct"] == 0.5
        assert autopilot._CONFIG["max_daily_loss_pct"] == 1.5
    finally:
        autopilot._CONFIG = original_config
        paper_live.SETTINGS["initial_balance"] = original_balance
