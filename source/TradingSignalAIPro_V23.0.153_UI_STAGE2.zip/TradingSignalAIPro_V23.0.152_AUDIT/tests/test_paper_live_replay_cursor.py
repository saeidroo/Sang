import sqlite3

import pytest

from backend import paper_live


def _seed_open_trade(db_path, monkeypatch):
    monkeypatch.setattr(paper_live, "_db_path", lambda: db_path)
    paper_live.init_db()
    with paper_live._connect() as c:
        cur = c.execute("""INSERT INTO paper_live_trades(
            opened_at,symbol,market,exchange,requested_exchange,side,quantity,notional,
            reference_entry,entry_fill,entry_fee,execution_costs_json,stop_price,target_price,
            settings_json,timeframe,status)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (0.0, "BTCUSDT", "spot", "binance", "binance", "LONG", 1.0, 100.0,
             100.0, 100.0, 0.1, '{"fee_bps_per_side":10,"total_adverse_price_bps_per_side":1}',
             90.0, 120.0, "{}", "5m", "OPEN"))
        return cur.lastrowid


def _candle(t, high=105, low=95):
    return {"t": t, "open": 100, "high": high, "low": low, "close": 101}


def test_replay_cursor_is_durable_and_duplicate_batch_is_rejected(tmp_path, monkeypatch):
    db = tmp_path / "paper.sqlite3"
    trade_id = _seed_open_trade(db, monkeypatch)
    first = paper_live.replay_position_candles(trade_id, [_candle(0)], now_ms=600_000)
    assert first["last_processed_open_ms"] == 0
    with paper_live._connect() as c:
        row = c.execute("SELECT replay_last_candle_open_ms,replay_status FROM paper_live_trades WHERE id=?", (trade_id,)).fetchone()
    assert tuple(row) == (0, "CURRENT")
    with pytest.raises(ValueError, match="duplicate_or_reordered"):
        paper_live.replay_position_candles(trade_id, [_candle(0)], now_ms=900_000)


def test_replay_gap_does_not_advance_persisted_cursor(tmp_path, monkeypatch):
    db = tmp_path / "paper.sqlite3"
    trade_id = _seed_open_trade(db, monkeypatch)
    with pytest.raises(ValueError, match="candle_gap_detected"):
        paper_live.replay_position_candles(trade_id, [_candle(0), _candle(600_000)], now_ms=1_200_000)
    with paper_live._connect() as c:
        row = c.execute("SELECT replay_last_candle_open_ms FROM paper_live_trades WHERE id=?", (trade_id,)).fetchone()
    assert row[0] is None


def test_replay_rejects_unknown_trade(tmp_path, monkeypatch):
    monkeypatch.setattr(paper_live, "_db_path", lambda: tmp_path / "paper.sqlite3")
    with pytest.raises(ValueError, match="پیدا نشد"):
        paper_live.replay_position_candles(999999, [], now_ms=100_000)


def test_replay_persists_trailing_state_and_time_exit(tmp_path, monkeypatch):
    db = tmp_path / "paper.sqlite3"
    trade_id = _seed_open_trade(db, monkeypatch)
    candles = [
        {"t": i * 300_000, "open": 100, "high": 101.4, "low": 99, "close": 100.5}
        for i in range(12)
    ]
    result = paper_live.replay_position_candles(trade_id, candles, now_ms=3_600_000)
    assert result["exit"]["reason"] == "TIME_EXIT"
    with paper_live._connect() as c:
        row = c.execute("SELECT status,replay_status,replay_last_candle_open_ms FROM paper_live_trades WHERE id=?",
                        (trade_id,)).fetchone()
    assert tuple(row) == ("CLOSED", "EXITED", 3_300_000)


def test_replay_persists_trailing_extreme_and_tightened_stop(tmp_path, monkeypatch):
    db = tmp_path / "paper.sqlite3"
    trade_id = _seed_open_trade(db, monkeypatch)
    candle = {"t": 0, "open": 100, "high": 102, "low": 99, "close": 101}
    result = paper_live.replay_position_candles(trade_id, [candle], now_ms=300_000)
    assert result["trailing_active"] is True
    with paper_live._connect() as c:
        row = c.execute("SELECT stop_price,trailing_peak_price,trailing_active,replay_status "
                        "FROM paper_live_trades WHERE id=?", (trade_id,)).fetchone()
    assert row[0] == pytest.approx(100.98)
    assert row[1] == 102
    assert row[2:] == (1, "CURRENT")
