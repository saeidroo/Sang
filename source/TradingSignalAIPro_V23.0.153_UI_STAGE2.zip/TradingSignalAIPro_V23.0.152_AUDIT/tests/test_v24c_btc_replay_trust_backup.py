import json
import pytest
from backend.btc_replay_anchor import sign_replay_head_anchor, verify_signed_replay_head_anchor
from backend.btc_replay_trust_backup import (audit_replay_trust_store,
    export_replay_trust_store_backup, restore_replay_trust_store_backup)


def _checkpoint():
    import hashlib
    body={'anchor_version':'btc-4h-replay-head-anchor-v1','anchor_sequence':1,
          'previous_anchor_sha256':'0'*64,'registry_record_count':0,
          'registry_chain_head_sha256':'0'*64}
    raw=json.dumps(body,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
    return {**body,'anchor_sha256':hashlib.sha256(raw).hexdigest()}


def test_encrypted_trust_backup_restore_preserves_historical_signatures(tmp_path,monkeypatch):
    source=tmp_path/'source-trust'; monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR',str(source))
    signed=sign_replay_head_anchor(_checkpoint(),output_path=tmp_path/'signed.json')
    from backend import signed_anchor
    signed_anchor.rotate_key(revoke_old=False)
    assert audit_replay_trust_store()['healthy']
    backup=tmp_path/'trust.enc'
    export_replay_trust_store_backup(backup,password='very-strong-test-password')
    restored=tmp_path/'restored-trust'
    result=restore_replay_trust_store_backup(backup,restored,password='very-strong-test-password')
    assert result['restored'] and result['trusted_key_count']==2
    monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR',str(restored))
    assert verify_signed_replay_head_anchor(signed)['valid'] is True
    assert audit_replay_trust_store()['healthy']


def test_trust_backup_wrong_password_and_tamper_rejected(tmp_path,monkeypatch):
    monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR',str(tmp_path/'source'))
    from backend import signed_anchor
    signed_anchor.ensure_keypair()
    backup=tmp_path/'trust.enc'; export_replay_trust_store_backup(backup,password='very-strong-test-password')
    with pytest.raises(ValueError,match='decryption_failed'):
        restore_replay_trust_store_backup(backup,tmp_path/'bad-password',password='wrong-password-long')
    env=json.loads(backup.read_text()); env['ciphertext_sha256']='0'*64
    tampered=tmp_path/'tampered.enc'; tampered.write_text(json.dumps(env))
    with pytest.raises(ValueError,match='ciphertext_hash_mismatch'):
        restore_replay_trust_store_backup(tampered,tmp_path/'bad-tamper',password='very-strong-test-password')


def test_trust_audit_flags_revoked_active_key(tmp_path,monkeypatch):
    monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR',str(tmp_path/'trust'))
    from backend import signed_anchor
    kp=signed_anchor.ensure_keypair(); signed_anchor.revoke_key(kp['key_id'])
    report=audit_replay_trust_store()
    assert not report['healthy'] and 'trust_active_key_revoked' in report['errors']
