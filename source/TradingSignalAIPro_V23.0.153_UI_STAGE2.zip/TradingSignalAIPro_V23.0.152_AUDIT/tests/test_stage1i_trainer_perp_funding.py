import pandas as pd
import pytest

from backend import funding
from backend import trainer


def _timeline():
    base_ms = 1_700_000_000_000
    return pd.DataFrame({
        't': [base_ms, base_ms + 60_000, base_ms + 120_000, base_ms + 180_000],
        'open': [100.0] * 4,
        'high': [101.0] * 4,
        'low': [99.0] * 4,
        'close': [100.0] * 4,
        'atr_14': [1.0] * 4,
    })


def _event(ts_seconds, rate=0.001, mark=100.0):
    return {'settlement_ts': ts_seconds, 'funding_rate': rate,
            'mark_price': mark, 'rate_kind': 'settled'}


def test_perp_funding_attaches_realized_event_in_candle_timestamp_units(monkeypatch):
    frame = _timeline()
    event = _event(frame.t.iloc[1] / 1000.0 + 20.0, mark=101.25)
    monkeypatch.setattr(funding, 'fetch_funding_history', lambda *a, **k: [event])
    monkeypatch.setattr(funding, 'funding_history_complete', lambda *a, **k: True)

    out, audit = trainer.attach_realized_perp_funding(
        frame, symbol='BTCUSDTPERP', timeframe='1m', source='binance_fut')

    assert audit['market'] == 'perp'
    assert audit['funding_events'] == 1
    assert audit['exchange'] == 'binance'
    # The settlement is assigned to the latest candle open at/before its time.
    assert out.loc[1, 'funding_rate'] == pytest.approx(0.001)
    assert out.loc[1, 'funding_mark_price'] == pytest.approx(101.25)
    assert out.loc[1, 'funding_settlement_ts'] == pytest.approx(event['settlement_ts'] * 1000)


def test_perp_funding_fails_closed_when_mark_price_is_missing(monkeypatch):
    frame = _timeline()
    event = _event(frame.t.iloc[1] / 1000.0 + 20.0)
    event['mark_price'] = None
    monkeypatch.setattr(funding, 'fetch_funding_history', lambda *a, **k: [event])
    monkeypatch.setattr(funding, 'funding_history_complete', lambda *a, **k: True)

    with pytest.raises(RuntimeError, match='Funding ناقص|Mark Price'):
        trainer.attach_realized_perp_funding(
            frame, symbol='BTCUSDTPERP', timeframe='1m', source='binance_fut')


def test_perp_funding_fails_closed_on_incomplete_history(monkeypatch):
    frame = _timeline()
    event = _event(frame.t.iloc[1] / 1000.0 + 20.0)
    monkeypatch.setattr(funding, 'fetch_funding_history', lambda *a, **k: [event])
    monkeypatch.setattr(funding, 'funding_history_complete', lambda *a, **k: False)

    with pytest.raises(RuntimeError, match='سقف صفحه‌بندی'):
        trainer.attach_realized_perp_funding(
            frame, symbol='BTCUSDTPERP', timeframe='1m', source='binance_fut')


def test_perp_funding_preserves_multiple_events_in_same_candle(monkeypatch):
    frame = _timeline()
    base = frame.t.iloc[1] / 1000.0
    events = [_event(base + 10.0, rate=0.001), _event(base + 20.0, rate=0.002)]
    monkeypatch.setattr(funding, 'fetch_funding_history', lambda *a, **k: events)
    monkeypatch.setattr(funding, 'funding_history_complete', lambda *a, **k: True)

    out, audit = trainer.attach_realized_perp_funding(
        frame, symbol='BTCUSDTPERP', timeframe='1m', source='binance_fut')
    stored = out.loc[1, 'funding_events']
    assert len(stored) == 2
    assert [item['funding_rate'] for item in stored] == pytest.approx([0.001, 0.002])
    assert [item['mark_price'] for item in stored] == pytest.approx([100.0, 100.0])
    assert pd.isna(out.loc[1, 'funding_rate'])  # legacy scalar is not ambiguous
    assert audit['funding_events'] == 2


def test_spot_timeline_does_not_fetch_or_require_funding():
    frame = _timeline()
    out, audit = trainer.attach_realized_perp_funding(
        frame, symbol='BTCUSDT', timeframe='1m', source='binance')
    assert out.equals(frame)
    assert audit == {'market': 'spot', 'funding_events': 0, 'status': 'NOT_APPLICABLE'}


def test_perp_source_without_exchange_identity_is_rejected():
    with pytest.raises(RuntimeError, match='منبع Funding قابل اتکا'):
        trainer.attach_realized_perp_funding(
            _timeline(), symbol='BTCUSDTPERP', timeframe='1m', source='history')
