import json

import pytest

from backend.btc_paper import run_btc_4h_paper_simulation
from backend.btc_paper_monitor import (
    build_hash_chain, build_monitoring_report, recover_paper_ledger,
    save_monitoring_report, verify_hash_chain,
)


def _ledger(path=None):
    candles = []
    for i in range(30):
        p = 100 + i * 0.2
        candles.append({'open': p, 'high': p + 1, 'low': p - 1, 'close': p + .2})
    return run_btc_4h_paper_simulation(
        candles, [{'signal_pos': 1, 'direction': 1}, {'signal_pos': 10, 'direction': -1},
                  {'signal_pos': 19, 'direction': 1}],
        initial_cash=1000, horizon_bars=2, fee_bps=0, slippage_bps=0,
        spread_bps=0, ledger_path=path)


def test_hash_chain_detects_tampering():
    chain = build_hash_chain([{'event_id': 'a', 'type': 'ENTRY'}, {'event_id': 'b', 'type': 'EXIT'}])
    assert verify_hash_chain(chain)['valid']
    chain[0]['type'] = 'ALTERED'
    assert not verify_hash_chain(chain)['valid']


def test_monitoring_has_daily_weekly_and_recomputed_risk():
    report = build_monitoring_report(_ledger())
    assert report['monitoring']['trade_count'] == 3
    assert report['daily'] and report['weekly']
    assert report['event_chain_verification']['valid']
    assert report['safety']['exchange_order_submission'] is False
    assert len(report['monitoring_hash']) == 64


def test_monitoring_report_persists_atomically(tmp_path):
    report = build_monitoring_report(_ledger())
    target = tmp_path / 'reports' / 'monitor.json'
    assert save_monitoring_report(report, target) == str(target)
    assert json.loads(target.read_text())['monitoring_hash'] == report['monitoring_hash']
    assert not (tmp_path / 'reports' / 'monitor.json.tmp').exists()


def test_recovery_validates_original_ledger_hash(tmp_path):
    path = tmp_path / 'paper.json'
    ledger = _ledger(path)
    recovered = recover_paper_ledger(path)
    assert recovered['recovered'] and recovered['trade_count'] == ledger['trade_count']
    data = json.loads(path.read_text())
    data['final_equity'] += 1
    path.write_text(json.dumps(data))
    with pytest.raises(ValueError, match='hash mismatch'):
        recover_paper_ledger(path)


def test_recovery_rejects_non_paper_file(tmp_path):
    path = tmp_path / 'live.json'
    path.write_text(json.dumps({'mode': 'LIVE', 'live_orders_sent': True}))
    with pytest.raises(ValueError, match='paper-only'):
        recover_paper_ledger(path)


def test_monitor_rejects_nonfinite_equity():
    ledger = _ledger()
    ledger['equity_curve'][0]['equity'] = float('nan')
    with pytest.raises(ValueError, match='non-finite'):
        build_monitoring_report(ledger)
