"""V21 part 6-8: ⚡ quick transfer training for a market with no model of its own."""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend import api, consensus  # noqa: E402


class FakeModel:
    is_fitted = True

    def __init__(self):
        self.feature_names = ['ret_1', 'ret_5']
        self.models = {'random_forest': object()}


def _seed_env(tmp_path, monkeypatch, pairs):
    d = tmp_path / 'models'
    d.mkdir()
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(d))
    consensus._CACHE.clear()
    from backend.features import FEATURE_SCHEMA_VERSION
    for sym, tf, edge, acc in pairs:
        (d / f'model_{sym}_{tf}.joblib').write_bytes(b'x')
        (d / f'meta_{sym}_{tf}.json').write_text(json.dumps({
            'symbol': sym, 'timeframe': tf, 'feature_schema_version': FEATURE_SCHEMA_VERSION,
            'edge_confirmed': edge, 'walk_forward_acc': acc}), encoding='utf-8')
    monkeypatch.setattr(consensus, '_load_model_cached', lambda p: FakeModel())
    return d


def test_suggest_seed_prefers_edge_then_relation(tmp_path, monkeypatch):
    _seed_env(tmp_path, monkeypatch, [
        ('ETHUSDT', '1h', True, 0.58), ('SOLUSDT', '1h', False, 0.70), ('BTCUSDT', '4h', True, 0.57)])
    seed = consensus.suggest_seed('NEWUSDT', '1h')
    assert seed['symbol'] == 'ETHUSDT' and seed['edge_confirmed'] is True   # edge first, same tf wins


def test_suggest_seed_twin_market_wins(tmp_path, monkeypatch):
    _seed_env(tmp_path, monkeypatch, [('ETHUSDT', '1h', True, 0.58), ('BTCUSDT', '1h', True, 0.58)])
    seed = consensus.suggest_seed('BTCUSDTPERP', '1h')
    assert seed['symbol'] == 'BTCUSDT' and seed['relation'] == 'twin_market'


def test_suggest_seed_none_when_empty(tmp_path, monkeypatch):
    _seed_env(tmp_path, monkeypatch, [])
    assert consensus.suggest_seed('NEWUSDT', '1h') is None


def test_seed_endpoint(tmp_path, monkeypatch):
    _seed_env(tmp_path, monkeypatch, [('ETHUSDT', '1h', True, 0.58)])
    api.app.config['TESTING'] = True
    with api.app.test_client() as c:
        d = c.get('/api/learn/seed?symbol=NEWUSDT&timeframe=1h').get_json()
        assert d['available'] is True and d['seed']['symbol'] == 'ETHUSDT' and 'path' not in d['seed']
        d = c.get('/api/learn/seed?symbol=ETHUSDT&timeframe=1h').get_json()   # has its own model
        assert d['has_own_model'] is True and d['available'] is False
        assert c.get('/api/learn/seed?symbol=bad!').status_code == 400


def _clean_longrun(monkeypatch):
    from backend import longrun
    clean = dict(longrun._STATE)
    clean.update(running=False, started_at=None, config=None, jobs=[])
    monkeypatch.setattr(longrun, '_STATE', clean)


def test_learn_with_seed_passes_transfer_args(tmp_path, monkeypatch):
    _seed_env(tmp_path, monkeypatch, [('ETHUSDT', '1h', True, 0.58)])
    _clean_longrun(monkeypatch)
    got = {}

    class FakeSession:
        is_running = False

        def run(self, **kw):
            got.update(kw)

        def log(self, *_):
            pass
    monkeypatch.setattr(api, 'get_session', lambda: FakeSession())
    api.app.config['TESTING'] = True
    with api.app.test_client() as c:
        r = c.post('/api/learn', json={'symbol': 'NEWUSDT', 'timeframe': '1h', 'limit': 3000, 'seed': 'auto'})
        assert r.status_code == 200
        body = r.get_json()
        assert body['quick'] is True and body['seed_from'] == 'ETHUSDT/1h'
    import time
    for _ in range(50):
        if got:
            break
        time.sleep(0.02)
    assert got['seed_from'] == ('ETHUSDT', '1h') and got['quick'] is True


def test_learn_with_seed_rejected_when_own_model_or_no_seed(tmp_path, monkeypatch):
    _seed_env(tmp_path, monkeypatch, [('ETHUSDT', '1h', True, 0.58)])
    _clean_longrun(monkeypatch)
    api.app.config['TESTING'] = True
    with api.app.test_client() as c:
        r = c.post('/api/learn', json={'symbol': 'ETHUSDT', 'timeframe': '1h', 'limit': 3000, 'seed': 'auto'})
        assert r.status_code == 409 and r.get_json()['has_own_model'] is True
        r = c.post('/api/learn', json={'symbol': 'NEWUSDT', 'timeframe': '4h', 'limit': 3000, 'seed': 'auto'})
        # a 1h model still qualifies as a (weaker) neighbour for 4h, so this is allowed;
        assert r.status_code in (200, 409)
    consensus._CACHE.clear()
    monkeypatch.setattr(consensus, 'suggest_seed', lambda *a, **k: None)
    with api.app.test_client() as c:
        r = c.post('/api/learn', json={'symbol': 'ZZZUSDT', 'timeframe': '1h', 'limit': 3000, 'seed': 'auto'})
        assert r.status_code == 409 and r.get_json()['no_seed'] is True


def test_frontend_quick_button_wiring():
    js = (ROOT / 'frontend' / 'app.js').read_text(encoding='utf-8')
    html = (ROOT / 'frontend' / 'index.html').read_text(encoding='utf-8')
    assert 'id="learnQuick"' in html
    assert "/api/learn/seed" in js and "seed: quick ? 'auto' : undefined" in js
    assert "startLearning(true)" in js and "startLearning(false)" in js


def _candles(n, seed):
    rng = np.random.default_rng(seed)
    close = 100 * np.exp(np.cumsum(rng.normal(0.0003, 0.008, n)))
    high = close * (1 + np.abs(rng.normal(0, 0.004, n)))
    low = close * (1 - np.abs(rng.normal(0, 0.004, n)))
    ts = pd.date_range('2024-01-01', periods=n, freq='1h').astype('int64') // 10**6
    df = pd.DataFrame({'t': ts, 'open': np.r_[close[0], close[:-1]], 'high': high, 'low': low,
                       'close': close, 'volume': rng.uniform(1000, 5000, n)})
    df.attrs['source'] = 'test'
    return df


def test_real_transfer_training_end_to_end(tmp_path, monkeypatch):
    """Train a seed coin, then a NEW coin from it: features + params transfer, meta records it."""
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(tmp_path / 'm'))
    consensus._CACHE.clear()
    from backend.trainer import TrainingSession
    a = TrainingSession().run('AAAUSDT', '1h', limit=2500, df=_candles(2500, 1), quick=True)
    b_sess = TrainingSession()
    b = b_sess.run('BBBUSDT', '1h', limit=2500, df=_candles(2500, 2),
                   seed_from=('AAAUSDT', '1h'), quick=True)
    assert a['meta']['seeded_from'] is None
    assert b['meta']['seeded_from'] == 'AAAUSDT/1h' and b['meta']['quick_mode'] is True
    assert b['meta']['transfer_mode'] in ('xgb_booster', 'features+params')
    assert b['feature_names'] == a['feature_names']          # same columns, same order
    assert len(b['meta']['trials']) == 2 or len([t for t in b['meta']['trials'] if t]) == 2
    assert any('انتقال یادگیری' in line for line in b_sess.progress_log)


def test_seed_ignored_when_market_already_has_model(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(tmp_path / 'm2'))
    consensus._CACHE.clear()
    from backend.trainer import TrainingSession
    TrainingSession().run('AAAUSDT', '1h', limit=2500, df=_candles(2500, 1), quick=True)
    TrainingSession().run('CCCUSDT', '1h', limit=2500, df=_candles(2500, 3), quick=True)
    r = TrainingSession().run('CCCUSDT', '1h', limit=2500, df=_candles(2500, 3),
                              seed_from=('AAAUSDT', '1h'), quick=True)
    assert r['meta']['seeded_from'] is None                   # own model exists -> normal path
