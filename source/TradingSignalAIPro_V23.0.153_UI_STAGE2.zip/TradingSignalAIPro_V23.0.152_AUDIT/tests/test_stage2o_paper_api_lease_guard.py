"""Dependency-light structural checks for Flask API lease guard wiring."""
import ast
from pathlib import Path


API_PATH = Path(__file__).resolve().parents[1] / "backend" / "api.py"
TREE = ast.parse(API_PATH.read_text(encoding="utf-8"))
FUNCTIONS = {node.name: node for node in TREE.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}


def _calls_named(node, name):
    return [n for n in ast.walk(node) if isinstance(n, ast.Call)
            and isinstance(n.func, ast.Name) and n.func.id == name]


def test_guard_uses_persistent_lease_and_fails_closed():
    guard = FUNCTIONS["_paper_ledger_lease_guard"]
    source = ast.get_source_segment(API_PATH.read_text(encoding="utf-8"), guard)
    assert "paper_process_lease.lease_status" in source
    assert "paper_live._db_path()" in source
    assert "503" in source and "409" in source
    assert "paper_ledger_lease_status_unavailable" in source
    assert "paper_ledger_owned_by_autopilot" in source


def test_all_manual_ledger_routes_check_lease_before_work():
    protected = {
        "paper_live_state",
        "paper_live_open_position",
        "paper_live_close_position",
        "paper_live_partial_close_position",
        "paper_live_learning_rebuild",
        "paper_live_decision_execution",
        "paper_live_lifecycle_monitor",
    }
    assert protected <= FUNCTIONS.keys()
    for name in protected:
        fn = FUNCTIONS[name]
        statements = fn.body[1:] if (fn.body and isinstance(fn.body[0], ast.Expr)
                                     and isinstance(fn.body[0].value, ast.Constant)
                                     and isinstance(fn.body[0].value.value, str)) else fn.body
        first_guard = next((i for i, stmt in enumerate(statements)
                            if any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                                   and n.func.id == "_paper_ledger_lease_guard"
                                   for n in ast.walk(stmt))), None)
        assert first_guard == 0, f"{name} must check lease before touching ledger"


def test_legacy_paper_endpoint_is_a_separate_ledger_not_misclassified():
    # The legacy /api/paper/trades routes call backend.advanced, not paper_live.
    # Keep them outside this guard's scope; their separate ledger has its own
    # lifecycle and must not be accidentally presented as the shared V23 ledger.
    fn = FUNCTIONS["paper_trades"]
    source = ast.get_source_segment(API_PATH.read_text(encoding="utf-8"), fn)
    assert "backend.advanced" in source
    assert "paper_live" not in source
