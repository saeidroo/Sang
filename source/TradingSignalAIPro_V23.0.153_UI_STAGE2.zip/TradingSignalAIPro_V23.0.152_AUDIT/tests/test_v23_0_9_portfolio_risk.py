import math
import sqlite3
import time

import pytest

from backend import paper_live, autopilot
from backend.portfolio_risk import aggregate_open_risk, estimate_stop_risk, size_for_risk


@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(tmp_path / "portfolio_risk.sqlite3"))
    paper_live._CACHE.clear()


def _row(*, trade_id=1, symbol="BTCUSDT", market="spot", side="LONG", entry=100.0,
         stop=98.5, qty=2.0, notional=200.0, fee=0.2):
    return {
        "id": trade_id, "symbol": symbol, "market": market, "side": side,
        "quantity": qty, "notional": notional, "entry_fill": entry,
        "entry_fee": fee, "stop_price": stop, "status": "OPEN",
    }


def _fake_quote(symbol, market="spot", exchange="auto", **kwargs):
    return {
        "symbol": symbol, "market": market, "exchange": "binance",
        "exchange_name": "Binance", "price": 100.0,
        "timestamp": "2026-11-19T00:00:00+00:00",
        "checked_at_epoch": time.time(), "authenticated": False,
    }


def test_long_and_short_stop_risk_include_round_trip_costs():
    long_risk = estimate_stop_risk(_row(side="LONG", entry=100, stop=98, qty=1, fee=0.1))
    short_risk = estimate_stop_risk(_row(side="SHORT", entry=100, stop=102, qty=1, fee=0.1))
    assert long_risk > 2.0
    assert short_risk > 2.0
    assert long_risk == pytest.approx(short_risk, rel=0.02)


def test_aggregate_open_risk_separates_market_and_direction():
    summary = aggregate_open_risk([
        _row(trade_id=1, market="spot", side="LONG"),
        _row(trade_id=2, market="perp", side="SHORT", entry=100, stop=101.5),
        {**_row(trade_id=3), "status": "CLOSED"},
    ])
    assert summary["complete"] is True
    assert summary["position_count"] == 2
    assert summary["total"] == pytest.approx(summary["by_market"]["spot"] + summary["by_market"]["perp"])
    assert summary["by_side"]["LONG"] > 0
    assert summary["by_side"]["SHORT"] > 0


def test_invalid_open_stop_risk_fails_closed():
    summary = aggregate_open_risk([_row(trade_id=77, stop=float("nan"))])
    assert summary["complete"] is False
    assert summary["invalid_position_ids"] == [77]


def test_sizing_decreases_notional_when_stop_distance_widens():
    narrow = size_for_risk(equity=1000, risk_budget_cash=5, stop_loss_pct=1,
                           max_position_notional_pct=50, available_balance=1000)
    wide = size_for_risk(equity=1000, risk_budget_cash=5, stop_loss_pct=2,
                         max_position_notional_pct=50, available_balance=1000)
    assert narrow["notional"] > wide["notional"]
    assert narrow["estimated_stop_risk"] <= 5
    assert wide["estimated_stop_risk"] <= 5


def test_open_position_respects_total_portfolio_risk_cap(monkeypatch):
    monkeypatch.setattr(paper_live, "get_quote", _fake_quote)
    common = {
        "max_open_positions": 10, "max_position_notional_pct": 20.0,
        "risk_per_trade_pct": 0.5, "stop_loss_pct": 1.5, "take_profit_pct": 3.0,
        "max_portfolio_risk_pct": 0.7, "max_spot_risk_pct": 0.7,
        "max_perp_risk_pct": 1.0, "max_directional_risk_pct": 2.0,
    }
    first = paper_live.open_position("BTCUSDT", "LONG", "spot", "auto", overrides=common)
    second = paper_live.open_position("ETHUSDT", "LONG", "spot", "auto", overrides=common)
    assert first["notional"] == pytest.approx(200.0)
    assert second["notional"] < first["notional"]
    with pytest.raises(ValueError, match="ظرفیت ریسک"):
        paper_live.open_position("SOLUSDT", "LONG", "spot", "auto", overrides=common)


def test_spot_and_perp_have_separate_risk_budgets(monkeypatch):
    monkeypatch.setattr(paper_live, "get_quote", _fake_quote)
    overrides = {
        "max_open_positions": 10, "max_position_notional_pct": 20.0,
        "risk_per_trade_pct": 0.5, "stop_loss_pct": 1.5, "take_profit_pct": 3.0,
        "max_portfolio_risk_pct": 2.0, "max_spot_risk_pct": 0.5,
        "max_perp_risk_pct": 1.0, "max_directional_risk_pct": 2.0,
    }
    paper_live.open_position("BTCUSDT", "LONG", "spot", "auto", overrides=overrides)
    # Spot cap is nearly used, but the separate perp bucket still has capacity.
    perp = paper_live.open_position("ETHUSDT", "LONG", "perp", "auto", overrides=overrides)
    assert perp["notional"] < 200.0  # marked equity includes the small unrealized loss on the spot leg
    assert perp["notional"] > 190.0
    state = paper_live.get_state(refresh_quotes=False)
    risk = state["account"]["portfolio_risk"]
    assert risk["by_market"]["spot"] > 0
    assert risk["by_market"]["perp"] > 0
    assert risk["complete"] is True


def test_directional_risk_cap_applies_across_spot_and_perp(monkeypatch):
    monkeypatch.setattr(paper_live, "get_quote", _fake_quote)
    overrides = {
        "max_open_positions": 10, "max_position_notional_pct": 20.0,
        "risk_per_trade_pct": 0.5, "stop_loss_pct": 1.5, "take_profit_pct": 3.0,
        "max_portfolio_risk_pct": 2.0, "max_spot_risk_pct": 1.5,
        "max_perp_risk_pct": 1.5, "max_directional_risk_pct": 0.35,
    }
    first = paper_live.open_position("BTCUSDT", "LONG", "spot", "auto", overrides=overrides)
    with pytest.raises(ValueError, match="ظرفیت ریسک"):
        paper_live.open_position("ETHUSDT", "LONG", "perp", "auto", overrides=overrides)
    # A separate direction has a separate directional budget.
    short = paper_live.open_position("ETHUSDT", "SHORT", "perp", "auto", overrides=overrides)
    assert first["side"] == "LONG"
    assert short["side"] == "SHORT"


def test_config_validates_and_forwards_portfolio_risk_caps():
    assert autopilot._config_value("max_portfolio_risk_pct", 2.0) == pytest.approx(2.0)
    assert autopilot._config_value("max_spot_risk_pct", 1.5) == pytest.approx(1.5)
    assert autopilot._config_value("max_perp_risk_pct", 1.0) == pytest.approx(1.0)
    assert autopilot._config_value("max_directional_risk_pct", 1.5) == pytest.approx(1.5)
    with pytest.raises(ValueError):
        autopilot._config_value("max_portfolio_risk_pct", 0)
    old = dict(autopilot._CONFIG)
    try:
        autopilot._CONFIG.update({
            "risk_preset": "balanced", "max_portfolio_risk_pct": 2.0,
            "max_spot_risk_pct": 1.5, "max_perp_risk_pct": 1.0,
            "max_directional_risk_pct": 1.5,
        })
        overrides = autopilot._risk_overrides()
        assert overrides["max_portfolio_risk_pct"] == 2.0
        assert overrides["max_spot_risk_pct"] == 1.5
    finally:
        autopilot._CONFIG.clear()
        autopilot._CONFIG.update(old)


def test_account_exposes_live_portfolio_risk_snapshot(monkeypatch):
    monkeypatch.setattr(paper_live, "get_quote", _fake_quote)
    paper_live.open_position("BTCUSDT", "LONG", "spot", "auto")
    risk = paper_live.get_state(refresh_quotes=False)["account"]["portfolio_risk"]
    assert risk["total"] > 0
    assert risk["portfolio_cap_usdt"] == pytest.approx(20.0)
    assert risk["remaining_portfolio_usdt"] < risk["portfolio_cap_usdt"]



def test_unrealized_loss_reduces_new_entry_equity_basis(monkeypatch):
    monkeypatch.setattr(paper_live, "get_quote", _fake_quote)
    monkeypatch.setattr(paper_live, "get_state", lambda refresh_quotes=True: {
        "account": {"disconnected_positions": 0, "equity": 900.0},
        "open_positions": [],
    })
    overrides = {
        "max_open_positions": 10, "max_position_notional_pct": 20.0,
        "risk_per_trade_pct": 1.0, "stop_loss_pct": 1.5, "take_profit_pct": 3.0,
        "max_portfolio_risk_pct": 10.0, "max_spot_risk_pct": 10.0,
        "max_perp_risk_pct": 10.0, "max_directional_risk_pct": 10.0,
    }
    opened = paper_live.open_position("BTCUSDT", "LONG", "spot", "auto", overrides=overrides)
    assert opened["notional"] == pytest.approx(180.0)


def test_paper_dashboard_renders_portfolio_stop_risk_metric():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    markup = (root / "frontend" / "index.html").read_text(encoding="utf-8")
    script = (root / "frontend" / "paper-live.js").read_text(encoding="utf-8")
    assert 'id="paperPortfolioRisk"' in markup
    assert 'a.portfolio_risk' in script
    assert 'remaining_portfolio_usdt' in script or 'portfolio_cap_usdt' in script


def test_autopilot_status_uses_persisted_preset_for_risk_display(monkeypatch):
    old_config = dict(autopilot._CONFIG)
    try:
        autopilot._CONFIG.update({
            "risk_preset": "conservative", "max_portfolio_risk_pct": 1.0,
            "max_spot_risk_pct": 0.75, "max_perp_risk_pct": 0.5,
            "max_directional_risk_pct": 0.75,
        })
        monkeypatch.setattr(paper_live, "get_state", lambda refresh_quotes=False: {
            "account": {"equity": 1000.0, "known_realized_equity": 1000.0,
                        "portfolio_risk": {"total": 2.0, "by_market": {"spot": 1.5, "perp": 0.5},
                                           "by_side": {"LONG": 1.5, "SHORT": 0.5}, "complete": True}},
            "open_positions": [], "recent_trades": [],
        })
        monkeypatch.setattr(autopilot, "_closed_autopilot_trades", lambda since=0.0: [])
        result = autopilot.status()
        risk = result["account"]["portfolio_risk"]
        assert risk["policy_source"] == "autopilot_persisted_config"
        assert risk["portfolio_cap_usdt"] == pytest.approx(10.0)
        assert risk["spot_cap_usdt"] == pytest.approx(7.5)
        assert risk["remaining_portfolio_usdt"] == pytest.approx(8.0)
    finally:
        autopilot._CONFIG.clear()
        autopilot._CONFIG.update(old_config)
