import sqlite3
import time

import pytest

from backend import funding, paper_live


@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(tmp_path / "funding.sqlite3"))
    paper_live._CACHE.clear()


def test_funding_cashflow_sign_and_mark_price_basis():
    long_pay, long_notional, basis = funding.funding_cashflow(
        "LONG", 2, 0.001, mark_price=110, entry_price=100)
    short_receive, _, _ = funding.funding_cashflow(
        "SHORT", 2, 0.001, mark_price=110, entry_price=100)
    long_receive, _, _ = funding.funding_cashflow(
        "LONG", 2, -0.001, mark_price=110, entry_price=100)
    assert long_pay == pytest.approx(-0.22)
    assert short_receive == pytest.approx(0.22)
    assert long_receive == pytest.approx(0.22)
    assert long_notional == pytest.approx(220)
    assert basis == "settlement_mark_price"


def test_funding_uses_entry_notional_proxy_when_mark_price_missing():
    cash, notional, basis = funding.funding_cashflow(
        "LONG", 3, 0.002, mark_price=None, entry_price=100)
    assert cash == pytest.approx(-0.6)
    assert notional == pytest.approx(300)
    assert basis == "entry_price_proxy"


def test_binance_adapter_normalizes_actual_funding_history(monkeypatch):
    calls = []

    class Response:
        def raise_for_status(self):
            pass

        def json(self):
            return [
                {"symbol": "BTCUSDT", "fundingRate": "0.0001", "fundingTime": 2000000000000,
                 "markPrice": "50000"},
                {"symbol": "BTCUSDT", "fundingRate": "-0.0002", "fundingTime": 2000000008000,
                 "markPrice": "50100"},
            ]

    def fake_get(url, params=None, timeout=None):
        calls.append((url, params, timeout))
        return Response()

    monkeypatch.setattr(funding.SESSION, "get", fake_get)
    rows = funding.fetch_funding_history("binance", "BTCUSDT", 1999999999, 2000000010)
    assert len(rows) == 2
    assert rows[0]["funding_rate"] == pytest.approx(0.0001)
    assert rows[0]["mark_price"] == pytest.approx(50000)
    assert calls and calls[0][1]["symbol"] == "BTCUSDT"


def _quote(symbol, market="spot", exchange="auto", **kwargs):
    return {"symbol": symbol, "market": market, "exchange": "binance",
            "exchange_name": "Binance", "price": 100.0,
            "timestamp": "2026-11-19T00:00:00+00:00",
            "checked_at_epoch": time.time(), "authenticated": False}


def test_funding_settlements_are_idempotent_and_flow_into_closed_net_pnl(monkeypatch):
    monkeypatch.setattr(paper_live, "get_quote", _quote)
    opened = paper_live.open_position("BTCUSDT", "LONG", "perp", "binance")
    db = sqlite3.connect(paper_live._db_path())
    opened_at = db.execute("SELECT opened_at FROM paper_live_trades WHERE id=?", (opened["id"],)).fetchone()[0]
    db.close()
    settlement = int(opened_at * 1000 + 1) / 1000
    monkeypatch.setattr(paper_live, "fetch_funding_history", lambda *a, **k: [
        {"funding_rate": 0.001, "settlement_ts": settlement,
         "mark_price": 100.0, "rate_kind": "settled"}
    ])

    first = paper_live.sync_open_funding_positions(opened["id"])
    second = paper_live.sync_open_funding_positions(opened["id"])
    assert first["events_inserted"] == 1
    assert second["events_inserted"] == 0

    db = sqlite3.connect(paper_live._db_path())
    event_count = db.execute("SELECT COUNT(*) FROM paper_funding_events WHERE trade_id=?", (opened["id"],)).fetchone()[0]
    stored_funding = db.execute("SELECT funding_total FROM paper_live_trades WHERE id=?", (opened["id"],)).fetchone()[0]
    db.close()
    assert event_count == 1
    assert stored_funding == pytest.approx(-opened["quantity"] * 100.0 * 0.001)

    closed = paper_live.close_position(opened["id"])
    assert closed["funding_event_count"] == 1
    assert closed["funding_total"] == pytest.approx(stored_funding)
    # Fees are also charged, and the funding payment is an additional cost.
    assert closed["net_pnl"] < -abs(stored_funding)


def test_funding_history_failure_marks_open_perp_pnl_incomplete(monkeypatch):
    monkeypatch.setattr(paper_live, "get_quote", _quote)
    opened = paper_live.open_position("ETHUSDT", "SHORT", "perp", "binance")

    def fail(*args, **kwargs):
        raise RuntimeError("temporary public funding API outage")

    monkeypatch.setattr(paper_live, "fetch_funding_history", fail)
    state = paper_live.get_state(refresh_quotes=False, sync_funding=True)
    assert state["account"]["funding_health"] == "DEGRADED"
    assert state["account"]["funding_incomplete_positions"] == 1
    assert state["account"]["unrealized_pnl_complete"] is False
    row = next(x for x in state["open_positions"] if x["id"] == opened["id"])
    assert row["funding_status"] == "ERROR"


def test_closed_trade_funding_failure_is_reconciled_later_before_learning(monkeypatch):
    monkeypatch.setattr(paper_live, "get_quote", _quote)
    opened = paper_live.open_position("SOLUSDT", "LONG", "perp", "binance")

    def fail(*args, **kwargs):
        raise RuntimeError("temporary public funding API outage")

    monkeypatch.setattr(paper_live, "fetch_funding_history", fail)
    first_close = paper_live.close_position(opened["id"])
    assert first_close["funding_status"] == "ERROR"

    db = sqlite3.connect(paper_live._db_path())
    opened_at, closed_at = db.execute(
        "SELECT opened_at,closed_at FROM paper_live_trades WHERE id=?", (opened["id"],)
    ).fetchone()
    initial_net = db.execute("SELECT net_pnl FROM paper_live_trades WHERE id=?", (opened["id"],)).fetchone()[0]
    learning_before = db.execute("SELECT COUNT(*) FROM paper_learning_events WHERE trade_id=?", (opened["id"],)).fetchone()[0]
    db.close()
    assert learning_before == 0

    settlement = (int(opened_at * 1000) + 1) / 1000
    assert settlement <= closed_at
    monkeypatch.setattr(paper_live, "fetch_funding_history", lambda *a, **k: [
        {"funding_rate": 0.002, "settlement_ts": settlement,
         "mark_price": 100.0, "rate_kind": "settled"}
    ])
    result = paper_live.sync_open_funding_positions(force=True)
    assert result["positions_synced"] == 1

    db = sqlite3.connect(paper_live._db_path())
    new_net, status = db.execute(
        "SELECT net_pnl,funding_status FROM paper_live_trades WHERE id=?", (opened["id"],)
    ).fetchone()
    learning_after = db.execute("SELECT COUNT(*) FROM paper_learning_events WHERE trade_id=?", (opened["id"],)).fetchone()[0]
    db.close()
    expected_cashflow = -opened["quantity"] * 100.0 * 0.002
    assert status == "SYNCED"
    assert new_net == pytest.approx(initial_net + expected_cashflow)
    assert learning_after == 1


@pytest.mark.parametrize("exchange,payload,expected_rate", [
    ("bybit", {"result": {"list": [{"fundingRate": "0.0005", "fundingRateTimestamp": "2000000001000"}]}}, 0.0005),
    ("okx", {"code": "0", "data": [{"realizedRate": "-0.0003", "fundingTime": "2000000001000"}]}, -0.0003),
    ("mexc", {"success": True, "data": {"resultList": [{"fundingRate": "0.0004", "settleTime": 2000000001000}]}}, 0.0004),
    ("gateio", [{"r": "0.0002", "t": 2000000001}], 0.0002),
    ("bitget", {"code": "00000", "data": {"resultList": [{"fundingRate": "0.0006", "fundingRateTimestamp": "2000000001000"}]}}, 0.0006),
])
def test_exchange_adapters_parse_documented_payloads(monkeypatch, exchange, payload, expected_rate):
    calls = []

    class Response:
        def raise_for_status(self):
            pass

        def json(self):
            return payload

    def fake_get(url, params=None, timeout=None):
        calls.append((url, params or {}))
        return Response()

    monkeypatch.setattr(funding.SESSION, "get", fake_get)
    rows = funding.fetch_funding_history(exchange, "BTCUSDT", 1999999999, 2000000010)
    assert rows
    assert rows[0]["funding_rate"] == pytest.approx(expected_rate)
    if exchange == "gateio":
        assert "api.gateio.ws/api/v4/futures/usdt/funding_rate" in calls[0][0]
        assert {"from", "to", "limit"}.issubset(calls[0][1])
        assert funding.HISTORY_EVENT_LIMITS["gateio"] == 1000 * funding.MAX_PAGES
    if exchange == "bitget":
        assert calls[0][0].endswith("/api/v3/market/history-fund-rate")
        assert calls[0][1]["cursor"] == "1"
        assert calls[0][1]["category"] == "USDT-FUTURES"


def test_funding_sync_respects_short_refresh_cooldown(monkeypatch):
    monkeypatch.setattr(paper_live, "get_quote", _quote)
    opened = paper_live.open_position("ADAUSDT", "LONG", "perp", "binance")
    calls = []
    monkeypatch.setattr(paper_live, "fetch_funding_history",
                        lambda *a, **k: calls.append(1) or [])
    first = paper_live.sync_open_funding_positions(opened["id"])
    second = paper_live.sync_open_funding_positions(opened["id"])
    assert first["positions_synced"] == 1
    assert second["positions_skipped_cooldown"] == 1
    assert len(calls) == 1
    forced = paper_live.sync_open_funding_positions(opened["id"], force=True)
    assert forced["positions_synced"] == 1
    assert len(calls) == 2


def test_funding_history_page_cap_marks_coverage_incomplete():
    events = [{"settlement_ts": 2_000_000_000 + i} for i in range(funding.HISTORY_EVENT_LIMITS["binance"])]
    assert funding.funding_history_complete("binance", events, 1_999_999_000) is False
    assert funding.funding_history_complete("binance", events, 2_000_000_000) is True


def test_binance_funding_history_paginates_after_1000_rows(monkeypatch):
    start_ms = 2_000_000_000_000
    step_ms = 8 * 60 * 60 * 1000
    first_page = [
        {"fundingRate": "0.0001", "fundingTime": start_ms + i * step_ms, "markPrice": "50000"}
        for i in range(1000)
    ]
    second_page = [{"fundingRate": "0.0002", "fundingTime": start_ms + 1000 * step_ms, "markPrice": "51000"}]
    calls = []

    class Response:
        def __init__(self, body): self.body = body
        def raise_for_status(self): pass
        def json(self): return self.body

    def fake_get(url, params=None, timeout=None):
        calls.append(dict(params or {}))
        return Response(first_page if len(calls) == 1 else second_page)

    monkeypatch.setattr(funding.SESSION, "get", fake_get)
    rows = funding.fetch_funding_history("binance", "BTCUSDT", 1_999_999_999,
                                         (start_ms + 1001 * step_ms) / 1000)
    assert len(rows) == 1001
    assert len(calls) == 2
    assert calls[1]["startTime"] == start_ms + 999 * step_ms + 1


def test_incomplete_closed_funding_hides_realized_totals_and_blocks_new_entries(monkeypatch):
    monkeypatch.setattr(paper_live, "get_quote", _quote)
    opened = paper_live.open_position("XRPUSDT", "LONG", "perp", "binance")
    monkeypatch.setattr(paper_live, "fetch_funding_history",
                        lambda *a, **k: (_ for _ in ()).throw(RuntimeError("funding API offline")))
    closed = paper_live.close_position(opened["id"])
    assert closed["funding_status"] == "ERROR"

    state = paper_live.get_state(refresh_quotes=False)
    assert state["account"]["funding_incomplete_closed_trades"] == 1
    assert state["account"]["realized_pnl_complete"] is False
    assert state["account"]["realized_pnl"] is None
    assert state["account"]["equity"] is None
    with pytest.raises(ValueError, match="Funding"):
        paper_live.open_position("LTCUSDT", "LONG", "spot", "binance")


def test_funding_quantity_is_allocated_at_each_settlement_timestamp():
    remaining, exited = funding.quantity_at_settlement(10.0, [
        {"created_at": 100.0, "quantity": 2.5},
        {"created_at": 200.0, "quantity": 1.0},
    ], 150.0)
    assert remaining == pytest.approx(7.5)
    assert exited == pytest.approx(2.5)
    remaining_later, exited_later = funding.quantity_at_settlement(10.0, [
        {"created_at": 100.0, "quantity": 2.5},
        {"created_at": 200.0, "quantity": 1.0},
    ], 250.0)
    assert remaining_later == pytest.approx(6.5)
    assert exited_later == pytest.approx(3.5)


def test_futures_partial_exit_allocates_funding_by_settlement_time(monkeypatch):
    monkeypatch.setattr(paper_live, "get_quote", _quote)
    opened = paper_live.open_position("BTCUSDT", "LONG", "perp", "binance")
    db = sqlite3.connect(paper_live._db_path())
    opened_at = db.execute("SELECT opened_at FROM paper_live_trades WHERE id=?", (opened["id"],)).fetchone()[0]
    db.close()

    # First settlement occurs before the partial close and is charged on full size.
    first_settlement = (int(opened_at * 1000) + 1) / 1000.0
    time.sleep(0.02)
    partial = paper_live.partial_close_position(
        opened["id"], opened["quantity"] * 0.25,
        idempotency_key="futures-partial-1", reason="TEST_PARTIAL",
    )
    assert partial["status"] == "PARTIAL"
    db = sqlite3.connect(paper_live._db_path())
    partial_at = db.execute("SELECT created_at FROM paper_partial_exits WHERE trade_id=?", (opened["id"],)).fetchone()[0]
    db.close()
    time.sleep(0.02)
    second_settlement = partial_at + 0.005
    monkeypatch.setattr(paper_live, "fetch_funding_history", lambda *a, **k: [
        {"funding_rate": 0.001, "settlement_ts": first_settlement, "mark_price": 100.0},
        {"funding_rate": 0.002, "settlement_ts": second_settlement, "mark_price": 100.0},
    ])

    synced = paper_live.sync_open_funding_positions(opened["id"], force=True)
    assert synced["events_inserted"] == 2
    db = sqlite3.connect(paper_live._db_path())
    events = db.execute("""SELECT position_quantity,partial_exited_quantity,cashflow
        FROM paper_funding_events WHERE trade_id=? ORDER BY settlement_ts_ms""", (opened["id"],)).fetchall()
    stored_total = db.execute("SELECT funding_total FROM paper_live_trades WHERE id=?", (opened["id"],)).fetchone()[0]
    db.close()
    exited = opened["quantity"] * 0.25
    remaining = opened["quantity"] - exited
    assert events[0][0] == pytest.approx(opened["quantity"])
    assert events[0][1] == pytest.approx(0.0)
    assert events[1][0] == pytest.approx(remaining)
    assert events[1][1] == pytest.approx(exited)
    expected = -(opened["quantity"] * 100.0 * 0.001 + remaining * 100.0 * 0.002)
    assert stored_total == pytest.approx(expected)

    # Reconciliation retries must not duplicate either settlement cashflow.
    replay = paper_live.sync_open_funding_positions(opened["id"], force=True)
    assert replay["events_inserted"] == 0
    db = sqlite3.connect(paper_live._db_path())
    count = db.execute("SELECT COUNT(*) FROM paper_funding_events WHERE trade_id=?", (opened["id"],)).fetchone()[0]
    db.close()
    assert count == 2


def test_partial_funding_coverage_is_retried_and_reconciled(monkeypatch):
    """A capped/incomplete history must remain eligible for later reconciliation."""
    monkeypatch.setattr(paper_live, "get_quote", _quote)
    opened = paper_live.open_position("XRPUSDT", "LONG", "perp", "binance")
    db = sqlite3.connect(paper_live._db_path())
    opened_at = db.execute(
        "SELECT opened_at FROM paper_live_trades WHERE id=?", (opened["id"],)
    ).fetchone()[0]
    db.close()
    first_ts = (int(opened_at * 1000) + 1) / 1000
    second_ts = first_ts + 8 * 60 * 60
    monkeypatch.setattr(paper_live, "fetch_funding_history", lambda *a, **k: [
        {"funding_rate": 0.001, "settlement_ts": first_ts, "mark_price": 100.0},
    ])
    monkeypatch.setattr(paper_live, "funding_history_complete", lambda *a, **k: False)

    closed = paper_live.close_position(opened["id"])
    assert closed["funding_status"] == "PARTIAL"
    first_net = closed["net_pnl"]

    # A later retry now has full coverage and includes an additional settlement.
    monkeypatch.setattr(paper_live, "fetch_funding_history", lambda *a, **k: [
        {"funding_rate": 0.001, "settlement_ts": first_ts, "mark_price": 100.0},
        {"funding_rate": -0.0005, "settlement_ts": second_ts, "mark_price": 110.0},
    ])
    monkeypatch.setattr(paper_live, "funding_history_complete", lambda *a, **k: True)
    result = paper_live.sync_open_funding_positions(opened["id"], force=True)
    assert result["positions_synced"] == 1

    db = sqlite3.connect(paper_live._db_path())
    event_count, status, net = db.execute(
        "SELECT funding_event_count,funding_status,net_pnl FROM paper_live_trades WHERE id=?",
        (opened["id"],),
    ).fetchone()
    db.close()
    assert event_count == 2  # first settlement was not duplicated
    assert status == "SYNCED"
    assert net != first_net
