import numpy as np
import pytest
from backend.evaluation import performance_metrics, probabilistic_sharpe_ratio, deflated_sharpe_ratio, compare_strategies

def test_stationary_bootstrap_metrics_are_deterministic_and_labeled():
    x=np.tile([.01,.012,-.004,-.003],80)
    a=performance_metrics(x,bootstrap_samples=200,seed=9,mean_block_length=4)
    b=performance_metrics(x,bootstrap_samples=200,seed=9,mean_block_length=4)
    assert a==b
    assert 'stationary_bootstrap' in a['bootstrap_method']
    assert len(a['mean_return_ci95'])==2

def test_psr_and_dsr_validate_trial_count_and_penalize_trials():
    rng=np.random.default_rng(3); x=rng.normal(.002,.01,1000)
    psr=probabilistic_sharpe_ratio(x,periods_per_year=365)
    dsr=deflated_sharpe_ratio(x,trials=100,periods_per_year=365)
    assert 0<=psr['psr']<=1 and 0<=dsr['dsr']<=1
    assert dsr['expected_max_sharpe_benchmark']>0
    with pytest.raises(ValueError): deflated_sharpe_ratio(x,trials=0)

def test_comparison_uses_aligned_paired_bootstrap_and_no_promotion_without_evidence():
    rng=np.random.default_rng(11); base=rng.normal(0,.01,400)
    challenger=base+0.0001
    result=compare_strategies({'primary':base,'meta':challenger,'buy_hold':base*.5},bootstrap_samples=300,trials=20,min_trades=500,seed=4)
    assert result['bootstrap_method']=='stationary_bootstrap_paired'
    assert result['n_bars']==400
    assert 'meta_vs_primary' in result['paired_comparisons']
    assert result['promotion_gates']['meta']['eligible'] is False

def test_comparison_rejects_misaligned_or_bad_returns():
    with pytest.raises(ValueError): compare_strategies({'a':[.1,.2,.3],'b':[.1,.2]})
    with pytest.raises(ValueError): compare_strategies({'a':[0,0,0],'b':[0,0,float('nan')]})
