import json
from backend import observability as obs

def test_event_append_and_read_order(tmp_path):
    a=obs.record_event('fetch_started',component='data',custom_dir=tmp_path)
    b=obs.record_event('fetch_failed',component='data',status='ERROR',details={'reason':'offline'},duration_ms=12.5,custom_dir=tmp_path)
    rows=obs.read_events(10,custom_dir=tmp_path)
    assert [x['event_id'] for x in rows] == [b['event_id'],a['event_id']]
    assert rows[0]['details']['reason']=='offline'
    assert len((tmp_path/'observability'/'events.jsonl').read_text().splitlines())==2

def test_event_summary_counts_errors(tmp_path):
    obs.record_event('ok',component='trainer',status='INFO',custom_dir=tmp_path)
    obs.record_event('bad',component='trainer',status='ERROR',custom_dir=tmp_path)
    summary=obs.event_summary(custom_dir=tmp_path)
    assert summary['events_sampled']==2
    assert summary['error_events_sampled']==1
    assert summary['counts']['trainer:ERROR']==1

def test_limit_is_bounded(tmp_path):
    for i in range(5): obs.record_event(f'e{i}',custom_dir=tmp_path)
    assert len(obs.read_events(2,custom_dir=tmp_path))==2
