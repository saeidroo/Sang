"""V19.3: Storm Scout — merging, scoring, resilience to blocked sources."""
import numpy as np
import pandas as pd

from backend import scout
from backend.api import app


def _row(base, c24, vol, src, c1h=None, mcap=None):
    return scout._row(base, 1.0, c24, vol, src, c1h, None, mcap)


def _candles(kind, n=300, seed=1):
    rng = np.random.default_rng(seed)
    close = 100 + np.cumsum(rng.normal(0, 0.05, n))
    vol = rng.uniform(900, 1100, n)
    if kind == 'storm':                                    # quiet range, then surge + breakout
        close[-6:] += np.linspace(0.5, 4.0, 6)
        vol[-4:] *= 5
    high, low = close + 0.1, close - 0.1
    if kind == 'storm':
        high[-6:] += np.linspace(0.2, 1.0, 6); low[-6:] -= 0.2
    return pd.DataFrame({'t': np.arange(n) * 900_000, 'high': high, 'low': low, 'close': close, 'volume': vol})


def test_row_filters_stables_leveraged_and_garbage():
    assert scout._row('USDC', 1, 0, 1e9, 'x') is None
    assert scout._row('BTCUP', 1, 5, 1e9, 'x') is None
    assert scout._row('ETH3L', 1, 5, 1e9, 'x') is None
    assert scout._row('ABC', 'nan', 5, 1e9, 'x') is None
    assert scout._row('abc', 1, 5, 1e9, 'x')['base'] == 'ABC'


def test_merge_uses_median_and_counts_independent_sources():
    rows = [_row('AAA', 10, 5e6, 'binance'), _row('AAA', 12, 8e6, 'okx'), _row('AAA', 11, 6e6, 'coingecko', 3, 2e7),
            {'flag_only': True, 'base': 'AAA', 'source': 'coingecko_trending'}]
    c = scout.merge(rows)['AAA']
    assert c['c24'] == 11 and c['vol'] == 6e6 and c['trending'] and len(c['sources']) == 3 and c['c1h'] == 3
    assert c['price'] == 1.0 and c['price_source_count'] == 3 and c['exchange_source_count'] == 2
    assert c['identity_conflict'] is False


def test_trending_flag_does_not_count_as_independent_price_source():
    c = scout.merge([_row('AAA', 5, 2e6, 'binance'),
                     {'flag_only': True, 'base': 'AAA', 'source': 'coingecko_trending'}])['AAA']
    assert c['trending'] is True
    assert c['sources'] == {'binance'}
    assert c['price_source_count'] == 1


def test_large_cross_source_price_dispersion_is_quarantined():
    rows = [_row('AAA', 5, 5e6, 'binance'),
            _row('AAA', 5, 5e6, 'okx'),
            _row('AAA', 9, 5e6, 'coingecko')]
    rows[-1]['price'] = 1.09
    c = scout.merge(rows)['AAA']
    assert c['identity_conflict'] is True
    assert c['price_dispersion_pct'] > scout.MAX_PRICE_DISPERSION_PCT
    score, phase, verified = scout.final_score(c, {'candle_score': 100, 'direction': 'up'})
    assert score <= scout.UNVERIFIED_CAP and verified is False


def test_small_cross_source_price_dispersion_is_accepted():
    rows = [_row('AAA', 5.00, 5e6, 'binance'),
            _row('AAA', 5.02, 5e6, 'okx'),
            _row('AAA', 4.99, 5e6, 'coingecko')]
    rows[0]['price'], rows[1]['price'], rows[2]['price'] = 5.00, 5.02, 4.99
    c = scout.merge(rows)['AAA']
    assert c['identity_conflict'] is False
    assert c['price'] == 5.0


def test_candle_features_separate_storm_from_quiet():
    storm = scout.candle_features(_candles('storm'))
    quiet = scout.candle_features(_candles('quiet'))
    assert storm['candle_score'] > 55 and storm['direction'] == 'up' and storm['vol_ratio'] > 3
    assert quiet['candle_score'] < 30
    assert scout.candle_features(_candles('quiet', n=100)) is None      # too few bars -> no opinion


def test_unverified_coin_can_never_reach_storm_level():
    c = scout.merge([_row('AAA', 25, 9e9, s, 6, 1e9) for s in ('binance', 'okx', 'bybit', 'kucoin', 'gate')]
                    + [{'flag_only': True, 'base': 'AAA', 'source': 'coingecko_trending'}])['AAA']
    score, phase, verified = scout.final_score(c, None)
    assert not verified and score <= scout.UNVERIFIED_CAP < scout.STORM_LEVEL


def test_exhausted_move_is_penalised():
    base = {'base': 'X', 'sources': {'a', 'b'}, 'trending': False}
    f = {'candle_score': 70.0}
    early = scout.final_score(dict(base, c24=5.0), f)[0]
    late = scout.final_score(dict(base, c24=80.0), f)
    assert late[1] == 'exhausted' and late[0] == early - 15


def _fake_sources(monkeypatch_dict, working):
    def boom():
        raise RuntimeError('blocked')
    out = {}
    for key, (label, fn) in monkeypatch_dict.items():
        out[key] = (label, (lambda r=working[key]: r) if key in working else boom)
    return out


def test_scan_survives_blocked_sources_and_reports_health():
    orig, orig_h = scout.SOURCES, dict(scout._HEALTH)
    scout._HEALTH.clear()
    work = {'binance': [_row('AAA', 6, 5e7, 'binance', 2, 1e8), _row('BBB', 1, 5e7, 'binance')],
            'okx': [_row('AAA', 7, 5e7, 'okx')]}
    scout.SOURCES = _fake_sources(orig, work)
    try:
        res = scout.scan_once(verify=lambda b: scout.candle_features(_candles('storm')) if b == 'AAA' else None)
    finally:
        scout.SOURCES = orig; scout._HEALTH.clear(); scout._HEALTH.update(orig_h)
    assert res['online'] and res['sources_ok'] == 2 and res['sources_total'] == len(orig)
    assert any(not s['ok'] and s.get('error') for s in res['sources'])
    top = (res['alerts'] + res['watch'])[0]
    assert top['base'] == 'AAA' and top['verified'] and top['direction'] == 'up'


def test_all_sources_down_returns_offline_not_fake_alerts():
    orig, orig_h = scout.SOURCES, dict(scout._HEALTH)
    scout._HEALTH.clear()
    scout.SOURCES = _fake_sources(orig, {})
    try:
        res = scout.scan_once()
    finally:
        scout.SOURCES = orig; scout._HEALTH.clear(); scout._HEALTH.update(orig_h)
    assert res['online'] is False and res['alerts'] == [] and res['watch'] == [] and 'error' in res


def test_failed_source_goes_on_cooldown_after_two_strikes():
    scout._HEALTH.pop('zzz', None)
    scout._mark_failed('zzz'); assert not scout._cooling('zzz')
    scout._mark_failed('zzz'); assert scout._cooling('zzz')
    scout._HEALTH.pop('zzz', None)


def test_offline_keeps_last_good_result_marked_stale():
    good = {'generated_at': 1, 'online': True, 'alerts': [{'base': 'AAA'}], 'watch': [], 'sources': []}
    orig = scout.scan_once
    scout._STATE.update(result=good, fail_streak=0, running=False)
    scout.scan_once = lambda: {'generated_at': 2, 'online': False, 'alerts': [], 'watch': [], 'sources': [], 'error': 'down'}
    try:
        st = scout.run_scan()
    finally:
        scout.scan_once = orig
    assert st['stale'] and st['alerts'][0]['base'] == 'AAA' and st['fail_streak'] == 1
    scout._STATE.update(result=None, fail_streak=0)


def test_scout_routes():
    c = app.test_client()
    scout._STATE.update(result=None, fail_streak=0, running=False)
    assert c.get('/api/scout').status_code == 200
    assert 'alerts' in c.get('/api/scout').get_json()
