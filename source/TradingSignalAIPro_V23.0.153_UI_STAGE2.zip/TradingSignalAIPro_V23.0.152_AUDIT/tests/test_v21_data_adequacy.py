"""V21 part 9-11: effective-sample honesty, feature cap, bigger default history."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend import adequacy, api, longrun  # noqa: E402


def test_effective_samples_divides_by_horizon():
    assert adequacy.effective_samples(2100) == 2100 // 12
    assert adequacy.effective_samples(0) == 0


def test_recommended_features_bounds():
    assert adequacy.recommended_features(100, 85) == 33            # 100 // 3
    assert adequacy.recommended_features(10, 85) == adequacy.MIN_FEATURES
    assert adequacy.recommended_features(5000, 85) == 85           # never above the max


def test_levels_and_notes():
    small = adequacy.assess(3000, '1h')
    big = adequacy.assess(20000, '1h')
    assert small['level'] in ('weak', 'medium') and small['days'] == 125.0
    assert any('۶ ماه' in n for n in small['notes'])               # single-regime warning
    assert big['effective_samples'] > small['effective_samples']
    assert big['level'] in ('good', 'great') and big['recommended_features'] > small['recommended_features']


def test_assess_uses_real_train_rows_when_given():
    r = adequacy.assess(10000, '1h', train_rows=1200)
    assert r['effective_samples'] == 100 and r['level'] == 'weak'


def test_adequacy_endpoint():
    api.app.config['TESTING'] = True
    with api.app.test_client() as c:
        d = c.get('/api/learn/adequacy?limit=10000&timeframe=1h').get_json()
        assert d['effective_samples'] > 300 and d['level_fa']
        assert c.get('/api/learn/adequacy?limit=10&timeframe=1h').status_code == 400
        assert c.get('/api/learn/adequacy?limit=5000&timeframe=9x').status_code == 400


def test_defaults_raised():
    assert longrun.normalize_config({'symbols': ['BTCUSDT'], 'timeframes': ['1h']})['limit'] == 10000
    html = (ROOT / 'frontend' / 'index.html').read_text(encoding='utf-8')
    assert '<option selected>10000</option>' in html
    assert 'id="learnAdequacy"' in html
    assert 'refreshAdequacy' in (ROOT / 'frontend' / 'app.js').read_text(encoding='utf-8')


def _candles(n, seed):
    rng = np.random.default_rng(seed)
    close = 100 * np.exp(np.cumsum(rng.normal(0.0003, 0.008, n)))
    high = close * (1 + np.abs(rng.normal(0, 0.004, n)))
    low = close * (1 - np.abs(rng.normal(0, 0.004, n)))
    ts = pd.date_range('2024-01-01', periods=n, freq='1h').astype('int64') // 10**6
    df = pd.DataFrame({'t': ts, 'open': np.r_[close[0], close[:-1]], 'high': high, 'low': low,
                       'close': close, 'volume': rng.uniform(1000, 5000, n)})
    df.attrs['source'] = 'test'
    return df


def test_trainer_caps_features_on_small_data_and_records_report(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(tmp_path / 'm'))
    from backend.trainer import TrainingSession
    sess = TrainingSession()
    r = sess.run('CAPUSDT', '1h', limit=2500, df=_candles(2500, 5), quick=True)
    meta = r['meta']
    rep = meta['data_adequacy']
    assert rep['effective_samples'] < 255                      # far below the 85-feature comfort zone
    assert meta['feature_count'] == rep['recommended_features'] < 85
    assert any('محدود شد' in line for line in sess.progress_log)
