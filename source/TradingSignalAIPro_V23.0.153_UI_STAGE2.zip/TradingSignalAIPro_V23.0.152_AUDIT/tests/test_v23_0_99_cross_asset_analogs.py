from backend import market_brain


def test_cross_asset_analogs_exclude_same_symbol():
    # Validate the cross-asset filtering contract independently of market data.
    rows = [('BTCUSDT', 1.0), ('ETHUSDT', 2.0), ('BTCUSDT', 3.0)]
    selected = [ret for symbol, ret in rows if symbol != 'BTCUSDT']
    assert selected == [2.0]


def test_cross_asset_summary_requires_minimum_samples():
    assert market_brain.MIN_ANALOGS == 8
    sample = [1.0, -1.0, 2.0]
    status = 'available' if len(sample) >= market_brain.MIN_ANALOGS else 'insufficient_samples'
    assert status == 'insufficient_samples'


def test_cross_asset_source_symbols_are_distinct():
    rows = [('ETHUSDT', 1.0), ('ETHUSDT', 2.0), ('SOLUSDT', 3.0)]
    assert len({symbol for symbol, _ in rows if symbol != 'BTCUSDT'}) == 2
