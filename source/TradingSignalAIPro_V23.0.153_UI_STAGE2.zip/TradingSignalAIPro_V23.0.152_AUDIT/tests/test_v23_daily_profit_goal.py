from backend import autopilot, paper_live


def test_daily_profit_goal_capital_tiers():
    assert autopilot.daily_profit_target_for_capital(1000) == 30.0
    assert autopilot.daily_profit_target_for_capital(2500) == 30.0
    assert autopilot.daily_profit_target_for_capital(999.99) == 20.0
    assert autopilot.daily_profit_target_for_capital(600) == 20.0
    assert autopilot.daily_profit_target_for_capital(200) == 20.0
    assert autopilot.daily_profit_target_for_capital(199.99) == 10.0
    assert autopilot.daily_profit_target_for_capital(50) == 10.0


def test_daily_profit_target_rejects_invalid_capital():
    for capital in (0, -1, float("nan"), float("inf"), "not-a-number"):
        try:
            autopilot.daily_profit_target_for_capital(capital)
        except ValueError:
            pass
        else:
            raise AssertionError(f"invalid capital accepted: {capital!r}")


def test_daily_profit_goal_uses_realized_closed_autopilot_net_pnl(monkeypatch):
    original = dict(autopilot._CONFIG)
    try:
        autopilot._CONFIG = dict(autopilot.DEFAULT_CONFIG)
        autopilot._CONFIG["daily_start_balance"] = 500.0
        monkeypatch.setattr(autopilot, "_closed_autopilot_trades", lambda since=None: [
            {"net_pnl": 8.5}, {"net_pnl": 10.0}, {"net_pnl": -1.0}
        ])
        result = autopilot.daily_profit_goal_snapshot()
        assert result["complete"] is True
        assert result["capital_usdt"] == 500.0
        assert result["target_usdt"] == 20.0
        assert result["realized_net_pnl_usdt"] == 17.5
        assert result["remaining_usdt"] == 2.5
        assert result["reached"] is False

        monkeypatch.setattr(autopilot, "_closed_autopilot_trades", lambda since=None: [
            {"net_pnl": 23.0}
        ])
        result = autopilot.daily_profit_goal_snapshot()
        assert result["reached"] is True
        assert result["action"] == "pause_new_entries_until_next_local_day"
    finally:
        autopilot._CONFIG = original


def test_daily_profit_goal_fails_closed_when_ledger_cannot_be_read(monkeypatch):
    monkeypatch.setattr(autopilot, "_closed_autopilot_trades", lambda since=None: (_ for _ in ()).throw(RuntimeError("ledger offline")))
    result = autopilot.daily_profit_goal_snapshot()
    assert result["complete"] is False
    assert result["reached"] is None
    assert result["action"] == "block_new_entries_until_ledger_readable"


def test_entry_cycle_does_not_open_new_trades_after_daily_goal(monkeypatch):
    old_loaded = autopilot._STATE.get("runtime_state_loaded")
    old_error = autopilot._STATE.get("runtime_state_error")
    try:
        autopilot._STATE["runtime_state_loaded"] = True
        autopilot._STATE["runtime_state_error"] = ""
        monkeypatch.setattr(autopilot, "daily_profit_goal_snapshot", lambda: {
            "complete": True, "reached": True, "target_usdt": 30.0,
            "realized_net_pnl_usdt": 31.0, "remaining_usdt": 0.0,
        })
        monkeypatch.setattr(autopilot, "_log_decision", lambda *args, **kwargs: None)
        monkeypatch.setattr(autopilot, "_persist_runtime_state", lambda: (_ for _ in ()).throw(AssertionError("should not reach scan")))
        result = autopilot._entry_cycle_once_impl(allow_when_stopped=True)
        assert result["profit_goal_reached"] is True
        assert result["opened"] == 0
    finally:
        autopilot._STATE["runtime_state_loaded"] = old_loaded
        autopilot._STATE["runtime_state_error"] = old_error


def test_real_order_execution_remains_disabled():
    assert paper_live.SETTINGS["real_orders_enabled"] is False
    assert autopilot.status()["safety"]["real_orders_enabled"] is False
