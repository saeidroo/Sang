"""Crash/exception atomicity checks for the local PAPER ledger."""
import sqlite3
import pytest
from backend import paper_live


def _trade(tmp_path, monkeypatch, market='spot'):
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'stage2j.sqlite3'))
    paper_live.init_db(backfill_learning=False)
    with paper_live._connect() as c:
        cur = c.execute('''INSERT INTO paper_live_trades(
            opened_at,symbol,market,exchange,requested_exchange,side,quantity,notional,
            reference_entry,entry_fill,entry_fee,stop_price,target_price,status,settings_json,
            timeframe,replay_status,funding_status)
            VALUES(1,'BTCUSDT',?,'binance','binance','LONG',1,100,100,100,0.1,95,110,'OPEN','{}','5m','PENDING',?)''',
            (market, 'PENDING' if market == 'perp' else 'NOT_APPLICABLE'))
        return cur.lastrowid


def test_sqlite_connections_use_wal_full_and_foreign_keys(tmp_path, monkeypatch):
    _trade(tmp_path, monkeypatch)
    with paper_live._connect() as c:
        assert str(c.execute('PRAGMA journal_mode').fetchone()[0]).lower() == 'wal'
        assert int(c.execute('PRAGMA synchronous').fetchone()[0]) == 2
        assert int(c.execute('PRAGMA foreign_keys').fetchone()[0]) == 1


def test_close_and_learning_event_roll_back_together_on_crash(tmp_path, monkeypatch):
    trade_id = _trade(tmp_path, monkeypatch)
    with pytest.raises(RuntimeError, match='simulated process interruption'):
        with paper_live._connect() as c:
            c.execute('BEGIN IMMEDIATE')
            paper_live._closed_trade(c, trade_id, 105, 'TEST')
            raise RuntimeError('simulated process interruption')
    with paper_live._connect() as c:
        assert c.execute('SELECT status FROM paper_live_trades WHERE id=?', (trade_id,)).fetchone()[0] == 'OPEN'
        assert c.execute('SELECT COUNT(*) FROM paper_learning_events WHERE trade_id=?', (trade_id,)).fetchone()[0] == 0


def test_partial_exit_row_rolls_back_on_crash(tmp_path, monkeypatch):
    trade_id = _trade(tmp_path, monkeypatch)
    with pytest.raises(RuntimeError):
        with paper_live._connect() as c:
            c.execute('BEGIN IMMEDIATE')
            c.execute('''INSERT INTO paper_partial_exits(trade_id,idempotency_key,created_at,quantity,
                reference_exit,exit_fill,entry_fee_allocated,exit_fee,gross_pnl,net_pnl)
                VALUES(?,?,?,?,?,?,?,?,?,?)''', (trade_id, 'once', 2, .25, 101, 100.8, .025, .01, .2, .165))
            raise RuntimeError('simulated process interruption')
    with paper_live._connect() as c:
        assert c.execute('SELECT COUNT(*) FROM paper_partial_exits WHERE trade_id=?', (trade_id,)).fetchone()[0] == 0


def test_funding_events_and_position_totals_roll_back_together(tmp_path, monkeypatch):
    trade_id = _trade(tmp_path, monkeypatch, market='perp')
    with pytest.raises(RuntimeError):
        with paper_live._connect() as c:
            c.execute('BEGIN IMMEDIATE')
            c.execute('''INSERT INTO paper_funding_events(trade_id,settlement_ts_ms,exchange,symbol,side,
                funding_rate,event_notional,notional_basis,position_quantity,partial_exited_quantity,cashflow,created_at)
                VALUES(?,1000,'binance','BTCUSDT','LONG',0.001,100,'mark',1,0,0.1,2)''', (trade_id,))
            c.execute("UPDATE paper_live_trades SET funding_total=.1,funding_event_count=1,funding_status='SYNCED' WHERE id=?", (trade_id,))
            raise RuntimeError('simulated process interruption')
    with paper_live._connect() as c:
        row = c.execute('SELECT funding_total,funding_event_count,funding_status FROM paper_live_trades WHERE id=?', (trade_id,)).fetchone()
        assert tuple(row) == (0.0, 0, 'PENDING')
        assert c.execute('SELECT COUNT(*) FROM paper_funding_events WHERE trade_id=?', (trade_id,)).fetchone()[0] == 0


def test_committed_idempotency_records_survive_reopen_and_reject_duplicates(tmp_path, monkeypatch):
    trade_id = _trade(tmp_path, monkeypatch)
    with paper_live._connect() as c:
        c.execute('''INSERT INTO paper_partial_exits(trade_id,idempotency_key,created_at,quantity,
            reference_exit,exit_fill,entry_fee_allocated,exit_fee,gross_pnl,net_pnl)
            VALUES(?,?,?,?,?,?,?,?,?,?)''', (trade_id, 'stable-key', 2, .25, 101, 100.8, .025, .01, .2, .165))
    with paper_live._connect() as c:
        assert c.execute('SELECT COUNT(*) FROM paper_partial_exits WHERE trade_id=? AND idempotency_key=?',
                         (trade_id, 'stable-key')).fetchone()[0] == 1
        with pytest.raises(sqlite3.IntegrityError):
            c.execute('''INSERT INTO paper_partial_exits(trade_id,idempotency_key,created_at,quantity,
                reference_exit,exit_fill,entry_fee_allocated,exit_fee,gross_pnl,net_pnl)
                VALUES(?,?,?,?,?,?,?,?,?,?)''', (trade_id, 'stable-key', 3, .25, 101, 100.8, .025, .01, .2, .165))


def test_funding_settlement_primary_key_prevents_duplicate_cashflow(tmp_path, monkeypatch):
    trade_id = _trade(tmp_path, monkeypatch, market='perp')
    sql = '''INSERT OR IGNORE INTO paper_funding_events(trade_id,settlement_ts_ms,exchange,symbol,side,
        funding_rate,event_notional,notional_basis,position_quantity,partial_exited_quantity,cashflow,created_at)
        VALUES(?,1000,'binance','BTCUSDT','LONG',0.001,100,'mark',1,0,0.1,2)'''
    with paper_live._connect() as c:
        first = c.execute(sql, (trade_id,)).rowcount
        second = c.execute(sql, (trade_id,)).rowcount
        assert (first, second) == (1, 0)
        assert c.execute('SELECT COUNT(*) FROM paper_funding_events WHERE trade_id=?', (trade_id,)).fetchone()[0] == 1
