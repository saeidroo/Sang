import json
import sqlite3
import zipfile

from backend import historical


def test_export_archive_bundle_contains_all_rows_and_manifest(tmp_path, monkeypatch):
    db = tmp_path / 'candles.sqlite3'
    monkeypatch.setattr(historical, 'DB_PATH', db)
    with historical._db() as con:
        con.executemany('INSERT INTO candles(symbol,timeframe,t,open,high,low,close,volume) VALUES (?,?,?,?,?,?,?,?)', [
            ('BTCUSDT','1h',1700000000000,1,2,0.5,1.5,100),
            ('BTCUSDT','1h',1700003600000,1.5,2,1,1.8,120),
            ('ICPUSDT','4h',1700000000000,10,12,9,11,500),
        ])
        con.commit()
    path, manifest = historical.export_archive_bundle()
    try:
        assert manifest['total_candles'] == 3
        assert manifest['market_timeframe_count'] == 2
        with zipfile.ZipFile(path) as zf:
            assert {'candles.sqlite3', 'manifest.json', 'README.txt'} <= set(zf.namelist())
            saved = json.loads(zf.read('manifest.json'))
            assert saved['total_candles'] == 3
            dbfile = tmp_path / 'export.sqlite3'
            dbfile.write_bytes(zf.read('candles.sqlite3'))
            con = sqlite3.connect(dbfile)
            try:
                assert con.execute('SELECT COUNT(*) FROM candles').fetchone()[0] == 3
            finally:
                con.close()
    finally:
        import os
        os.unlink(path)


def test_empty_archive_has_no_download(tmp_path, monkeypatch):
    monkeypatch.setattr(historical, 'DB_PATH', tmp_path / 'empty.sqlite3')
    path, manifest = historical.export_archive_bundle()
    assert path is None
    assert manifest['total_candles'] == 0
