import base64, json
from datetime import datetime, timezone
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from backend import external_anchor, signed_anchor


def _receipt(anchor, key, seq=1):
    payload = {'schema_version': external_anchor.SCHEMA, 'witness_id': 'independent-witness-test',
               'anchor_digest': external_anchor.anchor_digest(anchor), 'sequence': seq,
               'timestamp': datetime.now(timezone.utc).isoformat()}
    raw = json.dumps(payload, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
    return {**payload, 'signature': base64.b64encode(key.sign(raw)).decode()}


def test_external_witness_receipt_signature_and_digest(tmp_path, monkeypatch):
    key = Ed25519PrivateKey.generate()
    pem = key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode()
    anchor = {'key_id':'a'*64, 'sequence': 7, 'signature':'test-signature'}
    receipt = _receipt(anchor, key)
    assert external_anchor.verify_receipt(receipt, external_anchor.anchor_digest(anchor), public_key_pem=pem)['valid']
    tampered = dict(receipt, sequence=2)
    assert not external_anchor.verify_receipt(tampered, external_anchor.anchor_digest(anchor), public_key_pem=pem)['valid']
    assert not external_anchor.verify_receipt(receipt, '0'*64, public_key_pem=pem)['valid']


def test_external_witness_requires_https_and_pinned_key(monkeypatch):
    monkeypatch.delenv('TS_AI_WITNESS_PUBLIC_KEY_PEM', raising=False)
    monkeypatch.setenv('TS_AI_WITNESS_URL', 'http://example.invalid')
    assert external_anchor.submit_anchor({'a':1})['error'] == 'witness_https_url_required'
    monkeypatch.setenv('TS_AI_WITNESS_URL', 'https://witness.example.invalid')
    assert external_anchor.submit_anchor({'a':1})['error'] == 'witness_public_key_not_configured'


def test_trust_store_health_detects_missing_or_corrupt_material(tmp_path, monkeypatch):
    monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR', str(tmp_path/'trust'))
    assert signed_anchor.trust_store_health()['state'] == 'active_key_record_missing'
    kp = signed_anchor.ensure_keypair()
    assert signed_anchor.trust_store_health()['healthy']
    (tmp_path/'trust'/'trusted'/f"{kp['key_id']}.private.pem").write_text('corrupt')
    result = signed_anchor.trust_store_health()
    assert not result['healthy'] and result['state'] == 'trust_store_unreadable'
