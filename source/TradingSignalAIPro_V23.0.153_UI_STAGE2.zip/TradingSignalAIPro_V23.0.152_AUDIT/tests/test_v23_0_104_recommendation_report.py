from backend import storm_learning as sl


def _coin(symbol):
    return {'symbol': symbol, 'price': 100, 'score': 75, 'phase': 'early',
            'direction': 'up', 'verified': True}


def test_consolidated_report_classifies_all_recommendation_outcomes(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'consolidated.sqlite3')
    base = 1_750_000_000
    symbols = ('FAST', 'DAY', 'LATE', 'RECOVER', 'MISS')
    sl.record_scan([_coin(s) for s in symbols], timestamp=base)

    # 1h: FAST reaches target; all others remain below target.
    sl.record_scan([], timestamp=base + 3600, snapshots={
        'FAST': {'price': 102}, 'DAY': {'price': 100}, 'LATE': {'price': 100},
        'RECOVER': {'price': 100}})
    # 4h: no additional target is reached.
    sl.record_scan([], timestamp=base + 4 * 3600, snapshots={
        'FAST': {'price': 101}, 'DAY': {'price': 100}, 'LATE': {'price': 100},
        'RECOVER': {'price': 100}})
    # 24h: DAY reaches the 5% threshold; RECOVER records a real dip.
    sl.record_scan([], timestamp=base + 86400, snapshots={
        'FAST': {'price': 101}, 'DAY': {'price': 106}, 'LATE': {'price': 100},
        'RECOVER': {'price': 95}})
    # 3d: LATE pumps; RECOVER rebounds after the observed dip.
    sl.record_scan([], timestamp=base + 3 * 86400, snapshots={
        'FAST': {'price': 100}, 'DAY': {'price': 106}, 'LATE': {'price': 112},
        'RECOVER': {'price': 112}})
    sl.record_scan([], timestamp=base + 7 * 86400, snapshots={
        'FAST': {'price': 100}, 'DAY': {'price': 106}, 'LATE': {'price': 112},
        'RECOVER': {'price': 112}})
    # Let the unobserved coin's final horizon expire; it remains unknown.
    sl.record_scan([], timestamp=base + 10 * 86400, snapshots={
        'FAST': {'price': 100}, 'DAY': {'price': 106}, 'LATE': {'price': 112},
        'RECOVER': {'price': 112}})

    report = sl.followups()['performance_report']
    counts = report['counts']
    assert report['total_recommendations'] == 5
    assert counts['immediate_pump'] == 1
    assert counts['next_day_pump'] == 1
    assert counts['delayed_pump'] == 1
    assert counts['recovered_after_dip'] == 1
    assert counts['insufficient_observations'] == 1
    assert counts['never_reached_target'] == 0


def test_never_reached_target_requires_five_valid_observed_horizons(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'never.sqlite3')
    base = 1_760_000_000
    sl.record_scan([_coin('FLAT')], timestamp=base)
    for seconds in (3600, 4 * 3600, 86400, 3 * 86400, 7 * 86400):
        sl.record_scan([], timestamp=base + seconds, snapshots={'FLAT': {'price': 100}})
    report = sl.followups()['performance_report']
    assert report['counts']['never_reached_target'] == 1
    assert report['categories']['never_reached_target'][0]['completed_valid_horizons'] == 5


def test_missing_data_is_not_called_failure(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'unknown.sqlite3')
    base = 1_770_000_000
    sl.record_scan([_coin('UNKNOWN')], timestamp=base)
    # No real price snapshots: after all horizons and grace windows expire,
    # the report must preserve the outcome as unknown, not as a failed pick.
    sl.record_scan([], timestamp=base + 10 * 86400)
    report = sl.followups()['performance_report']
    assert report['counts']['insufficient_observations'] == 1
    assert report['counts']['never_reached_target'] == 0


def test_unresolved_recommendation_remains_pending(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'pending.sqlite3')
    sl.record_scan([_coin('WAIT')], timestamp=1_780_000_000)
    report = sl.followups()['performance_report']
    assert report['counts']['pending'] == 1
    assert report['counts']['never_reached_target'] == 0
