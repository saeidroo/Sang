import pytest

from backend.trade_contract import (
    ATR_SL_MULT, ATR_TP_MULT, TRADE_HORIZON_BARS, atr_bracket,
)
from backend import features, signal


def test_training_and_backtest_share_trade_contract_constants():
    assert features.TB_UP_MULT == ATR_TP_MULT
    assert features.TB_DN_MULT == ATR_SL_MULT
    assert features.TB_HORIZON == TRADE_HORIZON_BARS
    assert signal.ATR_TP_MULT == ATR_TP_MULT
    assert signal.ATR_SL_MULT == ATR_SL_MULT
    assert signal.SIM_HORIZON == TRADE_HORIZON_BARS
    assert signal.BACKTEST_HORIZON == TRADE_HORIZON_BARS


@pytest.mark.parametrize(
    "side,stop,target",
    [("LONG", 97.0, 103.0), ("SHORT", 103.0, 97.0)],
)
def test_paper_bracket_matches_symmetric_training_barriers(side, stop, target):
    result = atr_bracket(entry_price=100.0, atr_value=2.0, side=side)
    assert result["stop_price"] == pytest.approx(stop)
    assert result["target_price"] == pytest.approx(target)
    assert result["stop_atr_multiplier"] == ATR_SL_MULT
    assert result["target_atr_multiplier"] == ATR_TP_MULT
    assert result["horizon_bars"] == TRADE_HORIZON_BARS


def test_shared_bracket_rejects_invalid_market_inputs():
    with pytest.raises(ValueError):
        atr_bracket(entry_price=100, atr_value=0, side="LONG")
    with pytest.raises(ValueError):
        atr_bracket(entry_price=100, atr_value=1, side="SIDEWAYS")


def test_shared_bracket_reports_net_rr_without_changing_training_geometry():
    result = atr_bracket(entry_price=100, atr_value=1, side="LONG",
                         fee_bps_per_side=10, slippage_bps_per_side=5)
    assert result["stop_price"] == pytest.approx(100 - ATR_SL_MULT)
    assert result["target_price"] == pytest.approx(100 + ATR_TP_MULT)
    assert result["round_trip_cost_pct"] == pytest.approx(0.30)
    from backend.execution_model import net_return_fraction
    costs = {"fee_bps_per_side": 10.0, "total_adverse_price_bps_per_side": 5.0}
    reward = net_return_fraction(entry_reference=100, exit_reference=101.5,
                                 side="LONG", notional=1.0, costs=costs)
    risk = -net_return_fraction(entry_reference=100, exit_reference=98.5,
                                side="LONG", notional=1.0, costs=costs)
    assert result["net_reward_risk"] == pytest.approx(reward / risk)
    assert result["funding_included"] is False


def test_bracket_does_not_charge_entry_slippage_twice_for_an_executed_fill():
    from backend.execution_model import (
        execution_costs, fill_price, net_return_from_filled_entry_fraction,
    )

    costs = execution_costs(1000.0)
    reference = 100.0
    filled_entry = fill_price(reference, "LONG", "entry", costs)
    result = atr_bracket(
        entry_price=filled_entry, atr_value=1.0, side="LONG",
        fee_bps_per_side=costs["fee_bps_per_side"],
        slippage_bps_per_side=costs["total_adverse_price_bps_per_side"],
        entry_price_is_fill=True,
    )
    expected_reward = net_return_from_filled_entry_fraction(
        entry_fill=filled_entry, exit_reference=result["target_price"],
        side="LONG", notional=1.0, costs=costs,
    )
    expected_risk = -net_return_from_filled_entry_fraction(
        entry_fill=filled_entry, exit_reference=result["stop_price"],
        side="LONG", notional=1.0, costs=costs,
    )
    assert result["net_reward_pct"] == pytest.approx(expected_reward * 100.0)
    assert result["net_risk_pct"] == pytest.approx(expected_risk * 100.0)
    assert result["net_reward_risk"] == pytest.approx(expected_reward / expected_risk)


def test_live_time_horizon_uses_supported_timeframe_seconds():
    from backend.trade_contract import timeframe_seconds
    assert timeframe_seconds("5m") * TRADE_HORIZON_BARS == 3600
    assert timeframe_seconds("1h") * TRADE_HORIZON_BARS == 43200
    with pytest.raises(ValueError):
        timeframe_seconds("unknown")


def test_trailing_stop_contract_is_symmetric_and_tightens_with_favourable_peak():
    from backend.trade_contract import trailing_stop_price, TRAIL_DISTANCE_PCT
    assert trailing_stop_price(side="LONG", peak_price=110, distance_pct=TRAIL_DISTANCE_PCT) == pytest.approx(108.9)
    assert trailing_stop_price(side="SHORT", peak_price=90, distance_pct=TRAIL_DISTANCE_PCT) == pytest.approx(90.9)
    with pytest.raises(ValueError):
        trailing_stop_price(side="LONG", peak_price=0, distance_pct=1.0)


def test_backtest_round_trip_cost_uses_same_execution_model_as_paper():
    from backend.execution_model import execution_costs, round_trip_cost_pct
    from backend import signal

    costs = execution_costs(1000.0)
    expected_bps = 2 * costs["fee_bps_per_side"] + 2 * costs["total_adverse_price_bps_per_side"]
    assert round_trip_cost_pct(1000.0) == pytest.approx(expected_bps / 100.0)
    assert signal.ROUND_TRIP_COST_PCT == pytest.approx(round_trip_cost_pct(1000.0))
    assert signal.ROUND_TRIP_COST_PCT > 0.30


def test_backtest_net_return_uses_same_fill_and_fee_math_as_paper():
    from backend.execution_model import execution_costs, net_return_fraction, fill_price

    costs = execution_costs(1000.0)
    entry_ref, exit_ref = 100.0, 103.0
    result = net_return_fraction(entry_reference=entry_ref, exit_reference=exit_ref,
                                 side="LONG", notional=1000.0, costs=costs)
    entry_fill = fill_price(entry_ref, "LONG", "entry", costs)
    exit_fill = fill_price(exit_ref, "LONG", "exit", costs)
    quantity = 1000.0 / entry_fill
    expected = (quantity * (exit_fill - entry_fill)
                - 1000.0 * costs["fee_bps_per_side"] / 10000.0
                - quantity * exit_fill * costs["fee_bps_per_side"] / 10000.0) / 1000.0
    assert result == pytest.approx(expected)


def test_backtest_simulator_deducts_exact_execution_costs_on_barrier_exit():
    import numpy as np
    import pandas as pd
    from backend import signal
    from backend.execution_model import net_return_fraction

    rows = pd.DataFrame({
        "high": [100.0, 104.0],
        "low": [100.0, 99.0],
        "close": [100.0, 103.0],
        "atr_14": [2.0, 2.0],
    })
    result = signal.simulate_trades(np.array([0.9, 0.5]), rows, thr=0.6, horizon=1)
    entry_fill = 100.0 * (1.0 + signal.BACKTEST_EXECUTION_COSTS["total_adverse_price_bps_per_side"] / 10000.0)
    target = entry_fill + 1.5 * 2.0
    expected = net_return_fraction(entry_reference=100.0, exit_reference=target,
        side="LONG", notional=signal.BACKTEST_COST_NOTIONAL_USDT,
        costs=signal.BACKTEST_EXECUTION_COSTS)
    assert result["n_trades"] == 1
    assert result["wins"] == (1 if expected > 0 else 0)
    assert result["expectancy_pct"] == pytest.approx(expected * 100.0)


def test_funding_cashflow_sign_and_missing_settlement_behavior():
    import numpy as np
    from backend.execution_model import funding_cashflow_for_bars

    # Positive funding: longs pay, shorts receive; NaN means no settlement.
    rates = np.array([0.001, np.nan, -0.0005])
    marks = np.array([100.0, np.nan, 110.0])
    long_cash = funding_cashflow_for_bars(side="LONG", quantity=2.0,
                                           funding_rates=rates, mark_prices=marks)
    short_cash = funding_cashflow_for_bars(side="SHORT", quantity=2.0,
                                            funding_rates=rates, mark_prices=marks)
    assert long_cash == pytest.approx(-0.09)
    assert short_cash == pytest.approx(0.09)


def test_perpetual_backtest_requires_realized_funding_columns():
    import numpy as np
    import pandas as pd
    from backend.signal import simulate_trades

    rows = pd.DataFrame({"high": [100.0, 104.0], "low": [100.0, 99.0],
                         "close": [100.0, 103.0], "atr_14": [2.0, 2.0]})
    with pytest.raises(ValueError, match="realized funding"):
        simulate_trades(np.array([0.9, 0.5]), rows, thr=0.6, horizon=1, market="perp")


def test_perpetual_backtest_includes_realized_funding_in_net_expectancy():
    import numpy as np
    import pandas as pd
    from backend import signal

    rows = pd.DataFrame({"t": [1000, 2000], "high": [100.0, 104.0],
                         "low": [100.0, 99.0], "close": [100.0, 103.0],
                         "atr_14": [2.0, 2.0], "funding_rate": [np.nan, 0.001],
                         "funding_mark_price": [np.nan, 103.0],
                         "funding_settlement_ts": [np.nan, 1500]})
    result = signal.simulate_trades(np.array([0.9, 0.5]), rows, thr=0.6,
                                    horizon=1, market="perp")
    assert result["n_trades"] == 1
    # Funding charge for a long is included and makes the net result lower.
    spot_result = signal.simulate_trades(np.array([0.9, 0.5]), rows, thr=0.6,
                                         horizon=1, market="spot")
    assert result["expectancy_pct"] < spot_result["expectancy_pct"]


def test_per_trade_diagnostics_reuse_canonical_non_overlapping_net_simulator():
    import numpy as np
    import pandas as pd
    from backend.signal import simulate_trades, simulate_trades_per_trade

    # First signal exits at TP; the second overlapping signal must be skipped.
    rows = pd.DataFrame({
        "high": [100.0, 104.0, 100.0, 100.0],
        "low": [100.0, 99.0, 99.0, 99.0],
        "close": [100.0, 103.0, 100.0, 100.0],
        "atr_14": [2.0, 2.0, 2.0, 2.0],
    })
    probs = np.array([0.9, 0.9, 0.5, 0.5])
    aggregate = simulate_trades(probs, rows, thr=0.6, horizon=2)
    details = simulate_trades_per_trade(probs, rows, thr=0.6, horizon=2)

    assert len(details) == aggregate["n_trades"]
    assert [trade["idx"] for trade in details] == [trade["idx"] for trade in aggregate["trade_details"]]
    assert [trade["is_win"] for trade in details] == [trade["is_win"] for trade in aggregate["trade_details"]]
    assert details[0]["exit_reason"] == "TAKE_PROFIT"
    assert "net_return_pct" in details[0]


def test_per_trade_diagnostics_include_canonical_time_exit():
    import numpy as np
    import pandas as pd
    from backend.signal import simulate_trades_per_trade

    rows = pd.DataFrame({
        "high": [100.0, 101.0, 101.0],
        "low": [100.0, 99.0, 99.0],
        "close": [100.0, 100.5, 100.8],
        "atr_14": [2.0, 2.0, 2.0],
    })
    details = simulate_trades_per_trade(np.array([0.9, 0.5, 0.5]), rows,
                                        thr=0.6, horizon=2)
    assert len(details) == 1
    assert details[0]["exit_reason"] == "TIME_EXIT"


def test_perpetual_backtest_includes_settlement_in_entry_candle_after_entry():
    import numpy as np
    import pandas as pd
    from backend import signal

    rows = pd.DataFrame({
        "t": [1000, 2000],
        "high": [100.0, 104.0], "low": [100.0, 99.0],
        "close": [100.0, 103.0], "atr_14": [2.0, 2.0],
        # Settlement is stored on the entry candle but occurs after entry.
        "funding_rate": [0.001, np.nan],
        "funding_mark_price": [101.0, np.nan],
        "funding_settlement_ts": [1500.0, np.nan],
    })
    perp = signal.simulate_trades(np.array([0.9, 0.5]), rows, thr=0.6,
                                  horizon=1, market="perp")
    spot = signal.simulate_trades(np.array([0.9, 0.5]), rows, thr=0.6,
                                  horizon=1, market="spot")
    assert perp["n_trades"] == 1
    assert perp["expectancy_pct"] < spot["expectancy_pct"]


@pytest.mark.parametrize("bad_fields", [
    {"funding_rate": [0.001, float("nan")], "funding_mark_price": [float("nan"), float("nan")],
     "funding_settlement_ts": [1500.0, float("nan")]},
    {"funding_rate": [0.001, 0.002], "funding_mark_price": [101.0, 102.0],
     "funding_settlement_ts": [1500.0, 1500.0]},
    {"funding_rate": [0.001, 0.002], "funding_mark_price": [101.0, 102.0],
     "funding_settlement_ts": [1600.0, 1500.0]},
])
def test_perpetual_backtest_rejects_incomplete_duplicate_or_unordered_funding(bad_fields):
    import numpy as np
    import pandas as pd
    from backend import signal

    rows = pd.DataFrame({
        "t": [1000.0, 2000.0],
        "high": [100.0, 104.0], "low": [100.0, 99.0],
        "close": [100.0, 103.0], "atr_14": [2.0, 2.0],
        **bad_fields,
    })
    with pytest.raises(ValueError, match="funding"):
        signal.simulate_trades(np.array([0.9, 0.5]), rows, thr=0.6,
                               horizon=1, market="perp")

@pytest.mark.parametrize("side,first_price,next_price,expected_peak,expected_stop", [
    ("LONG", 102.0, 101.5, 102.0, 100.98),
    ("SHORT", 98.0, 98.5, 98.0, 98.98),
])
def test_paper_trailing_peak_is_persisted_across_manager_restarts(
        tmp_path, monkeypatch, side, first_price, next_price, expected_peak, expected_stop):
    from backend import paper_live

    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(tmp_path / "trailing.sqlite3"))
    paper_live.init_db(backfill_learning=False)
    with paper_live._connect() as conn:
        cur = conn.execute("""INSERT INTO paper_live_trades(
            opened_at,symbol,market,exchange,requested_exchange,side,quantity,notional,
            reference_entry,entry_fill,entry_fee,execution_costs_json,stop_price,target_price,
            status,settings_json,timeframe)
            VALUES(1,'TEST/USDT','perp','test','test',?,1,100,100,100,0,'{}',95,110,
                   'OPEN','{}','1h')""", (side,))
        trade_id = int(cur.lastrowid)
        if side == "SHORT":
            conn.execute("UPDATE paper_live_trades SET stop_price=105 WHERE id=?", (trade_id,))

    first = paper_live.update_trailing_state(trade_id, first_price,
                                              trigger_pct=1.5, distance_pct=1.0)
    assert first["trailing_active"] is True
    assert first["stop_updated"] is True
    assert first["peak_price"] == pytest.approx(expected_peak)
    assert first["new_stop"] == pytest.approx(expected_stop)

    # Simulate a fresh process: no in-memory peak metadata is available.
    second = paper_live.update_trailing_state(trade_id, next_price,
                                               trigger_pct=1.5, distance_pct=1.0)
    assert second["peak_price"] == pytest.approx(expected_peak)
    assert second["new_stop"] == pytest.approx(expected_stop)
    assert second["stop_updated"] is False
