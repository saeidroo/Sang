import pandas as pd
from backend import historical
from backend.data import fetch_candles


def test_sqlite_history_roundtrip_and_training_reader(tmp_path, monkeypatch):
    monkeypatch.setattr(historical, 'DB_PATH', tmp_path / 'history.sqlite3')
    rows=[]
    start=(1_700_000_000_000 // 3_600_000) * 3_600_000
    for i in range(320):
        p=100+i*0.1
        rows.append((start+i*3_600_000,p,p+1,p-1,p+0.2,10+i))
    inserted=historical._store_rows('BTCUSDT','1h',rows)
    assert inserted == 320
    assert historical.count_candles('BTCUSDT','1h') == 320
    assert historical.history_bounds('BTCUSDT','1h')['count'] == 320
    frame=historical.load_history('BTCUSDT','1h',250)
    assert len(frame)==250
    assert frame.t.is_monotonic_increasing
    # Exercise the same provider path used by the trainer.
    import backend.data as data
    monkeypatch.setattr(data, '_drop_unclosed', lambda df, tf: df)
    monkeypatch.setattr(data, '_save_cache', lambda *a, **k: None)
    result=fetch_candles('BTCUSDT','1h',limit=220,source='history')
    assert len(result)==220
    assert result.attrs['source']=='history'


def test_backfill_paginates_and_persists_without_network(tmp_path, monkeypatch):
    monkeypatch.setattr(historical, 'DB_PATH', tmp_path / 'history.sqlite3')
    class FakeResponse:
        status_code=200
        def raise_for_status(self): pass
        def json(self):
            return [[1_700_000_000_000,'100','102','99','101','50'],
                    [1_700_003_600_000,'101','103','100','102','60']]
    class FakeSession:
        headers={}
        def get(self,*args,**kwargs): return FakeResponse()
    monkeypatch.setattr(historical.requests,'Session',FakeSession)
    monkeypatch.setattr(historical.time,'sleep',lambda *_:None)
    result=historical.backfill_symbol('BTCUSDT','1h',start='2023-11-14T00:00:00+00:00')
    assert result['inserted']==2
    assert result['total_stored']==2
    assert historical.load_history('BTCUSDT','1h',10).close.tolist()==[101.0,102.0]


def test_all_market_expansion_includes_discovered_crypto_and_metals(monkeypatch):
    monkeypatch.setattr(historical, 'discover_binance_usdt_symbols', lambda: ['BTCUSDT','ETHUSDT','SOLUSDT'])
    symbols=historical.expand_market_symbols(['ALL_USDT'])
    assert symbols == ['BTCUSDT','ETHUSDT','SOLUSDT','GOLD','SILVER']


def test_metal_history_is_saved_separately(tmp_path, monkeypatch):
    monkeypatch.setattr(historical, 'DB_PATH', tmp_path / 'history.sqlite3')
    frame=pd.DataFrame([
        ((1_700_000_000_000 // 3_600_000) * 3_600_000, 2000, 2010, 1990, 2005, 100),
        ((1_700_000_000_000 // 3_600_000) * 3_600_000 + 3_600_000, 2005, 2020, 2000, 2015, 120),
    ], columns=['t','open','high','low','close','volume'])
    monkeypatch.setattr(historical, '_fetch_yahoo_metal', lambda symbol, tf, start: frame)
    result=historical.backfill_symbol('GOLD','1h')
    assert result['provider'].startswith('Yahoo')
    assert historical.count_candles('GOLD','1h') == 2
    assert historical.load_history('GOLD','1h',10).close.tolist() == [2005,2015]


def test_metal_training_reads_local_history(tmp_path, monkeypatch):
    monkeypatch.setattr(historical, 'DB_PATH', tmp_path / 'history.sqlite3')
    start=(1_700_000_000_000 // 3_600_000) * 3_600_000
    rows=[]
    for i in range(230):
        price=1900+i*0.2
        rows.append((start+i*3_600_000,price,price+1,price-1,price+0.5,100))
    historical._store_rows('GOLD','1h',rows)
    import backend.data as data
    monkeypatch.setattr(data, '_drop_unclosed', lambda df, tf: df)
    monkeypatch.setattr(data, '_save_cache', lambda *a, **k: None)
    result=fetch_candles('GOLD','1h',limit=220,source='history')
    assert len(result)==220
    assert result.attrs['source']=='history'
