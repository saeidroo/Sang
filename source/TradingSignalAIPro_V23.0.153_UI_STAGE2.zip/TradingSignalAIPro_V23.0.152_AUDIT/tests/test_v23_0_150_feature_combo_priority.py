from backend.scout import _apply_feature_combo_priority


def _cohort(direction='up', rate=.8, samples=60):
    return {
        'key': f'{direction}|UP|exchange_taker|strong|strong|leader',
        'direction': direction, 'market_regime': 'UP', 'flow_grade': 'exchange_taker',
        'volume_band': 'strong', 'buy_pressure_band': 'strong',
        'relative_strength_band': 'leader',
        'horizons': {'24h': {'samples': samples, 'success_rate': rate}},
    }


def _item(direction='up'):
    return {
        'market_regime': 'UP', 'flow_grade': 'exchange_taker',
        'volume_acceleration_ratio': 1.8,
        'buy_pressure_ratio': .70, 'buy_pressure_change': .08,
        'sell_pressure_ratio': .70, 'sell_pressure_change': .08,
        'relative_strength_score': 80,
        'directional_priority_score': 50, 'score': 70,
    }


def test_joint_successful_pump_combo_adds_small_priority():
    item = _item()
    out = _apply_feature_combo_priority([item], 'up', {'feature_combo_learning': {'cohorts': [_cohort()]}})[0]
    assert out['feature_combo_adjustment'] > 0
    assert out['directional_priority_score'] > 50
    assert out['feature_combo_samples'] == 60


def test_joint_failed_dump_combo_reduces_priority_and_is_directional():
    item = _item('down')
    out = _apply_feature_combo_priority([item], 'down', {'feature_combo_learning': {'cohorts': [_cohort('down', .2)]}})[0]
    assert out['feature_combo_adjustment'] < 0
    assert out['directional_priority_score'] < 50
    wrong = _apply_feature_combo_priority([_item()], 'down', {'feature_combo_learning': {'cohorts': [_cohort('up')]}})[0]
    assert wrong['feature_combo_adjustment'] == 0


def test_insufficient_samples_and_missing_cohort_are_neutral():
    item = _item()
    out = _apply_feature_combo_priority([item], 'up', {'feature_combo_learning': {'cohorts': [_cohort(samples=29)]}})[0]
    assert out['feature_combo_adjustment'] == 0
    assert out['directional_priority_score'] == 50


def test_combo_adjustment_is_bounded():
    item = _item()
    out = _apply_feature_combo_priority([item], 'up', {'feature_combo_learning': {'cohorts': [_cohort(rate=1.0, samples=10000)]}})[0]
    assert out['feature_combo_adjustment'] <= 1.0
