import pytest

from backend import exchange_listings as x


def test_bit24_is_in_iranian_exchange_tooltip_catalog():
    assert ("bit24", "بیت ۲۴", "https://bit24.cash") in x.IRANIAN
    provider = next(p for p in x.PROVIDERS if p[0] == "bit24")
    assert provider[1] == "بیت ۲۴"


def test_bit24_without_api_key_is_unknown_not_not_listed(monkeypatch):
    monkeypatch.delenv("BIT24_API_KEY", raising=False)
    with pytest.raises(RuntimeError, match="وضعیت نامشخص"):
        x.fetch_bit24_markets()
