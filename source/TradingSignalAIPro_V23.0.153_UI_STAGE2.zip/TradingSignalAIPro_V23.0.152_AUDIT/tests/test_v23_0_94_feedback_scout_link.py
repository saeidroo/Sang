from backend.market_brain import _feedback_validation


def test_feedback_validation_marks_small_samples_unreliable():
    result = _feedback_validation({'horizons': {'4h': {
        'directional_calls': 8, 'directional_correct': 7,
        'directional_accuracy_pct': 87.5, 'reliability': 'insufficient_samples'
    }}})
    assert result['4h']['accuracy_pct'] == 87.5
    assert result['4h']['reliability'] == 'insufficient_samples'


def test_feedback_validation_distinguishes_supportive_and_weak_track_record():
    result = _feedback_validation({'horizons': {
        '1h': {'directional_calls': 40, 'directional_correct': 25,
               'directional_accuracy_pct': 62.5, 'reliability': 'developing'},
        '4h': {'directional_calls': 50, 'directional_correct': 20,
               'directional_accuracy_pct': 40.0, 'reliability': 'sample_established'},
        '24h': {'directional_calls': 30, 'directional_correct': 15,
                'directional_accuracy_pct': 50.0, 'reliability': 'developing'},
    }})
    assert result['1h']['reliability'] == 'historically_supportive'
    assert result['4h']['reliability'] == 'historically_weak'
    assert result['24h']['reliability'] == 'near_coin_flip'


def test_feedback_validation_handles_missing_summary():
    result = _feedback_validation(None)
    assert set(result) == {'1h', '4h', '24h'}
    assert all(v['accuracy_pct'] is None for v in result.values())
