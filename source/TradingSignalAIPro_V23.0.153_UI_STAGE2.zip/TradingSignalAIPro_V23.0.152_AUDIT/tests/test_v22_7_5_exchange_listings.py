from backend import exchange_listings as x


def test_nobitex_market_parser_keeps_active_pairs_only():
    rows = x.parse_nobitex({"stats": {
        "btc-rls": {"isClosed": False}, "btc-usdt": {"isClosed": False},
        "old-rls": {"isClosed": True},
    }})
    assert {(r['base'], r['quote']) for r in rows} == {('BTC', 'RLS'), ('BTC', 'USDT')}


def test_wallex_parser_reads_result_symbols():
    rows = x.parse_wallex({"result": {"symbols": {
        "BTCUSDT": {"baseAsset": "BTC", "quoteAsset": "USDT", "symbol": "BTCUSDT"},
        "ETHUSDT": {"baseAsset": "ETH", "quoteAsset": "USDT", "symbol": "ETHUSDT"},
    }}})
    assert [(r['base'], r['quote']) for r in rows] == [('BTC', 'USDT'), ('ETH', 'USDT')]


def test_bitpin_parser_normalizes_underscore_symbols():
    rows = x.parse_bitpin([{"symbol": "ICP_IRT"}, {"symbol": "ICP_USDT"}])
    assert {(r['base'], r['quote']) for r in rows} == {('ICP', 'IRT'), ('ICP', 'USDT')}


def test_ramzinex_parser_skips_delisted_pairs():
    rows = x.parse_ramzinex({"data": [
        {"base_currency_symbol": {"en": "SOL"}, "quote_currency_symbol": {"en": "irr"}, "pair_id": 1},
        {"base_currency_symbol": {"en": "OLD"}, "quote_currency_symbol": {"en": "usdt"}, "is_delist": True},
    ]})
    assert len(rows) == 1 and rows[0]['base'] == 'SOL'


def test_ompfinex_only_listed_markets_are_returned():
    rows = x.parse_ompfinex({"data": [
        {"baseCurrencyId": "ARB", "quoteCurrencyId": "USDT", "status": "LISTED"},
        {"baseCurrencyId": "OLD", "quoteCurrencyId": "IRR", "status": "DELISTED"},
    ]})
    assert len(rows) == 1 and rows[0]['base'] == 'ARB'


def test_exchange_failure_is_not_equated_with_not_listed(monkeypatch):
    snap = {
        "checked_at": 100, "cache_ttl_seconds": 300,
        "markets": {"wallex": [{"base": "BTC", "quote": "USDT", "symbol": "BTCUSDT", "quote_label": "تتر"}]},
        "providers": {
            "nobitex": {"ok": False, "name": "نوبیتکس", "site": "https://nobitex.ir"},
            "wallex": {"ok": True, "name": "والکس", "site": "https://wallex.ir"},
        },
    }
    monkeypatch.setattr(x, '_snapshot', lambda force=False: snap)
    result = x.coin_listings('btc')
    statuses = {item['id']: item['status'] for item in result['groups']['iranian']}
    assert statuses['nobitex'] == 'unknown'
    assert statuses['wallex'] == 'listed'
    assert statuses['bitpin'] == 'unknown'
