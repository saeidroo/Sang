import json, sqlite3
import pytest
from backend.paper_live_backup import create_backup, verify_backup, restore_to_isolated_path


def _db(path):
    with sqlite3.connect(path) as c:
        c.execute('CREATE TABLE paper_live_trades(id INTEGER PRIMARY KEY, symbol TEXT)')
        c.execute('INSERT INTO paper_live_trades(symbol) VALUES (?)', ('BTCUSDT',))


def test_backup_verify_and_isolated_restore(tmp_path):
    source = tmp_path / 'live.sqlite3'; _db(source)
    backup = tmp_path / 'backup'
    result = create_backup(source, backup)
    assert result['ok']
    checked = verify_backup(backup)
    assert checked['valid']
    restored = tmp_path / 'restored.sqlite3'
    rr = restore_to_isolated_path(backup, restored)
    assert rr['isolated'] and restored.is_file()
    with sqlite3.connect(restored) as c:
        assert c.execute('SELECT symbol FROM paper_live_trades').fetchone()[0] == 'BTCUSDT'
    with sqlite3.connect(source) as c:
        c.execute("INSERT INTO paper_live_trades(symbol) VALUES ('ETHUSDT')")
    with sqlite3.connect(restored) as c:
        assert c.execute('SELECT COUNT(*) FROM paper_live_trades').fetchone()[0] == 1


def test_backup_detects_tampering(tmp_path):
    source = tmp_path / 'live.sqlite3'; _db(source)
    backup = tmp_path / 'backup'; create_backup(source, backup)
    with (backup / 'paper_live.sqlite3').open('ab') as f:
        f.write(b'tamper')
    result = verify_backup(backup)
    assert not result['valid']
    assert 'database_hash_or_size_mismatch' in result['errors']


def test_restore_refuses_existing_destination(tmp_path):
    source = tmp_path / 'live.sqlite3'; _db(source)
    backup = tmp_path / 'backup'; create_backup(source, backup)
    dest = tmp_path / 'restored.sqlite3'; dest.write_text('keep')
    with pytest.raises(FileExistsError):
        restore_to_isolated_path(backup, dest)
    assert dest.read_text() == 'keep'
