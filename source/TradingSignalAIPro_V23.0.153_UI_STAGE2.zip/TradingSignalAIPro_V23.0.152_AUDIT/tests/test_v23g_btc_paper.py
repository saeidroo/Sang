import json
import numpy as np
import pandas as pd
import pytest
from backend.btc_paper import run_btc_4h_paper_simulation


def candles(n=30):
    x = np.arange(n, dtype=float)
    op = 100 + x
    cl = op + 0.5
    return pd.DataFrame({'open': op, 'high': cl + 1, 'low': op - 1, 'close': cl})


def test_paper_entries_next_open_exit_fixed_horizon_and_equity(tmp_path):
    out = run_btc_4h_paper_simulation(candles(), [{'signal_pos': 1, 'direction': 1}],
        initial_cash=1000, position_fraction=.5, horizon_bars=2, fee_bps=0,
        slippage_bps=0, spread_bps=0, ledger_path=tmp_path/'ledger.json')
    trade = out['trades'][0]
    assert trade['entry_pos'] == 2 and trade['exit_pos'] == 4
    assert trade['entry_reference'] == 102 and trade['exit_reference'] == 104
    assert out['final_equity'] > 1000 and out['live_orders_sent'] is False
    assert json.loads((tmp_path/'ledger.json').read_text())['ledger_hash'] == out['ledger_hash']


def test_duplicate_signal_ids_are_idempotent_and_overlaps_skipped():
    sig = [{'signal_pos': 1, 'direction': 1, 'signal_id': 'a'},
           {'signal_pos': 2, 'direction': -1, 'signal_id': 'b'},
           {'signal_pos': 5, 'direction': 1, 'signal_id': 'a'}]
    out = run_btc_4h_paper_simulation(candles(), sig, horizon_bars=3,
                                      fee_bps=0, slippage_bps=0, spread_bps=0)
    assert out['trade_count'] == 1
    assert out['skipped']['overlap'] == 1
    assert out['skipped']['duplicate_id'] == 1


def test_costs_reduce_pnl_and_no_future_signal_is_skipped():
    sig = [{'signal_pos': 1, 'direction': 1}, {'signal_pos': 28, 'direction': -1}]
    free = run_btc_4h_paper_simulation(candles(), sig, horizon_bars=2,
        fee_bps=0, slippage_bps=0, spread_bps=0)
    costly = run_btc_4h_paper_simulation(candles(), sig, horizon_bars=2,
        fee_bps=10, slippage_bps=5, spread_bps=4)
    assert costly['net_pnl'] < free['net_pnl']
    assert costly['skipped']['no_future'] == 1
    assert all(e['type'].startswith('PAPER_') for e in costly['events'])


def test_invalid_execution_inputs_rejected():
    with pytest.raises(ValueError):
        run_btc_4h_paper_simulation(candles(), [{'signal_pos': 1, 'direction': 2}])
    with pytest.raises(ValueError):
        run_btc_4h_paper_simulation(candles(), [{'signal_pos': 1, 'direction': 1}], fee_bps=-1)
    with pytest.raises(ValueError):
        run_btc_4h_paper_simulation(candles(), [{'signal_pos': 1, 'direction': 1},
                                                {'signal_pos': 1, 'direction': -1}])


def test_stop_loss_and_take_profit_barriers_are_applied_conservatively():
    c = candles(20)
    # Long entry at 102; next bar's low crosses the 1% stop.
    c.loc[3, 'low'] = 100.0
    out = run_btc_4h_paper_simulation(c, [{'signal_pos': 1, 'direction': 1}],
        horizon_bars=5, fee_bps=0, slippage_bps=0, spread_bps=0,
        stop_loss_pct=.01, take_profit_pct=.05)
    assert out['trades'][0]['exit_reason'] == 'STOP_LOSS'
    assert out['trades'][0]['exit_pos'] == 3


def test_emergency_stop_prevents_all_entries():
    out = run_btc_4h_paper_simulation(candles(), [{'signal_pos': 1, 'direction': 1}], emergency_stop=True)
    assert out['trade_count'] == 0
    assert out['skipped']['emergency_stop'] == 1


def test_daily_loss_and_drawdown_gates_halt_future_entries():
    c = candles(40)
    # Force first long to lose heavily by the horizon exit.
    c.loc[7, 'open'] = 50.0
    sig = [{'signal_pos': 1, 'direction': 1}, {'signal_pos': 10, 'direction': 1}]
    out = run_btc_4h_paper_simulation(c, sig, horizon_bars=5, position_fraction=1,
        fee_bps=0, slippage_bps=0, spread_bps=0, max_daily_loss_pct=.01,
        max_drawdown_pct=.01, bars_per_day=100)
    assert out['trade_count'] == 1
    assert out['risk_controls']['global_halt'] is True
    assert out['skipped']['drawdown_limit'] == 1


def test_risk_configuration_validation_and_cooldown():
    with pytest.raises(ValueError):
        run_btc_4h_paper_simulation(candles(), [], stop_loss_pct=1.0)
    out = run_btc_4h_paper_simulation(candles(),
        [{'signal_pos': 1, 'direction': 1}, {'signal_pos': 10, 'direction': 1}],
        horizon_bars=2, min_bars_between_entries=20, fee_bps=0, slippage_bps=0, spread_bps=0)
    assert out['trade_count'] == 1
    assert out['skipped']['cooldown'] == 1
