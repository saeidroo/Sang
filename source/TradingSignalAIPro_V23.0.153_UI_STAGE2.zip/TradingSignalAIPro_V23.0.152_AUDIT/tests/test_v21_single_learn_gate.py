"""V21 part 3: single learning is reserved for NEW coins (not in the multi-hour list)."""
import json
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend import longrun  # noqa: E402
from backend import api  # noqa: E402


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(tmp_path / 'models'))
    clean = dict(longrun._STATE)          # other test files leave config/started_at behind
    clean.update(running=False, started_at=None, config=None, jobs=[])
    monkeypatch.setattr(longrun, '_STATE', clean)
    api.app.config['TESTING'] = True
    with api.app.test_client() as c:
        yield c


def _set_run(monkeypatch, symbols, running=False, age_sec=60):
    st = dict(longrun._STATE)
    st.update(running=running, started_at=time.time() - age_sec,
              config={'symbols': symbols, 'timeframes': ['1h']})
    monkeypatch.setattr(longrun, '_STATE', st)


def test_multihour_symbols_empty_by_default(client):
    assert longrun.multihour_symbols() == set()


def test_multihour_symbols_from_running_or_recent_run(client, monkeypatch):
    _set_run(monkeypatch, ['BTCUSDT', 'ETHUSDTPERP'], running=True)
    assert longrun.multihour_symbols() == {'BTCUSDT', 'ETHUSDTPERP'}
    _set_run(monkeypatch, ['SOLUSDT'], running=False, age_sec=3600)
    assert longrun.multihour_symbols() == {'SOLUSDT'}


def test_old_run_no_longer_owns_symbols(client, monkeypatch):
    _set_run(monkeypatch, ['BTCUSDT'], running=False,
             age_sec=(longrun.RESUME_LOOKBACK_HOURS + 1) * 3600)
    assert longrun.multihour_symbols() == set()


def test_eligibility_endpoint(client, monkeypatch):
    _set_run(monkeypatch, ['BTCUSDT'])
    d = client.get('/api/learn/eligibility?symbol=BTCUSDT').get_json()
    assert d['allowed'] is False and d['in_multihour'] is True
    d = client.get('/api/learn/eligibility?symbol=PEPEUSDT').get_json()
    assert d['allowed'] is True and d['in_multihour'] is False
    assert client.get('/api/learn/eligibility?symbol=bad!').status_code == 400


def test_learn_rejects_multihour_symbol(client, monkeypatch):
    _set_run(monkeypatch, ['BTCUSDT'])
    resp = client.post('/api/learn', json={'symbol': 'BTCUSDT', 'timeframe': '1h', 'limit': 3000})
    assert resp.status_code == 409
    body = resp.get_json()
    assert body['in_multihour'] is True and 'چندساعته' in body['error']


def test_learn_allows_new_coin(client, monkeypatch):
    _set_run(monkeypatch, ['BTCUSDT'])
    started = {}

    class FakeSession:
        is_running = False

        def run(self, **kw):
            started.update(kw)

        def log(self, *_):
            pass
    monkeypatch.setattr(api, 'get_session', lambda: FakeSession())
    resp = client.post('/api/learn', json={'symbol': 'PEPEUSDT', 'timeframe': '1h', 'limit': 3000})
    assert resp.status_code == 200 and resp.get_json()['started'] is True
    for _ in range(50):
        if started:
            break
        time.sleep(0.02)
    assert started.get('symbol') == 'PEPEUSDT'


def test_frontend_gate_wiring():
    js = (ROOT / 'frontend' / 'app.js').read_text(encoding='utf-8')
    html = (ROOT / 'frontend' / 'index.html').read_text(encoding='utf-8')
    assert 'refreshLearnGate' in js and '/api/learn/eligibility' in js
    assert 'learnBlocked' in js and 'addNewCoinForLearning' in js
    assert 'id="learnNewSymbol"' in html and 'id="learnGateNote"' in html
    # every re-enable of the button must respect the gate
    assert "$('learn').disabled = false;" not in js
