"""V20 tests: new data sources (HTX, Bitfinex, CryptoCompare, BingX, Stooq),
adaptive source ordering, and fallback-chain reporting."""
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend import data as D  # noqa: E402


@pytest.fixture(autouse=True)
def _isolated_cache(tmp_path, monkeypatch):
    """V21: candle cache must not leak between tests (it made fallback tests order-dependent)."""
    monkeypatch.setattr(D, '_cache_dir', lambda: tmp_path)
    D.reset_source_health()
    yield
    D.reset_source_health()


class FakeResponse:
    def __init__(self, payload):
        self._payload = payload
        self.text = payload if isinstance(payload, str) else ''

    def raise_for_status(self):
        pass


# ------------------------------------------------------------------ HTX
def test_htx_parses_klines(monkeypatch):
    now = int(pd.Timestamp('2024-06-01', tz='UTC').timestamp())
    payload = {'status': 'ok', 'data': [
        {'id': now - 3600 * i, 'open': 100 + i, 'high': 105 + i, 'low': 95 + i,
         'close': 102 + i, 'amount': 10 + i, 'vol': 1000 + i}
        for i in range(300)]}
    monkeypatch.setattr(D, '_get', lambda *a, **k: payload)
    df = D.fetch_htx('BTCUSDT', '1h', limit=250)
    assert len(df) >= 210
    assert list(df.columns) == ['t', 'open', 'high', 'low', 'close', 'volume']
    assert (df['close'] > 0).all()
    assert df['t'].is_monotonic_increasing


def test_htx_raises_on_bad_status(monkeypatch):
    monkeypatch.setattr(D, '_get', lambda *a, **k: {'status': 'error', 'err-msg': 'invalid symbol'})
    with pytest.raises(RuntimeError, match='invalid symbol'):
        D.fetch_htx('BADUSDT', '1h', limit=250)


# ------------------------------------------------------------- Bitfinex
def test_bitfinex_parses_rows(monkeypatch):
    now = int(pd.Timestamp('2024-06-01', tz='UTC').timestamp() * 1000)
    payload = [[now - 3600_000 * i, 100 + i, 102 + i, 105 + i, 95 + i, 12.5 + i]
               for i in range(300)]
    monkeypatch.setattr(D, '_get', lambda *a, **k: payload)
    df = D.fetch_bitfinex('BTCUSDT', '1h', limit=250)
    assert len(df) >= 210
    assert (df['high'] >= df['low']).all()
    assert df['t'].is_monotonic_increasing


# -------------------------------------------------------- CryptoCompare
def test_cryptocompare_parses_histohour(monkeypatch):
    now = int(pd.Timestamp('2024-06-01', tz='UTC').timestamp())
    payload = {'Response': 'Success', 'Data': {'Data': [
        {'time': now - 3600 * i, 'open': 50 + i, 'high': 52 + i, 'low': 48 + i,
         'close': 51 + i, 'volumefrom': 100 + i, 'volumeto': 5000 + i}
        for i in range(300)]}}
    monkeypatch.setattr(D, '_get', lambda *a, **k: payload)
    df = D.fetch_cryptocompare('BTCUSDT', '1h', limit=250)
    assert len(df) >= 210
    assert df['t'].is_monotonic_increasing


def test_cryptocompare_raises_on_error(monkeypatch):
    monkeypatch.setattr(D, '_get', lambda *a, **k: {'Response': 'Error', 'Message': 'rate limited'})
    with pytest.raises(RuntimeError, match='rate limited'):
        D.fetch_cryptocompare('BTCUSDT', '1h', limit=250)


# ----------------------------------------------------------------- BingX
def test_bingx_parses_list_rows(monkeypatch):
    now = int(pd.Timestamp('2024-06-01', tz='UTC').timestamp() * 1000)
    payload = {'code': 0, 'msg': '', 'data': {'s': 'BTC-USDT', 'list': [
        [str(now - 3600_000 * i), '100', '105', '95', '102', '12'] for i in range(300)]}}
    monkeypatch.setattr(D, '_get', lambda *a, **k: payload)
    df = D.fetch_bingx('BTCUSDT', '1h', limit=250)
    assert len(df) >= 210
    assert df['t'].is_monotonic_increasing


def test_bingx_accepts_dict_rows(monkeypatch):
    now = int(pd.Timestamp('2024-06-01', tz='UTC').timestamp() * 1000)
    payload = {'code': 0, 'data': {'list': [
        {'time': now - 3600_000 * i, 'open': '1', 'high': '2', 'low': '0.5',
         'close': '1.5', 'volume': '3'} for i in range(300)]}}
    monkeypatch.setattr(D, '_get', lambda *a, **k: payload)
    df = D.fetch_bingx('ETHUSDT', '1h', limit=250)
    assert len(df) >= 210


def test_bingx_raises_on_error_code(monkeypatch):
    monkeypatch.setattr(D, '_get', lambda *a, **k: {'code': 1001, 'msg': 'bad symbol'})
    with pytest.raises(RuntimeError, match='bad symbol'):
        D.fetch_bingx('BAD-USDT', '1h', limit=250)


# ----------------------------------------------------------------- Stooq
def test_stooq_parses_daily_csv(monkeypatch):
    csv_text = ('Date,Open,High,Low,Close,Volume\n'
                '2024-05-30,2300.5,2310.0,2290.2,2305.4,12345\n'
                '2024-05-31,2305.4,2320.1,2300.0,2315.7,15000\n')
    monkeypatch.setattr(D, 'SESSION', type('S', (), {'get': staticmethod(
        lambda url, timeout=None: FakeResponse(csv_text))}))
    df = D.fetch_stooq('XAUUSD', '1d', limit=2)
    assert len(df) == 2
    assert df['close'].iloc[-1] == pytest.approx(2315.7)


def test_stooq_rejects_intraday():
    with pytest.raises(RuntimeError, match='1d'):
        D.fetch_stooq('BTCUSDT', '1h', limit=250)


def test_stooq_rejects_html(monkeypatch):
    monkeypatch.setattr(D, 'SESSION', type('S', (), {'get': staticmethod(
        lambda url, timeout=None: FakeResponse('<html>blocked</html>'))}))
    with pytest.raises(RuntimeError, match='Stooq'):
        D.fetch_stooq('XAUUSD', '1d', limit=10)


# ------------------------------------------------- chain / adaptive order
@pytest.fixture(autouse=True)
def clean_state(monkeypatch, tmp_path):
    monkeypatch.setenv('HOME', str(tmp_path))
    D._SOURCE_DOWN.clear()
    D._SOURCE_SUCCESS_TS.clear()
    yield
    D._SOURCE_DOWN.clear()
    D._SOURCE_SUCCESS_TS.clear()


def _fake_candles(n=300):
    idx = pd.date_range('2024-01-01', periods=n, freq='1h')
    return pd.DataFrame({'t': (idx.astype('int64') // 10**6),
                         'open': 100.0, 'high': 101.0, 'low': 99.0,
                         'close': 100.5, 'volume': 10.0})


def test_fallback_chain_recorded(monkeypatch):
    """First source fails, second succeeds -> chain shows both steps."""
    calls = []

    def fake_src_binance(symbol, tf, limit):
        calls.append('binance')
        raise RuntimeError('binance blocked')

    def fake_src_bybit(symbol, tf, limit):
        calls.append('bybit')
        return _fake_candles()

    monkeypatch.setattr(D, 'SOURCE_FUNCS',
                        {'binance': fake_src_binance, 'bybit': fake_src_bybit})
    monkeypatch.setattr(D, 'CRYPTO_AUTO_ORDER', ['binance', 'bybit'])
    df = D.fetch_candles('BTCUSDT', '1h', limit=250, source='auto')
    assert df.attrs['source'] == 'bybit'
    chain = df.attrs['fallback_chain']
    assert [c['source'] for c in chain] == ['binance']
    assert 'blocked' in chain[0]['error']
    assert calls == ['binance', 'bybit']


def test_adaptive_order_success_first(monkeypatch):
    """A recently successful source leads the chain on the next fetch."""
    order = ['binance', 'bybit', 'okx']
    D._SOURCE_SUCCESS_TS['okx'] = 999.0
    D._SOURCE_SUCCESS_TS['bybit'] = 555.0
    out = D._adaptive_sort(order)
    assert out[0] == 'okx'
    assert out.index('bybit') < out.index('binance')


def test_stooq_skipped_for_intraday(monkeypatch):
    """stooq must never be tried for intraday timeframes."""
    tried = []

    def fake_stooq(symbol, tf, limit):
        tried.append(tf)
        return _fake_candles()

    monkeypatch.setattr(D, 'SOURCE_FUNCS', {'stooq': fake_stooq})
    monkeypatch.setattr(D, 'CRYPTO_AUTO_ORDER', ['stooq'])
    with pytest.raises(RuntimeError):
        D.fetch_candles('BTCUSDT', '1h', limit=250, source='auto')
    assert tried == []            # stooq was filtered out, never called


def test_success_marks_source_healthy(monkeypatch):
    def fake_src(symbol, tf, limit):
        return _fake_candles()
    monkeypatch.setattr(D, 'SOURCE_FUNCS', {'binance': fake_src})
    monkeypatch.setattr(D, 'CRYPTO_AUTO_ORDER', ['binance'])
    df = D.fetch_candles('BTCUSDT', '1h', limit=250, source='auto')
    assert df.attrs['source'] == 'binance'
    assert 'binance' in D._SOURCE_SUCCESS_TS


def test_all_sources_covered_in_catalog():
    cat = {c['id'] for c in D.source_catalog()}
    for src in ('htx', 'bitfinex', 'cryptocompare', 'bingx', 'stooq'):
        assert src in cat
        assert D.SOURCE_LABELS[src]


def test_bingx_sends_plain_intervals(monkeypatch):
    """BingX expects 1h-style intervals, not PT1H (verified live in V20)."""
    seen = {}

    def fake_get(url, timeout, params=None, headers=None):
        seen['params'] = params or {}
        now = int(pd.Timestamp('2024-06-01', tz='UTC').timestamp() * 1000)
        return {'code': 0, 'data': {'list': [
            [str(now - 3600_000 * i), '1', '2', '0.5', '1.5', '3']
            for i in range(300)]}}

    monkeypatch.setattr(D, '_get', fake_get)
    D.fetch_bingx('BTCUSDT', '1h', limit=250)
    assert seen['params']['interval'] == '1h'
    assert seen['params']['symbol'] == 'BTC-USDT'


def test_cryptocompare_skipped_without_key(monkeypatch):
    """Free CryptoCompare returns 401 without a key: must not be tried."""
    tried = []

    def fake_cc(symbol, tf, limit):
        tried.append('cc')
        return _fake_candles()

    monkeypatch.delenv('CRYPTOCOMPARE_API_KEY', raising=False)
    monkeypatch.setattr(D, 'SOURCE_FUNCS',
                        {'cryptocompare': fake_cc, 'bybit': lambda *a: _fake_candles()})
    monkeypatch.setattr(D, 'CRYPTO_AUTO_ORDER', ['cryptocompare', 'bybit'])
    df = D.fetch_candles('BTCUSDT', '1h', limit=250, source='auto')
    assert tried == []                 # never attempted without a key
    assert df.attrs['source'] == 'bybit'


def test_source_catalog_marks_key_sources():
    cat = {c['id']: c for c in D.source_catalog()}
    assert cat['coinmarketcap']['requires_key'] is True
    assert cat['cryptocompare']['requires_key'] is True
    assert cat['binance']['requires_key'] is False
    assert cat['bingx']['requires_key'] is False
