import importlib.util
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("windows_preflight", ROOT / "windows_preflight.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_current_runtime_report_has_required_fields():
    report = module.inspect_runtime()
    assert {"python", "version", "supported_version", "bits", "supported_architecture"} <= report.keys()


def test_supported_python_minor_versions_are_explicit():
    assert module.SUPPORTED == {(3, 10), (3, 11), (3, 12)}


def test_runtime_architecture_uses_pointer_width():
    assert module.inspect_runtime()["bits"] == struct.calcsize("P") * 8


def test_installer_checks_runtime_before_pip_install():
    installer = (ROOT / "install.bat").read_text(encoding="utf-8")
    assert installer.index("windows_preflight.py") < installer.index("pip install --upgrade pip")
    assert "pip check" in installer


def test_launcher_checks_virtual_environment_runtime():
    launcher = (ROOT / "run.bat").read_text(encoding="utf-8")
    assert "windows_preflight.py" in launcher
    assert launcher.index("windows_preflight.py") < launcher.index("main.py")


def test_linux_launcher_uses_the_same_supported_python_policy():
    launcher = (ROOT / "run.sh").read_text(encoding="utf-8")
    assert "python3.12 python3.11 python3.10 python3 python" in launcher
    assert "windows_preflight.py" in launcher
