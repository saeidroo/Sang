"""V19.4: stronger-brain indicator pack (choppiness, mass index, HV
percentile, pivot distance, skew/kurtosis, Hurst) + ensemble strengthening."""
import numpy as np
import pandas as pd

from backend import indicators as ind_mod
from backend import trainer
from backend.features import FEATURE_SCHEMA_VERSION, build_features


def _ohlcv(n=500, seed=0, drift=0.0, vol=0.01):
    rng = np.random.default_rng(seed)
    close = pd.Series(100 * np.exp(np.cumsum(rng.normal(drift, vol, n))))
    high = close + rng.uniform(0, 1, n)
    low = close - rng.uniform(0, 1, n)
    openp = close.shift(1).fillna(close)
    volume = pd.Series(rng.uniform(100, 1000, n))
    return pd.DataFrame({'t': range(n), 'open': openp, 'high': high, 'low': low,
                         'close': close, 'volume': volume})


def test_new_indicators_are_bounded_and_causal():
    df = _ohlcv()
    out = ind_mod.all_indicators(df)
    chop = out['choppiness_14'].dropna()
    assert chop.between(0, 100).all()
    hv = out['hv_percentile'].dropna()
    assert hv.between(0, 1).all()
    # pivot_dist at row i must be identical if a LATER row's OHLC changes
    # (it only ever looks at the PRIOR closed bar) — guards against lookahead.
    mutated = df.copy()
    mutated.loc[250:, ['open', 'high', 'low', 'close']] += 50
    a = ind_mod.pivot_point_dist(df['high'], df['low'], df['close'])
    b = ind_mod.pivot_point_dist(mutated['high'], mutated['low'], mutated['close'])
    pd.testing.assert_series_equal(a.iloc[:249], b.iloc[:249])


def test_hurst_distinguishes_trend_from_random_walk():
    trend = _ohlcv(n=400, seed=1, drift=0.003, vol=0.002)['close']
    chop = _ohlcv(n=400, seed=1, drift=0.0, vol=0.01)['close']
    h_trend = ind_mod.hurst_persistence(trend, 100).dropna().mean()
    h_chop = ind_mod.hurst_persistence(chop, 100).dropna().mean()
    assert h_trend > h_chop          # a real trend must score more "persistent"
    assert 0.0 <= h_trend <= 1.0 and 0.0 <= h_chop <= 1.0


def test_build_features_includes_new_columns_with_no_nans():
    df = _ohlcv(n=900, seed=3)
    X_train, y, *_ = build_features(df)
    new_cols = ['choppiness_14', 'mass_index', 'hv_percentile', 'pivot_dist',
               'ret_skew_30', 'ret_kurt_30', 'hurst_100', 'pivot_x_trend']
    for col in new_cols:
        assert col in X_train.columns, col
    assert not X_train[new_cols].isna().any().any()
    assert not np.isinf(X_train[new_cols].to_numpy()).any()


def test_feature_schema_version_bumped_to_force_retrain():
    assert FEATURE_SCHEMA_VERSION >= 8


def test_ensemble_strengthening_knobs():
    assert trainer.FINAL_N_SEEDS >= 3
    assert trainer.TOP_K_FEATURES >= 85
    grid = trainer.make_hp_grid(5, seed=2)
    assert len(grid) == 5
    assert all('neural_net' in g for g in grid)   # 6th ensemble family present
