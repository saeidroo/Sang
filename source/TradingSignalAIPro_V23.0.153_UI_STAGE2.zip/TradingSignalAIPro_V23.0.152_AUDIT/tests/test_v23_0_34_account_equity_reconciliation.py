import pytest


def _fake_quote(paper_live):
    def fake_fetch(exchange, symbol, market):
        return {'symbol': symbol, 'market': market, 'exchange': exchange,
                'exchange_name': paper_live.EXCHANGE_NAMES[exchange], 'price': 101.0,
                'timestamp': '2026-11-19T00:00:00+00:00', 'authenticated': False}
    return fake_fetch


def test_partial_exit_is_realized_once_in_account_equity(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'account.sqlite3'))
    paper_live._CACHE.clear()
    monkeypatch.setattr(paper_live, '_fetch_one', _fake_quote(paper_live))
    opened = paper_live.open_position('BTCUSDT', 'LONG', 'spot', 'binance')
    partial = paper_live.partial_close_position(opened['id'], opened['quantity'] * .25,
                                                idempotency_key='account-partial-1')
    audit_open = paper_live.reconcile_account_equity()
    assert audit_open['open_positions'] == 1
    assert audit_open['equity_complete'] is False
    assert audit_open['open_position_partial_realized_pnl'] == pytest.approx(partial['net_pnl'])
    assert audit_open['realized_pnl_total'] == pytest.approx(partial['net_pnl'])

    paper_live.close_position(opened['id'])
    audit_closed = paper_live.reconcile_account_equity()
    assert audit_closed['open_positions'] == 0
    assert audit_closed['equity_complete'] is True
    # The final closed-trade net PnL includes the partial exit; it is not added twice.
    assert audit_closed['realized_pnl_total'] == pytest.approx(audit_closed['closed_trade_net_pnl'])


def test_account_reconciliation_is_read_only_and_flags_peak_corruption(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'readonly.sqlite3'))
    paper_live._CACHE.clear()
    paper_live.init_db()
    with paper_live._connect() as conn:
        conn.execute("UPDATE paper_live_meta SET value='500' WHERE key='peak_equity'")
    result = paper_live.reconcile_account_equity()
    assert result['valid'] is False
    assert any(x['check'] == 'peak_equity_below_known_equity' for x in result['issues'])
    with paper_live._connect() as conn:
        assert conn.execute("SELECT value FROM paper_live_meta WHERE key='peak_equity'").fetchone()[0] == '500'
