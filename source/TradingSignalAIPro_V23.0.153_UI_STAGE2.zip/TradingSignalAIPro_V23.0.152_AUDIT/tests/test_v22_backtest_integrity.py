import numpy as np
import pandas as pd

from backend.features import build_features, triple_barrier_labels
from backend.trainer import temporal_split, walk_forward_full
from backend.signal import simulate_trades


def _candles(n=1000, seed=19):
    rng = np.random.default_rng(seed)
    close = 100 * np.exp(np.cumsum(rng.normal(0, 0.012, n)))
    open_ = close * (1 + rng.normal(0, 0.002, n))
    high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, 0.01, n)))
    low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, 0.01, n)))
    return pd.DataFrame({
        't': 1_700_000_000_000 + np.arange(n) * 60_000,
        'open': open_, 'high': high, 'low': low, 'close': close,
        'volume': rng.lognormal(8, 0.5, n),
    })


def test_triple_barrier_exposes_actual_end_position_and_timestamp():
    ind = pd.DataFrame({
        't': [100, 200, 300, 400],
        'close': [100., 100., 100., 100.],
        'high': [101., 120., 101., 101.],
        'low': [99., 99., 99., 99.],
        'atr_14': [10., 10., 10., 10.],
    })
    y, ambiguous = triple_barrier_labels(ind)
    assert y.iloc[0] == 1.0 and not ambiguous.iloc[0]
    y2, ambiguous2, end_pos, end_t = triple_barrier_labels(ind, return_details=True)
    assert y2.iloc[0] == 1.0 and not ambiguous2.iloc[0]
    assert end_pos.iloc[0] == 1
    assert end_t.iloc[0] == 200


def test_build_features_preserves_raw_bar_index_after_label_filtering():
    df = _candles(1000)
    X, y, _, _, ind_train, X_full, ind_full, y_raw, _, ambiguous = build_features(df)
    assert len(X) == len(y) == len(ind_train)
    assert X.index.equals(y.index) and X.index.equals(ind_train.index)
    assert X_full.index.equals(ind_full.index)
    assert X_full.index.is_monotonic_increasing
    assert np.all(np.diff(X_full.index.to_numpy()) == 1)
    # A filtered training sample must keep its original raw candle position.
    assert (X.index.to_numpy() >= 210).all()
    meta = X_full.attrs['v22_label_metadata']
    assert meta['label_interval'].startswith('left-closed-entry')
    assert meta['label_end_positions']
    assert len(y_raw) == len(X_full) == len(ind_full)
    assert int(ambiguous.sum()) >= 0


def test_temporal_split_purges_by_actual_label_end_and_keeps_full_timeline():
    positions = np.arange(200, dtype=int)
    X = pd.DataFrame({'f': positions.astype(float)}, index=positions)
    y = pd.Series(np.where(positions % 3 == 0, np.nan, positions % 2), index=positions)
    ends = {int(i): float(i + (2 if i % 5 == 0 else 12)) for i in positions}
    X.attrs['v22_label_metadata'] = {
        'raw_start_pos': 0, 'raw_end_pos': 199,
        'label_end_positions': ends,
    }
    (X_tr, y_tr, X_val, y_val, X_te, y_te, info) = temporal_split(
        X, y, train_frac=.60, val_frac=.20, embargo=5, return_details=True)
    assert len(X_tr) and len(X_val) and len(X_te)
    assert all(ends[int(i)] < 120 for i in X_tr.index)
    assert all(i >= 125 for i in X_val.index)
    assert all(ends[int(i)] < 160 for i in X_val.index)
    assert all(i >= 165 for i in X_te.index)
    # Full validation/test paths retain neutral labels and every raw bar.
    assert len(info['validation_features_full']) == 35
    assert len(info['test_features_full']) == 35
    assert np.all(np.diff(info['test_features_full'].index.to_numpy()) == 1)
    assert info['label_interval_policy'] == 'purge_by_actual_label_end_pos_plus_embargo'


def test_backtest_sees_neutral_bar_between_entry_and_exit():
    # The second bar has no training label, but it is still part of the real
    # price path and must be allowed to trigger the stop.
    ind = pd.DataFrame({
        'high': [101., 101., 101., 101.],
        'low': [99., 80., 99., 99.],
        'close': [100., 90., 100., 100.],
        'atr_14': [10., 10., 10., 10.],
    })
    probs = np.array([0.95, np.nan, 0.95, 0.95])
    sim = simulate_trades(probs, ind, thr=.60, horizon=2)
    assert sim['losses'] == 1
    assert sim['n_trades'] == 1


def test_walk_forward_predictions_keep_neutral_bars_and_actual_interval_purge(monkeypatch):
    import backend.trainer as trainer

    positions = np.arange(700, dtype=int)
    X = pd.DataFrame({'f': np.sin(positions / 10)}, index=positions)
    y = pd.Series(np.where(positions % 4 == 0, np.nan, (positions % 2).astype(float)), index=positions)
    ends = {int(i): float(i + (1 if i % 7 == 0 else 5)) for i in positions}
    X.attrs['v22_label_metadata'] = {
        'raw_start_pos': 0, 'raw_end_pos': 699,
        'label_end_positions': ends,
    }
    ind = pd.DataFrame({
        't': positions * 60_000,
        'open': 100., 'high': 101., 'low': 99., 'close': 100.,
        'atr_14': 1., 'volume': 100.,
    }, index=positions)

    class FakeEnsemble:
        def fit(self, X_fit, y_fit, **kwargs):
            self.fit_max = int(X_fit.index.max())
            X_early = kwargs.get('X_val')
            if isinstance(X_early, pd.DataFrame) and len(X_early):
                internal_boundary = int(X_early.index.min()) - 5
                assert all(ends[int(i)] < internal_boundary for i in X_fit.index)
            return self

        def predict_proba_array(self, X_test):
            return np.full(len(X_test), .7)

    monkeypatch.setattr(trainer, 'TradingEnsemble', FakeEnsemble)
    acc, probs, oof_y, oof_ind = walk_forward_full(
        X, y, ind, params={}, n_folds=3, embargo=5)
    assert len(probs) == len(oof_y) == len(oof_ind)
    assert len(oof_ind) > 0
    assert oof_ind.index.is_monotonic_increasing
    assert np.isnan(oof_y).any()  # neutral bars remain in the OOF timeline
    assert np.isfinite(probs).any()
    neutral_with_prediction = np.isnan(oof_y) & np.isfinite(probs)
    assert neutral_with_prediction.any()  # simulator receives probabilities on unlabeled bars too
