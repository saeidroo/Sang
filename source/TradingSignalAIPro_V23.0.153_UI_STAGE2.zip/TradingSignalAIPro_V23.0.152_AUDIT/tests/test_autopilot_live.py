# -*- coding: utf-8 -*-
"""Integration test: real Flask app + real exchange APIs + full autopilot cycle.
Runs in ONE process so background threads survive."""
import os, sys, json, time, threading
os.environ["TRADING_AI_MODELS_DIR"] = "/tmp/ap_models_live"
os.environ["TRADING_AI_PAPER_LIVE_DB"] = "/tmp/ap_models_live/paper_live.sqlite3"
os.environ["TRADING_AI_HISTORY_DB"] = "/tmp/ap_models_live/history.sqlite3"
os.environ["TS_AI_SIGNAL_MAX_AGE_BARS"] = "3"
os.makedirs("/tmp/ap_models_live", exist_ok=True)

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent))
FAIL = []
def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (" | " + str(extra) if extra else ""), flush=True)
    if not cond: FAIL.append(name)

from backend.api import app
from backend import autopilot

client = app.test_client()
autopilot.start()  # run_server() does this on the desktop; call it directly here

# ---------- 1) state endpoint ----------
r = client.get("/api/autopilot/state")
d = r.get_json()
check("GET state 200", r.status_code == 200, r.status_code)
check("engine started", d["running"] is True)
check("balanced config", d["config"]["risk_preset"] == "balanced")
check("paper safety flags", d["safety"]["paper_only"] and not d["safety"]["real_orders_enabled"])

# ---------- 2) live watchlist from Binance (+Bybit) ----------
t0 = time.time()
r = client.get("/api/autopilot/symbols?force=1")
wl = r.get_json()
check("watchlist 200", r.status_code == 200)
check("watchlist has 10 symbols", len(wl.get("symbols") or []) == 10, wl.get("symbols"))
check("no stable/stock junk in list", not any(s in ("USDCUSDT", "USD1USDT", "RLUSDUSDT", "NVDABUSDT", "FDUSDUSDT") for s in (wl.get("symbols") or [])), wl.get("symbols"))
check("BTC/ETH present", "BTCUSDT" in (wl.get("symbols") or []) and "ETHUSDT" in (wl.get("symbols") or []))
print(f"   watchlist took {time.time()-t0:.1f}s, source={wl.get('source')}")

# ---------- 3) config change through API ----------
r = client.post("/api/autopilot/config", json={"risk_preset": "conservative", "timeframe": "1h"})
d = r.get_json()
check("config POST 200", r.status_code == 200, r.status_code)
check("config applied", d["config"]["risk_preset"] == "conservative" and d["risk_overrides"]["max_open_positions"] == 3)
client.post("/api/autopilot/config", json={"risk_preset": "balanced"})

# ---------- 4) FULL ENGINE CYCLE on real market data ----------
t0 = time.time()
r = client.post("/api/autopilot/tick", json={})
d = r.get_json()
dur = time.time() - t0
check("tick 200", r.status_code == 200, r.status_code)
cyc = d.get("cycle") or {}
check("cycle ran", "duration_seconds" in cyc, f"{cyc.get('duration_seconds')}s, wall={dur:.0f}s")
entry = cyc.get("entry") or {}
print(f"   cycle: evaluated={entry.get('evaluated')} opened={entry.get('opened')} rejected={entry.get('rejected')} skipped={entry.get('skipped')}")

st = client.get("/api/autopilot/state").get_json()
opened = st.get("open_positions") or []
print(f"   open autopilot positions: {[(p['symbol'], p['market'], p['side']) for p in opened]}")
for p in opened:
    check(f"position {p['symbol']} has stop/target", p.get("stop_price") and p.get("target_price"),
          f"stop={p.get('stop_price')} tp={p.get('target_price')}")
check("decisions logged", len(st.get("decisions") or []) > 0, f"n={len(st.get('decisions') or [])}")
# risk cap: never more than max_open_positions
check("max positions respected", len(opened) <= 5, f"n={len(opened)}")

# ---------- 5) report + csv ----------
r = client.get("/api/autopilot/report?kind=session")
rep = r.get_json()
check("session report 200", r.status_code == 200)
check("report has narrative", "معامله" in (rep.get("narrative") or ""))
check("report account", (rep.get("account") or {}).get("equity") is not None)
r = client.get("/api/autopilot/report.csv")
check("csv 200", r.status_code == 200, r.status_code)
check("csv header", b"trade_id" in r.data)

# ---------- 6) engine loop ticks on its own ----------
t0 = time.time()
time.sleep(40)
st = client.get("/api/autopilot/state").get_json()
check("engine cycles advanced", st["cycles"] >= 2, f"cycles={st['cycles']} after {time.time()-t0:.0f}s")
check("no fatal cycle error", not st.get("last_cycle_error"), st.get("last_cycle_error"))

# ---------- 7) stop with close_all ----------
r = client.post("/api/autopilot/stop", json={"close_all": True})
d = r.get_json()
check("stop 200", r.status_code == 200)
st = client.get("/api/autopilot/state").get_json()
check("engine stopped", st["running"] is False)
check("close_all closed positions", len(st.get("open_positions") or []) == 0,
      f"remaining={len(st.get('open_positions') or [])}")

print("\n=== RESULT:", "ALL PASS" if not FAIL else f"FAILURES: {FAIL}")
sys.exit(1 if FAIL else 0)
