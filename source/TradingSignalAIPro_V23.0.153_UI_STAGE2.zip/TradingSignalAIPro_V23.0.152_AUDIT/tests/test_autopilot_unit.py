# -*- coding: utf-8 -*-
"""Pytest integration checks for the V23 AutoPilot (offline with mocked data)."""
import os
import sys
import json
import time
from pathlib import Path
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from backend import paper_live, autopilot


def test_autopilot_unit_regressions(tmp_path, monkeypatch):
    """Run the legacy smoke checks as one isolated, collectable pytest test."""
    model_dir = tmp_path / "models"
    model_dir.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("TRADING_AI_MODELS_DIR", str(model_dir))
    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(model_dir / "paper_live.sqlite3"))
    monkeypatch.setenv("TRADING_AI_HISTORY_DB", str(model_dir / "history.sqlite3"))
    autopilot._load_config()
    autopilot._load_runtime_state()

    failures = []
    def check(name, cond, extra=""):
        print(("PASS " if cond else "FAIL ") + name + (" | " + str(extra) if extra else ""))
        if not cond:
            failures.append(name)

    # ---------- 1) open with autopilot overrides + entry_source ----------
    quote_state = {"price": 100.0}
    def fake_quote(symbol, market="spot", exchange="auto", use_cache=True):
        return {"symbol": symbol, "market": market, "exchange": "binance", "exchange_name": "Binance",
                "price": quote_state["price"], "timestamp": time.time(), "source": "public_rest_ticker",
                "authenticated": False, "cached": False, "fallback": False}
    with patch.object(paper_live, "get_quote", fake_quote):
        pos = paper_live.open_position("TESTUSDT", "LONG", "spot", "auto", "1h",
                                       overrides=autopilot._risk_overrides(), entry_source="autopilot")
    check("open with overrides", pos["notional"] == 100.0, f"notional={pos['notional']} (10% of 1000)")
    # Entry fill uses the canonical spread + slippage + size-impact model.
    expected_entry_fill = float(pos["entry_fill"])
    check("stop uses canonical execution-cost entry", abs(pos["stop_price"] - expected_entry_fill * 0.985) < 1e-6,
          pos["stop_price"])
    check("target uses canonical execution-cost entry", abs(pos["target_price"] - expected_entry_fill * 1.03) < 1e-6,
          pos["target_price"])
    ctx = json.loads(paper_live.list_trades(limit=1)[0]["entry_context_json"])
    check("entry_source=autopilot", ctx.get("entry_source") == "autopilot", ctx.get("entry_source"))
    check("settings_json uses effective sl", json.loads(paper_live.list_trades(limit=1)[0]["settings_json"])["stop_loss_pct"] == 1.5)

    # ---------- 2) balanced preset caps open positions at 3 ----------
    with patch.object(paper_live, "get_quote", fake_quote):
        for i in range(2):
            quote_state["price"] = 100.0 + i * 0.01
            paper_live.open_position(f"TEST{i}USDT", "LONG", "spot", "auto", "1h",
                                     overrides=autopilot._risk_overrides(), entry_source="autopilot")
        try:
            paper_live.open_position("TEST9USDT", "LONG", "spot", "auto", "1h",
                                     overrides=autopilot._risk_overrides(), entry_source="autopilot")
            check("balanced max 3 positions enforced", False, "opened a 4th!")
        except ValueError as e:
            check("balanced max 3 positions enforced", "حداکثر" in str(e), str(e)[:50])

    # ---------- 3) trailing stop raise (LONG) ----------
    quote_state["price"] = 102.0   # +2% >= trigger 1.5%
    with patch.object(paper_live, "get_quote", fake_quote):
        state = paper_live.get_state(refresh_quotes=True)   # engine flow: fresh quotes first
    positions = autopilot._autopilot_open_positions(state)
    check("autopilot sees its positions", len(positions) == 3, f"n={len(positions)}")
    main_pos = [p for p in positions if p["symbol"] == "TESTUSDT"][0]
    n = autopilot._manage_trailing(positions)
    check("trailing updated >=1 position", n >= 1, f"updated={n}")
    st = paper_live.get_state(refresh_quotes=False)
    main2 = [p for p in st["open_positions"] if p["symbol"] == "TESTUSDT"][0]
    expected_stop = round(102.0 * 0.99, 6)
    check("stop raised to peak*(1-1%)", abs(float(main2["stop_price"]) - expected_stop) < 1e-4,
          f"stop={main2['stop_price']} expected~{expected_stop}")
    try:
        paper_live.update_stop_price(main_pos["id"], 98.0)  # loosening attempt
        check("stop cannot loosen", False, "loosened!")
    except ValueError:
        check("stop cannot loosen", True)

    # ---------- 4) trailing stop exit ----------
    quote_state["price"] = 100.9   # below trailing stop 100.98
    with patch.object(paper_live, "get_quote", fake_quote):
        st2 = paper_live.get_state(refresh_quotes=True)
    closed = [t for t in paper_live.list_trades(status="CLOSED") if t["symbol"] == "TESTUSDT"]
    check("trailing stop closed position", len(closed) == 1, f"closed={len(closed)}")
    if closed:
        t = closed[0]
        check("exit_reason=STOP_LOSS", t["exit_reason"] == "STOP_LOSS", t["exit_reason"])
        check("trailing exit profitable", float(t["net_pnl"]) > 0, f"pnl={t['net_pnl']:.4f}")
        ctx2 = json.loads(t["entry_context_json"])
        check("learning event tagged autopilot", ctx2.get("entry_source") == "autopilot")

    # ---------- 5) perp SHORT + quote-aware stop ----------
    quote_state["price"] = 50.0
    with patch.object(paper_live, "get_quote", fake_quote):
        sp = paper_live.open_position("SHORTTESTUSDT", "SHORT", "perp", "auto", "1h",
                                      overrides=autopilot._risk_overrides(), entry_source="autopilot")
    check("perp SHORT stop above entry", sp["stop_price"] > sp["entry_fill"], f"stop={sp['stop_price']:.4f}")
    quote_state["price"] = 49.2  # ~1.6% short profit: above TP target, past trail trigger
    with patch.object(paper_live, "get_quote", fake_quote):
        st3 = paper_live.get_state(refresh_quotes=True)
    sp_pos = [p for p in autopilot._autopilot_open_positions(st3) if p["symbol"] == "SHORTTESTUSDT"][0]
    n = autopilot._manage_trailing([sp_pos])
    check("short trailing lowered stop", n == 1, f"updated={n}, stop={sp_pos['stop_price']:.4f}")
    # close manually to clean
    with patch.object(paper_live, "get_quote", fake_quote):
        paper_live.close_position(sp["id"])

    # ---------- 6) stats + reports ----------
    trades = autopilot._closed_autopilot_trades()
    stats = autopilot._stats_from_trades(trades)
    check("stats computed", stats["closed_trades"] >= 2, f"closed={stats['closed_trades']}")
    check("stats by_market has spot+perp", "spot" in stats["by_market"] and "perp" in stats["by_market"], list(stats["by_market"]))
    rep = autopilot.build_report("full")
    check("full report narrative", "معامله" in rep["narrative"], rep["narrative"][:60])
    rep_s = autopilot.build_report("session")
    check("session report OK", "stats" in rep_s and "narrative" in rep_s)
    rep_d = autopilot.build_report("daily")
    check("daily report OK", rep_d["period"]["kind"] == "daily")
    csv = autopilot.autopilot_trades_csv()
    check("csv rows", csv.count("\n") >= 3, f"lines={csv.count(chr(10))}")

    # ---------- 7) tech brain on synthetic candles ----------
    import pandas as pd, numpy as np
    def synth_df(prices, start=1_700_000_000_000):
        n = len(prices)
        return pd.DataFrame({"t": [start + i * 3_600_000 for i in range(n)],
                             "open": prices, "high": [p * 1.01 for p in prices],
                             "low": [p * 0.99 for p in prices], "close": prices,
                             "volume": [1000.0] * n})
    x = np.arange(300)
    # A rising regime with realistic pullbacks keeps RSI below exhaustion
    # and lets MACD confirm the trend; a perfectly linear ramp falsely
    # represented an overbought market for this strategy.
    up_prices = list(100.0 + 0.1 * x + 2.0 * np.sin(x * 2.0 * np.pi / 30.0))
    with patch.object(autopilot, "fetch_candles", lambda *a, **k: synth_df(up_prices)):
        sig = autopilot._tech_signal("TESTUSDT", "spot", "1h")
    check("tech brain BUY on uptrend", bool(sig and sig["kind"] == "BUY"), f"kind={sig['kind'] if sig else None} conf={sig['confidence']:.2f}" if sig else "none")
    dn_prices = list(np.linspace(130, 100, 300))
    with patch.object(autopilot, "fetch_candles", lambda *a, **k: synth_df(dn_prices)):
        sig_dn = autopilot._tech_signal("TESTUSDT", "perp", "1h")
    check("tech brain SELL on downtrend(perp)", bool(sig_dn and sig_dn["kind"] == "SELL"), f"kind={sig_dn['kind'] if sig_dn else None}")
    flat_prices = [100.0] * 300
    with patch.object(autopilot, "fetch_candles", lambda *a, **k: synth_df(flat_prices)):
        sig_flat = autopilot._tech_signal("TESTUSDT", "spot", "1h")
    check("tech brain HOLD on flat", bool(sig_flat and sig_flat["kind"] == "HOLD"), f"kind={sig_flat['kind'] if sig_flat else None}")

    # ---------- 8) ML decision guards (V23.0.1) ----------
    with patch.object(autopilot, "_ml_signal", lambda *a, **k: None), \
         patch.object(autopilot, "_tech_signal", lambda *a, **k: {"kind": "BUY", "confidence": 0.8, "brain": "tech", "detail": "mock tech"}):
        dec = autopilot._decide_entry("TESTUSDT", "spot")
    check("hybrid uses labelled technical fallback only without exact market model",
          dec.get("fallback_reason") == "market_model_missing" and dec["brain"] == "tech" and dec["kind"] == "BUY",
          f"{dec.get('fallback_reason')} {dec['brain']} {dec['kind']}")
    with patch.object(autopilot, "_ml_signal", lambda *a, **k: {"kind": "BUY", "confidence": 0.9, "edge_confirmed": True, "brain": "ml", "detail": "mock", "candle_ts": 123}), \
         patch.object(autopilot, "_tech_signal", lambda *a, **k: {"kind": "BUY", "confidence": 0.75, "brain": "tech", "detail": "mock tech"}):
        dec2 = autopilot._decide_entry("TESTUSDT", "spot")
    check("hybrid requires ML + technical agreement", dec2["brain"] == "hybrid" and dec2["kind"] == "BUY" and dec2.get("tech_confirmation") is True,
          f"{dec2['brain']} {dec2['kind']}")
    with patch.object(autopilot, "_ml_signal", lambda *a, **k: {"kind": "HOLD", "confidence": 0.5, "edge_confirmed": False, "brain": "ml", "detail": "explicit hold"}), \
         patch.object(autopilot, "_tech_signal", return_value={"kind": "BUY", "confidence": 0.95, "brain": "tech", "detail": "strong tech"}) as tech_mock:
        dec3 = autopilot._decide_entry("TESTUSDT", "spot")
    check("ML HOLD cannot be bypassed by technical", dec3["kind"] == "HOLD" and not tech_mock.called, f"{dec3['kind']} {dec3['detail']}")
    with patch.object(autopilot, "_ml_signal", lambda *a, **k: {"kind": "BUY", "confidence": 0.95, "edge_confirmed": False, "brain": "ml", "detail": "edge false"}), \
         patch.object(autopilot, "_tech_signal", return_value={"kind": "BUY", "confidence": 0.95, "brain": "tech", "detail": "strong tech"}) as tech_mock:
        dec4 = autopilot._decide_entry("TESTUSDT", "spot")
    check("unconfirmed ML edge blocks automatic entry", dec4["kind"] == "HOLD" and not tech_mock.called, f"{dec4['kind']} {dec4['detail']}")
    with patch.object(autopilot, "_ml_signal", lambda *a, **k: {"kind": "BUY", "confidence": 0.9, "edge_confirmed": True, "brain": "ml", "detail": "mock"}), \
         patch.object(autopilot, "_tech_signal", lambda *a, **k: {"kind": "SELL", "confidence": 0.9, "brain": "tech", "detail": "opposite"}):
        dec5 = autopilot._decide_entry("TESTUSDT", "spot")
    check("hybrid direction disagreement blocks entry", dec5["kind"] == "HOLD" and "عدم توافق" in dec5["detail"], dec5["detail"])

    # ---------- 9) cooldown logic ----------
    autopilot._STATE["cooldowns"]["TESTUSDT|spot"] = time.time() + 300
    check("cooldown active", autopilot._in_cooldown("TESTUSDT", "spot") > 0)
    autopilot._STATE["cooldowns"].pop("TESTUSDT|spot")

    # ---------- 10) risk presets + invalid config ----------
    autopilot.update_config({"risk_preset": "conservative"})
    ov = autopilot._risk_overrides()
    check("conservative preset applied", ov["max_open_positions"] == 2 and ov["stop_loss_pct"] == 1.5, ov)
    autopilot.update_config({"risk_preset": "balanced"})
    ov2 = autopilot._risk_overrides()
    check("back to balanced", ov2["max_open_positions"] == 3 and ov2["stop_loss_pct"] == 1.5, ov2)
    try:
        autopilot.update_config({"brain_mode": "nonsense", "stop_loss_pct": -5, "timeframe": "9z"})
        invalid_rejected = False
    except ValueError:
        invalid_rejected = True
    check("invalid config rejected atomically", invalid_rejected)
    assert not failures, "AutoPilot regressions failed: " + ", ".join(failures)


if __name__ == "__main__":
    import pytest
    sys.exit(pytest.main(["-q", __file__]))
