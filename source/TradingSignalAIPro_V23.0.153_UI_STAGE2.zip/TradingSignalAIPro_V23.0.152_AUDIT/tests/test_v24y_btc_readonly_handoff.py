from datetime import datetime,timezone,timedelta
import json,pytest
from backend.btc_live_environment_validation import validate_live_environment,_canonical
from backend.btc_live_validation_review import review_live_validation_reports,save_live_validation_review
from backend.btc_readonly_rolling_slo import build_readonly_rolling_slo
from backend.btc_readonly_incident_export import build_incident_export_bundle
from backend.btc_readonly_handoff import build_readonly_handoff,verify_readonly_handoff
from backend.witness_server import bootstrap_keys,init_db,record_anchor
from backend.btc_readonly_incident_export import verify_incident_export_bundle
from backend.witness_server import digest_anchor

NOW=datetime.now(timezone.utc).replace(microsecond=0)
def fetcher(**kwargs):
 return {'status':'PASS','selected_source':'Binance','fallback_used':False,
  'reconciliation':{'status':'PASS','compared_candles':120,'primary_sha256':'a'*64,'backup_sha256':'b'*64},
  'source_observations':{'Binance':{'status':'PASS','row_count':120,'latest_age_hours':1,'candles_sha256':'a'*64},
   'OKX':{'status':'PASS','row_count':120,'latest_age_hours':1,'candles_sha256':'b'*64}},
  'errors':{},'read_only':True,'training_allowed':False,'live_orders':False}

def make_full_inputs(tmp):
 reports=[validate_live_environment(fetcher=fetcher,now_utc=NOW-timedelta(hours=i)) for i in (2,1,0)]
 review=review_live_validation_reports(reports,operator_approved=True,now_utc=NOW)
 review_path=tmp/'review.json'; review_path.write_bytes(_canonical(review)+b'\n')
 slo=build_readonly_rolling_slo(reports,min_reports=3,operator_approved=True,now_utc=NOW)
 slo_path=tmp/'slo.json'; slo_path.write_bytes(_canonical(slo)+b'\n')
 log=tmp/'incidents.jsonl'; log.write_bytes(b'')
 bundle=tmp/'incidents.zip'; build_incident_export_bundle(log_path=log,output_path=bundle)
 priv=tmp/'witness-private.pem'; pub=tmp/'witness-public.pem'; db=tmp/'witness.sqlite'
 bootstrap_keys(priv,pub); init_db(db)
 v=verify_incident_export_bundle(bundle); m=v['manifest']
 anchor={'schema_version':'ts-ai-readonly-incident-anchor-v1','bundle_sha256':v['bundle_sha256'],
  'manifest_sha256':m['manifest_sha256'],'incident_log_sha256':m['incident_log_sha256'],
  'incident_head_sha256':m['head_sha256'],'event_count':m['event_count'],
  'scope':'read_only_btc_4h_incident_audit','training_allowed':False,'live_orders':False}
 receipt=record_anchor(db,priv,anchor); receipt_path=tmp/'receipt.json'; receipt_path.write_bytes(_canonical(receipt)+b'\n')
 report_paths=[]
 for i,r in enumerate(reports):
  p=tmp/f'live-{i}.json'; p.write_bytes(_canonical(r)+b'\n'); report_paths.append(p)
 return report_paths,review_path,slo_path,bundle,receipt_path,pub

def test_full_handoff_go_readonly_only_when_every_gate_passes(tmp_path):
 paths,review,slo,bundle,receipt,pub=make_full_inputs(tmp_path)
 result=build_readonly_handoff(live_report_paths=paths,operator_review_path=review,
  rolling_slo_path=slo,incident_bundle_path=bundle,witness_receipt_path=receipt,
  witness_public_key_path=pub,recovery_dir=tmp_path/'restore',highwater_path=tmp_path/'highwater.json',
  operator_approved=True,output_path=tmp_path/'handoff.json')
 assert result['decision']=='GO_READONLY'
 assert verify_readonly_handoff(result)['valid']
 assert result['training_allowed'] is False and result['paper_execution_allowed'] is False and result['live_orders'] is False

def test_missing_or_unapproved_gate_is_no_go(tmp_path):
 result=build_readonly_handoff(live_report_paths=[],operator_review_path=tmp_path/'missing-review',
  rolling_slo_path=tmp_path/'missing-slo',incident_bundle_path=tmp_path/'missing.zip',
  witness_receipt_path=tmp_path/'missing-receipt',witness_public_key_path=tmp_path/'missing-key',
  recovery_dir=tmp_path/'restore',highwater_path=tmp_path/'highwater',operator_approved=False)
 assert result['decision']=='NO_GO' and result['blockers']
 assert verify_readonly_handoff(result)['valid']

def test_handoff_tamper_and_go_with_blockers_rejected(tmp_path):
 paths,review,slo,bundle,receipt,pub=make_full_inputs(tmp_path)
 result=build_readonly_handoff(live_report_paths=paths,operator_review_path=review,
  rolling_slo_path=slo,incident_bundle_path=bundle,witness_receipt_path=receipt,
  witness_public_key_path=pub,recovery_dir=tmp_path/'restore',highwater_path=tmp_path/'highwater',operator_approved=True)
 result['decision']='NO_GO'
 with pytest.raises(ValueError,match='hash_mismatch'): verify_readonly_handoff(result)
