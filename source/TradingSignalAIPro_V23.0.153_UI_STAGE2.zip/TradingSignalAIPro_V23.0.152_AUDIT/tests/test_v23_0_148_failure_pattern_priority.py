from backend import storm_learning as sl
from backend.scout import _apply_failure_audit_priority


def _setup(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'storm_learning.sqlite3')


def _add(con, direction, result, ts, phase='early', regime='down', score=80):
    cur = con.execute('''INSERT INTO scout_sightings
        (symbol,ts,price,score,phase,direction,verified,pattern,market_regime)
        VALUES(?,?,?,?,?,?,?,?,?)''',
        ('XYZUSDT', ts, 100, score, phase, direction, 1, 'test', regime))
    con.execute('''INSERT INTO scout_outcomes
        (sighting_id,horizon,due_ts,resolved_ts,return_pct,result)
        VALUES(?,?,?,?,?,?)''',
        (cur.lastrowid, '24h', ts + 86400, ts + 86400,
         -2 if result == 'fake' else 2 if result == 'success' else 0, result))


def test_audit_exposes_directional_24h_baselines(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    with sl._db() as con:
        for i in range(30):
            _add(con, 'down', 'fake' if i < 24 else 'success', 1000 + i)
        for i in range(30):
            _add(con, 'down', 'success' if i < 24 else 'fake', 2000 + i, regime='sideways', phase='breakout')
    report = sl.failure_pattern_audit(min_samples=5)
    baseline = next(x for x in report['baseline'] if x['direction'] == 'down' and x['horizon'] == '24h')
    assert baseline['decisive_samples'] == 60
    assert baseline['failure_rate'] == 0.5


def test_failure_audit_penalizes_repeated_bad_context_but_is_bounded():
    report = {
        'baseline': [{'direction': 'down', 'horizon': '24h', 'decisive_samples': 100, 'failure_rate': .2}],
        'patterns': [{'direction': 'down', 'horizon': '24h', 'phase': 'early',
                      'market_regime': 'down', 'score_band': 'high', 'samples': 50,
                      'successes': 5, 'failures': 45, 'failure_rate': .9}],
    }
    items = [
        {'phase': 'early', 'market_regime': 'down', 'score': 80, 'directional_priority_score': 80},
        {'phase': 'breakout', 'market_regime': 'sideways', 'score': 55, 'directional_priority_score': 70},
    ]
    ranked = _apply_failure_audit_priority(items, 'down', report)
    bad = next(x for x in ranked if x['phase'] == 'early')
    other = next(x for x in ranked if x['phase'] == 'breakout')
    assert -2.0 <= bad['failure_audit_adjustment'] < 0
    assert bad['directional_priority_score'] < 80
    assert other['failure_audit_adjustment'] == 0
    assert other['directional_priority_score'] == 70


def test_insufficient_baseline_and_no_pattern_are_neutral():
    item = {'phase': 'early', 'market_regime': 'down', 'score': 80, 'directional_priority_score': 75}
    out = _apply_failure_audit_priority([item], 'down', {'baseline': [], 'patterns': []})
    assert out[0]['directional_priority_score'] == 75
    assert out[0]['failure_audit_adjustment'] == 0
    assert out[0]['failure_audit_reliability'] == 'insufficient_baseline'


def test_up_and_down_evidence_never_crosses():
    report = {
        'baseline': [{'direction': 'up', 'horizon': '24h', 'decisive_samples': 80, 'failure_rate': .2}],
        'patterns': [{'direction': 'down', 'horizon': '24h', 'phase': 'early',
                      'market_regime': 'down', 'score_band': 'high', 'samples': 60,
                      'successes': 2, 'failures': 58, 'failure_rate': .9667}],
    }
    item = {'phase': 'early', 'market_regime': 'down', 'score': 80, 'directional_priority_score': 66}
    out = _apply_failure_audit_priority([item], 'up', report)
    assert out[0]['directional_priority_score'] == 66
    assert out[0]['failure_audit_adjustment'] == 0
