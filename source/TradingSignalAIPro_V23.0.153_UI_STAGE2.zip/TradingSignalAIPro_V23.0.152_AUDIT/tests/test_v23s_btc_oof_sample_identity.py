import copy
import pytest
from backend.btc_dataset import build_btc_4h_dataset
from backend.btc_baseline import evaluate_btc_4h_baselines
from backend.btc_oof_coverage import build_oof_coverage_contract
from backend.btc_oof_audit import audit_oof_report
from test_v23d_btc_dataset import candles


def test_dataset_sample_identity_is_deterministic_and_timestamp_bound():
    a = build_btc_4h_dataset(candles(), n_splits=3)
    b = build_btc_4h_dataset(candles(), n_splits=3)
    cols = ['sample_id', 'timestamp_utc', 'row_identity_sha256']
    assert a['metadata'][cols].equals(b['metadata'][cols])
    assert a['metadata']['sample_id'].is_unique
    assert a['metadata']['timestamp_utc'].is_unique
    assert not {'sample_id', 'timestamp_utc', 'row_identity_sha256'} & set(a['X'].columns)
    assert all(x.endswith('Z') for x in a['metadata']['timestamp_utc'])


def test_same_timestamp_with_changed_candle_has_different_row_identity():
    original = candles()
    changed = original.copy()
    changed.loc[100, 'close'] *= 1.01
    changed.loc[100, 'high'] = max(changed.loc[100, 'high'], changed.loc[100, 'close'] * 1.001)
    a = build_btc_4h_dataset(original, n_splits=3)
    b = build_btc_4h_dataset(changed, n_splits=3)
    row_a = a['metadata'].loc[a['metadata']['sample_pos'] == 100].iloc[0]
    row_b = b['metadata'].loc[b['metadata']['sample_pos'] == 100].iloc[0]
    assert row_a['timestamp_utc'] == row_b['timestamp_utc']
    assert row_a['row_identity_sha256'] != row_b['row_identity_sha256']
    assert row_a['sample_id'] != row_b['sample_id']


def test_oof_predictions_carry_exact_dataset_sample_identity():
    ds = build_btc_4h_dataset(candles(), n_splits=3)
    result = evaluate_btc_4h_baselines(ds, require_lineage=False)
    contract = result['oof_coverage_contract']
    model = result['oof_predictions'].iloc[0]['model']
    report = {'predictions': result['oof_predictions'].query('model == @model').to_dict('records'),
              'fold_reports': [r for r in result['fold_reports'] if r['model'] == model]}
    audit = audit_oof_report(report, model_name=model,
        expected_fold_ids=contract['expected_fold_ids'],
        expected_sample_indices=contract['expected_sample_indices'],
        expected_fold_sample_indices=contract['fold_sample_indices'],
        expected_sample_identities=contract['sample_identities'])
    assert audit['status'] == 'PASS'


def test_oof_timestamp_tampering_is_blocked():
    ds = build_btc_4h_dataset(candles(), n_splits=3)
    result = evaluate_btc_4h_baselines(ds, require_lineage=False)
    contract = result['oof_coverage_contract']
    model = result['oof_predictions'].iloc[0]['model']
    rows = result['oof_predictions'].query('model == @model').to_dict('records')
    rows[0]['timestamp_utc'] = '2099-01-01T00:00:00Z'
    report = {'predictions': rows,
              'fold_reports': [r for r in result['fold_reports'] if r['model'] == model]}
    with pytest.raises(ValueError, match='timestamp_utc_mismatch'):
        audit_oof_report(report, model_name=model,
            expected_fold_ids=contract['expected_fold_ids'],
            expected_sample_indices=contract['expected_sample_indices'],
            expected_fold_sample_indices=contract['fold_sample_indices'],
            expected_sample_identities=contract['sample_identities'])


def test_coverage_contract_rejects_identity_tampering():
    ds = build_btc_4h_dataset(candles(), n_splits=3)
    contract = build_oof_coverage_contract(ds)
    changed = copy.deepcopy(contract)
    changed['sample_identities'][next(iter(changed['sample_identities']))]['timestamp_utc'] = '2099-01-01T00:00:00Z'
    from backend.btc_oof_coverage import require_oof_coverage_contract
    with pytest.raises(ValueError, match='contract_hash_mismatch'):
        require_oof_coverage_contract(changed, dataset_hash=ds['manifest']['dataset_hash'])
