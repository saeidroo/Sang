import hashlib, json
import numpy as np
import pytest
from backend.btc_dataset import build_btc_4h_dataset
from backend.btc_source_reconciliation import reconcile_candles
from backend.btc_training_lineage import build_lineage_manifest
from backend.btc_baseline import evaluate_btc_4h_baselines
from backend.btc_training_replay import execute_baseline_replay

def _sha(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
def _candles(n=260):
    rows=[]; p=30000.
    for i in range(n):
        p*=1+0.0005+0.003*np.sin(i/8)
        rows.append({'t':i*14400000,'open':p*.999,'high':p*1.003,'low':p*.997,'close':p,'volume':100+i})
    return rows
def _dataset(tmp):
    rows=_candles(); snap={'version':'btc-4h-store-v1','symbol':'BTCUSDT','timeframe':'4h','data_sha256':_sha(rows),'candles':rows,'source_batches':['a'*64]}
    sp=tmp/'snapshot.json'; sp.write_text(json.dumps(snap,sort_keys=True))
    rec=reconcile_candles(rows,rows); rec.update({'status':'PASS','training_allowed':True}); rec['report_sha256']=_sha(rec)
    rp=tmp/'recon.json'; rp.write_text(json.dumps(rec,sort_keys=True))
    base=build_btc_4h_dataset(rows,n_splits=3); lin=build_lineage_manifest(sp,rp,base['manifest'])
    return build_btc_4h_dataset(rows,n_splits=3,lineage_manifest=lin)
def test_replay_retrains_and_writes_independent_artifact(tmp_path):
    ds=_dataset(tmp_path); first=evaluate_btc_4h_baselines(ds,require_lineage=True)
    replay=execute_baseline_replay(ds,first['oof_predictions'],original_run_id='original',replay_run_id='replay-1',artifact_dir=tmp_path/'replays')
    assert replay['all_models_deterministic'] is True
    assert replay['dataset_hash']==ds['manifest']['dataset_hash']
    assert (tmp_path/'replays'/'replay-1.json').exists()
    with pytest.raises(FileExistsError):
        execute_baseline_replay(ds,first['oof_predictions'],original_run_id='original',replay_run_id='replay-1',artifact_dir=tmp_path/'replays')
def test_replay_requires_lineage(tmp_path):
    ds=build_btc_4h_dataset(_candles(),n_splits=3)
    with pytest.raises(ValueError,match='training_lineage_required_for_replay'):
        execute_baseline_replay(ds,[],original_run_id='a',replay_run_id='b',artifact_dir=tmp_path)
def test_replay_run_id_must_be_distinct(tmp_path):
    ds=_dataset(tmp_path)
    with pytest.raises(ValueError,match='invalid_replay_run_identity'):
        execute_baseline_replay(ds,[],original_run_id='same',replay_run_id='same',artifact_dir=tmp_path)
