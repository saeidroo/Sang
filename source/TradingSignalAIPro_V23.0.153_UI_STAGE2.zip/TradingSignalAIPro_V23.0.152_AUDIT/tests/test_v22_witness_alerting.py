import json, sqlite3
from datetime import datetime, timezone, timedelta
import pytest
from backend.witness_alerting import scheduler_metrics, prometheus_metrics, prune_scheduler_history, send_webhook, notify_if_needed
from backend.witness_scheduler import init_scheduler_db


def _db(path):
    init_scheduler_db(path)
    with sqlite3.connect(path) as db:
        now=datetime.now(timezone.utc)
        for i in range(6):
            stamp=(now-timedelta(days=i)).isoformat()
            db.execute('''INSERT INTO replication_runs(started_at,finished_at,status,source_sequence,replica_sequence,lag,chunks,appended,duration_seconds,error,alert)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)''',(stamp,stamp,'success' if i<5 else 'failed',10,10,0,1,1,.2,None,None))
    return path


def test_metrics_and_prometheus(tmp_path):
    p=_db(tmp_path/'s.db'); m=scheduler_metrics(p)
    assert m['runs_total']==6 and m['success_total']==5 and m['failed_total']==1
    out=prometheus_metrics(p)
    assert 'witness_replication_runs_total 6' in out and 'witness_replication_lag 0' in out


def test_retention_dry_run_and_prune(tmp_path):
    p=_db(tmp_path/'s.db')
    preview=prune_scheduler_history(p,retention_days=30,max_rows=3,dry_run=True)
    assert preview['deleted_rows']==0
    done=prune_scheduler_history(p,retention_days=30,max_rows=3)
    assert done['deleted_rows']==3 and done['remaining_rows']==3
    with sqlite3.connect(p) as db: assert db.execute('SELECT COUNT(*) FROM replication_runs').fetchone()[0]==3


def test_retention_rejects_unsafe_limits(tmp_path):
    p=_db(tmp_path/'s.db')
    with pytest.raises(ValueError): prune_scheduler_history(p,retention_days=0)


def test_webhook_requires_https():
    with pytest.raises(ValueError,match='webhook_requires_https'):
        send_webhook('http://example.com/hook',{})


def test_alert_skips_without_alerts():
    assert notify_if_needed({'status':'success','alerts':[]})['status']=='skipped'
