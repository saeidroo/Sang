import time
import pytest


def test_complete_equity_is_persisted_and_drawdown_survives_restart(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'history.sqlite3'))
    paper_live._CACHE.clear()
    paper_live.init_db()
    with paper_live._connect() as conn:
        conn.execute("INSERT INTO paper_equity_history(recorded_at,equity,peak_equity,drawdown_pct,realized_pnl,unrealized_pnl,open_positions,quote_health,funding_health) VALUES(?,?,?,?,?,?,?,?,?)",
                     (time.time()-120, 1000, 1000, 0, 0, 0, 0, 'LIVE', 'COMPLETE'))
        conn.execute("INSERT INTO paper_equity_history(recorded_at,equity,peak_equity,drawdown_pct,realized_pnl,unrealized_pnl,open_positions,quote_health,funding_health) VALUES(?,?,?,?,?,?,?,?,?)",
                     (time.time()-60, 950, 1000, -5, -50, 0, 0, 'LIVE', 'COMPLETE'))
    paper_live._CACHE.clear()
    result = paper_live.get_equity_history(limit=10)
    assert result['count'] == 2
    assert result['max_drawdown_pct'] == pytest.approx(-5)
    assert result['latest_equity'] == pytest.approx(950)
    assert result['history'][0]['equity'] == pytest.approx(1000)


def test_history_is_empty_without_complete_snapshot(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'empty.sqlite3'))
    paper_live._CACHE.clear()
    result = paper_live.get_equity_history()
    assert result['count'] == 0
    assert result['latest_equity'] is None
    assert result['read_only'] is True
