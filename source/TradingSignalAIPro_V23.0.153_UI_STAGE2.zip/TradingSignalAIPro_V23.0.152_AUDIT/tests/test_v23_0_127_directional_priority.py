from backend.scout import _apply_directional_brain_priority


def test_pre_dump_priority_uses_dump_score_not_pump_score():
    items = [
        {'pre_dump_score': 80, 'pre_pump_score': 5, 'score': 30,
         'brain_prediction': {'pattern_learning': {'weight': 1.0, 'directional_calls': 30}}},
        {'pre_dump_score': 60, 'pre_pump_score': 99, 'score': 90,
         'brain_prediction': {'pattern_learning': {'weight': 1.0, 'directional_calls': 30}}},
    ]
    ranked = _apply_directional_brain_priority(items, 'down')
    assert ranked[0]['pre_dump_score'] == 80
    assert ranked[0]['directional_priority_direction'] == 'down'


def test_insufficient_feedback_does_not_change_directional_score():
    item = {'pre_pump_score': 70, 'relative_strength_score': 40,
            'brain_prediction': {'pattern_learning': {'weight': 1.15, 'directional_calls': 19}}}
    ranked = _apply_directional_brain_priority([item], 'up')
    assert ranked[0]['directional_brain_weight'] == 1.0
    assert ranked[0]['directional_priority_score'] == 72.0


def test_directional_priority_rejects_unknown_direction():
    try:
        _apply_directional_brain_priority([], 'sideways')
    except ValueError:
        return
    assert False, 'unknown direction must be rejected'
