import numpy as np
import pandas as pd
import pytest

from backend.data import _clean_candles
from backend.signal import simulate_trades, backtest_signals
from backend.advanced import strategy_lab, market_regime, paper_open
from backend.trainer import champion_gate
from backend import rl_engine


def test_bad_candles_are_removed_and_missing_volume_is_zero():
    frame = _clean_candles([
        {'t': 3, 'open': 10, 'high': 12, 'low': 9, 'close': 11},
        {'t': 2, 'open': 10, 'high': 8, 'low': 9, 'close': 11, 'volume': 1},  # invalid OHLC
        {'t': 4, 'open': float('nan'), 'high': 12, 'low': 9, 'close': 11, 'volume': 1},
    ])
    assert len(frame) == 1
    assert frame.iloc[0]['volume'] == 0


def test_timeout_trades_are_closed_and_not_dropped():
    n = 6
    frame = pd.DataFrame({
        'high': [100, 100, 100, 100, 100, 100],
        'low': [100, 100, 100, 100, 100, 100],
        'close': [100, 101, 102, 103, 104, 105],
        'atr_14': [10.0] * n,
    })
    result = simulate_trades(np.array([0.9] * n), frame, thr=0.6, horizon=3)
    assert result['timeouts'] == 1
    assert result['wins'] == 1 and result['n_trades'] == 1
    assert result['open_trades'] == 1  # the final signal has no complete forward horizon


def test_strategy_lab_is_selected_without_using_holdout():
    rng = np.random.default_rng(19)
    train = 100 * np.exp(np.cumsum(rng.normal(0, .01, 280)))
    a = np.r_[train, train[-1] * np.exp(np.cumsum(np.full(120, .01)))]
    b = np.r_[train, train[-1] * np.exp(np.cumsum(np.full(120, -.01)))]
    ra, rb = strategy_lab(pd.DataFrame({'close': a})), strategy_lab(pd.DataFrame({'close': b}))
    assert ra['selection'] == rb['selection'] == 'training_block_only'
    assert ra['best']['strategy'] == rb['best']['strategy']


def test_market_regime_accepts_timeframe():
    n = 100
    c = np.linspace(100, 120, n)
    df = pd.DataFrame({'close': c})
    assert market_regime(df, '1d')['regime'] in ('bull', 'bear', 'sideways', 'high_volatility')


def test_paper_open_validates_symbol(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_PAPER_DB', str(tmp_path / 'paper.sqlite3'))
    with pytest.raises(ValueError):
        paper_open('BTC;DROP TABLE trades', 'LONG', 1, 100, 90)


def test_champion_gate_fails_closed_without_common_test_window():
    class Stub:
        is_fitted = True
        feature_names = ['x']
    champion = Stub()
    challenger = Stub()
    features = pd.DataFrame({'x': np.zeros(120)})
    ind = pd.DataFrame({'t': np.arange(120), 'high': 101, 'low': 99, 'close': 100, 'atr_14': 1})
    y = pd.Series(np.tile([0, 1], 60))
    result = champion_gate(champion, {}, challenger, features, features, y, ind, .6)
    assert result['promote'] is False and result['compared'] is False


def test_rl_rejects_invalid_cost_and_market_before_thread_start():
    candles = pd.DataFrame({'t': np.arange(600), 'open': 100., 'high': 101., 'low': 99., 'close': 100., 'volume': 1.})
    with pytest.raises(ValueError):
        rl_engine.start_training('BTCUSDT', '1h', candles, timesteps=10000, fee_bps=float('nan'))
    with pytest.raises(ValueError):
        rl_engine.start_training('BTC;DROP', '1h', candles, timesteps=10000)


def test_gross_win_that_cannot_cover_cost_is_not_a_net_win(monkeypatch):
    import backend.signal as signal
    monkeypatch.setattr(signal, 'ROUND_TRIP_COST_PCT', 0.12)
    frame = pd.DataFrame({
        'high': [100.0, 100.2], 'low': [100.0, 100.0],
        'close': [100.0, 100.1], 'atr_14': [100.0, 100.0],
    })
    result = signal.simulate_trades(np.array([0.9, 0.9]), frame, thr=0.6,
                                    tp_mult=0.001, sl_mult=0.001, horizon=1)
    assert result['gross_wins'] == 1
    assert result['wins'] == 0 and result['losses'] == 1
    assert result['net_expectancy_pct'] < 0


def test_rl_rejects_negative_volume_and_unsorted_timestamps():
    base = pd.DataFrame({
        't': np.arange(600), 'open': 100., 'high': 101., 'low': 99.,
        'close': 100., 'volume': 1.,
    })
    bad_volume = base.copy()
    bad_volume.loc[10, 'volume'] = -1
    with pytest.raises(ValueError):
        rl_engine._features(bad_volume)
    bad_time = base.copy()
    bad_time.loc[10, 't'] = -2
    with pytest.raises(ValueError):
        rl_engine._features(bad_time)
