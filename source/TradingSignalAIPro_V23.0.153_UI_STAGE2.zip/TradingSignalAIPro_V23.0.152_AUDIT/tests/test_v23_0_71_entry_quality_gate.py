import pytest
from backend.entry_quality_gate import evaluate_entry_quality

GOOD = {'symbol':'BTCUSDT','market':'perp','timeframe':'1h','quote_age_seconds':2,
        'spread_bps':4,'volume_ratio':1.4,'liquidity_usdt':500000,
        'entry_distance_atr':0.4,'opportunity_quality_index':82}

def test_clean_candidate_passes_review_not_execution():
    r=evaluate_entry_quality([GOOD])
    assert r['results'][0]['decision']=='REVIEW_PASS'
    assert r['entry_authorized'] is False and r['real_orders_enabled'] is False
    assert r['capital_usdt']==1000

def test_stale_spread_volume_liquidity_and_late_entry_rejected():
    row=dict(GOOD, quote_age_seconds=99, spread_bps=80, volume_ratio=.2,
             liquidity_usdt=10, entry_distance_atr=3)
    reasons=evaluate_entry_quality([row])['results'][0]['reasons']
    assert {'STALE_OR_MISSING_QUOTE','SPREAD_UNSAFE_OR_MISSING','VOLUME_TOO_WEAK_OR_MISSING',
            'LIQUIDITY_TOO_LOW_OR_MISSING','LATE_ENTRY_OR_MISSING_DISTANCE'} <= set(reasons)

def test_conflict_expiry_blocker_and_duplicate_rejected():
    row=dict(GOOD,timeframe_conflict=True,expired=True,blockers=['NO_TRADE'])
    r=evaluate_entry_quality([GOOD,row,GOOD])
    assert r['results'][1]['decision']=='REJECT'
    assert 'TIMEFRAME_CONFLICT' in r['results'][1]['reasons']
    assert 'DUPLICATE_OR_REPEATED_SIGNAL' in r['results'][2]['reasons']

def test_missing_or_invalid_evidence_fails_closed():
    r=evaluate_entry_quality([{'symbol':'ETHUSDT','timeframe':'5m'}])
    assert r['results'][0]['decision']=='REJECT'
    with pytest.raises(ValueError): evaluate_entry_quality({}, {})
    with pytest.raises(ValueError): evaluate_entry_quality([], {'max_spread_bps':-1})

def test_no_real_order_authorization_even_for_pass():
    r=evaluate_entry_quality([GOOD])
    assert r['creates_orders'] is False and r['execution_authorized'] is False
