from backend import storm_learning as sl


def _setup(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'storm_learning.sqlite3')


def _insert(con, direction, horizon, result, ret, ts):
    cur = con.execute('''INSERT INTO scout_sightings
        (symbol,ts,price,score,phase,direction,verified,pattern,market_regime)
        VALUES(?,?,?,?,?,?,?,?,?)''',
        ('ABCUSDT', ts, 100.0, 80.0, 'early', direction, 1, 'test', 'UNKNOWN'))
    con.execute('''INSERT INTO scout_outcomes
        (sighting_id,horizon,due_ts,resolved_ts,return_pct,result)
        VALUES(?,?,?,?,?,?)''',
        (cur.lastrowid, horizon, ts + sl.HORIZONS[horizon],
         ts + sl.HORIZONS[horizon] if result != 'pending' else None,
         ret, None if result == 'pending' else result))


def test_report_separates_up_and_down_directional_results(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    with sl._db() as con:
        _insert(con, 'up', '1h', 'success', 1.5, 1_000_000)
        _insert(con, 'up', '1h', 'fake', -3.0, 1_000_001)
        _insert(con, 'down', '1h', 'success', -2.0, 1_000_002)
        _insert(con, 'down', '1h', 'neutral', 0.5, 1_000_003)
    report = sl.directional_performance_report()['directions']
    assert report['up']['1h']['samples'] == 2
    assert report['up']['1h']['success_rate'] == 0.5
    assert report['down']['1h']['samples'] == 2
    assert report['down']['1h']['success_rate'] == 0.5
    assert report['down']['1h']['avg_directional_return_pct'] == 0.75


def test_pending_and_missing_are_not_counted_as_resolved_samples(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    with sl._db() as con:
        _insert(con, 'down', '4h', 'pending', None, 2_000_000)
        _insert(con, 'down', '4h', 'missing_observation', None, 2_000_001)
    stats = sl.directional_performance_report()['directions']['down']['4h']
    assert stats['samples'] == 0
    assert stats['pending'] == 1
    assert stats['missing_observations'] == 1
    assert stats['success_rate'] is None


def test_horizons_are_all_five_and_no_automatic_tuning(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    report = sl.directional_performance_report()
    assert set(report['directions']['up']) == {'1h', '4h', '24h', '3d', '7d'}
    assert report['threshold_policy'] == 'fixed_no_auto_adjustment'
    assert report['paper_only'] is True


def test_insufficient_evidence_is_labeled(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    with sl._db() as con:
        _insert(con, 'up', '24h', 'success', 6.0, 3_000_000)
    stats = sl.directional_performance_report()['directions']['up']['24h']
    assert stats['evidence_level'] == 'insufficient'
    assert stats['success_rate_ci95'] is not None
