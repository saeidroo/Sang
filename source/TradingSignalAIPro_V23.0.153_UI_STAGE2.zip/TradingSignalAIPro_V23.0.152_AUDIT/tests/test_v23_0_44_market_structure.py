import pandas as pd
import pytest

from backend.portfolio_risk import analyze_support_resistance, validate_structure_room


def sample_frame():
    # Confirmed swing high around 110 and swing low around 90.
    highs = [101, 103, 105, 110, 106, 104, 102, 103, 104, 105, 106, 107, 108, 107, 106]
    lows  = [99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 92, 94, 96, 97, 98]
    closes = [(h+l)/2 for h, l in zip(highs, lows)]
    return pd.DataFrame({"high": highs, "low": lows, "close": closes})


def test_detects_confirmed_levels_and_long_obstacle():
    frame = sample_frame()
    result = analyze_support_resistance(frame, side="LONG", reference_price=100, pivot_width=2)
    assert result["data_policy"] == "CLOSED_CANDLES_ONLY"
    assert result["nearest_obstacle"]["type"] == "RESISTANCE"
    assert result["nearest_obstacle"]["price"] > 100


def test_short_uses_support_as_obstacle():
    result = analyze_support_resistance(sample_frame(), side="SHORT", reference_price=100, pivot_width=2)
    assert result["nearest_obstacle"]["type"] == "SUPPORT"
    assert result["nearest_obstacle"]["price"] < 100


def test_blocks_target_beyond_nearby_resistance():
    structure = {"nearest_obstacle": {"type": "RESISTANCE", "price": 102}}
    with pytest.raises(ValueError, match="فضای آزاد"):
        validate_structure_room(structure, side="LONG", entry_price=100, target_price=103)


def test_allows_target_before_obstacle():
    structure = {"nearest_obstacle": {"type": "RESISTANCE", "price": 105}}
    result = validate_structure_room(structure, side="LONG", entry_price=100, target_price=103)
    assert result["valid"] is True
    assert result["status"] == "CLEAR"


def test_no_level_is_not_a_false_block():
    result = validate_structure_room({}, side="SHORT", entry_price=100, target_price=97)
    assert result["status"] == "NO_OPPOSING_LEVEL"


def test_rejects_invalid_ohlc():
    frame = sample_frame()
    frame.loc[0, "high"] = 1
    frame.loc[0, "low"] = 2
    with pytest.raises(ValueError, match="OHLC"):
        analyze_support_resistance(frame, side="LONG", reference_price=100, pivot_width=2)
