import logging
from pathlib import Path
from backend.logging_setup import RedactingFilter, configure_logging

def test_redacting_filter_removes_common_credentials():
    record=logging.LogRecord('test',logging.INFO,'',1,'api_key=SECRET123 Authorization=Bearer abc.def',(),None)
    assert RedactingFilter().filter(record)
    rendered=record.getMessage()
    assert 'SECRET123' not in rendered
    assert 'abc.def' not in rendered
    assert '[REDACTED]' in rendered

def test_configure_logging_is_idempotent_and_creates_file(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_LOG_DIR',str(tmp_path))
    import backend.logging_setup as module
    module._CONFIGURED=False
    path=configure_logging(max_bytes=1024,backup_count=2)
    configure_logging(max_bytes=1024,backup_count=2)
    assert path == tmp_path/'trading_ai.log'
    logger=logging.getLogger('test.logging.setup')
    logger.info('safe test event')
    for handler in logging.getLogger().handlers:
        if getattr(handler,'baseFilename',None)==str(path): handler.flush()
    assert path.exists() and 'safe test event' in path.read_text(encoding='utf-8')
