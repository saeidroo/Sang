from backend import market_brain


def test_failure_patterns_compare_signal_time_conditions(tmp_path, monkeypatch):
    db = tmp_path / 'feedback.sqlite3'
    monkeypatch.setattr(market_brain, 'FEEDBACK_DB_PATH', db)
    snapshots = {}
    for i in range(5):
        symbol = f'BAD{i}USDT'
        market_brain.record_directional_signal_feedback(
            {'pre_dump': [{'symbol': symbol, 'price': 100.0, 'market_regime': 'bullish',
                           'sell_ratio': 0.30, 'pre_dump_score': 75}]},
            snapshots={}, now=1000 + i * 10)
        snapshots[symbol] = {'price': 102.0}
    for i in range(5):
        symbol = f'GOOD{i}USDT'
        market_brain.record_directional_signal_feedback(
            {'pre_dump': [{'symbol': symbol, 'price': 100.0, 'market_regime': 'bearish',
                           'sell_ratio': 0.75, 'pre_dump_score': 75}]},
            snapshots={}, now=2000 + i * 10)
        snapshots[symbol] = {'price': 98.0}

    market_brain.record_directional_signal_feedback({}, snapshots=snapshots, now=7000)
    report = market_brain.directional_failure_patterns(min_samples=5)
    assert report['status'] == 'ok'
    bullish = next(p for p in report['patterns']
                   if p['signal_type'] == 'pre_dump' and p['horizon'] == '1h'
                   and p['feature'] == 'market_regime' and p['value'] == 'bullish')
    bearish = next(p for p in report['patterns']
                   if p['signal_type'] == 'pre_dump' and p['horizon'] == '1h'
                   and p['feature'] == 'market_regime' and p['value'] == 'bearish')
    assert bullish['failure_rate_pct'] == 100.0
    assert bearish['failure_rate_pct'] == 0.0
    assert report['automatic_adjustment'] is False


def test_failure_patterns_hide_small_groups(tmp_path, monkeypatch):
    db = tmp_path / 'feedback.sqlite3'
    monkeypatch.setattr(market_brain, 'FEEDBACK_DB_PATH', db)
    market_brain.record_directional_signal_feedback(
        {'pre_dump': [{'symbol': 'ONEUSDT', 'price': 1.0, 'market_regime': 'bullish'}]},
        snapshots={}, now=1000)
    market_brain.record_directional_signal_feedback({}, snapshots={'ONEUSDT': {'price': 1.02}}, now=5000)
    report = market_brain.directional_failure_patterns(min_samples=5)
    assert report['patterns'] == []
    assert report['insufficient_samples'] is True
