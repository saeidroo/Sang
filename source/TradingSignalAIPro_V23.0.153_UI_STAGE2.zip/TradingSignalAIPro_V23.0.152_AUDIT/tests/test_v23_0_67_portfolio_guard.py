from backend.portfolio_guard import analyze_paper_portfolio

def test_aggregate_risk_and_exposure():
    r=analyze_paper_portfolio([
      {'symbol':'BTCUSDT','market':'PERP','side':'LONG','notional_usdt':200,'stop_risk_usdt':5,'correlation_group':'BTC'},
      {'symbol':'ETHUSDT','market':'PERP','side':'LONG','notional_usdt':150,'stop_risk_usdt':4,'correlation_group':'MAJORS'}], equity=1000)
    assert r['gross_exposure_usdt']==350
    assert r['aggregate_stop_risk_usdt']==9
    assert r['paper_only'] and not r['execution_authorized'] and not r['real_orders_enabled']

def test_duplicate_positions_blocked():
    p={'symbol':'BTCUSDT','notional_usdt':100,'stop_risk_usdt':2}
    r=analyze_paper_portfolio([p,p])
    assert 'DUPLICATE_OPEN_POSITION' in r['blockers']

def test_drawdown_reduces_future_risk_and_hard_stops():
    soft=analyze_paper_portfolio([],equity=940,peak_equity=1000)
    hard=analyze_paper_portfolio([],equity=870,peak_equity=1000)
    assert soft['future_risk_budget_multiplier'] < 1
    assert hard['future_risk_budget_multiplier'] == 0
    assert hard['portfolio_status']=='BLOCKED'

def test_concentration_limits():
    r=analyze_paper_portfolio([{'symbol':'BTCUSDT','notional_usdt':300,'stop_risk_usdt':2,'correlation_group':'MAJORS'}], settings={'max_group_exposure_pct':20})
    assert 'SINGLE_SYMBOL_CONCENTRATION' in r['blockers']
    assert 'CORRELATED_GROUP_CONCENTRATION' in r['blockers']
