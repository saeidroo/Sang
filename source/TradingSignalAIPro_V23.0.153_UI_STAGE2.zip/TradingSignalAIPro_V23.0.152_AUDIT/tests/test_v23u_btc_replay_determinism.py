import pytest
from backend.btc_replay_determinism import (build_training_environment,
    compare_prediction_replays, prediction_digest, require_deterministic_replay)


def rows():
    return [
        {'model':'logistic_regression','fold':1,'sample_id':'a','y_true':1,'y_pred':1,
         'p_down':0.1,'p_neutral':0.2,'p_up':0.7},
        {'model':'logistic_regression','fold':1,'sample_id':'b','y_true':0,'y_pred':0,
         'p_down':0.2,'p_neutral':0.6,'p_up':0.2},
    ]


def test_prediction_digest_is_order_independent():
    assert prediction_digest(rows()) == prediction_digest(list(reversed(rows())))


def test_identical_replay_passes():
    report = require_deterministic_replay(rows(), list(reversed(rows())))
    assert report['deterministic'] is True
    assert report['first_sha256'] == report['second_sha256']


def test_changed_prediction_is_detected():
    changed = rows(); changed[0]['p_up'] = 0.8
    report = compare_prediction_replays(rows(), changed)
    assert report['deterministic'] is False
    assert len(report['changed_keys']) == 1
    with pytest.raises(ValueError, match='btc4h_oof_replay_nondeterministic'):
        require_deterministic_replay(rows(), changed)


def test_added_and_removed_samples_are_detected():
    report = compare_prediction_replays(rows(), rows()[:1])
    assert len(report['removed_keys']) == 1


def test_environment_fingerprint_binds_seed_and_config():
    a = build_training_environment(random_state=42, model_config={'alpha':1})
    b = build_training_environment(random_state=42, model_config={'alpha':1})
    c = build_training_environment(random_state=7, model_config={'alpha':1})
    assert a['environment_sha256'] == b['environment_sha256']
    assert a['environment_sha256'] != c['environment_sha256']
