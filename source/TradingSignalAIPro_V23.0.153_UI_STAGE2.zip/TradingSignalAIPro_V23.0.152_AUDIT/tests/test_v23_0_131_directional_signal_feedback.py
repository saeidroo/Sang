from backend import market_brain


def test_directional_signal_feedback_records_both_dump_stages_and_horizons(tmp_path, monkeypatch):
    db = tmp_path / 'feedback.sqlite3'
    monkeypatch.setattr(market_brain, 'FEEDBACK_DB_PATH', db)
    groups = {
        'pre_dump': [{'symbol': 'BTCUSDT', 'price': 100.0}],
        'active_dump': [{'symbol': 'ETHUSDT', 'price': 50.0}],
        'pre_pump': [{'symbol': 'SOLUSDT', 'price': 20.0}],
    }
    result = market_brain.record_directional_signal_feedback(groups, snapshots={}, now=1000)
    assert result['inserted'] == 15
    assert result['pending'] == 15
    summary = market_brain.directional_signal_feedback_summary()
    assert set(summary['signals']) == {'pre_dump', 'active_dump', 'pre_pump'}
    assert set(summary['signals']['pre_dump']) == {'1h', '4h', '24h', '3d', '7d'}


def test_directional_feedback_resolves_dump_success_and_failure(tmp_path, monkeypatch):
    db = tmp_path / 'feedback.sqlite3'
    monkeypatch.setattr(market_brain, 'FEEDBACK_DB_PATH', db)
    groups = {'active_dump': [{'symbol': 'BTCUSDT', 'price': 100.0}]}
    market_brain.record_directional_signal_feedback(groups, snapshots={}, now=1000)
    # Resolve the 1h observation: a 2% decline is a successful dump signal.
    out = market_brain.record_directional_signal_feedback({}, snapshots={'BTCUSDT': {'price': 98.0}}, now=4600)
    assert out['resolved_now'] == 1
    row = market_brain.directional_signal_feedback_summary()['signals']['active_dump']['1h']
    assert row['successes'] == 1
    assert row['success_rate_pct'] == 100.0


def test_directional_feedback_treats_rise_after_dump_as_failure(tmp_path, monkeypatch):
    db = tmp_path / 'feedback.sqlite3'
    monkeypatch.setattr(market_brain, 'FEEDBACK_DB_PATH', db)
    market_brain.record_directional_signal_feedback({'pre_dump': [{'symbol': 'XRPUSDT', 'price': 1.0}]}, snapshots={}, now=1000)
    market_brain.record_directional_signal_feedback({}, snapshots={'XRPUSDT': {'price': 1.02}}, now=4600)
    row = market_brain.directional_signal_feedback_summary()['signals']['pre_dump']['1h']
    assert row['failures'] == 1
    assert row['success_rate_pct'] == 0.0


def test_failure_analysis_preserves_signal_time_context(tmp_path, monkeypatch):
    db = tmp_path / 'feedback.sqlite3'
    monkeypatch.setattr(market_brain, 'FEEDBACK_DB_PATH', db)
    market_brain.record_directional_signal_feedback(
        {'pre_dump': [{'symbol': 'ADAUSDT', 'price': 1.0, 'pre_dump_score': 82.5,
                       'sell_ratio': 0.71, 'phase': 'early'}]}, snapshots={}, now=1000)
    market_brain.record_directional_signal_feedback(
        {}, snapshots={'ADAUSDT': {'price': 1.03}}, now=4600)
    analysis = market_brain.directional_failure_analysis()
    assert analysis['status'] == 'ok'
    assert analysis['recent_failures'][0]['reason'] == 'opposite_move'
    assert analysis['recent_failures'][0]['signal_context']['pre_dump_score'] == 82.5
    assert analysis['groups'][0]['count'] == 1


def test_neutral_directional_signal_is_classified_as_no_follow_through(tmp_path, monkeypatch):
    db = tmp_path / 'feedback.sqlite3'
    monkeypatch.setattr(market_brain, 'FEEDBACK_DB_PATH', db)
    market_brain.record_directional_signal_feedback(
        {'pre_pump': [{'symbol': 'DOGEUSDT', 'price': 0.1}]}, snapshots={}, now=1000)
    market_brain.record_directional_signal_feedback(
        {}, snapshots={'DOGEUSDT': {'price': 0.1005}}, now=4600)
    analysis = market_brain.directional_failure_analysis()
    assert analysis['recent_failures'][0]['outcome'] == 'neutral'
    assert analysis['recent_failures'][0]['reason'] == 'no_follow_through'
