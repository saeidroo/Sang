from backend.market_brain import _bucket_signature


def _candles(direction=1, volume=1000):
    rows = []
    price = 100.0
    for i in range(25):
        op = price
        price *= (1 + direction * 0.008)
        rows.append(('ABCUSDT', i, op, max(op, price) * 1.001,
                     min(op, price) * 0.999, price, volume * (2 if i == 24 else 1)))
    return rows


def test_directional_signature_distinguishes_bull_and_bear_contexts():
    bull = _bucket_signature(_candles(1), 24)
    bear = _bucket_signature(_candles(-1), 24)
    assert bull is not None and bear is not None
    assert bull[0] == 'v2' and bear[0] == 'v2'
    assert bull != bear
    assert bull[1] == 'up'
    assert bear[1] == 'down'


def test_signature_includes_volume_shock_and_candle_pressure():
    normal = _bucket_signature(_candles(1, 1000), 24)
    assert normal is not None
    assert normal[4] == 'high'
    assert normal[6] == 'buy'


def test_signature_rejects_insufficient_or_invalid_window():
    assert _bucket_signature(_candles(1)[:20], 19) is None
    rows = _candles(1)
    rows[-1] = rows[-1][:5] + (0, rows[-1][6])
    assert _bucket_signature(rows, 24) is None
