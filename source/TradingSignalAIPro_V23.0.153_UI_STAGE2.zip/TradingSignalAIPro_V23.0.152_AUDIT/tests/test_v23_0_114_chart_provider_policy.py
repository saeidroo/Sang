from backend import data

def test_crypto_auto_chain_prefers_tradingview_then_fallbacks():
    assert data.CRYPTO_AUTO_ORDER[0] == "tradingview"
    assert len(data.CRYPTO_AUTO_ORDER) >= 10
    assert "binance" in data.CRYPTO_AUTO_ORDER[1:]

def test_commodity_auto_chain_prefers_tradingview_then_fallbacks():
    from backend.data import COMMODITIES_YAHOO
    assert "GOLD" in COMMODITIES_YAHOO
    assert "WTI" in COMMODITIES_YAHOO
    import inspect
    source = inspect.getsource(data.fetch_candles)
    assert "['tradingview', 'yahoo', 'stooq', 'history']" in source

def test_tradingview_explicitly_allowed_for_commodities():
    import inspect
    source = inspect.getsource(data.fetch_candles)
    assert "('tradingview', 'yahoo', 'stooq', 'history')" in source


def test_adaptive_order_never_moves_fallback_ahead_of_tradingview(monkeypatch):
    from backend import data
    monkeypatch.setattr(data, "_SOURCE_SUCCESS_TS", {"binance": 9999999999.0, "tradingview": 1.0})
    order = data.CRYPTO_AUTO_ORDER.copy()
    if order and order[0] == "tradingview":
        ordered = ["tradingview"] + data._adaptive_sort(order[1:])
    else:
        ordered = data._adaptive_sort(order)
    assert ordered[0] == "tradingview"
