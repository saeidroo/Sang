import pytest
from backend.opportunity_scoring import score_trade_opportunity


def test_complete_factors_score_and_paper_only():
    factors = {k: 90 for k in ('trend_structure','volume_strength','support_resistance','volatility_fit','historical_strategy','execution_cost','risk_reward','data_reliability')}
    r = score_trade_opportunity(symbol='BTCUSDT', factors=factors)
    assert r['opportunity_quality_index'] == 90
    assert r['classification'] == 'STRONG_CANDIDATE'
    assert r['authorizes_entries'] is False and r['real_orders_enabled'] is False
    assert r['is_probability_of_profit'] is False


def test_missing_factors_shrink_toward_neutral_and_report_coverage():
    r = score_trade_opportunity(symbol='ETHUSDT', factors={'trend_structure': 100})
    assert r['opportunity_quality_index'] < 100
    assert r['evidence_coverage'] == 0.16
    assert r['classification'] == 'INSUFFICIENT_EVIDENCE'
    assert len(r['missing_factors']) == 7


def test_blockers_override_high_score():
    factors = {k: 100 for k in ('trend_structure','volume_strength','support_resistance','volatility_fit','historical_strategy','execution_cost','risk_reward','data_reliability')}
    r = score_trade_opportunity(symbol='BTCUSDT', factors=factors, blockers=['STALE_DATA'])
    assert r['classification'] == 'BLOCKED'
    assert r['authorizes_entries'] is False


def test_invalid_factor_rejected():
    with pytest.raises(ValueError):
        score_trade_opportunity(symbol='BTCUSDT', factors={'risk_reward': 101})


def test_invalid_symbol_rejected():
    with pytest.raises(ValueError):
        score_trade_opportunity(symbol='BTC')
