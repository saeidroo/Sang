import time
import pytest
from backend import paper_live


def _base_row(exchange, market='spot'):
    now = int(time.time() * 1000)
    step = 300_000
    start = now - (now % step) - 2 * step
    return ({'exchange': exchange, 'market': market, 'symbol': 'BTCUSDT', 'timeframe': '5m',
             'opened_at': start / 1000, 'replay_last_candle_open_ms': None}, start)


def test_fetch_pinned_binance_ohlcv_normalizes_and_filters_open_candle(monkeypatch):
    row, start = _base_row('binance')
    step = 300_000
    captured = {}
    def fake(url, params):
        captured.update(url=url, params=params)
        return [[start, '100', '105', '95', '101'],
                [start + step, '101', '106', '96', '102'],
                [start + 2 * step, '102', '107', '97', '103']]
    monkeypatch.setattr(paper_live, '_http_json', fake)
    candles = paper_live.fetch_pinned_closed_candles(row)
    assert captured['url'].endswith('/api/v3/klines')
    assert captured['params']['symbol'] == 'BTCUSDT'
    assert len(candles) == 2
    assert candles[0] == {'t': start, 'open': 100.0, 'high': 105.0, 'low': 95.0, 'close': 101.0}


@pytest.mark.parametrize('exchange,market,url_part,payload', [
    ('gateio', 'spot', '/spot/candlesticks', [[1700000000, '1', '10', '12', '9', '11']]),
    ('gateio', 'perp', '/futures/usdt/candlesticks', [{'t': 1700000000, 'o': '11', 'h': '12', 'l': '9', 'c': '10'}]),
    ('mexc', 'spot', '/api/v3/klines', [[1700000000000, '10', '12', '9', '11']]),
    ('mexc', 'perp', '/contract/kline/', {'success': True, 'data': {'time': [1700000000], 'open': ['10'], 'high': ['12'], 'low': ['9'], 'close': ['11']}}),
    ('bitget', 'spot', '/spot/market/candles', {'code': '00000', 'data': [[1700000000000, '10', '12', '9', '11']]}),
    ('bitget', 'perp', '/mix/market/candles', {'code': '00000', 'data': [[1700000000000, '10', '12', '9', '11']]}),
])
def test_pinned_exchange_adapters_normalize_public_ohlcv(monkeypatch, exchange, market, url_part, payload):
    row, _ = _base_row(exchange, market)
    captured = {}
    def fake(url, params):
        captured.update(url=url, params=params)
        return payload
    monkeypatch.setattr(paper_live, '_http_json', fake)
    candles = paper_live.fetch_pinned_closed_candles(row)
    assert url_part in captured['url']
    assert candles
    candle = candles[0]
    assert set(candle) == {'t', 'open', 'high', 'low', 'close'}
    assert candle['low'] <= min(candle['open'], candle['close'])
    assert candle['high'] >= max(candle['open'], candle['close'])
    if exchange == 'bitget' and market == 'perp':
        assert captured['params']['productType'] == 'USDT-FUTURES'


def test_fetch_pinned_ohlcv_fails_closed_for_unknown_exchange():
    with pytest.raises(RuntimeError, match='unsupported'):
        paper_live.fetch_pinned_closed_candles({'exchange': 'unknown', 'market': 'spot',
            'symbol': 'BTCUSDT', 'timeframe': '5m', 'opened_at': 1})


def test_fetch_pinned_ohlcv_rejects_malformed_ohlc(monkeypatch):
    row, start = _base_row('mexc')
    monkeypatch.setattr(paper_live, '_http_json', lambda *_: [[start, '10', '8', '9', '11']])
    with pytest.raises(RuntimeError, match='values invalid'):
        paper_live.fetch_pinned_closed_candles(row)


def test_gateio_futures_documented_array_shape_is_normalized(monkeypatch):
    row, _ = _base_row('gateio', 'perp')
    # Gate.io futures candle arrays: [timestamp, volume, close, high, low, open]
    monkeypatch.setattr(paper_live, '_http_json', lambda *_: [[1700000000, '50', '11', '12', '9', '10']])
    candles = paper_live.fetch_pinned_closed_candles(row)
    assert candles
    assert candles[0]['open'] == 10.0
    assert candles[0]['high'] == 12.0
    assert candles[0]['low'] == 9.0
    assert candles[0]['close'] == 11.0
