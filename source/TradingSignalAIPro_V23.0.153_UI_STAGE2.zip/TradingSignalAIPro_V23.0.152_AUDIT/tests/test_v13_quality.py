import numpy as np
import pandas as pd

from backend.model import TradingEnsemble
from backend.signal import simulate_trades, compute_signal
import backend.news as news


class FixedProbabilityModel:
    def predict_proba(self, X):
        return np.tile(np.array([[0.30, 0.70]]), (len(X), 1))


def test_calibrator_applies_to_weighted_log_odds_inference():
    from sklearn.linear_model import LogisticRegression
    lr = LogisticRegression().fit(
        np.array([[-2.0], [-1.0], [1.0], [2.0]]),
        np.array([0, 0, 1, 1]),
    )
    model = TradingEnsemble(feature_names=['x'])
    model.models = {'fixed': FixedProbabilityModel()}
    model.weights = {'fixed': 1.0}
    model.calibrator = ('sigmoid', lr)
    model.is_fitted = True
    frame = pd.DataFrame({'x': [1.0, 2.0]})

    raw = np.full(2, 0.70)
    expected = model._apply_calibration(raw)
    actual = model.predict_proba_array(frame)
    assert np.allclose(actual, expected)
    assert np.isclose(model.predict_proba(frame.iloc[[0]]), expected[0])
    assert not np.allclose(actual, raw)
    # Explicit raw mode remains uncalibrated for diagnostic evaluation.
    assert np.allclose(model.predict_proba_array(frame, use_meta=False), raw)


def test_trade_simulation_does_not_open_overlapping_positions():
    n = 10
    frame = pd.DataFrame({
        'high': [100, 102, 100, 102, 100, 102, 100, 102, 100, 102],
        'low': [100] * n,
        'close': [100] * n,
        'atr_14': [1.0] * n,
    })
    probs = np.full(n, 0.90)
    result = simulate_trades(probs, frame, thr=0.60, tp_mult=1.5, sl_mult=1.5, horizon=3)
    assert result['non_overlapping'] is True
    assert result['n_trades'] == 5
    assert result['wins'] == 5


def test_news_payload_has_persian_headlines(monkeypatch):
    monkeypatch.setattr(news, '_news', lambda: [{'title': 'Bitcoin market update', 'url': 'https://example.test'}])
    monkeypatch.setattr(news, '_macro', lambda: [{'title': 'US inflation report', 'minutes_away': 90, 'currency': 'USD'}])
    monkeypatch.setattr(news, '_fear_greed', lambda: {'value': 42, 'classification': 'Fear'})
    monkeypatch.setattr(news, '_translate_fa', lambda text: 'ترجمه فارسی: ' + text)
    result = news.build_news_alert('BTCUSDT')
    assert result['breaking'][0]['title_fa'].startswith('ترجمه فارسی')
    assert result['macro_events'][0]['title_fa'].startswith('ترجمه فارسی')
    assert result['fear_greed']['classification_fa'] == 'ترس'


def test_stricter_oof_threshold_changes_live_signal_to_hold():
    ind = pd.DataFrame({
        'close': [110.0], 'ema_20': [105.0], 'ema_50': [100.0],
        'rsi_14': [50.0], 'volume': [1000.0], 'macd_hist': [1.0],
        'bb_pct': [0.5], 'atr_14': [2.0], 'volume_mean_20': [900.0],
        't': [1_700_000_000_000],
    })
    candidate = compute_signal(ind, 0.70, threshold=0.65)
    strict = compute_signal(ind, 0.70, threshold=0.75)
    assert candidate['kind'] == 'BUY'
    assert strict['kind'] == 'HOLD'
