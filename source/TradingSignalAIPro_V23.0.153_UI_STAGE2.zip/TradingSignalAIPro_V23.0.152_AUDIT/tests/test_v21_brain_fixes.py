"""V21 part 4: learning-brain bug fixes."""
import os
import sys
import time
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend import brain, consensus  # noqa: E402


@pytest.fixture()
def brain_db(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(tmp_path / 'models'))
    monkeypatch.setattr(brain, '_db_path', lambda: tmp_path / 'brain.sqlite')
    yield tmp_path


def test_brain_version_constant_matches_decision_label():
    assert brain.BRAIN_VERSION == 'central-brain-v4'


def test_health_reports_current_brain_version():
    from backend.api import app
    app.config['TESTING'] = True
    with app.test_client() as c:
        assert c.get('/api/health').get_json()['decision_brain'] == brain.BRAIN_VERSION


def test_observation_matures_with_current_price_only(brain_db):
    """Before V21 an observation could never mature without a market frame."""
    step = brain.TF_MS['1h']
    t0 = 1_700_000_000_000 - (1_700_000_000_000 % step)
    assert brain.record_observation('TESTUSDT', '1h', t0, 100.0, {'ml': 0.5})
    target_ts = t0 + step * brain.HORIZON_BARS
    changed = brain.update_matured_outcomes('TESTUSDT', '1h', target_ts, 110.0, market_frame=None)
    assert changed == 1
    with brain._connection() as conn:
        ret = conn.execute('SELECT realized_return FROM brain_observations').fetchone()[0]
    assert ret == pytest.approx(0.10)


def test_observation_not_matured_early(brain_db):
    step = brain.TF_MS['1h']
    t0 = 1_700_000_000_000 - (1_700_000_000_000 % step)
    brain.record_observation('TESTUSDT', '1h', t0, 100.0, {'ml': 0.5})
    assert brain.update_matured_outcomes('TESTUSDT', '1h', t0 + step * 5, 110.0) == 0


def test_quality_uses_walk_forward_not_max():
    q_wf = consensus._quality({'walk_forward_acc': 0.52, 'val_acc': 0.80, 'balanced_acc': 0.70})
    q_high = consensus._quality({'val_acc': 0.80})
    assert q_wf < q_high               # no longer inflated by the best-looking metric
    assert q_wf == pytest.approx(0.52)


def test_quality_falls_back_in_order():
    assert consensus._quality({'balanced_acc': 0.6, 'val_acc': 0.7}) == pytest.approx(0.6)
    assert consensus._quality({'val_acc': 0.7}) == pytest.approx(0.7)
    assert consensus._quality({}) == pytest.approx(0.5)


def test_twin_market_relation_weights():
    r = consensus._relation_weight
    assert r('BTCUSDT', '1h', 'BTCUSDTPERP', '1h') == consensus.W_TWIN_SAME_TF
    assert r('BTCUSDTPERP', '1h', 'BTCUSDT', '4h') == consensus.W_TWIN_OTHER_TF
    assert r('BTCUSDT', '1h', 'ETHUSDTPERP', '1h') == consensus.W_SAME_TF_OTHER_SYMBOL
    assert r('BTCUSDT', '1h', 'BTCUSDT', '4h') == consensus.W_SAME_SYMBOL_OTHER_TF
    assert r('BTCUSDT', '1h', 'ETHUSDT', '4h') == consensus.W_OTHER


def test_model_cache_reloads_after_retrain(tmp_path, monkeypatch):
    """A retrained file must not keep voting with the old cached model."""
    import backend.model as model_mod
    loads = []

    class Fake:
        is_fitted = True

        def __init__(self, tag):
            self.tag = tag

    def fake_load(path):
        loads.append(Path(path).read_text())
        return Fake(loads[-1])
    monkeypatch.setattr(model_mod.TradingEnsemble, 'load', staticmethod(fake_load))
    consensus._CACHE.clear()
    f = tmp_path / 'model_X_1h.joblib'
    f.write_text('v1')
    assert consensus._load_model_cached(f).tag == 'v1'
    assert consensus._load_model_cached(f).tag == 'v1'
    assert len(loads) == 1                              # second call served from cache
    time.sleep(0.01)
    f.write_text('version-two')                         # retrained: new mtime/size
    assert consensus._load_model_cached(f).tag == 'version-two'
    assert len([k for k in consensus._CACHE if k.startswith(str(f))]) == 1   # old copy evicted
    consensus._CACHE.clear()


def test_frontend_reports_kept_old_model():
    js = (ROOT / 'frontend' / 'app.js').read_text(encoding='utf-8')
    assert 'meta.promoted === false' in js
