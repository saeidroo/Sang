from datetime import datetime, timezone, timedelta
import pytest
from backend.btc_live_environment_validation import validate_live_environment
from backend.btc_readonly_rolling_slo import build_readonly_rolling_slo, verify_readonly_rolling_slo

NOW=datetime(2026,11,17,12,0,tzinfo=timezone.utc)
def fetcher(**kwargs):
 return {'status':'PASS','selected_source':'Binance','fallback_used':False,
  'reconciliation':{'status':'PASS','compared_candles':120,'primary_sha256':'a'*64,'backup_sha256':'b'*64},
  'source_observations':{
   'Binance':{'status':'PASS','row_count':120,'latest_age_hours':1.2,'candles_sha256':'a'*64},
   'OKX':{'status':'PASS','row_count':120,'latest_age_hours':1.3,'candles_sha256':'b'*64}},
  'errors':{},'read_only':True,'training_allowed':False,'live_orders':False}
def report(at, custom=None): return validate_live_environment(fetcher=custom or fetcher,now_utc=at)

def test_rolling_slo_continue_readonly_requires_thresholds_and_approval():
 rs=[report(NOW-timedelta(hours=i)) for i in (4,3,2,1,0)]
 result=build_readonly_rolling_slo(rs,min_reports=5,operator_approved=True,now_utc=NOW)
 assert result['decision']=='CONTINUE_READONLY'
 assert result['pass_rate']==1 and result['cross_source_agreement_rate']==1
 assert verify_readonly_rolling_slo(result)['valid']
 assert result['training_allowed'] is False and result['live_orders'] is False

def test_insufficient_window_or_missing_approval_requires_review():
 rs=[report(NOW-timedelta(hours=2)),report(NOW-timedelta(hours=1)),report(NOW)]
 assert build_readonly_rolling_slo(rs,min_reports=5,operator_approved=True,now_utc=NOW)['decision']=='REVIEW_REQUIRED'
 assert build_readonly_rolling_slo(rs,min_reports=3,operator_approved=False,now_utc=NOW)['decision']=='REVIEW_REQUIRED'

def test_availability_or_staleness_breach_stops_readonly():
 def degraded(**kwargs):
  x=fetcher(); x['status']='DEGRADED'; x['selected_source']='Binance'; x['fallback_used']=False
  x['errors']={'OKX':'network unavailable'}; x['source_observations']['OKX']={'status':'UNAVAILABLE'}
  return x
 rs=[report(NOW-timedelta(hours=i)) for i in (4,3,2,1)] + [report(NOW,degraded)]
 result=build_readonly_rolling_slo(rs,min_reports=5,operator_approved=True,now_utc=NOW)
 assert result['decision']=='STOP'
 assert 'okx_availability_below_slo' in result['threshold_breaches']

def test_stale_candles_stop_even_if_both_sources_available():
 def stale(**kwargs):
  x=fetcher(); x['source_observations']['Binance']['latest_age_hours']=10
  x['source_observations']['OKX']['latest_age_hours']=10
  return x
 rs=[report(NOW-timedelta(hours=i),stale) for i in (2,1,0)]
 result=build_readonly_rolling_slo(rs,min_reports=3,operator_approved=True,now_utc=NOW)
 assert result['decision']=='STOP'
 assert 'stale_candle_observed' in result['threshold_breaches']

def test_duplicate_or_tampered_slo_rejected():
 rs=[report(NOW-timedelta(hours=1)),report(NOW)]
 with pytest.raises(ValueError,match='duplicate'):
  build_readonly_rolling_slo([rs[0],rs[0]],now_utc=NOW)
 result=build_readonly_rolling_slo(rs,min_reports=3,now_utc=NOW)
 result['decision']='CONTINUE_READONLY'
 with pytest.raises(ValueError,match='hash_mismatch'):
  verify_readonly_rolling_slo(result)
