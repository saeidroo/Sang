from backend.scout import pre_dump_rejection_diagnostics


def _item(symbol, **updates):
    item = {
        'symbol': symbol, 'verified': True, 'phase': 'early',
        'pre_dump_candidate': True, 'pre_dump_score': 75.0,
        'change_24h': -2.0, 'pre_dump_price_change_1h_pct': -1.0,
    }
    item.update(updates)
    return item


def test_diagnostics_explain_phase_and_fast_move_rejections():
    items = [
        _item('EARLYUSDT'),
        _item('RUNUSDT', phase='running'),
        _item('FASTUSDT', **{'pre_dump_price_change_1h_pct': -4.0}),
    ]
    result = pre_dump_rejection_diagnostics(items, [items[0]])
    counts = result['rejection_counts']
    assert result['scanned'] == 3
    assert result['selected'] == 1
    assert counts['not_early_phase'] == 1
    assert counts['1h_move_out_of_range'] == 1
    assert {x['symbol'] for x in result['near_misses']} == {'RUNUSDT', 'FASTUSDT'}


def test_diagnostics_are_observability_only_and_report_unverified():
    item = _item('UNVERIFIEDUSDT', verified=False, pre_dump_candidate=False)
    result = pre_dump_rejection_diagnostics([item], [])
    assert result['rejection_counts']['unverified'] == 1
    assert result['rejection_counts']['flow_not_qualified'] == 1
    assert result['selected'] == 0
