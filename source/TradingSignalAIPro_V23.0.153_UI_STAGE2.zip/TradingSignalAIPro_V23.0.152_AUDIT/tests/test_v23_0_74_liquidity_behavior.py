import pytest
from backend.liquidity_behavior_analyzer import analyze_liquidity_behavior

BOOK = {'symbol':'ETHUSDT','exchange':'Demo','bids':[[100,80],[99.9,10]],
        'asks':[[100.1,20],[100.2,10]],
        'recent_trades':[{'side':'buy','qty':10},{'side':'buy','qty':8},{'side':'sell','qty':3}],
        'price_change_during_trades_pct':0.05}

def test_orderbook_depth_and_tape_are_advisory_only():
    r=analyze_liquidity_behavior([BOOK]); x=r['results'][0]
    assert x['evidence']['depth_imbalance'] > 0
    assert x['entry_authorized'] is False and r['real_orders_enabled'] is False
    assert r['capital_usdt']==1000

def test_wall_change_is_warning_not_spoofing_claim():
    old={'bids':[[100,10],[99.9,90]],'asks':[[100.1,10],[100.2,90]]}
    x=analyze_liquidity_behavior([dict(BOOK,previous_book=old)])['results'][0]
    assert any('WALL_CHANGE' in w for w in x['warnings'])

def test_missing_book_fails_closed():
    x=analyze_liquidity_behavior([{'symbol':'X','exchange':'Y'}])['results'][0]
    assert x['decision']=='INSUFFICIENT_DATA' and x['entry_authorized'] is False

def test_bad_input_and_bounded_lists():
    with pytest.raises(ValueError): analyze_liquidity_behavior({})
    x=analyze_liquidity_behavior([dict(BOOK,bids=[[float('nan'),2]])])['results'][0]
    assert x['decision']=='INSUFFICIENT_DATA'
