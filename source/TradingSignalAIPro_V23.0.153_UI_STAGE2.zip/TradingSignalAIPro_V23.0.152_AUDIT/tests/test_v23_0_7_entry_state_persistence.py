from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path

import pytest

from backend import autopilot


@pytest.fixture
def isolated_runtime_db(tmp_path, monkeypatch):
    db = tmp_path / "autopilot_runtime.sqlite3"
    monkeypatch.setattr(autopilot, "_runtime_state_db", lambda: db)
    with autopilot._LOCK:
        autopilot._STATE.update({
            "cooldowns": {},
            "candle_seen": {},
            "watchlist": [],
            "watchlist_at": 0.0,
            "watchlist_source": "fallback",
            "last_entry_scan_at": 0.0,
            "last_entry_summary": {},
            "last_closed_check_ts": 0.0,
            "daily_reports_done": set(),
            "cycles": 0,
            "manage_cycles": 0,
            "entry_cycles": 0,
            "entries_enabled": False,
            "runtime_state_loaded": False,
            "runtime_state_saved_at": 0.0,
            "runtime_state_error": "",
        })
    yield db



def test_runtime_state_round_trip_survives_restart(isolated_runtime_db):
    now = time.time()
    with autopilot._LOCK:
        autopilot._STATE["cooldowns"] = {"BTCUSDT|spot": now + 900}
        autopilot._STATE["candle_seen"] = {"BTCUSDT|spot|1h": 1_800_000_000.0}
        autopilot._STATE["watchlist"] = [{"symbol": "BTCUSDT", "volume": 123456.0}]
        autopilot._STATE["watchlist_at"] = now
        autopilot._STATE["watchlist_source"] = "binance+bybit"
        autopilot._STATE["last_entry_scan_at"] = now - 60
        autopilot._STATE["last_entry_summary"] = {
            "ts": now, "evaluated": 12, "opened": 1,
            "ranked": [{"symbol": "BTCUSDT", "score": 88.2}],
        }
        autopilot._STATE["last_closed_check_ts"] = now - 30
        autopilot._STATE["daily_reports_done"] = {"2026-11-18"}
        autopilot._STATE["cycles"] = 17
        autopilot._STATE["manage_cycles"] = 12
        autopilot._STATE["entry_cycles"] = 5
    assert autopilot._persist_runtime_state() is True

    with autopilot._LOCK:
        autopilot._STATE["cooldowns"] = {}
        autopilot._STATE["candle_seen"] = {}
        autopilot._STATE["watchlist"] = []
        autopilot._STATE["last_entry_summary"] = {}
        autopilot._STATE["daily_reports_done"] = set()
        autopilot._STATE["cycles"] = 0
    assert autopilot._load_runtime_state() is True

    with autopilot._LOCK:
        assert autopilot._STATE["cooldowns"]["BTCUSDT|spot"] > now
        assert autopilot._STATE["candle_seen"]["BTCUSDT|spot|1h"] == 1_800_000_000.0
        assert autopilot._STATE["watchlist"][0]["symbol"] == "BTCUSDT"
        assert autopilot._STATE["watchlist_source"] == "binance+bybit"
        assert autopilot._STATE["last_entry_summary"]["ranked"][0]["score"] == 88.2
        assert "2026-11-18" in autopilot._STATE["daily_reports_done"]
        assert autopilot._STATE["cycles"] == 17
        assert autopilot._STATE["entries_enabled"] is False
        assert autopilot._STATE["runtime_state_loaded"] is True


def test_legacy_candle_keys_migrate_to_active_timeframe(isolated_runtime_db):
    autopilot._CONFIG["timeframe"] = "4h"
    payload = {
        "schema_version": 0,
        "saved_at": time.time(),
        "cooldowns": {},
        "candle_seen": {"ETHUSDT|perp": 1_800_000_001.0},
    }
    with sqlite3.connect(isolated_runtime_db) as conn:
        conn.execute("""CREATE TABLE runtime_state (
            state_key TEXT PRIMARY KEY, schema_version INTEGER NOT NULL,
            value_json TEXT NOT NULL, updated_at REAL NOT NULL)""")
        conn.execute("INSERT INTO runtime_state VALUES('autopilot',0,?,?)",
                     (json.dumps(payload), time.time()))
    assert autopilot._load_runtime_state() is True
    assert autopilot._STATE["candle_seen"]["ETHUSDT|perp|4h"] == 1_800_000_001.0


def test_expired_cooldowns_are_not_restored(isolated_runtime_db):
    payload = {"schema_version": 1, "saved_at": time.time(),
               "cooldowns": {"BTCUSDT|spot": time.time() - 10},
               "candle_seen": {}}
    with sqlite3.connect(isolated_runtime_db) as conn:
        conn.execute("""CREATE TABLE runtime_state (
            state_key TEXT PRIMARY KEY, schema_version INTEGER NOT NULL,
            value_json TEXT NOT NULL, updated_at REAL NOT NULL)""")
        conn.execute("INSERT INTO runtime_state VALUES('autopilot',1,?,?)",
                     (json.dumps(payload), time.time()))
    assert autopilot._load_runtime_state() is True
    assert "BTCUSDT|spot" not in autopilot._STATE["cooldowns"]


def test_candle_marker_is_durable_and_monotonic(isolated_runtime_db):
    key = autopilot._candle_seen_key("btcusdt", "spot", "15m")
    assert key == "BTCUSDT|spot|15m"
    assert autopilot._mark_candle_seen(key, 1000.0) is True
    assert autopilot._mark_candle_seen(key, 900.0) is True
    assert autopilot._STATE["candle_seen"][key] == 1000.0
    with autopilot._LOCK:
        autopilot._STATE["candle_seen"] = {}
    assert autopilot._load_runtime_state() is True
    assert autopilot._STATE["candle_seen"][key] == 1000.0


def test_failed_checkpoint_is_reported_and_entry_marker_fails_closed(tmp_path, monkeypatch):
    bad_path = tmp_path / "not_a_database_directory"
    bad_path.mkdir()
    monkeypatch.setattr(autopilot, "_runtime_state_db", lambda: bad_path)
    key = autopilot._candle_seen_key("SOLUSDT", "perp", "1h")
    assert autopilot._mark_candle_seen(key, 2000.0) is False
    assert "unable to open database" in autopilot._STATE["runtime_state_error"].lower()
    # The in-memory marker remains set, so the same process also fails closed.
    assert autopilot._STATE["candle_seen"][key] == 2000.0


def test_runtime_state_payload_is_bounded_and_json_finite(isolated_runtime_db):
    with autopilot._LOCK:
        autopilot._STATE["watchlist"] = [
            {"symbol": f"COIN{i}USDT", "volume": float(i)} for i in range(150)
        ]
        autopilot._STATE["last_entry_summary"] = {
            "ranked": [{"symbol": f"COIN{i}USDT"} for i in range(100)]
        }
    assert autopilot._persist_runtime_state() is True
    with sqlite3.connect(isolated_runtime_db) as conn:
        raw = conn.execute("SELECT value_json FROM runtime_state WHERE state_key='autopilot'").fetchone()[0]
    payload = json.loads(raw)
    assert len(payload["watchlist"]) == 100
    assert len(payload["last_entry_summary"]["ranked"]) == 60


def test_new_timeframe_has_independent_processed_candle_key():
    key_1h = autopilot._candle_seen_key("BTCUSDT", "spot", "1h")
    key_4h = autopilot._candle_seen_key("BTCUSDT", "spot", "4h")
    assert key_1h != key_4h


def test_corrupt_runtime_checkpoint_does_not_enable_entry(monkeypatch, tmp_path):
    db = tmp_path / "corrupt.sqlite3"
    with sqlite3.connect(db) as conn:
        conn.execute("""CREATE TABLE runtime_state (
            state_key TEXT PRIMARY KEY, schema_version INTEGER NOT NULL,
            value_json TEXT NOT NULL, updated_at REAL NOT NULL)""")
        conn.execute("INSERT INTO runtime_state VALUES('autopilot',1,'{broken',?)", (time.time(),))
    monkeypatch.setattr(autopilot, "_runtime_state_db", lambda: db)
    assert autopilot._load_runtime_state() is False
    autopilot._STATE["entries_enabled"] = True
    result = autopilot._entry_cycle_once_impl()
    assert result["stopped"] is True
    assert result["opened"] == 0
    assert result["runtime_state_error"]


def test_entry_cycle_stops_when_pre_scan_checkpoint_fails(monkeypatch, isolated_runtime_db):
    autopilot._STATE["runtime_state_loaded"] = True
    autopilot._STATE["entries_enabled"] = True
    monkeypatch.setattr(autopilot, "_persist_runtime_state", lambda: False)
    monkeypatch.setattr(autopilot, "_entry_scan", lambda **kwargs: pytest.fail("scan must not run"))
    result = autopilot._entry_cycle_once_impl()
    assert result["stopped"] is True
    assert result["opened"] == 0
    assert result["runtime_state_error"]


def test_missing_candle_identity_never_creates_entry(monkeypatch, isolated_runtime_db):
    from unittest.mock import patch
    from backend import paper_live

    autopilot._STATE.update({
        "runtime_state_loaded": True,
        "entries_enabled": True,
        "watchlist": [{"symbol": "BTCUSDT", "volume": 100_000_000.0}],
        "watchlist_at": time.time(),
        "watchlist_source": "test",
        "cooldowns": {},
        "candle_seen": {},
    })
    autopilot._CONFIG.update({"markets": ["spot"], "max_open_positions": 3,
                              "max_positions_per_base": 1, "diversification_enabled": False,
                              "timeframe": "1h"})
    decision = {"kind": "BUY", "confidence": 0.9, "brain": "tech", "detail": "test"}
    with patch.object(autopilot, "_decide_entry", return_value=decision), \
         patch.object(paper_live, "get_state", return_value={"open_positions": []}), \
         patch.object(paper_live, "open_position") as open_position:
        result = autopilot._entry_scan()
    assert result["opened"] == 0
    assert result["skipped"] == 1
    open_position.assert_not_called()
