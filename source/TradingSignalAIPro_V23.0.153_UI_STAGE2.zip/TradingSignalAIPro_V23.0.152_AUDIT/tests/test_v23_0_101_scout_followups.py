from backend import storm_learning as sl


def test_followups_report_real_next_day_and_delayed_pumps(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'followups.sqlite3')
    base = 1_700_000_000
    coins = [
        {'symbol': 'AAAUSDT', 'price': 100, 'score': 72, 'phase': 'early', 'direction': 'up', 'verified': True},
        {'symbol': 'BBBUSDT', 'price': 100, 'score': 68, 'phase': 'early', 'direction': 'up', 'verified': True},
        {'symbol': 'CCCUSDT', 'price': 100, 'score': 66, 'phase': 'watch', 'direction': 'up', 'verified': True},
    ]
    sl.record_scan(coins, timestamp=base, snapshots={x['symbol'][:-4]: {'price': 100} for x in coins})
    # 24h +6%, 3d +12%, 7d +18%; all outcomes use observed prices only.
    sl.record_scan([], timestamp=base + 86400, snapshots={'AAA': {'price': 106}})
    sl.record_scan([], timestamp=base + 3 * 86400, snapshots={'BBB': {'price': 112}})
    sl.record_scan([], timestamp=base + 7 * 86400, snapshots={'CCC': {'price': 118}})
    report = sl.followups()
    by_symbol = {e['symbol']: e for e in report['events']}
    assert by_symbol['AAAUSDT']['horizon'] == '24h'
    assert by_symbol['AAAUSDT']['return_pct'] == 6.0
    assert by_symbol['BBBUSDT']['horizon'] == '3d'
    assert by_symbol['BBBUSDT']['delayed_pump'] is True
    assert by_symbol['CCCUSDT']['horizon'] == '7d'
    assert by_symbol['CCCUSDT']['delayed_pump'] is True
    assert len(report['delayed_pumps']) == 2


def test_missing_observation_is_not_reported_as_success(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'missing.sqlite3')
    base = 1_700_000_000
    sl.record_scan([{'symbol': 'MISSUSDT', 'price': 10, 'score': 60, 'phase': 'early',
                     'direction': 'up', 'verified': True}], timestamp=base)
    report = sl.followups()
    assert report['events'] == []
    assert report['delayed_pumps'] == []


def test_followups_learns_only_from_five_real_outcomes(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'cohorts.sqlite3')
    base = 1_710_000_000
    picks = [
        {'symbol': f'COIN{i}USDT', 'price': 100, 'score': 72, 'phase': 'early',
         'direction': 'up', 'verified': True}
        for i in range(5)
    ]
    sl.record_scan(picks, timestamp=base)
    # Resolve 1h outcomes using actual observed prices, not synthetic labels.
    sl.record_scan([], timestamp=base + 3600,
                   snapshots={f'COIN{i}': {'price': 102} for i in range(5)})
    report = sl.followups()
    matching = [x for x in report['historical_insights']
                if x['horizon'] == '1h' and x['phase'] == 'early' and x['score_band'] == '70-79']
    assert len(matching) == 1
    assert matching[0]['samples'] == 5
    assert matching[0]['success_rate'] == 1.0
    assert matching[0]['avg_return_pct'] == 2.0


def test_followups_hides_small_cohorts(tmp_path, monkeypatch):
    monkeypatch.setattr(sl, 'DB_PATH', tmp_path / 'small_cohorts.sqlite3')
    base = 1_720_000_000
    picks = [{'symbol': f'SMALL{i}USDT', 'price': 10, 'score': 65, 'phase': 'watch',
              'direction': 'up', 'verified': True} for i in range(4)]
    sl.record_scan(picks, timestamp=base)
    sl.record_scan([], timestamp=base + 3600,
                   snapshots={f'SMALL{i}': {'price': 10.2} for i in range(4)})
    assert sl.followups()['historical_insights'] == []
