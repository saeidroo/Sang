import copy, json
import pytest
from backend.btc_training_registry import register_training_run, load_training_run, list_training_runs
from backend.btc_baseline import evaluate_btc_4h_baselines
from test_v23o_btc_training_registry import _dataset, _canonical


def test_registry_persists_pass_audit_and_coverage(tmp_path):
    ds = _dataset(tmp_path)
    result = evaluate_btc_4h_baselines(ds, training_registry_dir=tmp_path/'reg')
    run = next(iter(result['training_runs'].values()))
    record = load_training_run(run['run_id'], registry_dir=tmp_path/'reg')
    audit = record['oof_audit']
    assert audit['status'] == 'PASS'
    assert audit['prediction_count'] == record['oof']['row_count']
    assert audit['artifact_sha256']
    assert list_training_runs(registry_dir=tmp_path/'reg')[0]['oof_audit_status'] == 'PASS'


def test_registry_rejects_incomplete_oof_before_append(tmp_path):
    ds = _dataset(tmp_path)
    result = evaluate_btc_4h_baselines(ds)
    model, artifact = next(iter(result['training_runs'].items()))
    rows = result['oof_predictions']
    report = {'predictions': rows[rows.model == model].to_dict(orient='records')[:-1],
              'fold_reports': [r for r in result['fold_reports'] if r['model'] == model],
              'evaluation_hash': result['summary']['evaluation_hash']}
    with pytest.raises(ValueError, match='oof_audit_blocked'):
        register_training_run(artifact, ds['manifest']['lineage'], report, registry_dir=tmp_path/'reg')
    assert not (tmp_path/'reg'/'btc_training_runs.jsonl').exists()


def test_registry_enforces_explicit_expected_coverage(tmp_path):
    ds = _dataset(tmp_path)
    result = evaluate_btc_4h_baselines(ds)
    model, artifact = next(iter(result['training_runs'].items()))
    rows = result['oof_predictions']
    report = {'predictions': rows[rows.model == model].to_dict(orient='records'),
              'fold_reports': [r for r in result['fold_reports'] if r['model'] == model],
              'evaluation_hash': result['summary']['evaluation_hash']}
    with pytest.raises(ValueError, match='fold_coverage_mismatch'):
        register_training_run(artifact, ds['manifest']['lineage'], report, registry_dir=tmp_path/'reg',
                              expected_fold_ids=[1, 2, 999])


def test_load_revalidates_stored_audit_artifact(tmp_path):
    ds = _dataset(tmp_path)
    result = evaluate_btc_4h_baselines(ds, training_registry_dir=tmp_path/'reg')
    run = next(iter(result['training_runs'].values()))
    path = tmp_path/'reg'/'btc_training_runs.jsonl'
    row = json.loads(path.read_text().splitlines()[0])
    row['oof_audit']['prediction_count'] += 1
    # Re-sign outer record to isolate the audit artifact integrity check.
    body = dict(row); body.pop('record_sha256', None)
    import hashlib
    row['record_sha256'] = hashlib.sha256(_canonical(body).encode()).hexdigest()
    path.write_text(_canonical(row)+'\n')
    with pytest.raises(ValueError, match='audit_artifact_hash_mismatch'):
        load_training_run(run['run_id'], registry_dir=tmp_path/'reg')
