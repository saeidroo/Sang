from datetime import datetime,timezone,timedelta
import json,pytest
from backend.btc_live_environment_validation import validate_live_environment
from backend.btc_readonly_rolling_slo import build_readonly_rolling_slo
from backend.btc_readonly_incidents import record_readonly_slo_incidents,verify_incident_log

NOW=datetime(2026,11,17,12,0,tzinfo=timezone.utc)
def fetcher(**kwargs):
 return {'status':'PASS','selected_source':'Binance','fallback_used':False,
  'reconciliation':{'status':'PASS','compared_candles':120,'primary_sha256':'a'*64,'backup_sha256':'b'*64},
  'source_observations':{'Binance':{'status':'PASS','row_count':120,'latest_age_hours':1,'candles_sha256':'a'*64},
   'OKX':{'status':'PASS','row_count':120,'latest_age_hours':1,'candles_sha256':'b'*64}},
  'errors':{},'read_only':True,'training_allowed':False,'live_orders':False}
def make_slo(decision='STOP'):
 reports=[validate_live_environment(fetcher=fetcher,now_utc=NOW-timedelta(hours=i)) for i in (2,1,0)]
 if decision=='STOP':
  # Produce a valid STOP by breaching the validation pass-rate threshold.
  def degraded(**kwargs):
   x=fetcher(); x['status']='DEGRADED'; x['selected_source']='Binance'; x['errors']={'OKX':'offline'}
   x['source_observations']['OKX']={'status':'UNAVAILABLE'}; return x
  reports[-1]=validate_live_environment(fetcher=degraded,now_utc=NOW)
 return build_readonly_rolling_slo(reports,min_reports=3,operator_approved=True,now_utc=NOW)

def test_open_duplicate_suppression_and_recovery(tmp_path):
 p=tmp_path/'incidents.jsonl'; stop=make_slo('STOP')
 first=record_readonly_slo_incidents(stop,log_path=p,now_utc=NOW)
 assert first['appended_count']==1 and first['log_state']['active_incidents']
 second=record_readonly_slo_incidents(stop,log_path=p,now_utc=NOW+timedelta(minutes=1))
 assert second['suppressed'] is True and second['appended_count']==1
 healthy_reports=[validate_live_environment(fetcher=fetcher,now_utc=NOW+timedelta(hours=i+1)) for i in (0,1,2)]
 healthy=build_readonly_rolling_slo(healthy_reports,min_reports=3,operator_approved=True,now_utc=NOW+timedelta(hours=3))
 recovered=record_readonly_slo_incidents(healthy,log_path=p,now_utc=NOW+timedelta(hours=3))
 assert recovered['appended_count']==1 and not recovered['log_state']['active_incidents']
 assert verify_incident_log(p)['event_count']==3

def test_tamper_chain_rejected(tmp_path):
 p=tmp_path/'incidents.jsonl'; record_readonly_slo_incidents(make_slo(),log_path=p,now_utc=NOW)
 row=json.loads(p.read_text().splitlines()[0]); row['severity']='INFO'; p.write_text(json.dumps(row)+'\n')
 with pytest.raises(ValueError,match='hash_mismatch'):
  verify_incident_log(p)

def test_corrupt_chain_blocks_append(tmp_path):
 p=tmp_path/'incidents.jsonl'; p.write_text('{bad json}\n')
 with pytest.raises(ValueError,match='json_invalid'):
  record_readonly_slo_incidents(make_slo(),log_path=p,now_utc=NOW)

def test_safety_flags_always_false(tmp_path):
 out=record_readonly_slo_incidents(make_slo(),log_path=tmp_path/'incidents.jsonl',now_utc=NOW)
 assert out['training_allowed'] is False and out['live_orders'] is False
