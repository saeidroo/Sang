import numpy as np
import pandas as pd
import pytest
from backend.btc_dataset import build_btc_4h_dataset
from backend.btc_baseline import evaluate_btc_4h_baselines


def _candles(n=520):
    rng = np.random.default_rng(2026)
    close = 30000 * np.exp(np.cumsum(rng.normal(0, .006, n)))
    op = close * (1 + rng.normal(0, .001, n))
    return pd.DataFrame({'t': np.arange(n, dtype=np.int64)*14_400_000,
        'open': op, 'high': np.maximum(op, close)*1.002,
        'low': np.minimum(op, close)*.998, 'close': close,
        'volume': rng.lognormal(5, .4, n)})


def test_baselines_train_on_purged_folds_and_produce_oof_predictions():
    ds = build_btc_4h_dataset(_candles(), horizon_bars=6, embargo_bars=2, n_splits=3)
    result = evaluate_btc_4h_baselines(ds, require_lineage=False)
    assert {'majority', 'logistic_regression'} <= set(result['aggregate_metrics'])
    assert len(result['oof_predictions']) > 0
    assert set(result['oof_predictions'].model) <= {'majority', 'logistic_regression'}
    assert result['summary']['dataset_hash'] == ds['manifest']['dataset_hash']
    assert result['holdout_status'].startswith('NOT_USED')


def test_metrics_are_finite_and_class_order_is_explicit():
    ds = build_btc_4h_dataset(_candles(), n_splits=3)
    result = evaluate_btc_4h_baselines(ds, require_lineage=False)
    for metrics in result['aggregate_metrics'].values():
        for key in ('accuracy', 'balanced_accuracy', 'macro_f1', 'log_loss', 'brier_score'):
            assert np.isfinite(metrics[key])
        assert metrics['confusion_matrix_labels'] == [-1, 0, 1]


def test_rejects_corrupted_fold_with_train_validation_overlap():
    ds = build_btc_4h_dataset(_candles(), n_splits=3)
    ds['folds'][0]['validation_sample_indices'] = ds['folds'][0]['train_sample_indices'][:1]
    with pytest.raises(ValueError, match='overlap'):
        evaluate_btc_4h_baselines(ds, require_lineage=False)


def test_rejects_unpurged_training_labels():
    ds = build_btc_4h_dataset(_candles(), n_splits=3)
    ds['folds'][0]['train_sample_indices'][-1] = ds['folds'][0]['validation_start_original_pos'] - 1
    with pytest.raises((ValueError, IndexError)):
        evaluate_btc_4h_baselines(ds, require_lineage=False)
