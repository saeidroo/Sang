import pytest

from backend import paper_live, paper_process_lease


def test_direct_ledger_mutators_fail_closed_while_autopilot_lease_is_held(tmp_path, monkeypatch):
    db = tmp_path / 'paper.sqlite3'
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(db))
    lease = paper_process_lease.claim_lease(db, owner_token='autopilot-owner')
    assert lease['ok']

    guarded_calls = [
        lambda: paper_live.open_position('', 'LONG'),
        lambda: paper_live.close_position(1),
        lambda: paper_live.partial_close_position(1, 0.1, idempotency_key='guard-test'),
        lambda: paper_live.replay_position_candles(1, []),
        lambda: paper_live.get_state(refresh_quotes=False),
        lambda: paper_live.sync_open_funding_positions(force=True),
        lambda: paper_live.update_stop_price(1, 1.0),
        lambda: paper_live.update_trailing_state(1, 1.0, trigger_pct=1.0, distance_pct=0.5),
    ]
    try:
        for call in guarded_calls:
            with pytest.raises(RuntimeError, match='paper_ledger_owned_by_autopilot'):
                call()
    finally:
        paper_process_lease.release_lease(db, 'autopilot-owner')


def test_trusted_autopilot_context_can_call_guarded_functions(tmp_path, monkeypatch):
    db = tmp_path / 'paper.sqlite3'
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(db))
    lease = paper_process_lease.claim_lease(db, owner_token='autopilot-owner')
    assert lease['ok']
    monkeypatch.setattr(paper_live, 'get_consensus_quote', lambda *a, **k: (_ for _ in ()).throw(ValueError('reached normal validation path')))
    try:
        with paper_live.authorized_paper_writer():
            # Invalid input reaches normal function validation instead of lease rejection.
            with pytest.raises(ValueError):
                paper_live.open_position('', 'LONG')
            state = paper_live.get_state(refresh_quotes=False)
            assert isinstance(state, dict)
    finally:
        paper_process_lease.release_lease(db, 'autopilot-owner')


def test_direct_paper_calls_remain_available_without_active_lease(tmp_path, monkeypatch):
    db = tmp_path / 'paper.sqlite3'
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(db))
    monkeypatch.setattr(paper_live, 'get_consensus_quote', lambda *a, **k: (_ for _ in ()).throw(ValueError('reached normal validation path')))
    with pytest.raises(ValueError, match='reached normal validation path'):
        paper_live.open_position('', 'LONG')
