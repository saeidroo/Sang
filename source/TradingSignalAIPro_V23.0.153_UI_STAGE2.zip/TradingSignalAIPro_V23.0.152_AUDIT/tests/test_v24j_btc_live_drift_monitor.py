import json
import pytest
from backend.btc_live_drift_monitor import (evaluate_live_drift,
    append_live_drift_alert,audit_live_drift_alerts)


def test_live_drift_critical_blocks_training_and_alert_is_auditable(tmp_path):
    alert=evaluate_live_drift(live_report={'status':'PASS','latest_age_hours':2},
        reconciliation_report={'status':'BLOCKED','revision_count':1,'removed_count':0,'added_count':1})
    assert alert['status']=='CRITICAL' and alert['training_allowed'] is False
    path=tmp_path/'alerts.jsonl'
    result=append_live_drift_alert(alert,alerts_path=path)
    assert result['status']=='APPENDED'
    assert append_live_drift_alert(alert,alerts_path=path)['status']=='UNCHANGED'
    assert audit_live_drift_alerts(path)['latest_status']=='CRITICAL'


def test_live_drift_warns_on_stale_or_revision_threshold(tmp_path):
    stale=evaluate_live_drift(live_report={'status':'PASS','latest_age_hours':12},max_latest_age_hours=8)
    assert stale['status']=='CRITICAL'
    warning=evaluate_live_drift(reconciliation_report={'status':'PASS','revision_count':1,'removed_count':0,'added_count':2})
    assert warning['status']=='WARNING'


def test_live_drift_alert_chain_detects_tamper(tmp_path):
    path=tmp_path/'alerts.jsonl'
    alert=evaluate_live_drift(live_report={'status':'PASS','latest_age_hours':1})
    append_live_drift_alert(alert,alerts_path=path)
    row=json.loads(path.read_text()); row['alert']['status']='CRITICAL'
    path.write_text(json.dumps(row)+'\n')
    with pytest.raises(ValueError,match='hash_mismatch'):
        audit_live_drift_alerts(path)
