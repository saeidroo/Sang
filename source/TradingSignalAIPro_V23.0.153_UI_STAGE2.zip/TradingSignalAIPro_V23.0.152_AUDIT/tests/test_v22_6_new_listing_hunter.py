from backend.new_listing_hunter import _triage, discover_new_listings

NOW = 1_800_000_000_000

def test_new_listing_with_adequate_quote_volume_is_watch_only():
    row = {'symbol':'NEWUSDT','base':'NEW','exchange':'Binance','listed_at_ms':NOW-86_400_000,
           'price':'0.25','quote_volume':'2500000','trades':1200,'change_pct':'18'}
    out = _triage(row, NOW, 30)
    assert out['is_new'] is True
    assert out['status'] == 'cold_start_watch'
    assert out['entry_ready'] is False
    assert out['risk'] == 'very_high'

def test_unknown_listing_time_is_never_called_new():
    out = _triage({'symbol':'UNKUSDT','price':1,'quote_volume':500000,'trades':500}, NOW, 30)
    assert out['is_new'] is False
    assert out['status'] == 'age_unknown'
    assert out['age_days'] is None

def test_thin_market_is_blocked():
    out = _triage({'symbol':'THINUSDT','listed_at_ms':NOW-1000,'price':1,'quote_volume':1000,'trades':4}, NOW, 30)
    assert out['status'] == 'thin_market'
    assert out['entry_ready'] is False

def test_old_listing_is_not_new():
    out = _triage({'symbol':'OLDUSDT','listed_at_ms':NOW-60*86_400_000,'price':1,'quote_volume':2e6,'trades':500}, NOW, 30)
    assert out['status'] == 'not_new'
    assert out['is_new'] is False

def test_discovery_merges_sources_and_preserves_unknown_age():
    def fake(url, params=None):
        if 'binance.com/api/v3/exchangeInfo' in url:
            return {'symbols':[{'symbol':'AAAUSDT','baseAsset':'AAA','quoteAsset':'USDT','status':'TRADING','onboardDate':NOW-86_400_000}]}
        if 'binance.com/api/v3/ticker/24hr' in url:
            return [{'symbol':'AAAUSDT','lastPrice':'1','quoteVolume':'2000000','count':1000,'priceChangePercent':'5'}]
        if 'mexc.com' in url:
            if 'exchangeInfo' in url:return {'symbols':[{'symbol':'BBBUSDT','baseAsset':'BBB','quoteAsset':'USDT','status':'1'}]}
            return [{'symbol':'BBBUSDT','lastPrice':'2','quoteVolume':'500000','count':300,'priceChangePercent':'3'}]
        if 'bybit.com' in url:
            if 'instruments-info' in url:return {'result':{'list':[{'symbol':'CCCUSDT','baseCoin':'CCC','quoteCoin':'USDT','status':'Trading','launchTime':str(NOW-2*86_400_000)}]}}
            return {'result':{'list':[{'symbol':'CCCUSDT','lastPrice':'3','turnover24h':'3000000','price24hPcnt':'0.1'}]}}
        raise AssertionError(url)
    result=discover_new_listings(30,30,fetch_json=fake,now_ms=NOW)
    by={x['base']:x for x in result['items']}
    assert set(by)=={'AAA','BBB','CCC'}
    assert by['AAA']['status']=='cold_start_watch'
    assert by['BBB']['status']=='age_unknown'
    assert by['CCC']['status']=='cold_start_watch'  # trade count unavailable, volume still assessed
    assert all(not x['entry_ready'] for x in result['items'])
