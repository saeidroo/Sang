"""V23.0.2 config validation, Custom preset, atomic persistence and migration."""
import json
from pathlib import Path
from unittest.mock import patch

from backend import autopilot


def _reset_config():
    autopilot._CONFIG.clear()
    autopilot._CONFIG.update(autopilot.DEFAULT_CONFIG)


def test_default_config_exposes_all_risk_controls():
    expected = {
        "max_open_positions", "max_position_notional_pct", "risk_per_trade_pct",
        "stop_loss_pct", "take_profit_pct", "max_daily_loss_pct", "max_drawdown_pct",
    }
    assert expected.issubset(autopilot.DEFAULT_CONFIG)
    assert autopilot._risk_overrides()["risk_per_trade_pct"] == autopilot.DEFAULT_CONFIG["risk_per_trade_pct"]


def test_custom_settings_persist_and_reload(tmp_path):
    path = tmp_path / "autopilot_config.json"
    with patch.object(autopilot, "_config_path", return_value=path), \
         patch.object(autopilot, "_log_decision", return_value=None), \
         patch.object(autopilot, "status", side_effect=lambda: {"config": dict(autopilot._CONFIG),
                                                               "risk_overrides": autopilot._risk_overrides()}):
        _reset_config()
        result = autopilot.update_config({
            "risk_preset": "custom", "max_open_positions": 2,
            "max_position_notional_pct": 17.0, "risk_per_trade_pct": 0.35,
            "stop_loss_pct": 1.2, "take_profit_pct": 2.8,
            "max_daily_loss_pct": 2.5, "max_drawdown_pct": 8.0,
            "brain_mode": "ml_only", "timeframe": "4h", "markets": ["perp"],
        })
        assert result["config"]["risk_preset"] == "custom"
        assert result["risk_overrides"]["max_open_positions"] == 2.0
        assert result["risk_overrides"]["max_position_notional_pct"] == 17.0
        assert result["risk_overrides"]["risk_per_trade_pct"] == 0.35
        assert result["risk_overrides"]["stop_loss_pct"] == 1.2
        assert result["risk_overrides"]["take_profit_pct"] == 2.8
        assert result["risk_overrides"]["max_daily_loss_pct"] == 2.5
        assert result["risk_overrides"]["max_drawdown_pct"] == 8.0
        saved = json.loads(path.read_text(encoding="utf-8"))
        assert saved["risk_per_trade_pct"] == 0.35

        _reset_config()
        autopilot._load_config()
        assert autopilot._CONFIG["risk_preset"] == "custom"
        assert autopilot._CONFIG["max_open_positions"] == 2
        assert autopilot._CONFIG["max_position_notional_pct"] == 17.0
        assert autopilot._CONFIG["risk_per_trade_pct"] == 0.35
        assert autopilot._CONFIG["max_daily_loss_pct"] == 2.5
        assert autopilot._CONFIG["max_drawdown_pct"] == 8.0
        assert autopilot._CONFIG["brain_mode"] == "ml_only"
        assert autopilot._CONFIG["timeframe"] == "4h"
        assert autopilot._CONFIG["markets"] == ["perp"]


def test_named_preset_updates_all_preset_risk_fields(tmp_path):
    path = tmp_path / "autopilot_config.json"
    with patch.object(autopilot, "_config_path", return_value=path), \
         patch.object(autopilot, "_log_decision", return_value=None), \
         patch.object(autopilot, "status", side_effect=lambda: {"config": dict(autopilot._CONFIG),
                                                               "risk_overrides": autopilot._risk_overrides()}):
        _reset_config()
        result = autopilot.update_config({"risk_preset": "conservative"})
        cfg = result["config"]
        for key, value in autopilot.RISK_PRESETS["conservative"].items():
            assert cfg[key] == value
        assert cfg["risk_preset"] == "conservative"
        _reset_config()
        autopilot._load_config()
        assert autopilot._CONFIG["risk_preset"] == "conservative"
        assert autopilot._CONFIG["max_open_positions"] == autopilot.RISK_PRESETS["conservative"]["max_open_positions"]
        assert autopilot._CONFIG["risk_per_trade_pct"] == autopilot.RISK_PRESETS["conservative"]["risk_per_trade_pct"]


def test_manual_preset_value_edit_switches_to_custom(tmp_path):
    path = tmp_path / "autopilot_config.json"
    with patch.object(autopilot, "_config_path", return_value=path), \
         patch.object(autopilot, "_log_decision", return_value=None), \
         patch.object(autopilot, "status", side_effect=lambda: {"config": dict(autopilot._CONFIG),
                                                               "risk_overrides": autopilot._risk_overrides()}):
        _reset_config()
        result = autopilot.update_config({
            "risk_preset": "balanced", "max_open_positions": 2,
            "max_position_notional_pct": 10.0, "risk_per_trade_pct": 1.0,
            "stop_loss_pct": 1.5, "take_profit_pct": 3.0,
        })
        assert result["config"]["risk_preset"] == "custom"
        assert result["config"]["max_open_positions"] == 2


def test_invalid_config_is_rejected_without_mutation_or_file_write(tmp_path):
    path = tmp_path / "autopilot_config.json"
    with patch.object(autopilot, "_config_path", return_value=path), \
         patch.object(autopilot, "_log_decision", return_value=None), \
         patch.object(autopilot, "status", return_value={}):
        _reset_config()
        before = dict(autopilot._CONFIG)
        try:
            autopilot.update_config({"risk_preset": "custom", "max_open_positions": 0,
                                     "stop_loss_pct": -1, "markets": []})
        except ValueError:
            pass
        else:
            raise AssertionError("invalid config should raise ValueError")
        assert autopilot._CONFIG == before
        assert not path.exists()


def test_legacy_config_migrates_named_preset(tmp_path):
    path = tmp_path / "autopilot_config.json"
    path.write_text(json.dumps({"risk_preset": "conservative", "brain_mode": "ml_only"}), encoding="utf-8")
    with patch.object(autopilot, "_config_path", return_value=path):
        _reset_config()
        autopilot._load_config()
    assert autopilot._CONFIG["risk_preset"] == "conservative"
    assert autopilot._CONFIG["max_open_positions"] == autopilot.RISK_PRESETS["conservative"]["max_open_positions"]
    assert autopilot._CONFIG["max_position_notional_pct"] == autopilot.RISK_PRESETS["conservative"]["max_position_notional_pct"]
    assert autopilot._CONFIG["risk_per_trade_pct"] == autopilot.RISK_PRESETS["conservative"]["risk_per_trade_pct"]
    assert autopilot._CONFIG["brain_mode"] == "ml_only"


def test_corrupt_config_falls_back_to_valid_defaults(tmp_path):
    path = tmp_path / "autopilot_config.json"
    path.write_text("{not-json", encoding="utf-8")
    with patch.object(autopilot, "_config_path", return_value=path):
        _reset_config()
        autopilot._load_config()
    assert autopilot._CONFIG == autopilot.DEFAULT_CONFIG


def test_failed_atomic_write_does_not_publish_runtime_config(tmp_path):
    with patch.object(autopilot, "_save_config", side_effect=OSError("disk full")), \
         patch.object(autopilot, "_log_decision", return_value=None), \
         patch.object(autopilot, "status", return_value={}):
        _reset_config()
        before = dict(autopilot._CONFIG)
        try:
            autopilot.update_config({"risk_preset": "custom", "max_open_positions": 2})
        except OSError:
            pass
        else:
            raise AssertionError("persistence failure should be surfaced")
        assert autopilot._CONFIG == before
