import pytest
from backend.opportunity_ranking import rank_opportunities


def c(symbol, score, group=None, coverage=.9, classification='STRONG_CANDIDATE', blockers=None):
    return {'symbol': symbol, 'market': 'perp', 'timeframe': '1h',
            'opportunity_quality_index': score, 'evidence_coverage': coverage,
            'classification': classification, 'correlation_group': group, 'blockers': blockers or []}


def test_ranks_best_first_and_is_deterministic():
    r = rank_opportunities([c('ETHUSDT', 80), c('BTCUSDT', 90)], max_per_group=1)
    assert [x['symbol'] for x in r['ranked_opportunities']] == ['BTCUSDT', 'ETHUSDT']
    assert [x['rank'] for x in r['ranked_opportunities']] == [1, 2]


def test_diversification_limits_correlated_candidates():
    r = rank_opportunities([c('BTCUSDT', 90, 'majors'), c('ETHUSDT', 88, 'majors'), c('SOLUSDT', 80, 'alt')])
    assert [x['symbol'] for x in r['ranked_opportunities']] == ['BTCUSDT', 'SOLUSDT']
    assert any(x['reason'] == 'DIVERSIFICATION_LIMIT' for x in r['rejected'])


def test_blocked_low_quality_and_low_score_are_excluded():
    r = rank_opportunities([c('BTCUSDT', 90, blockers=['NO_TRADE']),
                            c('ETHUSDT', 30),
                            c('SOLUSDT', 70, classification='INSUFFICIENT_EVIDENCE')])
    assert not r['ranked_opportunities']


def test_duplicate_and_invalid_records_are_rejected():
    r = rank_opportunities([c('BTCUSDT', 80), c('BTCUSDT', 85), {'symbol': 'BAD', 'opportunity_quality_index': 60}])
    assert r['ranked_count'] == 1
    assert r['rejected_count'] == 2


def test_paper_only_flags_and_validation():
    r = rank_opportunities([c('BTCUSDT', 80)])
    assert r['authorizes_entries'] is False
    assert r['real_orders_enabled'] is False
    assert r['paper_only'] and r['read_only']
    with pytest.raises(ValueError):
        rank_opportunities([], limit=0)
