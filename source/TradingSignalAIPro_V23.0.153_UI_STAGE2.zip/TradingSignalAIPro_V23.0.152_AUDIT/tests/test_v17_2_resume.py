"""V17.2: resumable multi-hour training, trial checkpoints, signal strength,
AI coach sanitisation and the .env loader."""
import json
import os
import time

import numpy as np
import pandas as pd
import pytest

from backend import ai_coach, env as env_mod, longrun, strength, trainer


# ---------------------------------------------------------------- strength
def test_strength_profiles_are_bounded_and_backward_compatible():
    conservative = strength.get_profile('conservative')
    assert conservative['entry_net_score'] == 2.0           # old V17.1 behaviour
    assert conservative['brain_min_support'] == 2
    assert conservative['brain_min_coverage'] == 0.48
    for name, prof in strength.PROFILES.items():
        assert 1.0 <= prof['entry_net_score'] <= 2.0
        assert 0 <= prof['power_boost'] <= 0.2
        assert prof['brain_min_coverage'] >= 0.30           # never recklessly loose
    with pytest.raises(ValueError):
        strength.normalize_strength('bogus')
    with pytest.raises(ValueError):
        strength.normalize_strength(None, default='also-bogus')


def _signal_frame():
    n = 25
    close = np.full(n, 100.0)
    # volume above its own 20-bar mean (which includes this bar) so the
    # volume-confirmation bonus (+0.5) fires deterministically
    volume = np.full(n, 10.0)
    volume[-1] = 12.0
    return pd.DataFrame({
        't': 1_700_000_000_000 + np.arange(n) * 3_600_000,
        'open': close, 'high': close + 1, 'low': close - 1, 'close': close,
        'volume': volume,
        'atr_14': np.full(n, 1.0),
        'ema_20': close - 1.0,      # price > e20 > e50 -> full uptrend +1.5
        'ema_50': close - 2.0,
        'rsi_14': np.full(n, 50.0),
        'macd_hist': np.full(n, np.nan),
        'bb_pct': np.full(n, 0.85),  # near upper band -> bear +0.5
    })


def test_assertive_profile_produces_signal_where_conservative_holds():
    frame = _signal_frame()
    prob = 0.55                       # model_conf = 0.1 -> bull 0.3 + 1.5 trend + 0.5 vol
    from backend.signal import compute_signal
    sig_cons = compute_signal(frame, prob, threshold=0.55, strength='conservative')
    sig_assert = compute_signal(frame, prob, threshold=0.55, strength='assertive')
    sig_bal = compute_signal(frame, prob, threshold=0.55, strength='balanced')
    assert sig_cons['kind'] == 'HOLD'
    assert sig_bal['kind'] == 'HOLD'
    assert sig_assert['kind'] == 'BUY'
    assert sig_assert['net_score'] == pytest.approx(1.8, abs=1e-6)
    assert sig_assert['strength_profile'] == 'assertive'


def test_oos_edge_gate_threshold_floor_depends_on_profile():
    from backend.signal import apply_oos_edge_gate
    meta = {'edge_confirmed': True, 'best_threshold': 0.6}
    sig = {'kind': 'BUY', 'power': 0.5}
    _, thr_cons, edge = apply_oos_edge_gate(sig, meta, 0.70, strength='conservative')
    assert edge and thr_cons == 0.70          # user can only be stricter
    _, thr_assert, edge = apply_oos_edge_gate(sig, meta, 0.70, strength='assertive')
    assert edge and thr_assert == 0.60        # OOF-selected threshold governs
    sig_noedge = {'kind': 'BUY', 'power': 0.9}
    _, _, edge = apply_oos_edge_gate(sig_noedge, {'edge_confirmed': False}, 0.6,
                                     strength='assertive')
    assert edge is False                      # edge gate is never bypassed


# ---------------------------------------------------------------- brain
def _brain_indicator_frame():
    # price > e20 but e20 < e50 (mixed trend) plus a below-price supertrend:
    # the technical vote stays far below the 0.15 directionality bar, so the
    # ML channel is the ONLY directional source.
    n = 50
    close = np.full(n, 100.0)
    return pd.DataFrame({
        't': 1_700_000_000_000 + np.arange(n) * 3_600_000,
        'close': close,
        'ema_20': close - 0.5,     # 99.5 -> price above it, but e20 < e50
        'ema_50': close - 0.2,     # 99.8
        'macd_hist': np.full(n, 1e-9),       # ~0 vote
        'plus_di': np.full(n, 12.5),
        'minus_di': np.full(n, 12.5),        # flat -> 0
        'cmf_20': np.full(n, 0.002),         # tiny
        'supertrend': close + 1.0,           # above price -> -1 vote
    })


def test_brain_support_requirement_depends_on_strength(tmp_path, monkeypatch):
    monkeypatch.setenv('TS_AI_BRAIN_DB', str(tmp_path / 'brain.sqlite3'))
    from backend import brain
    frame = _brain_indicator_frame()
    base = {'kind': 'BUY', 'reason': 'base', 'power': 0.7, 'meta_blocked': False}
    result_cons = brain.make_brain_decision(
        'BTCUSDT', '1h', int(frame.t.iloc[-1]), float(frame.close.iloc[-1]), 0.68,
        frame, edge_confirmed=True, base_signal=dict(base), strength='conservative')
    assert result_cons['final_signal'] == 'HOLD'
    assert any('منبع مستقل' in v for v in result_cons['vetoes'])
    base2 = {'kind': 'BUY', 'reason': 'base', 'power': 0.7, 'meta_blocked': False}
    result_assert = brain.make_brain_decision(
        'BTCUSDT', '1h', int(frame.t.iloc[-1]), float(frame.close.iloc[-1]), 0.68,
        frame, edge_confirmed=True, base_signal=base2, strength='assertive')
    assert result_assert['final_signal'] == 'BUY'
    assert base2['brain_confirmed'] is True
    # power is boosted, not clipped down, in the assertive profile
    assert base2['power'] >= 0.7


# ---------------------------------------------------------------- longrun
def test_dropped_markets_are_requeued_not_lost_forever():
    jobs = [{'symbol': 'A', 'timeframe': '1h', 'rounds': 1, 'fails': 2,
             'status': 'dropped', 'last_end_ts': 1.0, 'last': None, 'error': None}]
    assert longrun._requeue_dropped(jobs, 40) is True
    assert jobs[0]['status'] == 'queued' and jobs[0]['fails'] == 0
    # queued jobs are not dropped again, so a second call finds nothing
    assert longrun._requeue_dropped(jobs, 40) is False
    # a job that already used all rounds is never resurrected
    exhausted = [{'symbol': 'B', 'timeframe': '1h', 'rounds': 40, 'fails': 2,
                  'status': 'dropped', 'last_end_ts': 1.0, 'last': None, 'error': None}]
    assert longrun._requeue_dropped(exhausted, 40) is False


def test_resumable_state_survives_a_restart(tmp_path, monkeypatch):
    monkeypatch.setattr(longrun, '_state_file', lambda: tmp_path / 'longrun_state.json')
    now = time.time()
    cfg = {'hours': 2, 'symbols': ['BTCUSDT'], 'timeframes': ['1h'],
           'limit': 3000, 'trials': 12, 'max_rounds': 40}
    jobs = [{'symbol': 'BTCUSDT', 'timeframe': '1h', 'rounds': 3, 'fails': 0,
             'status': 'trained', 'last_end_ts': now, 'last': {'balanced_acc': 0.55},
             'error': None, 'coach_hints': None}]
    longrun._STATE.update(running=True, phase='running', started_at=now - 1000,
                          deadline_ts=now + 3600, config=cfg, jobs=jobs,
                          trainings_done=3, promoted=1, kept_old=2, failed=0,
                          rounds_done=3, current=None)
    longrun._persist()
    info = longrun.resumable()
    assert info and info['resumable'] is True
    assert info['jobs_total'] == 1 and info['jobs_done'] == 1
    assert info['trainings_done'] == 3
    assert info['remaining_sec'] > 3000
    assert info['interrupted'] is True
    # after 72h nothing is resumable any more
    longrun._STATE['started_at'] = now - 80 * 3600
    longrun._persist()
    assert longrun.resumable() is None
    longrun._STATE.update(running=False, phase='idle', started_at=None)


def test_start_with_resume_restores_previous_progress(monkeypatch):
    captured = {}

    def fake_worker(cfg, resume_state=None):
        captured['cfg'] = cfg
        captured['resume_state'] = resume_state

    monkeypatch.setattr(longrun, '_worker', fake_worker)
    monkeypatch.setattr(longrun, 'resumable',
                        lambda: {'resumable': True, 'remaining_sec': 600,
                                 'trainings_done': 5, 'config': {}})
    cfg = longrun.start({'hours': 1, 'preset': 'core5'}, resume=True)
    assert cfg['symbols'][0] == 'BTCUSDT'
    thread = longrun._THREAD
    thread.join(timeout=5)
    assert captured['resume_state']['trainings_done'] == 5
    assert captured['resume_state']['remaining_sec'] == 600
    # fresh start (resume=False) passes no state
    longrun._STATE.update(running=False)
    longrun.start({'hours': 0.2, 'preset': 'core5'}, resume=False)
    longrun._THREAD.join(timeout=5)
    assert captured['resume_state'] is None
    longrun._STATE.update(running=False, phase='idle', started_at=None)


def test_worker_resume_reuses_rounds_and_time_budget():
    cfg = {'hours': 1, 'symbols': ['BTCUSDT'], 'timeframes': ['1h'],
           'limit': 3000, 'trials': 8, 'max_rounds': 3}
    resume = {'trainings_done': 7, 'promoted': 3, 'kept_old': 4,
              'deadline_ts': time.time() + 900,
              'jobs': [{'symbol': 'BTCUSDT', 'timeframe': '1h', 'rounds': 2,
                        'fails': 2, 'status': 'dropped', 'last': {'balanced_acc': .5},
                        'error': 'x', 'coach_hints': {'lightgbm': {'num_leaves': 10}}},
                       {'symbol': 'ETHUSDT', 'timeframe': '1h', 'rounds': 0,
                        'fails': 0, 'status': 'queued', 'last': None,
                        'error': None, 'coach_hints': None}]}
    # emulate only the restore block of _worker by running it against a session
    # stub that records the first job it is asked to train
    class StubSession:
        is_running = False
        def run(self, **kwargs):
            raise RuntimeError('stop here')

    import types
    real_run_one = longrun._run_one
    seen = {}

    def fake_run_one(job, cfg_, session):
        seen['rounds'] = job['rounds']
        seen['hints'] = job.get('coach_hints')
        raise RuntimeError('done')

    longrun._run_one = fake_run_one
    longrun._STOP.clear()
    try:
        longrun._worker(cfg, resume)
    finally:
        longrun._run_one = real_run_one
        longrun._STOP.set()
        longrun._STOP.clear()
    assert seen['rounds'] == 2
    assert seen['hints'] == {'lightgbm': {'num_leaves': 10}}
    state = longrun._public_state()
    assert state['trainings_done'] == 7
    assert state['resumed_from']['trainings_done'] == 7
    assert state['running'] is False


# ---------------------------------------------------------------- trainer ckpt
def test_trial_checkpoint_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(tmp_path))
    payload = {'data_fp': 'fp1', 'grid_fp': 'grid1', 'top_feats': ['a', 'b'],
               'trials': {'0': {'val_acc': 0.5}}}
    trainer._save_checkpoint('BTCUSDT', '1h', payload)
    loaded = trainer._load_checkpoint('BTCUSDT', '1h')
    assert loaded['data_fp'] == 'fp1' and loaded['grid_fp'] == 'grid1'
    assert loaded['trials']['0']['val_acc'] == 0.5
    trainer._clear_checkpoint('BTCUSDT', '1h')
    assert trainer._load_checkpoint('BTCUSDT', '1h') == {}


def test_trial_score_formula_stays_identical():
    trial = {'val_balanced': 0.6, 'val_acc': 0.55,
             'val_high_conf_acc': 0.7, 'val_high_conf_cov': 0.2,
             'val_very_high_conf_acc': 0.8, 'val_very_high_conf_cov': 0.1,
             'val_ultra_conf_acc': 0.9, 'val_ultra_conf_cov': 0.05,
             'sim_win_rate_60': 0.6, 'sim_trades_60': 12}
    inline = (0.70 * 0.6 + 0.30 * 0.55
              + 0.20 * max(0.0, 0.7 - 0.6) * 0.2
              + 0.25 * max(0.0, 0.8 - 0.6) * 0.1
              + 0.30 * max(0.0, 0.9 - 0.6) * 0.05
              + 0.6 * (0.6 - 0.5))
    assert abs(trainer._trial_score(trial) - inline) < 1e-12
    # guard: a low-sample sim must not receive the bonus
    low = dict(trial, sim_trades_60=5)
    inline_low = inline - 0.6 * (0.6 - 0.5)
    assert abs(trainer._trial_score(low) - inline_low) < 1e-12


# ---------------------------------------------------------------- ai coach
def test_coach_hints_are_sanitized_into_safe_region():
    hint = ai_coach.sanitize_hint({'xgboost': {'max_depth': 20, 'learning_rate': 0.5,
                                               'n_estimators': 99999, 'junk': 3}})
    assert hint['xgboost']['max_depth'] == 6
    assert hint['xgboost']['learning_rate'] == 0.10
    assert hint['xgboost']['n_estimators'] == 400
    assert 'junk' not in hint['xgboost']
    hint2 = ai_coach.sanitize_hint({'lightgbm': {'num_leaves': 1, 'reg_lambda': 100}})
    assert hint2['lightgbm']['num_leaves'] == 4
    assert hint2['lightgbm']['reg_lambda'] == 7.0
    assert ai_coach.sanitize_hint({'unknown_model': {'x': 1}}) is None
    assert ai_coach.sanitize_hint('not-a-dict') is None
    assert ai_coach.sanitize_hint({}) is None


def test_coach_json_extraction_tolerates_fences():
    text = ("Sure! Here you go:\n```json\n"
            "{\"assessment\": \"ok\", \"verdict\": \"explore\", "
            "\"hp_hints\": {\"lightgbm\": {\"num_leaves\": 99}}}\n```")
    data = ai_coach._extract_json(text)
    assert data and data['verdict'] == 'explore'
    assert ai_coach._extract_json('no json here') is None


def test_coach_disabled_without_key():
    monkey = pytest.MonkeyPatch()
    monkey.delenv('ZAI_API_KEY', raising=False)
    monkey.delenv('AI_COACH_API_KEY', raising=False)
    info = ai_coach.coach_available()
    assert info['available'] is False
    reply = ai_coach.ask_coach({'symbol': 'BTCUSDT'})
    assert reply['available'] is False
    monkey.undo()


# ---------------------------------------------------------------- env loader
def test_env_loader_sets_new_keys_and_never_overrides_real_env(tmp_path):
    f = tmp_path / '.env'
    f.write_text('TS_AI_TEST_VAR=hello\n'
                 'TS_AI_TEST_VAR2="quoted"\n'
                 '# comment line\n'
                 '\n'
                 'export TS_AI_TEST_VAR3=exported\n', encoding='utf-8')
    for key in ('TS_AI_TEST_VAR', 'TS_AI_TEST_VAR2', 'TS_AI_TEST_VAR3'):
        os.environ.pop(key, None)
    applied = env_mod.load_dotenv(f)
    assert 'TS_AI_TEST_VAR' in applied
    assert os.environ['TS_AI_TEST_VAR'] == 'hello'
    assert os.environ['TS_AI_TEST_VAR2'] == 'quoted'
    assert os.environ['TS_AI_TEST_VAR3'] == 'exported'
    os.environ['TS_AI_TEST_VAR'] = 'env-wins'
    env_mod.load_dotenv(f)
    assert os.environ['TS_AI_TEST_VAR'] == 'env-wins'
    for key in ('TS_AI_TEST_VAR', 'TS_AI_TEST_VAR2', 'TS_AI_TEST_VAR3'):
        os.environ.pop(key, None)


# ---------------------------------------------------------------- api routes
def test_new_v172_api_routes():
    from backend.api import app
    client = app.test_client()
    r = client.get('/api/longrun/resumable')
    assert r.status_code == 200 and r.is_json and 'resumable' in r.get_json()
    r = client.get('/api/ai/coach')
    assert r.status_code == 200 and 'available' in r.get_json()
    r = client.post('/api/analyze',
                    json={'symbol': 'BTCUSDT', 'timeframe': '1h', 'strength': 'bogus'})
    assert r.status_code == 400
    r = client.post('/api/longrun/start', json={'hours': 999, 'resume': True})
    assert r.status_code == 400
