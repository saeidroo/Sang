import json
import time
import pytest


def _seed_events(paper_live, tags_and_pnls):
    paper_live.init_db(backfill_learning=False)
    with paper_live._connect() as conn:
        for i, (tag, pnl) in enumerate(tags_and_pnls, 1):
            context = {'decision_context': {'market_regime': tag}} if tag else {}
            conn.execute('''INSERT INTO paper_learning_events
                (trade_id,closed_at,symbol,market,timeframe,exchange,side,exit_reason,outcome,net_pnl,
                 return_pct,duration_seconds,notional,gross_pnl,total_fees,entry_fill,exit_fill,context_json)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (i, time.time(), 'BTCUSDT', 'perp', '1h', 'binance', 'LONG', 'TEST',
                 int(pnl > 0), pnl, pnl, 60, 100, pnl, 0, 100, 100, json.dumps(context)))


def test_regime_selection_uses_only_matching_explicit_regime(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'regime_select.sqlite3'))
    paper_live._CACHE.clear()
    _seed_events(paper_live, [('UPTREND', 5), ('UPTREND', 3), ('DOWNTREND', -8), ('', 9)])
    report = paper_live.get_regime_aware_strategy_selection(regime='UPTREND', min_trades=2)
    key = ('BTCUSDT', 'perp', '1h', 'LONG')
    assert report['regime_trade_count'] == 2
    assert report['untagged_trade_count'] == 1
    assert report['adjustments'][key]['trade_count'] == 2
    assert report['adjustments'][key]['eligible'] is True
    assert 0.9 <= report['adjustments'][key]['multiplier'] <= 1.1
    assert report['read_only'] is True
    assert report['real_orders_enabled'] is False


def test_regime_selection_rejects_unknown_regime(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'bad_regime.sqlite3'))
    paper_live._CACHE.clear()
    with pytest.raises(ValueError, match='regime'):
        paper_live.get_regime_aware_strategy_selection(regime='MAGIC', min_trades=2)


def test_regime_selection_small_sample_remains_ineligible(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'small_sample.sqlite3'))
    paper_live._CACHE.clear()
    _seed_events(paper_live, [('RANGE', 100)])
    report = paper_live.get_regime_aware_strategy_selection(regime='RANGE', min_trades=5)
    item = report['adjustments'][('BTCUSDT', 'perp', '1h', 'LONG')]
    assert item['eligible'] is False
    assert item['trade_count'] == 1
