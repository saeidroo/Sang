import pandas as pd
from backend.cold_start_analyzer import analyze_new_listing, _analyze_frame


def frame(n=240, trend='up'):
    close = [100 + i*0.2 if trend == 'up' else 100-i*0.1 for i in range(n)]
    return pd.DataFrame({'open': close, 'high':[x+1 for x in close], 'low':[x-1 for x in close],
                         'close': close, 'volume':[1000+i for i in range(n)]})


def test_short_history_is_fail_closed():
    r=_analyze_frame(frame(30), '5m')
    assert r['status']=='insufficient_history'


def test_supported_exchange_uses_exchange_specific_source_and_no_entry():
    calls=[]
    def fake(symbol, tf, limit, **kwargs):
        calls.append((symbol,tf,kwargs['source']))
        return frame()
    r=analyze_new_listing('Binance','ABCUSDT','ABC','USDT',fetcher=fake)
    assert calls==[('ABCUSDT','5m','binance'),('ABCUSDT','15m','binance'),('ABCUSDT','1h','binance')]
    assert r['status']=='identity_unverified'
    assert r['identity_status']=='contract_identity_unverified'
    assert r['entry_ready'] is False
    assert all(x['status']=='analysis_ready' for x in r['analyses'])


def test_contract_identity_mismatch_blocks_fetch():
    def forbidden(*a,**k): raise AssertionError('must not fetch')
    r=analyze_new_listing('Bybit','OTHERUSDT','ABC','USDT',fetcher=forbidden)
    assert r['status']=='pair_identity_mismatch'


def test_unknown_exchange_is_rejected():
    r=analyze_new_listing('Unknown','ABCUSDT','ABC','USDT',fetcher=lambda *a,**k: frame())
    assert r['status']=='unsupported_pair'


def test_missing_history_in_one_timeframe_blocks_readiness():
    def fake(symbol, tf, limit, **kwargs): return frame(100 if tf=='1h' else 240)
    r=analyze_new_listing('MEXC','ABCUSDT','ABC','USDT',fetcher=fake)
    assert r['status']=='insufficient_history'
    assert r['multi_timeframe_alignment'] is None
    assert r['entry_ready'] is False
