from backend.market_brain import _classify_extreme_window


def candle(high, low):
    return ("BTCUSDT", 0, 100.0, high, low, 100.0, 10.0)


def test_detects_intraday_pump_even_when_final_close_returns_to_start():
    rows = [candle(111.0, 99.0)] + [candle(101.0, 99.0) for _ in range(23)]
    assert _classify_extreme_window(100.0, rows) == (True, False)


def test_detects_intraday_dump_even_when_final_close_recovers():
    rows = [candle(101.0, 89.0)] + [candle(101.0, 99.0) for _ in range(23)]
    assert _classify_extreme_window(100.0, rows) == (False, True)


def test_preserves_both_directions_in_whipsaw_window():
    rows = [candle(112.0, 88.0)] + [candle(101.0, 99.0) for _ in range(23)]
    assert _classify_extreme_window(100.0, rows) == (True, True)


def test_invalid_or_empty_windows_are_not_labeled():
    assert _classify_extreme_window(100.0, []) == (False, False)
    assert _classify_extreme_window(0.0, [candle(120.0, 80.0)]) == (False, False)
    assert _classify_extreme_window(100.0, [("x", 0, 1, "bad", 90, 100, 1)]) == (False, False)
