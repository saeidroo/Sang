from backend.market_brain import _summarize_extreme_counts


def test_historical_extremes_require_minimum_samples():
    result = _summarize_extreme_counts(3, 1)
    assert result['historical_bias'] == 'insufficient_samples'
    assert result['evidence_reliability'] == 'low'
    assert result['samples'] == 4
    assert result['is_forecast'] is False


def test_historical_pump_pattern_is_identified_only_with_directional_evidence():
    result = _summarize_extreme_counts(14, 4)
    assert result['historical_bias'] == 'pump_favored'
    assert result['pump_share_pct'] == 77.8
    assert result['evidence_reliability'] == 'moderate'


def test_historical_dump_pattern_is_independent_from_pump_pattern():
    result = _summarize_extreme_counts(2, 8)
    assert result['historical_bias'] == 'dump_favored'
    assert result['dump_share_pct'] == 80.0
    assert result['event_definition'] == 'next_24_closed_1h_candles_high_low_excursion_at_least_10pct'


def test_balanced_extreme_history_stays_mixed():
    result = _summarize_extreme_counts(9, 8)
    assert result['historical_bias'] == 'mixed'
    assert result['samples'] == 17
