import numpy as np
import pandas as pd

from backend.scout import volume_flow_features


def _frame(volumes, buy_fractions, closes=None):
    n = len(volumes)
    if closes is None:
        closes = np.linspace(100.0, 99.8, n)
    closes = np.asarray(closes, dtype=float)
    return pd.DataFrame({
        'open': closes,
        'high': closes * 1.002,
        'low': closes * 0.998,
        'close': closes,
        'volume': np.asarray(volumes, dtype=float),
        'taker_buy_base_volume': np.asarray(volumes, dtype=float) * np.asarray(buy_fractions, dtype=float),
    })


def test_dump_requires_persistent_sell_pressure_not_just_negative_volume_delta():
    volumes = [100.0] * 112 + [100, 100, 100, 100, 40, 300, 300, 100]
    fractions = [0.5] * 112 + [0.9, 0.9, 0.9, 0.9, 0.9, 0.05, 0.05, 0.9]
    result = volume_flow_features(_frame(volumes, fractions))

    assert result['flow_delta_ratio'] < 0
    assert result['buy_flow_persistence'] > result['sell_flow_persistence']
    assert result['pre_dump_candidate'] is False


def test_persistent_sell_flow_can_still_qualify_as_pre_dump():
    volumes = [100.0] * 112 + [100.0] * 4 + [180.0] * 4
    fractions = [0.5] * 112 + [0.2] * 8
    result = volume_flow_features(_frame(volumes, fractions))

    assert result['sell_flow_persistence'] == 1.0
    assert result['sell_pressure_ratio'] > 0.57
    assert result['pre_dump_candidate'] is True
