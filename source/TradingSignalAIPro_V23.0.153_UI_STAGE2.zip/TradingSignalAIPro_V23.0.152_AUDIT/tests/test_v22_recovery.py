import json, sqlite3
from pathlib import Path
import pytest
from backend import evaluation, experiment_registry, recovery


def _setup(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_MODELS_DIR', str(tmp_path/'models'))
    monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR', str(tmp_path/'trusted-keys'))
    monkeypatch.setenv('TRADING_AI_V22_PAPER_DB', str(tmp_path/'models'/'paper.sqlite3'))
    experiment_registry.register_hypothesis('H1','test','test',custom_dir=tmp_path/'models')
    started=experiment_registry.start_experiment('H1',symbol='BTCUSDT',timeframe='4h',data_hash='a'*64,config={'x':1},custom_dir=tmp_path/'models')
    evaluation.paper_v22_record('run-1','trade_opened',{'symbol':'BTC'},'open-1')
    return started


def test_backup_verify_and_isolated_restore(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    backup=tmp_path/'backup'
    result=recovery.create_recovery_backup(backup)
    assert result['ok']
    assert recovery.verify_recovery_backup(backup)['valid']
    restored=tmp_path/'restored'
    rr=recovery.restore_recovery_backup(backup, restored)
    assert rr['ok'] and rr['isolated']
    assert (restored/'registry.jsonl').exists()
    assert (restored/'paper_v22.sqlite3').exists()
    with sqlite3.connect(restored/'paper_v22.sqlite3') as c:
        assert c.execute('select count(*) from paper_events').fetchone()[0] == 1
    with pytest.raises(FileExistsError): recovery.restore_recovery_backup(backup, restored)


def test_backup_tamper_detected(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    backup=tmp_path/'backup'; recovery.create_recovery_backup(backup)
    with (backup/'registry.jsonl').open('a') as f: f.write('{"tampered":true}\n')
    result=recovery.verify_recovery_backup(backup)
    assert not result['valid']
    assert any('registry' in e or 'file_invalid' in e for e in result['errors'])


def test_idempotency_survives_reopen_and_duplicate_retry(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    first=evaluation.paper_v22_record('run-1','trade_opened',{'symbol':'ETH'},'retry-key')
    # Reopen happens implicitly on every call; the retry must return original event.
    second=evaluation.paper_v22_record('run-1','trade_opened',{'symbol':'ETH'},'retry-key')
    assert first['event_id']==second['event_id']
    assert second['duplicate'] is True
    assert evaluation.paper_v22_audit_integrity()['valid']


def test_same_idempotency_key_cannot_create_second_event(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    a=evaluation.paper_v22_record('run-1','signal',{'side':'LONG'},'global-key')
    b=evaluation.paper_v22_record('run-2','signal',{'side':'SHORT'},'global-key')
    assert a['event_id']==b['event_id'] and b['duplicate']
    assert b['run_id']=='run-1'


def test_concurrent_paper_writers_preserve_hash_chain(tmp_path, monkeypatch):
    from concurrent.futures import ThreadPoolExecutor
    _setup(tmp_path, monkeypatch)
    def write(i):
        return evaluation.paper_v22_record('parallel-run','signal',{'n':i},f'parallel-{i}')
    with ThreadPoolExecutor(max_workers=8) as pool:
        rows=list(pool.map(write, range(24)))
    assert len({x['event_id'] for x in rows}) == 24
    audit=evaluation.paper_v22_audit_integrity()
    assert audit['valid'], audit
    assert audit['checked_events'] == 25


def test_signed_anchor_detects_rewritten_snapshot_and_manifest(tmp_path, monkeypatch):
    _setup(tmp_path, monkeypatch)
    backup=tmp_path/'backup'; recovery.create_recovery_backup(backup)
    # Simulate an attacker rewriting the payload and recomputing the ordinary
    # manifest digest, but without possession of the separately-held private key.
    with (backup/'registry.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps({'event_type':'forged'})+'\n')
    manifest_path=backup/'backup_manifest.json'
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    from backend.reproducible_run import sha256_file
    manifest['files']['registry.jsonl']={'sha256':sha256_file(backup/'registry.jsonl'),'size_bytes':(backup/'registry.jsonl').stat().st_size}
    manifest.pop('backup_sha256',None)
    import hashlib
    manifest['backup_sha256']=hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    manifest_path.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    anchor=json.loads((backup/'anchor.json').read_text(encoding='utf-8'))
    anchor['backup_sha256']=manifest['backup_sha256']
    (backup/'anchor.json').write_text(json.dumps(anchor,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    result=recovery.verify_recovery_backup(backup)
    assert not result['valid']
    assert any('anchor:' in e for e in result['errors'])


def test_key_rotation_keeps_old_key_trusted_and_new_key_active(tmp_path, monkeypatch):
    from backend import signed_anchor
    monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR', str(tmp_path/'trust'))
    first=signed_anchor.ensure_keypair()['key_id']
    old_anchor=signed_anchor.sign_backup('a'*64,'b'*64,'c'*64)
    rotated=signed_anchor.rotate_key(revoke_old=False)
    assert rotated['old_key_id']==first and rotated['new_key_id']!=first
    assert signed_anchor.verify_anchor(old_anchor)['valid']
    new_anchor=signed_anchor.sign_backup('d'*64,'e'*64,'f'*64)
    assert new_anchor['key_id']==rotated['new_key_id']
    assert signed_anchor.verify_anchor(new_anchor)['valid']


def test_revoked_key_and_fingerprint_confirmation(tmp_path, monkeypatch):
    from backend import signed_anchor
    monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR', str(tmp_path/'trust'))
    old=signed_anchor.ensure_keypair()
    anchor=signed_anchor.sign_backup('a'*64,'b'*64,'c'*64)
    exported=signed_anchor.export_public_key(old['key_id'])
    imported=signed_anchor.import_trusted_public_key(exported['public_key_pem'], expected_fingerprint=exported['fingerprint_sha256'])
    assert imported['imported']
    with pytest.raises(ValueError): signed_anchor.import_trusted_public_key(exported['public_key_pem'], expected_fingerprint='0'*64)
    signed_anchor.revoke_key(old['key_id'])
    result=signed_anchor.verify_anchor(anchor)
    assert not result['valid'] and 'anchor_key_revoked' in result['errors'][0]


def test_anti_rollback_sequence_rejects_older_valid_signature(tmp_path, monkeypatch):
    from backend import signed_anchor
    monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR', str(tmp_path/'trust'))
    first=signed_anchor.sign_backup('1'*64,'2'*64,'3'*64)
    second=signed_anchor.sign_backup('4'*64,'5'*64,'6'*64)
    assert signed_anchor.verify_anchor(second)['valid']
    older=signed_anchor.verify_anchor(first)
    assert not older['valid'] and 'anchor_rollback_detected' in older['errors'][0]
