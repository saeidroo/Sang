import json
import pytest
from backend.btc_replay_anchor import (create_replay_key_rotation_ceremony,
    verify_replay_key_rotation_ceremony, import_rotated_replay_trust,
    sign_replay_head_anchor, verify_signed_replay_head_anchor)


def _checkpoint():
    import hashlib
    body={'anchor_version':'btc-4h-replay-head-anchor-v1','anchor_sequence':1,
          'previous_anchor_sha256':'0'*64,'registry_record_count':0,
          'registry_chain_head_sha256':'0'*64}
    raw=json.dumps(body,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
    return {**body,'anchor_sha256':hashlib.sha256(raw).hexdigest()}


def test_dual_signed_rotation_and_new_trust_import(tmp_path, monkeypatch):
    monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR',str(tmp_path/'trust'))
    from backend import signed_anchor
    old=signed_anchor.ensure_keypair()
    old_pub=tmp_path/'pinned-old.pem'; old_pub.write_text(old['public_key_pem'])
    old_signed=sign_replay_head_anchor(_checkpoint(),output_path=tmp_path/'old-signed.json')
    result=create_replay_key_rotation_ceremony(output_path=tmp_path/'rotation.json')
    ceremony=result['ceremony']
    assert verify_replay_key_rotation_ceremony(ceremony,trusted_old_public_key_path=old_pub)['valid']
    imported=import_rotated_replay_trust(ceremony,trusted_old_public_key_path=old_pub)
    assert imported['imported']
    assert verify_signed_replay_head_anchor(old_signed)['valid']
    new_signed=sign_replay_head_anchor(_checkpoint(),output_path=tmp_path/'new-signed.json')
    assert new_signed['key_id']==result['new_key_id']
    assert verify_signed_replay_head_anchor(new_signed)['valid']


def test_rotation_ceremony_rejects_tamper_or_wrong_old_root(tmp_path, monkeypatch):
    monkeypatch.setenv('TS_AI_ANCHOR_KEY_DIR',str(tmp_path/'trust'))
    from backend import signed_anchor
    old=signed_anchor.ensure_keypair(); old_pub=tmp_path/'old.pem'; old_pub.write_text(old['public_key_pem'])
    ceremony=create_replay_key_rotation_ceremony(output_path=tmp_path/'rotation.json')['ceremony']
    changed=dict(ceremony); changed['new_key_id']='f'*64
    assert not verify_replay_key_rotation_ceremony(changed,trusted_old_public_key_path=old_pub)['valid']
    wrong=tmp_path/'wrong.pem'; wrong.write_text(ceremony['new_public_key_pem'])
    assert not verify_replay_key_rotation_ceremony(ceremony,trusted_old_public_key_path=wrong)['valid']
