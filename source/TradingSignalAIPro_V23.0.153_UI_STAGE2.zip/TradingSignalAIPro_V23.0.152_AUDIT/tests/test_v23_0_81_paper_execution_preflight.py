import pytest
from backend.paper_execution_preflight import preflight_paper_candidates
from backend import paper_execution_orchestrator as orchestrator


def candidate(**kw):
    x = {'symbol': 'BTCUSDT', 'decision': 'PAPER_BUY_CANDIDATE', 'score': 82,
         'coverage_pct': 78, 'conflict_ratio': 0.1, 'risk_blockers': [],
         'idempotency_key': 'signal:BTCUSDT:20261119:1h:001'}
    x.update(kw)
    return x


def test_preflight_is_read_only_and_accepts_valid_candidate():
    r = preflight_paper_candidates([candidate()])
    assert r['ready'] == 1 and r['status'] == 'PREFLIGHT_PASSED'
    assert r['creates_positions'] is False and r['real_orders_enabled'] is False


def test_preflight_blocks_duplicate_symbol_and_key():
    a = candidate()
    b = candidate(idempotency_key='signal:BTCUSDT:20261119:1h:002')
    c = candidate(symbol='ETHUSDT', idempotency_key='signal:ETHUSDT:20261119:1h:003')
    r = preflight_paper_candidates([a, b, c])
    assert [x['status'] for x in r['results']] == ['READY', 'BLOCKED', 'READY']
    assert r['results'][1]['reason'] == 'DUPLICATE_SYMBOL_IN_BATCH'


def test_preflight_rejects_bad_numbers_and_blocker_shape():
    r = preflight_paper_candidates([candidate(score=float('nan')), candidate(risk_blockers='none')])
    assert all(x['status'] == 'BLOCKED' for x in r['results'])


def test_preflight_batch_limit():
    with pytest.raises(ValueError):
        preflight_paper_candidates([candidate()] * 21)


def test_orchestrator_rejects_duplicate_symbol_before_second_open(monkeypatch):
    calls = []
    monkeypatch.setattr('backend.paper_live.open_position', lambda **kw: calls.append(kw) or {'id': len(calls)})
    a = candidate()
    b = candidate(idempotency_key='signal:BTCUSDT:20261119:1h:002')
    r = orchestrator.execute_paper_candidates([a, b], confirm_paper_execution=True)
    assert len(calls) == 1
    assert r['results'][1]['reason'] == 'DUPLICATE_SYMBOL_IN_BATCH'


def test_orchestrator_batch_limit_applies_even_when_unarmed():
    with pytest.raises(ValueError):
        orchestrator.execute_paper_candidates([candidate()] * 21)
