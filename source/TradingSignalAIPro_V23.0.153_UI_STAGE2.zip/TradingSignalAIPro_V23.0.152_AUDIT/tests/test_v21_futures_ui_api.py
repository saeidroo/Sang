"""V21 part 2: famous futures in /api/symbols, long-run presets, no spot archive for futures."""
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend import data, longrun  # noqa: E402
from backend.api import app  # noqa: E402


@pytest.fixture()
def client():
    app.config['TESTING'] = True
    with app.test_client() as c:
        yield c


def test_symbols_endpoint_lists_futures(client):
    d = client.get('/api/symbols').get_json()
    assert 'BTCUSDTPERP' in d['futures'] and 'ETHUSDTPERP' in d['futures']
    assert len(d['futures']) >= 12
    assert all(data.is_futures_symbol(x) for x in d['futures'])
    assert d['futures_labels']['BTCUSDTPERP'].startswith('BTCUSDT')
    assert 'BTCUSDT' in d['crypto']                      # spot list untouched


def test_futures_ids_pass_longrun_validation():
    cfg = longrun.normalize_config({'symbols': ['BTCUSDTPERP', 'ETHUSDT'], 'timeframes': ['1h']})
    assert cfg['symbols'] == ['BTCUSDTPERP', 'ETHUSDT']


def test_futures_presets_exist_and_are_futures_only():
    for name in ('fut_core5', 'fut_top12', 'fut_all'):
        assert longrun.PRESETS[name]
        assert all(data.is_futures_symbol(x) for x in longrun.PRESETS[name])
    assert len(longrun.PRESETS['fut_core5']) == 5


def test_spot_archive_not_used_for_futures(monkeypatch):
    called = {'archive': 0, 'live': []}
    import backend.historical as hist
    monkeypatch.setattr(hist, 'ensure_recent_history',
                        lambda *a, **k: called.__setitem__('archive', called['archive'] + 1))

    class Frame:
        attrs = {'source': 'binance_fut'}

    def fake_fetch(symbol, tf, limit=0, source='auto', progress_cb=None):
        called['live'].append((symbol, source))
        return Frame()
    monkeypatch.setattr(data, 'fetch_candles', fake_fetch)
    df, src = longrun.acquire_candles('BTCUSDTPERP', '1h', 5000)
    assert called['archive'] == 0
    assert called['live'] == [('BTCUSDTPERP', 'auto')]
    assert src == 'binance_fut'


def test_spot_still_uses_archive(monkeypatch):
    called = {'archive': 0}
    import backend.historical as hist

    def boom(*a, **k):
        called['archive'] += 1
        raise RuntimeError('no archive')
    monkeypatch.setattr(hist, 'ensure_recent_history', boom)

    class Frame:
        attrs = {'source': 'binance'}
    monkeypatch.setattr(data, 'fetch_candles', lambda *a, **k: Frame())
    longrun.acquire_candles('BTCUSDT', '1h', 5000)
    assert called['archive'] == 1


def test_frontend_has_futures_group_and_presets():
    js = (ROOT / 'frontend' / 'app.js').read_text(encoding='utf-8')
    html = (ROOT / 'frontend' / 'index.html').read_text(encoding='utf-8')
    assert "group:'futures'" in js and 'fut12' in js and "'.P'" in js
    assert 'data-preset="fut5"' in html and 'data-preset="fut12"' in html


def test_health_probes_split_futures_and_spot(monkeypatch, client):
    probed = []

    def fake(src):
        def f(symbol, tf, limit):
            probed.append(src)
            raise RuntimeError('x')
        return f
    from backend import api
    monkeypatch.setattr(api, 'SOURCE_FUNCS', {k: fake(k) for k in data.SOURCE_FUNCS})
    client.get('/api/data/health?symbol=BTCUSDTPERP&timeframe=1h')
    assert probed and set(probed) <= set(data.FUTURES_AUTO_ORDER) | {'history'}
    probed.clear()
    client.get('/api/data/health?symbol=BTCUSDT&timeframe=1h')
    assert probed and not set(probed) & set(data.FUTURES_AUTO_ORDER)
