import numpy as np
import pandas as pd
import pytest
from backend.btc_dataset import build_btc_4h_dataset


def candles(n=420):
    rng=np.random.default_rng(42)
    close=30000*np.exp(np.cumsum(rng.normal(0,0.004,n)))
    op=close*(1+rng.normal(0,0.001,n))
    hi=np.maximum(op,close)*1.002
    lo=np.minimum(op,close)*0.998
    return pd.DataFrame({'t':np.arange(n,dtype=np.int64)*14_400_000,
        'open':op,'high':hi,'low':lo,'close':close,
        'volume':rng.lognormal(5,0.3,n)})


def test_dataset_contract_separates_features_labels_metadata_and_manifest():
    d=build_btc_4h_dataset(candles(), horizon_bars=6, n_splits=3)
    assert len(d['X']) == len(d['y']) == len(d['metadata'])
    assert set(d['y'].unique()).issubset({-1,0,1})
    assert not any(any(t in c.lower() for t in ('label','forward','future','target')) for c in d['X'])
    assert {'sample_pos','label_end_pos','label_end_t','forward_return'} <= set(d['metadata'])
    assert d['manifest']['eligible_rows'] == len(d['X'])
    assert len(d['manifest']['dataset_hash']) == 64


def test_fold_purge_uses_original_label_end_positions():
    d=build_btc_4h_dataset(candles(), horizon_bars=8, embargo_bars=2, n_splits=3)
    for fold in d['folds']:
        assert max(d['metadata'].iloc[fold['train_sample_indices']]['label_end_pos']) < fold['validation_start_original_pos']-2
        assert set(fold['train_sample_indices']).isdisjoint(fold['validation_sample_indices'])


def test_deterministic_manifest_for_same_input_and_config():
    a=build_btc_4h_dataset(candles(), n_splits=3)
    b=build_btc_4h_dataset(candles(), n_splits=3)
    assert a['manifest']['dataset_hash'] == b['manifest']['dataset_hash']


@pytest.mark.parametrize('bad', ['label','forward_return','future_price','target_class','close'])
def test_forbidden_or_non_feature_columns_rejected(bad):
    with pytest.raises(ValueError):
        build_btc_4h_dataset(candles(), feature_columns=[bad], n_splits=3)


def test_invalid_integrity_is_blocked():
    df=candles(); df.loc[100,'high']=1
    with pytest.raises(ValueError, match='integrity blocked'):
        build_btc_4h_dataset(df, n_splits=3)
