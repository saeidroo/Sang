import pytest
from backend.explosive_opportunity_screener import screen_explosive_opportunities

GOOD={'symbol':'ABCUSDT','exchange':'Binance','volume_ratio':2.4,'range_compression_pct':20,
      'breakout_confirmed':True,'relative_strength_vs_btc_pct':2.1,'spread_bps':12,
      'change_pct':4,'atr_pct':5,'buy_sell_volume_ratio':1.4}

def test_positive_evidence_only_watch_never_entry():
    r=screen_explosive_opportunities([GOOD])
    x=r['results'][0]
    assert x['decision']=='WATCH' and x['score'] >= 55
    assert x['entry_authorized'] is False and r['real_orders_enabled'] is False
    assert r['capital_usdt']==1000

def test_extreme_move_and_spread_rejected():
    x=screen_explosive_opportunities([dict(GOOD,change_pct=45,spread_bps=120)])['results'][0]
    assert x['decision']=='REJECT'
    assert {'LATE_OR_EXTREME_MOVE','SPREAD_TOO_WIDE'} <= set(x['reasons'])

def test_missing_evidence_never_promoted():
    x=screen_explosive_opportunities([{'symbol':'XUSDT','exchange':'Bybit'}])['results'][0]
    assert x['decision']=='LOW_CONFIDENCE'
    assert x['entry_authorized'] is False

def test_invalid_settings_fail_closed():
    with pytest.raises(ValueError): screen_explosive_opportunities([],{'max_spread_bps':0})
    with pytest.raises(ValueError): screen_explosive_opportunities([],{'oops':1})
