import numpy as np
import pandas as pd
import pytest

from backend import signal
from backend.execution_model import funding_cashflow_for_bars


def _rows(events):
    return pd.DataFrame({
        't': [1000.0, 2000.0, 3000.0],
        'high': [100.0, 100.1, 104.0],
        'low': [100.0, 99.9, 99.0],
        'close': [100.0, 100.0, 103.0],
        'atr_14': [2.0, 2.0, 2.0],
        'funding_events': [events, [], []],
    })


def test_multiple_settlements_in_one_candle_are_independent_and_exact():
    events = [
        {'settlement_ts': 1200.0, 'funding_rate': 0.001, 'mark_price': 100.0},
        {'settlement_ts': 1800.0, 'funding_rate': -0.002, 'mark_price': 110.0},
    ]
    rates, marks = signal._funding_events_between(_rows(events), 0, 2)
    assert rates.tolist() == pytest.approx([0.001, -0.002])
    assert marks.tolist() == pytest.approx([100.0, 110.0])
    # Long pays positive funding and receives negative funding.
    assert funding_cashflow_for_bars(side='LONG', quantity=2, funding_rates=rates,
                                     mark_prices=marks) == pytest.approx(0.24)


def test_event_exactly_at_entry_excluded_and_at_exit_included():
    rows = _rows([
        {'settlement_ts': 1000.0, 'funding_rate': 0.01, 'mark_price': 100.0},
        {'settlement_ts': 3000.0, 'funding_rate': 0.002, 'mark_price': 105.0},
    ])
    rates, marks = signal._funding_events_between(rows, 0, 2)
    assert rates.tolist() == pytest.approx([0.002])
    assert marks.tolist() == pytest.approx([105.0])


def test_duplicate_settlement_timestamp_is_rejected_not_double_counted():
    rows = _rows([
        {'settlement_ts': 1200.0, 'funding_rate': 0.001, 'mark_price': 100.0},
        {'settlement_ts': 1200.0, 'funding_rate': 0.001, 'mark_price': 100.0},
    ])
    with pytest.raises(ValueError, match='duplicate'):
        signal._funding_events_between(rows, 0, 2)


def test_out_of_order_events_are_sorted_before_cashflow():
    rows = _rows([
        {'settlement_ts': 1800.0, 'funding_rate': 0.002, 'mark_price': 102.0},
        {'settlement_ts': 1200.0, 'funding_rate': 0.001, 'mark_price': 101.0},
    ])
    rates, marks = signal._funding_events_between(rows, 0, 2)
    assert rates.tolist() == pytest.approx([0.001, 0.002])
    assert marks.tolist() == pytest.approx([101.0, 102.0])
