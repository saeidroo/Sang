import pandas as pd
import pytest

from backend.indicators import aroon
from backend.trainer import align_indicators_to_splits, temporal_split
import backend.data as data


def test_aroon_down_uses_recent_low_position():
    high = pd.Series([10, 10, 10, 10, 10, 10], dtype=float)
    low_recent = pd.Series([9, 8, 7, 6, 5, 1], dtype=float)
    _, down_recent = aroon(high, low_recent, n=5)
    assert down_recent.iloc[-1] == pytest.approx(100.0)

    low_old = pd.Series([1, 5, 6, 7, 8, 9], dtype=float)
    _, down_old = aroon(high, low_old, n=5)
    assert down_old.iloc[-1] == pytest.approx(0.0)


def test_aroon_rejects_invalid_period():
    with pytest.raises(ValueError):
        aroon(pd.Series([1.0, 2.0]), pd.Series([0.5, 1.0]), n=0)


def test_indicator_split_alignment_respects_embargo_gaps():
    features = pd.DataFrame({'x': range(1000)})
    y = pd.Series([0, 1] * 500)
    X_tr, _, X_val, _, X_te, _ = temporal_split(features, y, embargo=12)
    ind = pd.DataFrame({'row_id': range(1000)})
    ind_val, ind_test = align_indicators_to_splits(ind, X_val, X_te)
    assert ind_val.row_id.tolist() == X_val.index.tolist()
    assert ind_test.row_id.tolist() == X_te.index.tolist()
    # Boundaries are defined on raw candle positions, not compressed sample counts.
    # Actual label-end purge removes 12 rows before each segment and embargo
    # skips another 12 raw bars after the boundary.
    assert ind_val.row_id.iloc[0] == int(len(features) * 0.70) + 12
    assert ind_test.row_id.iloc[0] == int(len(features) * 0.85) + 12


def test_coinmarketcap_v5_compact_rows(monkeypatch):
    monkeypatch.setenv('CMC_API_KEY', 'test-key')
    # Documented compact row layout: OHLCV, market cap, time_open, ...
    payload = {'data': [[100, 110, 90, 105, 1234, 999999,
                         '2026-01-01T00:00:00.000Z', '2026-01-01T00:14:59.999Z',
                         '2026-01-01T00:05:00.000Z', '2026-01-01T00:10:00.000Z']]}
    monkeypatch.setattr(data, '_get', lambda *a, **k: payload)
    result = data.fetch_coinmarketcap('BTCUSDT', '15m', 10)
    assert len(result) == 1
    assert result.iloc[0].open == 100
    assert result.iloc[0].close == 105
    assert result.iloc[0].volume == 1234


def test_coinmarketcap_object_payload(monkeypatch):
    monkeypatch.setenv('CMC_API_KEY', 'test-key')
    payload = {'data': {'quotes': [{
        'time_open': '2026-01-01T00:00:00.000Z',
        'quote': {'USD': {'open': 10, 'high': 12, 'low': 9,
                          'close': 11, 'volume': 500}},
    }]}}
    monkeypatch.setattr(data, '_get', lambda *a, **k: payload)
    result = data.fetch_coinmarketcap('ETHUSDT', '1h', 10)
    assert len(result) == 1
    assert result.iloc[0].close == 11
