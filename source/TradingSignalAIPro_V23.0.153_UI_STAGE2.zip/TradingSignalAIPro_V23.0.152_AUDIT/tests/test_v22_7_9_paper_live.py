import json

import pytest

from backend import paper_live


@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path / 'paper_live.sqlite3'))
    paper_live._CACHE.clear()


def test_fixed_paper_settings_are_readonly_and_safe():
    assert paper_live.SETTINGS['initial_balance'] == 1_000.0
    assert paper_live.SETTINGS['risk_per_trade_pct'] == 0.5
    assert paper_live.SETTINGS['max_open_positions'] == 3
    assert paper_live.SETTINGS['leverage'] == 1
    assert paper_live.SETTINGS['real_orders_enabled'] is False
    assert paper_live.SETTINGS['private_api_keys_required'] is False


def test_auto_quote_falls_back_after_primary_exchange_error(monkeypatch):
    calls = []

    def fake_fetch(exchange, symbol, market):
        calls.append(exchange)
        if exchange == 'binance':
            raise RuntimeError('blocked')
        return {'symbol': symbol, 'market': market, 'exchange': exchange,
                'exchange_name': paper_live.EXCHANGE_NAMES[exchange], 'price': 123.4,
                'timestamp': '2026-11-18T00:00:00+00:00'}

    monkeypatch.setattr(paper_live, '_fetch_one', fake_fetch)
    quote = paper_live.get_quote('BTCUSDT', 'spot', 'auto', use_cache=False)
    assert quote['exchange'] == 'bybit'
    assert quote['fallback'] is True
    assert calls[:2] == ['binance', 'bybit']


def test_open_position_uses_live_quote_and_fixed_risk_preset(monkeypatch):
    monkeypatch.setattr(paper_live, 'get_quote', lambda *a, **k: {
        'symbol': 'BTCUSDT', 'market': 'spot', 'exchange': 'binance',
        'exchange_name': 'Binance', 'price': 100_000.0,
        'timestamp': '2026-11-18T00:00:00+00:00', 'authenticated': False
    })
    opened = paper_live.open_position('BTCUSDT', 'LONG', 'spot', 'auto')
    assert opened['notional'] == pytest.approx(200.0)
    assert opened['quantity'] > 0
    assert opened['stop_price'] < opened['entry_fill'] < opened['target_price']
    state = paper_live.get_state(refresh_quotes=False)
    assert state['account']['open_positions'] == 1
    assert state['account']['available_balance'] is None


def test_spot_short_is_rejected_and_perpetual_short_is_allowed(monkeypatch):
    with pytest.raises(ValueError, match='اسپات'):
        paper_live.open_position('BTCUSDT', 'SHORT', 'spot', 'auto')
    monkeypatch.setattr(paper_live, 'get_quote', lambda *a, **k: {
        'symbol': 'BTCUSDT', 'market': 'perp', 'exchange': 'bybit',
        'exchange_name': 'Bybit', 'price': 100.0,
        'timestamp': '2026-11-18T00:00:00+00:00', 'authenticated': False
    })
    opened = paper_live.open_position('BTCUSDT', 'SHORT', 'perp', 'auto')
    assert opened['side'] == 'SHORT'
    assert opened['stop_price'] > opened['entry_fill'] > opened['target_price']


def test_close_position_records_realized_net_pnl_and_fees(monkeypatch):
    prices = iter([100.0, 105.0])
    monkeypatch.setattr(paper_live, 'get_quote', lambda *a, **k: {
        'symbol': 'BTCUSDT', 'market': 'spot', 'exchange': 'binance',
        'exchange_name': 'Binance', 'price': next(prices),
        'timestamp': '2026-11-18T00:00:00+00:00', 'authenticated': False
    })
    opened = paper_live.open_position('BTCUSDT', 'LONG', 'spot', 'auto')
    closed = paper_live.close_position(opened['id'])
    assert closed['status'] == 'CLOSED'
    assert closed['exit_fee'] > 0
    assert closed['net_pnl'] < closed['gross_pnl']
    state = paper_live.get_state(refresh_quotes=False)
    assert state['account']['open_positions'] == 0
    assert state['account']['realized_pnl'] == pytest.approx(closed['net_pnl'])


def test_auto_take_profit_closes_position_on_fresh_price(monkeypatch):
    prices = iter([100.0, 104.0])
    monkeypatch.setattr(paper_live, 'get_quote', lambda *a, **k: {
        'symbol': 'BTCUSDT', 'market': 'spot', 'exchange': 'binance',
        'exchange_name': 'Binance', 'price': next(prices),
        'timestamp': '2026-11-18T00:00:00+00:00', 'authenticated': False
    })
    paper_live.open_position('BTCUSDT', 'LONG', 'spot', 'auto')
    state = paper_live.get_state(refresh_quotes=True)
    assert state['account']['open_positions'] == 0
    assert state['recent_trades'][0]['status'] == 'CLOSED'
    assert state['recent_trades'][0]['exit_reason'] == 'TAKE_PROFIT'


def test_position_limit_is_enforced(monkeypatch):
    def fake_quote(symbol, market='spot', exchange='auto', **kwargs):
        return {
            'symbol': symbol, 'market': market, 'exchange': 'binance',
            'exchange_name': 'Binance', 'price': 2_000.0,
            'timestamp': '2026-11-18T00:00:00+00:00',
            'checked_at_epoch': __import__('time').time(), 'authenticated': False
        }
    monkeypatch.setattr(paper_live, 'get_quote', fake_quote)
    for symbol in ('BTCUSDT', 'ETHUSDT', 'SOLUSDT'):
        # use a single quote fixture for the symbol under test
        paper_live.open_position(symbol, 'LONG', 'spot', 'auto')
    with pytest.raises(ValueError, match='حداکثر تعداد'):
        paper_live.open_position('BNBUSDT', 'LONG', 'spot', 'auto')


def test_api_exposes_fixed_config_and_paper_open_route(monkeypatch):
    pytest.importorskip('flask')
    from backend.api import app

    monkeypatch.setattr(paper_live, 'get_quote', lambda *a, **k: {
        'symbol': 'BTCUSDT', 'market': 'spot', 'exchange': 'binance',
        'exchange_name': 'Binance', 'price': 100.0,
        'timestamp': '2026-11-18T00:00:00+00:00', 'authenticated': False
    })
    client = app.test_client()
    cfg = client.get('/api/paper-live/config')
    assert cfg.status_code == 200
    data = cfg.get_json()
    assert data['settings']['real_orders_enabled'] is False
    assert data['settings']['initial_balance'] == 1_000.0
    opened = client.post('/api/paper-live/positions', json={
        'symbol': 'BTCUSDT', 'market': 'spot', 'side': 'LONG', 'exchange': 'auto'
    })
    assert opened.status_code == 201
    assert opened.get_json()['exchange'] == 'binance'


@pytest.mark.parametrize('exchange,market,payload,expected', [
    ('binance', 'spot', {'price': '123.5'}, 123.5),
    ('bybit', 'perp', {'retCode': 0, 'result': {'list': [{'lastPrice': '124.5'}]}}, 124.5),
    ('mexc', 'perp', {'success': True, 'data': {'lastPrice': '125.5'}}, 125.5),
    ('okx', 'perp', {'code': '0', 'data': [{'last': '126.5'}]}, 126.5),
    ('gateio', 'spot', [{'last': '127.5'}], 127.5),
    ('bitget', 'spot', {'code': '00000', 'data': [{'lastPr': '128.5'}]}, 128.5),
])
def test_exchange_public_ticker_adapters(monkeypatch, exchange, market, payload, expected):
    seen = {}

    def fake_http(url, params=None):
        seen['url'] = url
        seen['params'] = params
        return payload

    monkeypatch.setattr(paper_live, '_http_json', fake_http)
    quote = paper_live._fetch_one(exchange, 'BTCUSDT', market)
    assert quote['price'] == pytest.approx(expected)
    assert quote['authenticated'] is False
    assert 'api' in seen['url'].lower()
    if exchange == 'gateio' and market == 'spot':
        assert seen['params']['currency_pair'] == 'BTC_USDT'


def test_auto_selected_position_never_fails_over_to_a_different_exchange(monkeypatch):
    unavailable = set()

    def fake_fetch(exchange, symbol, market):
        if exchange in unavailable:
            raise RuntimeError(f"{exchange} blocked after entry")
        price = 100.0 if exchange == "binance" else 101.0
        return {"symbol": symbol, "market": market, "exchange": exchange,
                "exchange_name": paper_live.EXCHANGE_NAMES[exchange], "price": price,
                "timestamp": "2026-11-18T00:00:00+00:00", "authenticated": False}

    monkeypatch.setattr(paper_live, "_fetch_one", fake_fetch)
    opened = paper_live.open_position("BTCUSDT", "LONG", "spot", "auto")
    pinned_exchange = opened["exchange"]
    assert pinned_exchange in {"binance", "bybit", "okx"}
    # Entry AUTO uses the median of multiple exchanges; after the trade is
    # opened, mark only its selected venue unavailable. Other venues remain
    # healthy, so any fallback would make this test incorrectly show LIVE.
    unavailable.add(pinned_exchange)
    paper_live._CACHE.clear()
    state = paper_live.get_state(refresh_quotes=True)
    position = state["open_positions"][0]
    assert position["quote_status"] == "DISCONNECTED"
    assert position.get("live_exchange") is None
    assert position["status"] == "OPEN"
    assert position["unrealized_net_pnl"] is None
    assert state["account"]["available_balance"] is None


def test_migrates_older_paper_live_database(tmp_path, monkeypatch):
    db_path = tmp_path / "old_paper_live.sqlite3"
    import sqlite3
    with sqlite3.connect(db_path) as conn:
        conn.execute("""CREATE TABLE paper_live_trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT, opened_at REAL NOT NULL, symbol TEXT NOT NULL,
            market TEXT NOT NULL, exchange TEXT NOT NULL, side TEXT NOT NULL, quantity REAL NOT NULL,
            notional REAL NOT NULL, reference_entry REAL NOT NULL, entry_fill REAL NOT NULL,
            entry_fee REAL NOT NULL, stop_price REAL NOT NULL, target_price REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'OPEN', closed_at REAL, reference_exit REAL, exit_fill REAL,
            exit_fee REAL, gross_pnl REAL, net_pnl REAL, exit_reason TEXT, last_price REAL,
            last_price_at REAL, settings_json TEXT NOT NULL)""")
    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(db_path))
    paper_live.init_db()
    with sqlite3.connect(db_path) as conn:
        cols = {row[1] for row in conn.execute("PRAGMA table_info(paper_live_trades)")}
    assert "requested_exchange" in cols


def test_legacy_account_peak_is_migrated_to_1000_without_deleting_history(tmp_path, monkeypatch):
    import sqlite3
    db_path = tmp_path / "legacy_paper_live.sqlite3"
    with sqlite3.connect(db_path) as conn:
        conn.execute("CREATE TABLE paper_live_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        conn.execute("INSERT INTO paper_live_meta(key,value) VALUES('peak_equity','10000.0')")
    monkeypatch.setenv("TRADING_AI_PAPER_LIVE_DB", str(db_path))
    paper_live.init_db()
    with sqlite3.connect(db_path) as conn:
        conn.execute("""INSERT INTO paper_live_trades(
            opened_at,symbol,market,exchange,side,quantity,notional,reference_entry,entry_fill,
            entry_fee,stop_price,target_price,status,closed_at,net_pnl,settings_json
        ) VALUES(1,'BTCUSDT','spot','binance','LONG',0.01,200,20000,20001,0.2,19700,20600,
                 'CLOSED',2,25,'{}')""")
        conn.commit()
        values = dict(conn.execute("SELECT key,value FROM paper_live_meta").fetchall())
    assert float(values["initial_balance"]) == 1_000.0
    state = paper_live.get_state(refresh_quotes=False)
    assert state["account"]["initial_balance"] == 1_000.0
    assert state["account"]["realized_pnl"] == pytest.approx(25.0)
    assert state["account"]["equity"] == pytest.approx(1_025.0)
    assert state["account"]["peak_equity"] == pytest.approx(1_025.0)


def test_paper_trading_panel_is_at_page_bottom():
    from pathlib import Path
    markup = (Path(__file__).resolve().parents[1] / "frontend" / "index.html").read_text(encoding="utf-8")
    assert markup.index('id="paperLivePanel"') > markup.index('id="performanceCenter"')
    assert '۱۰٬۰۰۰ USDT' not in markup[markup.index('id="paperLivePanel"'):]
    assert '۱٬۰۰۰ USDT' in markup[markup.index('id="paperLivePanel"'):]
