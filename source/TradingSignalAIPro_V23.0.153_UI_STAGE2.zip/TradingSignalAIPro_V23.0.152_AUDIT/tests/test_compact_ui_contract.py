from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_compact_sections_keep_navigation_and_persist_state():
    js=(ROOT/'frontend'/'ui-shell.js').read_text(encoding='utf-8')
    for section in ('opportunityRadar','marketWorkspace','paperWorkspace','autopilotPanel','performanceCenter'):
        assert section in js
    assert 'localStorage.setItem' in js
    assert "body.hidden=!open" in js
    assert "setOpen(el,body,button,true)" in js

def test_logging_is_configured_by_api_without_logging_request_body():
    api=(ROOT/'backend'/'api.py').read_text(encoding='utf-8')
    assert 'configure_logging()' in api
    assert "request.get_data" not in api


def test_paper_workspace_groups_signal_history_and_paper_execution():
    html=(ROOT/'frontend'/'index.html').read_text(encoding='utf-8')
    start=html.index('id="paperWorkspace"')
    end=html.index('id="autopilotPanel"')
    workspace=html[start:end]
    assert 'id="sigHistory"' in workspace
    assert 'id="paperLivePanel"' in workspace
    assert 'id="paperLearningPanel"' in workspace
    assert 'href="#paperWorkspace" data-section="paperWorkspace"' in html
    assert "APP_VERSION = '23.0.152'" in (ROOT/'backend'/'api.py').read_text(encoding='utf-8')
