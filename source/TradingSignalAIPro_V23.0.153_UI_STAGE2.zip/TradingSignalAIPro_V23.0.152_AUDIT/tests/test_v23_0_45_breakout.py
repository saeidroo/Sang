import pandas as pd
import pytest
from backend.portfolio_risk import detect_breakout_state


def frame(closes):
    highs = [max(c + 1, h) for c, h in zip(closes, [101,105,110,110,106,104,105,107,113,113])]
    lows = [c - 1 for c in closes]
    return pd.DataFrame({"high": highs, "low": lows, "close": closes})


def test_long_breakout_confirmed_on_closed_candle():
    df = frame([100,103,108,108,104,102,103,105,109,112])
    result = detect_breakout_state(df, side="LONG", atr_value=2, pivot_width=2)
    assert result["state"] == "BREAKOUT_CONFIRMED"
    assert result["level_type"] == "RESISTANCE"
    assert result["data_policy"] == "CLOSED_CANDLES_ONLY"


def test_long_failed_breakout_is_flagged():
    df = frame([100,103,108,108,104,102,103,105,112,108])
    result = detect_breakout_state(df, side="LONG", atr_value=2, pivot_width=2)
    assert result["state"] == "FALSE_BREAKOUT"


def test_short_breakout_uses_support():
    highs = [101,100,99,100,102,104,103,101,99,97]
    lows = [99,95,90,91,94,96,95,93,91,95]
    closes = [100,97,92,96,100,102,100,98,94,88]
    df = pd.DataFrame({"high": highs, "low": lows, "close": closes})
    result = detect_breakout_state(df, side="SHORT", atr_value=2, pivot_width=2)
    assert result["level_type"] == "SUPPORT"
    assert result["state"] in {"BREAKOUT_CONFIRMED", "NO_BREAKOUT"}


def test_rejects_invalid_parameters_and_insufficient_history():
    with pytest.raises(ValueError):
        detect_breakout_state(pd.DataFrame(), side="LONG", atr_value=1)
    with pytest.raises(ValueError):
        detect_breakout_state(frame([100] * 10), side="SIDEWAYS", atr_value=1)
