import sqlite3
from pathlib import Path
import pytest
from backend.witness_server import bootstrap_keys, init_db, record_anchor
import backend.witness_scheduler as scheduler


def setup(tmp_path):
    p=tmp_path/'src'; p.mkdir(); priv=p/'priv.pem'; pub=p/'pub.pem'; db=p/'w.sqlite'
    bootstrap_keys(priv,pub); init_db(db)
    for i in range(5): record_anchor(db,priv,{'i':i})
    return db,pub


def test_durable_scheduler_success_and_health(tmp_path,monkeypatch):
    db,pub=setup(tmp_path); state=tmp_path/'state.sqlite'
    monkeypatch.setattr(scheduler,'sync_replication_http',lambda *a,**k:{'chunks':2,'appended':5,'sequence':5})
    monkeypatch.setattr(scheduler,'_request',lambda *a,**k:{'sequence':5,'head_digest':'head'})
    r=scheduler.run_sync_once(db,pub,'https://example.invalid','secret',state,max_lag=0)
    assert r['status']=='success' and r['lag']==0 and r['chunks']==2
    h=scheduler.scheduler_status(state,max_lag=0,stale_after_seconds=3600)
    assert h['healthy'] is True and h['last_run']['appended']==5


def test_scheduler_persists_failure_and_alerts(tmp_path,monkeypatch):
    db,pub=setup(tmp_path); state=tmp_path/'state.sqlite'
    def fail(*a,**k): raise TimeoutError('network down')
    monkeypatch.setattr(scheduler,'sync_replication_http',fail)
    monkeypatch.setattr(scheduler,'_request',lambda *a,**k:{'sequence':2})
    r=scheduler.run_sync_once(db,pub,'https://example.invalid','secret',state,max_lag=0)
    assert r['status']=='failed' and r['lag']==3
    h=scheduler.scheduler_status(state,max_lag=0,stale_after_seconds=3600)
    assert not h['healthy'] and 'last_replication_failed' in h['alerts'] and 'replication_lag_exceeded' in h['alerts']


def test_scheduler_requires_safe_interval(tmp_path):
    with pytest.raises(ValueError,match='scheduler_interval'):
        scheduler.run_scheduler('x','y','https://example.invalid','t',tmp_path/'s.db',interval_seconds=1,max_runs=1)


def test_never_run_is_unhealthy(tmp_path):
    h=scheduler.scheduler_status(tmp_path/'empty.sqlite')
    assert h['status']=='never_run' and not h['healthy']
