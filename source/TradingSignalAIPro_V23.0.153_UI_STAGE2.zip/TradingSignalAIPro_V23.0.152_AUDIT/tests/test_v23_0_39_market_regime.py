import numpy as np
import pandas as pd
import pytest

from backend.market_regime import classify_market_regime


def candles_from_close(close, volatility=0.004):
    close = np.asarray(close, dtype=float)
    return pd.DataFrame({'open': close*(1-volatility/3), 'high': close*(1+volatility),
                         'low': close*(1-volatility), 'close': close})


def test_detects_uptrend_and_downtrend():
    up = candles_from_close(np.linspace(100, 150, 100))
    down = candles_from_close(np.linspace(150, 100, 100))
    assert classify_market_regime(up)['regime'] == 'UPTREND'
    assert classify_market_regime(down)['regime'] == 'DOWNTREND'


def test_rejects_short_or_invalid_ohlc():
    with pytest.raises(ValueError, match='۶۰'):
        classify_market_regime(candles_from_close(np.linspace(100, 110, 30)))
    bad = candles_from_close(np.linspace(100, 110, 80))
    bad.loc[0, 'high'] = 1
    with pytest.raises(ValueError, match='Invalid OHLC'):
        classify_market_regime(bad)


def test_regime_performance_only_uses_explicit_tags(tmp_path, monkeypatch):
    from backend import paper_live
    monkeypatch.setenv('TRADING_AI_PAPER_LIVE_DB', str(tmp_path/'regime.sqlite3'))
    paper_live._CACHE.clear()
    paper_live.init_db(backfill_learning=False)
    import time, json
    with paper_live._connect() as conn:
        for i, (tag, pnl) in enumerate([('UPTREND', 5), ('UPTREND', -1), ('', 9)], 1):
            conn.execute('''INSERT INTO paper_learning_events
                (trade_id,closed_at,symbol,market,timeframe,exchange,side,exit_reason,outcome,net_pnl,
                 return_pct,duration_seconds,notional,gross_pnl,total_fees,entry_fill,exit_fill,context_json)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (i,time.time(),'BTCUSDT','spot','1h','binance','LONG','TEST',int(pnl>0),pnl,pnl,60,100,pnl,0,100,100,
                 json.dumps({'decision_context': {'market_regime':tag}} if tag else {})))
    result = paper_live.get_regime_performance()
    assert result['tagged_trade_count'] == 2
    assert result['untagged_trade_count'] == 1
    assert result['regimes'][0]['regime'] == 'UPTREND'
    assert result['read_only'] is True
