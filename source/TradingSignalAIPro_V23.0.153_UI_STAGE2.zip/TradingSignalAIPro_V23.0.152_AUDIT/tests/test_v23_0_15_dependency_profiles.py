from pathlib import Path
from dependency_audit import audit, OPTIONAL

ROOT = Path(__file__).resolve().parents[1]


def test_optional_dependency_profiles_exist_and_are_separate():
    for name in ("requirements-desktop.txt", "requirements-tradingview.txt", "requirements-rl.txt"):
        assert (ROOT / name).is_file()
    core = (ROOT / "requirements.txt").read_text(encoding="utf-8").lower()
    assert "pywebview" not in core
    assert "tvdatafeed" not in core
    assert "stable-baselines3" not in core


def test_optional_inventory_includes_tvdatafeed_and_profiles():
    report = audit()
    assert "tvDatafeed" in {item[0] for item in OPTIONAL.values()}
    assert report["optional_install_files"] == {
        "desktop": True,
        "tradingview": True,
        "reinforcement_learning": True,
    }


def test_visible_version_strings_are_unified():
    for rel in ("backend/api.py", "main.py", "README.md"):
        text = (ROOT / rel).read_text(encoding="utf-8")
        assert "23.0.152" in text
