import numpy as np
import pandas as pd
import pytest
from backend.btc_dataset import build_btc_4h_dataset
from backend.btc_holdout import evaluate_btc_4h_holdout, _simulate_cost_aware


def candles(n=620):
    rng = np.random.default_rng(77)
    close = 30000 * np.exp(np.cumsum(rng.normal(0, .006, n)))
    op = close * (1 + rng.normal(0, .001, n))
    return pd.DataFrame({'t': np.arange(n, dtype=np.int64)*14_400_000,
        'open': op, 'high': np.maximum(op, close)*1.002,
        'low': np.minimum(op, close)*.998, 'close': close,
        'volume': rng.lognormal(5, .4, n)})


def test_holdout_is_final_block_and_training_labels_are_purged():
    ds = build_btc_4h_dataset(candles(), horizon_bars=6, embargo_bars=3, n_splits=3)
    result = evaluate_btc_4h_holdout(ds, min_trades=1)
    assert result['holdout_start_sample_index'] + result['holdout_rows'] == len(ds['X'])
    assert result['max_train_label_end_pos'] < result['holdout_start_original_pos'] - 3
    assert result['train_rows_after_purge'] > 0
    assert result['automatic_promotion'] is False


def test_costs_reduce_net_return_and_non_overlapping_trades():
    p = np.array([[0, 0, 1.]]*5)
    m = pd.DataFrame({'sample_pos':[1,2,3,8,9], 'label_end_pos':[4,5,6,11,12],
                      'forward_return':[.02]*5})
    no_cost = _simulate_cost_aware(p, m, probability_edge=.1, fee_bps=0,
        slippage_bps=0, spread_bps=0, min_trades=1)
    with_cost = _simulate_cost_aware(p, m, probability_edge=.1, fee_bps=5,
        slippage_bps=3, spread_bps=2, min_trades=1)
    assert no_cost['trade_count'] == 2
    assert with_cost['net_return_sum'] < no_cost['net_return_sum']
    assert all(a['label_end_pos'] < b['sample_pos'] for a,b in zip(with_cost['trades'], with_cost['trades'][1:]))


def test_holdout_report_is_hashed_and_does_not_auto_promote():
    ds = build_btc_4h_dataset(candles(), n_splits=3)
    a = evaluate_btc_4h_holdout(ds, min_trades=100000)
    assert len(a['evaluation_hash']) == 64
    assert all(v['promotion_allowed'] is False for v in a['models'].values())
    assert all(v['decision_gate'] == 'FAIL' for v in a['models'].values())


def test_invalid_holdout_and_cost_inputs_rejected():
    ds = build_btc_4h_dataset(candles(), n_splits=3)
    with pytest.raises(ValueError):
        evaluate_btc_4h_holdout(ds, holdout_fraction=.9)
    with pytest.raises(ValueError):
        evaluate_btc_4h_holdout(ds, fee_bps=-1)
