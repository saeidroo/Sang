import numpy as np
import pandas as pd
import pytest
from backend.portfolio_risk import analyze_rsi_macd_divergence


def sample_frame(n=100):
    x = np.arange(n, dtype=float)
    close = 100 + 0.08*x + 2.2*np.sin(x*0.48) + 0.7*np.sin(x*0.13)
    return pd.DataFrame({
        'open': close - 0.15*np.cos(x),
        'high': close + 0.55,
        'low': close - 0.55,
        'close': close,
        'volume': 1000 + 10*x,
    })


def test_divergence_engine_returns_rsi_macd_and_confirmed_pivots():
    result = analyze_rsi_macd_divergence(sample_frame(), side='LONG', pivot_width=2)
    assert result['side'] == 'LONG'
    assert 'rsi_divergence' in result and 'macd_divergence' in result
    assert result['data_policy'] == 'CLOSED_CANDLES_ONLY'
    assert result['confirmed_price_pivots']['highs'] > 0
    assert result['confirmed_price_pivots']['lows'] > 0
    assert isinstance(result['blocking'], bool)


def test_divergence_engine_handles_short_side_separately():
    result = analyze_rsi_macd_divergence(sample_frame(), side='SHORT', pivot_width=2)
    assert result['side'] == 'SHORT'
    assert result['data_policy'] == 'CLOSED_CANDLES_ONLY'
    assert result['blocking'] in (True, False)


def test_missing_ohlc_returns_unavailable_without_blocking():
    result = analyze_rsi_macd_divergence(pd.DataFrame({'close':[100]*50}), side='LONG')
    assert result['state'] == 'UNAVAILABLE'
    assert result['blocking'] is False


def test_invalid_side_and_parameters_rejected():
    with pytest.raises(ValueError):
        analyze_rsi_macd_divergence(sample_frame(), side='FLAT')
    with pytest.raises(ValueError):
        analyze_rsi_macd_divergence(sample_frame(), side='LONG', pivot_width=0)
