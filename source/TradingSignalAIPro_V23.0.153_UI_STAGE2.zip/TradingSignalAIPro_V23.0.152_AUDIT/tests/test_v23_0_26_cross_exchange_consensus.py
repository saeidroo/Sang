import pytest
from backend import paper_live as pl


def setup_function():
    pl._CACHE.clear()


def _quote(exchange, price):
    return {"symbol": "BTCUSDT", "market": "spot", "exchange": exchange,
            "exchange_name": pl.EXCHANGE_NAMES[exchange], "price": price,
            "timestamp": "test", "source": "test"}


def test_consensus_accepts_close_independent_prices(monkeypatch):
    prices = {"binance": 100.0, "bybit": 100.2, "okx": 99.9}
    monkeypatch.setattr(pl, "_fetch_one", lambda ex, s, m: _quote(ex, prices[ex]))
    result = pl.get_consensus_quote("BTCUSDT")
    assert result["cross_exchange_validated"] is True
    assert result["consensus_source_count"] == 3
    assert result["exchange"] in prices
    assert result["consensus_max_deviation_pct"] < 1.0


def test_consensus_rejects_large_price_divergence(monkeypatch):
    prices = {"binance": 100.0, "bybit": 100.2, "okx": 106.0}
    monkeypatch.setattr(pl, "_fetch_one", lambda ex, s, m: _quote(ex, prices[ex]))
    with pytest.raises(RuntimeError, match="اختلاف قیمت صرافی‌ها"):
        pl.get_consensus_quote("BTCUSDT", max_deviation_pct=1.0)


def test_consensus_fails_closed_with_only_one_source(monkeypatch):
    def fetch(ex, s, m):
        if ex == "binance":
            return _quote(ex, 100)
        raise RuntimeError("offline")
    monkeypatch.setattr(pl, "_fetch_one", fetch)
    with pytest.raises(RuntimeError, match="اجماع قیمت برقرار نشد"):
        pl.get_consensus_quote("BTCUSDT", min_sources=2)


def test_consensus_rejects_mismatched_symbol(monkeypatch):
    monkeypatch.setattr(pl, "_fetch_one", lambda ex, s, m: {**_quote(ex, 100), "symbol": "ETHUSDT"})
    with pytest.raises(RuntimeError, match="اجماع قیمت برقرار نشد"):
        pl.get_consensus_quote("BTCUSDT", min_sources=2)


def test_consensus_rejects_invalid_band():
    with pytest.raises(ValueError, match="حد اختلاف"):
        pl.get_consensus_quote("BTCUSDT", max_deviation_pct=0)
