import backend.storm_market_depth as md


def setup_function(tmp_path=None):
    md.DB_PATH = __import__('pathlib').Path('/tmp') / ('storm_test_%s.sqlite3' % __import__('os').getpid())
    if md.DB_PATH.exists(): md.DB_PATH.unlink()


def test_depth_calculations_and_spread():
    def fake(url, params):
        return {'bids': [['99', '10'], ['98', '5']], 'asks': [['101', '8'], ['102', '4']]}
    r=md.fetch_orderbook('binance','ABCUSDT',20,fetch_json=fake)
    assert r['status']=='depth_snapshot_ok'
    assert r['spread_bps'] > 0 and r['bid_depth_quote'] > 0 and r['ask_depth_quote'] > 0
    assert r['entry_ready'] is False


def test_depth_rejects_unknown_exchange_and_bad_pair():
    assert md.fetch_orderbook('unknown','ABCUSDT')['status']=='unsupported_exchange'
    assert md.fetch_orderbook('binance','ABCUSD')['status']=='unsupported_pair'


def test_depth_failure_is_safe():
    def fail(url, params): raise RuntimeError('offline')
    r=md.fetch_orderbook('bybit','ABCUSDT',fetch_json=fail)
    assert r['status']=='depth_unavailable' and r['entry_ready'] is False


def test_observations_persist_and_history_roundtrip():
    setup_function()
    a=md.record_observation('Binance','ABCUSDT',500000,10000,9000,12,timestamp=1000)
    b=md.record_observation('Binance','ABCUSDT',510000,11000,8000,10,timestamp=1600)
    c=md.record_observation('Binance','ABCUSDT',490000,12000,8500,11,timestamp=2200)
    assert a['status']=='insufficient_observations' and b['status']=='insufficient_observations'
    assert c['stable'] and c['entry_ready'] is False
    h=md.history('Binance','ABCUSDT')
    assert h['count']==3 and h['observations'][-1]['spread_bps']==11


def test_observation_rejects_duplicate_and_out_of_order():
    setup_function()
    md.record_observation('MEXC','XUSDT',200000,timestamp=1000)
    assert md.record_observation('MEXC','XUSDT',200000,timestamp=1200)['status']=='sample_too_soon'
    assert md.record_observation('MEXC','XUSDT',200000,timestamp=900)['status']=='out_of_order_snapshot'
