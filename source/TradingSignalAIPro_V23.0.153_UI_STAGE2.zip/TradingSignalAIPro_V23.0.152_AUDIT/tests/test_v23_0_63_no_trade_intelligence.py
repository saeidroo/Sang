import pytest
from backend.no_trade_intelligence import build_no_trade_report


def test_stale_data_blocks_trade():
    r=build_no_trade_report(symbol='BTCUSDT',data_age_seconds=45,signal_count=3)
    assert r['decision_state']=='NO_TRADE'
    assert 'STALE_MARKET_DATA' in r['block_reasons']


def test_invalid_data_and_conflict_block():
    r=build_no_trade_report(symbol='ETHUSDT',data_valid=False,evidence_conflict=True,signal_count=3)
    assert {'INVALID_MARKET_DATA','CONFLICTING_SIGNAL_EVIDENCE'} <= set(r['block_reasons'])


def test_low_confluence_blocks():
    r=build_no_trade_report(symbol='BTCUSDT',signal_count=1,required_signal_count=3)
    assert r['should_stand_aside']


def test_extreme_volatility_and_spread_block():
    r=build_no_trade_report(symbol='BTCUSDT',atr_pct=9,spread_pct=.2,volatility_zscore=3.5,signal_count=3)
    assert {'EXTREME_ATR_VOLATILITY','WIDE_SPREAD','VOLATILITY_SPIKE'} <= set(r['block_reasons'])


def test_missing_metrics_are_caution_not_safety_claim():
    r=build_no_trade_report(symbol='BTCUSDT',signal_count=3)
    assert r['decision_state']=='CAUTION'
    assert not r['should_stand_aside']
    assert 'DATA_FRESHNESS_NOT_PROVIDED' in r['warnings']


def test_paper_only_flags_always_false_for_execution():
    r=build_no_trade_report(symbol='BTCUSDT',data_age_seconds=1,spread_pct=.01,atr_pct=1,volume_ratio=1,signal_count=3)
    assert r['read_only'] and r['paper_only']
    assert r['authorizes_entries'] is False
    assert r['real_orders_enabled'] is False


@pytest.mark.parametrize('kwargs', [
    {'symbol':'','data_age_seconds':1},
    {'symbol':'BTCUSDT','data_age_seconds':-1},
    {'symbol':'BTCUSDT','atr_pct':float('nan')},
    {'symbol':'BTCUSDT','required_signal_count':0},
])
def test_invalid_inputs_rejected(kwargs):
    with pytest.raises(ValueError): build_no_trade_report(**kwargs)
