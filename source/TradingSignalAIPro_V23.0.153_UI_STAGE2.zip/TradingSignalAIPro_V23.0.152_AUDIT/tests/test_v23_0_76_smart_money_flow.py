import pytest
from backend.smart_money_flow import analyze_smart_money_flow


def rows():
    return [
        {'open':100,'high':102,'low':99,'close':101,'volume':100,'taker_buy_volume':70},
        {'open':101,'high':104,'low':100,'close':103,'volume':120,'taker_buy_volume':85},
        {'open':103,'high':107,'low':102,'close':106,'volume':180,'taker_buy_volume':135},
        {'open':106,'high':110,'low':105,'close':109,'volume':220,'taker_buy_volume':170},
    ]


def test_positive_flow_watch_is_not_entry_authorization():
    r=analyze_smart_money_flow([{'symbol':'ABCUSDT','candles':rows(),'benchmark_return_pct':0.1}])
    x=r['results'][0]
    assert x['flow_direction']=='BUY_PRESSURE'
    assert x['score'] > 0
    assert x['entry_authorized'] is False
    assert r['real_orders_enabled'] is False and r['capital_usdt']==1000


def test_missing_or_invalid_data_fails_closed():
    x=analyze_smart_money_flow([{'symbol':'X','candles':[]}])['results'][0]
    assert x['decision']=='INSUFFICIENT_DATA' and x['score']==0


def test_bad_taker_volume_is_not_used():
    c=rows(); c[-1]['taker_buy_volume']=9999
    x=analyze_smart_money_flow([{'symbol':'X','candles':c}])['results'][0]
    assert 'taker_buy_volume_share' not in x['evidence']
    assert 'TAKER_BUY_VOLUME_UNAVAILABLE' in x['warnings']


def test_invalid_input_shape_rejected():
    with pytest.raises(ValueError): analyze_smart_money_flow({})
