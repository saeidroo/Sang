import hashlib, json
import numpy as np
import pytest
from backend.btc_dataset import build_btc_4h_dataset
from backend.btc_source_reconciliation import reconcile_candles
from backend.btc_training_lineage import build_lineage_manifest
from backend.btc_baseline import evaluate_btc_4h_baselines
from backend.btc_training_replay import execute_baseline_replay
from backend.btc_training_registry import (register_replay_artifact, load_replay_run,
    list_replay_runs)

def _sha(x):
    raw=json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()
def _dataset(tmp):
    rows=[]; p=30000.
    for i in range(260):
        p*=1+.0005+.003*np.sin(i/8)
        rows.append({'t':i*14400000,'open':p*.999,'high':p*1.003,'low':p*.997,'close':p,'volume':100+i})
    snap={'version':'btc-4h-store-v1','symbol':'BTCUSDT','timeframe':'4h','data_sha256':_sha(rows),'candles':rows,'source_batches':['a'*64]}
    sp=tmp/'snapshot.json'; sp.write_text(json.dumps(snap,sort_keys=True))
    rec=reconcile_candles(rows,rows); rec.update({'status':'PASS','training_allowed':True}); rec['report_sha256']=_sha(rec)
    rp=tmp/'recon.json'; rp.write_text(json.dumps(rec,sort_keys=True))
    raw=build_btc_4h_dataset(rows,n_splits=3)
    lin=build_lineage_manifest(sp,rp,raw['manifest'])
    return build_btc_4h_dataset(rows,n_splits=3,lineage_manifest=lin)

def _setup(tmp):
    ds=_dataset(tmp); reg=tmp/'registry'
    original=evaluate_btc_4h_baselines(ds,training_registry_dir=reg)
    first=next(iter(original['training_runs'].values()))
    pred=original['oof_predictions']
    replay=execute_baseline_replay(ds,pred.to_dict(orient='records'),
        original_run_id=first['run_id'],replay_run_id='replay-w-test',artifact_dir=tmp/'artifacts')
    return reg,replay

def test_replay_registry_append_load_and_list(tmp_path):
    reg,replay=_setup(tmp_path)
    result=register_replay_artifact(replay,registry_dir=reg)
    assert result['comparison_status']=='PASS'
    loaded=load_replay_run('replay-w-test',registry_dir=reg)
    assert loaded['replay_artifact']['artifact_sha256']==replay['artifact_sha256']
    assert list_replay_runs(registry_dir=reg)[0]['replay_run_id']=='replay-w-test'

def test_duplicate_replay_id_rejected(tmp_path):
    reg,replay=_setup(tmp_path)
    register_replay_artifact(replay,registry_dir=reg)
    with pytest.raises(ValueError,match='duplicate'):
        register_replay_artifact(replay,registry_dir=reg)

def test_replay_artifact_tamper_detected(tmp_path):
    reg,replay=_setup(tmp_path); register_replay_artifact(replay,registry_dir=reg)
    path=reg/'btc_training_replays.jsonl'; row=json.loads(path.read_text())
    row['replay_artifact']['comparisons']['tampered']={'deterministic':True}
    path.write_text(json.dumps(row,sort_keys=True,separators=(',',':'))+'\n')
    with pytest.raises(ValueError,match='(record_hash_mismatch|chain_hash_mismatch)'):
        load_replay_run('replay-w-test',registry_dir=reg)

def test_replay_dataset_binding_mismatch_rejected(tmp_path):
    reg,replay=_setup(tmp_path); replay['dataset_hash']='0'*64
    body=dict(replay); body.pop('artifact_sha256')
    replay['artifact_sha256']=_sha(body)
    with pytest.raises(ValueError,match='lineage_binding_mismatch'):
        register_replay_artifact(replay,registry_dir=reg)


def test_replay_registry_chain_and_original_immutability(tmp_path):
    from backend.btc_training_registry import audit_replay_registry, load_training_run
    reg, replay = _setup(tmp_path)
    original_before = load_training_run(replay['original_run_id'], registry_dir=reg)
    register_replay_artifact(replay, registry_dir=reg)
    second = dict(replay)
    second['replay_run_id'] = 'replay-w-second'
    body = dict(second); body.pop('artifact_sha256')
    second['artifact_sha256'] = _sha(body)
    register_replay_artifact(second, registry_dir=reg)
    original_after = load_training_run(replay['original_run_id'], registry_dir=reg)
    assert original_before == original_after
    audit = audit_replay_registry(registry_dir=reg)
    assert audit['status'] == 'PASS' and audit['record_count'] == 2
    rows = [json.loads(x) for x in (reg/'btc_training_replays.jsonl').read_text().splitlines()]
    assert rows[0]['sequence'] == 1 and rows[1]['sequence'] == 2
    assert rows[1]['previous_chain_sha256'] == rows[0]['chain_sha256']


def test_replay_registry_detects_deleted_or_reordered_record(tmp_path):
    from backend.btc_training_registry import audit_replay_registry
    reg, replay = _setup(tmp_path)
    register_replay_artifact(replay, registry_dir=reg)
    second = dict(replay); second['replay_run_id'] = 'replay-w-second'
    body = dict(second); body.pop('artifact_sha256')
    second['artifact_sha256'] = _sha(body)
    register_replay_artifact(second, registry_dir=reg)
    path = reg/'btc_training_replays.jsonl'
    lines = path.read_text().splitlines()
    path.write_text(lines[1]+'\n'+lines[0]+'\n')
    with pytest.raises(ValueError, match='sequence|chain'):
        audit_replay_registry(registry_dir=reg)


def test_replay_registry_detects_chain_hash_tamper(tmp_path):
    from backend.btc_training_registry import audit_replay_registry
    reg, replay = _setup(tmp_path)
    register_replay_artifact(replay, registry_dir=reg)
    path = reg/'btc_training_replays.jsonl'
    row = json.loads(path.read_text())
    row['chain_sha256'] = '0'*64
    path.write_text(json.dumps(row)+'\n')
    with pytest.raises(ValueError, match='chain_hash'):
        audit_replay_registry(registry_dir=reg)


def test_replay_query_filters(tmp_path):
    from backend.btc_training_registry import query_replay_runs
    reg, replay = _setup(tmp_path)
    register_replay_artifact(replay, registry_dir=reg)
    second = dict(replay); second['replay_run_id'] = 'replay-query-second'
    body = dict(second); body.pop('artifact_sha256')
    second['artifact_sha256'] = _sha(body)
    register_replay_artifact(second, registry_dir=reg)
    assert len(query_replay_runs(registry_dir=reg, original_run_id=replay['original_run_id'])) == 2
    assert query_replay_runs(registry_dir=reg, replay_run_id='replay-query-second')[0]['sequence'] == 2
    assert query_replay_runs(registry_dir=reg, min_sequence=2, max_sequence=2)[0]['replay_run_id'] == 'replay-query-second'
    assert query_replay_runs(registry_dir=reg, comparison_status='PASS')


def test_external_head_anchor_detects_tail_truncation(tmp_path):
    from backend.btc_training_registry import (audit_replay_registry_anchor,
        checkpoint_replay_registry)
    reg, replay = _setup(tmp_path)
    register_replay_artifact(replay, registry_dir=reg)
    anchor = tmp_path / 'external_backup' / 'replay_head.jsonl'
    created = checkpoint_replay_registry(registry_dir=reg, anchor_path=anchor)
    assert created['status'] == 'ANCHORED'
    assert audit_replay_registry_anchor(registry_dir=reg, anchor_path=anchor)['status'] == 'PASS'
    # Truncate the replay log after the external checkpoint was durably written.
    (reg / 'btc_training_replays.jsonl').write_text('', encoding='utf-8')
    with pytest.raises(ValueError, match='tail_truncated'):
        audit_replay_registry_anchor(registry_dir=reg, anchor_path=anchor)


def test_external_anchor_detects_head_replacement_and_is_append_only(tmp_path):
    from backend.btc_training_registry import (audit_replay_registry_anchor,
        checkpoint_replay_registry)
    reg, replay = _setup(tmp_path)
    register_replay_artifact(replay, registry_dir=reg)
    anchor = tmp_path / 'separate_volume' / 'head.jsonl'
    first = checkpoint_replay_registry(registry_dir=reg, anchor_path=anchor)
    same = checkpoint_replay_registry(registry_dir=reg, anchor_path=anchor)
    assert same['status'] == 'UNCHANGED'
    second = dict(replay); second['replay_run_id'] = 'replay-anchor-second'
    body = dict(second); body.pop('artifact_sha256')
    second['artifact_sha256'] = _sha(body)
    register_replay_artifact(second, registry_dir=reg)
    next_anchor = checkpoint_replay_registry(registry_dir=reg, anchor_path=anchor)
    assert next_anchor['anchor_sequence'] == first['anchor_sequence'] + 1
    assert audit_replay_registry_anchor(registry_dir=reg, anchor_path=anchor)['status'] == 'PASS'
    rows = [json.loads(x) for x in anchor.read_text().splitlines()]
    assert len(rows) == 2 and rows[1]['previous_anchor_sha256'] == rows[0]['anchor_sha256']
