import pandas as pd
import pytest
from backend.supply_demand import analyze_supply_demand


def fixture_frame():
    rows=[]
    for i in range(50):
        o=c=100.0; h=101.0; l=99.0
        if i==20: o,c,h,l=108.0,109.0,110.0,107.5
        if i in (24,25,26): o,c,h,l=96.0,96.5,97.0,95.5
        if i==48: o,c,h,l=106.0,107.0,107.5,105.5
        if i==49: o,c,h,l=107.5,108.0,108.5,107.0
        rows.append({'open':o,'high':h,'low':l,'close':c,'volume':100})
    return pd.DataFrame(rows)


def test_detects_supply_zone_above_long_price():
    result=analyze_supply_demand(fixture_frame(),side='LONG',atr_value=2.0,pivot_width=2)
    assert any(z['type']=='SUPPLY' for z in result['zones'])
    assert result['state']=='OPPOSING_ZONE_NEAR'
    assert result['blocking'] is True


def test_directional_zone_selection_for_short():
    result=analyze_supply_demand(fixture_frame(),side='SHORT',atr_value=2.0,pivot_width=2)
    assert result['side']=='SHORT'
    assert result['blocking'] is False


def test_insufficient_history_is_unavailable():
    result=analyze_supply_demand(fixture_frame().head(5),side='LONG',atr_value=2.0,pivot_width=3)
    assert result['state']=='UNAVAILABLE'
    assert not result['blocking']


def test_invalid_ohlc_does_not_block():
    df=fixture_frame(); df.loc[49,'high']=1
    result=analyze_supply_demand(df,side='LONG',atr_value=2.0,pivot_width=2)
    assert result['state']=='INVALID'
    assert not result['blocking']


def test_invalid_side_raises():
    with pytest.raises(ValueError):
        analyze_supply_demand(fixture_frame(),side='BUY',atr_value=2.0)
