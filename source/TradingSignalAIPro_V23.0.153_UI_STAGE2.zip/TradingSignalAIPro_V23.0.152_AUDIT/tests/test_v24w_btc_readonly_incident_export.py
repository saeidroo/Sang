import json,zipfile,pytest
from datetime import datetime,timezone,timedelta
from backend.btc_readonly_incident_export import build_incident_export_bundle,verify_incident_export_bundle,submit_incident_bundle_to_witness
from backend.witness_server import bootstrap_keys,init_db,record_anchor
from backend.btc_live_environment_validation import validate_live_environment
from backend.btc_readonly_rolling_slo import build_readonly_rolling_slo
from backend.btc_readonly_incidents import record_readonly_slo_incidents

NOW=datetime(2026,11,17,12,0,tzinfo=timezone.utc)
def fetcher(**kwargs):
 return {'status':'PASS','selected_source':'Binance','fallback_used':False,
  'reconciliation':{'status':'PASS','compared_candles':120,'primary_sha256':'a'*64,'backup_sha256':'b'*64},
  'source_observations':{'Binance':{'status':'PASS','row_count':120,'latest_age_hours':1,'candles_sha256':'a'*64},
   'OKX':{'status':'PASS','row_count':120,'latest_age_hours':1,'candles_sha256':'b'*64}},
  'errors':{},'read_only':True,'training_allowed':False,'live_orders':False}
def make_log(path):
 reports=[validate_live_environment(fetcher=fetcher,now_utc=NOW-timedelta(hours=i)) for i in (2,1,0)]
 slo=build_readonly_rolling_slo(reports,min_reports=3,operator_approved=True,now_utc=NOW)
 # A valid healthy SLO with no incidents creates a valid empty audit log.
 path.write_text('')
 return path

def test_export_and_verify_empty_log(tmp_path):
 log=make_log(tmp_path/'incidents.jsonl'); out=tmp_path/'export.zip'
 built=build_incident_export_bundle(log_path=log,output_path=out)
 checked=verify_incident_export_bundle(out)
 assert built['event_count']==0 and checked['valid'] is True
 with pytest.raises(FileExistsError): build_incident_export_bundle(log_path=log,output_path=out)

def test_export_preserves_and_verifies_incident_chain(tmp_path):
 log=tmp_path/'incidents.jsonl'; make_log(log)
 reports=[validate_live_environment(fetcher=fetcher,now_utc=NOW-timedelta(hours=i)) for i in (2,1,0)]
 def degraded(**kwargs):
  x=fetcher(); x['status']='DEGRADED'; x['selected_source']='Binance'; x['errors']={'OKX':'offline'}
  x['source_observations']['OKX']={'status':'UNAVAILABLE'}; return x
 reports[-1]=validate_live_environment(fetcher=degraded,now_utc=NOW)
 stop=build_readonly_rolling_slo(reports,min_reports=3,operator_approved=True,now_utc=NOW)
 record_readonly_slo_incidents(stop,log_path=log,now_utc=NOW)
 out=tmp_path/'chain.zip'; build_incident_export_bundle(log_path=log,output_path=out)
 assert verify_incident_export_bundle(out)['event_count']==1

def test_bundle_tamper_rejected(tmp_path):
 log=make_log(tmp_path/'incidents.jsonl'); out=tmp_path/'bundle.zip'
 build_incident_export_bundle(log_path=log,output_path=out)
 tampered=tmp_path/'tampered.zip'
 with zipfile.ZipFile(out,'r') as source, zipfile.ZipFile(tampered,'w') as target:
  target.writestr('manifest.json',source.read('manifest.json'))
  target.writestr('incidents.jsonl',b'{tampered}')
 with pytest.raises(ValueError,match='log_hash_mismatch'): verify_incident_export_bundle(tampered)

def test_external_witness_receipt_verified(tmp_path):
 log=make_log(tmp_path/'incidents.jsonl'); out=tmp_path/'bundle.zip'
 build_incident_export_bundle(log_path=log,output_path=out)
 priv=tmp_path/'witness-private.pem'; pub=tmp_path/'witness-public.pem'; db=tmp_path/'witness.sqlite'
 bootstrap_keys(priv,pub); init_db(db)
 def fake_post(endpoint,payload,token,timeout):
  assert endpoint=='https://witness.example'
  assert token=='do-not-persist'
  return record_anchor(db,priv,payload['anchor'])
 result=submit_incident_bundle_to_witness(out,endpoint='https://witness.example',
  bearer_token='do-not-persist',pinned_public_key_path=pub,post_json=fake_post)
 assert result['anchored'] and result['signature_verified']
 assert result['training_allowed'] is False and result['live_orders'] is False

def test_bad_witness_receipt_rejected(tmp_path):
 log=make_log(tmp_path/'incidents.jsonl'); out=tmp_path/'bundle.zip'
 build_incident_export_bundle(log_path=log,output_path=out)
 priv=tmp_path/'witness-private.pem'; pub=tmp_path/'witness-public.pem'; db=tmp_path/'witness.sqlite'
 bootstrap_keys(priv,pub); init_db(db)
 def fake_post(endpoint,payload,token,timeout):
  receipt=record_anchor(db,priv,payload['anchor']); receipt['sequence']=receipt['sequence']+1; return receipt
 with pytest.raises(Exception):
  submit_incident_bundle_to_witness(out,endpoint='https://witness.example',bearer_token='token',
   pinned_public_key_path=pub,post_json=fake_post)
