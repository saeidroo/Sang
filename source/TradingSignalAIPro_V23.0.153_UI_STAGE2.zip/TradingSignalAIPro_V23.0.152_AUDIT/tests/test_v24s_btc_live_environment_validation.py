import json
import pytest
from backend.btc_live_environment_validation import (
    validate_live_environment, verify_live_environment_report, save_live_environment_report,
)


def good_fetcher(**kwargs):
    return {'status':'PASS','selected_source':'Binance','fallback_used':False,
            'reconciliation':{'status':'PASS','compared_candles':120},
            'training_allowed':False,'live_orders':False,'read_only':True}


def test_pass_report_and_verify():
    report = validate_live_environment(fetcher=good_fetcher)
    assert report['status'] == 'PASS'
    assert report['training_allowed'] is False and report['live_orders'] is False
    assert verify_live_environment_report(report)['valid'] is True


def test_network_failure_is_blocked_and_saved(tmp_path):
    def fail(**kwargs): raise RuntimeError('offline')
    report = validate_live_environment(fetcher=fail)
    assert report['status'] == 'BLOCKED'
    path = tmp_path/'report.json'
    saved = save_live_environment_report(report, output_path=path)
    assert saved['saved'] is True
    assert json.loads(path.read_text())['status'] == 'BLOCKED'


def test_tamper_detected():
    report = validate_live_environment(fetcher=good_fetcher)
    report['status'] = 'PASS'
    report['training_allowed'] = True
    with pytest.raises(ValueError, match='hash_mismatch'):
        verify_live_environment_report(report)


def test_immutable_output(tmp_path):
    report = validate_live_environment(fetcher=good_fetcher)
    path = tmp_path/'report.json'
    save_live_environment_report(report, output_path=path)
    with pytest.raises(FileExistsError):
        save_live_environment_report(report, output_path=path)
