from backend.master_market_intelligence import analyze_master_market_intelligence


def test_fuses_bullish_sweep_and_bid_absorption_without_dropping_direction():
    result = analyze_master_market_intelligence([{
        'symbol': 'BTCUSDT',
        'evidence': {
            'technical': {'score': 82, 'direction': 'BUY'},
            'smart_money_flow': {'score': 78, 'direction': 'BUY_PRESSURE'},
        },
        'market_signals': {
            'liquidity_sweep': {'sweep_type': 'SELL_SIDE', 'decision': 'CONFIRMED_BULLISH_SWEEP', 'score': 75},
            'absorption': {'context': 'POTENTIALLY_BULLISH', 'decision': 'PERSISTENT_BID_ABSORPTION_CANDIDATE'},
        },
    }])['results'][0]
    assert result['direction'] == 'BULLISH'
    assert 'liquidity' in result['evidence']
    assert 'absorption' in result['evidence']
    assert result['entry_authorized'] is False


def test_fuses_bearish_trap_and_ask_absorption():
    result = analyze_master_market_intelligence([{
        'symbol': 'ETHUSDT',
        'evidence': {'technical': {'score': 80, 'direction': 'SELL'},
                     'smart_money_flow': {'score': 75, 'direction': 'SELL_PRESSURE'}},
        'market_signals': {
            'trap': {'trap_type': 'BULL_TRAP_CANDIDATE', 'score': 65, 'confirmed_by_follow_through': True},
            'absorption': {'context': 'POTENTIALLY_BEARISH', 'decision': 'PERSISTENT_ASK_ABSORPTION_CANDIDATE'},
        },
    }])['results'][0]
    assert result['direction'] == 'BEARISH'
    assert 'market_trap' in result['evidence']
    assert 'absorption' in result['evidence']


def test_missing_market_signals_do_not_create_fabricated_evidence():
    result = analyze_master_market_intelligence([{'symbol': 'X', 'evidence': {}}])['results'][0]
    assert result['decision'] == 'INSUFFICIENT_DATA'
    assert result['evidence'] == {}


def test_opposing_signals_are_kept_as_conflict_not_silently_filtered():
    result = analyze_master_market_intelligence([{
        'symbol': 'SOLUSDT',
        'evidence': {'technical': {'score': 80, 'direction': 'BUY'},
                     'smart_money_flow': {'score': 80, 'direction': 'SELL'}},
        'market_signals': {
            'liquidity_sweep': {'sweep_type': 'BUY_SIDE', 'decision': 'CONFIRMED_BEARISH_SWEEP', 'score': 80},
            'absorption': {'context': 'POTENTIALLY_BULLISH', 'decision': 'PERSISTENT_BID_ABSORPTION_CANDIDATE'},
        },
    }])['results'][0]
    assert result['decision'] == 'CONFLICTING_EVIDENCE'
    assert result['conflict_ratio'] > 0
    assert result['entry_authorized'] is False
