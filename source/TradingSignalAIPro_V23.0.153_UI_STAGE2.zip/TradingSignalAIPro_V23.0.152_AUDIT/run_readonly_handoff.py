"""Evaluate final GO/NO-GO for controlled read-only BTC 4h pilot."""
import argparse,json
from backend.btc_readonly_handoff import build_readonly_handoff,verify_readonly_handoff

def main():
 p=argparse.ArgumentParser(description='Final controlled read-only pilot handoff; no training or orders')
 p.add_argument('--live-reports',nargs='+',required=True); p.add_argument('--operator-review',required=True)
 p.add_argument('--rolling-slo',required=True); p.add_argument('--incident-bundle',required=True)
 p.add_argument('--witness-receipt',required=True); p.add_argument('--witness-public-key',required=True)
 p.add_argument('--highwater',required=True); p.add_argument('--recovery-dir',required=True)
 p.add_argument('--operator-approved',action='store_true'); p.add_argument('--output',required=True)
 a=p.parse_args(); result=build_readonly_handoff(live_report_paths=a.live_reports,
  operator_review_path=a.operator_review,rolling_slo_path=a.rolling_slo,
  incident_bundle_path=a.incident_bundle,witness_receipt_path=a.witness_receipt,
  witness_public_key_path=a.witness_public_key,recovery_dir=a.recovery_dir,
  highwater_path=a.highwater,operator_approved=a.operator_approved,output_path=a.output)
 verify_readonly_handoff(result); print(json.dumps(result,ensure_ascii=False,indent=2))
 raise SystemExit(0 if result['decision']=='GO_READONLY' else 2)
if __name__=='__main__': main()
